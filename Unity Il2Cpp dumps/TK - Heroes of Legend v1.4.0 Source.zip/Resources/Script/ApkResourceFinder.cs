using UnityEngine;

namespace Iteedee.ApkReader
{
    public class ApkResourceFinder
    {
        // Fields
        private const long HEADER_START = 0;
        private static short RES_STRING_POOL_TYPE; // static_offset: 0x00000000
        private static short RES_TABLE_TYPE; // static_offset: 0x00000002
        private static short RES_TABLE_PACKAGE_TYPE; // static_offset: 0x00000004
        private static short RES_TABLE_TYPE_TYPE; // static_offset: 0x00000006
        private static short RES_TABLE_TYPE_SPEC_TYPE; // static_offset: 0x00000008
        private string[] valueStringPool; //  0x00000010
        private string[] typeStringPool; //  0x00000018
        private string[] keyStringPool; //  0x00000020
        private int package_id; //  0x00000028
        private System.Collections.Generic.List<string> resIdList; //  0x00000030
        private static byte TYPE_REFERENCE; // static_offset: 0x0000000A
        private static byte TYPE_STRING; // static_offset: 0x0000000B
        private System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>> responseMap; //  0x00000038
        private System.Collections.Generic.Dictionary<int, System.Collections.Generic.List<string>> entryMap; //  0x00000040
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x017BB534 (24884532), len: 112  VirtAddr: 0x017BB534 RVA: 0x017BB534 token: 100684427 methodIndex: 45997 delegateWrapperIndex: 0 methodInvoker: 0
        public ApkResourceFinder()
        {
            //
            // Disasemble & Code
            // 0x017BB534: STP x20, x19, [sp, #-0x20]! | stack[1152921513634255696] = ???;  stack[1152921513634255704] = ???;  //  dest_result_addr=1152921513634255696 |  dest_result_addr=1152921513634255704
            // 0x017BB538: STP x29, x30, [sp, #0x10]  | stack[1152921513634255712] = ???;  stack[1152921513634255720] = ???;  //  dest_result_addr=1152921513634255712 |  dest_result_addr=1152921513634255720
            // 0x017BB53C: ADD x29, sp, #0x10         | X29 = (1152921513634255696 + 16) = 1152921513634255712 (0x100000021A135360);
            // 0x017BB540: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017BB544: LDRB w8, [x20, #0x95d]     | W8 = (bool)static_value_0373895D;       
            // 0x017BB548: MOV x19, x0                | X19 = 1152921513634267728 (0x100000021A138250);//ML01
            // 0x017BB54C: TBNZ w8, #0, #0x17bb568    | if (static_value_0373895D == true) goto label_0;
            // 0x017BB550: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x017BB554: LDR x8, [x8, #0x190]       | X8 = 0x2B8B03C;                         
            // 0x017BB558: LDR w0, [x8]               | W0 = 0x2CD;                             
            // 0x017BB55C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2CD, ????);      
            // 0x017BB560: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BB564: STRB w8, [x20, #0x95d]     | static_value_0373895D = true;            //  dest_result_addr=57903453
            label_0:
            // 0x017BB568: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x017BB56C: LDR x8, [x8, #0x1e0]       | X8 = 1152921504615792640;               
            // 0x017BB570: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>> val_1 = null;
            // 0x017BB574: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x017BB578: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x017BB57C: LDR x8, [x8, #0xf98]       | X8 = 1152921513634242704;               
            // 0x017BB580: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BB584: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>::.ctor();
            // 0x017BB588: BL #0x2413320              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>();
            // 0x017BB58C: STR x20, [x19, #0x40]      | this.entryMap = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921513634267792
            this.entryMap = val_1;
            // 0x017BB590: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017BB594: MOV x0, x19                | X0 = 1152921513634267728 (0x100000021A138250);//ML01
            // 0x017BB598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB59C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017BB5A0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BBD98 (24886680), len: 152  VirtAddr: 0x017BBD98 RVA: 0x017BBD98 token: 100684428 methodIndex: 45998 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>> initialize()
        {
            //
            // Disasemble & Code
            // 0x017BBD98: STP x22, x21, [sp, #-0x30]! | stack[1152921513634404640] = ???;  stack[1152921513634404648] = ???;  //  dest_result_addr=1152921513634404640 |  dest_result_addr=1152921513634404648
            // 0x017BBD9C: STP x20, x19, [sp, #0x10]  | stack[1152921513634404656] = ???;  stack[1152921513634404664] = ???;  //  dest_result_addr=1152921513634404656 |  dest_result_addr=1152921513634404664
            // 0x017BBDA0: STP x29, x30, [sp, #0x20]  | stack[1152921513634404672] = ???;  stack[1152921513634404680] = ???;  //  dest_result_addr=1152921513634404672 |  dest_result_addr=1152921513634404680
            // 0x017BBDA4: ADD x29, sp, #0x20         | X29 = (1152921513634404640 + 32) = 1152921513634404672 (0x100000021A159940);
            // 0x017BBDA8: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017BBDAC: LDRB w8, [x20, #0x95e]     | W8 = (bool)static_value_0373895E;       
            // 0x017BBDB0: MOV x19, x0                | X19 = 1152921513634416688 (0x100000021A15C830);//ML01
            // 0x017BBDB4: TBNZ w8, #0, #0x17bbdd0    | if (static_value_0373895E == true) goto label_0;
            // 0x017BBDB8: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x017BBDBC: LDR x8, [x8, #0x2a0]       | X8 = 0x2B8B040;                         
            // 0x017BBDC0: LDR w0, [x8]               | W0 = 0x2CE;                             
            // 0x017BBDC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2CE, ????);      
            // 0x017BBDC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BBDCC: STRB w8, [x20, #0x95e]     | static_value_0373895E = true;            //  dest_result_addr=57903454
            label_0:
            // 0x017BBDD0: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x017BBDD4: LDR x8, [x8, #0x4e0]       | X8 = (string**)(1152921513634355728)("resources.arsc");
            // 0x017BBDD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BBDDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBDE0: LDR x1, [x8]               | X1 = "resources.arsc";                  
            // 0x017BBDE4: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
            System.Byte[] val_1 = System.IO.File.ReadAllBytes(path:  0);
            // 0x017BBDE8: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017BBDEC: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x017BBDF0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x017BBDF4: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x017BBDF8: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_2 = null;
            // 0x017BBDFC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BBE00: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x017BBE04: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x017BBE08: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BBE0C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017BBE10: BL #0x25e9474              | .ctor();                                
            val_2 = new System.Collections.Generic.List<System.String>();
            // 0x017BBE14: MOV x0, x19                | X0 = 1152921513634416688 (0x100000021A15C830);//ML01
            // 0x017BBE18: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x017BBE1C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017BBE20: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017BBE24: MOV x2, x21                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BBE28: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017BBE2C: B #0x17bb5a4               | return this.processResourceTable(data:  val_1, resIdList:  val_2);
            return this.processResourceTable(data:  val_1, resIdList:  val_2);
        
        }
        //
        // Offset in libil2cpp.so: 0x017BB5A4 (24884644), len: 1936  VirtAddr: 0x017BB5A4 RVA: 0x017BB5A4 token: 100684429 methodIndex: 45999 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>> processResourceTable(byte[] data, System.Collections.Generic.List<string> resIdList)
        {
            //
            // Disasemble & Code
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            System.Byte[] val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> val_22;
            //  | 
            System.IO.BinaryReader val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x017BB5A4: STP x28, x27, [sp, #-0x60]! | stack[1152921513634658640] = ???;  stack[1152921513634658648] = ???;  //  dest_result_addr=1152921513634658640 |  dest_result_addr=1152921513634658648
            // 0x017BB5A8: STP x26, x25, [sp, #0x10]  | stack[1152921513634658656] = ???;  stack[1152921513634658664] = ???;  //  dest_result_addr=1152921513634658656 |  dest_result_addr=1152921513634658664
            // 0x017BB5AC: STP x24, x23, [sp, #0x20]  | stack[1152921513634658672] = ???;  stack[1152921513634658680] = ???;  //  dest_result_addr=1152921513634658672 |  dest_result_addr=1152921513634658680
            // 0x017BB5B0: STP x22, x21, [sp, #0x30]  | stack[1152921513634658688] = ???;  stack[1152921513634658696] = ???;  //  dest_result_addr=1152921513634658688 |  dest_result_addr=1152921513634658696
            // 0x017BB5B4: STP x20, x19, [sp, #0x40]  | stack[1152921513634658704] = ???;  stack[1152921513634658712] = ???;  //  dest_result_addr=1152921513634658704 |  dest_result_addr=1152921513634658712
            // 0x017BB5B8: STP x29, x30, [sp, #0x50]  | stack[1152921513634658720] = ???;  stack[1152921513634658728] = ???;  //  dest_result_addr=1152921513634658720 |  dest_result_addr=1152921513634658728
            // 0x017BB5BC: ADD x29, sp, #0x50         | X29 = (1152921513634658640 + 80) = 1152921513634658720 (0x100000021A1979A0);
            // 0x017BB5C0: SUB sp, sp, #0x10          | SP = (1152921513634658640 - 16) = 1152921513634658624 (0x100000021A197940);
            // 0x017BB5C4: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x017BB5C8: LDRB w8, [x22, #0x95f]     | W8 = (bool)static_value_0373895F;       
            // 0x017BB5CC: MOV x19, x2                | X19 = resIdList;//m1                    
            // 0x017BB5D0: MOV x20, x1                | X20 = data;//m1                         
            // 0x017BB5D4: MOV x21, x0                | X21 = 1152921513634670736 (0x100000021A19A890);//ML01
            // 0x017BB5D8: TBNZ w8, #0, #0x17bb5f4    | if (static_value_0373895F == true) goto label_0;
            // 0x017BB5DC: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x017BB5E0: LDR x8, [x8, #0xbd8]       | X8 = 0x2B8B048;                         
            // 0x017BB5E4: LDR w0, [x8]               | W0 = 0x2D0;                             
            // 0x017BB5E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2D0, ????);      
            // 0x017BB5EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BB5F0: STRB w8, [x22, #0x95f]     | static_value_0373895F = true;            //  dest_result_addr=57903455
            label_0:
            // 0x017BB5F4: STR x19, [x21, #0x30]      | this.resIdList = resIdList;              //  dest_result_addr=1152921513634670784
            this.resIdList = resIdList;
            // 0x017BB5F8: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x017BB5FC: LDR x8, [x8, #0x298]       | X8 = 1152921504615792640;               
            // 0x017BB600: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> val_1 = null;
            // 0x017BB604: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x017BB608: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x017BB60C: LDR x8, [x8, #0x468]       | X8 = 1152921513634582512;               
            // 0x017BB610: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BB614: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::.ctor();
            // 0x017BB618: BL #0x23fb0c4              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>();
            // 0x017BB61C: STR x19, [x21, #0x38]      | this.responseMap = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921513634670792
            this.responseMap = val_1;
            // 0x017BB620: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x017BB624: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x017BB628: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_2 = null;
            // 0x017BB62C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BB630: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BB634: MOV x1, x20                | X1 = data;//m1                          
            // 0x017BB638: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BB63C: BL #0x1e78658              | .ctor(buffer:  data);                   
            val_2 = new System.IO.MemoryStream(buffer:  data);
            // 0x017BB640: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x017BB644: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x017BB648: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            // 0x017BB64C: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            // 0x017BB650: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x017BB654: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BB658: MOV x20, x0                | X20 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB65C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            // 0x017BB660: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BB664: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            System.IO.BinaryReader val_3 = null;
            // 0x017BB668: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BB66C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x017BB670: BL #0x1e664fc              | .ctor(input:  val_2);                   
            val_3 = new System.IO.BinaryReader(input:  val_2);
            // 0x017BB674: CBNZ x20, #0x17bb67c       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x017BB678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_2), ????);
            label_1:
            // 0x017BB67C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB680: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BB684: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BB688: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB68C: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BB690: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB694: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB698: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BB69C: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BB6A0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB6A4: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BB6A8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB6AC: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BB6B0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BB6B4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB6B8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BB6BC: MOV w23, w0                | W23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB6C0: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB6C4: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BB6C8: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BB6CC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB6D0: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BB6D4: MOV w22, w0                | W22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB6D8: ADRP x26, #0x3656000       | X26 = 56975360 (0x3656000);             
            // 0x017BB6DC: LDR x26, [x26, #0x670]     | X26 = 1152921504856686592;              
            // 0x017BB6E0: LDR x0, [x26]              | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_16 = null;
            // 0x017BB6E4: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BB6E8: TBZ w8, #0, #0x17bb6fc     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x017BB6EC: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BB6F0: CBNZ w8, #0x17bb6fc        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x017BB6F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BB6F8: LDR x0, [x26]              | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_16 = null;
            label_3:
            // 0x017BB6FC: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BB700: AND w9, w24, #0xffff       | W9 = (null & 65535) = 16384 (0x00004000);
            // 0x017BB704: LDRH w8, [x8, #2]          | W8 = Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE;
            // 0x017BB708: CMP w9, w8                 | STATE = COMPARE(0x4000, Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE)
            // 0x017BB70C: B.NE #0x17bbbdc            | if (16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE) goto label_4;
            if(16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE)
            {
                goto label_4;
            }
            // 0x017BB710: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB714: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB718: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB71C: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB720: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB724: CBNZ x24, #0x17bb72c       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x017BB728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_5:
            // 0x017BB72C: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BB730: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x017BB734: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB738: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x017BB73C: SXTW x8, w23               | X8 = 13844480 (0x00D34000);             
            // 0x017BB740: STR w22, [sp, #0xc]        | stack[1152921513634658636] = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921513634658636
            // 0x017BB744: CMP x8, x0                 | STATE = COMPARE(0xD34000, typeof(System.IO.BinaryReader))
            // 0x017BB748: B.NE #0x17bbc20            | if (13844480 != null) goto label_6;     
            if(13844480 != null)
            {
                goto label_6;
            }
            // 0x017BB74C: ADRP x22, #0x35db000       | X22 = 56471552 (0x35DB000);             
            // 0x017BB750: LDR x22, [x22, #0xf00]     | X22 = 1152921504996170800;              
            // 0x017BB754: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x017BB758: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_31:
            // 0x017BB75C: CBNZ x20, #0x17bb764       | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x017BB760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_7:
            // 0x017BB764: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB768: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB76C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB770: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB774: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB778: CBNZ x23, #0x17bb780       | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x017BB77C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_8:
            // 0x017BB780: LDR x8, [x23]              | X8 = ;                                  
            // 0x017BB784: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BB788: MOV x0, x23                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB78C: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BB790: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB794: CBNZ x20, #0x17bb79c       | if ( != 0) goto label_9;                
            if(null != 0)
            {
                goto label_9;
            }
            // 0x017BB798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_9:
            // 0x017BB79C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB7A0: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BB7A4: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BB7A8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB7AC: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BB7B0: MOV w25, w0                | W25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB7B4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB7B8: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BB7BC: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BB7C0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB7C4: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BB7C8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB7CC: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            val_19 = mem[null + 584];
            // 0x017BB7D0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BB7D4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB7D8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BB7DC: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB7E0: LDR x0, [x26]              | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_20 = null;
            // 0x017BB7E4: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BB7E8: TBZ w8, #0, #0x17bb7fc     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x017BB7EC: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BB7F0: CBNZ w8, #0x17bb7fc        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x017BB7F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BB7F8: LDR x0, [x26]              | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_20 = null;
            label_11:
            // 0x017BB7FC: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BB800: AND w10, w25, #0xffff      | W10 = (null & 65535) = 16384 (0x00004000);
            // 0x017BB804: LDRH w9, [x8]              | W9 = Iteedee.ApkReader.ApkResourceFinder.RES_STRING_POOL_TYPE;
            // 0x017BB808: CMP w10, w9                | STATE = COMPARE(0x4000, Iteedee.ApkReader.ApkResourceFinder.RES_STRING_POOL_TYPE)
            // 0x017BB80C: B.NE #0x17bb8c8            | if (16384 != Iteedee.ApkReader.ApkResourceFinder.RES_STRING_POOL_TYPE) goto label_12;
            if(16384 != Iteedee.ApkReader.ApkResourceFinder.RES_STRING_POOL_TYPE)
            {
                goto label_12;
            }
            // 0x017BB810: CBNZ w28, #0x17bb8c0       | if (0x0 != 0) goto label_13;            
            if(val_18 != 0)
            {
                goto label_13;
            }
            // 0x017BB814: LDR x25, [x22]             | X25 = typeof(System.Byte[]);            
            // 0x017BB818: MOV x0, x25                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BB81C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x017BB820: MOV w1, w24                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB824: MOV x0, x25                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BB828: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x017BB82C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB830: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB834: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB838: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB83C: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB840: CBNZ x25, #0x17bb848       | if ( != 0) goto label_14;               
            if(null != 0)
            {
                goto label_14;
            }
            // 0x017BB844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_14:
            // 0x017BB848: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BB84C: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BB850: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB854: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BB858: CBNZ x20, #0x17bb860       | if ( != 0) goto label_15;               
            if(null != 0)
            {
                goto label_15;
            }
            // 0x017BB85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_15:
            // 0x017BB860: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB864: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB868: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB86C: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB870: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB874: CBNZ x25, #0x17bb87c       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x017BB878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_16:
            // 0x017BB87C: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BB880: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BB884: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BB888: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BB88C: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB890: MOV x1, x23                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB894: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BB898: CBNZ x20, #0x17bb8a0       | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x017BB89C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_17:
            // 0x017BB8A0: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB8A4: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BB8A8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB8AC: MOV w1, w24                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB8B0: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BB8B4: MOV x1, x0                 | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_19 = null;
            // 0x017BB8B8: BL #0x17bbe30              | X0 = processStringPool(data:  val_19 = null);
            System.String[] val_4 = processStringPool(data:  val_19);
            // 0x017BB8BC: STR x0, [x21, #0x10]       | this.valueStringPool = val_4;            //  dest_result_addr=1152921513634670752
            this.valueStringPool = val_4;
            label_13:
            // 0x017BB8C0: ADD w28, w28, #1           | W28 = (val_18 + 1);                     
            val_18 = val_18 + 1;
            // 0x017BB8C4: B #0x17bb9a4               |  goto label_18;                         
            goto label_18;
            label_12:
            // 0x017BB8C8: LDRB w9, [x0, #0x10a]      | W9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BB8CC: TBZ w9, #0, #0x17bb8e4     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x017BB8D0: LDR w9, [x0, #0xbc]        | W9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BB8D4: CBNZ w9, #0x17bb8e4        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x017BB8D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BB8DC: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BB8E0: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            label_20:
            // 0x017BB8E4: LDRH w8, [x8, #4]          | W8 = Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_PACKAGE_TYPE;
            // 0x017BB8E8: AND w9, w25, #0xffff       | W9 = (null & 65535) = 16384 (0x00004000);
            // 0x017BB8EC: CMP w9, w8                 | STATE = COMPARE(0x4000, Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_PACKAGE_TYPE)
            // 0x017BB8F0: B.NE #0x17bbc64            | if (16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_PACKAGE_TYPE) goto label_21;
            if(16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_PACKAGE_TYPE)
            {
                goto label_21;
            }
            // 0x017BB8F4: LDR x25, [x22]             | X25 = typeof(System.Byte[]);            
            // 0x017BB8F8: MOV x0, x25                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BB8FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x017BB900: MOV w1, w24                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB904: MOV x0, x25                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BB908: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x017BB90C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB910: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB914: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB918: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB91C: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB920: CBNZ x25, #0x17bb928       | if ( != 0) goto label_22;               
            if(null != 0)
            {
                goto label_22;
            }
            // 0x017BB924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_22:
            // 0x017BB928: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BB92C: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BB930: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB934: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BB938: CBNZ x20, #0x17bb940       | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x017BB93C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_23:
            // 0x017BB940: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB944: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB948: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB94C: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB950: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB954: CBNZ x25, #0x17bb95c       | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x017BB958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_24:
            // 0x017BB95C: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BB960: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BB964: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BB968: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BB96C: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB970: MOV x1, x23                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB974: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BB978: CBNZ x20, #0x17bb980       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x017BB97C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_25:
            // 0x017BB980: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB984: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BB988: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB98C: MOV w1, w24                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB990: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BB994: MOV x1, x0                 | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_19 = null;
            // 0x017BB998: MOV x0, x21                | X0 = 1152921513634670736 (0x100000021A19A890);//ML01
            // 0x017BB99C: BL #0x17bc57c              | this.processPackage(data:  val_19 = null);
            this.processPackage(data:  val_19);
            // 0x017BB9A0: ADD w27, w27, #1           | W27 = (val_17 + 1);                     
            val_17 = val_17 + 1;
            label_18:
            // 0x017BB9A4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB9A8: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB9AC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB9B0: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB9B4: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB9B8: CBNZ x25, #0x17bb9c0       | if ( != 0) goto label_26;               
            if(null != 0)
            {
                goto label_26;
            }
            // 0x017BB9BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_26:
            // 0x017BB9C0: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BB9C4: ADD x1, x23, w24, sxtw     | X1 = (null + (null) << );               
            var val_5 = null + (null << );
            // 0x017BB9C8: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BB9CC: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BB9D0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BB9D4: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB9D8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BB9DC: CBNZ x20, #0x17bb9e4       | if ( != 0) goto label_27;               
            if(null != 0)
            {
                goto label_27;
            }
            // 0x017BB9E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_27:
            // 0x017BB9E4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BB9E8: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BB9EC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB9F0: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BB9F4: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BB9F8: CBNZ x23, #0x17bba00       | if ( != 0) goto label_28;               
            if(null != 0)
            {
                goto label_28;
            }
            // 0x017BB9FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_28:
            // 0x017BBA00: LDR x8, [x23]              | X8 = ;                                  
            // 0x017BBA04: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BBA08: MOV x0, x23                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBA0C: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BBA10: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBA14: CBNZ x20, #0x17bba1c       | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x017BBA18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_29:
            // 0x017BBA1C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBA20: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BBA24: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBA28: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BBA2C: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBA30: CBNZ x24, #0x17bba38       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x017BBA34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_30:
            // 0x017BBA38: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BBA3C: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x017BBA40: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBA44: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x017BBA48: CMP x23, x0                | STATE = COMPARE(typeof(System.IO.BinaryReader), typeof(System.IO.BinaryReader))
            // 0x017BBA4C: B.NE #0x17bb75c            | if (null != null) goto label_31;        
            if(null != null)
            {
                goto label_31;
            }
            // 0x017BBA50: CMP w28, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x017BBA54: B.NE #0x17bbca8            | if (val_18 != 0x1) goto label_32;       
            if(val_18 != 1)
            {
                goto label_32;
            }
            // 0x017BBA58: LDR w8, [sp, #0xc]         | W8 = typeof(System.IO.BinaryReader);    
            // 0x017BBA5C: CMP w27, w8                | STATE = COMPARE((val_17 + 1), typeof(System.IO.BinaryReader))
            // 0x017BBA60: B.NE #0x17bbcec            | if (val_17 != null) goto label_33;      
            if(val_17 != null)
            {
                goto label_33;
            }
            // 0x017BBA64: LDR x22, [x21, #0x38]      | X22 = this.responseMap; //P2            
            val_22 = this.responseMap;
            // 0x017BBA68: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x017BBA6C: MOVZ w23, #0x1d6           | W23 = 470 (0x1D6);//ML01                
            val_24 = 470;
            // 0x017BBA70: B #0x17bba90               |  goto label_34;                         
            goto label_34;
            label_52:
            // 0x017BBA74: CMP w1, #1                 | STATE = COMPARE(mem[null + 400 + 8], 0x1)
            // 0x017BBA78: B.NE #0x17bbae4            | if (mem[null + 400 + 8] != 0x1) goto label_35;
            if((mem[null + 400 + 8]) != 1)
            {
                goto label_35;
            }
            // 0x017BBA7C: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BBA80: LDR x21, [x0]              | X21 = ;                                 
            val_23 = null;
            // 0x017BBA84: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x017BBA88: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x017BBA8C: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.BinaryReader), ????);
            label_34:
            // 0x017BBA90: CBZ x20, #0x17bbb14        | if ( == 0) goto label_36;               
            if(null == 0)
            {
                goto label_36;
            }
            // 0x017BBA94: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BBA98: LDR x8, [x20]              | X8 = ;                                  
            System.IO.BinaryReader val_18 = null;
            // 0x017BBA9C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BBAA0: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BBAA4: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BBAA8: CBZ x9, #0x17bbad4         | if (mem[null + 258] == 0) goto label_37;
            if((mem[null + 258]) == 0)
            {
                goto label_37;
            }
            // 0x017BBAAC: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_16 = mem[null + 152];
            // 0x017BBAB0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_17 = 0;
            // 0x017BBAB4: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_16 = val_16 + 8;
            label_39:
            // 0x017BBAB8: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BBABC: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BBAC0: B.EQ #0x17bbafc            | if ((mem[null + 152] + 8) + -8 == null) goto label_38;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_38;
            }
            // 0x017BBAC4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_17 = val_17 + 1;
            // 0x017BBAC8: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_16 = val_16 + 16;
            // 0x017BBACC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BBAD0: B.LO #0x17bbab8            | if (0 < mem[null + 258]) goto label_39; 
            if(val_17 < (mem[null + 258]))
            {
                goto label_39;
            }
            label_37:
            // 0x017BBAD4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BBAD8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_25 = null;
            // 0x017BBADC: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BBAE0: B #0x17bbb08               |  goto label_40;                         
            goto label_40;
            label_35:
            // 0x017BBAE4: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x017BBAE8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_51:
            // 0x017BBAEC: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BBAF0: LDR x21, [x0]              | X21 = ;                                 
            val_23 = null;
            // 0x017BBAF4: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BBAF8: B #0x17bbb30               |  goto label_43;                         
            goto label_43;
            label_38:
            // 0x017BBAFC: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BBB00: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_18 = val_18 + (((mem[null + 152] + 8)) << 4);
            // 0x017BBB04: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_40:
            // 0x017BBB08: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.BinaryReader.__il2cppRuntimeField_gc_desc; //  | 
            // 0x017BBB0C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBB10: BLR x8                     | X0 = x8();                              
            label_36:
            // 0x017BBB14: CMP w23, #0x1d6            | STATE = COMPARE(0x0, 0x1D6)             
            // 0x017BBB18: B.EQ #0x17bbb30            | if (val_24 == 0x1D6) goto label_43;     
            if(val_24 == 470)
            {
                goto label_43;
            }
            // 0x017BBB1C: CBZ x21, #0x17bbb30        | if ( == 0) goto label_43;               
            if(val_23 == 0)
            {
                goto label_43;
            }
            // 0x017BBB20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BBB24: MOV x0, x21                | X0 = X21;//m1                           
            // 0x017BBB28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            // 0x017BBB2C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_43:
            // 0x017BBB30: CBZ x19, #0x17bbb9c        | if ( == 0) goto label_44;               
            if(null == 0)
            {
                goto label_44;
            }
            // 0x017BBB34: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BBB38: LDR x8, [x19]              | X8 = ;                                  
            System.IO.MemoryStream val_21 = null;
            // 0x017BBB3C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BBB40: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BBB44: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BBB48: CBZ x9, #0x17bbb74         | if (mem[null + 258] == 0) goto label_45;
            if((mem[null + 258]) == 0)
            {
                goto label_45;
            }
            // 0x017BBB4C: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_19 = mem[null + 152];
            // 0x017BBB50: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_20 = 0;
            // 0x017BBB54: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_19 = val_19 + 8;
            label_47:
            // 0x017BBB58: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BBB5C: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BBB60: B.EQ #0x17bbb84            | if ((mem[null + 152] + 8) + -8 == null) goto label_46;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_46;
            }
            // 0x017BBB64: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_20 = val_20 + 1;
            // 0x017BBB68: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_19 = val_19 + 16;
            // 0x017BBB6C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BBB70: B.LO #0x17bbb58            | if (0 < mem[null + 258]) goto label_47; 
            if(val_20 < (mem[null + 258]))
            {
                goto label_47;
            }
            label_45:
            // 0x017BBB74: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BBB78: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_26 = val_2;
            // 0x017BBB7C: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BBB80: B #0x17bbb90               |  goto label_48;                         
            goto label_48;
            label_46:
            // 0x017BBB84: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BBB88: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_21 = val_21 + (((mem[null + 152] + 8)) << 4);
            // 0x017BBB8C: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_48:
            // 0x017BBB90: LDP x8, x1, [x0]           |                                          //  not_find_field!1:0 |  not_find_field!1:8
            // 0x017BBB94: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BBB98: BLR x8                     | X0 = mem[val_23]();                     
            label_44:
            // 0x017BBB9C: CMP w23, #0x1d6            | STATE = COMPARE(0x0, 0x1D6)             
            // 0x017BBBA0: B.EQ #0x17bbbb4            | if (val_24 == 0x1D6) goto label_50;     
            if(val_24 == 470)
            {
                goto label_50;
            }
            // 0x017BBBA4: CBZ x21, #0x17bbbb4        | if (0x0 == 0) goto label_50;            
            if(val_23 == 0)
            {
                goto label_50;
            }
            // 0x017BBBA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BBBAC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x017BBBB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_50:
            // 0x017BBBB4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x017BBBB8: SUB sp, x29, #0x50         | SP = (1152921513634658720 - 80) = 1152921513634658640 (0x100000021A197950);
            // 0x017BBBBC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x017BBBC0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x017BBBC4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x017BBBC8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x017BBBCC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x017BBBD0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x017BBBD4: RET                        |  return (System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>)null;
            return (System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>)val_22;
            //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>, size=8, nGRN=0 }
            // 0x017BBBD8: B #0x17bbaec               |  goto label_51;                         
            goto label_51;
            label_4:
            // 0x017BBBDC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BBBE0: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BBBE4: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BBBE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BBBEC: MOV x21, x0                | X21 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBBF0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017BBBF4: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921513634624496)("No RES_TABLE_TYPE found!");
            // 0x017BBBF8: LDR x1, [x8]               | X1 = "No RES_TABLE_TYPE found!";        
            // 0x017BBBFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBC00: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_6 = null;
            // 0x017BBC04: BL #0x1c32b48              | .ctor(message:  "No RES_TABLE_TYPE found!");
            val_6 = new System.Exception(message:  "No RES_TABLE_TYPE found!");
            // 0x017BBC08: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x017BBC0C: LDR x8, [x8, #0x1a0]       | X8 = 1152921513634624624;               
            // 0x017BBC10: LDR x1, [x8]               | X1 = public System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> Iteedee.ApkReader.ApkResourceFinder::processResourceTable(byte[] data, System.Collections.Generic.List<string> resIdList);
            // 0x017BBC14: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBC18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BBC1C: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_7 = System.Collections.IEnumerable.GetEnumerator();
            label_6:
            // 0x017BBC20: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BBC24: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BBC28: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BBC2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BBC30: MOV x21, x0                | X21 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBC34: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x017BBC38: LDR x8, [x8, #0xe0]        | X8 = (string**)(1152921513634629744)("The buffer size not matches to the resource table size.");
            // 0x017BBC3C: LDR x1, [x8]               | X1 = "The buffer size not matches to the resource table size.";
            // 0x017BBC40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBC44: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_8 = null;
            // 0x017BBC48: BL #0x1c32b48              | .ctor(message:  "The buffer size not matches to the resource table size.");
            val_8 = new System.Exception(message:  "The buffer size not matches to the resource table size.");
            // 0x017BBC4C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x017BBC50: LDR x8, [x8, #0x1a0]       | X8 = 1152921513634624624;               
            // 0x017BBC54: LDR x1, [x8]               | X1 = public System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> Iteedee.ApkReader.ApkResourceFinder::processResourceTable(byte[] data, System.Collections.Generic.List<string> resIdList);
            // 0x017BBC58: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBC5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BBC60: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_9 = System.Collections.IEnumerable.GetEnumerator();
            label_21:
            // 0x017BBC64: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x017BBC68: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x017BBC6C: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            // 0x017BBC70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x017BBC74: MOV x21, x0                | X21 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x017BBC78: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x017BBC7C: LDR x8, [x8, #0xcb8]       | X8 = (string**)(1152921513634634032)("Unsupported Type");
            // 0x017BBC80: LDR x1, [x8]               | X1 = "Unsupported Type";                
            // 0x017BBC84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBC88: MOV x0, x21                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            System.InvalidOperationException val_10 = null;
            // 0x017BBC8C: BL #0x1e6648c              | .ctor(message:  "Unsupported Type");    
            val_10 = new System.InvalidOperationException(message:  "Unsupported Type");
            // 0x017BBC90: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x017BBC94: LDR x8, [x8, #0x1a0]       | X8 = 1152921513634624624;               
            // 0x017BBC98: LDR x1, [x8]               | X1 = public System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> Iteedee.ApkReader.ApkResourceFinder::processResourceTable(byte[] data, System.Collections.Generic.List<string> resIdList);
            // 0x017BBC9C: MOV x0, x21                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x017BBCA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x017BBCA4: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_11 = System.Collections.IEnumerable.GetEnumerator();
            label_32:
            // 0x017BBCA8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BBCAC: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BBCB0: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BBCB4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BBCB8: MOV x21, x0                | X21 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBCBC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x017BBCC0: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921513634638240)("More than 1 string pool found!");
            // 0x017BBCC4: LDR x1, [x8]               | X1 = "More than 1 string pool found!";  
            // 0x017BBCC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBCCC: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_12 = null;
            // 0x017BBCD0: BL #0x1c32b48              | .ctor(message:  "More than 1 string pool found!");
            val_12 = new System.Exception(message:  "More than 1 string pool found!");
            // 0x017BBCD4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x017BBCD8: LDR x8, [x8, #0x1a0]       | X8 = 1152921513634624624;               
            // 0x017BBCDC: LDR x1, [x8]               | X1 = public System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> Iteedee.ApkReader.ApkResourceFinder::processResourceTable(byte[] data, System.Collections.Generic.List<string> resIdList);
            // 0x017BBCE0: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBCE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BBCE8: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_13 = System.Collections.IEnumerable.GetEnumerator();
            label_33:
            // 0x017BBCEC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BBCF0: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BBCF4: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BBCF8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BBCFC: MOV x21, x0                | X21 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBD00: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x017BBD04: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921513634642464)("Real package count not equals the declared count.");
            // 0x017BBD08: LDR x1, [x8]               | X1 = "Real package count not equals the declared count.";
            // 0x017BBD0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBD10: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_14 = null;
            // 0x017BBD14: BL #0x1c32b48              | .ctor(message:  "Real package count not equals the declared count.");
            val_14 = new System.Exception(message:  "Real package count not equals the declared count.");
            // 0x017BBD18: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x017BBD1C: LDR x8, [x8, #0x1a0]       | X8 = 1152921513634624624;               
            // 0x017BBD20: LDR x1, [x8]               | X1 = public System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> Iteedee.ApkReader.ApkResourceFinder::processResourceTable(byte[] data, System.Collections.Generic.List<string> resIdList);
            // 0x017BBD24: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BBD28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BBD2C: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_15 = System.Collections.IEnumerable.GetEnumerator();
            // 0x017BBD30: B #0x17bba74               |  goto label_52;                         
            goto label_52;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BC57C (24888700), len: 2432  VirtAddr: 0x017BC57C RVA: 0x017BC57C token: 100684430 methodIndex: 46000 delegateWrapperIndex: 0 methodInvoker: 0
        private void processPackage(byte[] data)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            System.IO.Stream val_17;
            //  | 
            var val_18;
            //  | 
            System.Byte[] val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            System.IO.BinaryReader val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x017BC57C: STP x26, x25, [sp, #-0x50]! | stack[1152921513634988976] = ???;  stack[1152921513634988984] = ???;  //  dest_result_addr=1152921513634988976 |  dest_result_addr=1152921513634988984
            // 0x017BC580: STP x24, x23, [sp, #0x10]  | stack[1152921513634988992] = ???;  stack[1152921513634989000] = ???;  //  dest_result_addr=1152921513634988992 |  dest_result_addr=1152921513634989000
            // 0x017BC584: STP x22, x21, [sp, #0x20]  | stack[1152921513634989008] = ???;  stack[1152921513634989016] = ???;  //  dest_result_addr=1152921513634989008 |  dest_result_addr=1152921513634989016
            // 0x017BC588: STP x20, x19, [sp, #0x30]  | stack[1152921513634989024] = ???;  stack[1152921513634989032] = ???;  //  dest_result_addr=1152921513634989024 |  dest_result_addr=1152921513634989032
            // 0x017BC58C: STP x29, x30, [sp, #0x40]  | stack[1152921513634989040] = ???;  stack[1152921513634989048] = ???;  //  dest_result_addr=1152921513634989040 |  dest_result_addr=1152921513634989048
            // 0x017BC590: ADD x29, sp, #0x40         | X29 = (1152921513634988976 + 64) = 1152921513634989040 (0x100000021A1E83F0);
            // 0x017BC594: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BC598: LDRB w8, [x19, #0x960]     | W8 = (bool)static_value_03738960;       
            // 0x017BC59C: MOV x20, x1                | X20 = data;//m1                         
            // 0x017BC5A0: MOV x21, x0                | X21 = 1152921513635001056 (0x100000021A1EB2E0);//ML01
            // 0x017BC5A4: TBNZ w8, #0, #0x17bc5c0    | if (static_value_03738960 == true) goto label_0;
            // 0x017BC5A8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x017BC5AC: LDR x8, [x8, #0x6b0]       | X8 = 0x2B8B044;                         
            // 0x017BC5B0: LDR w0, [x8]               | W0 = 0x2CF;                             
            // 0x017BC5B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2CF, ????);      
            // 0x017BC5B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BC5BC: STRB w8, [x19, #0x960]     | static_value_03738960 = true;            //  dest_result_addr=57903456
            label_0:
            // 0x017BC5C0: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x017BC5C4: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x017BC5C8: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x017BC5CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BC5D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BC5D4: MOV x1, x20                | X1 = data;//m1                          
            // 0x017BC5D8: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_17 = val_1;
            // 0x017BC5DC: BL #0x1e78658              | .ctor(buffer:  data);                   
            val_1 = new System.IO.MemoryStream(buffer:  data);
            // 0x017BC5E0: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x017BC5E4: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x017BC5E8: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            // 0x017BC5EC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x017BC5F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BC5F4: MOV x20, x0                | X20 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC5F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BC5FC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            System.IO.BinaryReader val_2 = null;
            // 0x017BC600: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BC604: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x017BC608: BL #0x1e664fc              | .ctor(input:  val_17);                  
            val_2 = new System.IO.BinaryReader(input:  val_17);
            // 0x017BC60C: CBNZ x20, #0x17bc614       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x017BC610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_17), ????);
            label_1:
            // 0x017BC614: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC618: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BC61C: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BC620: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC624: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BC628: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC62C: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BC630: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BC634: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC638: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BC63C: MOV w23, w0                | W23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC640: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC644: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC648: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC64C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC650: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC654: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC658: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC65C: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC660: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC664: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC668: STR w0, [x21, #0x28]       | this.package_id = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921513635001096
            this.package_id = null;
            // 0x017BC66C: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x017BC670: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x017BC674: LDR x22, [x8]              | X22 = typeof(System.Char[]);            
            // 0x017BC678: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x017BC67C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x017BC680: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
            // 0x017BC684: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x017BC688: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x017BC68C: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x017BC690: ADD x25, x22, #0x20        | X25 = (null + 32) = 1152921504947213104 (0x1000000014499330);
            // 0x017BC694: MOVN x26, #0               | X26 = 0 (0x0);//ML01                    
            var val_18 = 0;
            label_5:
            // 0x017BC698: CBNZ x20, #0x17bc6a0       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x017BC69C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
            label_2:
            // 0x017BC6A0: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC6A4: LDR x1, [x8, #0x208]       |  //  not_find_field!1:520
            // 0x017BC6A8: LDR x9, [x8, #0x200]       |  //  not_find_field!1:512
            // 0x017BC6AC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC6B0: BLR x9                     | X0 = mem[null + 512]();                 
            // 0x017BC6B4: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC6B8: CBNZ x22, #0x17bc6c0       | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x017BC6BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_3:
            // 0x017BC6C0: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
            // 0x017BC6C4: ADD x9, x26, #1            | X9 = (0 + 1);                           
            var val_3 = val_18 + 1;
            // 0x017BC6C8: CMP x9, x8                 | STATE = COMPARE((0 + 1), System.Char[].__il2cppRuntimeField_namespaze)
            // 0x017BC6CC: B.LO #0x17bc6dc            | if (val_3 < System.Char[].__il2cppRuntimeField_namespaze) goto label_4;
            // 0x017BC6D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BC6D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC6D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryReader), ????);
            label_4:
            // 0x017BC6DC: STRH w24, [x25], #2        | System.Char[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_2 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504947213104
            System.Char[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_2 = null;
            // 0x017BC6E0: ADD x26, x26, #1           | X26 = (0 + 1);                          
            val_18 = val_18 + 1;
            // 0x017BC6E4: CMP x26, #0xff             | STATE = COMPARE((0 + 1), 0xFF)          
            // 0x017BC6E8: B.LT #0x17bc698            | if (0 < 0xFF) goto label_5;             
            if(val_18 < 255)
            {
                goto label_5;
            }
            // 0x017BC6EC: CBNZ x20, #0x17bc6f4       | if ( != 0) goto label_6;                
            if(null != 0)
            {
                goto label_6;
            }
            // 0x017BC6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_6:
            // 0x017BC6F4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC6F8: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC6FC: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC700: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC704: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC708: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC70C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC710: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC714: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC718: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC71C: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC720: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC724: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC728: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC72C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC730: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC734: MOV w22, w0                | W22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC738: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC73C: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC740: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC744: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC748: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC74C: CMP w24, w23, sxth         | STATE = COMPARE(typeof(System.IO.BinaryReader), typeof(System.IO.BinaryReader))
            // 0x017BC750: B.NE #0x17bceb4            | if (null != null) goto label_7;         
            if(null != null)
            {
                goto label_7;
            }
            // 0x017BC754: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC758: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC75C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC760: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC764: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC768: CBNZ x23, #0x17bc770       | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x017BC76C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_8:
            // 0x017BC770: LDR x8, [x23]              | X8 = ;                                  
            // 0x017BC774: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BC778: MOV x0, x23                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC77C: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BC780: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC784: CBNZ x20, #0x17bc78c       | if ( != 0) goto label_9;                
            if(null != 0)
            {
                goto label_9;
            }
            // 0x017BC788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_9:
            // 0x017BC78C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC790: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC794: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC798: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC79C: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC7A0: CBNZ x25, #0x17bc7a8       | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x017BC7A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_10:
            // 0x017BC7A8: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BC7AC: SXTW x1, w24               | X1 = 13844480 (0x00D34000);             
            // 0x017BC7B0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC7B4: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC7B8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC7BC: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC7C0: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC7C4: CBNZ x20, #0x17bc7cc       | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x017BC7C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_11:
            // 0x017BC7CC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC7D0: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC7D4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC7D8: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC7DC: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC7E0: CBNZ x24, #0x17bc7e8       | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x017BC7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_12:
            // 0x017BC7E8: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BC7EC: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x017BC7F0: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC7F4: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x017BC7F8: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC7FC: CBNZ x20, #0x17bc804       | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x017BC800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_13:
            // 0x017BC804: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC808: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC80C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC810: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC814: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC818: CBNZ x25, #0x17bc820       | if ( != 0) goto label_14;               
            if(null != 0)
            {
                goto label_14;
            }
            // 0x017BC81C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_14:
            // 0x017BC820: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BC824: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BC828: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC82C: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BC830: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC834: CBNZ x20, #0x17bc83c       | if ( != 0) goto label_15;               
            if(null != 0)
            {
                goto label_15;
            }
            // 0x017BC838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_15:
            // 0x017BC83C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC840: SUB w1, w24, w25           | W1 = (null - null) = 0 (0x00000000);    
            // 0x017BC844: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BC848: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC84C: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BC850: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC854: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC858: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC85C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC860: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC864: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC868: CBNZ x25, #0x17bc870       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x017BC86C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_16:
            // 0x017BC870: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BC874: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC878: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC87C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC880: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC884: MOV x1, x23                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC888: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC88C: MOV x1, x24                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC890: BL #0x17bbe30              | X0 = processStringPool(data:  null);    
            System.String[] val_4 = processStringPool(data:  null);
            // 0x017BC894: STR x0, [x21, #0x18]       | this.typeStringPool = val_4;             //  dest_result_addr=1152921513635001080
            this.typeStringPool = val_4;
            // 0x017BC898: CBNZ x20, #0x17bc8a0       | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x017BC89C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_17:
            // 0x017BC8A0: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC8A4: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC8A8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC8AC: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC8B0: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC8B4: CBNZ x23, #0x17bc8bc       | if ( != 0) goto label_18;               
            if(null != 0)
            {
                goto label_18;
            }
            // 0x017BC8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_18:
            // 0x017BC8BC: LDR x8, [x23]              | X8 = ;                                  
            // 0x017BC8C0: SXTW x25, w22              | X25 = 13844480 (0x00D34000);            
            // 0x017BC8C4: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC8C8: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC8CC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC8D0: MOV x0, x23                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC8D4: MOV x1, x25                | X1 = 13844480 (0xD34000);//ML01         
            // 0x017BC8D8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC8DC: CBNZ x20, #0x17bc8e4       | if ( != 0) goto label_19;               
            if(null != 0)
            {
                goto label_19;
            }
            // 0x017BC8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_19:
            // 0x017BC8E4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC8E8: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BC8EC: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BC8F0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC8F4: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BC8F8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC8FC: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BC900: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BC904: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC908: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BC90C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC910: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC914: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC918: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC91C: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC920: MOV w23, w0                | W23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC924: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC928: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC92C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC930: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC934: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC938: CBNZ x24, #0x17bc940       | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x017BC93C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_20:
            // 0x017BC940: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BC944: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BC948: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC94C: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BC950: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC954: CBNZ x20, #0x17bc95c       | if ( != 0) goto label_21;               
            if(null != 0)
            {
                goto label_21;
            }
            // 0x017BC958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_21:
            // 0x017BC95C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC960: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC964: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC968: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC96C: MOV x26, x0                | X26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC970: CBNZ x26, #0x17bc978       | if ( != 0) goto label_22;               
            if(null != 0)
            {
                goto label_22;
            }
            // 0x017BC974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_22:
            // 0x017BC978: LDR x8, [x26]              | X8 = ;                                  
            // 0x017BC97C: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC980: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC984: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC988: MOV x0, x26                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC98C: MOV x1, x25                | X1 = 13844480 (0xD34000);//ML01         
            // 0x017BC990: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC994: CBNZ x20, #0x17bc99c       | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x017BC998: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_23:
            // 0x017BC99C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC9A0: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC9A4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9A8: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC9AC: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9B0: CBNZ x25, #0x17bc9b8       | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x017BC9B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_24:
            // 0x017BC9B8: LDR x8, [x25]              | X8 = ;                                  
            // 0x017BC9BC: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x017BC9C0: MOV x0, x25                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9C4: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x017BC9C8: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9CC: CBNZ x20, #0x17bc9d4       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x017BC9D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_25:
            // 0x017BC9D4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC9D8: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC9DC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9E0: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC9E4: MOV x26, x0                | X26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9E8: CBNZ x26, #0x17bc9f0       | if ( != 0) goto label_26;               
            if(null != 0)
            {
                goto label_26;
            }
            // 0x017BC9EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_26:
            // 0x017BC9F0: LDR x8, [x26]              | X8 = ;                                  
            // 0x017BC9F4: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BC9F8: MOV x0, x26                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC9FC: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BCA00: MOV x26, x0                | X26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA04: CBNZ x20, #0x17bca0c       | if ( != 0) goto label_27;               
            if(null != 0)
            {
                goto label_27;
            }
            // 0x017BCA08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_27:
            // 0x017BCA0C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCA10: SUB w1, w25, w26           | W1 = (null - null) = 0 (0x00000000);    
            // 0x017BCA14: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BCA18: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA1C: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BCA20: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA24: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCA28: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCA2C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA30: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCA34: MOV x26, x0                | X26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA38: CBNZ x26, #0x17bca40       | if ( != 0) goto label_28;               
            if(null != 0)
            {
                goto label_28;
            }
            // 0x017BCA3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_28:
            // 0x017BCA40: LDR x8, [x26]              | X8 = ;                                  
            // 0x017BCA44: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCA48: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BCA4C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCA50: MOV x0, x26                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA54: MOV x1, x24                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA58: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCA5C: MOV x1, x25                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA60: BL #0x17bbe30              | X0 = processStringPool(data:  null);    
            System.String[] val_5 = processStringPool(data:  null);
            // 0x017BCA64: STR x0, [x21, #0x20]       | this.keyStringPool = val_5;              //  dest_result_addr=1152921513635001088
            this.keyStringPool = val_5;
            // 0x017BCA68: CBNZ x20, #0x17bca70       | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x017BCA6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_29:
            // 0x017BCA70: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCA74: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCA78: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA7C: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCA80: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCA84: CBNZ x24, #0x17bca8c       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x017BCA88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_30:
            // 0x017BCA8C: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BCA90: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCA94: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BCA98: ADD w8, w23, w22           | W8 = (null + null) = 2305843009241382912 (0x2000000001A68000);
            // 0x017BCA9C: SXTW x1, w8                | X1 = 27688960 (0x01A68000);             
            // 0x017BCAA0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCAA4: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCAA8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCAAC: ADRP x25, #0x3656000       | X25 = 56975360 (0x3656000);             
            // 0x017BCAB0: ADRP x26, #0x35db000       | X26 = 56471552 (0x35DB000);             
            // 0x017BCAB4: LDR x25, [x25, #0x670]     | X25 = 1152921504856686592;              
            val_18 = 1152921504856686592;
            // 0x017BCAB8: LDR x26, [x26, #0xf00]     | X26 = 1152921504996170800;              
            label_50:
            // 0x017BCABC: CBNZ x20, #0x17bcac4       | if ( != 0) goto label_31;               
            if(null != 0)
            {
                goto label_31;
            }
            // 0x017BCAC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_31:
            // 0x017BCAC4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCAC8: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCACC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCAD0: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCAD4: MOV x22, x0                | X22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCAD8: CBNZ x22, #0x17bcae0       | if ( != 0) goto label_32;               
            if(null != 0)
            {
                goto label_32;
            }
            // 0x017BCADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_32:
            // 0x017BCAE0: LDR x8, [x22]              | X8 = ;                                  
            // 0x017BCAE4: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BCAE8: MOV x0, x22                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCAEC: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BCAF0: MOV x22, x0                | X22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCAF4: CBNZ x20, #0x17bcafc       | if ( != 0) goto label_33;               
            if(null != 0)
            {
                goto label_33;
            }
            // 0x017BCAF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_33:
            // 0x017BCAFC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCB00: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BCB04: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BCB08: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB0C: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BCB10: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB14: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCB18: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BCB1C: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BCB20: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB24: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BCB28: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCB2C: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            val_19 = mem[null + 584];
            // 0x017BCB30: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCB34: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB38: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCB3C: MOV w23, w0                | W23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB40: LDR x0, [x25]              | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_20 = null;
            // 0x017BCB44: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BCB48: TBZ w8, #0, #0x17bcb5c     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_35;
            // 0x017BCB4C: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BCB50: CBNZ w8, #0x17bcb5c        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
            // 0x017BCB54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BCB58: LDR x0, [x25]              | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_20 = null;
            label_35:
            // 0x017BCB5C: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BCB60: AND w10, w24, #0xffff      | W10 = (null & 65535) = 16384 (0x00004000);
            // 0x017BCB64: LDRH w9, [x8, #8]          | W9 = Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_SPEC_TYPE;
            // 0x017BCB68: CMP w10, w9                | STATE = COMPARE(0x4000, Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_SPEC_TYPE)
            // 0x017BCB6C: B.NE #0x17bcbe8            | if (16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_SPEC_TYPE) goto label_36;
            if(16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_SPEC_TYPE)
            {
                goto label_36;
            }
            // 0x017BCB70: LDR x24, [x26]             | X24 = typeof(System.Byte[]);            
            // 0x017BCB74: MOV x0, x24                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BCB78: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x017BCB7C: MOV w1, w23                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB80: MOV x0, x24                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BCB84: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x017BCB88: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCB8C: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCB90: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB94: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCB98: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCB9C: CBNZ x24, #0x17bcba4       | if ( != 0) goto label_37;               
            if(null != 0)
            {
                goto label_37;
            }
            // 0x017BCBA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_37:
            // 0x017BCBA4: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BCBA8: SXTW x1, w22               | X1 = 13844480 (0x00D34000);             
            // 0x017BCBAC: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCBB0: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BCBB4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCBB8: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCBBC: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCBC0: CBNZ x20, #0x17bcbc8       | if ( != 0) goto label_38;               
            if(null != 0)
            {
                goto label_38;
            }
            // 0x017BCBC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_38:
            // 0x017BCBC8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCBCC: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BCBD0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCBD4: MOV w1, w23                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCBD8: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BCBDC: MOV x1, x0                 | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_19 = null;
            // 0x017BCBE0: BL #0x17bcefc              | processTypeSpec(data:  val_19 = null);  
            processTypeSpec(data:  val_19);
            // 0x017BCBE4: B #0x17bcc8c               |  goto label_42;                         
            goto label_42;
            label_36:
            // 0x017BCBE8: LDRB w9, [x0, #0x10a]      | W9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BCBEC: TBZ w9, #0, #0x17bcc04     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_41;
            // 0x017BCBF0: LDR w9, [x0, #0xbc]        | W9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BCBF4: CBNZ w9, #0x17bcc04        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x017BCBF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BCBFC: LDR x8, [x25]              | X8 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BCC00: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            label_41:
            // 0x017BCC04: LDRH w8, [x8, #6]          | W8 = Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_TYPE;
            // 0x017BCC08: AND w9, w24, #0xffff       | W9 = (null & 65535) = 16384 (0x00004000);
            // 0x017BCC0C: CMP w9, w8                 | STATE = COMPARE(0x4000, Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_TYPE)
            // 0x017BCC10: B.NE #0x17bcc8c            | if (16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_TYPE) goto label_42;
            if(16384 != Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_TYPE)
            {
                goto label_42;
            }
            // 0x017BCC14: LDR x24, [x26]             | X24 = typeof(System.Byte[]);            
            // 0x017BCC18: MOV x0, x24                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BCC1C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x017BCC20: MOV w1, w23                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC24: MOV x0, x24                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017BCC28: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x017BCC2C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCC30: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCC34: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC38: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCC3C: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC40: CBNZ x24, #0x17bcc48       | if ( != 0) goto label_43;               
            if(null != 0)
            {
                goto label_43;
            }
            // 0x017BCC44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_43:
            // 0x017BCC48: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BCC4C: SXTW x1, w22               | X1 = 13844480 (0x00D34000);             
            // 0x017BCC50: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCC54: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BCC58: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCC5C: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC60: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCC64: CBNZ x20, #0x17bcc6c       | if ( != 0) goto label_44;               
            if(null != 0)
            {
                goto label_44;
            }
            // 0x017BCC68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_44:
            // 0x017BCC6C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCC70: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BCC74: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC78: MOV w1, w23                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC7C: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BCC80: MOV x1, x0                 | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_19 = null;
            // 0x017BCC84: MOV x0, x21                | X0 = 1152921513635001056 (0x100000021A1EB2E0);//ML01
            // 0x017BCC88: BL #0x17bd218              | this.processType(typeData:  val_19 = null);
            this.processType(typeData:  val_19);
            label_42:
            // 0x017BCC8C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCC90: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCC94: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCC98: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCC9C: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCCA0: CBNZ x24, #0x17bcca8       | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x017BCCA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_45:
            // 0x017BCCA8: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BCCAC: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCCB0: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BCCB4: ADD w8, w23, w22           | W8 = (null + null) = 2305843009241382912 (0x2000000001A68000);
            // 0x017BCCB8: SXTW x1, w8                | X1 = 27688960 (0x01A68000);             
            // 0x017BCCBC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCCC0: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCCC4: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCCC8: CBNZ x20, #0x17bccd0       | if ( != 0) goto label_46;               
            if(null != 0)
            {
                goto label_46;
            }
            // 0x017BCCCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_46:
            // 0x017BCCD0: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCCD4: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCCD8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCCDC: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCCE0: MOV x22, x0                | X22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCCE4: CBNZ x22, #0x17bccec       | if ( != 0) goto label_47;               
            if(null != 0)
            {
                goto label_47;
            }
            // 0x017BCCE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_47:
            // 0x017BCCEC: LDR x8, [x22]              | X8 = ;                                  
            // 0x017BCCF0: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BCCF4: MOV x0, x22                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCCF8: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BCCFC: MOV x22, x0                | X22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCD00: CBNZ x20, #0x17bcd08       | if ( != 0) goto label_48;               
            if(null != 0)
            {
                goto label_48;
            }
            // 0x017BCD04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_48:
            // 0x017BCD08: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCD0C: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BCD10: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCD14: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BCD18: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_22 = null;
            // 0x017BCD1C: CBNZ x23, #0x17bcd24       | if ( != 0) goto label_49;               
            if(null != 0)
            {
                goto label_49;
            }
            // 0x017BCD20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_49:
            // 0x017BCD24: LDR x8, [x23]              | X8 = ;                                  
            // 0x017BCD28: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x017BCD2C: MOV x0, x23                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCD30: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x017BCD34: CMP x22, x0                | STATE = COMPARE(typeof(System.IO.BinaryReader), typeof(System.IO.BinaryReader))
            // 0x017BCD38: B.NE #0x17bcabc            | if (null != val_22) goto label_50;      
            if(null != val_22)
            {
                goto label_50;
            }
            // 0x017BCD3C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x017BCD40: MOVZ w22, #0x28a           | W22 = 650 (0x28A);//ML01                
            val_24 = 650;
            // 0x017BCD44: B #0x17bcd64               |  goto label_51;                         
            goto label_51;
            // 0x017BCD48: B #0x17bcd4c               |  goto label_70;                         
            goto label_70;
            label_70:
            // 0x017BCD4C: CMP w1, #1                 | STATE = COMPARE(mem[null + 400 + 8], 0x1)
            // 0x017BCD50: B.NE #0x17bcdb8            | if (mem[null + 400 + 8] != 0x1) goto label_53;
            if((mem[null + 400 + 8]) != 1)
            {
                goto label_53;
            }
            // 0x017BCD54: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BCD58: LDR x21, [x0]              | X21 = ;                                 
            val_23 = null;
            // 0x017BCD5C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x017BCD60: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.BinaryReader), ????);
            label_51:
            // 0x017BCD64: CBZ x20, #0x17bcde4        | if ( == 0) goto label_54;               
            if(null == 0)
            {
                goto label_54;
            }
            // 0x017BCD68: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BCD6C: LDR x8, [x20]              | X8 = ;                                  
            System.IO.BinaryReader val_21 = null;
            // 0x017BCD70: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BCD74: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BCD78: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BCD7C: CBZ x9, #0x17bcda8         | if (mem[null + 258] == 0) goto label_55;
            if((mem[null + 258]) == 0)
            {
                goto label_55;
            }
            // 0x017BCD80: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_19 = mem[null + 152];
            // 0x017BCD84: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_20 = 0;
            // 0x017BCD88: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_19 = val_19 + 8;
            label_57:
            // 0x017BCD8C: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BCD90: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BCD94: B.EQ #0x17bcdcc            | if ((mem[null + 152] + 8) + -8 == null) goto label_56;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_56;
            }
            // 0x017BCD98: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_20 = val_20 + 1;
            // 0x017BCD9C: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_19 = val_19 + 16;
            // 0x017BCDA0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BCDA4: B.LO #0x17bcd8c            | if (0 < mem[null + 258]) goto label_57; 
            if(val_20 < (mem[null + 258]))
            {
                goto label_57;
            }
            label_55:
            // 0x017BCDA8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCDAC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_25 = null;
            // 0x017BCDB0: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BCDB4: B #0x17bcdd8               |  goto label_58;                         
            goto label_58;
            label_53:
            // 0x017BCDB8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_24 = 0;
            label_69:
            // 0x017BCDBC: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BCDC0: LDR x21, [x0]              | X21 = ;                                 
            val_23 = null;
            // 0x017BCDC4: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BCDC8: B #0x17bce00               |  goto label_61;                         
            goto label_61;
            label_56:
            // 0x017BCDCC: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BCDD0: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_21 = val_21 + (((mem[null + 152] + 8)) << 4);
            // 0x017BCDD4: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_58:
            // 0x017BCDD8: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.BinaryReader.__il2cppRuntimeField_gc_desc; //  | 
            // 0x017BCDDC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCDE0: BLR x8                     | X0 = x8();                              
            label_54:
            // 0x017BCDE4: CMP w22, #0x28a            | STATE = COMPARE(0x0, 0x28A)             
            // 0x017BCDE8: B.EQ #0x17bce00            | if (val_24 == 0x28A) goto label_61;     
            if(val_24 == 650)
            {
                goto label_61;
            }
            // 0x017BCDEC: CBZ x21, #0x17bce00        | if ( == 0) goto label_61;               
            if(val_23 == 0)
            {
                goto label_61;
            }
            // 0x017BCDF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BCDF4: MOV x0, x21                | X0 = X21;//m1                           
            // 0x017BCDF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            // 0x017BCDFC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_61:
            // 0x017BCE00: CBZ x19, #0x17bce6c        | if ( == 0) goto label_62;               
            if(null == 0)
            {
                goto label_62;
            }
            // 0x017BCE04: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BCE08: LDR x8, [x19]              | X8 = ;                                  
            System.IO.MemoryStream val_24 = null;
            // 0x017BCE0C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BCE10: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BCE14: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BCE18: CBZ x9, #0x17bce44         | if (mem[null + 258] == 0) goto label_63;
            if((mem[null + 258]) == 0)
            {
                goto label_63;
            }
            // 0x017BCE1C: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_22 = mem[null + 152];
            // 0x017BCE20: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_23 = 0;
            // 0x017BCE24: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_22 = val_22 + 8;
            label_65:
            // 0x017BCE28: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BCE2C: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BCE30: B.EQ #0x17bce54            | if ((mem[null + 152] + 8) + -8 == null) goto label_64;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_64;
            }
            // 0x017BCE34: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_23 = val_23 + 1;
            // 0x017BCE38: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_22 = val_22 + 16;
            // 0x017BCE3C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BCE40: B.LO #0x17bce28            | if (0 < mem[null + 258]) goto label_65; 
            if(val_23 < (mem[null + 258]))
            {
                goto label_65;
            }
            label_63:
            // 0x017BCE44: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BCE48: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_26 = val_17;
            // 0x017BCE4C: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BCE50: B #0x17bce60               |  goto label_66;                         
            goto label_66;
            label_64:
            // 0x017BCE54: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BCE58: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_24 = val_24 + (((mem[null + 152] + 8)) << 4);
            // 0x017BCE5C: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_66:
            // 0x017BCE60: LDP x8, x1, [x0]           |                                          //  not_find_field!1:0 |  not_find_field!1:8
            // 0x017BCE64: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BCE68: BLR x8                     | X0 = mem[val_23]();                     
            label_62:
            // 0x017BCE6C: CMP w22, #0x28a            | STATE = COMPARE(0x0, 0x28A)             
            // 0x017BCE70: B.EQ #0x17bce98            | if (val_24 == 0x28A) goto label_68;     
            if(val_24 == 650)
            {
                goto label_68;
            }
            // 0x017BCE74: CBZ x21, #0x17bce98        | if (0x0 == 0) goto label_68;            
            if(val_23 == 0)
            {
                goto label_68;
            }
            // 0x017BCE78: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x017BCE7C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x017BCE80: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            val_17 = ???;
            // 0x017BCE84: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            val_23 = ???;
            // 0x017BCE88: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            val_22 = ???;
            // 0x017BCE8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BCE90: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            val_18 = ???;
            // 0x017BCE94: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_68:
            // 0x017BCE98: LDP x29, x30, [sp, #0x40]  | X29 = val_6; X30 = val_7;                //  find_add[1152921513634977056] |  find_add[1152921513634977056]
            // 0x017BCE9C: LDP x20, x19, [sp, #0x30]  | X20 = val_8; X19 = val_9;                //  find_add[1152921513634977056] |  find_add[1152921513634977056]
            // 0x017BCEA0: LDP x22, x21, [sp, #0x20]  | X22 = val_10; X21 = val_11;              //  find_add[1152921513634977056] |  find_add[1152921513634977056]
            // 0x017BCEA4: LDP x24, x23, [sp, #0x10]  | X24 = val_12; X23 = val_13;              //  find_add[1152921513634977056] |  find_add[1152921513634977056]
            // 0x017BCEA8: LDP x26, x25, [sp], #0x50  | X26 = val_14; X25 = val_15;              //  find_add[1152921513634977056] |  find_add[1152921513634977056]
            // 0x017BCEAC: RET                        |  return;                                
            return;
            // 0x017BCEB0: B #0x17bcdbc               |  goto label_69;                         
            goto label_69;
            label_7:
            // 0x017BCEB4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BCEB8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BCEBC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BCEC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BCEC4: MOV x21, x0                | X21 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BCEC8: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x017BCECC: LDR x8, [x8, #0x8f8]       | X8 = (string**)(1152921513634971728)("TypeStrings must immediately follow the package structure header.");
            // 0x017BCED0: LDR x1, [x8]               | X1 = "TypeStrings must immediately follow the package structure header.";
            // 0x017BCED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BCED8: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_16 = null;
            // 0x017BCEDC: BL #0x1c32b48              | .ctor(message:  "TypeStrings must immediately follow the package structure header.");
            val_16 = new System.Exception(message:  "TypeStrings must immediately follow the package structure header.");
            // 0x017BCEE0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x017BCEE4: LDR x8, [x8, #0x308]       | X8 = 1152921513634971936;               
            // 0x017BCEE8: LDR x1, [x8]               | X1 = System.Void Iteedee.ApkReader.ApkResourceFinder::processPackage(byte[] data);
            // 0x017BCEEC: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BCEF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BCEF4: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_17 = System.Collections.IEnumerable.GetEnumerator();
            // 0x017BCEF8: B #0x17bcd4c               |  goto label_70;                         
            goto label_70;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BDF74 (24895348), len: 456  VirtAddr: 0x017BDF74 RVA: 0x017BDF74 token: 100684431 methodIndex: 46001 delegateWrapperIndex: 0 methodInvoker: 0
        private void putIntoMap(string resId, string value)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.List<System.String> val_9;
            // 0x017BDF74: STP x24, x23, [sp, #-0x40]! | stack[1152921513635262784] = ???;  stack[1152921513635262792] = ???;  //  dest_result_addr=1152921513635262784 |  dest_result_addr=1152921513635262792
            // 0x017BDF78: STP x22, x21, [sp, #0x10]  | stack[1152921513635262800] = ???;  stack[1152921513635262808] = ???;  //  dest_result_addr=1152921513635262800 |  dest_result_addr=1152921513635262808
            // 0x017BDF7C: STP x20, x19, [sp, #0x20]  | stack[1152921513635262816] = ???;  stack[1152921513635262824] = ???;  //  dest_result_addr=1152921513635262816 |  dest_result_addr=1152921513635262824
            // 0x017BDF80: STP x29, x30, [sp, #0x30]  | stack[1152921513635262832] = ???;  stack[1152921513635262840] = ???;  //  dest_result_addr=1152921513635262832 |  dest_result_addr=1152921513635262840
            // 0x017BDF84: ADD x29, sp, #0x30         | X29 = (1152921513635262784 + 48) = 1152921513635262832 (0x100000021A22B170);
            // 0x017BDF88: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x017BDF8C: LDRB w8, [x22, #0x961]     | W8 = (bool)static_value_03738961;       
            // 0x017BDF90: MOV x21, x2                | X21 = value;//m1                        
            // 0x017BDF94: MOV x19, x1                | X19 = resId;//m1                        
            // 0x017BDF98: MOV x20, x0                | X20 = 1152921513635274848 (0x100000021A22E060);//ML01
            // 0x017BDF9C: TBNZ w8, #0, #0x17bdfb8    | if (static_value_03738961 == true) goto label_0;
            // 0x017BDFA0: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x017BDFA4: LDR x8, [x8, #0x730]       | X8 = 0x2B8B058;                         
            // 0x017BDFA8: LDR w0, [x8]               | W0 = 0x2D4;                             
            // 0x017BDFAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2D4, ????);      
            // 0x017BDFB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BDFB4: STRB w8, [x22, #0x961]     | static_value_03738961 = true;            //  dest_result_addr=57903457
            label_0:
            // 0x017BDFB8: LDR x22, [x20, #0x38]      | X22 = this.responseMap; //P2            
            // 0x017BDFBC: CBNZ x19, #0x17bdfc4       | if (resId != null) goto label_1;        
            if(resId != null)
            {
                goto label_1;
            }
            // 0x017BDFC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2D4, ????);      
            label_1:
            // 0x017BDFC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDFC8: MOV x0, x19                | X0 = resId;//m1                         
            // 0x017BDFCC: BL #0x18af030              | X0 = resId.ToUpper();                   
            string val_1 = resId.ToUpper();
            // 0x017BDFD0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x017BDFD4: CBNZ x22, #0x17bdfdc       | if (this.responseMap != null) goto label_2;
            if(this.responseMap != null)
            {
                goto label_2;
            }
            // 0x017BDFD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x017BDFDC: ADRP x24, #0x3605000       | X24 = 56643584 (0x3605000);             
            // 0x017BDFE0: LDR x24, [x24, #0xf50]     | X24 = 1152921513633382752;              
            // 0x017BDFE4: MOV x0, x22                | X0 = this.responseMap;//m1              
            // 0x017BDFE8: MOV x1, x23                | X1 = val_1;//m1                         
            // 0x017BDFEC: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::ContainsKey(System.String key);
            // 0x017BDFF0: BL #0x23fd9f0              | X0 = this.responseMap.ContainsKey(key:  val_1);
            bool val_2 = this.responseMap.ContainsKey(key:  val_1);
            // 0x017BDFF4: TBZ w0, #0, #0x17be03c     | if (val_2 == false) goto label_3;       
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x017BDFF8: LDR x22, [x20, #0x38]      | X22 = this.responseMap; //P2            
            // 0x017BDFFC: CBNZ x19, #0x17be004       | if (resId != null) goto label_4;        
            if(resId != null)
            {
                goto label_4;
            }
            // 0x017BE000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x017BE004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BE008: MOV x0, x19                | X0 = resId;//m1                         
            // 0x017BE00C: BL #0x18af030              | X0 = resId.ToUpper();                   
            string val_3 = resId.ToUpper();
            // 0x017BE010: MOV x23, x0                | X23 = val_3;//m1                        
            // 0x017BE014: CBNZ x22, #0x17be01c       | if (this.responseMap != null) goto label_5;
            if(this.responseMap != null)
            {
                goto label_5;
            }
            // 0x017BE018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x017BE01C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x017BE020: LDR x8, [x8, #0x800]       | X8 = 1152921513633387872;               
            // 0x017BE024: MOV x0, x22                | X0 = this.responseMap;//m1              
            // 0x017BE028: MOV x1, x23                | X1 = val_3;//m1                         
            // 0x017BE02C: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<System.String> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::get_Item(System.String key);
            // 0x017BE030: BL #0x23fc26c              | X0 = this.responseMap.get_Item(key:  val_3);
            System.Collections.Generic.List<System.String> val_4 = this.responseMap.Item[val_3];
            // 0x017BE034: MOV x22, x0                | X22 = val_4;//m1                        
            val_9 = val_4;
            // 0x017BE038: CBNZ x22, #0x17be06c       | if (val_4 != null) goto label_7;        
            if(val_9 != null)
            {
                goto label_7;
            }
            label_3:
            // 0x017BE03C: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017BE040: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x017BE044: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_5 = null;
            // 0x017BE048: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BE04C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x017BE050: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x017BE054: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            val_9 = val_5;
            // 0x017BE058: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017BE05C: BL #0x25e9474              | .ctor();                                
            val_5 = new System.Collections.Generic.List<System.String>();
            // 0x017BE060: CBNZ x22, #0x17be06c       | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x017BE064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x017BE068: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_7:
            // 0x017BE06C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x017BE070: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x017BE074: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x017BE078: MOV x1, x21                | X1 = value;//m1                         
            // 0x017BE07C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x017BE080: BL #0x25ea480              | val_9.Add(item:  value);                
            val_9.Add(item:  value);
            // 0x017BE084: LDR x21, [x20, #0x38]      | X21 = this.responseMap; //P2            
            // 0x017BE088: CBNZ x19, #0x17be090       | if (resId != null) goto label_8;        
            if(resId != null)
            {
                goto label_8;
            }
            // 0x017BE08C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_8:
            // 0x017BE090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BE094: MOV x0, x19                | X0 = resId;//m1                         
            // 0x017BE098: BL #0x18af030              | X0 = resId.ToUpper();                   
            string val_6 = resId.ToUpper();
            // 0x017BE09C: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x017BE0A0: CBNZ x21, #0x17be0a8       | if (this.responseMap != null) goto label_9;
            if(this.responseMap != null)
            {
                goto label_9;
            }
            // 0x017BE0A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_9:
            // 0x017BE0A8: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::ContainsKey(System.String key);
            // 0x017BE0AC: MOV x0, x21                | X0 = this.responseMap;//m1              
            // 0x017BE0B0: MOV x1, x23                | X1 = val_6;//m1                         
            // 0x017BE0B4: BL #0x23fd9f0              | X0 = this.responseMap.ContainsKey(key:  val_6);
            bool val_7 = this.responseMap.ContainsKey(key:  val_6);
            // 0x017BE0B8: LDR x20, [x20, #0x38]      | X20 = this.responseMap; //P2            
            // 0x017BE0BC: MOV w21, w0                | W21 = val_7;//m1                        
            // 0x017BE0C0: CBNZ x19, #0x17be0c8       | if (resId != null) goto label_10;       
            if(resId != null)
            {
                goto label_10;
            }
            // 0x017BE0C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_10:
            // 0x017BE0C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BE0CC: MOV x0, x19                | X0 = resId;//m1                         
            // 0x017BE0D0: BL #0x18af030              | X0 = resId.ToUpper();                   
            string val_8 = resId.ToUpper();
            // 0x017BE0D4: MOV x19, x0                | X19 = val_8;//m1                        
            // 0x017BE0D8: CBNZ x20, #0x17be0e0       | if (this.responseMap != null) goto label_11;
            if(this.responseMap != null)
            {
                goto label_11;
            }
            // 0x017BE0DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_11:
            // 0x017BE0E0: TBZ w21, #0, #0x17be110    | if (val_7 == false) goto label_12;      
            if(val_7 == false)
            {
                goto label_12;
            }
            // 0x017BE0E4: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BE0E8: LDR x8, [x8, #0xa78]       | X8 = 1152921513635248800;               
            // 0x017BE0EC: MOV x0, x20                | X0 = this.responseMap;//m1              
            // 0x017BE0F0: MOV x1, x19                | X1 = val_8;//m1                         
            // 0x017BE0F4: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x017BE0F8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::set_Item(System.String key, System.Collections.Generic.List<System.String> value);
            // 0x017BE0FC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x017BE100: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x017BE104: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x017BE108: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x017BE10C: B #0x23fc55c               | this.responseMap.set_Item(key:  val_8, value:  val_9); return;
            this.responseMap.set_Item(key:  val_8, value:  val_9);
            return;
            label_12:
            // 0x017BE110: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x017BE114: LDR x8, [x8, #0xf90]       | X8 = 1152921513635249824;               
            // 0x017BE118: MOV x0, x20                | X0 = this.responseMap;//m1              
            // 0x017BE11C: MOV x1, x19                | X1 = val_8;//m1                         
            // 0x017BE120: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x017BE124: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::Add(System.String key, System.Collections.Generic.List<System.String> value);
            // 0x017BE128: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x017BE12C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x017BE130: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x017BE134: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x017BE138: B #0x23fd44c               | this.responseMap.Add(key:  val_8, value:  val_9); return;
            this.responseMap.Add(key:  val_8, value:  val_9);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BD218 (24891928), len: 3420  VirtAddr: 0x017BD218 RVA: 0x017BD218 token: 100684432 methodIndex: 46002 delegateWrapperIndex: 0 methodInvoker: 0
        private void processType(byte[] typeData)
        {
            //
            // Disasemble & Code
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            string val_41;
            //  | 
            var val_42;
            //  | 
            System.Collections.Generic.List<System.String> val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            Iteedee.ApkReader.ApkResourceFinder val_46;
            //  | 
            Iteedee.ApkReader.ApkResourceFinder val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            // 0x017BD218: STP x28, x27, [sp, #-0x60]! | stack[1152921513635533648] = ???;  stack[1152921513635533656] = ???;  //  dest_result_addr=1152921513635533648 |  dest_result_addr=1152921513635533656
            // 0x017BD21C: STP x26, x25, [sp, #0x10]  | stack[1152921513635533664] = ???;  stack[1152921513635533672] = ???;  //  dest_result_addr=1152921513635533664 |  dest_result_addr=1152921513635533672
            // 0x017BD220: STP x24, x23, [sp, #0x20]  | stack[1152921513635533680] = ???;  stack[1152921513635533688] = ???;  //  dest_result_addr=1152921513635533680 |  dest_result_addr=1152921513635533688
            // 0x017BD224: STP x22, x21, [sp, #0x30]  | stack[1152921513635533696] = ???;  stack[1152921513635533704] = ???;  //  dest_result_addr=1152921513635533696 |  dest_result_addr=1152921513635533704
            // 0x017BD228: STP x20, x19, [sp, #0x40]  | stack[1152921513635533712] = ???;  stack[1152921513635533720] = ???;  //  dest_result_addr=1152921513635533712 |  dest_result_addr=1152921513635533720
            // 0x017BD22C: STP x29, x30, [sp, #0x50]  | stack[1152921513635533728] = ???;  stack[1152921513635533736] = ???;  //  dest_result_addr=1152921513635533728 |  dest_result_addr=1152921513635533736
            // 0x017BD230: ADD x29, sp, #0x50         | X29 = (1152921513635533648 + 80) = 1152921513635533728 (0x100000021A26D3A0);
            // 0x017BD234: SUB sp, sp, #0x90          | SP = (1152921513635533648 - 144) = 1152921513635533504 (0x100000021A26D2C0);
            // 0x017BD238: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BD23C: LDRB w8, [x19, #0x962]     | W8 = (bool)static_value_03738962;       
            // 0x017BD240: MOV x20, x1                | X20 = typeData;//m1                     
            // 0x017BD244: STR x0, [sp, #0x18]        | stack[1152921513635533528] = this;       //  dest_result_addr=1152921513635533528
            // 0x017BD248: TBNZ w8, #0, #0x17bd264    | if (static_value_03738962 == true) goto label_0;
            // 0x017BD24C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x017BD250: LDR x8, [x8, #0x3a8]       | X8 = 0x2B8B050;                         
            // 0x017BD254: LDR w0, [x8]               | W0 = 0x2D2;                             
            // 0x017BD258: BL #0x2782188              | X0 = sub_2782188( ?? 0x2D2, ????);      
            // 0x017BD25C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BD260: STRB w8, [x19, #0x962]     | static_value_03738962 = true;            //  dest_result_addr=57903458
            label_0:
            // 0x017BD264: STP wzr, wzr, [x29, #-0x58] | stack[1152921513635533640] = 0x0;  stack[1152921513635533644] = 0x0;  //  dest_result_addr=1152921513635533640 |  dest_result_addr=1152921513635533644
            // 0x017BD268: STP xzr, xzr, [sp, #0x78]  | stack[1152921513635533624] = 0x0;  stack[1152921513635533632] = 0x0;  //  dest_result_addr=1152921513635533624 |  dest_result_addr=1152921513635533632
            // 0x017BD26C: STR xzr, [sp, #0x70]       | stack[1152921513635533616] = 0x0;        //  dest_result_addr=1152921513635533616
            // 0x017BD270: STP wzr, wzr, [sp, #0x68]  | stack[1152921513635533608] = 0x0;  stack[1152921513635533612] = 0x0;  //  dest_result_addr=1152921513635533608 |  dest_result_addr=1152921513635533612
            // 0x017BD274: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x017BD278: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x017BD27C: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x017BD280: STP xzr, xzr, [sp, #0x58]  | stack[1152921513635533592] = 0x0;  stack[1152921513635533600] = 0x0;  //  dest_result_addr=1152921513635533592 |  dest_result_addr=1152921513635533600
            // 0x017BD284: STR xzr, [sp, #0x50]       | stack[1152921513635533584] = 0x0;        //  dest_result_addr=1152921513635533584
            // 0x017BD288: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BD28C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BD290: MOV x1, x20                | X1 = typeData;//m1                      
            // 0x017BD294: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BD298: BL #0x1e78658              | .ctor(buffer:  typeData);               
            val_1 = new System.IO.MemoryStream(buffer:  typeData);
            // 0x017BD29C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x017BD2A0: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x017BD2A4: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            // 0x017BD2A8: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD2AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD2B0: MOV x20, x0                | X20 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD2B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BD2B8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            System.IO.BinaryReader val_2 = null;
            // 0x017BD2BC: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BD2C0: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD2C4: BL #0x1e664fc              | .ctor(input:  val_1);                   
            val_2 = new System.IO.BinaryReader(input:  val_1);
            // 0x017BD2C8: CBNZ x20, #0x17bd2d4       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x017BD2CC: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD2D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_1), ????);
            label_1:
            // 0x017BD2D4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD2D8: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD2DC: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD2E0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD2E4: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD2E8: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD2EC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD2F0: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD2F4: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD2F8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD2FC: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD300: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD304: MOV w23, w0                | W23 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD308: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD30C: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD310: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD314: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD318: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD31C: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD320: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD324: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BD328: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD32C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD330: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BD334: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD338: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD33C: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BD340: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD344: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD348: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BD34C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD350: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD354: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD358: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD35C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD360: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD364: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD368: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD36C: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD370: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD374: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD378: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD37C: MOV w25, w0                | W25 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_41 = null;
            // 0x017BD380: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD384: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD388: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD38C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD390: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD394: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD398: MOV w26, w0                | W26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD39C: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x017BD3A0: LDR x8, [x8, #0x610]       | X8 = 1152921504615792640;               
            // 0x017BD3A4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            // 0x017BD3A8: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD3AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x017BD3B0: MOV x22, x0                | X22 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BD3B4: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x017BD3B8: LDR x8, [x8, #0x6d8]       | X8 = 1152921510000487872;               
            // 0x017BD3BC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::.ctor();
            // 0x017BD3C0: MOV x0, x22                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            System.Collections.Generic.Dictionary<System.String, System.Int32> val_3 = null;
            // 0x017BD3C4: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD3C8: BL #0x23f2edc              | .ctor();                                
            val_3 = new System.Collections.Generic.Dictionary<System.String, System.Int32>();
            // 0x017BD3CC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD3D0: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD3D4: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD3D8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD3DC: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD3E0: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD3E4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD3E8: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BD3EC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD3F0: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD3F4: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BD3F8: MOV x27, x0                | X27 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD3FC: CBNZ x27, #0x17bd408       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x017BD400: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_2:
            // 0x017BD408: LDR x8, [x27]              | X8 = ;                                  
            // 0x017BD40C: SXTH x1, w23               | X1 = 16384 (0x4000);                    
            // 0x017BD410: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD414: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD418: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BD41C: MOV x0, x27                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD420: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD424: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD428: LSL w8, w25, #2            | W8 = (val_41 << 2) = 0 (0x00000000);    
            // 0x017BD42C: ADD w8, w8, w23, sxth      | W8 = (0 + null) = 1152921504676069376 (0x1000000004204000);
            // 0x017BD430: CMP w8, w26                | STATE = COMPARE(typeof(FileWebRequest.FileWebStream), typeof(System.IO.BinaryReader))
            // 0x017BD434: B.NE #0x17bdf20            | if (1152921504676069376 != null) goto label_3;
            if(1152921504676069376 != null)
            {
                goto label_3;
            }
            // 0x017BD438: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x017BD43C: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x017BD440: LDR x23, [x8]              | X23 = typeof(System.Int32[]);           
            // 0x017BD444: MOV x0, x23                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BD448: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD44C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
            // 0x017BD450: MOV w1, w25                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD454: MOV x0, x23                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BD458: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD45C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
            // 0x017BD460: MOV x23, x0                | X23 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BD464: CMP w25, #1                | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BD468: B.LT #0x17bd9f0            | if (val_41 < 0x1) goto label_9;         
            if(val_41 < 1)
            {
                goto label_9;
            }
            // 0x017BD46C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            var val_41 = 0;
            // 0x017BD470: SXTW x27, w25              | X27 = 13844480 (0x00D34000);            
            // 0x017BD474: ADD x28, x23, #0x20        | X28 = (null + 32) = 1152921504962510864 (0x1000000015330010);
            label_8:
            // 0x017BD478: CBNZ x20, #0x17bd480       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x017BD47C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_5:
            // 0x017BD480: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD484: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            val_42 = mem[null + 584];
            // 0x017BD488: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD48C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD490: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD494: MOV w26, w0                | W26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD498: CBNZ x23, #0x17bd4a0       | if ( != null) goto label_6;             
            if(null != null)
            {
                goto label_6;
            }
            // 0x017BD49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_6:
            // 0x017BD4A0: LDR w8, [x23, #0x18]       | W8 = System.Int32[].__il2cppRuntimeField_namespaze;
            // 0x017BD4A4: CMP x21, x8                | STATE = COMPARE(0x0, System.Int32[].__il2cppRuntimeField_namespaze)
            // 0x017BD4A8: B.LO #0x17bd4b8            | if (0 < System.Int32[].__il2cppRuntimeField_namespaze) goto label_7;
            // 0x017BD4AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD4B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_42 = 0;
            // 0x017BD4B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryReader), ????);
            label_7:
            // 0x017BD4B8: STR w26, [x28, x21, lsl #2] | System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504962510864
            System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = null;
            // 0x017BD4BC: ADD x21, x21, #1           | X21 = (0 + 1);                          
            val_41 = val_41 + 1;
            // 0x017BD4C0: CMP x21, x27               | STATE = COMPARE((0 + 1), 0xD34000)      
            // 0x017BD4C4: B.LT #0x17bd478            | if (0 < 13844480) goto label_8;         
            if(val_41 < 13844480)
            {
                goto label_8;
            }
            // 0x017BD4C8: CMP w25, #1                | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BD4CC: B.LT #0x17bd9f0            | if (val_41 < 0x1) goto label_9;         
            if(val_41 < 1)
            {
                goto label_9;
            }
            // 0x017BD4D0: AND w8, w24, #0xff         | W8 = (null & 255) = 0 (0x00000000);     
            // 0x017BD4D4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            var val_44 = 0;
            // 0x017BD4D8: SXTW x9, w25               | X9 = 13844480 (0x00D34000);             
            // 0x017BD4DC: LSL w8, w8, #0x10          | W8 = (0 << 16) = 0 (0x00000000);        
            // 0x017BD4E0: STR x9, [sp, #8]           | stack[1152921513635533512] = 0xD34000;   //  dest_result_addr=1152921513635533512
            // 0x017BD4E4: STR w8, [sp, #0x14]        | stack[1152921513635533524] = 0x0;        //  dest_result_addr=1152921513635533524
            label_44:
            // 0x017BD4E8: LDR w8, [x23, #0x18]       | W8 = System.Int32[].__il2cppRuntimeField_namespaze;
            // 0x017BD4EC: CMP x21, x8                | STATE = COMPARE(0x0, System.Int32[].__il2cppRuntimeField_namespaze)
            // 0x017BD4F0: B.LO #0x17bd500            | if (0 < System.Int32[].__il2cppRuntimeField_namespaze) goto label_10;
            // 0x017BD4F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD4F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_42 = 0;
            // 0x017BD4FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryReader), ????);
            label_10:
            // 0x017BD500: ADD x8, x23, x21, lsl #2   | X8 = (null + 0) = 1152921504962510832 (0x100000001532FFF0);
            // 0x017BD504: LDR w8, [x8, #0x20]        | W8 = typeof(System.IO.BinaryReader);    
            // 0x017BD508: CMN w8, #1                 | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BD50C: B.EQ #0x17bd9e0            | if (System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 == 0x1) goto label_29;
            // 0x017BD510: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD514: LDR w9, [sp, #0x14]        | W9 = 0x0;                               
            var val_42 = 0;
            // 0x017BD518: LDR w8, [x8, #0x28]        | W8 = mem[1152921513635545784];          
            var val_43 = mem[1152921513635545784];
            // 0x017BD51C: ORR w9, w21, w9            | W9 = (0 | 0);                           
            val_42 = val_44 | val_42;
            // 0x017BD520: ORR w8, w9, w8, lsl #24    | W8 = ((0 | 0) | (mem[1152921513635545784]) << 24);
            val_43 = val_42 | (val_43 << 24);
            // 0x017BD524: STUR w8, [x29, #-0x54]     | stack[1152921513635533644] = ((0 | 0) | (mem[1152921513635545784]) << 24);  //  dest_result_addr=1152921513635533644
            // 0x017BD528: CBNZ x20, #0x17bd530       | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x017BD52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_12:
            // 0x017BD530: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD534: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BD538: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD53C: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BD540: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD544: CBNZ x24, #0x17bd54c       | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x017BD548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_13:
            // 0x017BD54C: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BD550: LDP x9, x1, [x8, #0x1a0]   |                                          //  not_find_field!1:416 |  not_find_field!1:424
            // 0x017BD554: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD558: BLR x9                     | X0 = mem[null + 416]();                 
            // 0x017BD55C: CBNZ x20, #0x17bd564       | if ( != 0) goto label_14;               
            if(null != 0)
            {
                goto label_14;
            }
            // 0x017BD560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_14:
            // 0x017BD564: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD568: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD56C: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD570: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD574: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD578: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD57C: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD580: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD584: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD588: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD58C: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD590: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD594: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD598: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD59C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5A0: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD5A4: MOV w26, w0                | W26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5A8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD5AC: AND w9, w24, #1            | W9 = (null & 1) = 0 (0x00000000);       
            // 0x017BD5B0: TBNZ w9, #0, #0x17bd7b4    | if ((0x0 & 0x1) != 0) goto label_15;    
            if((0 & 1) != 0)
            {
                goto label_15;
            }
            // 0x017BD5B4: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD5B8: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD5BC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5C0: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD5C4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD5C8: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BD5CC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5D0: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BD5D4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD5D8: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BD5DC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5E0: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BD5E4: MOV w25, w0                | W25 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5E8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD5EC: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD5F0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD5F4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD5F8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD5FC: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x017BD600: LDR x8, [x8, #0x658]       | X8 = (string**)(1152921509750944816)("X4");
            // 0x017BD604: STUR w0, [x29, #-0x58]     | stack[1152921513635533640] = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921513635533640
            // 0x017BD608: LDR x1, [x8]               | X1 = "X4";                              
            // 0x017BD60C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BD610: SUB x0, x29, #0x54         | X0 = (1152921513635533728 - 84) = 1152921513635533644 (0x100000021A26D34C);
            // 0x017BD614: BL #0x1e63df8              | X0 = ((0 | 0) | (mem[1152921513635545784]) << 24).ToString(format:  "X4");
            string val_4 = val_43.ToString(format:  "X4");
            // 0x017BD618: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x017BD61C: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD620: LDR x27, [x8, #0x20]       | X27 = mem[1152921513635545776];         
            // 0x017BD624: CBNZ x27, #0x17bd62c       | if (mem[1152921513635545776] != 0) goto label_16;
            if(mem[1152921513635545776] != 0)
            {
                goto label_16;
            }
            // 0x017BD628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_16:
            // 0x017BD62C: LDR w8, [x27, #0x18]       | W8 = mem[1152921513635545776] + 24;     
            // 0x017BD630: CMP w26, w8                | STATE = COMPARE(typeof(System.IO.BinaryReader), mem[1152921513635545776] + 24)
            // 0x017BD634: B.LO #0x17bd644            | if (null < mem[1152921513635545776] + 24) goto label_17;
            if(null < (mem[1152921513635545776] + 24))
            {
                goto label_17;
            }
            // 0x017BD638: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x017BD63C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BD640: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_17:
            // 0x017BD644: SXTW x8, w26               | X8 = 13844480 (0x00D34000);             
            // 0x017BD648: ADD x8, x27, x8, lsl #3    | X8 = (mem[1152921513635545776] + 110755840);
            var val_5 = mem[1152921513635545776] + 110755840;
            // 0x017BD64C: LDR x27, [x8, #0x20]       | X27 = (mem[1152921513635545776] + 110755840) + 32;
            // 0x017BD650: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD654: LDR x26, [x8, #0x40]       | X26 = mem[1152921513635545808];         
            // 0x017BD658: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BD65C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BD660: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x017BD664: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x017BD668: BL #0x1e623b0              | X0 = System.Int32.Parse(s:  0, style:  val_4);
            int val_6 = System.Int32.Parse(s:  0, style:  val_4);
            // 0x017BD66C: MOV w28, w0                | W28 = val_6;//m1                        
            // 0x017BD670: CBNZ x26, #0x17bd678       | if (mem[1152921513635545808] != 0) goto label_18;
            if(mem[1152921513635545808] != 0)
            {
                goto label_18;
            }
            // 0x017BD674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_18:
            // 0x017BD678: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x017BD67C: LDR x8, [x8, #0x238]       | X8 = 1152921513635448864;               
            // 0x017BD680: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>::ContainsKey(System.Int32 key);
            // 0x017BD684: MOV x0, x26                | X0 = mem[1152921513635545808];//m1      
            // 0x017BD688: MOV w1, w28                | W1 = val_6;//m1                         
            // 0x017BD68C: BL #0x2415bdc              | X0 = mem[1152921513635545808].ContainsKey(key:  val_6);
            bool val_7 = mem[1152921513635545808].ContainsKey(key:  val_6);
            // 0x017BD690: TBZ w0, #0, #0x17bd6dc     | if (val_7 == false) goto label_19;      
            if(val_7 == false)
            {
                goto label_19;
            }
            // 0x017BD694: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD698: LDR x26, [x8, #0x40]       | X26 = mem[1152921513635545808];         
            // 0x017BD69C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BD6A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BD6A4: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x017BD6A8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x017BD6AC: BL #0x1e623b0              | X0 = System.Int32.Parse(s:  0, style:  val_4);
            int val_8 = System.Int32.Parse(s:  0, style:  val_4);
            // 0x017BD6B0: MOV w28, w0                | W28 = val_8;//m1                        
            // 0x017BD6B4: CBNZ x26, #0x17bd6bc       | if (mem[1152921513635545808] != 0) goto label_20;
            if(mem[1152921513635545808] != 0)
            {
                goto label_20;
            }
            // 0x017BD6B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_20:
            // 0x017BD6BC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x017BD6C0: LDR x8, [x8, #0xf58]       | X8 = 1152921513635449888;               
            // 0x017BD6C4: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<System.String> System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>::get_Item(System.Int32 key);
            // 0x017BD6C8: MOV x0, x26                | X0 = mem[1152921513635545808];//m1      
            // 0x017BD6CC: MOV w1, w28                | W1 = val_8;//m1                         
            // 0x017BD6D0: BL #0x24144f0              | X0 = mem[1152921513635545808].get_Item(key:  val_8);
            System.Collections.Generic.List<System.String> val_9 = mem[1152921513635545808].Item[val_8];
            // 0x017BD6D4: MOV x26, x0                | X26 = val_9;//m1                        
            val_43 = val_9;
            // 0x017BD6D8: CBNZ x26, #0x17bd710       | if (val_9 != null) goto label_22;       
            if(val_43 != null)
            {
                goto label_22;
            }
            label_19:
            // 0x017BD6DC: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017BD6E0: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x017BD6E4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            // 0x017BD6E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BD6EC: MOV x26, x0                | X26 = 1152921504616644608 (0x1000000000958000);//ML01
            val_43 = null;
            // 0x017BD6F0: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x017BD6F4: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x017BD6F8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017BD6FC: MOV x0, x26                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_10 = val_43;
            // 0x017BD700: BL #0x25e9474              | .ctor();                                
            val_10 = new System.Collections.Generic.List<System.String>();
            // 0x017BD704: CBNZ x26, #0x17bd710       | if ( != 0) goto label_22;               
            if(null != 0)
            {
                goto label_22;
            }
            // 0x017BD708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x017BD70C: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_43 = 0;
            label_22:
            // 0x017BD710: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x017BD714: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x017BD718: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x017BD71C: MOV x0, x26                | X0 = 0 (0x0);//ML01                     
            // 0x017BD720: MOV x1, x27                | X1 = (mem[1152921513635545776] + 110755840) + 32;//m1
            // 0x017BD724: BL #0x25ea480              | val_43.Add(item:  (mem[1152921513635545776] + 110755840) + 32);
            val_43.Add(item:  (mem[1152921513635545776] + 110755840) + 32);
            // 0x017BD728: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD72C: LDR x27, [x8, #0x40]       | X27 = mem[1152921513635545808];         
            // 0x017BD730: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BD734: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BD738: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x017BD73C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x017BD740: BL #0x1e623b0              | X0 = System.Int32.Parse(s:  0, style:  val_4);
            int val_11 = System.Int32.Parse(s:  0, style:  val_4);
            // 0x017BD744: MOV w28, w0                | W28 = val_11;//m1                       
            // 0x017BD748: CBNZ x27, #0x17bd750       | if (mem[1152921513635545808] != 0) goto label_23;
            if(mem[1152921513635545808] != 0)
            {
                goto label_23;
            }
            // 0x017BD74C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_23:
            // 0x017BD750: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x017BD754: LDR x8, [x8, #0x238]       | X8 = 1152921513635448864;               
            // 0x017BD758: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>::ContainsKey(System.Int32 key);
            // 0x017BD75C: MOV x0, x27                | X0 = mem[1152921513635545808];//m1      
            // 0x017BD760: MOV w1, w28                | W1 = val_11;//m1                        
            // 0x017BD764: BL #0x2415bdc              | X0 = mem[1152921513635545808].ContainsKey(key:  val_11);
            bool val_12 = mem[1152921513635545808].ContainsKey(key:  val_11);
            // 0x017BD768: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD76C: LDR x27, [x8, #0x40]       | X27 = mem[1152921513635545808];         
            // 0x017BD770: TBZ w0, #0, #0x17bd854     | if (val_12 == false) goto label_24;     
            if(val_12 == false)
            {
                goto label_24;
            }
            // 0x017BD774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BD778: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BD77C: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x017BD780: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x017BD784: BL #0x1e623b0              | X0 = System.Int32.Parse(s:  0, style:  val_4);
            int val_13 = System.Int32.Parse(s:  0, style:  val_4);
            // 0x017BD788: MOV w28, w0                | W28 = val_13;//m1                       
            // 0x017BD78C: CBNZ x27, #0x17bd794       | if (mem[1152921513635545808] != 0) goto label_25;
            if(mem[1152921513635545808] != 0)
            {
                goto label_25;
            }
            // 0x017BD790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_25:
            // 0x017BD794: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x017BD798: LDR x8, [x8, #0x8c8]       | X8 = 1152921513635455008;               
            // 0x017BD79C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>::set_Item(System.Int32 key, System.Collections.Generic.List<System.String> value);
            // 0x017BD7A0: MOV x0, x27                | X0 = mem[1152921513635545808];//m1      
            // 0x017BD7A4: MOV w1, w28                | W1 = val_13;//m1                        
            // 0x017BD7A8: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x017BD7AC: BL #0x24147b0              | mem[1152921513635545808].set_Item(key:  val_13, value:  val_43);
            mem[1152921513635545808].set_Item(key:  val_13, value:  val_43);
            // 0x017BD7B0: B #0x17bd890               |  goto label_26;                         
            goto label_26;
            label_15:
            // 0x017BD7B4: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD7B8: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD7BC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD7C0: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD7C4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD7C8: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD7CC: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD7D0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD7D4: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD7D8: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD7DC: CMP w24, #1                | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BD7E0: B.LT #0x17bd9e0            | if (null < 0x1) goto label_29;          
            if(null < 1)
            {
                goto label_29;
            }
            // 0x017BD7E4: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            label_28:
            // 0x017BD7E8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD7EC: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD7F0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD7F4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD7F8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD7FC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD800: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BD804: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BD808: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD80C: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD810: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD814: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BD818: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD81C: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BD820: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD824: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BD828: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD82C: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BD830: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD834: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD838: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD83C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD840: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD844: ADD w25, w25, #1           | W25 = (0 + 1);                          
            val_41 = 0 + 1;
            // 0x017BD848: CMP w25, w24               | STATE = COMPARE((0 + 1), typeof(System.IO.BinaryReader))
            // 0x017BD84C: B.LT #0x17bd7e8            | if (val_41 < null) goto label_28;       
            if(val_41 < null)
            {
                goto label_28;
            }
            // 0x017BD850: B #0x17bd9e0               |  goto label_29;                         
            goto label_29;
            label_24:
            // 0x017BD854: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BD858: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BD85C: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x017BD860: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x017BD864: BL #0x1e623b0              | X0 = System.Int32.Parse(s:  0, style:  val_4);
            int val_14 = System.Int32.Parse(s:  0, style:  val_4);
            // 0x017BD868: MOV w28, w0                | W28 = val_14;//m1                       
            // 0x017BD86C: CBNZ x27, #0x17bd874       | if (mem[1152921513635545808] != 0) goto label_30;
            if(mem[1152921513635545808] != 0)
            {
                goto label_30;
            }
            // 0x017BD870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_30:
            // 0x017BD874: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x017BD878: LDR x8, [x8, #0x48]        | X8 = 1152921513635456032;               
            // 0x017BD87C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<System.String>>::Add(System.Int32 key, System.Collections.Generic.List<System.String> value);
            // 0x017BD880: MOV x0, x27                | X0 = mem[1152921513635545808];//m1      
            // 0x017BD884: MOV w1, w28                | W1 = val_14;//m1                        
            // 0x017BD888: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x017BD88C: BL #0x2415668              | mem[1152921513635545808].Add(key:  val_14, value:  val_43);
            mem[1152921513635545808].Add(key:  val_14, value:  val_43);
            label_26:
            // 0x017BD890: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x017BD894: LDR x8, [x8, #0x670]       | X8 = 1152921504856686592;               
            // 0x017BD898: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_44 = null;
            // 0x017BD89C: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BD8A0: TBZ w8, #0, #0x17bd8bc     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x017BD8A4: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BD8A8: CBNZ w8, #0x17bd8bc        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x017BD8AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BD8B0: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x017BD8B4: LDR x8, [x8, #0x670]       | X8 = 1152921504856686592;               
            // 0x017BD8B8: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            val_44 = null;
            label_32:
            // 0x017BD8BC: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BD8C0: AND w10, w25, #0xff        | W10 = (null & 255) = 0 (0x00000000);    
            // 0x017BD8C4: LDRB w9, [x8, #0xb]        | W9 = Iteedee.ApkReader.ApkResourceFinder.TYPE_STRING;
            // 0x017BD8C8: CMP w10, w9                | STATE = COMPARE(0x0, Iteedee.ApkReader.ApkResourceFinder.TYPE_STRING)
            // 0x017BD8CC: B.NE #0x17bd908            | if (0 != Iteedee.ApkReader.ApkResourceFinder.TYPE_STRING) goto label_33;
            if(0 != Iteedee.ApkReader.ApkResourceFinder.TYPE_STRING)
            {
                goto label_33;
            }
            // 0x017BD8D0: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BD8D4: LDURSW x26, [x29, #-0x58]  | X26 = typeof(System.IO.BinaryReader);   
            // 0x017BD8D8: LDR x25, [x8, #0x10]       | X25 = mem[1152921513635545760];         
            // 0x017BD8DC: CBNZ x25, #0x17bd8e4       | if (mem[1152921513635545760] != 0) goto label_34;
            if(mem[1152921513635545760] != 0)
            {
                goto label_34;
            }
            // 0x017BD8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            label_34:
            // 0x017BD8E4: LDR w8, [x25, #0x18]       | W8 = mem[1152921513635545760] + 24;     
            // 0x017BD8E8: CMP w26, w8                | STATE = COMPARE(typeof(System.IO.BinaryReader), mem[1152921513635545760] + 24)
            // 0x017BD8EC: B.LO #0x17bd8fc            | if (null < mem[1152921513635545760] + 24) goto label_35;
            if(null < (mem[1152921513635545760] + 24))
            {
                goto label_35;
            }
            // 0x017BD8F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BD8F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BD8F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            label_35:
            // 0x017BD8FC: ADD x8, x25, x26, lsl #3   | X8 = (mem[1152921513635545760] + -9223372036744019968);
            var val_15 = mem[1152921513635545760] + (-9223372036744019968);
            // 0x017BD900: LDR x25, [x8, #0x20]       | X25 = (mem[1152921513635545760] + -9223372036744019968) + 32;
            val_41 = mem[(mem[1152921513635545760] + -9223372036744019968) + 32];
            val_41 = (mem[1152921513635545760] + -9223372036744019968) + 32;
            // 0x017BD904: B #0x17bd994               |  goto label_41;                         
            goto label_41;
            label_33:
            // 0x017BD908: LDRB w9, [x0, #0x10a]      | W9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_10A;
            // 0x017BD90C: TBZ w9, #0, #0x17bd92c     | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x017BD910: LDR w9, [x0, #0xbc]        | W9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished;
            // 0x017BD914: CBNZ w9, #0x17bd92c        | if (Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x017BD918: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BD91C: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x017BD920: LDR x8, [x8, #0x670]       | X8 = 1152921504856686592;               
            // 0x017BD924: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BD928: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            label_38:
            // 0x017BD92C: LDRB w8, [x8, #0xa]        | W8 = Iteedee.ApkReader.ApkResourceFinder.TYPE_REFERENCE;
            // 0x017BD930: AND w9, w25, #0xff         | W9 = (null & 255) = 0 (0x00000000);     
            // 0x017BD934: CMP w9, w8                 | STATE = COMPARE(0x0, Iteedee.ApkReader.ApkResourceFinder.TYPE_REFERENCE)
            // 0x017BD938: B.NE #0x17bd984            | if (0 != Iteedee.ApkReader.ApkResourceFinder.TYPE_REFERENCE) goto label_39;
            if(0 != Iteedee.ApkReader.ApkResourceFinder.TYPE_REFERENCE)
            {
                goto label_39;
            }
            // 0x017BD93C: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x017BD940: LDR x8, [x8, #0x658]       | X8 = (string**)(1152921509750944816)("X4");
            // 0x017BD944: LDR x1, [x8]               | X1 = "X4";                              
            // 0x017BD948: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BD94C: SUB x0, x29, #0x58         | X0 = (1152921513635533728 - 88) = 1152921513635533640 (0x100000021A26D348);
            // 0x017BD950: BL #0x1e63df8              | X0 = typeof(System.IO.BinaryReader).ToString(format:  "X4");
            string val_16 = null.ToString(format:  "X4");
            // 0x017BD954: LDUR w25, [x29, #-0x58]    | W25 = typeof(System.IO.BinaryReader);   
            // 0x017BD958: CBNZ x22, #0x17bd960       | if ( != 0) goto label_40;               
            if(null != 0)
            {
                goto label_40;
            }
            // 0x017BD95C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_40:
            // 0x017BD960: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x017BD964: LDR x8, [x8, #0xfb0]       | X8 = 1152921509743365200;               
            // 0x017BD968: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
            // 0x017BD96C: MOV x0, x22                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BD970: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x017BD974: MOV w2, w25                | W2 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD978: BL #0x23f5288              | Add(key:  val_4, value:  13844480);     
            Add(key:  val_4, value:  13844480);
            // 0x017BD97C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_41 = 0;
            // 0x017BD980: B #0x17bd994               |  goto label_41;                         
            goto label_41;
            label_39:
            // 0x017BD984: SUB x0, x29, #0x58         | X0 = (1152921513635533728 - 88) = 1152921513635533640 (0x100000021A26D348);
            // 0x017BD988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BD98C: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
            // 0x017BD990: MOV x25, x0                | X25 = 1152921513635533640 (0x100000021A26D348);//ML01
            val_41;
            label_41:
            // 0x017BD994: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BD998: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BD99C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BD9A0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BD9A4: TBZ w8, #0, #0x17bd9b4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x017BD9A8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BD9AC: CBNZ w8, #0x17bd9b4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x017BD9B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_43:
            // 0x017BD9B4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x017BD9B8: LDR x8, [x8, #0xf68]       | X8 = (string**)(1152921512830278272)("@");
            // 0x017BD9BC: LDR x1, [x8]               | X1 = "@";                               
            // 0x017BD9C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BD9C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BD9C8: MOV x2, x24                | X2 = val_4;//m1                         
            // 0x017BD9CC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "@");
            string val_17 = System.String.Concat(str0:  0, str1:  "@");
            // 0x017BD9D0: MOV x1, x0                 | X1 = val_17;//m1                        
            // 0x017BD9D4: LDR x0, [sp, #0x18]        | X0 = this;                              
            // 0x017BD9D8: MOV x2, x25                | X2 = 1152921513635533640 (0x100000021A26D348);//ML01
            // 0x017BD9DC: BL #0x17bdf74              | this.putIntoMap(resId:  val_17, value:  null);
            this.putIntoMap(resId:  val_17, value:  null);
            label_29:
            // 0x017BD9E0: LDR x8, [sp, #8]           | X8 = 0xD34000;                          
            // 0x017BD9E4: ADD x21, x21, #1           | X21 = (0 + 1);                          
            val_44 = val_44 + 1;
            // 0x017BD9E8: CMP x21, x8                | STATE = COMPARE((0 + 1), 0xD34000)      
            // 0x017BD9EC: B.LT #0x17bd4e8            | if (0 < 13844480) goto label_44;        
            if(val_44 < 13844480)
            {
                goto label_44;
            }
            label_9:
            // 0x017BD9F0: CBNZ x22, #0x17bd9fc       | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x017BD9F4: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BD9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_45:
            // 0x017BD9FC: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x017BDA00: LDR x8, [x8, #0x810]       | X8 = 1152921513635465248;               
            // 0x017BDA04: LDR x1, [x8]               | X1 = public Dictionary.KeyCollection<TKey, TValue> System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Keys();
            // 0x017BDA08: MOV x0, x22                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BDA0C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDA10: BL #0x23f6910              | X0 = get_Keys();                        
            Dictionary.KeyCollection<TKey, TValue> val_18 = Keys;
            // 0x017BDA14: MOV x24, x0                | X24 = val_18;//m1                       
            // 0x017BDA18: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x017BDA1C: LDR x8, [x8, #0x138]       | X8 = 1152921504685920256;               
            // 0x017BDA20: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.HashSet<T>);
            // 0x017BDA24: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDA28: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.HashSet<T>), ????);
            // 0x017BDA2C: MOV x23, x0                | X23 = 1152921504685920256 (0x1000000004B69000);//ML01
            // 0x017BDA30: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x017BDA34: LDR x8, [x8, #0x8b8]       | X8 = 1152921513635470368;               
            // 0x017BDA38: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.HashSet<System.String>::.ctor(System.Collections.Generic.IEnumerable<T> collection);
            // 0x017BDA3C: MOV x0, x23                | X0 = 1152921504685920256 (0x1000000004B69000);//ML01
            System.Collections.Generic.HashSet<System.String> val_19 = null;
            // 0x017BDA40: MOV x1, x24                | X1 = val_18;//m1                        
            // 0x017BDA44: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDA48: BL #0x1f3d69c              | .ctor(collection:  val_18);             
            val_19 = new System.Collections.Generic.HashSet<System.String>(collection:  val_18);
            // 0x017BDA4C: CBNZ x23, #0x17bda58       | if ( != 0) goto label_46;               
            if(null != 0)
            {
                goto label_46;
            }
            // 0x017BDA50: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDA54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(collection:  val_18), ????);
            label_46:
            // 0x017BDA58: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x017BDA5C: LDR x8, [x8, #0xd80]       | X8 = 1152921513635471392;               
            // 0x017BDA60: LDR x1, [x8]               | X1 = public HashSet.Enumerator<T> System.Collections.Generic.HashSet<System.String>::GetEnumerator();
            // 0x017BDA64: ADD x8, sp, #0x38          | X8 = (1152921513635533504 + 56) = 1152921513635533560 (0x100000021A26D2F8);
            // 0x017BDA68: MOV x0, x23                | X0 = 1152921504685920256 (0x1000000004B69000);//ML01
            // 0x017BDA6C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDA70: BL #0x1f3eff4              | X0 = GetEnumerator();                   
            HashSet.Enumerator<T> val_20 = GetEnumerator();
            // 0x017BDA74: LDR x8, [sp, #0x48]        | X8 = val_21;                             //  find_add[1152921513635521744]
            // 0x017BDA78: LDUR q0, [sp, #0x38]       | Q0 = val_22;                             //  find_add[1152921513635521744]
            // 0x017BDA7C: ADRP x27, #0x35c8000       | X27 = 56393728 (0x35C8000);             
            // 0x017BDA80: ADRP x21, #0x364c000       | X21 = 56934400 (0x364C000);             
            // 0x017BDA84: LDR x27, [x27, #0xeb0]     | X27 = 1152921510808082832;              
            // 0x017BDA88: LDR x21, [x21, #0x658]     | X21 = (string**)(1152921509750944816)("X4");
            // 0x017BDA8C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDA90: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_46 = 0;
            // 0x017BDA94: STR x8, [sp, #0x80]        | stack[1152921513635533632] = val_21;     //  dest_result_addr=1152921513635533632
            // 0x017BDA98: STR q0, [sp, #0x70]        | stack[1152921513635533616] = val_22;     //  dest_result_addr=1152921513635533616
            label_68:
            // 0x017BDA9C: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x017BDAA0: LDR x8, [x8, #0xe78]       | X8 = 1152921513635472416;               
            // 0x017BDAA4: LDR x1, [x8]               | X1 = public System.Boolean HashSet.Enumerator<System.String>::MoveNext();
            // 0x017BDAA8: ADD x0, sp, #0x70          | X0 = (1152921513635533504 + 112) = 1152921513635533616 (0x100000021A26D330);
            // 0x017BDAAC: BL #0x1f3b040              | X0 = label_HashSet_Enumerator<System_Object>_System_Collections_IEnumerator_Reset_GL01F3B040();
            // 0x017BDAB0: AND w8, w0, #1             | W8 = (1152921513635533616 & 1) = 0 (0x00000000);
            // 0x017BDAB4: TBZ w8, #0, #0x17bdda4     | if ((0x0 & 0x1) == 0) goto label_47;    
            if((0 & 1) == 0)
            {
                goto label_47;
            }
            // 0x017BDAB8: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x017BDABC: LDR x8, [x8, #0x6c8]       | X8 = 1152921513635473440;               
            // 0x017BDAC0: LDR x1, [x8]               | X1 = public System.String HashSet.Enumerator<System.String>::get_Current();
            // 0x017BDAC4: ADD x0, sp, #0x70          | X0 = (1152921513635533504 + 112) = 1152921513635533616 (0x100000021A26D330);
            // 0x017BDAC8: BL #0x1f3b15c              | X0 = val_22.get_InitialType();          
            System.Type val_23 = val_22.InitialType;
            // 0x017BDACC: MOV x24, x0                | X24 = val_23;//m1                       
            // 0x017BDAD0: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BDAD4: LDR x25, [x8, #0x38]       | X25 = mem[1152921513635545800];         
            // 0x017BDAD8: CBNZ x22, #0x17bdae0       | if ( != 0) goto label_48;               
            if(null != 0)
            {
                goto label_48;
            }
            // 0x017BDADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_48:
            // 0x017BDAE0: LDR x2, [x27]              | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
            // 0x017BDAE4: MOV x0, x22                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BDAE8: MOV x1, x24                | X1 = val_23;//m1                        
            // 0x017BDAEC: BL #0x23f40a8              | X0 = get_Item(key:  val_23);            
            int val_24 = Item[val_23];
            // 0x017BDAF0: LDR x1, [x21]              | X1 = "X4";                              
            // 0x017BDAF4: STR w0, [sp, #0x6c]        | stack[1152921513635533612] = val_24;     //  dest_result_addr=1152921513635533612
            // 0x017BDAF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BDAFC: ADD x0, sp, #0x6c          | X0 = (1152921513635533504 + 108) = 1152921513635533612 (0x100000021A26D32C);
            // 0x017BDB00: BL #0x1e63df8              | X0 = val_24.ToString(format:  "X4");    
            string val_25 = val_24.ToString(format:  "X4");
            // 0x017BDB04: MOV x26, x0                | X26 = val_25;//m1                       
            // 0x017BDB08: CBNZ x26, #0x17bdb10       | if (val_25 != null) goto label_49;      
            if(val_25 != null)
            {
                goto label_49;
            }
            // 0x017BDB0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_49:
            // 0x017BDB10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDB14: MOV x0, x26                | X0 = val_25;//m1                        
            // 0x017BDB18: BL #0x18af030              | X0 = val_25.ToUpper();                  
            string val_26 = val_25.ToUpper();
            // 0x017BDB1C: MOV x26, x0                | X26 = val_26;//m1                       
            // 0x017BDB20: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BDB24: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BDB28: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BDB2C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BDB30: TBZ w8, #0, #0x17bdb40     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x017BDB34: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BDB38: CBNZ w8, #0x17bdb40        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x017BDB3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_51:
            // 0x017BDB40: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x017BDB44: LDR x8, [x8, #0xf68]       | X8 = (string**)(1152921512830278272)("@");
            // 0x017BDB48: LDR x1, [x8]               | X1 = "@";                               
            // 0x017BDB4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BDB50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BDB54: MOV x2, x26                | X2 = val_26;//m1                        
            // 0x017BDB58: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "@");
            string val_27 = System.String.Concat(str0:  0, str1:  "@");
            // 0x017BDB5C: MOV x26, x0                | X26 = val_27;//m1                       
            // 0x017BDB60: CBNZ x25, #0x17bdb68       | if (mem[1152921513635545800] != 0) goto label_52;
            if(mem[1152921513635545800] != 0)
            {
                goto label_52;
            }
            // 0x017BDB64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_52:
            // 0x017BDB68: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x017BDB6C: LDR x8, [x8, #0xf50]       | X8 = 1152921513633382752;               
            // 0x017BDB70: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::ContainsKey(System.String key);
            // 0x017BDB74: MOV x0, x25                | X0 = mem[1152921513635545800];//m1      
            // 0x017BDB78: MOV x1, x26                | X1 = val_27;//m1                        
            // 0x017BDB7C: BL #0x23fd9f0              | X0 = mem[1152921513635545800].ContainsKey(key:  val_27);
            bool val_28 = mem[1152921513635545800].ContainsKey(key:  val_27);
            // 0x017BDB80: TBZ w0, #0, #0x17bda9c     | if (val_28 == false) goto label_68;     
            if(val_28 == false)
            {
                goto label_68;
            }
            // 0x017BDB84: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x017BDB88: LDR x25, [x8, #0x38]       | X25 = mem[1152921513635545800];         
            // 0x017BDB8C: CBNZ x22, #0x17bdb94       | if ( != 0) goto label_54;               
            if(null != 0)
            {
                goto label_54;
            }
            // 0x017BDB90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_54:
            // 0x017BDB94: LDR x2, [x27]              | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
            // 0x017BDB98: MOV x0, x22                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017BDB9C: MOV x1, x24                | X1 = val_23;//m1                        
            // 0x017BDBA0: BL #0x23f40a8              | X0 = get_Item(key:  val_23);            
            int val_29 = Item[val_23];
            // 0x017BDBA4: LDR x1, [x21]              | X1 = "X4";                              
            // 0x017BDBA8: STR w0, [sp, #0x68]        | stack[1152921513635533608] = val_29;     //  dest_result_addr=1152921513635533608
            // 0x017BDBAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BDBB0: ADD x0, sp, #0x68          | X0 = (1152921513635533504 + 104) = 1152921513635533608 (0x100000021A26D328);
            // 0x017BDBB4: BL #0x1e63df8              | X0 = val_29.ToString(format:  "X4");    
            string val_30 = val_29.ToString(format:  "X4");
            // 0x017BDBB8: MOV x26, x0                | X26 = val_30;//m1                       
            // 0x017BDBBC: CBNZ x26, #0x17bdbc4       | if (val_30 != null) goto label_55;      
            if(val_30 != null)
            {
                goto label_55;
            }
            // 0x017BDBC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_55:
            // 0x017BDBC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDBC8: MOV x0, x26                | X0 = val_30;//m1                        
            // 0x017BDBCC: BL #0x18af030              | X0 = val_30.ToUpper();                  
            string val_31 = val_30.ToUpper();
            // 0x017BDBD0: MOV x26, x0                | X26 = val_31;//m1                       
            // 0x017BDBD4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BDBD8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BDBDC: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BDBE0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BDBE4: TBZ w8, #0, #0x17bdbf4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_57;
            // 0x017BDBE8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BDBEC: CBNZ w8, #0x17bdbf4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
            // 0x017BDBF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_57:
            // 0x017BDBF4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x017BDBF8: LDR x8, [x8, #0xf68]       | X8 = (string**)(1152921512830278272)("@");
            // 0x017BDBFC: LDR x1, [x8]               | X1 = "@";                               
            // 0x017BDC00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BDC04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BDC08: MOV x2, x26                | X2 = val_31;//m1                        
            // 0x017BDC0C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "@");
            string val_32 = System.String.Concat(str0:  0, str1:  "@");
            // 0x017BDC10: MOV x26, x0                | X26 = val_32;//m1                       
            // 0x017BDC14: CBNZ x25, #0x17bdc1c       | if (mem[1152921513635545800] != 0) goto label_58;
            if(mem[1152921513635545800] != 0)
            {
                goto label_58;
            }
            // 0x017BDC18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_58:
            // 0x017BDC1C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x017BDC20: LDR x8, [x8, #0x800]       | X8 = 1152921513633387872;               
            // 0x017BDC24: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<System.String> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::get_Item(System.String key);
            // 0x017BDC28: MOV x0, x25                | X0 = mem[1152921513635545800];//m1      
            // 0x017BDC2C: MOV x1, x26                | X1 = val_32;//m1                        
            // 0x017BDC30: BL #0x23fc26c              | X0 = mem[1152921513635545800].get_Item(key:  val_32);
            System.Collections.Generic.List<System.String> val_33 = mem[1152921513635545800].Item[val_32];
            // 0x017BDC34: CBZ x0, #0x17bda9c         | if (val_33 == null) goto label_68;      
            if(val_33 == null)
            {
                goto label_68;
            }
            // 0x017BDC38: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x017BDC3C: LDR x8, [x8, #0xb00]       | X8 = 1152921510022785904;               
            // 0x017BDC40: MOV w25, w28               | W25 = 0 (0x0);//ML01                    
            // 0x017BDC44: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.String>::GetEnumerator();
            // 0x017BDC48: ADD x8, sp, #0x20          | X8 = (1152921513635533504 + 32) = 1152921513635533536 (0x100000021A26D2E0);
            // 0x017BDC4C: BL #0x25ebf2c              | X0 = val_33.GetEnumerator();            
            List.Enumerator<T> val_34 = val_33.GetEnumerator();
            // 0x017BDC50: ADRP x26, #0x3637000       | X26 = 56848384 (0x3637000);             
            // 0x017BDC54: LDR x26, [x26, #0x1a8]     | X26 = 1152921510022786928;              
            // 0x017BDC58: LDR x8, [sp, #0x30]        | X8 = val_35;                             //  find_add[1152921513635521744]
            // 0x017BDC5C: LDR q0, [sp, #0x20]        | Q0 = val_36;                             //  find_add[1152921513635521744]
            // 0x017BDC60: STR x8, [sp, #0x60]        | stack[1152921513635533600] = val_35;     //  dest_result_addr=1152921513635533600
            // 0x017BDC64: STR q0, [sp, #0x50]        | stack[1152921513635533584] = val_36;     //  dest_result_addr=1152921513635533584
            label_63:
            // 0x017BDC68: LDR x1, [x26]              | X1 = public System.Boolean List.Enumerator<System.String>::MoveNext();
            // 0x017BDC6C: ADD x0, sp, #0x50          | X0 = (1152921513635533504 + 80) = 1152921513635533584 (0x100000021A26D310);
            // 0x017BDC70: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x017BDC74: AND w8, w0, #1             | W8 = (1152921513635533584 & 1) = 0 (0x00000000);
            // 0x017BDC78: TBZ w8, #0, #0x17bdd04     | if ((0x0 & 0x1) == 0) goto label_60;    
            if((0 & 1) == 0)
            {
                goto label_60;
            }
            // 0x017BDC7C: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x017BDC80: LDR x8, [x8, #0x8d0]       | X8 = 1152921510022787952;               
            // 0x017BDC84: LDR x1, [x8]               | X1 = public System.String List.Enumerator<System.String>::get_Current();
            // 0x017BDC88: ADD x0, sp, #0x50          | X0 = (1152921513635533504 + 80) = 1152921513635533584 (0x100000021A26D310);
            // 0x017BDC8C: BL #0x13372d8              | X0 = val_36.get_InitialType();          
            System.Type val_37 = val_36.InitialType;
            // 0x017BDC90: MOV x25, x0                | X25 = val_37;//m1                       
            // 0x017BDC94: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BDC98: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BDC9C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BDCA0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BDCA4: TBZ w8, #0, #0x17bdcb4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_62;
            // 0x017BDCA8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BDCAC: CBNZ w8, #0x17bdcb4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
            // 0x017BDCB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_62:
            // 0x017BDCB4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x017BDCB8: LDR x8, [x8, #0xf68]       | X8 = (string**)(1152921512830278272)("@");
            // 0x017BDCBC: LDR x1, [x8]               | X1 = "@";                               
            // 0x017BDCC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BDCC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BDCC8: MOV x2, x24                | X2 = val_23;//m1                        
            // 0x017BDCCC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "@");
            string val_38 = System.String.Concat(str0:  0, str1:  "@");
            // 0x017BDCD0: MOV x1, x0                 | X1 = val_38;//m1                        
            // 0x017BDCD4: LDR x0, [sp, #0x18]        | X0 = this;                              
            // 0x017BDCD8: MOV x2, x25                | X2 = val_37;//m1                        
            // 0x017BDCDC: BL #0x17bdf74              | this.putIntoMap(resId:  val_38, value:  val_37);
            this.putIntoMap(resId:  val_38, value:  val_37);
            // 0x017BDCE0: B #0x17bdc68               |  goto label_63;                         
            goto label_63;
            // 0x017BDCE4: CMP w1, #1                 | STATE = COMPARE(val_38, 0x1)            
            // 0x017BDCE8: B.NE #0x17bdd68            | if (val_38 != 0x1) goto label_69;       
            if(val_38 != 1)
            {
                goto label_69;
            }
            // 0x017BDCEC: MOV w25, w28               | W25 = 0 (0x0);//ML01                    
            // 0x017BDCF0: BL #0x981060               | X0 = sub_981060( ?? this, ????);        
            // 0x017BDCF4: LDR x24, [x0]              | X24 = this;                             
            val_47 = this;
            // 0x017BDCF8: BL #0x980920               | X0 = sub_980920( ?? this, ????);        
            // 0x017BDCFC: MOV w25, w28               | W25 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x017BDD00: B #0x17bdd0c               |  goto label_65;                         
            goto label_65;
            label_60:
            // 0x017BDD04: MOVZ w25, #0x397           | W25 = 919 (0x397);//ML01                
            val_48 = 919;
            // 0x017BDD08: MOV x24, x23               | X24 = 0 (0x0);//ML01                    
            val_47 = val_46;
            label_65:
            // 0x017BDD0C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x017BDD10: LDR x8, [x8, #0xd70]       | X8 = 1152921510022801264;               
            // 0x017BDD14: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.String>::Dispose();
            // 0x017BDD18: ADD x0, sp, #0x50          | X0 = (1152921513635533504 + 80) = 1152921513635533584 (0x100000021A26D310);
            // 0x017BDD1C: BL #0x13371f4              | val_36.Dispose();                       
            val_36.Dispose();
            // 0x017BDD20: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDD24: CMP w25, #0x397            | STATE = COMPARE(0x397, 0x397)           
            // 0x017BDD28: MOV x23, x24               | X23 = 0 (0x0);//ML01                    
            // 0x017BDD2C: B.EQ #0x17bda9c            | if (0x397 == 0x397) goto label_68;      
            if(919 == 919)
            {
                goto label_68;
            }
            // 0x017BDD30: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            // 0x017BDD34: MOV w28, w25               | W28 = 919 (0x397);//ML01                
            // 0x017BDD38: CBZ x24, #0x17bda9c        | if (0x0 == 0) goto label_68;            
            if(val_47 == 0)
            {
                goto label_68;
            }
            // 0x017BDD3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDD40: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x017BDD44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x017BDD48: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            // 0x017BDD4C: MOV w28, w25               | W28 = 919 (0x397);//ML01                
            // 0x017BDD50: B #0x17bda9c               |  goto label_68;                         
            goto label_68;
            // 0x017BDD54: MOV w28, w25               | W28 = 919 (0x397);//ML01                
            val_49 = 919;
            // 0x017BDD58: B #0x17bdd68               |  goto label_69;                         
            goto label_69;
            // 0x017BDD5C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_50 = 0;
            label_94:
            // 0x017BDD60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            val_51 = 1;
            // 0x017BDD64: B #0x17bdd84               |  goto label_71;                         
            goto label_71;
            label_69:
            // 0x017BDD68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            val_51 = 1;
            // 0x017BDD6C: CMP w1, w8                 | STATE = COMPARE(val_38, 0x1)            
            // 0x017BDD70: B.NE #0x17bdd84            | if (val_38 != val_51) goto label_71;    
            if(val_38 != val_51)
            {
                goto label_71;
            }
            // 0x017BDD74: BL #0x981060               | X0 = sub_981060( ?? this, ????);        
            // 0x017BDD78: LDR x23, [x0]              | X23 = this;                             
            val_46 = this;
            // 0x017BDD7C: BL #0x980920               | X0 = sub_980920( ?? this, ????);        
            // 0x017BDD80: B #0x17bdda8               |  goto label_72;                         
            goto label_72;
            label_71:
            // 0x017BDD84: CMP w1, w8                 | STATE = COMPARE(0x0, 0x1)               
            // 0x017BDD88: B.NE #0x17bde68            | if (0 != val_51) goto label_73;         
            if(0 != val_51)
            {
                goto label_73;
            }
            // 0x017BDD8C: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
            // 0x017BDD90: LDR x23, [x0]              | X23 = 0x10102464C457F;                  
            val_46 = 1179403647;
            // 0x017BDD94: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
            // 0x017BDD98: B #0x17bdddc               |  goto label_74;                         
            goto label_74;
            // 0x017BDD9C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDDA0: B #0x17bdd60               |  goto label_94;                         
            goto label_94;
            label_47:
            // 0x017BDDA4: MOVZ w28, #0x3b6           | W28 = 950 (0x3B6);//ML01                
            val_52 = 950;
            label_72:
            // 0x017BDDA8: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x017BDDAC: LDR x8, [x8, #0x800]       | X8 = 1152921513635515424;               
            // 0x017BDDB0: LDR x1, [x8]               | X1 = public System.Void HashSet.Enumerator<System.String>::Dispose();
            // 0x017BDDB4: ADD x0, sp, #0x70          | X0 = (1152921513635533504 + 112) = 1152921513635533616 (0x100000021A26D330);
            // 0x017BDDB8: BL #0x1f3b16c              | val_22.Dispose();                       
            val_22.Dispose();
            // 0x017BDDBC: CMP w28, #0x3b6            | STATE = COMPARE(0x3B6, 0x3B6)           
            // 0x017BDDC0: B.EQ #0x17bddd8            | if (0x3B6 == 0x3B6) goto label_77;      
            if(950 == 950)
            {
                goto label_77;
            }
            // 0x017BDDC4: CBZ x23, #0x17bddd8        | if (0x0 == 0) goto label_77;            
            if(val_46 == 0)
            {
                goto label_77;
            }
            // 0x017BDDC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDDCC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x017BDDD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x017BDDD4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_46 = 0;
            label_77:
            // 0x017BDDD8: MOVZ w28, #0x3d5           | W28 = 981 (0x3D5);//ML01                
            val_50 = 981;
            label_74:
            // 0x017BDDDC: CBZ x20, #0x17bde48        | if ( == 0) goto label_78;               
            if(null == 0)
            {
                goto label_78;
            }
            // 0x017BDDE0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BDDE4: LDR x8, [x20]              | X8 = ;                                  
            System.IO.BinaryReader val_47 = null;
            // 0x017BDDE8: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BDDEC: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BDDF0: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BDDF4: CBZ x9, #0x17bde20         | if (mem[null + 258] == 0) goto label_79;
            if((mem[null + 258]) == 0)
            {
                goto label_79;
            }
            // 0x017BDDF8: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_45 = mem[null + 152];
            // 0x017BDDFC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_46 = 0;
            // 0x017BDE00: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_45 = val_45 + 8;
            label_81:
            // 0x017BDE04: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BDE08: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BDE0C: B.EQ #0x17bde30            | if ((mem[null + 152] + 8) + -8 == null) goto label_80;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_80;
            }
            // 0x017BDE10: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_46 = val_46 + 1;
            // 0x017BDE14: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_45 = val_45 + 16;
            // 0x017BDE18: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BDE1C: B.LO #0x17bde04            | if (0 < mem[null + 258]) goto label_81; 
            if(val_46 < (mem[null + 258]))
            {
                goto label_81;
            }
            label_79:
            // 0x017BDE20: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BDE24: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_53 = null;
            // 0x017BDE28: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BDE2C: B #0x17bde3c               |  goto label_82;                         
            goto label_82;
            label_80:
            // 0x017BDE30: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BDE34: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_47 = val_47 + (((mem[null + 152] + 8)) << 4);
            // 0x017BDE38: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_82:
            // 0x017BDE3C: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
            // 0x017BDE40: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BDE44: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(System.IO.BinaryReader), ????);
            label_78:
            // 0x017BDE48: CMP w28, #0x3d5            | STATE = COMPARE(0x3D5, 0x3D5)           
            // 0x017BDE4C: B.EQ #0x17bde74            | if (0x3D5 == 0x3D5) goto label_85;      
            if(981 == 981)
            {
                goto label_85;
            }
            // 0x017BDE50: CBZ x23, #0x17bde74        | if (0x0 == 0) goto label_85;            
            if(val_46 == 0)
            {
                goto label_85;
            }
            // 0x017BDE54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDE58: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x017BDE5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x017BDE60: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_46 = 0;
            // 0x017BDE64: B #0x17bde74               |  goto label_85;                         
            goto label_85;
            label_73:
            // 0x017BDE68: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
            // 0x017BDE6C: LDR x23, [x0]              | X23 = 0x10102464C457F;                  
            val_46 = 1179403647;
            // 0x017BDE70: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
            label_85:
            // 0x017BDE74: CBZ x19, #0x17bdee0        | if ( == 0) goto label_86;               
            if(null == 0)
            {
                goto label_86;
            }
            // 0x017BDE78: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BDE7C: LDR x8, [x19]              | X8 = ;                                  
            System.IO.MemoryStream val_50 = null;
            // 0x017BDE80: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BDE84: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BDE88: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BDE8C: CBZ x9, #0x17bdeb8         | if (mem[null + 258] == 0) goto label_87;
            if((mem[null + 258]) == 0)
            {
                goto label_87;
            }
            // 0x017BDE90: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_48 = mem[null + 152];
            // 0x017BDE94: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_49 = 0;
            // 0x017BDE98: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_48 = val_48 + 8;
            label_89:
            // 0x017BDE9C: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BDEA0: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BDEA4: B.EQ #0x17bdec8            | if ((mem[null + 152] + 8) + -8 == null) goto label_88;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_88;
            }
            // 0x017BDEA8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_49 = val_49 + 1;
            // 0x017BDEAC: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_48 = val_48 + 16;
            // 0x017BDEB0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BDEB4: B.LO #0x17bde9c            | if (0 < mem[null + 258]) goto label_89; 
            if(val_49 < (mem[null + 258]))
            {
                goto label_89;
            }
            label_87:
            // 0x017BDEB8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BDEBC: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_54 = val_1;
            // 0x017BDEC0: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BDEC4: B #0x17bded4               |  goto label_90;                         
            goto label_90;
            label_88:
            // 0x017BDEC8: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BDECC: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_50 = val_50 + (((mem[null + 152] + 8)) << 4);
            // 0x017BDED0: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_90:
            // 0x017BDED4: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
            // 0x017BDED8: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BDEDC: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(System.IO.MemoryStream), ????);
            label_86:
            // 0x017BDEE0: CMP w28, #0x3d5            | STATE = COMPARE(0x0, 0x3D5)             
            // 0x017BDEE4: B.EQ #0x17bdef8            | if (val_50 == 0x3D5) goto label_92;     
            if(val_50 == 981)
            {
                goto label_92;
            }
            // 0x017BDEE8: CBZ x23, #0x17bdef8        | if (0x10102464C457F == 0) goto label_92;
            if(val_46 == 0)
            {
                goto label_92;
            }
            // 0x017BDEEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BDEF0: MOV x0, x23                | X0 = 282584257676671 (0x10102464C457F);//ML01
            // 0x017BDEF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
            label_92:
            // 0x017BDEF8: SUB sp, x29, #0x50         | SP = (1152921513635533728 - 80) = 1152921513635533648 (0x100000021A26D350);
            // 0x017BDEFC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x017BDF00: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x017BDF04: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x017BDF08: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x017BDF0C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x017BDF10: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x017BDF14: RET                        |  return;                                
            return;
            // 0x017BDF18: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDF1C: B #0x17bdd60               |  goto label_94;                         
            goto label_94;
            label_3:
            // 0x017BDF20: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BDF24: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BDF28: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BDF2C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDF30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BDF34: MOV x21, x0                | X21 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BDF38: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x017BDF3C: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921513635516448)("HeaderSize, entryCount and entriesStart are not valid.");
            // 0x017BDF40: LDR x1, [x8]               | X1 = "HeaderSize, entryCount and entriesStart are not valid.";
            // 0x017BDF44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BDF48: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_39 = null;
            // 0x017BDF4C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDF50: BL #0x1c32b48              | .ctor(message:  "HeaderSize, entryCount and entriesStart are not valid.");
            val_39 = new System.Exception(message:  "HeaderSize, entryCount and entriesStart are not valid.");
            // 0x017BDF54: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x017BDF58: LDR x8, [x8, #0x148]       | X8 = 1152921513635516624;               
            // 0x017BDF5C: LDR x1, [x8]               | X1 = System.Void Iteedee.ApkReader.ApkResourceFinder::processType(byte[] typeData);
            // 0x017BDF60: MOV x0, x21                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BDF64: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            // 0x017BDF68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BDF6C: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_40 = System.Collections.IEnumerable.GetEnumerator();
            // 0x017BDF70: B #0x17bdd60               |  goto label_94;                         
            goto label_94;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BBE30 (24886832), len: 1868  VirtAddr: 0x017BBE30 RVA: 0x017BBE30 token: 100684433 methodIndex: 46003 delegateWrapperIndex: 0 methodInvoker: 0
        private string[] processStringPool(byte[] data)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            string val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x017BBE30: STP x28, x27, [sp, #-0x60]! | stack[1152921513635793104] = ???;  stack[1152921513635793112] = ???;  //  dest_result_addr=1152921513635793104 |  dest_result_addr=1152921513635793112
            // 0x017BBE34: STP x26, x25, [sp, #0x10]  | stack[1152921513635793120] = ???;  stack[1152921513635793128] = ???;  //  dest_result_addr=1152921513635793120 |  dest_result_addr=1152921513635793128
            // 0x017BBE38: STP x24, x23, [sp, #0x20]  | stack[1152921513635793136] = ???;  stack[1152921513635793144] = ???;  //  dest_result_addr=1152921513635793136 |  dest_result_addr=1152921513635793144
            // 0x017BBE3C: STP x22, x21, [sp, #0x30]  | stack[1152921513635793152] = ???;  stack[1152921513635793160] = ???;  //  dest_result_addr=1152921513635793152 |  dest_result_addr=1152921513635793160
            // 0x017BBE40: STP x20, x19, [sp, #0x40]  | stack[1152921513635793168] = ???;  stack[1152921513635793176] = ???;  //  dest_result_addr=1152921513635793168 |  dest_result_addr=1152921513635793176
            // 0x017BBE44: STP x29, x30, [sp, #0x50]  | stack[1152921513635793184] = ???;  stack[1152921513635793192] = ???;  //  dest_result_addr=1152921513635793184 |  dest_result_addr=1152921513635793192
            // 0x017BBE48: ADD x29, sp, #0x50         | X29 = (1152921513635793104 + 80) = 1152921513635793184 (0x100000021A2AC920);
            // 0x017BBE4C: SUB sp, sp, #0x10          | SP = (1152921513635793104 - 16) = 1152921513635793088 (0x100000021A2AC8C0);
            // 0x017BBE50: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BBE54: LDRB w8, [x19, #0x963]     | W8 = (bool)static_value_03738963;       
            // 0x017BBE58: MOV x20, x1                | X20 = data;//m1                         
            // 0x017BBE5C: TBNZ w8, #0, #0x17bbe78    | if (static_value_03738963 == true) goto label_0;
            // 0x017BBE60: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x017BBE64: LDR x8, [x8, #0xe28]       | X8 = 0x2B8B04C;                         
            // 0x017BBE68: LDR w0, [x8]               | W0 = 0x2D1;                             
            // 0x017BBE6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2D1, ????);      
            // 0x017BBE70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BBE74: STRB w8, [x19, #0x963]     | static_value_03738963 = true;            //  dest_result_addr=57903459
            label_0:
            // 0x017BBE78: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x017BBE7C: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x017BBE80: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x017BBE84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BBE88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBE8C: MOV x1, x20                | X1 = data;//m1                          
            // 0x017BBE90: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BBE94: BL #0x1e78658              | .ctor(buffer:  data);                   
            val_1 = new System.IO.MemoryStream(buffer:  data);
            // 0x017BBE98: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x017BBE9C: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x017BBEA0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x017BBEA4: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            // 0x017BBEA8: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x017BBEAC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BBEB0: MOV x20, x0                | X20 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBEB4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x017BBEB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BBEBC: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            System.IO.BinaryReader val_2 = null;
            // 0x017BBEC0: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BBEC4: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x017BBEC8: BL #0x1e664fc              | .ctor(input:  val_1);                   
            val_2 = new System.IO.BinaryReader(input:  val_1);
            // 0x017BBECC: CBNZ x20, #0x17bbed4       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x017BBED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_1), ????);
            label_1:
            // 0x017BBED4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBED8: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BBEDC: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BBEE0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBEE4: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BBEE8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBEEC: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BBEF0: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BBEF4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBEF8: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BBEFC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBF00: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBF04: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBF08: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF0C: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBF10: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBF14: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBF18: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBF1C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF20: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBF24: MOV w24, w0                | W24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF28: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBF2C: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBF30: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBF34: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF38: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBF3C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBF40: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBF44: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBF48: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF4C: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBF50: MOV w25, w0                | W25 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_5 = null;
            // 0x017BBF54: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBF58: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBF5C: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBF60: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF64: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBF68: STR w0, [sp, #0xc]         | stack[1152921513635793100] = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921513635793100
            // 0x017BBF6C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBF70: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBF74: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBF78: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF7C: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBF80: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x017BBF84: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x017BBF88: LDR x23, [x8]              | X23 = typeof(System.Int32[]);           
            // 0x017BBF8C: MOV x0, x23                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BBF90: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
            // 0x017BBF94: MOV w21, w24               | W21 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBF98: MOV x0, x23                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BBF9C: MOV x1, x21                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBFA0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
            // 0x017BBFA4: MOV x23, x0                | X23 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BBFA8: CMP w24, #1                | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BBFAC: B.LT #0x17bc00c            | if (null < 0x1) goto label_2;           
            if(null < 1)
            {
                goto label_2;
            }
            // 0x017BBFB0: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            // 0x017BBFB4: SXTW x28, w24              | X28 = 13844480 (0x00D34000);            
            // 0x017BBFB8: ADD x22, x23, #0x20        | X22 = (null + 32) = 1152921504962510864 (0x1000000015330010);
            label_6:
            // 0x017BBFBC: CBNZ x20, #0x17bbfc4       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x017BBFC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_3:
            // 0x017BBFC4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BBFC8: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BBFCC: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BBFD0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBFD4: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BBFD8: MOV w26, w0                | W26 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BBFDC: CBNZ x23, #0x17bbfe4       | if ( != null) goto label_4;             
            if(null != null)
            {
                goto label_4;
            }
            // 0x017BBFE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_4:
            // 0x017BBFE4: LDR w8, [x23, #0x18]       | W8 = System.Int32[].__il2cppRuntimeField_namespaze;
            // 0x017BBFE8: CMP x27, x8                | STATE = COMPARE(0x0, System.Int32[].__il2cppRuntimeField_namespaze)
            // 0x017BBFEC: B.LO #0x17bbffc            | if (0 < System.Int32[].__il2cppRuntimeField_namespaze) goto label_5;
            // 0x017BBFF0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BBFF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BBFF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryReader), ????);
            label_5:
            // 0x017BBFFC: STR w26, [x22, x27, lsl #2] | System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504962510864
            System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = null;
            // 0x017BC000: ADD x27, x27, #1           | X27 = (0 + 1);                          
            val_6 = 0 + 1;
            // 0x017BC004: CMP x27, x28               | STATE = COMPARE((0 + 1), 0xD34000)      
            // 0x017BC008: B.LT #0x17bbfbc            | if (val_6 < 13844480) goto label_6;     
            if(val_6 < 13844480)
            {
                goto label_6;
            }
            label_2:
            // 0x017BC00C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x017BC010: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
            // 0x017BC014: LDR x26, [x8]              | X26 = typeof(System.String[]);          
            // 0x017BC018: MOV x0, x26                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017BC01C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x017BC020: MOV x0, x26                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017BC024: MOV x1, x21                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_7 = null;
            // 0x017BC028: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x017BC02C: MOV x21, x0                | X21 = 1152921504948897168 (0x1000000014634590);//ML01
            val_8 = null;
            // 0x017BC030: CMP w24, #1                | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BC034: B.LT #0x17bc400            | if (null < 0x1) goto label_7;           
            if(null < 1)
            {
                goto label_7;
            }
            // 0x017BC038: AND w8, w25, #0x100        | W8 = (val_5 & 256) = 0 (0x00000000);    
            // 0x017BC03C: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x017BC040: STR w8, [sp, #8]           | stack[1152921513635793096] = 0x0;        //  dest_result_addr=1152921513635793096
            // 0x017BC044: SXTW x8, w24               | X8 = 13844480 (0x00D34000);             
            // 0x017BC048: ADD x28, x23, #0x20        | X28 = (null + 32) = 1152921504962510864 (0x1000000015330010);
            // 0x017BC04C: ADD x27, x21, #0x20        | X27 = (val_8 + 32) = val_6 (0x10000000146345B0);
            val_6 = 1152921504948897200;
            // 0x017BC050: STR x8, [sp]               | stack[1152921513635793088] = 0xD34000;   //  dest_result_addr=1152921513635793088
            label_50:
            // 0x017BC054: CBNZ x23, #0x17bc05c       | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x017BC058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_8:
            // 0x017BC05C: LDR w8, [x23, #0x18]       | W8 = System.Int32[].__il2cppRuntimeField_namespaze;
            // 0x017BC060: CMP x26, x8                | STATE = COMPARE(0x0, System.Int32[].__il2cppRuntimeField_namespaze)
            // 0x017BC064: B.LO #0x17bc074            | if (0 < System.Int32[].__il2cppRuntimeField_namespaze) goto label_9;
            // 0x017BC068: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.String[]), ????);
            // 0x017BC06C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x017BC070: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.String[]), ????);
            label_9:
            // 0x017BC074: LDR w22, [x28, x26, lsl #2] | W22 = typeof(System.IO.BinaryReader);   
            // 0x017BC078: CBNZ x20, #0x17bc080       | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x017BC07C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_10:
            // 0x017BC080: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC084: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x017BC088: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC08C: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x017BC090: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC094: CBNZ x24, #0x17bc09c       | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x017BC098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_11:
            // 0x017BC09C: LDR x8, [x24]              | X8 = ;                                  
            // 0x017BC0A0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BC0A4: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BC0A8: LDR w8, [sp, #0xc]         | W8 = typeof(System.IO.BinaryReader);    
            // 0x017BC0AC: ADD w8, w22, w8            | W8 = (System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 + null) = 2305843009241382912 (0x2000000001A68000);
            // 0x017BC0B0: SXTW x1, w8                | X1 = 27688960 (0x01A68000);             
            val_9 = 27688960;
            // 0x017BC0B4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC0B8: MOV x0, x24                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC0BC: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BC0C0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BC0C4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BC0C8: LDR x0, [x8]               | X0 = typeof(System.String);             
            val_10 = null;
            // 0x017BC0CC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BC0D0: TBZ w8, #0, #0x17bc0ec     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x017BC0D4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BC0D8: CBNZ w8, #0x17bc0ec        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x017BC0DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017BC0E0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BC0E4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BC0E8: LDR x0, [x8]               | X0 = typeof(System.String);             
            val_10 = null;
            label_13:
            // 0x017BC0EC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BC0F0: LDR x24, [x8]              | X24 = System.String.Empty;              
            // 0x017BC0F4: CBNZ x21, #0x17bc0fc       | if ( != null) goto label_14;            
            if(null != null)
            {
                goto label_14;
            }
            // 0x017BC0F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_14:
            // 0x017BC0FC: CBZ x24, #0x17bc120        | if (System.String.Empty == null) goto label_16;
            if(System.String.Empty == null)
            {
                goto label_16;
            }
            // 0x017BC100: LDR x8, [x21]              | X8 = ;                                  
            // 0x017BC104: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            val_9 = mem[null + 48];
            // 0x017BC108: MOV x0, x24                | X0 = System.String.Empty;//m1           
            // 0x017BC10C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x017BC110: CBNZ x0, #0x17bc120        | if (System.String.Empty != null) goto label_16;
            if(System.String.Empty != null)
            {
                goto label_16;
            }
            // 0x017BC114: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x017BC118: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x017BC11C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_16:
            // 0x017BC120: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017BC124: CMP x26, x8                | STATE = COMPARE(0x0, System.String[].__il2cppRuntimeField_namespaze)
            // 0x017BC128: B.LO #0x17bc138            | if (0 < System.String[].__il2cppRuntimeField_namespaze) goto label_17;
            // 0x017BC12C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x017BC130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x017BC134: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_17:
            // 0x017BC138: LDR w8, [sp, #8]           | W8 = 0x0;                               
            // 0x017BC13C: STR x24, [x27, x26, lsl #3] | System.String[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = System.String.Empty;  //  dest_result_addr=1152921504948897200
            System.String[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = System.String.Empty;
            // 0x017BC140: CBNZ w8, #0x17bc24c        | if (0x464C457F != 0) goto label_18;     
            if(1179403647 != 0)
            {
                goto label_18;
            }
            // 0x017BC144: CBNZ x20, #0x17bc14c       | if ( != 0) goto label_19;               
            if(null != 0)
            {
                goto label_19;
            }
            // 0x017BC148: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.String.Empty, ????);
            label_19:
            // 0x017BC14C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC150: LDR x1, [x8, #0x298]       |  //  not_find_field!1:664
            // 0x017BC154: LDR x9, [x8, #0x290]       |  //  not_find_field!1:656
            // 0x017BC158: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC15C: BLR x9                     | X0 = mem[null + 656]();                 
            // 0x017BC160: AND w25, w0, #0xffff       | W25 = (null & 65535) = val_5 (0x00004000);
            val_5 = 16384;
            // 0x017BC164: TBZ w0, #0xf, #0x17bc188   | if ((typeof(System.IO.BinaryReader) & 0x8000) == 0) goto label_20;
            if((null & 32768) == 0)
            {
                goto label_20;
            }
            // 0x017BC168: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC16C: LDR x1, [x8, #0x298]       |  //  not_find_field!1:664
            // 0x017BC170: LDR x9, [x8, #0x290]       |  //  not_find_field!1:656
            // 0x017BC174: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC178: BLR x9                     | X0 = mem[null + 656]();                 
            // 0x017BC17C: AND w8, w0, #0xffff        | W8 = (null & 65535) = 16384 (0x00004000);
            // 0x017BC180: BFI w8, w25, #0x10, #0xf   | W8 = 16384 | 0                          
            // 0x017BC184: MOV w25, w8                | W25 = 16384 (0x4000);//ML01             
            val_5 = 16384;
            label_20:
            // 0x017BC188: CMP w25, #1                | STATE = COMPARE(0x4000, 0x1)            
            // 0x017BC18C: B.LT #0x17bc3f0            | if (val_5 < 0x1) goto label_21;         
            if(val_5 < 1)
            {
                goto label_21;
            }
            // 0x017BC190: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x017BC194: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x017BC198: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x017BC19C: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x017BC1A0: TBZ w8, #0, #0x17bc1b0     | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x017BC1A4: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x017BC1A8: CBNZ w8, #0x17bc1b0        | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x017BC1AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_23:
            // 0x017BC1B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BC1B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC1B8: BL #0x1b56974              | X0 = System.Text.Encoding.get_Unicode();
            System.Text.Encoding val_3 = System.Text.Encoding.Unicode;
            // 0x017BC1BC: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x017BC1C0: CBNZ x20, #0x17bc1c8       | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x017BC1C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_24:
            // 0x017BC1C8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC1CC: LSL w1, w25, #1            | W1 = (val_5 << 1) = 0 (0x00000000);     
            // 0x017BC1D0: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BC1D4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC1D8: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BC1DC: MOV x25, x0                | X25 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_5 = null;
            // 0x017BC1E0: CBNZ x24, #0x17bc1e8       | if (val_3 != null) goto label_25;       
            if(val_3 != null)
            {
                goto label_25;
            }
            // 0x017BC1E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_25:
            // 0x017BC1E8: LDR x8, [x24]              | X8 = typeof(System.Text.Encoding);      
            // 0x017BC1EC: LDR x9, [x8, #0x2c0]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C0;
            // 0x017BC1F0: LDR x2, [x8, #0x2c8]       | X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C8;
            // 0x017BC1F4: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x017BC1F8: MOV x1, x25                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC1FC: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C0();
            // 0x017BC200: MOV x24, x0                | X24 = val_3;//m1                        
            val_11 = val_3;
            // 0x017BC204: CBNZ x21, #0x17bc20c       | if ( != null) goto label_26;            
            if(null != null)
            {
                goto label_26;
            }
            // 0x017BC208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_26:
            // 0x017BC20C: CBZ x24, #0x17bc230        | if (val_3 == null) goto label_28;       
            if(val_11 == null)
            {
                goto label_28;
            }
            // 0x017BC210: LDR x8, [x21]              | X8 = ;                                  
            // 0x017BC214: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017BC218: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x017BC21C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x017BC220: CBNZ x0, #0x17bc230        | if (val_3 != null) goto label_28;       
            if(val_11 != null)
            {
                goto label_28;
            }
            // 0x017BC224: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x017BC228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC22C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_28:
            // 0x017BC230: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017BC234: CMP x26, x8                | STATE = COMPARE(0x0, System.String[].__il2cppRuntimeField_namespaze)
            // 0x017BC238: B.LO #0x17bc3ec            | if (0 < System.String[].__il2cppRuntimeField_namespaze) goto label_49;
            // 0x017BC23C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x017BC240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC244: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x017BC248: B #0x17bc3ec               |  goto label_49;                         
            goto label_49;
            label_18:
            // 0x017BC24C: CBNZ x20, #0x17bc254       | if ( != 0) goto label_31;               
            if(null != 0)
            {
                goto label_31;
            }
            // 0x017BC250: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.String.Empty, ????);
            label_31:
            // 0x017BC254: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC258: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            val_12 = mem[null + 480 + 8];
            // 0x017BC25C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC260: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BC264: SXTB w8, w0                | W8 = 0 (0x0);                           
            // 0x017BC268: TBZ w8, #0x1f, #0x17bc27c  | if ((0x0 & 0x80000000) == 0) goto label_32;
            if((0 & 2147483648) == 0)
            {
                goto label_32;
            }
            // 0x017BC26C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC270: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            val_12 = mem[null + 480 + 8];
            // 0x017BC274: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC278: BLR x9                     | X0 = mem[null + 480]();                 
            label_32:
            // 0x017BC27C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC280: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BC284: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC288: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BC28C: AND w24, w0, #0xff         | W24 = (null & 255) = val_13 (0x00000000);
            val_13 = 0;
            // 0x017BC290: TBZ w0, #7, #0x17bc2b0     | if ((typeof(System.IO.BinaryReader) & 0x80) == 0) goto label_33;
            if((null & 128) == 0)
            {
                goto label_33;
            }
            // 0x017BC294: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC298: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BC29C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC2A0: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BC2A4: AND w8, w0, #0xff          | W8 = (null & 255) = 0 (0x00000000);     
            // 0x017BC2A8: BFI w8, w24, #8, #7        | W8 = 0 | val_13                         
            // 0x017BC2AC: MOV w24, w8                | W24 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_33:
            // 0x017BC2B0: CMP w24, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x017BC2B4: B.LT #0x17bc374            | if (val_13 < 0x1) goto label_34;        
            if(val_13 < 1)
            {
                goto label_34;
            }
            // 0x017BC2B8: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x017BC2BC: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x017BC2C0: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x017BC2C4: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x017BC2C8: TBZ w8, #0, #0x17bc2d8     | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x017BC2CC: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x017BC2D0: CBNZ w8, #0x17bc2d8        | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x017BC2D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_36:
            // 0x017BC2D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BC2DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC2E0: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_4 = System.Text.Encoding.UTF8;
            // 0x017BC2E4: MOV x25, x0                | X25 = val_4;//m1                        
            val_5 = val_4;
            // 0x017BC2E8: CBNZ x20, #0x17bc2f0       | if ( != 0) goto label_37;               
            if(null != 0)
            {
                goto label_37;
            }
            // 0x017BC2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_37:
            // 0x017BC2F0: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BC2F4: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x017BC2F8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC2FC: MOV w1, w24                | W1 = 0 (0x0);//ML01                     
            // 0x017BC300: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x017BC304: MOV x24, x0                | X24 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC308: CBNZ x25, #0x17bc310       | if (val_4 != null) goto label_38;       
            if(val_5 != null)
            {
                goto label_38;
            }
            // 0x017BC30C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_38:
            // 0x017BC310: LDR x8, [x25]              | X8 = typeof(System.Text.Encoding);      
            // 0x017BC314: LDR x9, [x8, #0x2c0]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C0;
            // 0x017BC318: LDR x2, [x8, #0x2c8]       | X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C8;
            // 0x017BC31C: MOV x0, x25                | X0 = val_4;//m1                         
            // 0x017BC320: MOV x1, x24                | X1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC324: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C0();
            // 0x017BC328: MOV x24, x0                | X24 = val_4;//m1                        
            val_11 = val_5;
            // 0x017BC32C: CBNZ x21, #0x17bc334       | if ( != null) goto label_39;            
            if(null != null)
            {
                goto label_39;
            }
            // 0x017BC330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_39:
            // 0x017BC334: CBZ x24, #0x17bc358        | if (val_4 == null) goto label_41;       
            if(val_11 == null)
            {
                goto label_41;
            }
            // 0x017BC338: LDR x8, [x21]              | X8 = ;                                  
            // 0x017BC33C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017BC340: MOV x0, x24                | X0 = val_4;//m1                         
            // 0x017BC344: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x017BC348: CBNZ x0, #0x17bc358        | if (val_4 != null) goto label_41;       
            if(val_11 != null)
            {
                goto label_41;
            }
            // 0x017BC34C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x017BC350: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC354: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_41:
            // 0x017BC358: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017BC35C: CMP x26, x8                | STATE = COMPARE(0x0, System.String[].__il2cppRuntimeField_namespaze)
            // 0x017BC360: B.LO #0x17bc3ec            | if (0 < System.String[].__il2cppRuntimeField_namespaze) goto label_49;
            // 0x017BC364: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x017BC368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC36C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x017BC370: B #0x17bc3ec               |  goto label_49;                         
            goto label_49;
            label_34:
            // 0x017BC374: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BC378: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BC37C: LDR x0, [x8]               | X0 = typeof(System.String);             
            val_14 = null;
            // 0x017BC380: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BC384: TBZ w8, #0, #0x17bc3a0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x017BC388: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BC38C: CBNZ w8, #0x17bc3a0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x017BC390: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017BC394: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BC398: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BC39C: LDR x0, [x8]               | X0 = typeof(System.String);             
            val_14 = null;
            label_45:
            // 0x017BC3A0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BC3A4: LDR x24, [x8]              | X24 = System.String.Empty;              
            val_11 = System.String.Empty;
            // 0x017BC3A8: CBNZ x21, #0x17bc3b0       | if ( != null) goto label_46;            
            if(null != null)
            {
                goto label_46;
            }
            // 0x017BC3AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_46:
            // 0x017BC3B0: CBZ x24, #0x17bc3d4        | if (System.String.Empty == null) goto label_48;
            if(val_11 == null)
            {
                goto label_48;
            }
            // 0x017BC3B4: LDR x8, [x21]              | X8 = ;                                  
            // 0x017BC3B8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017BC3BC: MOV x0, x24                | X0 = System.String.Empty;//m1           
            // 0x017BC3C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x017BC3C4: CBNZ x0, #0x17bc3d4        | if (System.String.Empty != null) goto label_48;
            if(val_11 != null)
            {
                goto label_48;
            }
            // 0x017BC3C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x017BC3CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC3D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_48:
            // 0x017BC3D4: LDR w8, [x21, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017BC3D8: CMP x26, x8                | STATE = COMPARE(0x0, System.String[].__il2cppRuntimeField_namespaze)
            // 0x017BC3DC: B.LO #0x17bc3ec            | if (0 < System.String[].__il2cppRuntimeField_namespaze) goto label_49;
            // 0x017BC3E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x017BC3E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC3E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_49:
            // 0x017BC3EC: STR x24, [x27, x26, lsl #3] | System.String[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = System.String.Empty;  //  dest_result_addr=1152921504948897200
            System.String[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_11;
            label_21:
            // 0x017BC3F0: LDR x8, [sp]               | X8 = 0xD34000;                          
            // 0x017BC3F4: ADD x26, x26, #1           | X26 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x017BC3F8: CMP x26, x8                | STATE = COMPARE((0 + 1), 0xD34000)      
            // 0x017BC3FC: B.LT #0x17bc054            | if (0 < 13844480) goto label_50;        
            if(val_5 < 13844480)
            {
                goto label_50;
            }
            label_7:
            // 0x017BC400: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x017BC404: ORR w23, wzr, #0x1c0       | W23 = 448(0x1C0);                       
            val_16 = 448;
            // 0x017BC408: B #0x17bc42c               |  goto label_51;                         
            goto label_51;
            // 0x017BC40C: B #0x17bc410               |  goto label_69;                         
            goto label_69;
            label_69:
            // 0x017BC410: CMP w1, #1                 | STATE = COMPARE(0x0, 0x1)               
            // 0x017BC414: B.NE #0x17bc480            | if (0 != 0x1) goto label_53;            
            if(0 != 1)
            {
                goto label_53;
            }
            // 0x017BC418: BL #0x981060               | X0 = sub_981060( ?? System.String.Empty, ????);
            // 0x017BC41C: LDR x22, [x0]              | X22 =  typeof(System.String);           
            // 0x017BC420: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x017BC424: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x017BC428: BL #0x980920               | X0 = sub_980920( ?? System.String.Empty, ????);
            label_51:
            // 0x017BC42C: CBZ x20, #0x17bc4b0        | if ( == 0) goto label_54;               
            if(null == 0)
            {
                goto label_54;
            }
            // 0x017BC430: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BC434: LDR x8, [x20]              | X8 = ;                                  
            System.IO.BinaryReader val_8 = null;
            // 0x017BC438: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BC43C: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BC440: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BC444: CBZ x9, #0x17bc470         | if (mem[null + 258] == 0) goto label_55;
            if((mem[null + 258]) == 0)
            {
                goto label_55;
            }
            // 0x017BC448: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_6 = mem[null + 152];
            // 0x017BC44C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x017BC450: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_6 = val_6 + 8;
            label_57:
            // 0x017BC454: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BC458: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BC45C: B.EQ #0x17bc498            | if ((mem[null + 152] + 8) + -8 == null) goto label_56;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_56;
            }
            // 0x017BC460: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x017BC464: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_6 = val_6 + 16;
            // 0x017BC468: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BC46C: B.LO #0x17bc454            | if (0 < mem[null + 258]) goto label_57; 
            if(val_7 < (mem[null + 258]))
            {
                goto label_57;
            }
            label_55:
            // 0x017BC470: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC474: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_17 = null;
            // 0x017BC478: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BC47C: B #0x17bc4a4               |  goto label_58;                         
            goto label_58;
            label_53:
            // 0x017BC480: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x017BC484: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_70:
            // 0x017BC488: BL #0x981060               | X0 = sub_981060( ?? System.String.Empty, ????);
            // 0x017BC48C: LDR x22, [x0]              | X22 =  typeof(System.String);           
            // 0x017BC490: BL #0x980920               | X0 = sub_980920( ?? System.String.Empty, ????);
            // 0x017BC494: B #0x17bc4cc               |  goto label_61;                         
            goto label_61;
            label_56:
            // 0x017BC498: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BC49C: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_8 = val_8 + (((mem[null + 152] + 8)) << 4);
            // 0x017BC4A0: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_58:
            // 0x017BC4A4: LDP x8, x1, [x0]           | X8 =  typeof(System.String); X1 = System.String.Empty + 8; //  |  not_find_field!2:8
            // 0x017BC4A8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BC4AC: BLR x8                     | X0 = Empty( ?? typeof(System.IO.BinaryReader), ????);
            label_54:
            // 0x017BC4B0: CMP w23, #0x1c0            | STATE = COMPARE(0x0, 0x1C0)             
            // 0x017BC4B4: B.EQ #0x17bc4cc            | if (val_16 == 0x1C0) goto label_61;     
            if(val_16 == 448)
            {
                goto label_61;
            }
            // 0x017BC4B8: CBZ x22, #0x17bc4cc        | if (null == 0) goto label_61;           
            if(null == 0)
            {
                goto label_61;
            }
            // 0x017BC4BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC4C0: MOV x0, x22                | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x017BC4C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? Empty, ????);      
            // 0x017BC4C8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_61:
            // 0x017BC4CC: CBZ x19, #0x17bc538        | if ( == 0) goto label_62;               
            if(null == 0)
            {
                goto label_62;
            }
            // 0x017BC4D0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BC4D4: LDR x8, [x19]              | X8 = ;                                  
            System.IO.MemoryStream val_11 = null;
            // 0x017BC4D8: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BC4DC: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BC4E0: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BC4E4: CBZ x9, #0x17bc510         | if (mem[null + 258] == 0) goto label_63;
            if((mem[null + 258]) == 0)
            {
                goto label_63;
            }
            // 0x017BC4E8: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_9 = mem[null + 152];
            // 0x017BC4EC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x017BC4F0: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_9 = val_9 + 8;
            label_65:
            // 0x017BC4F4: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BC4F8: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BC4FC: B.EQ #0x17bc520            | if ((mem[null + 152] + 8) + -8 == null) goto label_64;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_64;
            }
            // 0x017BC500: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x017BC504: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_9 = val_9 + 16;
            // 0x017BC508: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BC50C: B.LO #0x17bc4f4            | if (0 < mem[null + 258]) goto label_65; 
            if(val_10 < (mem[null + 258]))
            {
                goto label_65;
            }
            label_63:
            // 0x017BC510: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BC514: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_18 = val_1;
            // 0x017BC518: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BC51C: B #0x17bc52c               |  goto label_66;                         
            goto label_66;
            label_64:
            // 0x017BC520: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BC524: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_11 = val_11 + (((mem[null + 152] + 8)) << 4);
            // 0x017BC528: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_66:
            // 0x017BC52C: LDP x8, x1, [x0]           | X8 = null; X1 = System.String.__il2cppRuntimeField_gc_desc; //  | 
            // 0x017BC530: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BC534: BLR x8                     | X0 = x8();                              
            label_62:
            // 0x017BC538: CMP w23, #0x1c0            | STATE = COMPARE(0x0, 0x1C0)             
            // 0x017BC53C: B.EQ #0x17bc550            | if (val_16 == 0x1C0) goto label_68;     
            if(val_16 == 448)
            {
                goto label_68;
            }
            // 0x017BC540: CBZ x22, #0x17bc550        | if (0x0 == 0) goto label_68;            
            if(val_15 == 0)
            {
                goto label_68;
            }
            // 0x017BC544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BC548: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x017BC54C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_68:
            // 0x017BC550: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x017BC554: SUB sp, x29, #0x50         | SP = (1152921513635793184 - 80) = 1152921513635793104 (0x100000021A2AC8D0);
            // 0x017BC558: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x017BC55C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x017BC560: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x017BC564: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x017BC568: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x017BC56C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x017BC570: RET                        |  return (System.String[])null;          
            return (System.String[])val_8;
            //  |  // // {name=val_0, type=System.String[], size=8, nGRN=0 }
            // 0x017BC574: B #0x17bc410               | 
            // 0x017BC578: B #0x17bc488               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x017BCEFC (24891132), len: 796  VirtAddr: 0x017BCEFC RVA: 0x017BCEFC token: 100684434 methodIndex: 46004 delegateWrapperIndex: 0 methodInvoker: 0
        private void processTypeSpec(byte[] data)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            System.IO.Stream val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            System.IO.BinaryReader val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x017BCEFC: STP x26, x25, [sp, #-0x50]! | stack[1152921513635987040] = ???;  stack[1152921513635987048] = ???;  //  dest_result_addr=1152921513635987040 |  dest_result_addr=1152921513635987048
            // 0x017BCF00: STP x24, x23, [sp, #0x10]  | stack[1152921513635987056] = ???;  stack[1152921513635987064] = ???;  //  dest_result_addr=1152921513635987056 |  dest_result_addr=1152921513635987064
            // 0x017BCF04: STP x22, x21, [sp, #0x20]  | stack[1152921513635987072] = ???;  stack[1152921513635987080] = ???;  //  dest_result_addr=1152921513635987072 |  dest_result_addr=1152921513635987080
            // 0x017BCF08: STP x20, x19, [sp, #0x30]  | stack[1152921513635987088] = ???;  stack[1152921513635987096] = ???;  //  dest_result_addr=1152921513635987088 |  dest_result_addr=1152921513635987096
            // 0x017BCF0C: STP x29, x30, [sp, #0x40]  | stack[1152921513635987104] = ???;  stack[1152921513635987112] = ???;  //  dest_result_addr=1152921513635987104 |  dest_result_addr=1152921513635987112
            // 0x017BCF10: ADD x29, sp, #0x40         | X29 = (1152921513635987040 + 64) = 1152921513635987104 (0x100000021A2DBEA0);
            // 0x017BCF14: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BCF18: LDRB w8, [x19, #0x964]     | W8 = (bool)static_value_03738964;       
            // 0x017BCF1C: MOV x20, x1                | X20 = data;//m1                         
            // 0x017BCF20: TBNZ w8, #0, #0x17bcf3c    | if (static_value_03738964 == true) goto label_0;
            // 0x017BCF24: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x017BCF28: LDR x8, [x8, #0xed0]       | X8 = 0x2B8B054;                         
            // 0x017BCF2C: LDR w0, [x8]               | W0 = 0x2D3;                             
            // 0x017BCF30: BL #0x2782188              | X0 = sub_2782188( ?? 0x2D3, ????);      
            // 0x017BCF34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BCF38: STRB w8, [x19, #0x964]     | static_value_03738964 = true;            //  dest_result_addr=57903460
            label_0:
            // 0x017BCF3C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x017BCF40: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x017BCF44: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x017BCF48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BCF4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BCF50: MOV x1, x20                | X1 = data;//m1                          
            // 0x017BCF54: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_13 = val_1;
            // 0x017BCF58: BL #0x1e78658              | .ctor(buffer:  data);                   
            val_1 = new System.IO.MemoryStream(buffer:  data);
            // 0x017BCF5C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x017BCF60: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x017BCF64: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            // 0x017BCF68: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x017BCF6C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BCF70: MOV x20, x0                | X20 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCF74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BCF78: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            System.IO.BinaryReader val_2 = null;
            // 0x017BCF7C: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BCF80: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x017BCF84: BL #0x1e664fc              | .ctor(input:  val_13);                  
            val_2 = new System.IO.BinaryReader(input:  val_13);
            // 0x017BCF88: CBNZ x20, #0x17bcf90       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x017BCF8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_13), ????);
            label_1:
            // 0x017BCF90: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCF94: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BCF98: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BCF9C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCFA0: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BCFA4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCFA8: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BCFAC: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BCFB0: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCFB4: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BCFB8: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCFBC: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BCFC0: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BCFC4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCFC8: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BCFCC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCFD0: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BCFD4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCFD8: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BCFDC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCFE0: LDP x9, x1, [x8, #0x1e0]   |                                          //  not_find_field!1:480 |  not_find_field!1:488
            // 0x017BCFE4: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCFE8: BLR x9                     | X0 = mem[null + 480]();                 
            // 0x017BCFEC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BCFF0: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x017BCFF4: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x017BCFF8: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BCFFC: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x017BD000: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD004: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD008: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD00C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD010: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD014: MOV w22, w0                | W22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD018: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x017BD01C: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x017BD020: LDR x21, [x8]              | X21 = typeof(System.Int32[]);           
            // 0x017BD024: MOV x0, x21                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BD028: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
            // 0x017BD02C: MOV w1, w22                | W1 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD030: MOV x0, x21                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BD034: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
            // 0x017BD038: MOV x21, x0                | X21 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x017BD03C: CMP w22, #1                | STATE = COMPARE(typeof(System.IO.BinaryReader), 0x1)
            // 0x017BD040: B.LT #0x17bd0a0            | if (null < 0x1) goto label_2;           
            if(null < 1)
            {
                goto label_2;
            }
            // 0x017BD044: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            // 0x017BD048: SXTW x24, w22              | X24 = 13844480 (0x00D34000);            
            // 0x017BD04C: ADD x25, x21, #0x20        | X25 = (null + 32) = val_14 (0x1000000015330010);
            val_14 = 1152921504962510864;
            label_6:
            // 0x017BD050: CBNZ x20, #0x17bd058       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x017BD054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_3:
            // 0x017BD058: LDR x8, [x20]              | X8 = ;                                  
            // 0x017BD05C: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x017BD060: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x017BD064: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD068: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x017BD06C: MOV w22, w0                | W22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD070: CBNZ x21, #0x17bd078       | if ( != null) goto label_4;             
            if(null != null)
            {
                goto label_4;
            }
            // 0x017BD074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_4:
            // 0x017BD078: LDR w8, [x21, #0x18]       | W8 = System.Int32[].__il2cppRuntimeField_namespaze;
            // 0x017BD07C: CMP x23, x8                | STATE = COMPARE(0x0, System.Int32[].__il2cppRuntimeField_namespaze)
            // 0x017BD080: B.LO #0x17bd090            | if (0 < System.Int32[].__il2cppRuntimeField_namespaze) goto label_5;
            // 0x017BD084: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BD08C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryReader), ????);
            label_5:
            // 0x017BD090: STR w22, [x25, x23, lsl #2] | System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504962510864
            System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = null;
            // 0x017BD094: ADD x23, x23, #1           | X23 = (0 + 1);                          
            val_15 = 0 + 1;
            // 0x017BD098: CMP x23, x24               | STATE = COMPARE((0 + 1), 0xD34000)      
            // 0x017BD09C: B.LT #0x17bd050            | if (val_15 < 13844480) goto label_6;    
            if(val_15 < 13844480)
            {
                goto label_6;
            }
            label_2:
            // 0x017BD0A0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x017BD0A4: MOVZ w22, #0x8e            | W22 = 142 (0x8E);//ML01                 
            val_17 = 142;
            // 0x017BD0A8: B #0x17bd0c4               |  goto label_7;                          
            goto label_7;
            label_24:
            // 0x017BD0AC: CMP w1, #1                 | STATE = COMPARE(0x0, 0x1)               
            // 0x017BD0B0: B.NE #0x17bd118            | if (0 != 0x1) goto label_8;             
            if(0 != 1)
            {
                goto label_8;
            }
            // 0x017BD0B4: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD0B8: LDR x21, [x0]              | X21 = ;                                 
            val_16 = null;
            // 0x017BD0BC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x017BD0C0: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.BinaryReader), ????);
            label_7:
            // 0x017BD0C4: CBZ x20, #0x17bd144        | if ( == 0) goto label_9;                
            if(null == 0)
            {
                goto label_9;
            }
            // 0x017BD0C8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BD0CC: LDR x8, [x20]              | X8 = ;                                  
            System.IO.BinaryReader val_15 = null;
            // 0x017BD0D0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BD0D4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BD0D8: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BD0DC: CBZ x9, #0x17bd108         | if (mem[null + 258] == 0) goto label_10;
            if((mem[null + 258]) == 0)
            {
                goto label_10;
            }
            // 0x017BD0E0: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_13 = mem[null + 152];
            // 0x017BD0E4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x017BD0E8: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_13 = val_13 + 8;
            label_12:
            // 0x017BD0EC: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BD0F0: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BD0F4: B.EQ #0x17bd12c            | if ((mem[null + 152] + 8) + -8 == null) goto label_11;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_11;
            }
            // 0x017BD0F8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x017BD0FC: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_13 = val_13 + 16;
            // 0x017BD100: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BD104: B.LO #0x17bd0ec            | if (0 < mem[null + 258]) goto label_12; 
            if(val_14 < (mem[null + 258]))
            {
                goto label_12;
            }
            label_10:
            // 0x017BD108: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BD10C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_18 = null;
            // 0x017BD110: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD114: B #0x17bd138               |  goto label_13;                         
            goto label_13;
            label_8:
            // 0x017BD118: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_25:
            // 0x017BD11C: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD120: LDR x21, [x0]              | X21 = ;                                 
            val_16 = null;
            // 0x017BD124: BL #0x980920               | X0 = sub_980920( ?? typeof(System.IO.BinaryReader), ????);
            // 0x017BD128: B #0x17bd160               |  goto label_16;                         
            goto label_16;
            label_11:
            // 0x017BD12C: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BD130: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_15 = val_15 + (((mem[null + 152] + 8)) << 4);
            // 0x017BD134: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_13:
            // 0x017BD138: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.BinaryReader.__il2cppRuntimeField_gc_desc; //  | 
            // 0x017BD13C: MOV x0, x20                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x017BD140: BLR x8                     | X0 = x8();                              
            label_9:
            // 0x017BD144: CMP w22, #0x8e             | STATE = COMPARE(0x0, 0x8E)              
            // 0x017BD148: B.EQ #0x17bd160            | if (val_17 == 0x8E) goto label_16;      
            if(val_17 == 142)
            {
                goto label_16;
            }
            // 0x017BD14C: CBZ x21, #0x17bd160        | if ( == 0) goto label_16;               
            if(val_16 == 0)
            {
                goto label_16;
            }
            // 0x017BD150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BD154: MOV x0, x21                | X0 = X21;//m1                           
            // 0x017BD158: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            // 0x017BD15C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_16:
            // 0x017BD160: CBZ x19, #0x17bd1cc        | if ( == 0) goto label_17;               
            if(null == 0)
            {
                goto label_17;
            }
            // 0x017BD164: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x017BD168: LDR x8, [x19]              | X8 = ;                                  
            System.IO.MemoryStream val_18 = null;
            // 0x017BD16C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x017BD170: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x017BD174: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x017BD178: CBZ x9, #0x17bd1a4         | if (mem[null + 258] == 0) goto label_18;
            if((mem[null + 258]) == 0)
            {
                goto label_18;
            }
            // 0x017BD17C: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_16 = mem[null + 152];
            // 0x017BD180: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_17 = 0;
            // 0x017BD184: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_16 = val_16 + 8;
            label_20:
            // 0x017BD188: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x017BD18C: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x017BD190: B.EQ #0x17bd1b4            | if ((mem[null + 152] + 8) + -8 == null) goto label_19;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_19;
            }
            // 0x017BD194: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_17 = val_17 + 1;
            // 0x017BD198: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_16 = val_16 + 16;
            // 0x017BD19C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x017BD1A0: B.LO #0x17bd188            | if (0 < mem[null + 258]) goto label_20; 
            if(val_17 < (mem[null + 258]))
            {
                goto label_20;
            }
            label_18:
            // 0x017BD1A4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x017BD1A8: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_19 = val_13;
            // 0x017BD1AC: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.MemoryStream), ????);
            // 0x017BD1B0: B #0x17bd1c0               |  goto label_21;                         
            goto label_21;
            label_19:
            // 0x017BD1B4: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x017BD1B8: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_18 = val_18 + (((mem[null + 152] + 8)) << 4);
            // 0x017BD1BC: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_21:
            // 0x017BD1C0: LDP x8, x1, [x0]           |                                          //  not_find_field!1:0 |  not_find_field!1:8
            // 0x017BD1C4: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x017BD1C8: BLR x8                     | X0 = mem[val_16]();                     
            label_17:
            // 0x017BD1CC: CMP w22, #0x8e             | STATE = COMPARE(0x0, 0x8E)              
            // 0x017BD1D0: B.EQ #0x17bd1f8            | if (val_17 == 0x8E) goto label_23;      
            if(val_17 == 142)
            {
                goto label_23;
            }
            // 0x017BD1D4: CBZ x21, #0x17bd1f8        | if (0x0 == 0) goto label_23;            
            if(val_16 == 0)
            {
                goto label_23;
            }
            // 0x017BD1D8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x017BD1DC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x017BD1E0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            val_13 = ???;
            // 0x017BD1E4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            val_16 = ???;
            // 0x017BD1E8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            val_15 = ???;
            // 0x017BD1EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BD1F0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            val_14 = ???;
            // 0x017BD1F4: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_23:
            // 0x017BD1F8: LDP x29, x30, [sp, #0x40]  | X29 = val_3; X30 = val_4;                //  find_add[1152921513635975120] |  find_add[1152921513635975120]
            // 0x017BD1FC: LDP x20, x19, [sp, #0x30]  | X20 = val_5; X19 = val_6;                //  find_add[1152921513635975120] |  find_add[1152921513635975120]
            // 0x017BD200: LDP x22, x21, [sp, #0x20]  | X22 = val_7; X21 = val_8;                //  find_add[1152921513635975120] |  find_add[1152921513635975120]
            // 0x017BD204: LDP x24, x23, [sp, #0x10]  | X24 = val_9; X23 = val_10;               //  find_add[1152921513635975120] |  find_add[1152921513635975120]
            // 0x017BD208: LDP x26, x25, [sp], #0x50  | X26 = val_11; X25 = val_12;              //  find_add[1152921513635975120] |  find_add[1152921513635975120]
            // 0x017BD20C: RET                        |  return;                                
            return;
            // 0x017BD210: B #0x17bd0ac               | 
            // 0x017BD214: B #0x17bd11c               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x017BE13C (24895804), len: 176  VirtAddr: 0x017BE13C RVA: 0x017BE13C token: 100684435 methodIndex: 46005 delegateWrapperIndex: 0 methodInvoker: 0
        private static ApkResourceFinder()
        {
            //
            // Disasemble & Code
            // 0x017BE13C: STP x20, x19, [sp, #-0x20]! | stack[1152921513636135952] = ???;  stack[1152921513636135960] = ???;  //  dest_result_addr=1152921513636135952 |  dest_result_addr=1152921513636135960
            // 0x017BE140: STP x29, x30, [sp, #0x10]  | stack[1152921513636135968] = ???;  stack[1152921513636135976] = ???;  //  dest_result_addr=1152921513636135968 |  dest_result_addr=1152921513636135976
            // 0x017BE144: ADD x29, sp, #0x10         | X29 = (1152921513636135952 + 16) = 1152921513636135968 (0x100000021A300420);
            // 0x017BE148: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BE14C: LDRB w8, [x19, #0x965]     | W8 = (bool)static_value_03738965;       
            // 0x017BE150: TBNZ w8, #0, #0x17be16c    | if (static_value_03738965 == true) goto label_0;
            // 0x017BE154: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x017BE158: LDR x8, [x8, #0x248]       | X8 = 0x2B8B038;                         
            // 0x017BE15C: LDR w0, [x8]               | W0 = 0x2CC;                             
            // 0x017BE160: BL #0x2782188              | X0 = sub_2782188( ?? 0x2CC, ????);      
            // 0x017BE164: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BE168: STRB w8, [x19, #0x965]     | static_value_03738965 = true;            //  dest_result_addr=57903461
            label_0:
            // 0x017BE16C: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x017BE170: LDR x8, [x8, #0x670]       | X8 = 1152921504856686592;               
            // 0x017BE174: ORR w10, wzr, #1           | W10 = 1(0x1);                           
            // 0x017BE178: ORR w11, wzr, #2           | W11 = 2(0x2);                           
            // 0x017BE17C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE180: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE184: STRH w10, [x9]             | Iteedee.ApkReader.ApkResourceFinder.RES_STRING_POOL_TYPE = 1;  //  dest_result_addr=1152921504856690688
            Iteedee.ApkReader.ApkResourceFinder.RES_STRING_POOL_TYPE = 1;
            // 0x017BE188: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE18C: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE190: STRH w11, [x9, #2]         | Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE = 2;  //  dest_result_addr=1152921504856690690
            Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE = 2;
            // 0x017BE194: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE198: ORR w11, wzr, #0x200       | W11 = 512(0x200);                       
            // 0x017BE19C: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE1A0: STRH w11, [x9, #4]         | Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_PACKAGE_TYPE = 512;  //  dest_result_addr=1152921504856690692
            Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_PACKAGE_TYPE = 512;
            // 0x017BE1A4: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE1A8: MOVZ w11, #0x201           | W11 = 513 (0x201);//ML01                
            // 0x017BE1AC: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE1B0: STRH w11, [x9, #6]         | Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_TYPE = 513;  //  dest_result_addr=1152921504856690694
            Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_TYPE = 513;
            // 0x017BE1B4: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE1B8: MOVZ w11, #0x202           | W11 = 514 (0x202);//ML01                
            // 0x017BE1BC: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE1C0: STRH w11, [x9, #8]         | Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_SPEC_TYPE = 514;  //  dest_result_addr=1152921504856690696
            Iteedee.ApkReader.ApkResourceFinder.RES_TABLE_TYPE_SPEC_TYPE = 514;
            // 0x017BE1C4: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE1C8: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE1CC: STRB w10, [x9, #0xa]       | Iteedee.ApkReader.ApkResourceFinder.TYPE_REFERENCE = 1;  //  dest_result_addr=1152921504856690698
            Iteedee.ApkReader.ApkResourceFinder.TYPE_REFERENCE = 1;
            // 0x017BE1D0: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BE1D4: ORR w9, wzr, #3            | W9 = 3(0x3);                            
            // 0x017BE1D8: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkResourceFinder.__il2cppRuntimeField_static_fields;
            // 0x017BE1DC: STRB w9, [x8, #0xb]        | Iteedee.ApkReader.ApkResourceFinder.TYPE_STRING = 3;  //  dest_result_addr=1152921504856690699
            Iteedee.ApkReader.ApkResourceFinder.TYPE_STRING = 3;
            // 0x017BE1E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017BE1E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017BE1E8: RET                        |  return;                                
            return;
        
        }
    
    }

}
