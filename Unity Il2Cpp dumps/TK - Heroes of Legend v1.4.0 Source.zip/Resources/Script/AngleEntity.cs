using UnityEngine;
public class TargetMgr.AngleEntity
{
    // Fields
    public float angle; //  0x00000010
    public bool IsNull; //  0x00000014
    public CombatEntity self; //  0x00000018
    public UnityEngine.Vector3 selfTargetPos; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00AF88F4 (11503860), len: 8  VirtAddr: 0x00AF88F4 RVA: 0x00AF88F4 token: 100693102 methodIndex: 55257 delegateWrapperIndex: 0 methodInvoker: 0
    public TargetMgr.AngleEntity()
    {
        //
        // Disasemble & Code
        // 0x00AF88F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00AF88F8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }

}
