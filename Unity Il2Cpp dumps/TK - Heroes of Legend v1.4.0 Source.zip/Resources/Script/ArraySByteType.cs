using UnityEngine;

namespace wxb
{
    internal class ArraySByteType : ArraySerialize<sbyte>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2C1C4 (14860740), len: 80  VirtAddr: 0x00E2C1C4 RVA: 0x00E2C1C4 token: 100681185 methodIndex: 57221 delegateWrapperIndex: 0 methodInvoker: 0
        public ArraySByteType()
        {
            //
            // Disasemble & Code
            // 0x00E2C1C4: STP x20, x19, [sp, #-0x20]! | stack[1152921513023993760] = ???;  stack[1152921513023993768] = ???;  //  dest_result_addr=1152921513023993760 |  dest_result_addr=1152921513023993768
            // 0x00E2C1C8: STP x29, x30, [sp, #0x10]  | stack[1152921513023993776] = ???;  stack[1152921513023993784] = ???;  //  dest_result_addr=1152921513023993776 |  dest_result_addr=1152921513023993784
            // 0x00E2C1CC: ADD x29, sp, #0x10         | X29 = (1152921513023993760 + 16) = 1152921513023993776 (0x10000001F5B377B0);
            // 0x00E2C1D0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C1D4: LDRB w8, [x20, #0x8f3]     | W8 = (bool)static_value_037348F3;       
            // 0x00E2C1D8: MOV x19, x0                | X19 = 1152921513024005792 (0x10000001F5B3A6A0);//ML01
            // 0x00E2C1DC: TBNZ w8, #0, #0xe2c1f8     | if (static_value_037348F3 == true) goto label_0;
            // 0x00E2C1E0: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00E2C1E4: LDR x8, [x8, #0xda8]       | X8 = 0x2B8E824;                         
            // 0x00E2C1E8: LDR w0, [x8]               | W0 = 0x10C7;                            
            // 0x00E2C1EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x10C7, ????);     
            // 0x00E2C1F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C1F4: STRB w8, [x20, #0x8f3]     | static_value_037348F3 = true;            //  dest_result_addr=57886963
            label_0:
            // 0x00E2C1F8: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00E2C1FC: LDR x8, [x8, #0x538]       | X8 = 1152921513023980768;               
            // 0x00E2C200: MOV x0, x19                | X0 = 1152921513024005792 (0x10000001F5B3A6A0);//ML01
            // 0x00E2C204: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.SByte>::.ctor();
            // 0x00E2C208: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C20C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C210: B #0x1d871e8               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C214 (14860820), len: 8  VirtAddr: 0x00E2C214 RVA: 0x00E2C214 token: 100681186 methodIndex: 57222 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2C214: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00E2C218: RET                        |  return (System.Int32)1;                
            return (int)1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C21C (14860828), len: 52  VirtAddr: 0x00E2C21C RVA: 0x00E2C21C token: 100681187 methodIndex: 57223 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, sbyte value)
        {
            //
            // Disasemble & Code
            // 0x00E2C21C: STP x20, x19, [sp, #-0x20]! | stack[1152921513024221856] = ???;  stack[1152921513024221864] = ???;  //  dest_result_addr=1152921513024221856 |  dest_result_addr=1152921513024221864
            // 0x00E2C220: STP x29, x30, [sp, #0x10]  | stack[1152921513024221872] = ???;  stack[1152921513024221880] = ???;  //  dest_result_addr=1152921513024221872 |  dest_result_addr=1152921513024221880
            // 0x00E2C224: ADD x29, sp, #0x10         | X29 = (1152921513024221856 + 16) = 1152921513024221872 (0x10000001F5B6F2B0);
            // 0x00E2C228: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2C22C: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2C230: CBNZ x20, #0xe2c238        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C238: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C23C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C240: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2C244: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2C248: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C24C: B #0x26a3a24               | stream.WriteSByte(value:  value); return;
            stream.WriteSByte(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C250 (14860880), len: 44  VirtAddr: 0x00E2C250 RVA: 0x00E2C250 token: 100681188 methodIndex: 57224 delegateWrapperIndex: 0 methodInvoker: 0
        protected override sbyte Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2C250: STP x20, x19, [sp, #-0x20]! | stack[1152921513024342048] = ???;  stack[1152921513024342056] = ???;  //  dest_result_addr=1152921513024342048 |  dest_result_addr=1152921513024342056
            // 0x00E2C254: STP x29, x30, [sp, #0x10]  | stack[1152921513024342064] = ???;  stack[1152921513024342072] = ???;  //  dest_result_addr=1152921513024342064 |  dest_result_addr=1152921513024342072
            // 0x00E2C258: ADD x29, sp, #0x10         | X29 = (1152921513024342048 + 16) = 1152921513024342064 (0x10000001F5B8C830);
            // 0x00E2C25C: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2C260: CBNZ x19, #0xe2c268        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C264: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C268: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C26C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C270: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2C274: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C278: B #0x26a3ab4               | return stream.ReadSByte();              
            return stream.ReadSByte();
        
        }
    
    }

}
