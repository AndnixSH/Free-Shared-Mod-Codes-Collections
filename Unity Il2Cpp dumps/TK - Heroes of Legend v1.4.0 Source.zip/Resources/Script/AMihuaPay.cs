using UnityEngine;
public class AMihuaPay
{
    // Fields
    private System.Collections.Generic.Dictionary<string, string> payParams; //  0x00000010
    private string referer; //  0x00000018
    private string callBackName; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B25D04 (11689220), len: 1084  VirtAddr: 0x00B25D04 RVA: 0x00B25D04 token: 100694756 methodIndex: 24772 delegateWrapperIndex: 0 methodInvoker: 0
    public AMihuaPay(string referer)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        object val_14;
        //  | 
        string val_15;
        //  | 
        string val_16;
        // 0x00B25D04: STP x24, x23, [sp, #-0x40]! | stack[1152921515234453600] = ???;  stack[1152921515234453608] = ???;  //  dest_result_addr=1152921515234453600 |  dest_result_addr=1152921515234453608
        // 0x00B25D08: STP x22, x21, [sp, #0x10]  | stack[1152921515234453616] = ???;  stack[1152921515234453624] = ???;  //  dest_result_addr=1152921515234453616 |  dest_result_addr=1152921515234453624
        // 0x00B25D0C: STP x20, x19, [sp, #0x20]  | stack[1152921515234453632] = ???;  stack[1152921515234453640] = ???;  //  dest_result_addr=1152921515234453632 |  dest_result_addr=1152921515234453640
        // 0x00B25D10: STP x29, x30, [sp, #0x30]  | stack[1152921515234453648] = ???;  stack[1152921515234453656] = ???;  //  dest_result_addr=1152921515234453648 |  dest_result_addr=1152921515234453656
        // 0x00B25D14: ADD x29, sp, #0x30         | X29 = (1152921515234453600 + 48) = 1152921515234453648 (0x1000000279746890);
        // 0x00B25D18: SUB sp, sp, #0x10          | SP = (1152921515234453600 - 16) = 1152921515234453584 (0x1000000279746850);
        // 0x00B25D1C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B25D20: LDRB w8, [x21, #0x742]     | W8 = (bool)static_value_03733742;       
        // 0x00B25D24: MOV x20, x1                | X20 = referer;//m1                      
        // 0x00B25D28: MOV x19, x0                | X19 = 1152921515234465664 (0x1000000279749780);//ML01
        // 0x00B25D2C: TBNZ w8, #0, #0xb25d48     | if (static_value_03733742 == true) goto label_0;
        // 0x00B25D30: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B25D34: LDR x8, [x8, #0x620]       | X8 = 0x2B8AC4C;                         
        // 0x00B25D38: LDR w0, [x8]               | W0 = 0x1D1;                             
        // 0x00B25D3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D1, ????);      
        // 0x00B25D40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B25D44: STRB w8, [x21, #0x742]     | static_value_03733742 = true;            //  dest_result_addr=57882434
        label_0:
        // 0x00B25D48: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00B25D4C: LDR x8, [x8, #0xf18]       | X8 = 1152921504615792640;               
        // 0x00B25D50: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.String> val_1 = null;
        // 0x00B25D54: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B25D58: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B25D5C: LDR x8, [x8, #0x9f8]       | X8 = 1152921509931587600;               
        // 0x00B25D60: MOV x21, x0                | X21 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25D64: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::.ctor();
        // 0x00B25D68: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.String>();
        // 0x00B25D6C: CBNZ x21, #0xb25d74        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B25D70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B25D74: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B25D78: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
        // 0x00B25D7C: ADRP x24, #0x363b000       | X24 = 56864768 (0x363B000);             
        // 0x00B25D80: LDR x8, [x8, #0x468]       | X8 = (string**)(1152921512771215408)("app_id");
        // 0x00B25D84: LDR x9, [x9, #0xe20]       | X9 = (string**)(1152921515234406768)("2017092008827319");
        // 0x00B25D88: LDR x24, [x24, #0x310]     | X24 = 1152921509931601104;              
        // 0x00B25D8C: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25D90: LDR x1, [x8]               | X1 = "app_id";                          
        // 0x00B25D94: LDR x2, [x9]               | X2 = "2017092008827319";                
        // 0x00B25D98: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25D9C: BL #0x23fd44c              | Add(key:  "app_id", value:  "2017092008827319");
        Add(key:  "app_id", value:  "2017092008827319");
        // 0x00B25DA0: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
        // 0x00B25DA4: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
        // 0x00B25DA8: LDR x0, [x23]              | X0 = typeof(System.String);             
        val_13 = null;
        // 0x00B25DAC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B25DB0: TBZ w8, #0, #0xb25dc4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B25DB4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B25DB8: CBNZ w8, #0xb25dc4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B25DBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B25DC0: LDR x0, [x23]              | X0 = typeof(System.String);             
        val_13 = null;
        label_3:
        // 0x00B25DC4: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B25DC8: LDR x22, [x8]              | X22 = System.String.Empty;              
        // 0x00B25DCC: CBZ x21, #0xb25df0         | if ( == 0) goto label_4;                
        if(null == 0)
        {
            goto label_4;
        }
        // 0x00B25DD0: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00B25DD4: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921515234406880)("biz_content");
        // 0x00B25DD8: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25DDC: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25DE0: MOV x2, x22                | X2 = System.String.Empty;//m1           
        // 0x00B25DE4: LDR x1, [x8]               | X1 = "biz_content";                     
        // 0x00B25DE8: BL #0x23fd44c              | Add(key:  "biz_content", value:  System.String.Empty);
        Add(key:  "biz_content", value:  System.String.Empty);
        // 0x00B25DEC: B #0xb25e14                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00B25DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
        // 0x00B25DF4: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00B25DF8: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921515234406880)("biz_content");
        // 0x00B25DFC: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25E00: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25E04: MOV x2, x22                | X2 = System.String.Empty;//m1           
        // 0x00B25E08: LDR x1, [x8]               | X1 = "biz_content";                     
        // 0x00B25E0C: BL #0x23fd44c              | Add(key:  "biz_content", value:  System.String.Empty);
        Add(key:  "biz_content", value:  System.String.Empty);
        // 0x00B25E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_5:
        // 0x00B25E14: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B25E18: ADRP x9, #0x3635000        | X9 = 56840192 (0x3635000);              
        // 0x00B25E1C: LDR x8, [x8, #0xec8]       | X8 = (string**)(1152921509478566768)("method");
        // 0x00B25E20: LDR x9, [x9, #0x328]       | X9 = (string**)(1152921515234406976)("alipay.trade.app.pay");
        // 0x00B25E24: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25E28: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25E2C: LDR x1, [x8]               | X1 = "method";                          
        // 0x00B25E30: LDR x2, [x9]               | X2 = "alipay.trade.app.pay";            
        // 0x00B25E34: BL #0x23fd44c              | Add(key:  "method", value:  "alipay.trade.app.pay");
        Add(key:  "method", value:  "alipay.trade.app.pay");
        // 0x00B25E38: CBZ x21, #0xb25e64         | if ( == 0) goto label_6;                
        if(null == 0)
        {
            goto label_6;
        }
        // 0x00B25E3C: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B25E40: ADRP x9, #0x3684000        | X9 = 57163776 (0x3684000);              
        // 0x00B25E44: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921515234407088)("charset");
        // 0x00B25E48: LDR x9, [x9, #0x178]       | X9 = (string**)(1152921509649807760)("utf-8");
        // 0x00B25E4C: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25E50: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25E54: LDR x1, [x8]               | X1 = "charset";                         
        // 0x00B25E58: LDR x2, [x9]               | X2 = "utf-8";                           
        // 0x00B25E5C: BL #0x23fd44c              | Add(key:  "charset", value:  "utf-8");  
        Add(key:  "charset", value:  "utf-8");
        // 0x00B25E60: B #0xb25e90                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00B25E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B25E68: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B25E6C: ADRP x9, #0x3684000        | X9 = 57163776 (0x3684000);              
        // 0x00B25E70: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921515234407088)("charset");
        // 0x00B25E74: LDR x9, [x9, #0x178]       | X9 = (string**)(1152921509649807760)("utf-8");
        // 0x00B25E78: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25E7C: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25E80: LDR x1, [x8]               | X1 = "charset";                         
        // 0x00B25E84: LDR x2, [x9]               | X2 = "utf-8";                           
        // 0x00B25E88: BL #0x23fd44c              | Add(key:  "charset", value:  "utf-8");  
        Add(key:  "charset", value:  "utf-8");
        // 0x00B25E8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_7:
        // 0x00B25E90: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B25E94: ADRP x9, #0x35f6000        | X9 = 56582144 (0x35F6000);              
        // 0x00B25E98: LDR x8, [x8, #0xa18]       | X8 = (string**)(1152921515234407184)("sign_type");
        // 0x00B25E9C: LDR x9, [x9, #0x720]       | X9 = (string**)(1152921515234407280)("RSA2");
        // 0x00B25EA0: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25EA4: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25EA8: LDR x1, [x8]               | X1 = "sign_type";                       
        // 0x00B25EAC: LDR x2, [x9]               | X2 = "RSA2";                            
        // 0x00B25EB0: BL #0x23fd44c              | Add(key:  "sign_type", value:  "RSA2"); 
        Add(key:  "sign_type", value:  "RSA2");
        // 0x00B25EB4: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x00B25EB8: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B25EBC: LDR x22, [x8]              | X22 = System.String.Empty;              
        // 0x00B25EC0: CBZ x21, #0xb25ee4         | if ( == 0) goto label_8;                
        if(null == 0)
        {
            goto label_8;
        }
        // 0x00B25EC4: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B25EC8: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921515234407360)("timestamp");
        // 0x00B25ECC: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25ED0: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25ED4: MOV x2, x22                | X2 = System.String.Empty;//m1           
        // 0x00B25ED8: LDR x1, [x8]               | X1 = "timestamp";                       
        // 0x00B25EDC: BL #0x23fd44c              | Add(key:  "timestamp", value:  System.String.Empty);
        Add(key:  "timestamp", value:  System.String.Empty);
        // 0x00B25EE0: B #0xb25f08                |  goto label_9;                          
        goto label_9;
        label_8:
        // 0x00B25EE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B25EE8: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B25EEC: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921515234407360)("timestamp");
        // 0x00B25EF0: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25EF4: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25EF8: MOV x2, x22                | X2 = System.String.Empty;//m1           
        // 0x00B25EFC: LDR x1, [x8]               | X1 = "timestamp";                       
        // 0x00B25F00: BL #0x23fd44c              | Add(key:  "timestamp", value:  System.String.Empty);
        Add(key:  "timestamp", value:  System.String.Empty);
        // 0x00B25F04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_9:
        // 0x00B25F08: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00B25F0C: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B25F10: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921509425266608)("version");
        // 0x00B25F14: LDR x9, [x9, #0xf18]       | X9 = (string**)(1152921509463144272)("1.0");
        // 0x00B25F18: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25F1C: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25F20: LDR x1, [x8]               | X1 = "version";                         
        // 0x00B25F24: LDR x2, [x9]               | X2 = "1.0";                             
        // 0x00B25F28: BL #0x23fd44c              | Add(key:  "version", value:  "1.0");    
        Add(key:  "version", value:  "1.0");
        // 0x00B25F2C: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x00B25F30: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B25F34: LDR x22, [x8]              | X22 = System.String.Empty;              
        // 0x00B25F38: CBNZ x21, #0xb25f40        | if ( != 0) goto label_10;               
        if(null != 0)
        {
            goto label_10;
        }
        // 0x00B25F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_10:
        // 0x00B25F40: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B25F44: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921515234407456)("notify_url");
        // 0x00B25F48: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B25F4C: MOV x0, x21                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B25F50: MOV x2, x22                | X2 = System.String.Empty;//m1           
        // 0x00B25F54: LDR x1, [x8]               | X1 = "notify_url";                      
        // 0x00B25F58: BL #0x23fd44c              | Add(key:  "notify_url", value:  System.String.Empty);
        Add(key:  "notify_url", value:  System.String.Empty);
        // 0x00B25F5C: STR x21, [x19, #0x10]      | this.payParams = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515234465680
        this.payParams = val_1;
        // 0x00B25F60: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00B25F64: LDR x8, [x8, #0x6a8]       | X8 = (string**)(1152921515234407552)("mihuahudong.com://");
        // 0x00B25F68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25F6C: MOV x0, x19                | X0 = 1152921515234465664 (0x1000000279749780);//ML01
        // 0x00B25F70: LDR x8, [x8]               | X8 = "mihuahudong.com://";              
        // 0x00B25F74: STR x8, [x19, #0x18]       | this.referer = "mihuahudong.com://";     //  dest_result_addr=1152921515234465688
        this.referer = "mihuahudong.com://";
        // 0x00B25F78: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B25F7C: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921515234407664)("zhifubao");
        // 0x00B25F80: LDR x8, [x8]               | X8 = "zhifubao";                        
        // 0x00B25F84: STR x8, [x19, #0x20]       | this.callBackName = "zhifubao";          //  dest_result_addr=1152921515234465696
        this.callBackName = "zhifubao";
        // 0x00B25F88: BL #0x16f59f0              | this..ctor();                           
        // 0x00B25F8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25F90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25F94: MOV x1, x20                | X1 = referer;//m1                       
        // 0x00B25F98: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_2 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B25F9C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B25FA0: TBNZ w8, #0, #0xb25fdc     | if ((val_2 & 1) == true) goto label_11; 
        if(val_3 == true)
        {
            goto label_11;
        }
        // 0x00B25FA4: LDR x0, [x23]              | X0 = typeof(System.String);             
        // 0x00B25FA8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B25FAC: TBZ w8, #0, #0xb25fbc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B25FB0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B25FB4: CBNZ w8, #0xb25fbc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B25FB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_13:
        // 0x00B25FBC: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00B25FC0: LDR x8, [x8, #0x5a8]       | X8 = (string**)(1152921513178512912)("0");
        // 0x00B25FC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25FC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B25FCC: MOV x1, x20                | X1 = referer;//m1                       
        // 0x00B25FD0: LDR x2, [x8]               | X2 = "0";                               
        // 0x00B25FD4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  referer);
        bool val_4 = System.String.op_Equality(a:  0, b:  referer);
        // 0x00B25FD8: TBZ w0, #0, #0xb260f4      | if (val_4 == false) goto label_14;      
        if(val_4 == false)
        {
            goto label_14;
        }
        label_11:
        // 0x00B25FDC: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B25FE0: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
        // 0x00B25FE4: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
        // 0x00B25FE8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
        // 0x00B25FEC: TBZ w8, #0, #0xb25ffc      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B25FF0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B25FF4: CBNZ w8, #0xb25ffc         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B25FF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
        label_16:
        // 0x00B25FFC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B26000: ADRP x9, #0x361a000        | X9 = 56729600 (0x361A000);              
        // 0x00B26004: LDR x8, [x8, #0x290]       | X8 = (string**)(1152921515173014304)("vs_tag");
        // 0x00B26008: LDR x9, [x9, #0xbb8]       | X9 = 1152921515234407760;               
        // 0x00B2600C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26010: LDR x1, [x8]               | X1 = "vs_tag";                          
        // 0x00B26014: LDR x2, [x9]               | X2 = public static VersionTag Mihua.Asset.AssetMgr::LoadResource<VersionTag>(string resPath);
        // 0x00B26018: BL #0xfd8e34               | X0 = Mihua.Asset.AssetMgr.LoadResource<UIAtlas>(resPath:  0);
        UIAtlas val_5 = Mihua.Asset.AssetMgr.LoadResource<UIAtlas>(resPath:  0);
        // 0x00B2601C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B26020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26024: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26028: BL #0x20c767c              | X0 = UnityEngine.Application.get_identifier();
        string val_6 = UnityEngine.Application.identifier;
        // 0x00B2602C: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B26030: CBNZ x21, #0xb26038        | if (val_6 != null) goto label_17;       
        if(val_6 != null)
        {
            goto label_17;
        }
        // 0x00B26034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_17:
        // 0x00B26038: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B2603C: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
        // 0x00B26040: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26044: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00B26048: LDR x1, [x8]               | X1 = ".";                               
        // 0x00B2604C: BL #0x18ad1e4              | X0 = val_6.LastIndexOf(value:  ".");    
        int val_7 = val_6.LastIndexOf(value:  ".");
        // 0x00B26050: MOV w21, w0                | W21 = val_7;//m1                        
        // 0x00B26054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2605C: BL #0x20c767c              | X0 = UnityEngine.Application.get_identifier();
        string val_8 = UnityEngine.Application.identifier;
        // 0x00B26060: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B26064: CBNZ x22, #0xb2606c        | if (val_8 != null) goto label_18;       
        if(val_8 != null)
        {
            goto label_18;
        }
        // 0x00B26068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_18:
        // 0x00B2606C: ADD w1, w21, #1            | W1 = (val_7 + 1);                       
        int val_9 = val_7 + 1;
        // 0x00B26070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26074: MOV x0, x22                | X0 = val_8;//m1                         
        // 0x00B26078: BL #0x18a5a40              | X0 = val_8.Substring(startIndex:  int val_9 = val_7 + 1);
        string val_10 = val_8.Substring(startIndex:  val_9);
        // 0x00B2607C: MOV x21, x0                | X21 = val_10;//m1                       
        val_14 = val_10;
        // 0x00B26080: CBNZ x20, #0xb26088        | if (val_5 != null) goto label_19;       
        if(val_5 != null)
        {
            goto label_19;
        }
        // 0x00B26084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_19:
        // 0x00B26088: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B2608C: LDR w8, [x20, #0x1c]       | 
        // 0x00B26090: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B26094: ADD x1, sp, #0xc           | X1 = (1152921515234453584 + 12) = 1152921515234453596 (0x100000027974685C);
        // 0x00B26098: STR w8, [sp, #0xc]         | stack[1152921515234453596] = (string**)(1152921509414037808)(".");  //  dest_result_addr=1152921515234453596
        // 0x00B2609C: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B260A0: BL #0x27bc028              | X0 = 1152921515234518144 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (string**)(1152921509414037808)("."));
        // 0x00B260A4: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x00B260A8: MOV x20, x0                | X20 = 1152921515234518144 (0x1000000279756480);//ML01
        // 0x00B260AC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B260B0: TBZ w9, #0, #0xb260c4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00B260B4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B260B8: CBNZ w9, #0xb260c4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00B260BC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B260C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_21:
        // 0x00B260C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B260C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B260CC: MOV x1, x21                | X1 = val_10;//m1                        
        // 0x00B260D0: MOV x2, x20                | X2 = 1152921515234518144 (0x1000000279756480);//ML01
        // 0x00B260D4: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  val_14);
        string val_11 = System.String.Concat(arg0:  0, arg1:  val_14);
        // 0x00B260D8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B260DC: LDR x8, [x8, #0x118]       | X8 = (string**)(1152921515234433360)(".mihuahudong.com://");
        // 0x00B260E0: MOV x1, x0                 | X1 = val_11;//m1                        
        val_15 = val_11;
        // 0x00B260E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_16 = 0;
        // 0x00B260E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B260EC: LDR x2, [x8]               | X2 = ".mihuahudong.com://";             
        // 0x00B260F0: B #0xb26120                |  goto label_22;                         
        goto label_22;
        label_14:
        // 0x00B260F4: LDR x0, [x23]              | X0 = typeof(System.String);             
        // 0x00B260F8: LDR x21, [x19, #0x18]      | X21 = this.referer; //P2                
        val_14 = this.referer;
        // 0x00B260FC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B26100: TBZ w8, #0, #0xb26110      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x00B26104: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B26108: CBNZ w8, #0xb26110         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x00B2610C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_24:
        // 0x00B26110: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_16 = 0;
        // 0x00B26114: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26118: MOV x1, x20                | X1 = referer;//m1                       
        val_15 = referer;
        // 0x00B2611C: MOV x2, x21                | X2 = this.referer;//m1                  
        label_22:
        // 0x00B26120: BL #0x18a3e88              | X0 = System.String.Concat(str0:  val_16 = 0, str1:  val_15 = referer);
        string val_12 = System.String.Concat(str0:  val_16, str1:  val_15);
        // 0x00B26124: STR x0, [x19, #0x18]       | this.referer = val_12;                   //  dest_result_addr=1152921515234465688
        this.referer = val_12;
        // 0x00B26128: SUB sp, x29, #0x30         | SP = (1152921515234453648 - 48) = 1152921515234453600 (0x1000000279746860);
        // 0x00B2612C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B26130: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B26134: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B26138: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2613C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B26140 (11690304), len: 632  VirtAddr: 0x00B26140 RVA: 0x00B26140 token: 100694757 methodIndex: 24773 delegateWrapperIndex: 0 methodInvoker: 0
    public void InitPayParams()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00B26140: STP x24, x23, [sp, #-0x40]! | stack[1152921515234602656] = ???;  stack[1152921515234602664] = ???;  //  dest_result_addr=1152921515234602656 |  dest_result_addr=1152921515234602664
        // 0x00B26144: STP x22, x21, [sp, #0x10]  | stack[1152921515234602672] = ???;  stack[1152921515234602680] = ???;  //  dest_result_addr=1152921515234602672 |  dest_result_addr=1152921515234602680
        // 0x00B26148: STP x20, x19, [sp, #0x20]  | stack[1152921515234602688] = ???;  stack[1152921515234602696] = ???;  //  dest_result_addr=1152921515234602688 |  dest_result_addr=1152921515234602696
        // 0x00B2614C: STP x29, x30, [sp, #0x30]  | stack[1152921515234602704] = ???;  stack[1152921515234602712] = ???;  //  dest_result_addr=1152921515234602704 |  dest_result_addr=1152921515234602712
        // 0x00B26150: ADD x29, sp, #0x30         | X29 = (1152921515234602656 + 48) = 1152921515234602704 (0x100000027976AED0);
        // 0x00B26154: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B26158: LDRB w8, [x20, #0x743]     | W8 = (bool)static_value_03733743;       
        // 0x00B2615C: MOV x19, x0                | X19 = 1152921515234614720 (0x100000027976DDC0);//ML01
        // 0x00B26160: TBNZ w8, #0, #0xb2617c     | if (static_value_03733743 == true) goto label_0;
        // 0x00B26164: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00B26168: LDR x8, [x8, #0x378]       | X8 = 0x2B8AC58;                         
        // 0x00B2616C: LDR w0, [x8]               | W0 = 0x1D4;                             
        // 0x00B26170: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D4, ????);      
        // 0x00B26174: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B26178: STRB w8, [x20, #0x743]     | static_value_03733743 = true;            //  dest_result_addr=57882435
        label_0:
        // 0x00B2617C: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00B26180: LDR x8, [x8, #0x2c0]       | X8 = (string**)(1152921515234590528)("alipay");
        // 0x00B26184: LDR x8, [x8]               | X8 = "alipay";                          
        // 0x00B26188: STR x8, [x19, #0x20]       | this.callBackName = "alipay";            //  dest_result_addr=1152921515234614752
        this.callBackName = "alipay";
        // 0x00B2618C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00B26190: LDR x8, [x8, #0xf18]       | X8 = 1152921504615792640;               
        // 0x00B26194: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.String> val_1 = null;
        // 0x00B26198: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B2619C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B261A0: LDR x8, [x8, #0x9f8]       | X8 = 1152921509931587600;               
        // 0x00B261A4: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B261A8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::.ctor();
        // 0x00B261AC: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.String>();
        // 0x00B261B0: CBNZ x20, #0xb261b8        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B261B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B261B8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B261BC: ADRP x9, #0x35d0000        | X9 = 56426496 (0x35D0000);              
        // 0x00B261C0: ADRP x22, #0x363b000       | X22 = 56864768 (0x363B000);             
        // 0x00B261C4: LDR x8, [x8, #0x468]       | X8 = (string**)(1152921512771215408)("app_id");
        // 0x00B261C8: LDR x9, [x9, #0x1f0]       | X9 = (string**)(1152921515234590608)("2018011601902192");
        // 0x00B261CC: LDR x22, [x22, #0x310]     | X22 = 1152921509931601104;              
        // 0x00B261D0: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B261D4: LDR x1, [x8]               | X1 = "app_id";                          
        // 0x00B261D8: LDR x2, [x9]               | X2 = "2018011601902192";                
        // 0x00B261DC: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B261E0: BL #0x23fd44c              | Add(key:  "app_id", value:  "2018011601902192");
        Add(key:  "app_id", value:  "2018011601902192");
        // 0x00B261E4: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
        // 0x00B261E8: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
        // 0x00B261EC: LDR x0, [x23]              | X0 = typeof(System.String);             
        val_2 = null;
        // 0x00B261F0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B261F4: TBZ w8, #0, #0xb26208      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B261F8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B261FC: CBNZ w8, #0xb26208         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B26200: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B26204: LDR x0, [x23]              | X0 = typeof(System.String);             
        val_2 = null;
        label_3:
        // 0x00B26208: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B2620C: LDR x21, [x8]              | X21 = System.String.Empty;              
        // 0x00B26210: CBZ x20, #0xb26234         | if ( == 0) goto label_4;                
        if(null == 0)
        {
            goto label_4;
        }
        // 0x00B26214: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00B26218: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921515234406880)("biz_content");
        // 0x00B2621C: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26220: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26224: MOV x2, x21                | X2 = System.String.Empty;//m1           
        // 0x00B26228: LDR x1, [x8]               | X1 = "biz_content";                     
        // 0x00B2622C: BL #0x23fd44c              | Add(key:  "biz_content", value:  System.String.Empty);
        Add(key:  "biz_content", value:  System.String.Empty);
        // 0x00B26230: B #0xb26258                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00B26234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
        // 0x00B26238: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00B2623C: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921515234406880)("biz_content");
        // 0x00B26240: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26244: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26248: MOV x2, x21                | X2 = System.String.Empty;//m1           
        // 0x00B2624C: LDR x1, [x8]               | X1 = "biz_content";                     
        // 0x00B26250: BL #0x23fd44c              | Add(key:  "biz_content", value:  System.String.Empty);
        Add(key:  "biz_content", value:  System.String.Empty);
        // 0x00B26254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_5:
        // 0x00B26258: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B2625C: ADRP x9, #0x3635000        | X9 = 56840192 (0x3635000);              
        // 0x00B26260: LDR x8, [x8, #0xec8]       | X8 = (string**)(1152921509478566768)("method");
        // 0x00B26264: LDR x9, [x9, #0x328]       | X9 = (string**)(1152921515234406976)("alipay.trade.app.pay");
        // 0x00B26268: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B2626C: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26270: LDR x1, [x8]               | X1 = "method";                          
        // 0x00B26274: LDR x2, [x9]               | X2 = "alipay.trade.app.pay";            
        // 0x00B26278: BL #0x23fd44c              | Add(key:  "method", value:  "alipay.trade.app.pay");
        Add(key:  "method", value:  "alipay.trade.app.pay");
        // 0x00B2627C: CBZ x20, #0xb262a8         | if ( == 0) goto label_6;                
        if(null == 0)
        {
            goto label_6;
        }
        // 0x00B26280: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B26284: ADRP x9, #0x3684000        | X9 = 57163776 (0x3684000);              
        // 0x00B26288: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921515234407088)("charset");
        // 0x00B2628C: LDR x9, [x9, #0x178]       | X9 = (string**)(1152921509649807760)("utf-8");
        // 0x00B26290: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26294: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26298: LDR x1, [x8]               | X1 = "charset";                         
        // 0x00B2629C: LDR x2, [x9]               | X2 = "utf-8";                           
        // 0x00B262A0: BL #0x23fd44c              | Add(key:  "charset", value:  "utf-8");  
        Add(key:  "charset", value:  "utf-8");
        // 0x00B262A4: B #0xb262d4                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00B262A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B262AC: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B262B0: ADRP x9, #0x3684000        | X9 = 57163776 (0x3684000);              
        // 0x00B262B4: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921515234407088)("charset");
        // 0x00B262B8: LDR x9, [x9, #0x178]       | X9 = (string**)(1152921509649807760)("utf-8");
        // 0x00B262BC: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B262C0: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B262C4: LDR x1, [x8]               | X1 = "charset";                         
        // 0x00B262C8: LDR x2, [x9]               | X2 = "utf-8";                           
        // 0x00B262CC: BL #0x23fd44c              | Add(key:  "charset", value:  "utf-8");  
        Add(key:  "charset", value:  "utf-8");
        // 0x00B262D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_7:
        // 0x00B262D4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B262D8: ADRP x9, #0x35f6000        | X9 = 56582144 (0x35F6000);              
        // 0x00B262DC: LDR x8, [x8, #0xa18]       | X8 = (string**)(1152921515234407184)("sign_type");
        // 0x00B262E0: LDR x9, [x9, #0x720]       | X9 = (string**)(1152921515234407280)("RSA2");
        // 0x00B262E4: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B262E8: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B262EC: LDR x1, [x8]               | X1 = "sign_type";                       
        // 0x00B262F0: LDR x2, [x9]               | X2 = "RSA2";                            
        // 0x00B262F4: BL #0x23fd44c              | Add(key:  "sign_type", value:  "RSA2"); 
        Add(key:  "sign_type", value:  "RSA2");
        // 0x00B262F8: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x00B262FC: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B26300: LDR x21, [x8]              | X21 = System.String.Empty;              
        // 0x00B26304: CBZ x20, #0xb26328         | if ( == 0) goto label_8;                
        if(null == 0)
        {
            goto label_8;
        }
        // 0x00B26308: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B2630C: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921515234407360)("timestamp");
        // 0x00B26310: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26314: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26318: MOV x2, x21                | X2 = System.String.Empty;//m1           
        // 0x00B2631C: LDR x1, [x8]               | X1 = "timestamp";                       
        // 0x00B26320: BL #0x23fd44c              | Add(key:  "timestamp", value:  System.String.Empty);
        Add(key:  "timestamp", value:  System.String.Empty);
        // 0x00B26324: B #0xb2634c                |  goto label_9;                          
        goto label_9;
        label_8:
        // 0x00B26328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B2632C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B26330: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921515234407360)("timestamp");
        // 0x00B26334: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26338: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B2633C: MOV x2, x21                | X2 = System.String.Empty;//m1           
        // 0x00B26340: LDR x1, [x8]               | X1 = "timestamp";                       
        // 0x00B26344: BL #0x23fd44c              | Add(key:  "timestamp", value:  System.String.Empty);
        Add(key:  "timestamp", value:  System.String.Empty);
        // 0x00B26348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_9:
        // 0x00B2634C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00B26350: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00B26354: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921509425266608)("version");
        // 0x00B26358: LDR x9, [x9, #0xf18]       | X9 = (string**)(1152921509463144272)("1.0");
        // 0x00B2635C: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26360: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26364: LDR x1, [x8]               | X1 = "version";                         
        // 0x00B26368: LDR x2, [x9]               | X2 = "1.0";                             
        // 0x00B2636C: BL #0x23fd44c              | Add(key:  "version", value:  "1.0");    
        Add(key:  "version", value:  "1.0");
        // 0x00B26370: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x00B26374: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B26378: LDR x21, [x8]              | X21 = System.String.Empty;              
        // 0x00B2637C: CBNZ x20, #0xb26384        | if ( != 0) goto label_10;               
        if(null != 0)
        {
            goto label_10;
        }
        // 0x00B26380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_10:
        // 0x00B26384: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B26388: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921515234407456)("notify_url");
        // 0x00B2638C: LDR x3, [x22]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B26390: MOV x0, x20                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B26394: MOV x2, x21                | X2 = System.String.Empty;//m1           
        // 0x00B26398: LDR x1, [x8]               | X1 = "notify_url";                      
        // 0x00B2639C: BL #0x23fd44c              | Add(key:  "notify_url", value:  System.String.Empty);
        Add(key:  "notify_url", value:  System.String.Empty);
        // 0x00B263A0: STR x20, [x19, #0x10]      | this.payParams = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515234614736
        this.payParams = val_1;
        // 0x00B263A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B263A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B263AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B263B0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B263B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B263B8 (11690936), len: 644  VirtAddr: 0x00B263B8 RVA: 0x00B263B8 token: 100694758 methodIndex: 24774 delegateWrapperIndex: 0 methodInvoker: 0
    public string BuildOrderParam()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_17;
        //  | 
        var val_18;
        // 0x00B263B8: STP x28, x27, [sp, #-0x60]! | stack[1152921515234751568] = ???;  stack[1152921515234751576] = ???;  //  dest_result_addr=1152921515234751568 |  dest_result_addr=1152921515234751576
        // 0x00B263BC: STP x26, x25, [sp, #0x10]  | stack[1152921515234751584] = ???;  stack[1152921515234751592] = ???;  //  dest_result_addr=1152921515234751584 |  dest_result_addr=1152921515234751592
        // 0x00B263C0: STP x24, x23, [sp, #0x20]  | stack[1152921515234751600] = ???;  stack[1152921515234751608] = ???;  //  dest_result_addr=1152921515234751600 |  dest_result_addr=1152921515234751608
        // 0x00B263C4: STP x22, x21, [sp, #0x30]  | stack[1152921515234751616] = ???;  stack[1152921515234751624] = ???;  //  dest_result_addr=1152921515234751616 |  dest_result_addr=1152921515234751624
        // 0x00B263C8: STP x20, x19, [sp, #0x40]  | stack[1152921515234751632] = ???;  stack[1152921515234751640] = ???;  //  dest_result_addr=1152921515234751632 |  dest_result_addr=1152921515234751640
        // 0x00B263CC: STP x29, x30, [sp, #0x50]  | stack[1152921515234751648] = ???;  stack[1152921515234751656] = ???;  //  dest_result_addr=1152921515234751648 |  dest_result_addr=1152921515234751656
        // 0x00B263D0: ADD x29, sp, #0x50         | X29 = (1152921515234751568 + 80) = 1152921515234751648 (0x100000027978F4A0);
        // 0x00B263D4: SUB sp, sp, #0x50          | SP = (1152921515234751568 - 80) = 1152921515234751488 (0x100000027978F400);
        // 0x00B263D8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B263DC: LDRB w8, [x19, #0x744]     | W8 = (bool)static_value_03733744;       
        // 0x00B263E0: MOV x20, x0                | X20 = 1152921515234763664 (0x1000000279792390);//ML01
        // 0x00B263E4: TBNZ w8, #0, #0xb26400     | if (static_value_03733744 == true) goto label_0;
        // 0x00B263E8: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B263EC: LDR x8, [x8, #0x8c8]       | X8 = 0x2B8AC50;                         
        // 0x00B263F0: LDR w0, [x8]               | W0 = 0x1D2;                             
        // 0x00B263F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D2, ????);      
        // 0x00B263F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B263FC: STRB w8, [x19, #0x744]     | static_value_03733744 = true;            //  dest_result_addr=57882436
        label_0:
        // 0x00B26400: STP xzr, xzr, [sp, #0x40]  | stack[1152921515234751552] = 0x0;  stack[1152921515234751560] = 0x0;  //  dest_result_addr=1152921515234751552 |  dest_result_addr=1152921515234751560
        // 0x00B26404: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B26408: STR xzr, [sp, #0x38]       | stack[1152921515234751544] = 0x0;        //  dest_result_addr=1152921515234751544
        // 0x00B2640C: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x00B26410: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_1 = null;
        // 0x00B26414: STP xzr, xzr, [sp, #0x28]  | stack[1152921515234751528] = 0x0;  stack[1152921515234751536] = 0x0;  //  dest_result_addr=1152921515234751528 |  dest_result_addr=1152921515234751536
        // 0x00B26418: STR xzr, [sp, #0x20]       | stack[1152921515234751520] = 0x0;        //  dest_result_addr=1152921515234751520
        // 0x00B2641C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00B26420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26424: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B26428: BL #0x1b5a30c              | .ctor();                                
        val_1 = new System.Text.StringBuilder();
        // 0x00B2642C: LDR x20, [x20, #0x10]      | X20 = this.payParams; //P2              
        // 0x00B26430: CBNZ x20, #0xb26438        | if (this.payParams != null) goto label_1;
        if(this.payParams != null)
        {
            goto label_1;
        }
        // 0x00B26434: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B26438: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B2643C: LDR x8, [x8, #0xae8]       | X8 = 1152921510817759984;               
        // 0x00B26440: MOV x0, x20                | X0 = this.payParams;//m1                
        // 0x00B26444: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, System.String>::GetEnumerator();
        // 0x00B26448: MOV x8, sp                 | X8 = 1152921515234751488 (0x100000027978F400);//ML01
        // 0x00B2644C: BL #0x23ff0fc              | X0 = this.payParams.GetEnumerator();    
        Dictionary.Enumerator<TKey, TValue> val_2 = this.payParams.GetEnumerator();
        // 0x00B26450: LDP q1, q0, [sp]           | Q1 = val_3; Q0 = val_4;                  //  find_add[1152921515234739664] |  find_add[1152921515234739664]
        // 0x00B26454: ADRP x21, #0x3640000       | X21 = 56885248 (0x3640000);             
        // 0x00B26458: ADRP x22, #0x364a000       | X22 = 56926208 (0x364A000);             
        // 0x00B2645C: ADRP x23, #0x35da000       | X23 = 56467456 (0x35DA000);             
        // 0x00B26460: ADRP x24, #0x35c6000       | X24 = 56385536 (0x35C6000);             
        // 0x00B26464: ADRP x25, #0x3608000       | X25 = 56655872 (0x3608000);             
        // 0x00B26468: ADRP x26, #0x365a000       | X26 = 56991744 (0x365A000);             
        // 0x00B2646C: LDR x21, [x21, #0x178]     | X21 = 1152921510818745232;              
        // 0x00B26470: LDR x22, [x22, #0x5f0]     | X22 = 1152921510818566672;              
        // 0x00B26474: LDR x23, [x23, #0x718]     | X23 = 1152921510851429776;              
        // 0x00B26478: LDR x24, [x24, #0x9f0]     | X24 = (string**)(1152921515234706816)("=");
        // 0x00B2647C: LDR x25, [x25, #0x368]     | X25 = 1152921510851608336;              
        // 0x00B26480: LDR x26, [x26, #0xd48]     | X26 = 1152921504649285632;              
        // 0x00B26484: STP q1, q0, [sp, #0x20]    | stack[1152921515234751520] = val_3;  stack[1152921515234751536] = val_4;  //  dest_result_addr=1152921515234751520 |  dest_result_addr=1152921515234751536
        // 0x00B26488: ADRP x27, #0x35b8000       | X27 = 56328192 (0x35B8000);             
        // 0x00B2648C: LDR x27, [x27, #0x40]      | X27 = (string**)(1152921509527434512)("&");
        label_9:
        // 0x00B26490: LDR x1, [x21]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, System.String>::MoveNext();
        // 0x00B26494: ADD x0, sp, #0x20          | X0 = (1152921515234751488 + 32) = 1152921515234751520 (0x100000027978F420);
        // 0x00B26498: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
        // 0x00B2649C: AND w8, w0, #1             | W8 = (1152921515234751520 & 1) = 0 (0x00000000);
        // 0x00B264A0: TBZ w8, #0, #0xb26630      | if ((0x0 & 0x1) == 0) goto label_2;     
        if((0 & 1) == 0)
        {
            goto label_2;
        }
        // 0x00B264A4: LDR x1, [x22]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, System.String>::get_Current();
        // 0x00B264A8: ADD x0, sp, #0x20          | X0 = (1152921515234751488 + 32) = 1152921515234751520 (0x100000027978F420);
        // 0x00B264AC: BL #0xf3ac3c               | X0 = val_3.GetHandle();                 
        UnityEngine.Playables.PlayableHandle val_5 = val_3.GetHandle();
        // 0x00B264B0: LDR x8, [x23]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, System.String>::get_Key();
        // 0x00B264B4: STP x0, x1, [sp, #0x40]    | stack[1152921515234751552] = val_5.m_Handle;  stack[1152921515234751560] = val_5.m_Version;  //  dest_result_addr=1152921515234751552 |  dest_result_addr=1152921515234751560
        // 0x00B264B8: ADD x0, sp, #0x40          | X0 = (1152921515234751488 + 64) = 1152921515234751552 (0x100000027978F440);
        // 0x00B264BC: MOV x1, x8                 | X1 = 1152921510851429776 (0x100000017434C590);//ML01
        // 0x00B264C0: BL #0x1dc9dd4              | X0 = val_5.m_Handle.get_InitialType();  
        System.Type val_6 = val_5.m_Handle.InitialType;
        // 0x00B264C4: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00B264C8: CBNZ x19, #0xb264d0        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00B264CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_3:
        // 0x00B264D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B264D4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B264D8: MOV x1, x20                | X1 = val_6;//m1                         
        // 0x00B264DC: BL #0x1b5b818              | X0 = Append(value:  val_6);             
        System.Text.StringBuilder val_7 = Append(value:  val_6);
        // 0x00B264E0: CBNZ x19, #0xb264e8        | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x00B264E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_4:
        // 0x00B264E8: LDR x1, [x24]              | X1 = "=";                               
        // 0x00B264EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B264F0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B264F4: BL #0x1b5b818              | X0 = Append(value:  "=");               
        System.Text.StringBuilder val_8 = Append(value:  "=");
        // 0x00B264F8: LDR x1, [x25]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, System.String>::get_Value();
        // 0x00B264FC: ADD x0, sp, #0x40          | X0 = (1152921515234751488 + 64) = 1152921515234751552 (0x100000027978F440);
        // 0x00B26500: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
        // 0x00B26504: MOV x20, x0                | X20 = 1152921515234751552 (0x100000027978F440);//ML01
        // 0x00B26508: LDR x0, [x26]              | X0 = typeof(System.Text.Encoding);      
        // 0x00B2650C: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00B26510: TBZ w8, #0, #0xb26520      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B26514: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00B26518: CBNZ w8, #0xb26520         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B2651C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_6:
        // 0x00B26520: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26528: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_9 = System.Text.Encoding.UTF8;
        // 0x00B2652C: MOV x2, x0                 | X2 = val_9;//m1                         
        // 0x00B26530: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26534: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26538: MOV x1, x20                | X1 = 1152921515234751552 (0x100000027978F440);//ML01
        // 0x00B2653C: BL #0x276e93c              | X0 = UnityEngine.WWW.EscapeURL(s:  0, e:  val_5.m_Handle);
        string val_10 = UnityEngine.WWW.EscapeURL(s:  0, e:  val_5.m_Handle);
        // 0x00B26540: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B26544: CBNZ x19, #0xb2654c        | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x00B26548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_7:
        // 0x00B2654C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26550: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B26554: MOV x1, x20                | X1 = val_10;//m1                        
        // 0x00B26558: BL #0x1b5b818              | X0 = Append(value:  val_10);            
        System.Text.StringBuilder val_11 = Append(value:  val_10);
        // 0x00B2655C: CBNZ x19, #0xb26564        | if ( != 0) goto label_8;                
        if(null != 0)
        {
            goto label_8;
        }
        // 0x00B26560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_8:
        // 0x00B26564: LDR x1, [x27]              | X1 = "&";                               
        // 0x00B26568: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2656C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B26570: BL #0x1b5b818              | X0 = Append(value:  "&");               
        System.Text.StringBuilder val_12 = Append(value:  "&");
        // 0x00B26574: B #0xb26490                |  goto label_9;                          
        goto label_9;
        // 0x00B26578: BL #0x981060               | X0 = sub_981060( ?? val_12, ????);      
        // 0x00B2657C: LDR x20, [x0]              | X20 = typeof(System.Text.StringBuilder);
        // 0x00B26580: BL #0x980920               | X0 = sub_980920( ?? val_12, ????);      
        // 0x00B26584: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        label_15:
        // 0x00B26588: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00B2658C: LDR x8, [x8, #0x698]       | X8 = 1152921510818915600;               
        // 0x00B26590: ADD x0, sp, #0x20          | X0 = (1152921515234751488 + 32) = 1152921515234751520 (0x100000027978F420);
        // 0x00B26594: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, System.String>::Dispose();
        val_17 = public System.Void Dictionary.Enumerator<System.String, System.String>::Dispose();
        // 0x00B26598: BL #0xf3acac               | val_3.Dispose();                        
        val_3.Dispose();
        // 0x00B2659C: TBNZ w21, #0, #0xb265b0    | if ((0x0 & 0x1) != 0) goto label_11;    
        if((0 & 1) != 0)
        {
            goto label_11;
        }
        // 0x00B265A0: CBZ x20, #0xb265b0         | if (typeof(System.Text.StringBuilder) == null) goto label_11;
        if(null == null)
        {
            goto label_11;
        }
        // 0x00B265A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_17 = 0;
        // 0x00B265A8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B265AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Text.StringBuilder), ????);
        label_11:
        // 0x00B265B0: CBNZ x19, #0xb265b8        | if ( != 0) goto label_12;               
        if(null != 0)
        {
            goto label_12;
        }
        // 0x00B265B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Text.StringBuilder), ????);
        label_12:
        // 0x00B265B8: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B265BC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B265C0: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
        // 0x00B265C4: BLR x9                     | X0 = mem[null + 320]();                 
        // 0x00B265C8: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B265CC: CBZ x19, #0xb265e4         | if ( == 0) goto label_13;               
        if(null == 0)
        {
            goto label_13;
        }
        // 0x00B265D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B265D4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B265D8: BL #0x18a4460              | X0 = get_Length();                      
        int val_13 = Length;
        // 0x00B265DC: MOV w20, w0                | W20 = val_13;//m1                       
        val_18 = val_13;
        // 0x00B265E0: B #0xb265fc                |  goto label_14;                         
        goto label_14;
        label_13:
        // 0x00B265E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00B265E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B265EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B265F0: BL #0x18a4460              | X0 = 0.get_Length();                    
        int val_14 = 0.Length;
        // 0x00B265F4: MOV w20, w0                | W20 = val_14;//m1                       
        val_18 = val_14;
        // 0x00B265F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_14:
        // 0x00B265FC: SUB w1, w20, #1            | W1 = (val_14 - 1);                      
        int val_15 = val_18 - 1;
        // 0x00B26600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26604: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B26608: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B2660C: BL #0x18ad8c4              | X0 = Remove(startIndex:  int val_15 = val_18 - 1, count:  1);
        string val_16 = Remove(startIndex:  val_15, count:  1);
        // 0x00B26610: SUB sp, x29, #0x50         | SP = (1152921515234751648 - 80) = 1152921515234751568 (0x100000027978F450);
        // 0x00B26614: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B26618: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2661C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B26620: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B26624: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B26628: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B2662C: RET                        |  return (System.String)val_16;          
        return val_16;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        label_2:
        // 0x00B26630: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        // 0x00B26634: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        // 0x00B26638: B #0xb26588                |  goto label_15;                         
        goto label_15;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2663C (11691580), len: 500  VirtAddr: 0x00B2663C RVA: 0x00B2663C token: 100694759 methodIndex: 24775 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.WWWForm BuildOrderParam2WWWForm()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.WWWForm val_6;
        //  | 
        var val_7;
        // 0x00B2663C: STP x26, x25, [sp, #-0x50]! | stack[1152921515234912736] = ???;  stack[1152921515234912744] = ???;  //  dest_result_addr=1152921515234912736 |  dest_result_addr=1152921515234912744
        // 0x00B26640: STP x24, x23, [sp, #0x10]  | stack[1152921515234912752] = ???;  stack[1152921515234912760] = ???;  //  dest_result_addr=1152921515234912752 |  dest_result_addr=1152921515234912760
        // 0x00B26644: STP x22, x21, [sp, #0x20]  | stack[1152921515234912768] = ???;  stack[1152921515234912776] = ???;  //  dest_result_addr=1152921515234912768 |  dest_result_addr=1152921515234912776
        // 0x00B26648: STP x20, x19, [sp, #0x30]  | stack[1152921515234912784] = ???;  stack[1152921515234912792] = ???;  //  dest_result_addr=1152921515234912784 |  dest_result_addr=1152921515234912792
        // 0x00B2664C: STP x29, x30, [sp, #0x40]  | stack[1152921515234912800] = ???;  stack[1152921515234912808] = ???;  //  dest_result_addr=1152921515234912800 |  dest_result_addr=1152921515234912808
        // 0x00B26650: ADD x29, sp, #0x40         | X29 = (1152921515234912736 + 64) = 1152921515234912800 (0x10000002797B6A20);
        // 0x00B26654: SUB sp, sp, #0x40          | SP = (1152921515234912736 - 64) = 1152921515234912672 (0x10000002797B69A0);
        // 0x00B26658: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B2665C: LDRB w8, [x19, #0x745]     | W8 = (bool)static_value_03733745;       
        // 0x00B26660: MOV x20, x0                | X20 = 1152921515234924816 (0x10000002797B9910);//ML01
        // 0x00B26664: TBNZ w8, #0, #0xb26680     | if (static_value_03733745 == true) goto label_0;
        // 0x00B26668: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00B2666C: LDR x8, [x8, #0x6c0]       | X8 = 0x2B8AC54;                         
        // 0x00B26670: LDR w0, [x8]               | W0 = 0x1D3;                             
        // 0x00B26674: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D3, ????);      
        // 0x00B26678: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2667C: STRB w8, [x19, #0x745]     | static_value_03733745 = true;            //  dest_result_addr=57882437
        label_0:
        // 0x00B26680: STP xzr, xzr, [sp, #0x30]  | stack[1152921515234912720] = 0x0;  stack[1152921515234912728] = 0x0;  //  dest_result_addr=1152921515234912720 |  dest_result_addr=1152921515234912728
        // 0x00B26684: STP xzr, xzr, [sp, #0x20]  | stack[1152921515234912704] = 0x0;  stack[1152921515234912712] = 0x0;  //  dest_result_addr=1152921515234912704 |  dest_result_addr=1152921515234912712
        // 0x00B26688: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B2668C: LDR x8, [x8, #0x18]        | X8 = 1152921504719998976;               
        // 0x00B26690: LDR x0, [x8]               | X0 = typeof(UnityEngine.WWWForm);       
        UnityEngine.WWWForm val_1 = null;
        // 0x00B26694: STP xzr, xzr, [sp, #0x10]  | stack[1152921515234912688] = 0x0;  stack[1152921515234912696] = 0x0;  //  dest_result_addr=1152921515234912688 |  dest_result_addr=1152921515234912696
        // 0x00B26698: STR wzr, [sp, #0xc]        | stack[1152921515234912684] = 0x0;        //  dest_result_addr=1152921515234912684
        // 0x00B2669C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.WWWForm), ????);
        // 0x00B266A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B266A4: MOV x19, x0                | X19 = 1152921504719998976 (0x1000000006BE9000);//ML01
        // 0x00B266A8: BL #0x2759534              | .ctor();                                
        val_1 = new UnityEngine.WWWForm();
        // 0x00B266AC: LDR x20, [x20, #0x10]      | X20 = this.payParams; //P2              
        // 0x00B266B0: CBNZ x20, #0xb266b8        | if (this.payParams != null) goto label_1;
        if(this.payParams != null)
        {
            goto label_1;
        }
        // 0x00B266B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B266B8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B266BC: LDR x8, [x8, #0xae8]       | X8 = 1152921510817759984;               
        // 0x00B266C0: MOV x0, x20                | X0 = this.payParams;//m1                
        // 0x00B266C4: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, System.String>::GetEnumerator();
        // 0x00B266C8: ADD x8, sp, #0x10          | X8 = (1152921515234912672 + 16) = 1152921515234912688 (0x10000002797B69B0);
        // 0x00B266CC: BL #0x23ff0fc              | X0 = this.payParams.GetEnumerator();    
        Dictionary.Enumerator<TKey, TValue> val_2 = this.payParams.GetEnumerator();
        // 0x00B266D0: ADRP x22, #0x3640000       | X22 = 56885248 (0x3640000);             
        // 0x00B266D4: ADRP x23, #0x364a000       | X23 = 56926208 (0x364A000);             
        // 0x00B266D8: ADRP x24, #0x35da000       | X24 = 56467456 (0x35DA000);             
        // 0x00B266DC: ADRP x25, #0x3608000       | X25 = 56655872 (0x3608000);             
        // 0x00B266E0: LDR x22, [x22, #0x178]     | X22 = 1152921510818745232;              
        // 0x00B266E4: LDR x23, [x23, #0x5f0]     | X23 = 1152921510818566672;              
        // 0x00B266E8: LDR x24, [x24, #0x718]     | X24 = 1152921510851429776;              
        // 0x00B266EC: LDR x25, [x25, #0x368]     | X25 = 1152921510851608336;              
        label_4:
        // 0x00B266F0: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, System.String>::MoveNext();
        // 0x00B266F4: ADD x0, sp, #0x10          | X0 = (1152921515234912672 + 16) = 1152921515234912688 (0x10000002797B69B0);
        // 0x00B266F8: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
        // 0x00B266FC: AND w8, w0, #1             | W8 = (1152921515234912688 & 1) = 0 (0x00000000);
        // 0x00B26700: TBZ w8, #0, #0xb2676c      | if ((0x0 & 0x1) == 0) goto label_2;     
        if((0 & 1) == 0)
        {
            goto label_2;
        }
        // 0x00B26704: LDR x1, [x23]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, System.String>::get_Current();
        // 0x00B26708: ADD x0, sp, #0x10          | X0 = (1152921515234912672 + 16) = 1152921515234912688 (0x10000002797B69B0);
        // 0x00B2670C: BL #0xf3ac3c               | X0 = null.GetHandle();                  
        UnityEngine.Playables.PlayableHandle val_3 = 0.GetHandle();
        // 0x00B26710: LDR x8, [x24]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, System.String>::get_Key();
        // 0x00B26714: STP x0, x1, [sp, #0x30]    | stack[1152921515234912720] = val_3.m_Handle;  stack[1152921515234912728] = val_3.m_Version;  //  dest_result_addr=1152921515234912720 |  dest_result_addr=1152921515234912728
        // 0x00B26718: ADD x0, sp, #0x30          | X0 = (1152921515234912672 + 48) = 1152921515234912720 (0x10000002797B69D0);
        // 0x00B2671C: MOV x1, x8                 | X1 = 1152921510851429776 (0x100000017434C590);//ML01
        // 0x00B26720: BL #0x1dc9dd4              | X0 = val_3.m_Handle.get_InitialType();  
        System.Type val_4 = val_3.m_Handle.InitialType;
        // 0x00B26724: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B26728: LDR x1, [x25]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, System.String>::get_Value();
        // 0x00B2672C: ADD x0, sp, #0x30          | X0 = (1152921515234912672 + 48) = 1152921515234912720 (0x10000002797B69D0);
        // 0x00B26730: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
        // 0x00B26734: MOV x21, x0                | X21 = 1152921515234912720 (0x10000002797B69D0);//ML01
        // 0x00B26738: CBNZ x19, #0xb26740        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00B2673C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002797B69D0, ????);
        label_3:
        // 0x00B26740: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26744: MOV x0, x19                | X0 = 1152921504719998976 (0x1000000006BE9000);//ML01
        // 0x00B26748: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00B2674C: MOV x2, x21                | X2 = 1152921515234912720 (0x10000002797B69D0);//ML01
        // 0x00B26750: BL #0x2759700              | AddField(fieldName:  val_4, value:  val_3.m_Handle);
        AddField(fieldName:  val_4, value:  val_3.m_Handle);
        // 0x00B26754: B #0xb266f0                |  goto label_4;                          
        goto label_4;
        // 0x00B26758: BL #0x981060               | X0 = sub_981060( ?? typeof(UnityEngine.WWWForm), ????);
        // 0x00B2675C: LDR x20, [x0]              | X20 = ;                                 
        val_6 = null;
        // 0x00B26760: BL #0x980920               | X0 = sub_980920( ?? typeof(UnityEngine.WWWForm), ????);
        // 0x00B26764: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x00B26768: B #0xb26774                |  goto label_5;                          
        goto label_5;
        label_2:
        // 0x00B2676C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_6 = 0;
        // 0x00B26770: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        val_7 = 1;
        label_5:
        // 0x00B26774: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00B26778: LDR x8, [x8, #0x698]       | X8 = 1152921510818915600;               
        // 0x00B2677C: ADD x0, sp, #0x10          | X0 = (1152921515234912672 + 16) = 1152921515234912688 (0x10000002797B69B0);
        // 0x00B26780: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, System.String>::Dispose();
        // 0x00B26784: BL #0xf3acac               | null.Dispose();                         
        0.Dispose();
        // 0x00B26788: TBNZ w21, #0, #0xb2679c    | if ((0x1 & 0x1) != 0) goto label_7;     
        if((val_7 & 1) != 0)
        {
            goto label_7;
        }
        // 0x00B2678C: CBZ x20, #0xb2679c         | if (0x0 == 0) goto label_7;             
        if(val_6 == 0)
        {
            goto label_7;
        }
        // 0x00B26790: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26794: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00B26798: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_7:
        // 0x00B2679C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B267A0: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B267A4: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B267A8: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B267AC: TBZ w8, #0, #0xb267bc      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B267B0: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B267B4: CBNZ w8, #0xb267bc         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B267B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_9:
        // 0x00B267BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B267C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B267C4: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_5 = VersionMgr.Instance;
        // 0x00B267C8: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B267CC: CBNZ x20, #0xb267d4        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B267D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B267D4: LDR w8, [x20, #0x88]       | W8 = val_5.userType; //P2               
        // 0x00B267D8: ADD x0, sp, #0xc           | X0 = (1152921515234912672 + 12) = 1152921515234912684 (0x10000002797B69AC);
        // 0x00B267DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B267E0: STR w8, [sp, #0xc]         | stack[1152921515234912684] = val_5.userType;  //  dest_result_addr=1152921515234912684
        // 0x00B267E4: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00B267E8: MOV x20, x0                | X20 = 1152921515234912684 (0x10000002797B69AC);//ML01
        // 0x00B267EC: CBNZ x19, #0xb267f4        | if ( != 0) goto label_11;               
        if(null != 0)
        {
            goto label_11;
        }
        // 0x00B267F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002797B69AC, ????);
        label_11:
        // 0x00B267F4: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B267F8: LDR x8, [x8, #0x440]       | X8 = (string**)(1152921512771228272)("userType");
        // 0x00B267FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26800: MOV x0, x19                | X0 = 1152921504719998976 (0x1000000006BE9000);//ML01
        // 0x00B26804: MOV x2, x20                | X2 = 1152921515234912684 (0x10000002797B69AC);//ML01
        // 0x00B26808: LDR x1, [x8]               | X1 = "userType";                        
        // 0x00B2680C: BL #0x2759700              | AddField(fieldName:  "userType", value:  val_5.userType);
        AddField(fieldName:  "userType", value:  val_5.userType);
        // 0x00B26810: MOV x0, x19                | X0 = 1152921504719998976 (0x1000000006BE9000);//ML01
        // 0x00B26814: SUB sp, x29, #0x40         | SP = (1152921515234912800 - 64) = 1152921515234912736 (0x10000002797B69E0);
        // 0x00B26818: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2681C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B26820: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B26824: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B26828: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B2682C: RET                        |  return (UnityEngine.WWWForm)typeof(UnityEngine.WWWForm);
        return (UnityEngine.WWWForm)val_1;
        //  |  // // {name=val_0, type=UnityEngine.WWWForm, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B26830 (11692080), len: 1424  VirtAddr: 0x00B26830 RVA: 0x00B26830 token: 100694760 methodIndex: 24776 delegateWrapperIndex: 0 methodInvoker: 0
    public void Pay(Mihua.SDK.PayInfo payInfo)
    {
        //
        // Disasemble & Code
        // 0x00B26830: STP x24, x23, [sp, #-0x40]! | stack[1152921515235166208] = ???;  stack[1152921515235166216] = ???;  //  dest_result_addr=1152921515235166208 |  dest_result_addr=1152921515235166216
        // 0x00B26834: STP x22, x21, [sp, #0x10]  | stack[1152921515235166224] = ???;  stack[1152921515235166232] = ???;  //  dest_result_addr=1152921515235166224 |  dest_result_addr=1152921515235166232
        // 0x00B26838: STP x20, x19, [sp, #0x20]  | stack[1152921515235166240] = ???;  stack[1152921515235166248] = ???;  //  dest_result_addr=1152921515235166240 |  dest_result_addr=1152921515235166248
        // 0x00B2683C: STP x29, x30, [sp, #0x30]  | stack[1152921515235166256] = ???;  stack[1152921515235166264] = ???;  //  dest_result_addr=1152921515235166256 |  dest_result_addr=1152921515235166264
        // 0x00B26840: ADD x29, sp, #0x30         | X29 = (1152921515235166208 + 48) = 1152921515235166256 (0x10000002797F4830);
        // 0x00B26844: SUB sp, sp, #0x10          | SP = (1152921515235166208 - 16) = 1152921515235166192 (0x10000002797F47F0);
        // 0x00B26848: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2684C: LDRB w8, [x20, #0x746]     | W8 = (bool)static_value_03733746;       
        // 0x00B26850: MOV x21, x1                | X21 = payInfo;//m1                      
        // 0x00B26854: MOV x19, x0                | X19 = 1152921515235178272 (0x10000002797F7720);//ML01
        // 0x00B26858: TBNZ w8, #0, #0xb26874     | if (static_value_03733746 == true) goto label_0;
        // 0x00B2685C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00B26860: LDR x8, [x8, #0xf38]       | X8 = 0x2B8AC5C;                         
        // 0x00B26864: LDR w0, [x8]               | W0 = 0x1D5;                             
        // 0x00B26868: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D5, ????);      
        // 0x00B2686C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B26870: STRB w8, [x20, #0x746]     | static_value_03733746 = true;            //  dest_result_addr=57882438
        label_0:
        // 0x00B26874: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00B26878: LDR x8, [x8, #0x5f0]       | X8 = 1152921504861265920;               
        // 0x00B2687C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Linq.JObject);
        Newtonsoft.Json.Linq.JObject val_1 = null;
        // 0x00B26880: STP xzr, xzr, [sp]         | stack[1152921515235166192] = 0x0;  stack[1152921515235166200] = 0x0;  //  dest_result_addr=1152921515235166192 |  dest_result_addr=1152921515235166200
        // 0x00B26884: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
        // 0x00B26888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2688C: MOV x20, x0                | X20 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B26890: BL #0x2924c68              | .ctor();                                
        val_1 = new Newtonsoft.Json.Linq.JObject();
        // 0x00B26894: CBNZ x21, #0xb2689c        | if (payInfo != null) goto label_1;      
        if(payInfo != null)
        {
            goto label_1;
        }
        // 0x00B26898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B2689C: LDR x1, [x21, #0x20]       | X1 = payInfo.productName; //P2          
        // 0x00B268A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B268A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B268A8: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_2 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B268AC: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B268B0: CBNZ x20, #0xb268b8        | if ( != 0) goto label_2;                
        if(null != 0)
        {
            goto label_2;
        }
        // 0x00B268B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B268B8: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B268BC: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921515235037392)("body");
        // 0x00B268C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B268C4: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B268C8: MOV x2, x22                | X2 = val_2;//m1                         
        // 0x00B268CC: LDR x1, [x8]               | X1 = "body";                            
        // 0x00B268D0: BL #0x2926f6c              | Add(propertyName:  "body", value:  val_2);
        Add(propertyName:  "body", value:  val_2);
        // 0x00B268D4: LDR x1, [x21, #0x20]       | X1 = payInfo.productName; //P2          
        // 0x00B268D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B268DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B268E0: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_3 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B268E4: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00B268E8: CBNZ x20, #0xb268f0        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00B268EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00B268F0: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B268F4: LDR x8, [x8, #0xc28]       | X8 = (string**)(1152921515235045664)("subject");
        // 0x00B268F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B268FC: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B26900: MOV x2, x22                | X2 = val_3;//m1                         
        // 0x00B26904: LDR x1, [x8]               | X1 = "subject";                         
        // 0x00B26908: BL #0x2926f6c              | Add(propertyName:  "subject", value:  val_3);
        Add(propertyName:  "subject", value:  val_3);
        // 0x00B2690C: LDR x1, [x21, #0x18]       | X1 = payInfo.orderId; //P2              
        // 0x00B26910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26914: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26918: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_4 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B2691C: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B26920: CBNZ x20, #0xb26928        | if ( != 0) goto label_4;                
        if(null != 0)
        {
            goto label_4;
        }
        // 0x00B26924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00B26928: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00B2692C: LDR x8, [x8, #0xde0]       | X8 = (string**)(1152921515235053952)("out_trade_no");
        // 0x00B26930: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26934: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B26938: MOV x2, x22                | X2 = val_4;//m1                         
        // 0x00B2693C: LDR x1, [x8]               | X1 = "out_trade_no";                    
        // 0x00B26940: BL #0x2926f6c              | Add(propertyName:  "out_trade_no", value:  val_4);
        Add(propertyName:  "out_trade_no", value:  val_4);
        // 0x00B26944: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B26948: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921515235054048)("30m");
        // 0x00B2694C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26954: LDR x1, [x8]               | X1 = "30m";                             
        // 0x00B26958: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_5 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B2695C: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00B26960: CBNZ x20, #0xb26968        | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x00B26964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00B26968: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B2696C: LDR x8, [x8, #0xf50]       | X8 = (string**)(1152921515235058224)("timeout_express");
        // 0x00B26970: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26974: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B26978: MOV x2, x22                | X2 = val_5;//m1                         
        // 0x00B2697C: LDR x1, [x8]               | X1 = "timeout_express";                 
        // 0x00B26980: BL #0x2926f6c              | Add(propertyName:  "timeout_express", value:  val_5);
        Add(propertyName:  "timeout_express", value:  val_5);
        // 0x00B26984: CBNZ x21, #0xb2698c        | if (payInfo != null) goto label_6;      
        if(payInfo != null)
        {
            goto label_6;
        }
        // 0x00B26988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Linq.JObject), ????);
        label_6:
        // 0x00B2698C: LDR x1, [x21, #0x10]       | X1 = payInfo.amount; //P2               
        // 0x00B26990: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26994: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26998: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_6 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B2699C: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B269A0: CBNZ x20, #0xb269a8        | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x00B269A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_7:
        // 0x00B269A8: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B269AC: LDR x8, [x8, #0x908]       | X8 = (string**)(1152921515235066528)("total_amount");
        // 0x00B269B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B269B4: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B269B8: MOV x2, x22                | X2 = val_6;//m1                         
        // 0x00B269BC: LDR x1, [x8]               | X1 = "total_amount";                    
        // 0x00B269C0: BL #0x2926f6c              | Add(propertyName:  "total_amount", value:  val_6);
        Add(propertyName:  "total_amount", value:  val_6);
        // 0x00B269C4: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x00B269C8: LDR x8, [x8, #0x830]       | X8 = (string**)(1152921515235066624)("QUICK_MSECURITY_PAY");
        // 0x00B269CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B269D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B269D4: LDR x1, [x8]               | X1 = "QUICK_MSECURITY_PAY";             
        // 0x00B269D8: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_7 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B269DC: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00B269E0: CBNZ x20, #0xb269e8        | if ( != 0) goto label_8;                
        if(null != 0)
        {
            goto label_8;
        }
        // 0x00B269E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_8:
        // 0x00B269E8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00B269EC: LDR x8, [x8, #0xb00]       | X8 = (string**)(1152921515235070832)("product_code");
        // 0x00B269F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B269F4: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B269F8: MOV x2, x22                | X2 = val_7;//m1                         
        // 0x00B269FC: LDR x1, [x8]               | X1 = "product_code";                    
        // 0x00B26A00: BL #0x2926f6c              | Add(propertyName:  "product_code", value:  val_7);
        Add(propertyName:  "product_code", value:  val_7);
        // 0x00B26A04: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B26A08: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B26A0C: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x00B26A10: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26A14: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B26A18: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B26A1C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26A20: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B26A24: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26A28: CBNZ x21, #0xb26a30        | if (payInfo != null) goto label_9;      
        if(payInfo != null)
        {
            goto label_9;
        }
        // 0x00B26A2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_9:
        // 0x00B26A30: LDR x23, [x21, #0x48]      | X23 = payInfo.serverId; //P2            
        // 0x00B26A34: CBNZ x22, #0xb26a3c        | if ( != null) goto label_10;            
        if(null != null)
        {
            goto label_10;
        }
        // 0x00B26A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_10:
        // 0x00B26A3C: CBZ x23, #0xb26a60         | if (payInfo.serverId == null) goto label_12;
        if(payInfo.serverId == null)
        {
            goto label_12;
        }
        // 0x00B26A40: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B26A44: MOV x0, x23                | X0 = payInfo.serverId;//m1              
        // 0x00B26A48: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B26A4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? payInfo.serverId, ????);
        // 0x00B26A50: CBNZ x0, #0xb26a60         | if (payInfo.serverId != null) goto label_12;
        if(payInfo.serverId != null)
        {
            goto label_12;
        }
        // 0x00B26A54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? payInfo.serverId, ????);
        // 0x00B26A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26A5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payInfo.serverId, ????);
        label_12:
        // 0x00B26A60: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B26A64: CBNZ w8, #0xb26a74         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_13;
        // 0x00B26A68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? payInfo.serverId, ????);
        // 0x00B26A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26A70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payInfo.serverId, ????);
        label_13:
        // 0x00B26A74: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = payInfo.serverId;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = payInfo.serverId;
        // 0x00B26A78: CBNZ x21, #0xb26a80        | if (payInfo != null) goto label_14;     
        if(payInfo != null)
        {
            goto label_14;
        }
        // 0x00B26A7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? payInfo.serverId, ????);
        label_14:
        // 0x00B26A80: LDR x23, [x21, #0x30]      | X23 = payInfo.roleId; //P2              
        // 0x00B26A84: CBZ x23, #0xb26aa8         | if (payInfo.roleId == null) goto label_16;
        if(payInfo.roleId == null)
        {
            goto label_16;
        }
        // 0x00B26A88: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B26A8C: MOV x0, x23                | X0 = payInfo.roleId;//m1                
        // 0x00B26A90: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B26A94: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? payInfo.roleId, ????);
        // 0x00B26A98: CBNZ x0, #0xb26aa8         | if (payInfo.roleId != null) goto label_16;
        if(payInfo.roleId != null)
        {
            goto label_16;
        }
        // 0x00B26A9C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? payInfo.roleId, ????);
        // 0x00B26AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26AA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payInfo.roleId, ????);
        label_16:
        // 0x00B26AA8: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B26AAC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B26AB0: B.HI #0xb26ac0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_17;
        // 0x00B26AB4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? payInfo.roleId, ????);
        // 0x00B26AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26ABC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payInfo.roleId, ????);
        label_17:
        // 0x00B26AC0: STR x23, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = payInfo.roleId;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = payInfo.roleId;
        // 0x00B26AC4: CBNZ x21, #0xb26acc        | if (payInfo != null) goto label_18;     
        if(payInfo != null)
        {
            goto label_18;
        }
        // 0x00B26AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? payInfo.roleId, ????);
        label_18:
        // 0x00B26ACC: LDR x21, [x21, #0x28]      | X21 = payInfo.productType; //P2         
        // 0x00B26AD0: CBZ x21, #0xb26af4         | if (payInfo.productType == null) goto label_20;
        if(payInfo.productType == null)
        {
            goto label_20;
        }
        // 0x00B26AD4: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B26AD8: MOV x0, x21                | X0 = payInfo.productType;//m1           
        // 0x00B26ADC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B26AE0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? payInfo.productType, ????);
        // 0x00B26AE4: CBNZ x0, #0xb26af4         | if (payInfo.productType != null) goto label_20;
        if(payInfo.productType != null)
        {
            goto label_20;
        }
        // 0x00B26AE8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? payInfo.productType, ????);
        // 0x00B26AEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26AF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payInfo.productType, ????);
        label_20:
        // 0x00B26AF4: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B26AF8: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B26AFC: B.HI #0xb26b0c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_21;
        // 0x00B26B00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? payInfo.productType, ????);
        // 0x00B26B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26B08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? payInfo.productType, ????);
        label_21:
        // 0x00B26B0C: STR x21, [x22, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = payInfo.productType;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = payInfo.productType;
        // 0x00B26B10: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
        // 0x00B26B14: LDR x8, [x8, #0xa58]       | X8 = (string**)(1152921515235083216)("{0}:{1}:{2}");
        // 0x00B26B18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26B1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26B20: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26B24: LDR x1, [x8]               | X1 = "{0}:{1}:{2}";                     
        // 0x00B26B28: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}:{1}:{2}");
        string val_8 = EString.EFormat(format:  0, args:  "{0}:{1}:{2}");
        // 0x00B26B2C: MOV x1, x0                 | X1 = val_8;//m1                         
        // 0x00B26B30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26B34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26B38: BL #0x2930740              | X0 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        Newtonsoft.Json.Linq.JToken val_9 = Newtonsoft.Json.Linq.JToken.op_Implicit(value:  0);
        // 0x00B26B3C: MOV x21, x0                | X21 = val_9;//m1                        
        // 0x00B26B40: CBNZ x20, #0xb26b48        | if ( != 0) goto label_22;               
        if(null != 0)
        {
            goto label_22;
        }
        // 0x00B26B44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_22:
        // 0x00B26B48: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B26B4C: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921515235091504)("passback_params");
        // 0x00B26B50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26B54: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B26B58: MOV x2, x21                | X2 = val_9;//m1                         
        // 0x00B26B5C: LDR x1, [x8]               | X1 = "passback_params";                 
        // 0x00B26B60: BL #0x2926f6c              | Add(propertyName:  "passback_params", value:  val_9);
        Add(propertyName:  "passback_params", value:  val_9);
        // 0x00B26B64: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00B26B68: LDR x8, [x8, #0x420]       | X8 = 1152921504911425536;               
        // 0x00B26B6C: LDR x21, [x19, #0x10]      | X21 = this.payParams; //P2              
        // 0x00B26B70: LDR x0, [x8]               | X0 = typeof(VersionMgr);                
        // 0x00B26B74: LDRB w8, [x0, #0x10a]      | W8 = VersionMgr.__il2cppRuntimeField_10A;
        // 0x00B26B78: TBZ w8, #0, #0xb26b88      | if (VersionMgr.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x00B26B7C: LDR w8, [x0, #0xbc]        | W8 = VersionMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00B26B80: CBNZ w8, #0xb26b88         | if (VersionMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x00B26B84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(VersionMgr), ????);
        label_24:
        // 0x00B26B88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26B8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26B90: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_10 = VersionMgr.Instance;
        // 0x00B26B94: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00B26B98: CBNZ x22, #0xb26ba0        | if (val_10 != null) goto label_25;      
        if(val_10 != null)
        {
            goto label_25;
        }
        // 0x00B26B9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_25:
        // 0x00B26BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26BA4: MOV x0, x22                | X0 = val_10;//m1                        
        // 0x00B26BA8: BL #0xe27dac               | X0 = val_10.get_currentVS();            
        VersionInfo val_11 = val_10.currentVS;
        // 0x00B26BAC: MOV x22, x0                | X22 = val_11;//m1                       
        // 0x00B26BB0: CBNZ x22, #0xb26bb8        | if (val_11 != null) goto label_26;      
        if(val_11 != null)
        {
            goto label_26;
        }
        // 0x00B26BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_26:
        // 0x00B26BB8: LDR x22, [x22, #0xb0]      | X22 = val_11.paycburl; //P2             
        // 0x00B26BBC: LDR x23, [x19, #0x20]      | X23 = this.callBackName; //P2           
        // 0x00B26BC0: CBNZ x22, #0xb26bc8        | if (val_11.paycburl != null) goto label_27;
        if(val_11.paycburl != null)
        {
            goto label_27;
        }
        // 0x00B26BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_27:
        // 0x00B26BC8: ADRP x24, #0x3675000       | X24 = 57102336 (0x3675000);             
        // 0x00B26BCC: LDR x24, [x24, #0x7a8]     | X24 = (string**)(1152921515235112096)("@pay");
        // 0x00B26BD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26BD4: MOV x0, x22                | X0 = val_11.paycburl;//m1               
        // 0x00B26BD8: MOV x2, x23                | X2 = this.callBackName;//m1             
        // 0x00B26BDC: LDR x1, [x24]              | X1 = "@pay";                            
        // 0x00B26BE0: BL #0x18ae7e4              | X0 = val_11.paycburl.Replace(oldValue:  "@pay", newValue:  this.callBackName);
        string val_12 = val_11.paycburl.Replace(oldValue:  "@pay", newValue:  this.callBackName);
        // 0x00B26BE4: MOV x22, x0                | X22 = val_12;//m1                       
        // 0x00B26BE8: CBNZ x21, #0xb26bf0        | if (this.payParams != null) goto label_28;
        if(this.payParams != null)
        {
            goto label_28;
        }
        // 0x00B26BEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_28:
        // 0x00B26BF0: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B26BF4: ADRP x23, #0x35c7000       | X23 = 56389632 (0x35C7000);             
        // 0x00B26BF8: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921515234407456)("notify_url");
        // 0x00B26BFC: LDR x23, [x23, #0x878]     | X23 = 1152921514160897264;              
        // 0x00B26C00: MOV x0, x21                | X0 = this.payParams;//m1                
        // 0x00B26C04: MOV x2, x22                | X2 = val_12;//m1                        
        // 0x00B26C08: LDR x1, [x8]               | X1 = "notify_url";                      
        // 0x00B26C0C: LDR x3, [x23]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::set_Item(System.String key, System.String value);
        // 0x00B26C10: BL #0x23fc55c              | this.payParams.set_Item(key:  "notify_url", value:  val_12);
        this.payParams.set_Item(key:  "notify_url", value:  val_12);
        // 0x00B26C14: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B26C18: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00B26C1C: LDR x21, [x19, #0x10]      | X21 = this.payParams; //P2              
        // 0x00B26C20: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
        // 0x00B26C24: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
        // 0x00B26C28: TBZ w8, #0, #0xb26c38      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00B26C2C: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
        // 0x00B26C30: CBNZ w8, #0xb26c38         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00B26C34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
        label_30:
        // 0x00B26C38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26C40: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_13 = System.DateTime.Now;
        // 0x00B26C44: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x00B26C48: LDR x8, [x8]               | X8 = (string**)(1152921515235120368)("yyyy-MM-dd hh:mm:ss");
        // 0x00B26C4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26C50: LDR x8, [x8]               | X8 = "yyyy-MM-dd hh:mm:ss";             
        // 0x00B26C54: STP x0, x1, [sp]           | stack[1152921515235166192] = val_13.ticks._ticks;  stack[1152921515235166200] = val_13.kind;  //  dest_result_addr=1152921515235166192 |  dest_result_addr=1152921515235166200
        // 0x00B26C58: MOV x0, sp                 | X0 = 1152921515235166192 (0x10000002797F47F0);//ML01
        // 0x00B26C5C: MOV x1, x8                 | X1 = 1152921515235120368 (0x10000002797E94F0);//ML01
        // 0x00B26C60: BL #0x1bb12d0              | X0 = val_13.ticks._ticks.ToString(format:  "yyyy-MM-dd hh:mm:ss");
        string val_14 = val_13.ticks._ticks.ToString(format:  "yyyy-MM-dd hh:mm:ss");
        // 0x00B26C64: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00B26C68: CBNZ x21, #0xb26c70        | if (this.payParams != null) goto label_31;
        if(this.payParams != null)
        {
            goto label_31;
        }
        // 0x00B26C6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_31:
        // 0x00B26C70: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B26C74: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921515234407360)("timestamp");
        // 0x00B26C78: LDR x3, [x23]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::set_Item(System.String key, System.String value);
        // 0x00B26C7C: MOV x0, x21                | X0 = this.payParams;//m1                
        // 0x00B26C80: MOV x2, x22                | X2 = val_14;//m1                        
        // 0x00B26C84: LDR x1, [x8]               | X1 = "timestamp";                       
        // 0x00B26C88: BL #0x23fc55c              | this.payParams.set_Item(key:  "timestamp", value:  val_14);
        this.payParams.set_Item(key:  "timestamp", value:  val_14);
        // 0x00B26C8C: LDR x21, [x19, #0x10]      | X21 = this.payParams; //P2              
        // 0x00B26C90: CBNZ x20, #0xb26c98        | if ( != 0) goto label_32;               
        if(null != 0)
        {
            goto label_32;
        }
        // 0x00B26C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.payParams, ????);
        label_32:
        // 0x00B26C98: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B26C9C: LDR x8, [x8, #0x4f8]       | X8 = 1152921507604262304;               
        // 0x00B26CA0: LDR x22, [x8]              | X22 = typeof(Newtonsoft.Json.JsonConverter[]);
        // 0x00B26CA4: MOV x0, x22                | X0 = 1152921507604262304 (0x10000000B2A8EDA0);//ML01
        // 0x00B26CA8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Newtonsoft.Json.JsonConverter[]), ????);
        // 0x00B26CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26CB0: MOV x0, x22                | X0 = 1152921507604262304 (0x10000000B2A8EDA0);//ML01
        // 0x00B26CB4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Newtonsoft.Json.JsonConverter[]), ????);
        // 0x00B26CB8: MOV x2, x0                 | X2 = 1152921507604262304 (0x10000000B2A8EDA0);//ML01
        // 0x00B26CBC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B26CC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26CC4: MOV x0, x20                | X0 = 1152921504861265920 (0x100000000F2A2000);//ML01
        // 0x00B26CC8: BL #0x292bd78              | X0 = ToString(formatting:  0, converters:  null);
        string val_15 = ToString(formatting:  0, converters:  null);
        // 0x00B26CCC: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00B26CD0: CBNZ x21, #0xb26cd8        | if (this.payParams != null) goto label_33;
        if(this.payParams != null)
        {
            goto label_33;
        }
        // 0x00B26CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_33:
        // 0x00B26CD8: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00B26CDC: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921515234406880)("biz_content");
        // 0x00B26CE0: LDR x3, [x23]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::set_Item(System.String key, System.String value);
        // 0x00B26CE4: MOV x0, x21                | X0 = this.payParams;//m1                
        // 0x00B26CE8: MOV x2, x20                | X2 = val_15;//m1                        
        // 0x00B26CEC: LDR x1, [x8]               | X1 = "biz_content";                     
        // 0x00B26CF0: BL #0x23fc55c              | this.payParams.set_Item(key:  "biz_content", value:  val_15);
        this.payParams.set_Item(key:  "biz_content", value:  val_15);
        // 0x00B26CF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26CF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26CFC: BL #0xe27ca8               | X0 = VersionMgr.get_Instance();         
        VersionMgr val_16 = VersionMgr.Instance;
        // 0x00B26D00: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x00B26D04: CBNZ x20, #0xb26d0c        | if (val_16 != null) goto label_34;      
        if(val_16 != null)
        {
            goto label_34;
        }
        // 0x00B26D08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_34:
        // 0x00B26D0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26D10: MOV x0, x20                | X0 = val_16;//m1                        
        // 0x00B26D14: BL #0xe27dac               | X0 = val_16.get_currentVS();            
        VersionInfo val_17 = val_16.currentVS;
        // 0x00B26D18: MOV x20, x0                | X20 = val_17;//m1                       
        // 0x00B26D1C: CBNZ x20, #0xb26d24        | if (val_17 != null) goto label_35;      
        if(val_17 != null)
        {
            goto label_35;
        }
        // 0x00B26D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_35:
        // 0x00B26D24: LDR x20, [x20, #0xb8]      | X20 = val_17.orderurl; //P2             
        // 0x00B26D28: CBNZ x20, #0xb26d30        | if (val_17.orderurl != null) goto label_36;
        if(val_17.orderurl != null)
        {
            goto label_36;
        }
        // 0x00B26D2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_36:
        // 0x00B26D30: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B26D34: LDR x1, [x24]              | X1 = "@pay";                            
        // 0x00B26D38: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921515234407664)("zhifubao");
        // 0x00B26D3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26D40: MOV x0, x20                | X0 = val_17.orderurl;//m1               
        // 0x00B26D44: LDR x2, [x8]               | X2 = "zhifubao";                        
        // 0x00B26D48: BL #0x18ae7e4              | X0 = val_17.orderurl.Replace(oldValue:  "@pay", newValue:  "zhifubao");
        string val_18 = val_17.orderurl.Replace(oldValue:  "@pay", newValue:  "zhifubao");
        // 0x00B26D4C: MOV x20, x0                | X20 = val_18;//m1                       
        // 0x00B26D50: MOV x0, x19                | X0 = 1152921515235178272 (0x10000002797F7720);//ML01
        // 0x00B26D54: BL #0xb2663c               | X0 = this.BuildOrderParam2WWWForm();    
        UnityEngine.WWWForm val_19 = this.BuildOrderParam2WWWForm();
        // 0x00B26D58: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x00B26D5C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
        // 0x00B26D60: LDR x8, [x8, #0xae8]       | X8 = 1152921515235153248;               
        // 0x00B26D64: LDR x9, [x9, #0x658]       | X9 = 1152921504920424448;               
        // 0x00B26D68: MOV x22, x0                | X22 = val_19;//m1                       
        // 0x00B26D6C: LDR x21, [x8]              | X21 = System.Void AMihuaPay::SignCallBack(bool success, string arg);
        // 0x00B26D70: LDR x8, [x9]               | X8 = typeof(Mihua.SDK.SdkwwwCallBack);  
        // 0x00B26D74: MOV x0, x8                 | X0 = 1152921504920424448 (0x1000000012B0D000);//ML01
        Mihua.SDK.SdkwwwCallBack val_20 = null;
        // 0x00B26D78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.SDK.SdkwwwCallBack), ????);
        // 0x00B26D7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26D80: MOV x1, x19                | X1 = 1152921515235178272 (0x10000002797F7720);//ML01
        // 0x00B26D84: MOV x2, x21                | X2 = 1152921515235153248 (0x10000002797F1560);//ML01
        // 0x00B26D88: MOV x23, x0                | X23 = 1152921504920424448 (0x1000000012B0D000);//ML01
        // 0x00B26D8C: BL #0xac27f4               | .ctor(object:  this, method:  System.Void AMihuaPay::SignCallBack(bool success, string arg));
        val_20 = new Mihua.SDK.SdkwwwCallBack(object:  this, method:  System.Void AMihuaPay::SignCallBack(bool success, string arg));
        // 0x00B26D90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26D94: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B26D98: MOV x1, x20                | X1 = val_18;//m1                        
        // 0x00B26D9C: MOV x2, x22                | X2 = val_19;//m1                        
        // 0x00B26DA0: MOV x3, x23                | X3 = 1152921504920424448 (0x1000000012B0D000);//ML01
        // 0x00B26DA4: BL #0xac2170               | Mihua.SDK.Sdkwww.Request(url:  0, wwwForm:  val_18, callBack:  val_19);
        Mihua.SDK.Sdkwww.Request(url:  0, wwwForm:  val_18, callBack:  val_19);
        // 0x00B26DA8: SUB sp, x29, #0x30         | SP = (1152921515235166256 - 48) = 1152921515235166208 (0x10000002797F4800);
        // 0x00B26DAC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B26DB0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B26DB4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B26DB8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B26DBC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B26DC0 (11693504), len: 1284  VirtAddr: 0x00B26DC0 RVA: 0x00B26DC0 token: 100694761 methodIndex: 24777 delegateWrapperIndex: 0 methodInvoker: 0
    private void SignCallBack(bool success, string arg)
    {
        //
        // Disasemble & Code
        //  | 
        System.Text.Encoding val_16;
        //  | 
        var val_17;
        // 0x00B26DC0: STP x24, x23, [sp, #-0x40]! | stack[1152921515235501008] = ???;  stack[1152921515235501016] = ???;  //  dest_result_addr=1152921515235501008 |  dest_result_addr=1152921515235501016
        // 0x00B26DC4: STP x22, x21, [sp, #0x10]  | stack[1152921515235501024] = ???;  stack[1152921515235501032] = ???;  //  dest_result_addr=1152921515235501024 |  dest_result_addr=1152921515235501032
        // 0x00B26DC8: STP x20, x19, [sp, #0x20]  | stack[1152921515235501040] = ???;  stack[1152921515235501048] = ???;  //  dest_result_addr=1152921515235501040 |  dest_result_addr=1152921515235501048
        // 0x00B26DCC: STP x29, x30, [sp, #0x30]  | stack[1152921515235501056] = ???;  stack[1152921515235501064] = ???;  //  dest_result_addr=1152921515235501056 |  dest_result_addr=1152921515235501064
        // 0x00B26DD0: ADD x29, sp, #0x30         | X29 = (1152921515235501008 + 48) = 1152921515235501056 (0x1000000279846400);
        // 0x00B26DD4: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B26DD8: LDRB w8, [x22, #0x747]     | W8 = (bool)static_value_03733747;       
        // 0x00B26DDC: MOV x19, x2                | X19 = arg;//m1                          
        // 0x00B26DE0: MOV w21, w1                | W21 = success;//m1                      
        val_16 = success;
        // 0x00B26DE4: MOV x20, x0                | X20 = 1152921515235513072 (0x10000002798492F0);//ML01
        // 0x00B26DE8: TBNZ w8, #0, #0xb26e04     | if (static_value_03733747 == true) goto label_0;
        // 0x00B26DEC: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B26DF0: LDR x8, [x8, #0x5d0]       | X8 = 0x2B8AC60;                         
        // 0x00B26DF4: LDR w0, [x8]               | W0 = 0x1D6;                             
        // 0x00B26DF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D6, ????);      
        // 0x00B26DFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B26E00: STRB w8, [x22, #0x747]     | static_value_03733747 = true;            //  dest_result_addr=57882439
        label_0:
        // 0x00B26E04: TBZ w21, #0, #0xb27198     | if (success == false) goto label_1;     
        if(val_16 == false)
        {
            goto label_1;
        }
        // 0x00B26E08: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B26E0C: LDR x8, [x8, #0x1a0]       | X8 = 1152921515235397344;               
        // 0x00B26E10: LDR x2, [x8]               | X2 = public static Newtonsoft.Json.Linq.JObject JSON::parse<Newtonsoft.Json.Linq.JObject>(string json);
        // 0x00B26E14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26E18: MOV x1, x19                | X1 = arg;//m1                           
        // 0x00B26E1C: BL #0xfd8784               | X0 = JSON.parse<ProductInfo[]>(json:  0);
        ProductInfo[] val_1 = JSON.parse<ProductInfo[]>(json:  0);
        // 0x00B26E20: MOV x21, x0                | X21 = val_1;//m1                        
        val_16 = val_1;
        // 0x00B26E24: CBZ x21, #0xb27178         | if (val_1 == null) goto label_3;        
        if(val_16 == null)
        {
            goto label_3;
        }
        // 0x00B26E28: ADRP x22, #0x365e000       | X22 = 57008128 (0x365E000);             
        // 0x00B26E2C: LDR x22, [x22, #0x8b8]     | X22 = (string**)(1152921515235435232)("sign");
        // 0x00B26E30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26E34: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B26E38: LDR x1, [x22]              | X1 = "sign";                            
        // 0x00B26E3C: BL #0x2926ff0              | X0 = val_1.ContainsKey(key:  "sign");   
        bool val_2 = val_16.ContainsKey(key:  "sign");
        // 0x00B26E40: TBZ w0, #0, #0xb27178      | if (val_2 == false) goto label_3;       
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B26E44: MOV x0, x20                | X0 = 1152921515235513072 (0x10000002798492F0);//ML01
        // 0x00B26E48: BL #0xb263b8               | X0 = this.BuildOrderParam();            
        string val_3 = this.BuildOrderParam();
        // 0x00B26E4C: LDR x1, [x22]              | X1 = "sign";                            
        // 0x00B26E50: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B26E54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B26E58: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B26E5C: BL #0x2925c6c              | X0 = val_1.get_Item(propertyName:  "sign");
        Newtonsoft.Json.Linq.JToken val_4 = val_16.Item["sign"];
        // 0x00B26E60: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00B26E64: CBNZ x21, #0xb26e6c        | if (val_4 != null) goto label_4;        
        if(val_4 != null)
        {
            goto label_4;
        }
        // 0x00B26E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00B26E6C: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
        // 0x00B26E70: LDR x8, [x8, #0x898]       | X8 = 1152921514976783024;               
        // 0x00B26E74: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B26E78: LDR x1, [x8]               | X1 = public System.String Newtonsoft.Json.Linq.JToken::ToObject<System.String>();
        // 0x00B26E7C: BL #0xfda9f0               | X0 = val_4.ToObject<System.String>();   
        string val_5 = val_4.ToObject<System.String>();
        // 0x00B26E80: ADRP x24, #0x3630000       | X24 = 56819712 (0x3630000);             
        // 0x00B26E84: LDR x24, [x24, #0x3d0]     | X24 = 1152921504954501264;              
        // 0x00B26E88: MOV x21, x0                | X21 = val_5;//m1                        
        val_16 = val_5;
        // 0x00B26E8C: LDR x22, [x24]             | X22 = typeof(System.Object[]);          
        // 0x00B26E90: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26E94: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B26E98: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B26E9C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26EA0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B26EA4: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26EA8: CBNZ x22, #0xb26eb0        | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x00B26EAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_5:
        // 0x00B26EB0: CBZ x20, #0xb26ed4         | if (val_3 == null) goto label_7;        
        if(val_3 == null)
        {
            goto label_7;
        }
        // 0x00B26EB4: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B26EB8: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B26EBC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B26EC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x00B26EC4: CBNZ x0, #0xb26ed4         | if (val_3 != null) goto label_7;        
        if(val_3 != null)
        {
            goto label_7;
        }
        // 0x00B26EC8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
        // 0x00B26ECC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26ED0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_7:
        // 0x00B26ED4: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B26ED8: CBNZ w8, #0xb26ee8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x00B26EDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B26EE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26EE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_8:
        // 0x00B26EE8: STR x20, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;
        // 0x00B26EEC: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B26EF0: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00B26EF4: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00B26EF8: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00B26EFC: TBZ w8, #0, #0xb26f0c      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B26F00: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00B26F04: CBNZ w8, #0xb26f0c         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B26F08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_10:
        // 0x00B26F0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26F10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26F14: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_6 = System.Text.Encoding.UTF8;
        // 0x00B26F18: MOV x2, x0                 | X2 = val_6;//m1                         
        // 0x00B26F1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26F20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26F24: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B26F28: BL #0x276e93c              | X0 = UnityEngine.WWW.EscapeURL(s:  0, e:  val_16);
        string val_7 = UnityEngine.WWW.EscapeURL(s:  0, e:  val_16);
        // 0x00B26F2C: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00B26F30: CBZ x23, #0xb26f54         | if (val_7 == null) goto label_12;       
        if(val_7 == null)
        {
            goto label_12;
        }
        // 0x00B26F34: LDR x8, [x22]              | X8 = ;                                  
        // 0x00B26F38: MOV x0, x23                | X0 = val_7;//m1                         
        // 0x00B26F3C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B26F40: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
        // 0x00B26F44: CBNZ x0, #0xb26f54         | if (val_7 != null) goto label_12;       
        if(val_7 != null)
        {
            goto label_12;
        }
        // 0x00B26F48: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
        // 0x00B26F4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26F50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_12:
        // 0x00B26F54: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B26F58: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B26F5C: B.HI #0xb26f6c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_13;
        // 0x00B26F60: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00B26F64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26F68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_13:
        // 0x00B26F6C: STR x23, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_7;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_7;
        // 0x00B26F70: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B26F74: LDR x8, [x8, #0xb98]       | X8 = (string**)(1152921515235455792)("签名成功 完整订单信息： {0}&sign={1}");
        // 0x00B26F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26F7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26F80: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B26F84: LDR x1, [x8]               | X1 = "签名成功 完整订单信息： {0}&sign={1}";       
        // 0x00B26F88: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "签名成功 完整订单信息： {0}&sign={1}");
        string val_8 = EString.EFormat(format:  0, args:  "签名成功 完整订单信息： {0}&sign={1}");
        // 0x00B26F8C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B26F90: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B26F94: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B26F98: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B26F9C: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B26FA0: TBZ w9, #0, #0xb26fb4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B26FA4: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B26FA8: CBNZ w9, #0xb26fb4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B26FAC: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B26FB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_15:
        // 0x00B26FB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26FB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B26FBC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B26FC0: MOV x1, x22                | X1 = val_8;//m1                         
        // 0x00B26FC4: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_8);
        EDebug.Log(message:  0, isShowStack:  val_8);
        // 0x00B26FC8: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B26FCC: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B26FD0: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B26FD4: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B26FD8: TBZ w8, #0, #0xb26fe8      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B26FDC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B26FE0: CBNZ w8, #0xb26fe8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B26FE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_17:
        // 0x00B26FE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B26FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B26FF0: BL #0x26a8680              | X0 = ZMG.get_PluginsSdkMgr();           
        PluginsSdkMgr val_9 = ZMG.PluginsSdkMgr;
        // 0x00B26FF4: MOV x22, x0                | X22 = val_9;//m1                        
        // 0x00B26FF8: CBNZ x22, #0xb27000        | if (val_9 != null) goto label_18;       
        if(val_9 != null)
        {
            goto label_18;
        }
        // 0x00B26FFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_18:
        // 0x00B27000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27004: MOV x0, x22                | X0 = val_9;//m1                         
        // 0x00B27008: BL #0x137b0bc              | X0 = val_9.get_androidJavaObject();     
        UnityEngine.AndroidJavaObject val_10 = val_9.androidJavaObject;
        // 0x00B2700C: LDR x23, [x24]             | X23 = typeof(System.Object[]);          
        // 0x00B27010: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00B27014: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27018: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B2701C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B27020: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27024: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B27028: LDR x24, [x24]             | X24 = typeof(System.Object[]);          
        // 0x00B2702C: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27030: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27034: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B27038: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B2703C: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27040: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B27044: MOV x24, x0                | X24 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27048: CBNZ x24, #0xb27050        | if ( != null) goto label_19;            
        if(null != null)
        {
            goto label_19;
        }
        // 0x00B2704C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_19:
        // 0x00B27050: CBZ x20, #0xb27074         | if (val_3 == null) goto label_21;       
        if(val_3 == null)
        {
            goto label_21;
        }
        // 0x00B27054: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B27058: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B2705C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B27060: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x00B27064: CBNZ x0, #0xb27074         | if (val_3 != null) goto label_21;       
        if(val_3 != null)
        {
            goto label_21;
        }
        // 0x00B27068: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
        // 0x00B2706C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27070: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_21:
        // 0x00B27074: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B27078: CBNZ w8, #0xb27088         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_22;
        // 0x00B2707C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B27080: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27084: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_22:
        // 0x00B27088: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2708C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27090: STR x20, [x24, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;
        // 0x00B27094: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_11 = System.Text.Encoding.UTF8;
        // 0x00B27098: MOV x2, x0                 | X2 = val_11;//m1                        
        // 0x00B2709C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B270A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B270A4: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B270A8: BL #0x276e93c              | X0 = UnityEngine.WWW.EscapeURL(s:  0, e:  val_16);
        string val_12 = UnityEngine.WWW.EscapeURL(s:  0, e:  val_16);
        // 0x00B270AC: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00B270B0: CBZ x20, #0xb270d4         | if (val_12 == null) goto label_24;      
        if(val_12 == null)
        {
            goto label_24;
        }
        // 0x00B270B4: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B270B8: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00B270BC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B270C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
        // 0x00B270C4: CBNZ x0, #0xb270d4         | if (val_12 != null) goto label_24;      
        if(val_12 != null)
        {
            goto label_24;
        }
        // 0x00B270C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
        // 0x00B270CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B270D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_24:
        // 0x00B270D4: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B270D8: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B270DC: B.HI #0xb270ec             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_25;
        // 0x00B270E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
        // 0x00B270E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B270E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_25:
        // 0x00B270EC: STR x20, [x24, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_12;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_12;
        // 0x00B270F0: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00B270F4: LDR x8, [x8, #0x5a8]       | X8 = (string**)(1152921515235476400)("{0}&sign={1}");
        // 0x00B270F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B270FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27100: MOV x2, x24                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27104: LDR x1, [x8]               | X1 = "{0}&sign={1}";                    
        // 0x00B27108: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}&sign={1}");
        string val_13 = EString.EFormat(format:  0, args:  "{0}&sign={1}");
        // 0x00B2710C: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00B27110: CBNZ x23, #0xb27118        | if ( != null) goto label_26;            
        if(null != null)
        {
            goto label_26;
        }
        // 0x00B27114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_26:
        // 0x00B27118: CBZ x20, #0xb2713c         | if (val_13 == null) goto label_28;      
        if(val_13 == null)
        {
            goto label_28;
        }
        // 0x00B2711C: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B27120: MOV x0, x20                | X0 = val_13;//m1                        
        // 0x00B27124: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B27128: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
        // 0x00B2712C: CBNZ x0, #0xb2713c         | if (val_13 != null) goto label_28;      
        if(val_13 != null)
        {
            goto label_28;
        }
        // 0x00B27130: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
        // 0x00B27134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27138: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
        label_28:
        // 0x00B2713C: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B27140: CBNZ w8, #0xb27150         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_29;
        // 0x00B27144: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
        // 0x00B27148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2714C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
        label_29:
        // 0x00B27150: STR x20, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_13;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_13;
        // 0x00B27154: CBNZ x22, #0xb2715c        | if (val_10 != null) goto label_30;      
        if(val_10 != null)
        {
            goto label_30;
        }
        // 0x00B27158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_30:
        // 0x00B2715C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00B27160: LDR x8, [x8, #0xa28]       | X8 = (string**)(1152921515235480592)("AlipayMihua");
        // 0x00B27164: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27168: MOV x0, x22                | X0 = val_10;//m1                        
        // 0x00B2716C: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B27170: LDR x1, [x8]               | X1 = "AlipayMihua";                     
        // 0x00B27174: BL #0x20bdbd4              | val_10.Call(methodName:  "AlipayMihua", args:  null);
        val_10.Call(methodName:  "AlipayMihua", args:  null);
        label_3:
        // 0x00B27178: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00B2717C: LDR x8, [x8, #0x868]       | X8 = (string**)(1152921515235480688)("签名成功 arg： {0}");
        // 0x00B27180: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27188: MOV x2, x19                | X2 = arg;//m1                           
        // 0x00B2718C: LDR x1, [x8]               | X1 = "签名成功 arg： {0}";                   
        // 0x00B27190: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "签名成功 arg： {0}");
        string val_14 = EString.EFormat(format:  0, arg0:  "签名成功 arg： {0}");
        // 0x00B27194: B #0xb271d4                |  goto label_31;                         
        goto label_31;
        label_1:
        // 0x00B27198: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B2719C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B271A0: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B271A4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B271A8: TBZ w8, #0, #0xb271b8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x00B271AC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B271B0: CBNZ w8, #0xb271b8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x00B271B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_33:
        // 0x00B271B8: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x00B271BC: LDR x8, [x8, #0x938]       | X8 = (string**)(1152921515235484880)("签名异常，支付失败 arg:");
        // 0x00B271C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B271C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B271C8: MOV x2, x19                | X2 = arg;//m1                           
        // 0x00B271CC: LDR x1, [x8]               | X1 = "签名异常，支付失败 arg:";                  
        // 0x00B271D0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "签名异常，支付失败 arg:");
        string val_15 = System.String.Concat(str0:  0, str1:  "签名异常，支付失败 arg:");
        label_31:
        // 0x00B271D4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B271D8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B271DC: MOV x19, x0                | X19 = val_15;//m1                       
        // 0x00B271E0: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B271E4: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B271E8: TBZ w9, #0, #0xb271fc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_35;
        // 0x00B271EC: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B271F0: CBNZ w9, #0xb271fc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
        // 0x00B271F4: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B271F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_35:
        // 0x00B271FC: MOV x1, x19                | X1 = val_15;//m1                        
        // 0x00B27200: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27204: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B27208: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2720C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27210: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27214: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B27218: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2721C: B #0xb45c10                | EDebug.Log(message:  0, isShowStack:  val_15); return;
        EDebug.Log(message:  0, isShowStack:  val_15);
        return;
    
    }

}
