using UnityEngine;
protected internal enum TypeModel.CallbackType
{
    // Fields
    BeforeSerialize = 0
    ,AfterSerialize = 1
    ,BeforeDeserialize = 2
    ,AfterDeserialize = 3
    

}
