using UnityEngine;
[Serializable]
public class AnimationSpriteSheet1 : MonoBehaviour
{
    // Fields
    public int uvX; //  0x00000018
    public int uvY; //  0x0000001C
    public float fps; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02790A78 (41486968), len: 56  VirtAddr: 0x02790A78 RVA: 0x02790A78 token: 100663300 methodIndex: 57663 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimationSpriteSheet1()
    {
        //
        // Disasemble & Code
        // 0x02790A78: STP x20, x19, [sp, #-0x20]! | stack[1152921515609341120] = ???;  stack[1152921515609341128] = ???;  //  dest_result_addr=1152921515609341120 |  dest_result_addr=1152921515609341128
        // 0x02790A7C: STP x29, x30, [sp, #0x10]  | stack[1152921515609341136] = ???;  stack[1152921515609341144] = ???;  //  dest_result_addr=1152921515609341136 |  dest_result_addr=1152921515609341144
        // 0x02790A80: ADD x29, sp, #0x10         | X29 = (1152921515609341120 + 16) = 1152921515609341136 (0x100000028FCCBCD0);
        // 0x02790A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790A88: MOV x19, x0                | X19 = 1152921515609353152 (0x100000028FCCEBC0);//ML01
        // 0x02790A8C: BL #0x1b76fd4              | this..ctor();                           
        // 0x02790A90: ORR x8, xzr, #0x200000002  | X8 = 8589934594(0x200000002);           
        // 0x02790A94: MOVZ w9, #0x41c0, lsl #16  | W9 = 1103101952 (0x41C00000);//ML01     
        // 0x02790A98: MOVK x8, #0x4              | X8 = 8589934598 (0x200000006);          
        // 0x02790A9C: STR w9, [x19, #0x20]       | this.fps = 24;                           //  dest_result_addr=1152921515609353184
        this.fps = 24f;
        // 0x02790AA0: STR x8, [x19, #0x18]       | this.uvX = 6; this.uvY = 2;              //  dest_result_addr=1152921515609353176 dest_result_addr=1152921515609353180
        this.uvX = 6;
        this.uvY = 2;
        // 0x02790AA4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02790AA8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02790AAC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02790AB0 (41487024), len: 392  VirtAddr: 0x02790AB0 RVA: 0x02790AB0 token: 100663301 methodIndex: 57664 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Update()
    {
        //
        // Disasemble & Code
        // 0x02790AB0: STP d11, d10, [sp, #-0x50]! | stack[1152921515609469456] = ???;  stack[1152921515609469464] = ???;  //  dest_result_addr=1152921515609469456 |  dest_result_addr=1152921515609469464
        // 0x02790AB4: STP d9, d8, [sp, #0x10]    | stack[1152921515609469472] = ???;  stack[1152921515609469480] = ???;  //  dest_result_addr=1152921515609469472 |  dest_result_addr=1152921515609469480
        // 0x02790AB8: STP x22, x21, [sp, #0x20]  | stack[1152921515609469488] = ???;  stack[1152921515609469496] = ???;  //  dest_result_addr=1152921515609469488 |  dest_result_addr=1152921515609469496
        // 0x02790ABC: STP x20, x19, [sp, #0x30]  | stack[1152921515609469504] = ???;  stack[1152921515609469512] = ???;  //  dest_result_addr=1152921515609469504 |  dest_result_addr=1152921515609469512
        // 0x02790AC0: STP x29, x30, [sp, #0x40]  | stack[1152921515609469520] = ???;  stack[1152921515609469528] = ???;  //  dest_result_addr=1152921515609469520 |  dest_result_addr=1152921515609469528
        // 0x02790AC4: ADD x29, sp, #0x40         | X29 = (1152921515609469456 + 64) = 1152921515609469520 (0x100000028FCEB250);
        // 0x02790AC8: SUB sp, sp, #0x10          | SP = (1152921515609469456 - 16) = 1152921515609469440 (0x100000028FCEB200);
        // 0x02790ACC: ADRP x20, #0x3745000       | X20 = 57954304 (0x3745000);             
        // 0x02790AD0: LDRB w8, [x20, #0x9d9]     | W8 = (bool)static_value_037459D9;       
        // 0x02790AD4: MOV x19, x0                | X19 = 1152921515609481536 (0x100000028FCEE140);//ML01
        // 0x02790AD8: TBNZ w8, #0, #0x2790af4    | if (static_value_037459D9 == true) goto label_0;
        // 0x02790ADC: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x02790AE0: LDR x8, [x8, #0xd28]       | X8 = 0x2B8AF04;                         
        // 0x02790AE4: LDR w0, [x8]               | W0 = 0x27F;                             
        // 0x02790AE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x27F, ????);      
        // 0x02790AEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02790AF0: STRB w8, [x20, #0x9d9]     | static_value_037459D9 = true;            //  dest_result_addr=57956825
        label_0:
        // 0x02790AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02790AF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790AFC: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x02790B00: LDR s1, [x19, #0x20]       | S1 = this.fps; //P2                     
        // 0x02790B04: LDP w8, w9, [x19, #0x18]   | W8 = this.uvX; //P2  W9 = this.uvY; //P2  //  | 
        int val_15 = this.uvY;
        // 0x02790B08: FMOV s10, #1.00000000      | S10 = 1;                                
        // 0x02790B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790B10: FMUL s0, s0, s1            | S0 = (val_1 * this.fps);                
        val_1 = val_1 * this.fps;
        // 0x02790B14: MUL w10, w9, w8            | W10 = (this.uvY * this.uvX);            
        int val_2 = val_15 * this.uvX;
        // 0x02790B18: SCVTF s1, w8               | S1 = (float)(this.uvX);                 
        // 0x02790B1C: SCVTF s2, w9               | S2 = (float)(this.uvY);                 
        // 0x02790B20: FCVTZS w8, s0              | W8 = (int)((val_1 * this.fps));         
        // 0x02790B24: FDIV s0, s10, s1           | S0 = (1f / this.uvX);                   
        float val_3 = 1f / (float)this.uvX;
        // 0x02790B28: SDIV w9, w8, w10           | W9 = ((val_1 * this.fps) / (this.uvY * this.uvX));
        val_15 = (int)val_1 / val_2;
        // 0x02790B2C: FDIV s1, s10, s2           | S1 = (1f / this.uvY);                   
        float val_4 = 1f / (float)val_15;
        // 0x02790B30: ADD x0, sp, #8             | X0 = (1152921515609469440 + 8) = 1152921515609469448 (0x100000028FCEB208);
        // 0x02790B34: STR xzr, [sp, #8]          | stack[1152921515609469448] = 0x0;        //  dest_result_addr=1152921515609469448
        // 0x02790B38: MSUB w20, w9, w10, w8      | W20 = (val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX));
        float val_5 = (int)val_1 - (val_15 * val_2);
        // 0x02790B3C: BL #0x2697148              | null..ctor(_x:  float val_3 = 1f / (float)this.uvX, _y:  float val_4 = 1f / (float)this.uvY);
        Geometric.Point val_6 = new Geometric.Point(_x:  val_3, _y:  val_4);
        // 0x02790B40: LDR w8, [x19, #0x18]       | W8 = this.uvX; //P2                     
        int val_16 = this.uvX;
        // 0x02790B44: LDP s9, s8, [sp, #8]       | S9 = val_6.x; S8 = val_6.y;              //  | 
        // 0x02790B48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790B4C: MOV x0, sp                 | X0 = 1152921515609469440 (0x100000028FCEB200);//ML01
        Geometric.Point val_10;
        // 0x02790B50: SDIV w9, w20, w8           | W9 = ((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) / 
        val_15 = val_5 / val_16;
        // 0x02790B54: MSUB w8, w9, w8, w20       | W8 = (val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) - (
        val_16 = val_5 - (val_15 * val_16);
        // 0x02790B58: SCVTF s0, w9               | S0 = (float)(((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) / this.uvX));
        // 0x02790B5C: FSUB s1, s10, s8           | S1 = (1f - val_6.y);                    
        float val_7 = 1f - val_6.y;
        // 0x02790B60: SCVTF s2, w8               | S2 = (float)((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) - (((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) / this.uvX) * this.uvX));
        // 0x02790B64: FMUL s3, s8, s0            | S3 = (val_6.y * ((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) / this.uvX));
        float val_8 = val_6.y * (float)val_15;
        // 0x02790B68: FMUL s0, s9, s2            | S0 = (val_6.x * (val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) - (((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) / this.uvX) * this.uvX));
        float val_9 = val_6.x * (float)val_16;
        // 0x02790B6C: FSUB s1, s1, s3            | S1 = ((1f - val_6.y) - (val_6.y * ((val_1 * this.fps) - (((val_1 * this.fps) / (this.uvY * this.uvX)) * (this.uvY * this.uvX)) / this.uvX)));
        val_7 = val_7 - val_8;
        // 0x02790B70: STR xzr, [sp]              | stack[1152921515609469440] = 0x0;        //  dest_result_addr=1152921515609469440
        // 0x02790B74: BL #0x2697148              | null..ctor(_x:  float val_9 = val_6.x * (float)this.uvX, _y:  val_7 = val_7 - val_8);
        val_10 = new Geometric.Point(_x:  val_9, _y:  val_7);
        // 0x02790B78: ADRP x21, #0x35be000       | X21 = 56352768 (0x35BE000);             
        // 0x02790B7C: LDP s10, s11, [sp]         | S10 = val_10.x; S11 = val_10.y;          //  | 
        // 0x02790B80: LDR x21, [x21, #0x8c8]     | X21 = 1152921513055923456;              
        // 0x02790B84: MOV x0, x19                | X0 = 1152921515609481536 (0x100000028FCEE140);//ML01
        // 0x02790B88: LDR x1, [x21]              | X1 = public UnityEngine.Renderer UnityEngine.Component::GetComponent<UnityEngine.Renderer>();
        // 0x02790B8C: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Renderer>();
        UnityEngine.Renderer val_11 = this.GetComponent<UnityEngine.Renderer>();
        // 0x02790B90: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x02790B94: CBNZ x20, #0x2790b9c       | if (val_11 != null) goto label_1;       
        if(val_11 != null)
        {
            goto label_1;
        }
        // 0x02790B98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_1:
        // 0x02790B9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790BA0: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x02790BA4: BL #0x1b863a4              | X0 = val_11.get_material();             
        UnityEngine.Material val_12 = val_11.material;
        // 0x02790BA8: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x02790BAC: CBNZ x20, #0x2790bb4       | if (val_12 != null) goto label_2;       
        if(val_12 != null)
        {
            goto label_2;
        }
        // 0x02790BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_2:
        // 0x02790BB4: ADRP x22, #0x3682000       | X22 = 57155584 (0x3682000);             
        // 0x02790BB8: LDR x22, [x22, #0x1a0]     | X22 = (string**)(1152921509939427360)("_MainTex");
        // 0x02790BBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02790BC0: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x02790BC4: MOV v0.16b, v10.16b        | V0 = val_10.x;//m1                      
        // 0x02790BC8: LDR x1, [x22]              | X1 = "_MainTex";                        
        // 0x02790BCC: MOV v1.16b, v11.16b        | V1 = val_10.y;//m1                      
        // 0x02790BD0: BL #0x1a78210              | val_12.SetTextureOffset(name:  "_MainTex", value:  new UnityEngine.Vector2() {x = val_10.x, y = val_10.y});
        val_12.SetTextureOffset(name:  "_MainTex", value:  new UnityEngine.Vector2() {x = val_10.x, y = val_10.y});
        // 0x02790BD4: LDR x1, [x21]              | X1 = public UnityEngine.Renderer UnityEngine.Component::GetComponent<UnityEngine.Renderer>();
        // 0x02790BD8: MOV x0, x19                | X0 = 1152921515609481536 (0x100000028FCEE140);//ML01
        // 0x02790BDC: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Renderer>();
        UnityEngine.Renderer val_13 = this.GetComponent<UnityEngine.Renderer>();
        // 0x02790BE0: MOV x19, x0                | X19 = val_13;//m1                       
        // 0x02790BE4: CBNZ x19, #0x2790bec       | if (val_13 != null) goto label_3;       
        if(val_13 != null)
        {
            goto label_3;
        }
        // 0x02790BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_3:
        // 0x02790BEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790BF0: MOV x0, x19                | X0 = val_13;//m1                        
        // 0x02790BF4: BL #0x1b863a4              | X0 = val_13.get_material();             
        UnityEngine.Material val_14 = val_13.material;
        // 0x02790BF8: MOV x19, x0                | X19 = val_14;//m1                       
        // 0x02790BFC: CBNZ x19, #0x2790c04       | if (val_14 != null) goto label_4;       
        if(val_14 != null)
        {
            goto label_4;
        }
        // 0x02790C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_4:
        // 0x02790C04: LDR x1, [x22]              | X1 = "_MainTex";                        
        // 0x02790C08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02790C0C: MOV x0, x19                | X0 = val_14;//m1                        
        // 0x02790C10: MOV v0.16b, v9.16b         | V0 = val_6.x;//m1                       
        // 0x02790C14: MOV v1.16b, v8.16b         | V1 = val_6.y;//m1                       
        // 0x02790C18: BL #0x1a78378              | val_14.SetTextureScale(name:  "_MainTex", value:  new UnityEngine.Vector2() {x = val_6.x, y = val_6.y});
        val_14.SetTextureScale(name:  "_MainTex", value:  new UnityEngine.Vector2() {x = val_6.x, y = val_6.y});
        // 0x02790C1C: SUB sp, x29, #0x40         | SP = (1152921515609469520 - 64) = 1152921515609469456 (0x100000028FCEB210);
        // 0x02790C20: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02790C24: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02790C28: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02790C2C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02790C30: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x02790C34: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02790C38 (41487416), len: 4  VirtAddr: 0x02790C38 RVA: 0x02790C38 token: 100663302 methodIndex: 57665 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02790C38: RET                        |  return;                                
        return;
    
    }

}
