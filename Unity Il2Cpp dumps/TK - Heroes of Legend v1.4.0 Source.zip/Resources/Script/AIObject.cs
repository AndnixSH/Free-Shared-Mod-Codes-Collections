using UnityEngine;
public class AIObject
{
    // Fields
    public readonly npcAICfg mpJson; //  0x00000010
    public readonly int id; //  0x00000018
    public readonly int[] behaviorID; //  0x00000020
    public readonly int[] conditionID; //  0x00000028
    public float delayStartTime; //  0x00000030
    public float delayTime; //  0x00000034
    public int delayID; //  0x00000038
    private float mLastUseTime; //  0x0000003C
    private int curCount; //  0x00000040
    
    // Properties
    public bool isInCD { get; }
    public bool isComplete { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B20E48 (11669064), len: 1048  VirtAddr: 0x00B20E48 RVA: 0x00B20E48 token: 100691857 methodIndex: 24737 delegateWrapperIndex: 0 methodInvoker: 0
    public AIObject(int id)
    {
        //
        // Disasemble & Code
        //  | 
        bool val_16;
        //  | 
        npcAICfg val_17;
        //  | 
        npcAICfg val_18;
        //  | 
        var val_19;
        //  | 
        var val_20;
        // 0x00B20E48: STP d9, d8, [sp, #-0x60]!  | stack[1152921514726270832] = ???;  stack[1152921514726270840] = ???;  //  dest_result_addr=1152921514726270832 |  dest_result_addr=1152921514726270840
        // 0x00B20E4C: STP x26, x25, [sp, #0x10]  | stack[1152921514726270848] = ???;  stack[1152921514726270856] = ???;  //  dest_result_addr=1152921514726270848 |  dest_result_addr=1152921514726270856
        // 0x00B20E50: STP x24, x23, [sp, #0x20]  | stack[1152921514726270864] = ???;  stack[1152921514726270872] = ???;  //  dest_result_addr=1152921514726270864 |  dest_result_addr=1152921514726270872
        // 0x00B20E54: STP x22, x21, [sp, #0x30]  | stack[1152921514726270880] = ???;  stack[1152921514726270888] = ???;  //  dest_result_addr=1152921514726270880 |  dest_result_addr=1152921514726270888
        // 0x00B20E58: STP x20, x19, [sp, #0x40]  | stack[1152921514726270896] = ???;  stack[1152921514726270904] = ???;  //  dest_result_addr=1152921514726270896 |  dest_result_addr=1152921514726270904
        // 0x00B20E5C: STP x29, x30, [sp, #0x50]  | stack[1152921514726270912] = ???;  stack[1152921514726270920] = ???;  //  dest_result_addr=1152921514726270912 |  dest_result_addr=1152921514726270920
        // 0x00B20E60: ADD x29, sp, #0x50         | X29 = (1152921514726270832 + 80) = 1152921514726270912 (0x100000025B2A27C0);
        // 0x00B20E64: SUB sp, sp, #0x10          | SP = (1152921514726270832 - 16) = 1152921514726270816 (0x100000025B2A2760);
        // 0x00B20E68: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B20E6C: LDRB w8, [x21, #0x730]     | W8 = (bool)static_value_03733730;       
        // 0x00B20E70: MOV w20, w1                | W20 = id;//m1                           
        // 0x00B20E74: MOV x19, x0                | X19 = 1152921514726282928 (0x100000025B2A56B0);//ML01
        val_16 = this;
        // 0x00B20E78: TBNZ w8, #0, #0xb20e94     | if (static_value_03733730 == true) goto label_0;
        // 0x00B20E7C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B20E80: LDR x8, [x8, #0xf08]       | X8 = 0x2B8AB18;                         
        // 0x00B20E84: LDR w0, [x8]               | W0 = 0x184;                             
        // 0x00B20E88: BL #0x2782188              | X0 = sub_2782188( ?? 0x184, ????);      
        // 0x00B20E8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20E90: STRB w8, [x21, #0x730]     | static_value_03733730 = true;            //  dest_result_addr=57882416
        label_0:
        // 0x00B20E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20E98: MOV x0, x19                | X0 = 1152921514726282928 (0x100000025B2A56B0);//ML01
        // 0x00B20E9C: BL #0x16f59f0              | this..ctor();                           
        // 0x00B20EA0: STR wzr, [x19, #0x30]      | this.delayStartTime = 0;                 //  dest_result_addr=1152921514726282976
        this.delayStartTime = 0f;
        // 0x00B20EA4: ADRP x23, #0x3668000       | X23 = 57049088 (0x3668000);             
        // 0x00B20EA8: STR w20, [x19, #0x18]      | this.id = id;                            //  dest_result_addr=1152921514726282952
        this.id = id;
        // 0x00B20EAC: LDR x23, [x23, #0x960]     | X23 = 1152921504911851520;              
        // 0x00B20EB0: LDR x0, [x23]              | X0 = typeof(ZMG);                       
        // 0x00B20EB4: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B20EB8: TBZ w8, #0, #0xb20ec8      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B20EBC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B20EC0: CBNZ w8, #0xb20ec8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B20EC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00B20EC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20ECC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20ED0: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_1 = ZMG.CfgDataMgr;
        // 0x00B20ED4: MOV x21, x0                | X21 = val_1;//m1                        
        val_17 = val_1;
        // 0x00B20ED8: CBNZ x21, #0xb20ee0        | if (val_1 != null) goto label_3;        
        if(val_17 != null)
        {
            goto label_3;
        }
        // 0x00B20EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B20EE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20EE4: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B20EE8: MOV w1, w20                | W1 = id;//m1                            
        // 0x00B20EEC: BL #0xb48a98               | X0 = val_1.GetnpcAICfg(id:  id);        
        npcAICfg val_2 = val_17.GetnpcAICfg(id:  id);
        // 0x00B20EF0: STR x0, [x19, #0x10]       | this.mpJson = val_2;                     //  dest_result_addr=1152921514726282944
        this.mpJson = val_2;
        // 0x00B20EF4: CBZ x0, #0xb211d0          | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00B20EF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20EFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20F00: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_3 = UnityEngine.Time.time;
        // 0x00B20F04: LDR x21, [x19, #0x10]      | X21 = this.mpJson; //P2                 
        val_17 = this.mpJson;
        // 0x00B20F08: MOV v8.16b, v0.16b         | V8 = val_3;//m1                         
        // 0x00B20F0C: MOV x20, x21               | X20 = this.mpJson;//m1                  
        val_18 = val_17;
        // 0x00B20F10: CBNZ x21, #0xb20f1c        | if (this.mpJson != null) goto label_5;  
        if(val_17 != null)
        {
            goto label_5;
        }
        // 0x00B20F14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B20F18: LDR x20, [x19, #0x10]      | X20 = this.mpJson; //P2                 
        val_18 = this.mpJson;
        label_5:
        // 0x00B20F1C: LDR s0, [x21, #0x30]       | S0 = this.mpJson.cdstarttime; //P2      
        // 0x00B20F20: SCVTF s0, s0               | S0 = (float)(this.mpJson.cdstarttime);  
        float val_16 = (float)this.mpJson.cdstarttime;
        // 0x00B20F24: FSUB s0, s8, s0            | S0 = (val_3 - this.mpJson.cdstarttime); 
        val_16 = val_3 - val_16;
        // 0x00B20F28: STR s0, [x19, #0x3c]       | this.mLastUseTime = (val_3 - this.mpJson.cdstarttime);  //  dest_result_addr=1152921514726282988
        this.mLastUseTime = val_16;
        // 0x00B20F2C: CBNZ x20, #0xb20f34        | if (this.mpJson != null) goto label_6;  
        if(val_18 != null)
        {
            goto label_6;
        }
        // 0x00B20F30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00B20F34: ADRP x24, #0x35d6000       | X24 = 56451072 (0x35D6000);             
        // 0x00B20F38: LDR x24, [x24, #0xe38]     | X24 = 1152921504608284672;              
        // 0x00B20F3C: LDR x20, [x20, #0x28]      | X20 = this.mpJson.behavior; //P2        
        // 0x00B20F40: LDR x0, [x24]              | X0 = typeof(System.String);             
        // 0x00B20F44: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B20F48: TBZ w8, #0, #0xb20f58      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B20F4C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B20F50: CBNZ w8, #0xb20f58         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B20F54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_8:
        // 0x00B20F58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20F5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20F60: MOV x1, x20                | X1 = this.mpJson.behavior;//m1          
        // 0x00B20F64: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_4 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B20F68: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x00B20F6C: TBNZ w8, #0, #0xb21080     | if ((val_4 & 1) == true) goto label_18; 
        if(val_5 == true)
        {
            goto label_18;
        }
        // 0x00B20F70: LDR x20, [x19, #0x10]      | X20 = this.mpJson; //P2                 
        // 0x00B20F74: CBNZ x20, #0xb20f7c        | if (this.mpJson != null) goto label_10; 
        if(this.mpJson != null)
        {
            goto label_10;
        }
        // 0x00B20F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_10:
        // 0x00B20F7C: LDR x0, [x23]              | X0 = typeof(ZMG);                       
        // 0x00B20F80: LDR x20, [x20, #0x28]      | X20 = this.mpJson.behavior; //P2        
        // 0x00B20F84: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B20F88: TBZ w8, #0, #0xb20f98      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B20F8C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B20F90: CBNZ w8, #0xb20f98         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B20F94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_12:
        // 0x00B20F98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20FA0: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_6 = ZMG.GlobalGOMgr;
        // 0x00B20FA4: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00B20FA8: CBNZ x21, #0xb20fb0        | if (val_6 != null) goto label_13;       
        if(val_6 != null)
        {
            goto label_13;
        }
        // 0x00B20FAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_13:
        // 0x00B20FB0: LDR x21, [x21, #0x10]      | X21 = val_6.separator; //P2             
        // 0x00B20FB4: CBNZ x20, #0xb20fbc        | if (this.mpJson.behavior != null) goto label_14;
        if(this.mpJson.behavior != null)
        {
            goto label_14;
        }
        // 0x00B20FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00B20FBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20FC0: MOV x0, x20                | X0 = this.mpJson.behavior;//m1          
        // 0x00B20FC4: MOV x1, x21                | X1 = val_6.separator;//m1               
        // 0x00B20FC8: BL #0x18a881c              | X0 = this.mpJson.behavior.Split(separator:  val_6.separator);
        System.String[] val_7 = this.mpJson.behavior.Split(separator:  val_6.separator);
        // 0x00B20FCC: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B20FD0: CBNZ x20, #0xb20fd8        | if (val_7 != null) goto label_15;       
        if(val_7 != null)
        {
            goto label_15;
        }
        // 0x00B20FD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_15:
        // 0x00B20FD8: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B20FDC: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
        // 0x00B20FE0: LDR w22, [x20, #0x18]      | W22 = val_7.Length; //P2                
        // 0x00B20FE4: LDR x21, [x8]              | X21 = typeof(System.Int32[]);           
        val_17 = null;
        // 0x00B20FE8: MOV x0, x21                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
        // 0x00B20FEC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
        // 0x00B20FF0: MOV x0, x21                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
        // 0x00B20FF4: MOV x1, x22                | X1 = val_7.Length;//m1                  
        // 0x00B20FF8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
        // 0x00B20FFC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_19 = 0;
        // 0x00B21000: STR x0, [x19, #0x20]       | this.behaviorID = typeof(System.Int32[]);  //  dest_result_addr=1152921514726282960
        this.behaviorID = val_17;
        // 0x00B21004: B #0xb21014                |  goto label_16;                         
        goto label_16;
        label_22:
        // 0x00B21008: ADD x8, x25, x26, lsl #2   | X8 = (X25 + (X26) << 2);                
        var val_8 = X25 + ((X26) << 2);
        // 0x00B2100C: ADD w22, w22, #1           | W22 = (val_19 + 1) = val_19 (0x00000001);
        val_19 = 1;
        // 0x00B21010: STR w21, [x8, #0x20]       | mem2[0] = typeof(System.Int32[]);        //  dest_result_addr=0
        mem2[0] = val_17;
        label_16:
        // 0x00B21014: CBNZ x20, #0xb2101c        | if (val_7 != null) goto label_17;       
        if(val_7 != null)
        {
            goto label_17;
        }
        // 0x00B21018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
        label_17:
        // 0x00B2101C: LDR w8, [x20, #0x18]       | W8 = val_7.Length; //P2                 
        // 0x00B21020: CMP w22, w8                | STATE = COMPARE(0x1, val_7.Length)      
        // 0x00B21024: B.GE #0xb21080             | if (val_19 >= val_7.Length) goto label_18;
        if(val_19 >= val_7.Length)
        {
            goto label_18;
        }
        // 0x00B21028: LDR x25, [x19, #0x20]      | X25 = this.behaviorID; //P2             
        // 0x00B2102C: SXTW x26, w22              | X26 = 1 (0x00000001);                   
        // 0x00B21030: CMP w22, w8                | STATE = COMPARE(0x1, val_7.Length)      
        // 0x00B21034: B.LO #0xb21044             | if (val_19 < val_7.Length) goto label_19;
        if(val_19 < val_7.Length)
        {
            goto label_19;
        }
        // 0x00B21038: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Int32[]), ????);
        // 0x00B2103C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21040: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Int32[]), ????);
        label_19:
        // 0x00B21044: ADD x8, x20, x26, lsl #3   | X8 = val_7[0x1]; //PARR1                
        // 0x00B21048: LDR x1, [x8, #0x20]        | X1 = val_7[0x1][0]                      
        string val_17 = val_7[1];
        // 0x00B2104C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21050: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B21054: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_9 = System.Int32.Parse(s:  0);
        // 0x00B21058: MOV w21, w0                | W21 = val_9;//m1                        
        // 0x00B2105C: CBNZ x25, #0xb21064        | if (this.behaviorID != null) goto label_20;
        if(this.behaviorID != null)
        {
            goto label_20;
        }
        // 0x00B21060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_20:
        // 0x00B21064: LDR w8, [x25, #0x18]       | W8 = this.behaviorID.Length; //P2       
        // 0x00B21068: CMP w22, w8                | STATE = COMPARE(0x1, this.behaviorID.Length)
        // 0x00B2106C: B.LO #0xb21008             | if (val_19 < this.behaviorID.Length) goto label_22;
        if(val_19 < this.behaviorID.Length)
        {
            goto label_22;
        }
        // 0x00B21070: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
        // 0x00B21074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21078: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        // 0x00B2107C: B #0xb21008                |  goto label_22;                         
        goto label_22;
        label_18:
        // 0x00B21080: LDR x20, [x19, #0x10]      | X20 = this.mpJson; //P2                 
        // 0x00B21084: CBNZ x20, #0xb2108c        | if (this.mpJson != null) goto label_23; 
        if(this.mpJson != null)
        {
            goto label_23;
        }
        // 0x00B21088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_23:
        // 0x00B2108C: LDR x0, [x24]              | X0 = typeof(System.String);             
        // 0x00B21090: LDR x20, [x20, #0x20]      | X20 = this.mpJson.condition; //P2       
        // 0x00B21094: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B21098: TBZ w8, #0, #0xb210a8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00B2109C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B210A0: CBNZ w8, #0xb210a8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00B210A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_25:
        // 0x00B210A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B210AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B210B0: MOV x1, x20                | X1 = this.mpJson.condition;//m1         
        // 0x00B210B4: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_10 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B210B8: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        bool val_11 = val_10;
        // 0x00B210BC: TBNZ w8, #0, #0xb21240     | if ((val_10 & 1) == true) goto label_35;
        if(val_11 == true)
        {
            goto label_35;
        }
        // 0x00B210C0: LDR x20, [x19, #0x10]      | X20 = this.mpJson; //P2                 
        // 0x00B210C4: CBNZ x20, #0xb210cc        | if (this.mpJson != null) goto label_27; 
        if(this.mpJson != null)
        {
            goto label_27;
        }
        // 0x00B210C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_27:
        // 0x00B210CC: LDR x0, [x23]              | X0 = typeof(ZMG);                       
        // 0x00B210D0: LDR x20, [x20, #0x20]      | X20 = this.mpJson.condition; //P2       
        // 0x00B210D4: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B210D8: TBZ w8, #0, #0xb210e8      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_29;
        // 0x00B210DC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B210E0: CBNZ w8, #0xb210e8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
        // 0x00B210E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_29:
        // 0x00B210E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B210EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B210F0: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_12 = ZMG.GlobalGOMgr;
        // 0x00B210F4: MOV x21, x0                | X21 = val_12;//m1                       
        // 0x00B210F8: CBNZ x21, #0xb21100        | if (val_12 != null) goto label_30;      
        if(val_12 != null)
        {
            goto label_30;
        }
        // 0x00B210FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_30:
        // 0x00B21100: LDR x21, [x21, #0x10]      | X21 = val_12.separator; //P2            
        // 0x00B21104: CBNZ x20, #0xb2110c        | if (this.mpJson.condition != null) goto label_31;
        if(this.mpJson.condition != null)
        {
            goto label_31;
        }
        // 0x00B21108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_31:
        // 0x00B2110C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B21110: MOV x0, x20                | X0 = this.mpJson.condition;//m1         
        // 0x00B21114: MOV x1, x21                | X1 = val_12.separator;//m1              
        // 0x00B21118: BL #0x18a881c              | X0 = this.mpJson.condition.Split(separator:  val_12.separator);
        System.String[] val_13 = this.mpJson.condition.Split(separator:  val_12.separator);
        // 0x00B2111C: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00B21120: CBNZ x20, #0xb21128        | if (val_13 != null) goto label_32;      
        if(val_13 != null)
        {
            goto label_32;
        }
        // 0x00B21124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_32:
        // 0x00B21128: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B2112C: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
        // 0x00B21130: LDR w22, [x20, #0x18]      | W22 = val_13.Length; //P2               
        // 0x00B21134: LDR x21, [x8]              | X21 = typeof(System.Int32[]);           
        val_17 = null;
        // 0x00B21138: MOV x0, x21                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
        // 0x00B2113C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
        // 0x00B21140: MOV x0, x21                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
        // 0x00B21144: MOV x1, x22                | X1 = val_13.Length;//m1                 
        // 0x00B21148: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
        // 0x00B2114C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_20 = 0;
        // 0x00B21150: STR x0, [x19, #0x28]       | this.conditionID = typeof(System.Int32[]);  //  dest_result_addr=1152921514726282968
        this.conditionID = val_17;
        // 0x00B21154: B #0xb21164                |  goto label_33;                         
        goto label_33;
        label_39:
        // 0x00B21158: ADD x8, x23, x24, lsl #2   | X8 = (1152921504911851520 + 231908960) = 289903072 (0x114791E0);
        // 0x00B2115C: ADD w22, w22, #1           | W22 = (val_20 + 1) = val_20 (0x00000001);
        val_20 = 1;
        // 0x00B21160: STR w21, [x8, #0x20]       | mem[289903104] = typeof(System.Int32[]);  //  dest_result_addr=289903104
        mem[289903104] = val_17;
        label_33:
        // 0x00B21164: CBNZ x20, #0xb2116c        | if (val_13 != null) goto label_34;      
        if(val_13 != null)
        {
            goto label_34;
        }
        // 0x00B21168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
        label_34:
        // 0x00B2116C: LDR w8, [x20, #0x18]       | W8 = val_13.Length; //P2                
        // 0x00B21170: CMP w22, w8                | STATE = COMPARE(0x1, val_13.Length)     
        // 0x00B21174: B.GE #0xb21240             | if (val_20 >= val_13.Length) goto label_35;
        if(val_20 >= val_13.Length)
        {
            goto label_35;
        }
        // 0x00B21178: LDR x23, [x19, #0x28]      | X23 = this.conditionID; //P2            
        // 0x00B2117C: SXTW x24, w22              | X24 = 1 (0x00000001);                   
        // 0x00B21180: CMP w22, w8                | STATE = COMPARE(0x1, val_13.Length)     
        // 0x00B21184: B.LO #0xb21194             | if (val_20 < val_13.Length) goto label_36;
        if(val_20 < val_13.Length)
        {
            goto label_36;
        }
        // 0x00B21188: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Int32[]), ????);
        // 0x00B2118C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21190: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Int32[]), ????);
        label_36:
        // 0x00B21194: ADD x8, x20, x24, lsl #3   | X8 = val_13[0x1]; //PARR1               
        // 0x00B21198: LDR x1, [x8, #0x20]        | X1 = val_13[0x1][0]                     
        string val_18 = val_13[1];
        // 0x00B2119C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B211A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B211A4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_14 = System.Int32.Parse(s:  0);
        // 0x00B211A8: MOV w21, w0                | W21 = val_14;//m1                       
        // 0x00B211AC: CBNZ x23, #0xb211b4        | if (this.conditionID != null) goto label_37;
        if(this.conditionID != null)
        {
            goto label_37;
        }
        // 0x00B211B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_37:
        // 0x00B211B4: LDR w8, [x23, #0x18]       | W8 = this.conditionID.Length; //P2      
        // 0x00B211B8: CMP w22, w8                | STATE = COMPARE(0x1, this.conditionID.Length)
        // 0x00B211BC: B.LO #0xb21158             | if (val_20 < this.conditionID.Length) goto label_39;
        if(val_20 < this.conditionID.Length)
        {
            goto label_39;
        }
        // 0x00B211C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
        // 0x00B211C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B211C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
        // 0x00B211CC: B #0xb21158                |  goto label_39;                         
        goto label_39;
        label_4:
        // 0x00B211D0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B211D4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B211D8: ADD x1, sp, #0xc           | X1 = (1152921514726270816 + 12) = 1152921514726270828 (0x100000025B2A276C);
        // 0x00B211DC: STR w20, [sp, #0xc]        | stack[1152921514726270828] = id;         //  dest_result_addr=1152921514726270828
        // 0x00B211E0: LDR x0, [x8]               | X0 = typeof(System.Int32);              
        // 0x00B211E4: BL #0x27bc028              | X0 = 1152921514726597552 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), id);
        // 0x00B211E8: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00B211EC: LDR x8, [x8, #0xae0]       | X8 = (string**)(1152921514726254720)("ai模板表找不到ai id{0}");
        // 0x00B211F0: MOV x2, x0                 | X2 = 1152921514726597552 (0x100000025B2F23B0);//ML01
        // 0x00B211F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B211F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B211FC: LDR x1, [x8]               | X1 = "ai模板表找不到ai id{0}";                
        // 0x00B21200: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "ai模板表找不到ai id{0}");
        string val_15 = EString.EFormat(format:  0, arg0:  "ai模板表找不到ai id{0}");
        // 0x00B21204: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B21208: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B2120C: MOV x19, x0                | X19 = val_15;//m1                       
        val_16 = val_15;
        // 0x00B21210: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B21214: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B21218: TBZ w9, #0, #0xb2122c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_41;
        // 0x00B2121C: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B21220: CBNZ w9, #0xb2122c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
        // 0x00B21224: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B21228: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_41:
        // 0x00B2122C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21230: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B21234: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B21238: MOV x1, x19                | X1 = val_15;//m1                        
        // 0x00B2123C: BL #0xb5b538               | EDebug.LogError(message:  0, isShowStack:  val_16);
        EDebug.LogError(message:  0, isShowStack:  val_16);
        label_35:
        // 0x00B21240: SUB sp, x29, #0x50         | SP = (1152921514726270912 - 80) = 1152921514726270832 (0x100000025B2A2770);
        // 0x00B21244: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B21248: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2124C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B21250: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B21254: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B21258: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00B2125C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2152C (11670828), len: 84  VirtAddr: 0x00B2152C RVA: 0x00B2152C token: 100691858 methodIndex: 24738 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isInCD()
    {
        //
        // Disasemble & Code
        // 0x00B2152C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514726677792] = ???;  stack[1152921514726677800] = ???;  //  dest_result_addr=1152921514726677792 |  dest_result_addr=1152921514726677800
        // 0x00B21530: STP x20, x19, [sp, #0x10]  | stack[1152921514726677808] = ???;  stack[1152921514726677816] = ???;  //  dest_result_addr=1152921514726677808 |  dest_result_addr=1152921514726677816
        // 0x00B21534: STP x29, x30, [sp, #0x20]  | stack[1152921514726677824] = ???;  stack[1152921514726677832] = ???;  //  dest_result_addr=1152921514726677824 |  dest_result_addr=1152921514726677832
        // 0x00B21538: ADD x29, sp, #0x20         | X29 = (1152921514726677792 + 32) = 1152921514726677824 (0x100000025B305D40);
        // 0x00B2153C: MOV x19, x0                | X19 = 1152921514726689840 (0x100000025B308C30);//ML01
        // 0x00B21540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21548: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x00B2154C: LDR s9, [x19, #0x3c]       | S9 = this.mLastUseTime; //P2            
        // 0x00B21550: LDR x19, [x19, #0x10]      | X19 = this.mpJson; //P2                 
        // 0x00B21554: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
        // 0x00B21558: CBNZ x19, #0xb21560        | if (this.mpJson != null) goto label_0;  
        if(this.mpJson != null)
        {
            goto label_0;
        }
        // 0x00B2155C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_0:
        // 0x00B21560: LDR s0, [x19, #0x14]       | S0 = this.mpJson.cdtime; //P2           
        // 0x00B21564: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B21568: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2156C: FSUB s1, s8, s9            | S1 = (val_1 - this.mLastUseTime);       
        float val_2 = val_1 - this.mLastUseTime;
        // 0x00B21570: FCMP s1, s0                | STATE = COMPARE((val_1 - this.mLastUseTime), this.mpJson.cdtime)
        // 0x00B21574: CSET w0, ls                | W0 = val_2 <= this.mpJson.cdtime ? 1 : 0;
        var val_3 = (val_2 <= this.mpJson.cdtime) ? 1 : 0;
        // 0x00B21578: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B2157C: RET                        |  return (System.Boolean)val_2 <= this.mpJson.cdtime ? 1 : 0;
        return (bool)val_3;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B21580 (11670912), len: 88  VirtAddr: 0x00B21580 RVA: 0x00B21580 token: 100691859 methodIndex: 24739 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isComplete()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00B21580: STP x20, x19, [sp, #-0x20]! | stack[1152921514726802096] = ???;  stack[1152921514726802104] = ???;  //  dest_result_addr=1152921514726802096 |  dest_result_addr=1152921514726802104
        // 0x00B21584: STP x29, x30, [sp, #0x10]  | stack[1152921514726802112] = ???;  stack[1152921514726802120] = ???;  //  dest_result_addr=1152921514726802112 |  dest_result_addr=1152921514726802120
        // 0x00B21588: ADD x29, sp, #0x10         | X29 = (1152921514726802096 + 16) = 1152921514726802112 (0x100000025B3242C0);
        // 0x00B2158C: MOV x19, x0                | X19 = 1152921514726814128 (0x100000025B3271B0);//ML01
        // 0x00B21590: LDR x20, [x19, #0x10]      | X20 = this.mpJson; //P2                 
        // 0x00B21594: CBNZ x20, #0xb2159c        | if (this.mpJson != null) goto label_0;  
        if(this.mpJson != null)
        {
            goto label_0;
        }
        // 0x00B21598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B2159C: LDR w8, [x20, #0x18]       | W8 = this.mpJson.count; //P2            
        // 0x00B215A0: CMP w8, #1                 | STATE = COMPARE(this.mpJson.count, 0x1) 
        // 0x00B215A4: B.LT #0xb215c8             | if (this.mpJson.count < 1) goto label_1;
        if(this.mpJson.count < 1)
        {
            goto label_1;
        }
        // 0x00B215A8: LDR x20, [x19, #0x10]      | X20 = this.mpJson; //P2                 
        // 0x00B215AC: CBNZ x20, #0xb215b4        | if (this.mpJson != null) goto label_2;  
        if(this.mpJson != null)
        {
            goto label_2;
        }
        // 0x00B215B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00B215B4: LDR w8, [x20, #0x18]       | W8 = this.mpJson.count; //P2            
        // 0x00B215B8: LDR w9, [x19, #0x40]       | W9 = this.curCount; //P2                
        // 0x00B215BC: CMP w8, w9                 | STATE = COMPARE(this.mpJson.count, this.curCount)
        // 0x00B215C0: CSET w0, le                | W0 = this.mpJson.count <= this.curCount ? 1 : 0;
        var val_1 = (this.mpJson.count <= this.curCount) ? 1 : 0;
        // 0x00B215C4: B #0xb215cc                |  goto label_3;                          
        goto label_3;
        label_1:
        // 0x00B215C8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_2 = 0;
        label_3:
        // 0x00B215CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B215D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B215D4: RET                        |  return (System.Boolean)false;          
        return (bool)val_2;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B21BC0 (11672512), len: 56  VirtAddr: 0x00B21BC0 RVA: 0x00B21BC0 token: 100691860 methodIndex: 24740 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnUseing()
    {
        //
        // Disasemble & Code
        // 0x00B21BC0: STP x20, x19, [sp, #-0x20]! | stack[1152921514726922288] = ???;  stack[1152921514726922296] = ???;  //  dest_result_addr=1152921514726922288 |  dest_result_addr=1152921514726922296
        // 0x00B21BC4: STP x29, x30, [sp, #0x10]  | stack[1152921514726922304] = ???;  stack[1152921514726922312] = ???;  //  dest_result_addr=1152921514726922304 |  dest_result_addr=1152921514726922312
        // 0x00B21BC8: ADD x29, sp, #0x10         | X29 = (1152921514726922288 + 16) = 1152921514726922304 (0x100000025B341840);
        // 0x00B21BCC: MOV x19, x0                | X19 = 1152921514726934320 (0x100000025B344730);//ML01
        // 0x00B21BD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B21BD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B21BD8: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x00B21BDC: LDR w8, [x19, #0x40]       | W8 = this.curCount; //P2                
        int val_2 = this.curCount;
        // 0x00B21BE0: STR s0, [x19, #0x3c]       | this.mLastUseTime = val_1;               //  dest_result_addr=1152921514726934380
        this.mLastUseTime = val_1;
        // 0x00B21BE4: ADD w8, w8, #1             | W8 = (this.curCount + 1);               
        val_2 = val_2 + 1;
        // 0x00B21BE8: STR w8, [x19, #0x40]       | this.curCount = (this.curCount + 1);     //  dest_result_addr=1152921514726934384
        this.curCount = val_2;
        // 0x00B21BEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B21BF0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B21BF4: RET                        |  return;                                
        return;
    
    }

}
