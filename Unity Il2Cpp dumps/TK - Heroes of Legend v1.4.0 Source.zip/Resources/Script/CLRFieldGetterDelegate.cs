using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public sealed class CLRFieldGetterDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E8FD0 (42897360), len: 16  VirtAddr: 0x028E8FD0 RVA: 0x028E8FD0 token: 100680188 methodIndex: 29539 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRFieldGetterDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x028E8FD0: LDR x8, [x2]               | X8 = method;                            
            // 0x028E8FD4: STP x1, x2, [x0, #0x20]    | mem[1152921512875594912] = object;  mem[1152921512875594920] = method;  //  dest_result_addr=1152921512875594912 |  dest_result_addr=1152921512875594920
            mem[1152921512875594912] = object;
            mem[1152921512875594920] = method;
            // 0x028E8FD8: STR x8, [x0, #0x10]        | mem[1152921512875594896] = method;       //  dest_result_addr=1152921512875594896
            mem[1152921512875594896] = method;
            // 0x028E8FDC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E8FE0 (42897376), len: 528  VirtAddr: 0x028E8FE0 RVA: 0x028E8FE0 token: 100680189 methodIndex: 29540 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object Invoke(ref object target)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            label_1:
            // 0x028E8FE0: STP x22, x21, [sp, #-0x30]! | stack[1152921512875711136] = ???;  stack[1152921512875711144] = ???;  //  dest_result_addr=1152921512875711136 |  dest_result_addr=1152921512875711144
            // 0x028E8FE4: STP x20, x19, [sp, #0x10]  | stack[1152921512875711152] = ???;  stack[1152921512875711160] = ???;  //  dest_result_addr=1152921512875711152 |  dest_result_addr=1152921512875711160
            // 0x028E8FE8: STP x29, x30, [sp, #0x20]  | stack[1152921512875711168] = ???;  stack[1152921512875711176] = ???;  //  dest_result_addr=1152921512875711168 |  dest_result_addr=1152921512875711176
            // 0x028E8FEC: ADD x29, sp, #0x20         | X29 = (1152921512875711136 + 32) = 1152921512875711168 (0x10000001ECDCDAC0);
            // 0x028E8FF0: SUB sp, sp, #0x10          | SP = (1152921512875711136 - 16) = 1152921512875711120 (0x10000001ECDCDA90);
            // 0x028E8FF4: MOV x22, x0                | X22 = 1152921512875723184 (0x10000001ECDD09B0);//ML01
            // 0x028E8FF8: LDR x0, [x22, #0x58]       | 
            // 0x028E8FFC: MOV x19, x1                | X19 = 1152921512875755184 (0x10000001ECDD86B0);//ML01
            // 0x028E9000: CBZ x0, #0x28e900c         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x028E9004: MOV x1, x19                | X1 = 1152921512875755184 (0x10000001ECDD86B0);//ML01
            // 0x028E9008: BL #0x28e8fe0              |  R0 = label_1();                        
            label_0:
            // 0x028E900C: LDR x0, [x22, #0x10]       | 
            // 0x028E9010: STR x0, [sp, #8]           | stack[1152921512875711128] = this;       //  dest_result_addr=1152921512875711128
            // 0x028E9014: LDP x20, x21, [x22, #0x20] |                                          //  | 
            // 0x028E9018: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E901C: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
            // 0x028E9020: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9024: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
            // 0x028E9028: AND w8, w0, #1             | W8 = (X21 & 1);                         
            var val_1 = X21 & 1;
            // 0x028E902C: TBZ w8, #0, #0x28e90bc     | if (((X21 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x028E9030: LDRSH w8, [x21, #0x4c]     | W8 = X21 + 76;                          
            // 0x028E9034: CMN w8, #1                 | STATE = COMPARE(X21 + 76, 0x1)          
            // 0x028E9038: B.EQ #0x28e90d0            | if (X21 + 76 == 0x1) goto label_6;      
            if((X21 + 76) == 1)
            {
                goto label_6;
            }
            // 0x028E903C: CBZ x20, #0x28e904c        | if (X20 == 0) goto label_4;             
            if(X20 == 0)
            {
                goto label_4;
            }
            // 0x028E9040: LDR x8, [x20]              | X8 = X20;                               
            // 0x028E9044: LDRB w8, [x8, #0xed]       | W8 = X20 + 237;                         
            // 0x028E9048: TBNZ w8, #0, #0x28e90d0    | if ((X20 + 237 & 0x1) != 0) goto label_6;
            if(((X20 + 237) & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x028E904C: LDR x8, [x22, #0x18]       | 
            // 0x028E9050: CBZ x8, #0x28e90d0         | if (X20 + 237 == 0) goto label_6;       
            if((X20 + 237) == 0)
            {
                goto label_6;
            }
            // 0x028E9054: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9058: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x028E905C: MOV w22, w0                | W22 = X21;//m1                          
            // 0x028E9060: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9064: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X21.pressedSprite;
            // 0x028E9068: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x028E906C: TBZ w22, #0, #0x28e911c    | if ((X21 & 0x1) == 0) goto label_7;     
            if((X21 & 1) == 0)
            {
                goto label_7;
            }
            // 0x028E9070: TBZ w0, #0, #0x28e9178     | if ((val_2 & 0x1) == 0) goto label_8;   
            if((val_2 & 1) == 0)
            {
                goto label_8;
            }
            // 0x028E9074: LDR x8, [x20]              | X8 = X20;                               
            var val_11 = X20;
            // 0x028E9078: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x028E907C: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x028E9080: LDRH w9, [x8, #0x102]      | W9 = X20 + 258;                         
            // 0x028E9084: CBZ x9, #0x28e90b0         | if (X20 + 258 == 0) goto label_9;       
            if((X20 + 258) == 0)
            {
                goto label_9;
            }
            // 0x028E9088: LDR x10, [x8, #0x98]       | X10 = X20 + 152;                        
            var val_5 = X20 + 152;
            // 0x028E908C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x028E9090: ADD x10, x10, #8           | X10 = (X20 + 152 + 8);                  
            val_5 = val_5 + 8;
            label_11:
            // 0x028E9094: LDUR x12, [x10, #-8]       | X12 = (X20 + 152 + 8) + -8;             
            // 0x028E9098: CMP x12, x1                | STATE = COMPARE((X20 + 152 + 8) + -8, X21 + 24)
            // 0x028E909C: B.EQ #0x28e919c            | if ((X20 + 152 + 8) + -8 == X21 + 24) goto label_10;
            if(((X20 + 152 + 8) + -8) == (X21 + 24))
            {
                goto label_10;
            }
            // 0x028E90A0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x028E90A4: ADD x10, x10, #0x10        | X10 = ((X20 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x028E90A8: CMP x11, x9                | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x028E90AC: B.LO #0x28e9094            | if (0 < X20 + 258) goto label_11;       
            if(val_6 < (X20 + 258))
            {
                goto label_11;
            }
            label_9:
            // 0x028E90B0: MOV x0, x20                | X0 = X20;//m1                           
            val_7 = X20;
            // 0x028E90B4: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x028E90B8: B #0x28e91ac               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x028E90BC: LDRB w8, [x21, #0x4e]      | W8 = X21 + 78;                          
            // 0x028E90C0: CMP w8, #1                 | STATE = COMPARE(X21 + 78, 0x1)          
            // 0x028E90C4: B.NE #0x28e90f4            | if (X21 + 78 != 0x1) goto label_13;     
            if((X21 + 78) != 1)
            {
                goto label_13;
            }
            // 0x028E90C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E90CC: B #0x28e90d4               |  goto label_14;                         
            goto label_14;
            label_6:
            // 0x028E90D0: MOV x0, x20                | X0 = X20;//m1                           
            label_14:
            // 0x028E90D4: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x028E90D8: MOV x1, x19                | X1 = 1152921512875755184 (0x10000001ECDD86B0);//ML01
            // 0x028E90DC: MOV x2, x21                | X2 = X21;//m1                           
            label_23:
            // 0x028E90E0: SUB sp, x29, #0x20         | SP = (1152921512875711168 - 32) = 1152921512875711136 (0x10000001ECDCDAA0);
            // 0x028E90E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E90E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E90EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E90F0: BR x3                      | X0 = this( ?? X20, ????);               
            label_13:
            // 0x028E90F4: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x028E90F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E90FC: MOV x1, x20                | X1 = X20;//m1                           
            // 0x028E9100: MOV x2, x19                | X2 = 1152921512875755184 (0x10000001ECDD86B0);//ML01
            // 0x028E9104: MOV x3, x21                | X3 = X21;//m1                           
            // 0x028E9108: SUB sp, x29, #0x20         | SP = (1152921512875711168 - 32) = 1152921512875711136 (0x10000001ECDCDAA0);
            // 0x028E910C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9110: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9114: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E9118: BR x4                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x028E911C: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
            // 0x028E9120: TBZ w0, #0, #0x28e918c     | if ((val_2 & 0x1) == 0) goto label_15;  
            if((val_2 & 1) == 0)
            {
                goto label_15;
            }
            // 0x028E9124: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9128: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X21.pressedSprite;
            // 0x028E912C: LDR x9, [x20]              | X9 = X20;                               
            // 0x028E9130: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x028E9134: LDRH w10, [x9, #0x102]     | W10 = X20 + 258;                        
            // 0x028E9138: CBZ x10, #0x28e9164        | if (X20 + 258 == 0) goto label_16;      
            if((X20 + 258) == 0)
            {
                goto label_16;
            }
            // 0x028E913C: LDR x11, [x9, #0x98]       | X11 = X20 + 152;                        
            var val_7 = X20 + 152;
            // 0x028E9140: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028E9144: ADD x11, x11, #8           | X11 = (X20 + 152 + 8);                  
            val_7 = val_7 + 8;
            label_18:
            // 0x028E9148: LDUR x13, [x11, #-8]       | X13 = (X20 + 152 + 8) + -8;             
            // 0x028E914C: CMP x13, x8                | STATE = COMPARE((X20 + 152 + 8) + -8, val_3)
            // 0x028E9150: B.EQ #0x28e91d0            | if ((X20 + 152 + 8) + -8 == val_3) goto label_17;
            if(((X20 + 152 + 8) + -8) == val_3)
            {
                goto label_17;
            }
            // 0x028E9154: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028E9158: ADD x11, x11, #0x10        | X11 = ((X20 + 152 + 8) + 16);           
            val_7 = val_7 + 16;
            // 0x028E915C: CMP x12, x10               | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x028E9160: B.LO #0x28e9148            | if (0 < X20 + 258) goto label_18;       
            if(val_8 < (X20 + 258))
            {
                goto label_18;
            }
            label_16:
            // 0x028E9164: MOV x0, x20                | X0 = X20;//m1                           
            val_8 = X20;
            // 0x028E9168: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x028E916C: MOV w2, w22                | W2 = X21 + 76;//m1                      
            // 0x028E9170: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x028E9174: B #0x28e91e0               |  goto label_19;                         
            goto label_19;
            label_8:
            // 0x028E9178: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x028E917C: LDR x9, [x20]              | X9 = X20;                               
            // 0x028E9180: ADD x8, x9, x8, lsl #4     | X8 = (X20 + (X21 + 76) << 4);           
            var val_4 = X20 + ((X21 + 76) << 4);
            // 0x028E9184: LDR x0, [x8, #0x118]       | X0 = (X20 + (X21 + 76) << 4) + 280;     
            val_9 = mem[(X20 + (X21 + 76) << 4) + 280];
            val_9 = (X20 + (X21 + 76) << 4) + 280;
            // 0x028E9188: B #0x28e91b0               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x028E918C: LDR x8, [x20]              | X8 = X20;                               
            var val_9 = X20;
            // 0x028E9190: ADD x8, x8, w22, uxtw #4   | X8 = (X20 + X21 + 76);                  
            val_9 = val_9 + (X21 + 76);
            // 0x028E9194: LDP x3, x2, [x8, #0x110]   | X3 = (X20 + X21 + 76) + 272; X2 = (X20 + X21 + 76) + 272 + 8; //  | 
            // 0x028E9198: B #0x28e91e4               |  goto label_21;                         
            goto label_21;
            label_10:
            // 0x028E919C: LDR w9, [x10]              | W9 = (X20 + 152 + 8);                   
            var val_10 = val_5;
            // 0x028E91A0: ADD w9, w9, w2             | W9 = ((X20 + 152 + 8) + X21 + 76);      
            val_10 = val_10 + (X21 + 76);
            // 0x028E91A4: ADD x8, x8, w9, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
            val_11 = val_11 + val_10;
            // 0x028E91A8: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
            val_7 = val_11 + 272;
            label_12:
            // 0x028E91AC: LDR x0, [x0, #8]           | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            val_9 = mem[((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8];
            val_9 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            label_20:
            // 0x028E91B0: MOV x1, x21                | X1 = X21;//m1                           
            // 0x028E91B4: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
            // 0x028E91B8: MOV x8, x0                 | X8 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x028E91BC: LDR x3, [x8]               | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            // 0x028E91C0: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E91C4: MOV x1, x19                | X1 = 1152921512875755184 (0x10000001ECDD86B0);//ML01
            // 0x028E91C8: MOV x2, x8                 | X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x028E91CC: B #0x28e90e0               |  goto label_23;                         
            goto label_23;
            label_17:
            // 0x028E91D0: LDR w8, [x11]              | W8 = (X20 + 152 + 8);                   
            var val_12 = val_7;
            // 0x028E91D4: ADD w8, w8, w22            | W8 = ((X20 + 152 + 8) + X21 + 76);      
            val_12 = val_12 + (X21 + 76);
            // 0x028E91D8: ADD x8, x9, w8, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
            val_12 = X20 + val_12;
            // 0x028E91DC: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
            val_8 = val_12 + 272;
            label_19:
            // 0x028E91E0: LDP x3, x2, [x0]           | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272); X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
            label_21:
            // 0x028E91E4: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E91E8: MOV x1, x19                | X1 = 1152921512875755184 (0x10000001ECDD86B0);//ML01
            // 0x028E91EC: B #0x28e90e0               |  goto label_23;                         
            goto label_23;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E91F0 (42897904), len: 40  VirtAddr: 0x028E91F0 RVA: 0x028E91F0 token: 100680190 methodIndex: 29541 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(ref object target, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x028E91F0: STP x29, x30, [sp, #-0x10]! | stack[1152921512875847600] = ???;  stack[1152921512875847608] = ???;  //  dest_result_addr=1152921512875847600 |  dest_result_addr=1152921512875847608
            // 0x028E91F4: MOV x29, sp                | X29 = 1152921512875847600 (0x10000001ECDEEFB0);//ML01
            // 0x028E91F8: STP xzr, xzr, [sp, #-0x10]! | stack[1152921512875847584] = 0x0;  stack[1152921512875847592] = 0x0;  //  dest_result_addr=1152921512875847584 |  dest_result_addr=1152921512875847592
            // 0x028E91FC: LDR x8, [x1]               | X8 = target;                            
            // 0x028E9200: MOV x1, sp                 | X1 = 1152921512875847584 (0x10000001ECDEEFA0);//ML01
            // 0x028E9204: STR x8, [sp]               | stack[1152921512875847584] = target;     //  dest_result_addr=1152921512875847584
            // 0x028E9208: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x028E920C: MOV sp, x29                | SP = 1152921512875847600 (0x10000001ECDEEFB0);//ML01
            // 0x028E9210: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E9214: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9218 (42897944), len: 40  VirtAddr: 0x028E9218 RVA: 0x028E9218 token: 100680191 methodIndex: 29542 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object EndInvoke(ref object target, System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x028E9218: STP x29, x30, [sp, #-0x10]! | stack[1152921512875979936] = ???;  stack[1152921512875979944] = ???;  //  dest_result_addr=1152921512875979936 |  dest_result_addr=1152921512875979944
            // 0x028E921C: MOV x29, sp                | X29 = 1152921512875979936 (0x10000001ECE0F4A0);//ML01
            // 0x028E9220: SUB sp, sp, #0x10          | SP = (1152921512875979936 - 16) = 1152921512875979920 (0x10000001ECE0F490);
            // 0x028E9224: STR x1, [sp, #8]           | stack[1152921512875979928] = target;     //  dest_result_addr=1152921512875979928
            // 0x028E9228: ADD x1, sp, #8             | X1 = (1152921512875979920 + 8) = 1152921512875979928 (0x10000001ECE0F498);
            // 0x028E922C: MOV x0, x2                 | X0 = result;//m1                        
            // 0x028E9230: BL #0x278fde8              | X0 = sub_278FDE8( ?? result, ????);     
            // 0x028E9234: MOV sp, x29                | SP = 1152921512875979936 (0x10000001ECE0F4A0);//ML01
            // 0x028E9238: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E923C: RET                        |  return (System.Object)result;          
            return (object)result;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
