using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class Component_Extension_Binding
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x01BFF5DC (29357532), len: 8  VirtAddr: 0x01BFF5DC RVA: 0x01BFF5DC token: 100665073 methodIndex: 31122 delegateWrapperIndex: 0 methodInvoker: 0
        public Component_Extension_Binding()
        {
            //
            // Disasemble & Code
            // 0x01BFF5DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01BFF5E0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01BFF5E4 (29357540), len: 4  VirtAddr: 0x01BFF5E4 RVA: 0x01BFF5E4 token: 100665074 methodIndex: 31123 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            // 0x01BFF5E4: RET                        |  return;                                
            return;
        
        }
    
    }

}
