using UnityEngine;
private struct Geometric.Circle
{
    // Fields
    public float x; //  0x00000000
    public float y; //  0x00000004
    public float r; //  0x00000008
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0287D3D4 (42456020), len: 12  VirtAddr: 0x0287D3D4 RVA: 0x0287D3D4 token: 100692454 methodIndex: 28326 delegateWrapperIndex: 0 methodInvoker: 0
    public Geometric.Circle(float _x, float _y, float _r)
    {
        //
        // Disasemble & Code
        // 0x0287D3D4: STP s0, s1, [x0, #0x10]    | mem[1152921514832005216] = _x;  mem[1152921514832005220] = _y;  //  dest_result_addr=1152921514832005216 |  dest_result_addr=1152921514832005220
        mem[1152921514832005216] = _x;
        mem[1152921514832005220] = _y;
        // 0x0287D3D8: STR s2, [x0, #0x18]        | mem[1152921514832005224] = _r;           //  dest_result_addr=1152921514832005224
        mem[1152921514832005224] = _r;
        // 0x0287D3DC: RET                        |  return;                                
        return;
    
    }

}
