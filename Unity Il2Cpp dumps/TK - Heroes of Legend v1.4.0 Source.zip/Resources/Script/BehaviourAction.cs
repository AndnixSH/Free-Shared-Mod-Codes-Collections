using UnityEngine;

namespace wxb
{
    public class BehaviourAction : MonoBehaviour
    {
        // Fields
        public System.Action<wxb.BehaviourAction, int> OnAnimatorIKAction; //  0x00000018
        public System.Action<wxb.BehaviourAction> OnAnimatorMoveAction; //  0x00000020
        public System.Action<wxb.BehaviourAction, bool> OnApplicationFocusAction; //  0x00000028
        public System.Action<wxb.BehaviourAction, bool> OnApplicationPauseAction; //  0x00000030
        public System.Action<wxb.BehaviourAction> OnApplicationQuitAction; //  0x00000038
        public System.Action<wxb.BehaviourAction, float[], int> OnAudioFilterReadAction; //  0x00000040
        public System.Action<wxb.BehaviourAction> OnBecameInvisibleAction; //  0x00000048
        public System.Action<wxb.BehaviourAction> OnBecameVisibleAction; //  0x00000050
        public System.Action<wxb.BehaviourAction> OnBeforeTransformParentChangedAction; //  0x00000058
        public System.Action<wxb.BehaviourAction> OnCanvasGroupChangedAction; //  0x00000060
        public System.Action<wxb.BehaviourAction, UnityEngine.Collision> OnCollisionEnterAction; //  0x00000068
        public System.Action<wxb.BehaviourAction, UnityEngine.Collision2D> OnCollisionEnter2DAction; //  0x00000070
        public System.Action<wxb.BehaviourAction, UnityEngine.Collision> OnCollisionExitAction; //  0x00000078
        public System.Action<wxb.BehaviourAction, UnityEngine.Collision2D> OnCollisionExit2DAction; //  0x00000080
        public System.Action<wxb.BehaviourAction, UnityEngine.Collision> OnCollisionStayAction; //  0x00000088
        public System.Action<wxb.BehaviourAction, UnityEngine.Collision2D> OnCollisionStay2DAction; //  0x00000090
        public System.Action<wxb.BehaviourAction> OnConnectedToServerAction; //  0x00000098
        public System.Action<wxb.BehaviourAction, UnityEngine.ControllerColliderHit> OnControllerColliderHitAction; //  0x000000A0
        public System.Action<wxb.BehaviourAction> OnDestroyAction; //  0x000000A8
        public System.Action<wxb.BehaviourAction> OnDisableAction; //  0x000000B0
        public System.Action<wxb.BehaviourAction> OnEnableAction; //  0x000000B8
        public System.Action<wxb.BehaviourAction, float> OnJointBreakAction; //  0x000000C0
        public System.Action<wxb.BehaviourAction, UnityEngine.Joint2D> OnJointBreak2DAction; //  0x000000C8
        public System.Action<wxb.BehaviourAction> OnMouseDownAction; //  0x000000D0
        public System.Action<wxb.BehaviourAction> OnMouseDragAction; //  0x000000D8
        public System.Action<wxb.BehaviourAction> OnMouseEnterAction; //  0x000000E0
        public System.Action<wxb.BehaviourAction> OnMouseExitAction; //  0x000000E8
        public System.Action<wxb.BehaviourAction> OnMouseOverAction; //  0x000000F0
        public System.Action<wxb.BehaviourAction> OnMouseUpAction; //  0x000000F8
        public System.Action<wxb.BehaviourAction> OnMouseUpAsButtonAction; //  0x00000100
        public System.Action<wxb.BehaviourAction, UnityEngine.GameObject> OnParticleCollisionAction; //  0x00000108
        public System.Action<wxb.BehaviourAction> OnParticleTriggerAction; //  0x00000110
        public System.Action<wxb.BehaviourAction> OnPostRenderAction; //  0x00000118
        public System.Action<wxb.BehaviourAction> OnPreCullAction; //  0x00000120
        public System.Action<wxb.BehaviourAction> OnPreRenderAction; //  0x00000128
        public System.Action<wxb.BehaviourAction> OnRectTransformDimensionsChangeAction; //  0x00000130
        public System.Action<wxb.BehaviourAction> OnRectTransformRemovedAction; //  0x00000138
        public System.Action<wxb.BehaviourAction, UnityEngine.RenderTexture, UnityEngine.RenderTexture> OnRenderImageAction; //  0x00000140
        public System.Action<wxb.BehaviourAction> OnRenderObjectAction; //  0x00000148
        public System.Action<wxb.BehaviourAction> OnTransformChildrenChangedAction; //  0x00000150
        public System.Action<wxb.BehaviourAction> OnTransformParentChangedAction; //  0x00000158
        public System.Action<wxb.BehaviourAction, UnityEngine.Collider> OnTriggerEnterAction; //  0x00000160
        public System.Action<wxb.BehaviourAction, UnityEngine.Collider2D> OnTriggerEnter2DAction; //  0x00000168
        public System.Action<wxb.BehaviourAction, UnityEngine.Collider> OnTriggerExitAction; //  0x00000170
        public System.Action<wxb.BehaviourAction, UnityEngine.Collider2D> OnTriggerExit2DAction; //  0x00000178
        public System.Action<wxb.BehaviourAction, UnityEngine.Collider> OnTriggerStayAction; //  0x00000180
        public System.Action<wxb.BehaviourAction, UnityEngine.Collider2D> OnTriggerStay2DAction; //  0x00000188
        public System.Action<wxb.BehaviourAction> OnValidateAction; //  0x00000190
        public System.Action<wxb.BehaviourAction> OnWillRenderObjectAction; //  0x00000198
        public System.Action<wxb.BehaviourAction> StartAction; //  0x000001A0
        public System.Action<wxb.BehaviourAction> AwakeAction; //  0x000001A8
        public System.Action<wxb.BehaviourAction> FixedUpdateAction; //  0x000001B0
        public System.Action<wxb.BehaviourAction> LateUpdateAction; //  0x000001B8
        public System.Action<wxb.BehaviourAction> UpdateAction; //  0x000001C0
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2CA44 (14862916), len: 8  VirtAddr: 0x00E2CA44 RVA: 0x00E2CA44 token: 100680849 methodIndex: 57247 delegateWrapperIndex: 0 methodInvoker: 0
        public BehaviourAction()
        {
            //
            // Disasemble & Code
            // 0x00E2CA44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2CA48: B #0x1b76fd4               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CA4C (14862924), len: 120  VirtAddr: 0x00E2CA4C RVA: 0x00E2CA4C token: 100680850 methodIndex: 57248 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnAnimatorIK(int layerIndex)
        {
            //
            // Disasemble & Code
            // 0x00E2CA4C: STP x22, x21, [sp, #-0x30]! | stack[1152921512975819584] = ???;  stack[1152921512975819592] = ???;  //  dest_result_addr=1152921512975819584 |  dest_result_addr=1152921512975819592
            // 0x00E2CA50: STP x20, x19, [sp, #0x10]  | stack[1152921512975819600] = ???;  stack[1152921512975819608] = ???;  //  dest_result_addr=1152921512975819600 |  dest_result_addr=1152921512975819608
            // 0x00E2CA54: STP x29, x30, [sp, #0x20]  | stack[1152921512975819616] = ???;  stack[1152921512975819624] = ???;  //  dest_result_addr=1152921512975819616 |  dest_result_addr=1152921512975819624
            // 0x00E2CA58: ADD x29, sp, #0x20         | X29 = (1152921512975819584 + 32) = 1152921512975819616 (0x10000001F2D46360);
            // 0x00E2CA5C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2CA60: LDRB w8, [x21, #0x8fb]     | W8 = (bool)static_value_037348FB;       
            // 0x00E2CA64: MOV w19, w1                | W19 = layerIndex;//m1                   
            // 0x00E2CA68: MOV x20, x0                | X20 = 1152921512975831632 (0x10000001F2D49250);//ML01
            // 0x00E2CA6C: TBNZ w8, #0, #0xe2ca88     | if (static_value_037348FB == true) goto label_0;
            // 0x00E2CA70: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00E2CA74: LDR x8, [x8, #0xdb8]       | X8 = 0x2B8F184;                         
            // 0x00E2CA78: LDR w0, [x8]               | W0 = 0x1323;                            
            // 0x00E2CA7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1323, ????);     
            // 0x00E2CA80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CA84: STRB w8, [x21, #0x8fb]     | static_value_037348FB = true;            //  dest_result_addr=57886971
            label_0:
            // 0x00E2CA88: LDR x0, [x20, #0x18]       | X0 = this.OnAnimatorIKAction; //P2      
            // 0x00E2CA8C: CBZ x0, #0xe2cab4          | if (this.OnAnimatorIKAction == null) goto label_1;
            if(this.OnAnimatorIKAction == null)
            {
                goto label_1;
            }
            // 0x00E2CA90: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00E2CA94: LDR x8, [x8, #0x348]       | X8 = 1152921512975806608;               
            // 0x00E2CA98: MOV x1, x20                | X1 = 1152921512975831632 (0x10000001F2D49250);//ML01
            // 0x00E2CA9C: MOV w2, w19                | W2 = layerIndex;//m1                    
            // 0x00E2CAA0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, System.Int32>::Invoke(wxb.BehaviourAction arg1, System.Int32 arg2);
            // 0x00E2CAA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CAA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CAAC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CAB0: B #0x12a2c74               | this.OnAnimatorIKAction.Invoke(arg1:  this, arg2:  layerIndex); return;
            this.OnAnimatorIKAction.Invoke(arg1:  this, arg2:  layerIndex);
            return;
            label_1:
            // 0x00E2CAB4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CAB8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CABC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CAC0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CAC4 (14863044), len: 100  VirtAddr: 0x00E2CAC4 RVA: 0x00E2CAC4 token: 100680851 methodIndex: 57249 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnAnimatorMove()
        {
            //
            // Disasemble & Code
            // 0x00E2CAC4: STP x20, x19, [sp, #-0x20]! | stack[1152921512975940816] = ???;  stack[1152921512975940824] = ???;  //  dest_result_addr=1152921512975940816 |  dest_result_addr=1152921512975940824
            // 0x00E2CAC8: STP x29, x30, [sp, #0x10]  | stack[1152921512975940832] = ???;  stack[1152921512975940840] = ???;  //  dest_result_addr=1152921512975940832 |  dest_result_addr=1152921512975940840
            // 0x00E2CACC: ADD x29, sp, #0x10         | X29 = (1152921512975940816 + 16) = 1152921512975940832 (0x10000001F2D63CE0);
            // 0x00E2CAD0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2CAD4: LDRB w8, [x20, #0x8fc]     | W8 = (bool)static_value_037348FC;       
            // 0x00E2CAD8: MOV x19, x0                | X19 = 1152921512975952848 (0x10000001F2D66BD0);//ML01
            // 0x00E2CADC: TBNZ w8, #0, #0xe2caf8     | if (static_value_037348FC == true) goto label_0;
            // 0x00E2CAE0: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00E2CAE4: LDR x8, [x8, #0xc50]       | X8 = 0x2B8F188;                         
            // 0x00E2CAE8: LDR w0, [x8]               | W0 = 0x1324;                            
            // 0x00E2CAEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1324, ????);     
            // 0x00E2CAF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CAF4: STRB w8, [x20, #0x8fc]     | static_value_037348FC = true;            //  dest_result_addr=57886972
            label_0:
            // 0x00E2CAF8: LDR x0, [x19, #0x20]       | X0 = this.OnAnimatorMoveAction; //P2    
            // 0x00E2CAFC: CBZ x0, #0xe2cb1c          | if (this.OnAnimatorMoveAction == null) goto label_1;
            if(this.OnAnimatorMoveAction == null)
            {
                goto label_1;
            }
            // 0x00E2CB00: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2CB04: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2CB08: MOV x1, x19                | X1 = 1152921512975952848 (0x10000001F2D66BD0);//ML01
            // 0x00E2CB0C: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2CB10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CB14: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CB18: B #0x129b8e0               | this.OnAnimatorMoveAction.Invoke(obj:  this); return;
            this.OnAnimatorMoveAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2CB1C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CB20: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CB24: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CB28 (14863144), len: 120  VirtAddr: 0x00E2CB28 RVA: 0x00E2CB28 token: 100680852 methodIndex: 57250 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnApplicationFocus(bool focus)
        {
            //
            // Disasemble & Code
            // 0x00E2CB28: STP x22, x21, [sp, #-0x30]! | stack[1152921512976062016] = ???;  stack[1152921512976062024] = ???;  //  dest_result_addr=1152921512976062016 |  dest_result_addr=1152921512976062024
            // 0x00E2CB2C: STP x20, x19, [sp, #0x10]  | stack[1152921512976062032] = ???;  stack[1152921512976062040] = ???;  //  dest_result_addr=1152921512976062032 |  dest_result_addr=1152921512976062040
            // 0x00E2CB30: STP x29, x30, [sp, #0x20]  | stack[1152921512976062048] = ???;  stack[1152921512976062056] = ???;  //  dest_result_addr=1152921512976062048 |  dest_result_addr=1152921512976062056
            // 0x00E2CB34: ADD x29, sp, #0x20         | X29 = (1152921512976062016 + 32) = 1152921512976062048 (0x10000001F2D81660);
            // 0x00E2CB38: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2CB3C: LDRB w8, [x21, #0x8fd]     | W8 = (bool)static_value_037348FD;       
            // 0x00E2CB40: MOV w19, w1                | W19 = focus;//m1                        
            // 0x00E2CB44: MOV x20, x0                | X20 = 1152921512976074064 (0x10000001F2D84550);//ML01
            // 0x00E2CB48: TBNZ w8, #0, #0xe2cb64     | if (static_value_037348FD == true) goto label_0;
            // 0x00E2CB4C: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00E2CB50: LDR x8, [x8, #0x250]       | X8 = 0x2B8F18C;                         
            // 0x00E2CB54: LDR w0, [x8]               | W0 = 0x1325;                            
            // 0x00E2CB58: BL #0x2782188              | X0 = sub_2782188( ?? 0x1325, ????);     
            // 0x00E2CB5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CB60: STRB w8, [x21, #0x8fd]     | static_value_037348FD = true;            //  dest_result_addr=57886973
            label_0:
            // 0x00E2CB64: LDR x0, [x20, #0x28]       | X0 = this.OnApplicationFocusAction; //P2 
            // 0x00E2CB68: CBZ x0, #0xe2cb90          | if (this.OnApplicationFocusAction == null) goto label_1;
            if(this.OnApplicationFocusAction == null)
            {
                goto label_1;
            }
            // 0x00E2CB6C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00E2CB70: LDR x8, [x8, #0xe98]       | X8 = 1152921512976049040;               
            // 0x00E2CB74: AND w2, w19, #1            | W2 = (focus & 1);                       
            bool val_1 = focus;
            // 0x00E2CB78: MOV x1, x20                | X1 = 1152921512976074064 (0x10000001F2D84550);//ML01
            // 0x00E2CB7C: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, System.Boolean>::Invoke(wxb.BehaviourAction arg1, System.Boolean arg2);
            // 0x00E2CB80: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CB84: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CB88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CB8C: B #0x12a27dc               | this.OnApplicationFocusAction.Invoke(arg1:  this, arg2:  bool val_1 = focus); return;
            this.OnApplicationFocusAction.Invoke(arg1:  this, arg2:  val_1);
            return;
            label_1:
            // 0x00E2CB90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CB94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CB98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CB9C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CBA0 (14863264), len: 120  VirtAddr: 0x00E2CBA0 RVA: 0x00E2CBA0 token: 100680853 methodIndex: 57251 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnApplicationPause(bool pause)
        {
            //
            // Disasemble & Code
            // 0x00E2CBA0: STP x22, x21, [sp, #-0x30]! | stack[1152921512976182208] = ???;  stack[1152921512976182216] = ???;  //  dest_result_addr=1152921512976182208 |  dest_result_addr=1152921512976182216
            // 0x00E2CBA4: STP x20, x19, [sp, #0x10]  | stack[1152921512976182224] = ???;  stack[1152921512976182232] = ???;  //  dest_result_addr=1152921512976182224 |  dest_result_addr=1152921512976182232
            // 0x00E2CBA8: STP x29, x30, [sp, #0x20]  | stack[1152921512976182240] = ???;  stack[1152921512976182248] = ???;  //  dest_result_addr=1152921512976182240 |  dest_result_addr=1152921512976182248
            // 0x00E2CBAC: ADD x29, sp, #0x20         | X29 = (1152921512976182208 + 32) = 1152921512976182240 (0x10000001F2D9EBE0);
            // 0x00E2CBB0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2CBB4: LDRB w8, [x21, #0x8fe]     | W8 = (bool)static_value_037348FE;       
            // 0x00E2CBB8: MOV w19, w1                | W19 = pause;//m1                        
            // 0x00E2CBBC: MOV x20, x0                | X20 = 1152921512976194256 (0x10000001F2DA1AD0);//ML01
            // 0x00E2CBC0: TBNZ w8, #0, #0xe2cbdc     | if (static_value_037348FE == true) goto label_0;
            // 0x00E2CBC4: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x00E2CBC8: LDR x8, [x8, #0xfd0]       | X8 = 0x2B8F190;                         
            // 0x00E2CBCC: LDR w0, [x8]               | W0 = 0x1326;                            
            // 0x00E2CBD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1326, ????);     
            // 0x00E2CBD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CBD8: STRB w8, [x21, #0x8fe]     | static_value_037348FE = true;            //  dest_result_addr=57886974
            label_0:
            // 0x00E2CBDC: LDR x0, [x20, #0x30]       | X0 = this.OnApplicationPauseAction; //P2 
            // 0x00E2CBE0: CBZ x0, #0xe2cc08          | if (this.OnApplicationPauseAction == null) goto label_1;
            if(this.OnApplicationPauseAction == null)
            {
                goto label_1;
            }
            // 0x00E2CBE4: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00E2CBE8: LDR x8, [x8, #0xe98]       | X8 = 1152921512976049040;               
            // 0x00E2CBEC: AND w2, w19, #1            | W2 = (pause & 1);                       
            bool val_1 = pause;
            // 0x00E2CBF0: MOV x1, x20                | X1 = 1152921512976194256 (0x10000001F2DA1AD0);//ML01
            // 0x00E2CBF4: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, System.Boolean>::Invoke(wxb.BehaviourAction arg1, System.Boolean arg2);
            // 0x00E2CBF8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CBFC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CC00: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CC04: B #0x12a27dc               | this.OnApplicationPauseAction.Invoke(arg1:  this, arg2:  bool val_1 = pause); return;
            this.OnApplicationPauseAction.Invoke(arg1:  this, arg2:  val_1);
            return;
            label_1:
            // 0x00E2CC08: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CC0C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CC10: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CC14: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CC18 (14863384), len: 100  VirtAddr: 0x00E2CC18 RVA: 0x00E2CC18 token: 100680854 methodIndex: 57252 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnApplicationQuit()
        {
            //
            // Disasemble & Code
            // 0x00E2CC18: STP x20, x19, [sp, #-0x20]! | stack[1152921512976302416] = ???;  stack[1152921512976302424] = ???;  //  dest_result_addr=1152921512976302416 |  dest_result_addr=1152921512976302424
            // 0x00E2CC1C: STP x29, x30, [sp, #0x10]  | stack[1152921512976302432] = ???;  stack[1152921512976302440] = ???;  //  dest_result_addr=1152921512976302432 |  dest_result_addr=1152921512976302440
            // 0x00E2CC20: ADD x29, sp, #0x10         | X29 = (1152921512976302416 + 16) = 1152921512976302432 (0x10000001F2DBC160);
            // 0x00E2CC24: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2CC28: LDRB w8, [x20, #0x8ff]     | W8 = (bool)static_value_037348FF;       
            // 0x00E2CC2C: MOV x19, x0                | X19 = 1152921512976314448 (0x10000001F2DBF050);//ML01
            // 0x00E2CC30: TBNZ w8, #0, #0xe2cc4c     | if (static_value_037348FF == true) goto label_0;
            // 0x00E2CC34: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00E2CC38: LDR x8, [x8, #0x368]       | X8 = 0x2B8F194;                         
            // 0x00E2CC3C: LDR w0, [x8]               | W0 = 0x1327;                            
            // 0x00E2CC40: BL #0x2782188              | X0 = sub_2782188( ?? 0x1327, ????);     
            // 0x00E2CC44: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CC48: STRB w8, [x20, #0x8ff]     | static_value_037348FF = true;            //  dest_result_addr=57886975
            label_0:
            // 0x00E2CC4C: LDR x0, [x19, #0x38]       | X0 = this.OnApplicationQuitAction; //P2 
            // 0x00E2CC50: CBZ x0, #0xe2cc70          | if (this.OnApplicationQuitAction == null) goto label_1;
            if(this.OnApplicationQuitAction == null)
            {
                goto label_1;
            }
            // 0x00E2CC54: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2CC58: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2CC5C: MOV x1, x19                | X1 = 1152921512976314448 (0x10000001F2DBF050);//ML01
            // 0x00E2CC60: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2CC64: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CC68: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CC6C: B #0x129b8e0               | this.OnApplicationQuitAction.Invoke(obj:  this); return;
            this.OnApplicationQuitAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2CC70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CC74: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CC78: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CC7C (14863484), len: 128  VirtAddr: 0x00E2CC7C RVA: 0x00E2CC7C token: 100680855 methodIndex: 57253 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnAudioFilterRead(float[] data, int channels)
        {
            //
            // Disasemble & Code
            // 0x00E2CC7C: STP x22, x21, [sp, #-0x30]! | stack[1152921512976460480] = ???;  stack[1152921512976460488] = ???;  //  dest_result_addr=1152921512976460480 |  dest_result_addr=1152921512976460488
            // 0x00E2CC80: STP x20, x19, [sp, #0x10]  | stack[1152921512976460496] = ???;  stack[1152921512976460504] = ???;  //  dest_result_addr=1152921512976460496 |  dest_result_addr=1152921512976460504
            // 0x00E2CC84: STP x29, x30, [sp, #0x20]  | stack[1152921512976460512] = ???;  stack[1152921512976460520] = ???;  //  dest_result_addr=1152921512976460512 |  dest_result_addr=1152921512976460520
            // 0x00E2CC88: ADD x29, sp, #0x20         | X29 = (1152921512976460480 + 32) = 1152921512976460512 (0x10000001F2DE2AE0);
            // 0x00E2CC8C: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E2CC90: LDRB w8, [x22, #0x900]     | W8 = (bool)static_value_03734900;       
            // 0x00E2CC94: MOV w19, w2                | W19 = channels;//m1                     
            // 0x00E2CC98: MOV x20, x1                | X20 = data;//m1                         
            // 0x00E2CC9C: MOV x21, x0                | X21 = 1152921512976472528 (0x10000001F2DE59D0);//ML01
            // 0x00E2CCA0: TBNZ w8, #0, #0xe2ccbc     | if (static_value_03734900 == true) goto label_0;
            // 0x00E2CCA4: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x00E2CCA8: LDR x8, [x8, #0x9b0]       | X8 = 0x2B8F198;                         
            // 0x00E2CCAC: LDR w0, [x8]               | W0 = 0x1328;                            
            // 0x00E2CCB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1328, ????);     
            // 0x00E2CCB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CCB8: STRB w8, [x22, #0x900]     | static_value_03734900 = true;            //  dest_result_addr=57886976
            label_0:
            // 0x00E2CCBC: LDR x0, [x21, #0x40]       | X0 = this.OnAudioFilterReadAction; //P2 
            // 0x00E2CCC0: CBZ x0, #0xe2ccec          | if (this.OnAudioFilterReadAction == null) goto label_1;
            if(this.OnAudioFilterReadAction == null)
            {
                goto label_1;
            }
            // 0x00E2CCC4: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00E2CCC8: LDR x8, [x8, #0xad8]       | X8 = 1152921512976447504;               
            // 0x00E2CCCC: MOV x2, x20                | X2 = data;//m1                          
            // 0x00E2CCD0: MOV w3, w19                | W3 = channels;//m1                      
            // 0x00E2CCD4: MOV x1, x21                | X1 = 1152921512976472528 (0x10000001F2DE59D0);//ML01
            // 0x00E2CCD8: LDR x4, [x8]               | X4 = public System.Void System.Action<wxb.BehaviourAction, System.Single[], System.Int32>::Invoke(wxb.BehaviourAction arg1, System.Single[] arg2, System.Int32 arg3);
            // 0x00E2CCDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CCE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CCE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CCE8: B #0x12a5908               | this.OnAudioFilterReadAction.Invoke(arg1:  this, arg2:  data, arg3:  channels); return;
            this.OnAudioFilterReadAction.Invoke(arg1:  this, arg2:  data, arg3:  channels);
            return;
            label_1:
            // 0x00E2CCEC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CCF0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CCF4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CCF8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CCFC (14863612), len: 100  VirtAddr: 0x00E2CCFC RVA: 0x00E2CCFC token: 100680856 methodIndex: 57254 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnBecameInvisible()
        {
            //
            // Disasemble & Code
            // 0x00E2CCFC: STP x20, x19, [sp, #-0x20]! | stack[1152921512976617552] = ???;  stack[1152921512976617560] = ???;  //  dest_result_addr=1152921512976617552 |  dest_result_addr=1152921512976617560
            // 0x00E2CD00: STP x29, x30, [sp, #0x10]  | stack[1152921512976617568] = ???;  stack[1152921512976617576] = ???;  //  dest_result_addr=1152921512976617568 |  dest_result_addr=1152921512976617576
            // 0x00E2CD04: ADD x29, sp, #0x10         | X29 = (1152921512976617552 + 16) = 1152921512976617568 (0x10000001F2E09060);
            // 0x00E2CD08: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2CD0C: LDRB w8, [x20, #0x901]     | W8 = (bool)static_value_03734901;       
            // 0x00E2CD10: MOV x19, x0                | X19 = 1152921512976629584 (0x10000001F2E0BF50);//ML01
            // 0x00E2CD14: TBNZ w8, #0, #0xe2cd30     | if (static_value_03734901 == true) goto label_0;
            // 0x00E2CD18: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00E2CD1C: LDR x8, [x8, #0x90]        | X8 = 0x2B8F19C;                         
            // 0x00E2CD20: LDR w0, [x8]               | W0 = 0x1329;                            
            // 0x00E2CD24: BL #0x2782188              | X0 = sub_2782188( ?? 0x1329, ????);     
            // 0x00E2CD28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CD2C: STRB w8, [x20, #0x901]     | static_value_03734901 = true;            //  dest_result_addr=57886977
            label_0:
            // 0x00E2CD30: LDR x0, [x19, #0x48]       | X0 = this.OnBecameInvisibleAction; //P2 
            // 0x00E2CD34: CBZ x0, #0xe2cd54          | if (this.OnBecameInvisibleAction == null) goto label_1;
            if(this.OnBecameInvisibleAction == null)
            {
                goto label_1;
            }
            // 0x00E2CD38: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2CD3C: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2CD40: MOV x1, x19                | X1 = 1152921512976629584 (0x10000001F2E0BF50);//ML01
            // 0x00E2CD44: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2CD48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CD4C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CD50: B #0x129b8e0               | this.OnBecameInvisibleAction.Invoke(obj:  this); return;
            this.OnBecameInvisibleAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2CD54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CD58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CD5C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CD60 (14863712), len: 100  VirtAddr: 0x00E2CD60 RVA: 0x00E2CD60 token: 100680857 methodIndex: 57255 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnBecameVisible()
        {
            //
            // Disasemble & Code
            // 0x00E2CD60: STP x20, x19, [sp, #-0x20]! | stack[1152921512976737744] = ???;  stack[1152921512976737752] = ???;  //  dest_result_addr=1152921512976737744 |  dest_result_addr=1152921512976737752
            // 0x00E2CD64: STP x29, x30, [sp, #0x10]  | stack[1152921512976737760] = ???;  stack[1152921512976737768] = ???;  //  dest_result_addr=1152921512976737760 |  dest_result_addr=1152921512976737768
            // 0x00E2CD68: ADD x29, sp, #0x10         | X29 = (1152921512976737744 + 16) = 1152921512976737760 (0x10000001F2E265E0);
            // 0x00E2CD6C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2CD70: LDRB w8, [x20, #0x902]     | W8 = (bool)static_value_03734902;       
            // 0x00E2CD74: MOV x19, x0                | X19 = 1152921512976749776 (0x10000001F2E294D0);//ML01
            // 0x00E2CD78: TBNZ w8, #0, #0xe2cd94     | if (static_value_03734902 == true) goto label_0;
            // 0x00E2CD7C: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00E2CD80: LDR x8, [x8, #0xef0]       | X8 = 0x2B8F1A0;                         
            // 0x00E2CD84: LDR w0, [x8]               | W0 = 0x132A;                            
            // 0x00E2CD88: BL #0x2782188              | X0 = sub_2782188( ?? 0x132A, ????);     
            // 0x00E2CD8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CD90: STRB w8, [x20, #0x902]     | static_value_03734902 = true;            //  dest_result_addr=57886978
            label_0:
            // 0x00E2CD94: LDR x0, [x19, #0x50]       | X0 = this.OnBecameVisibleAction; //P2   
            // 0x00E2CD98: CBZ x0, #0xe2cdb8          | if (this.OnBecameVisibleAction == null) goto label_1;
            if(this.OnBecameVisibleAction == null)
            {
                goto label_1;
            }
            // 0x00E2CD9C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2CDA0: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2CDA4: MOV x1, x19                | X1 = 1152921512976749776 (0x10000001F2E294D0);//ML01
            // 0x00E2CDA8: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2CDAC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CDB0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CDB4: B #0x129b8e0               | this.OnBecameVisibleAction.Invoke(obj:  this); return;
            this.OnBecameVisibleAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2CDB8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CDBC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CDC0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CDC4 (14863812), len: 100  VirtAddr: 0x00E2CDC4 RVA: 0x00E2CDC4 token: 100680858 methodIndex: 57256 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnBeforeTransformParentChanged()
        {
            //
            // Disasemble & Code
            // 0x00E2CDC4: STP x20, x19, [sp, #-0x20]! | stack[1152921512976857936] = ???;  stack[1152921512976857944] = ???;  //  dest_result_addr=1152921512976857936 |  dest_result_addr=1152921512976857944
            // 0x00E2CDC8: STP x29, x30, [sp, #0x10]  | stack[1152921512976857952] = ???;  stack[1152921512976857960] = ???;  //  dest_result_addr=1152921512976857952 |  dest_result_addr=1152921512976857960
            // 0x00E2CDCC: ADD x29, sp, #0x10         | X29 = (1152921512976857936 + 16) = 1152921512976857952 (0x10000001F2E43B60);
            // 0x00E2CDD0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2CDD4: LDRB w8, [x20, #0x903]     | W8 = (bool)static_value_03734903;       
            // 0x00E2CDD8: MOV x19, x0                | X19 = 1152921512976869968 (0x10000001F2E46A50);//ML01
            // 0x00E2CDDC: TBNZ w8, #0, #0xe2cdf8     | if (static_value_03734903 == true) goto label_0;
            // 0x00E2CDE0: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00E2CDE4: LDR x8, [x8, #0xc00]       | X8 = 0x2B8F1A4;                         
            // 0x00E2CDE8: LDR w0, [x8]               | W0 = 0x132B;                            
            // 0x00E2CDEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x132B, ????);     
            // 0x00E2CDF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CDF4: STRB w8, [x20, #0x903]     | static_value_03734903 = true;            //  dest_result_addr=57886979
            label_0:
            // 0x00E2CDF8: LDR x0, [x19, #0x58]       | X0 = this.OnBeforeTransformParentChangedAction; //P2 
            // 0x00E2CDFC: CBZ x0, #0xe2ce1c          | if (this.OnBeforeTransformParentChangedAction == null) goto label_1;
            if(this.OnBeforeTransformParentChangedAction == null)
            {
                goto label_1;
            }
            // 0x00E2CE00: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2CE04: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2CE08: MOV x1, x19                | X1 = 1152921512976869968 (0x10000001F2E46A50);//ML01
            // 0x00E2CE0C: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2CE10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CE14: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CE18: B #0x129b8e0               | this.OnBeforeTransformParentChangedAction.Invoke(obj:  this); return;
            this.OnBeforeTransformParentChangedAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2CE1C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CE20: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CE24: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CE28 (14863912), len: 100  VirtAddr: 0x00E2CE28 RVA: 0x00E2CE28 token: 100680859 methodIndex: 57257 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCanvasGroupChanged()
        {
            //
            // Disasemble & Code
            // 0x00E2CE28: STP x20, x19, [sp, #-0x20]! | stack[1152921512976978128] = ???;  stack[1152921512976978136] = ???;  //  dest_result_addr=1152921512976978128 |  dest_result_addr=1152921512976978136
            // 0x00E2CE2C: STP x29, x30, [sp, #0x10]  | stack[1152921512976978144] = ???;  stack[1152921512976978152] = ???;  //  dest_result_addr=1152921512976978144 |  dest_result_addr=1152921512976978152
            // 0x00E2CE30: ADD x29, sp, #0x10         | X29 = (1152921512976978128 + 16) = 1152921512976978144 (0x10000001F2E610E0);
            // 0x00E2CE34: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2CE38: LDRB w8, [x20, #0x904]     | W8 = (bool)static_value_03734904;       
            // 0x00E2CE3C: MOV x19, x0                | X19 = 1152921512976990160 (0x10000001F2E63FD0);//ML01
            // 0x00E2CE40: TBNZ w8, #0, #0xe2ce5c     | if (static_value_03734904 == true) goto label_0;
            // 0x00E2CE44: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00E2CE48: LDR x8, [x8, #0x4d8]       | X8 = 0x2B8F1A8;                         
            // 0x00E2CE4C: LDR w0, [x8]               | W0 = 0x132C;                            
            // 0x00E2CE50: BL #0x2782188              | X0 = sub_2782188( ?? 0x132C, ????);     
            // 0x00E2CE54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CE58: STRB w8, [x20, #0x904]     | static_value_03734904 = true;            //  dest_result_addr=57886980
            label_0:
            // 0x00E2CE5C: LDR x0, [x19, #0x60]       | X0 = this.OnCanvasGroupChangedAction; //P2 
            // 0x00E2CE60: CBZ x0, #0xe2ce80          | if (this.OnCanvasGroupChangedAction == null) goto label_1;
            if(this.OnCanvasGroupChangedAction == null)
            {
                goto label_1;
            }
            // 0x00E2CE64: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2CE68: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2CE6C: MOV x1, x19                | X1 = 1152921512976990160 (0x10000001F2E63FD0);//ML01
            // 0x00E2CE70: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2CE74: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CE78: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CE7C: B #0x129b8e0               | this.OnCanvasGroupChangedAction.Invoke(obj:  this); return;
            this.OnCanvasGroupChangedAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2CE80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CE84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CE88: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CE8C (14864012), len: 120  VirtAddr: 0x00E2CE8C RVA: 0x00E2CE8C token: 100680860 methodIndex: 57258 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCollisionEnter(UnityEngine.Collision collision)
        {
            //
            // Disasemble & Code
            // 0x00E2CE8C: STP x22, x21, [sp, #-0x30]! | stack[1152921512977103424] = ???;  stack[1152921512977103432] = ???;  //  dest_result_addr=1152921512977103424 |  dest_result_addr=1152921512977103432
            // 0x00E2CE90: STP x20, x19, [sp, #0x10]  | stack[1152921512977103440] = ???;  stack[1152921512977103448] = ???;  //  dest_result_addr=1152921512977103440 |  dest_result_addr=1152921512977103448
            // 0x00E2CE94: STP x29, x30, [sp, #0x20]  | stack[1152921512977103456] = ???;  stack[1152921512977103464] = ???;  //  dest_result_addr=1152921512977103456 |  dest_result_addr=1152921512977103464
            // 0x00E2CE98: ADD x29, sp, #0x20         | X29 = (1152921512977103424 + 32) = 1152921512977103456 (0x10000001F2E7FA60);
            // 0x00E2CE9C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2CEA0: LDRB w8, [x21, #0x905]     | W8 = (bool)static_value_03734905;       
            // 0x00E2CEA4: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2CEA8: MOV x20, x0                | X20 = 1152921512977115472 (0x10000001F2E82950);//ML01
            // 0x00E2CEAC: TBNZ w8, #0, #0xe2cec8     | if (static_value_03734905 == true) goto label_0;
            // 0x00E2CEB0: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00E2CEB4: LDR x8, [x8, #0xf0]        | X8 = 0x2B8F1AC;                         
            // 0x00E2CEB8: LDR w0, [x8]               | W0 = 0x132D;                            
            // 0x00E2CEBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x132D, ????);     
            // 0x00E2CEC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CEC4: STRB w8, [x21, #0x905]     | static_value_03734905 = true;            //  dest_result_addr=57886981
            label_0:
            // 0x00E2CEC8: LDR x0, [x20, #0x68]       | X0 = this.OnCollisionEnterAction; //P2  
            // 0x00E2CECC: CBZ x0, #0xe2cef4          | if (this.OnCollisionEnterAction == null) goto label_1;
            if(this.OnCollisionEnterAction == null)
            {
                goto label_1;
            }
            // 0x00E2CED0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E2CED4: LDR x8, [x8, #0xc58]       | X8 = 1152921512977090448;               
            // 0x00E2CED8: MOV x1, x20                | X1 = 1152921512977115472 (0x10000001F2E82950);//ML01
            // 0x00E2CEDC: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2CEE0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collision>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collision arg2);
            // 0x00E2CEE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CEE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CEEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CEF0: B #0x12a30fc               | this.OnCollisionEnterAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnCollisionEnterAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2CEF4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CEF8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CEFC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CF00: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CF04 (14864132), len: 120  VirtAddr: 0x00E2CF04 RVA: 0x00E2CF04 token: 100680861 methodIndex: 57259 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCollisionEnter2D(UnityEngine.Collision2D collision)
        {
            //
            // Disasemble & Code
            // 0x00E2CF04: STP x22, x21, [sp, #-0x30]! | stack[1152921512977232832] = ???;  stack[1152921512977232840] = ???;  //  dest_result_addr=1152921512977232832 |  dest_result_addr=1152921512977232840
            // 0x00E2CF08: STP x20, x19, [sp, #0x10]  | stack[1152921512977232848] = ???;  stack[1152921512977232856] = ???;  //  dest_result_addr=1152921512977232848 |  dest_result_addr=1152921512977232856
            // 0x00E2CF0C: STP x29, x30, [sp, #0x20]  | stack[1152921512977232864] = ???;  stack[1152921512977232872] = ???;  //  dest_result_addr=1152921512977232864 |  dest_result_addr=1152921512977232872
            // 0x00E2CF10: ADD x29, sp, #0x20         | X29 = (1152921512977232832 + 32) = 1152921512977232864 (0x10000001F2E9F3E0);
            // 0x00E2CF14: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2CF18: LDRB w8, [x21, #0x906]     | W8 = (bool)static_value_03734906;       
            // 0x00E2CF1C: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2CF20: MOV x20, x0                | X20 = 1152921512977244880 (0x10000001F2EA22D0);//ML01
            // 0x00E2CF24: TBNZ w8, #0, #0xe2cf40     | if (static_value_03734906 == true) goto label_0;
            // 0x00E2CF28: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00E2CF2C: LDR x8, [x8, #0xef8]       | X8 = 0x2B8F1B0;                         
            // 0x00E2CF30: LDR w0, [x8]               | W0 = 0x132E;                            
            // 0x00E2CF34: BL #0x2782188              | X0 = sub_2782188( ?? 0x132E, ????);     
            // 0x00E2CF38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CF3C: STRB w8, [x21, #0x906]     | static_value_03734906 = true;            //  dest_result_addr=57886982
            label_0:
            // 0x00E2CF40: LDR x0, [x20, #0x70]       | X0 = this.OnCollisionEnter2DAction; //P2 
            // 0x00E2CF44: CBZ x0, #0xe2cf6c          | if (this.OnCollisionEnter2DAction == null) goto label_1;
            if(this.OnCollisionEnter2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2CF48: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00E2CF4C: LDR x8, [x8, #0xb40]       | X8 = 1152921512977219856;               
            // 0x00E2CF50: MOV x1, x20                | X1 = 1152921512977244880 (0x10000001F2EA22D0);//ML01
            // 0x00E2CF54: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2CF58: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collision2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collision2D arg2);
            // 0x00E2CF5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CF60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CF64: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CF68: B #0x12a30fc               | this.OnCollisionEnter2DAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnCollisionEnter2DAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2CF6C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CF70: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CF74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CF78: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CF7C (14864252), len: 120  VirtAddr: 0x00E2CF7C RVA: 0x00E2CF7C token: 100680862 methodIndex: 57260 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCollisionExit(UnityEngine.Collision collision)
        {
            //
            // Disasemble & Code
            // 0x00E2CF7C: STP x22, x21, [sp, #-0x30]! | stack[1152921512977361216] = ???;  stack[1152921512977361224] = ???;  //  dest_result_addr=1152921512977361216 |  dest_result_addr=1152921512977361224
            // 0x00E2CF80: STP x20, x19, [sp, #0x10]  | stack[1152921512977361232] = ???;  stack[1152921512977361240] = ???;  //  dest_result_addr=1152921512977361232 |  dest_result_addr=1152921512977361240
            // 0x00E2CF84: STP x29, x30, [sp, #0x20]  | stack[1152921512977361248] = ???;  stack[1152921512977361256] = ???;  //  dest_result_addr=1152921512977361248 |  dest_result_addr=1152921512977361256
            // 0x00E2CF88: ADD x29, sp, #0x20         | X29 = (1152921512977361216 + 32) = 1152921512977361248 (0x10000001F2EBE960);
            // 0x00E2CF8C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2CF90: LDRB w8, [x21, #0x907]     | W8 = (bool)static_value_03734907;       
            // 0x00E2CF94: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2CF98: MOV x20, x0                | X20 = 1152921512977373264 (0x10000001F2EC1850);//ML01
            // 0x00E2CF9C: TBNZ w8, #0, #0xe2cfb8     | if (static_value_03734907 == true) goto label_0;
            // 0x00E2CFA0: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x00E2CFA4: LDR x8, [x8, #0x528]       | X8 = 0x2B8F1B4;                         
            // 0x00E2CFA8: LDR w0, [x8]               | W0 = 0x132F;                            
            // 0x00E2CFAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x132F, ????);     
            // 0x00E2CFB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2CFB4: STRB w8, [x21, #0x907]     | static_value_03734907 = true;            //  dest_result_addr=57886983
            label_0:
            // 0x00E2CFB8: LDR x0, [x20, #0x78]       | X0 = this.OnCollisionExitAction; //P2   
            // 0x00E2CFBC: CBZ x0, #0xe2cfe4          | if (this.OnCollisionExitAction == null) goto label_1;
            if(this.OnCollisionExitAction == null)
            {
                goto label_1;
            }
            // 0x00E2CFC0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E2CFC4: LDR x8, [x8, #0xc58]       | X8 = 1152921512977090448;               
            // 0x00E2CFC8: MOV x1, x20                | X1 = 1152921512977373264 (0x10000001F2EC1850);//ML01
            // 0x00E2CFCC: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2CFD0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collision>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collision arg2);
            // 0x00E2CFD4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CFD8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CFDC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CFE0: B #0x12a30fc               | this.OnCollisionExitAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnCollisionExitAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2CFE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CFE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CFEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2CFF0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CFF4 (14864372), len: 120  VirtAddr: 0x00E2CFF4 RVA: 0x00E2CFF4 token: 100680863 methodIndex: 57261 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCollisionExit2D(UnityEngine.Collision2D collision)
        {
            //
            // Disasemble & Code
            // 0x00E2CFF4: STP x22, x21, [sp, #-0x30]! | stack[1152921512977489600] = ???;  stack[1152921512977489608] = ???;  //  dest_result_addr=1152921512977489600 |  dest_result_addr=1152921512977489608
            // 0x00E2CFF8: STP x20, x19, [sp, #0x10]  | stack[1152921512977489616] = ???;  stack[1152921512977489624] = ???;  //  dest_result_addr=1152921512977489616 |  dest_result_addr=1152921512977489624
            // 0x00E2CFFC: STP x29, x30, [sp, #0x20]  | stack[1152921512977489632] = ???;  stack[1152921512977489640] = ???;  //  dest_result_addr=1152921512977489632 |  dest_result_addr=1152921512977489640
            // 0x00E2D000: ADD x29, sp, #0x20         | X29 = (1152921512977489600 + 32) = 1152921512977489632 (0x10000001F2EDDEE0);
            // 0x00E2D004: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2D008: LDRB w8, [x21, #0x908]     | W8 = (bool)static_value_03734908;       
            // 0x00E2D00C: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2D010: MOV x20, x0                | X20 = 1152921512977501648 (0x10000001F2EE0DD0);//ML01
            // 0x00E2D014: TBNZ w8, #0, #0xe2d030     | if (static_value_03734908 == true) goto label_0;
            // 0x00E2D018: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00E2D01C: LDR x8, [x8, #0x6b8]       | X8 = 0x2B8F1B8;                         
            // 0x00E2D020: LDR w0, [x8]               | W0 = 0x1330;                            
            // 0x00E2D024: BL #0x2782188              | X0 = sub_2782188( ?? 0x1330, ????);     
            // 0x00E2D028: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D02C: STRB w8, [x21, #0x908]     | static_value_03734908 = true;            //  dest_result_addr=57886984
            label_0:
            // 0x00E2D030: LDR x0, [x20, #0x80]       | X0 = this.OnCollisionExit2DAction; //P2 
            // 0x00E2D034: CBZ x0, #0xe2d05c          | if (this.OnCollisionExit2DAction == null) goto label_1;
            if(this.OnCollisionExit2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2D038: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00E2D03C: LDR x8, [x8, #0xb40]       | X8 = 1152921512977219856;               
            // 0x00E2D040: MOV x1, x20                | X1 = 1152921512977501648 (0x10000001F2EE0DD0);//ML01
            // 0x00E2D044: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2D048: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collision2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collision2D arg2);
            // 0x00E2D04C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D050: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D054: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D058: B #0x12a30fc               | this.OnCollisionExit2DAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnCollisionExit2DAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2D05C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D060: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D064: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D068: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D06C (14864492), len: 120  VirtAddr: 0x00E2D06C RVA: 0x00E2D06C token: 100680864 methodIndex: 57262 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCollisionStay(UnityEngine.Collision collision)
        {
            //
            // Disasemble & Code
            // 0x00E2D06C: STP x22, x21, [sp, #-0x30]! | stack[1152921512977617984] = ???;  stack[1152921512977617992] = ???;  //  dest_result_addr=1152921512977617984 |  dest_result_addr=1152921512977617992
            // 0x00E2D070: STP x20, x19, [sp, #0x10]  | stack[1152921512977618000] = ???;  stack[1152921512977618008] = ???;  //  dest_result_addr=1152921512977618000 |  dest_result_addr=1152921512977618008
            // 0x00E2D074: STP x29, x30, [sp, #0x20]  | stack[1152921512977618016] = ???;  stack[1152921512977618024] = ???;  //  dest_result_addr=1152921512977618016 |  dest_result_addr=1152921512977618024
            // 0x00E2D078: ADD x29, sp, #0x20         | X29 = (1152921512977617984 + 32) = 1152921512977618016 (0x10000001F2EFD460);
            // 0x00E2D07C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2D080: LDRB w8, [x21, #0x909]     | W8 = (bool)static_value_03734909;       
            // 0x00E2D084: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2D088: MOV x20, x0                | X20 = 1152921512977630032 (0x10000001F2F00350);//ML01
            // 0x00E2D08C: TBNZ w8, #0, #0xe2d0a8     | if (static_value_03734909 == true) goto label_0;
            // 0x00E2D090: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x00E2D094: LDR x8, [x8, #0x840]       | X8 = 0x2B8F1BC;                         
            // 0x00E2D098: LDR w0, [x8]               | W0 = 0x1331;                            
            // 0x00E2D09C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1331, ????);     
            // 0x00E2D0A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D0A4: STRB w8, [x21, #0x909]     | static_value_03734909 = true;            //  dest_result_addr=57886985
            label_0:
            // 0x00E2D0A8: LDR x0, [x20, #0x88]       | X0 = this.OnCollisionStayAction; //P2   
            // 0x00E2D0AC: CBZ x0, #0xe2d0d4          | if (this.OnCollisionStayAction == null) goto label_1;
            if(this.OnCollisionStayAction == null)
            {
                goto label_1;
            }
            // 0x00E2D0B0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E2D0B4: LDR x8, [x8, #0xc58]       | X8 = 1152921512977090448;               
            // 0x00E2D0B8: MOV x1, x20                | X1 = 1152921512977630032 (0x10000001F2F00350);//ML01
            // 0x00E2D0BC: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2D0C0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collision>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collision arg2);
            // 0x00E2D0C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D0C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D0CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D0D0: B #0x12a30fc               | this.OnCollisionStayAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnCollisionStayAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2D0D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D0D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D0DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D0E0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D0E4 (14864612), len: 120  VirtAddr: 0x00E2D0E4 RVA: 0x00E2D0E4 token: 100680865 methodIndex: 57263 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnCollisionStay2D(UnityEngine.Collision2D collision)
        {
            //
            // Disasemble & Code
            // 0x00E2D0E4: STP x22, x21, [sp, #-0x30]! | stack[1152921512977746368] = ???;  stack[1152921512977746376] = ???;  //  dest_result_addr=1152921512977746368 |  dest_result_addr=1152921512977746376
            // 0x00E2D0E8: STP x20, x19, [sp, #0x10]  | stack[1152921512977746384] = ???;  stack[1152921512977746392] = ???;  //  dest_result_addr=1152921512977746384 |  dest_result_addr=1152921512977746392
            // 0x00E2D0EC: STP x29, x30, [sp, #0x20]  | stack[1152921512977746400] = ???;  stack[1152921512977746408] = ???;  //  dest_result_addr=1152921512977746400 |  dest_result_addr=1152921512977746408
            // 0x00E2D0F0: ADD x29, sp, #0x20         | X29 = (1152921512977746368 + 32) = 1152921512977746400 (0x10000001F2F1C9E0);
            // 0x00E2D0F4: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2D0F8: LDRB w8, [x21, #0x90a]     | W8 = (bool)static_value_0373490A;       
            // 0x00E2D0FC: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2D100: MOV x20, x0                | X20 = 1152921512977758416 (0x10000001F2F1F8D0);//ML01
            // 0x00E2D104: TBNZ w8, #0, #0xe2d120     | if (static_value_0373490A == true) goto label_0;
            // 0x00E2D108: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00E2D10C: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8F1C0;                         
            // 0x00E2D110: LDR w0, [x8]               | W0 = 0x1332;                            
            // 0x00E2D114: BL #0x2782188              | X0 = sub_2782188( ?? 0x1332, ????);     
            // 0x00E2D118: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D11C: STRB w8, [x21, #0x90a]     | static_value_0373490A = true;            //  dest_result_addr=57886986
            label_0:
            // 0x00E2D120: LDR x0, [x20, #0x90]       | X0 = this.OnCollisionStay2DAction; //P2 
            // 0x00E2D124: CBZ x0, #0xe2d14c          | if (this.OnCollisionStay2DAction == null) goto label_1;
            if(this.OnCollisionStay2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2D128: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00E2D12C: LDR x8, [x8, #0xb40]       | X8 = 1152921512977219856;               
            // 0x00E2D130: MOV x1, x20                | X1 = 1152921512977758416 (0x10000001F2F1F8D0);//ML01
            // 0x00E2D134: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2D138: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collision2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collision2D arg2);
            // 0x00E2D13C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D140: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D144: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D148: B #0x12a30fc               | this.OnCollisionStay2DAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnCollisionStay2DAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2D14C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D150: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D154: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D158: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D15C (14864732), len: 100  VirtAddr: 0x00E2D15C RVA: 0x00E2D15C token: 100680866 methodIndex: 57264 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnConnectedToServer()
        {
            //
            // Disasemble & Code
            // 0x00E2D15C: STP x20, x19, [sp, #-0x20]! | stack[1152921512977870672] = ???;  stack[1152921512977870680] = ???;  //  dest_result_addr=1152921512977870672 |  dest_result_addr=1152921512977870680
            // 0x00E2D160: STP x29, x30, [sp, #0x10]  | stack[1152921512977870688] = ???;  stack[1152921512977870696] = ???;  //  dest_result_addr=1152921512977870688 |  dest_result_addr=1152921512977870696
            // 0x00E2D164: ADD x29, sp, #0x10         | X29 = (1152921512977870672 + 16) = 1152921512977870688 (0x10000001F2F3AF60);
            // 0x00E2D168: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D16C: LDRB w8, [x20, #0x90b]     | W8 = (bool)static_value_0373490B;       
            // 0x00E2D170: MOV x19, x0                | X19 = 1152921512977882704 (0x10000001F2F3DE50);//ML01
            // 0x00E2D174: TBNZ w8, #0, #0xe2d190     | if (static_value_0373490B == true) goto label_0;
            // 0x00E2D178: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00E2D17C: LDR x8, [x8, #0x9d0]       | X8 = 0x2B8F1C4;                         
            // 0x00E2D180: LDR w0, [x8]               | W0 = 0x1333;                            
            // 0x00E2D184: BL #0x2782188              | X0 = sub_2782188( ?? 0x1333, ????);     
            // 0x00E2D188: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D18C: STRB w8, [x20, #0x90b]     | static_value_0373490B = true;            //  dest_result_addr=57886987
            label_0:
            // 0x00E2D190: LDR x0, [x19, #0x98]       | X0 = this.OnConnectedToServerAction; //P2 
            // 0x00E2D194: CBZ x0, #0xe2d1b4          | if (this.OnConnectedToServerAction == null) goto label_1;
            if(this.OnConnectedToServerAction == null)
            {
                goto label_1;
            }
            // 0x00E2D198: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D19C: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D1A0: MOV x1, x19                | X1 = 1152921512977882704 (0x10000001F2F3DE50);//ML01
            // 0x00E2D1A4: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D1A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D1AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D1B0: B #0x129b8e0               | this.OnConnectedToServerAction.Invoke(obj:  this); return;
            this.OnConnectedToServerAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D1B4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D1B8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D1BC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D1C0 (14864832), len: 120  VirtAddr: 0x00E2D1C0 RVA: 0x00E2D1C0 token: 100680867 methodIndex: 57265 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnControllerColliderHit(UnityEngine.ControllerColliderHit hit)
        {
            //
            // Disasemble & Code
            // 0x00E2D1C0: STP x22, x21, [sp, #-0x30]! | stack[1152921512977995968] = ???;  stack[1152921512977995976] = ???;  //  dest_result_addr=1152921512977995968 |  dest_result_addr=1152921512977995976
            // 0x00E2D1C4: STP x20, x19, [sp, #0x10]  | stack[1152921512977995984] = ???;  stack[1152921512977995992] = ???;  //  dest_result_addr=1152921512977995984 |  dest_result_addr=1152921512977995992
            // 0x00E2D1C8: STP x29, x30, [sp, #0x20]  | stack[1152921512977996000] = ???;  stack[1152921512977996008] = ???;  //  dest_result_addr=1152921512977996000 |  dest_result_addr=1152921512977996008
            // 0x00E2D1CC: ADD x29, sp, #0x20         | X29 = (1152921512977995968 + 32) = 1152921512977996000 (0x10000001F2F598E0);
            // 0x00E2D1D0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2D1D4: LDRB w8, [x21, #0x90c]     | W8 = (bool)static_value_0373490C;       
            // 0x00E2D1D8: MOV x19, x1                | X19 = hit;//m1                          
            // 0x00E2D1DC: MOV x20, x0                | X20 = 1152921512978008016 (0x10000001F2F5C7D0);//ML01
            // 0x00E2D1E0: TBNZ w8, #0, #0xe2d1fc     | if (static_value_0373490C == true) goto label_0;
            // 0x00E2D1E4: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00E2D1E8: LDR x8, [x8, #0xf50]       | X8 = 0x2B8F1C8;                         
            // 0x00E2D1EC: LDR w0, [x8]               | W0 = 0x1334;                            
            // 0x00E2D1F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1334, ????);     
            // 0x00E2D1F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D1F8: STRB w8, [x21, #0x90c]     | static_value_0373490C = true;            //  dest_result_addr=57886988
            label_0:
            // 0x00E2D1FC: LDR x0, [x20, #0xa0]       | X0 = this.OnControllerColliderHitAction; //P2 
            // 0x00E2D200: CBZ x0, #0xe2d228          | if (this.OnControllerColliderHitAction == null) goto label_1;
            if(this.OnControllerColliderHitAction == null)
            {
                goto label_1;
            }
            // 0x00E2D204: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00E2D208: LDR x8, [x8, #0x18]        | X8 = 1152921512977982992;               
            // 0x00E2D20C: MOV x1, x20                | X1 = 1152921512978008016 (0x10000001F2F5C7D0);//ML01
            // 0x00E2D210: MOV x2, x19                | X2 = hit;//m1                           
            // 0x00E2D214: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.ControllerColliderHit>::Invoke(wxb.BehaviourAction arg1, UnityEngine.ControllerColliderHit arg2);
            // 0x00E2D218: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D21C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D220: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D224: B #0x12a30fc               | this.OnControllerColliderHitAction.Invoke(arg1:  this, arg2:  hit); return;
            this.OnControllerColliderHitAction.Invoke(arg1:  this, arg2:  hit);
            return;
            label_1:
            // 0x00E2D228: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D22C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D230: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D234: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D238 (14864952), len: 100  VirtAddr: 0x00E2D238 RVA: 0x00E2D238 token: 100680868 methodIndex: 57266 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnDestroy()
        {
            //
            // Disasemble & Code
            // 0x00E2D238: STP x20, x19, [sp, #-0x20]! | stack[1152921512978120272] = ???;  stack[1152921512978120280] = ???;  //  dest_result_addr=1152921512978120272 |  dest_result_addr=1152921512978120280
            // 0x00E2D23C: STP x29, x30, [sp, #0x10]  | stack[1152921512978120288] = ???;  stack[1152921512978120296] = ???;  //  dest_result_addr=1152921512978120288 |  dest_result_addr=1152921512978120296
            // 0x00E2D240: ADD x29, sp, #0x10         | X29 = (1152921512978120272 + 16) = 1152921512978120288 (0x10000001F2F77E60);
            // 0x00E2D244: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D248: LDRB w8, [x20, #0x90d]     | W8 = (bool)static_value_0373490D;       
            // 0x00E2D24C: MOV x19, x0                | X19 = 1152921512978132304 (0x10000001F2F7AD50);//ML01
            // 0x00E2D250: TBNZ w8, #0, #0xe2d26c     | if (static_value_0373490D == true) goto label_0;
            // 0x00E2D254: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00E2D258: LDR x8, [x8, #0x898]       | X8 = 0x2B8F1CC;                         
            // 0x00E2D25C: LDR w0, [x8]               | W0 = 0x1335;                            
            // 0x00E2D260: BL #0x2782188              | X0 = sub_2782188( ?? 0x1335, ????);     
            // 0x00E2D264: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D268: STRB w8, [x20, #0x90d]     | static_value_0373490D = true;            //  dest_result_addr=57886989
            label_0:
            // 0x00E2D26C: LDR x0, [x19, #0xa8]       | X0 = this.OnDestroyAction; //P2         
            // 0x00E2D270: CBZ x0, #0xe2d290          | if (this.OnDestroyAction == null) goto label_1;
            if(this.OnDestroyAction == null)
            {
                goto label_1;
            }
            // 0x00E2D274: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D278: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D27C: MOV x1, x19                | X1 = 1152921512978132304 (0x10000001F2F7AD50);//ML01
            // 0x00E2D280: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D284: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D288: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D28C: B #0x129b8e0               | this.OnDestroyAction.Invoke(obj:  this); return;
            this.OnDestroyAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D290: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D294: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D298: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D29C (14865052), len: 100  VirtAddr: 0x00E2D29C RVA: 0x00E2D29C token: 100680869 methodIndex: 57267 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnDisable()
        {
            //
            // Disasemble & Code
            // 0x00E2D29C: STP x20, x19, [sp, #-0x20]! | stack[1152921512978240464] = ???;  stack[1152921512978240472] = ???;  //  dest_result_addr=1152921512978240464 |  dest_result_addr=1152921512978240472
            // 0x00E2D2A0: STP x29, x30, [sp, #0x10]  | stack[1152921512978240480] = ???;  stack[1152921512978240488] = ???;  //  dest_result_addr=1152921512978240480 |  dest_result_addr=1152921512978240488
            // 0x00E2D2A4: ADD x29, sp, #0x10         | X29 = (1152921512978240464 + 16) = 1152921512978240480 (0x10000001F2F953E0);
            // 0x00E2D2A8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D2AC: LDRB w8, [x20, #0x90e]     | W8 = (bool)static_value_0373490E;       
            // 0x00E2D2B0: MOV x19, x0                | X19 = 1152921512978252496 (0x10000001F2F982D0);//ML01
            // 0x00E2D2B4: TBNZ w8, #0, #0xe2d2d0     | if (static_value_0373490E == true) goto label_0;
            // 0x00E2D2B8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00E2D2BC: LDR x8, [x8, #0xf20]       | X8 = 0x2B8F1D0;                         
            // 0x00E2D2C0: LDR w0, [x8]               | W0 = 0x1336;                            
            // 0x00E2D2C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1336, ????);     
            // 0x00E2D2C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D2CC: STRB w8, [x20, #0x90e]     | static_value_0373490E = true;            //  dest_result_addr=57886990
            label_0:
            // 0x00E2D2D0: LDR x0, [x19, #0xb0]       | X0 = this.OnDisableAction; //P2         
            // 0x00E2D2D4: CBZ x0, #0xe2d2f4          | if (this.OnDisableAction == null) goto label_1;
            if(this.OnDisableAction == null)
            {
                goto label_1;
            }
            // 0x00E2D2D8: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D2DC: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D2E0: MOV x1, x19                | X1 = 1152921512978252496 (0x10000001F2F982D0);//ML01
            // 0x00E2D2E4: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D2E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D2EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D2F0: B #0x129b8e0               | this.OnDisableAction.Invoke(obj:  this); return;
            this.OnDisableAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D2F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D2F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D2FC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D300 (14865152), len: 100  VirtAddr: 0x00E2D300 RVA: 0x00E2D300 token: 100680870 methodIndex: 57268 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnEnable()
        {
            //
            // Disasemble & Code
            // 0x00E2D300: STP x20, x19, [sp, #-0x20]! | stack[1152921512978360656] = ???;  stack[1152921512978360664] = ???;  //  dest_result_addr=1152921512978360656 |  dest_result_addr=1152921512978360664
            // 0x00E2D304: STP x29, x30, [sp, #0x10]  | stack[1152921512978360672] = ???;  stack[1152921512978360680] = ???;  //  dest_result_addr=1152921512978360672 |  dest_result_addr=1152921512978360680
            // 0x00E2D308: ADD x29, sp, #0x10         | X29 = (1152921512978360656 + 16) = 1152921512978360672 (0x10000001F2FB2960);
            // 0x00E2D30C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D310: LDRB w8, [x20, #0x90f]     | W8 = (bool)static_value_0373490F;       
            // 0x00E2D314: MOV x19, x0                | X19 = 1152921512978372688 (0x10000001F2FB5850);//ML01
            // 0x00E2D318: TBNZ w8, #0, #0xe2d334     | if (static_value_0373490F == true) goto label_0;
            // 0x00E2D31C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00E2D320: LDR x8, [x8, #0xdf0]       | X8 = 0x2B8F1D4;                         
            // 0x00E2D324: LDR w0, [x8]               | W0 = 0x1337;                            
            // 0x00E2D328: BL #0x2782188              | X0 = sub_2782188( ?? 0x1337, ????);     
            // 0x00E2D32C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D330: STRB w8, [x20, #0x90f]     | static_value_0373490F = true;            //  dest_result_addr=57886991
            label_0:
            // 0x00E2D334: LDR x0, [x19, #0xb8]       | X0 = this.OnEnableAction; //P2          
            // 0x00E2D338: CBZ x0, #0xe2d358          | if (this.OnEnableAction == null) goto label_1;
            if(this.OnEnableAction == null)
            {
                goto label_1;
            }
            // 0x00E2D33C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D340: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D344: MOV x1, x19                | X1 = 1152921512978372688 (0x10000001F2FB5850);//ML01
            // 0x00E2D348: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D34C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D350: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D354: B #0x129b8e0               | this.OnEnableAction.Invoke(obj:  this); return;
            this.OnEnableAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D358: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D35C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D360: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D364 (14865252), len: 120  VirtAddr: 0x00E2D364 RVA: 0x00E2D364 token: 100680871 methodIndex: 57269 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnJointBreak(float breakForce)
        {
            //
            // Disasemble & Code
            // 0x00E2D364: STP d9, d8, [sp, #-0x30]!  | stack[1152921512978481856] = ???;  stack[1152921512978481864] = ???;  //  dest_result_addr=1152921512978481856 |  dest_result_addr=1152921512978481864
            // 0x00E2D368: STP x20, x19, [sp, #0x10]  | stack[1152921512978481872] = ???;  stack[1152921512978481880] = ???;  //  dest_result_addr=1152921512978481872 |  dest_result_addr=1152921512978481880
            // 0x00E2D36C: STP x29, x30, [sp, #0x20]  | stack[1152921512978481888] = ???;  stack[1152921512978481896] = ???;  //  dest_result_addr=1152921512978481888 |  dest_result_addr=1152921512978481896
            // 0x00E2D370: ADD x29, sp, #0x20         | X29 = (1152921512978481856 + 32) = 1152921512978481888 (0x10000001F2FD02E0);
            // 0x00E2D374: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D378: LDRB w8, [x20, #0x910]     | W8 = (bool)static_value_03734910;       
            // 0x00E2D37C: MOV v8.16b, v0.16b         | V8 = breakForce;//m1                    
            // 0x00E2D380: MOV x19, x0                | X19 = 1152921512978493904 (0x10000001F2FD31D0);//ML01
            // 0x00E2D384: TBNZ w8, #0, #0xe2d3a0     | if (static_value_03734910 == true) goto label_0;
            // 0x00E2D388: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00E2D38C: LDR x8, [x8, #0x838]       | X8 = 0x2B8F1D8;                         
            // 0x00E2D390: LDR w0, [x8]               | W0 = 0x1338;                            
            // 0x00E2D394: BL #0x2782188              | X0 = sub_2782188( ?? 0x1338, ????);     
            // 0x00E2D398: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D39C: STRB w8, [x20, #0x910]     | static_value_03734910 = true;            //  dest_result_addr=57886992
            label_0:
            // 0x00E2D3A0: LDR x0, [x19, #0xc0]       | X0 = this.OnJointBreakAction; //P2      
            // 0x00E2D3A4: CBZ x0, #0xe2d3cc          | if (this.OnJointBreakAction == null) goto label_1;
            if(this.OnJointBreakAction == null)
            {
                goto label_1;
            }
            // 0x00E2D3A8: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00E2D3AC: LDR x8, [x8, #0xab0]       | X8 = 1152921512978468880;               
            // 0x00E2D3B0: MOV x1, x19                | X1 = 1152921512978493904 (0x10000001F2FD31D0);//ML01
            // 0x00E2D3B4: MOV v0.16b, v8.16b         | V0 = breakForce;//m1                    
            // 0x00E2D3B8: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction, System.Single>::Invoke(wxb.BehaviourAction arg1, System.Single arg2);
            // 0x00E2D3BC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D3C0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D3C4: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00E2D3C8: B #0x12a3518               | this.OnJointBreakAction.Invoke(arg1:  this, arg2:  breakForce); return;
            this.OnJointBreakAction.Invoke(arg1:  this, arg2:  breakForce);
            return;
            label_1:
            // 0x00E2D3CC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D3D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D3D4: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00E2D3D8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D3DC (14865372), len: 120  VirtAddr: 0x00E2D3DC RVA: 0x00E2D3DC token: 100680872 methodIndex: 57270 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnJointBreak2D(UnityEngine.Joint2D joint)
        {
            //
            // Disasemble & Code
            // 0x00E2D3DC: STP x22, x21, [sp, #-0x30]! | stack[1152921512978607168] = ???;  stack[1152921512978607176] = ???;  //  dest_result_addr=1152921512978607168 |  dest_result_addr=1152921512978607176
            // 0x00E2D3E0: STP x20, x19, [sp, #0x10]  | stack[1152921512978607184] = ???;  stack[1152921512978607192] = ???;  //  dest_result_addr=1152921512978607184 |  dest_result_addr=1152921512978607192
            // 0x00E2D3E4: STP x29, x30, [sp, #0x20]  | stack[1152921512978607200] = ???;  stack[1152921512978607208] = ???;  //  dest_result_addr=1152921512978607200 |  dest_result_addr=1152921512978607208
            // 0x00E2D3E8: ADD x29, sp, #0x20         | X29 = (1152921512978607168 + 32) = 1152921512978607200 (0x10000001F2FEEC60);
            // 0x00E2D3EC: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2D3F0: LDRB w8, [x21, #0x911]     | W8 = (bool)static_value_03734911;       
            // 0x00E2D3F4: MOV x19, x1                | X19 = joint;//m1                        
            // 0x00E2D3F8: MOV x20, x0                | X20 = 1152921512978619216 (0x10000001F2FF1B50);//ML01
            // 0x00E2D3FC: TBNZ w8, #0, #0xe2d418     | if (static_value_03734911 == true) goto label_0;
            // 0x00E2D400: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00E2D404: LDR x8, [x8, #0x3c8]       | X8 = 0x2B8F1DC;                         
            // 0x00E2D408: LDR w0, [x8]               | W0 = 0x1339;                            
            // 0x00E2D40C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1339, ????);     
            // 0x00E2D410: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D414: STRB w8, [x21, #0x911]     | static_value_03734911 = true;            //  dest_result_addr=57886993
            label_0:
            // 0x00E2D418: LDR x0, [x20, #0xc8]       | X0 = this.OnJointBreak2DAction; //P2    
            // 0x00E2D41C: CBZ x0, #0xe2d444          | if (this.OnJointBreak2DAction == null) goto label_1;
            if(this.OnJointBreak2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2D420: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00E2D424: LDR x8, [x8, #0x640]       | X8 = 1152921512978594192;               
            // 0x00E2D428: MOV x1, x20                | X1 = 1152921512978619216 (0x10000001F2FF1B50);//ML01
            // 0x00E2D42C: MOV x2, x19                | X2 = joint;//m1                         
            // 0x00E2D430: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Joint2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Joint2D arg2);
            // 0x00E2D434: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D438: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D43C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D440: B #0x12a30fc               | this.OnJointBreak2DAction.Invoke(arg1:  this, arg2:  joint); return;
            this.OnJointBreak2DAction.Invoke(arg1:  this, arg2:  joint);
            return;
            label_1:
            // 0x00E2D444: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D448: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D44C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D450: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D454 (14865492), len: 100  VirtAddr: 0x00E2D454 RVA: 0x00E2D454 token: 100680873 methodIndex: 57271 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseDown()
        {
            //
            // Disasemble & Code
            // 0x00E2D454: STP x20, x19, [sp, #-0x20]! | stack[1152921512978731472] = ???;  stack[1152921512978731480] = ???;  //  dest_result_addr=1152921512978731472 |  dest_result_addr=1152921512978731480
            // 0x00E2D458: STP x29, x30, [sp, #0x10]  | stack[1152921512978731488] = ???;  stack[1152921512978731496] = ???;  //  dest_result_addr=1152921512978731488 |  dest_result_addr=1152921512978731496
            // 0x00E2D45C: ADD x29, sp, #0x10         | X29 = (1152921512978731472 + 16) = 1152921512978731488 (0x10000001F300D1E0);
            // 0x00E2D460: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D464: LDRB w8, [x20, #0x912]     | W8 = (bool)static_value_03734912;       
            // 0x00E2D468: MOV x19, x0                | X19 = 1152921512978743504 (0x10000001F30100D0);//ML01
            // 0x00E2D46C: TBNZ w8, #0, #0xe2d488     | if (static_value_03734912 == true) goto label_0;
            // 0x00E2D470: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00E2D474: LDR x8, [x8, #0xc80]       | X8 = 0x2B8F1E0;                         
            // 0x00E2D478: LDR w0, [x8]               | W0 = 0x133A;                            
            // 0x00E2D47C: BL #0x2782188              | X0 = sub_2782188( ?? 0x133A, ????);     
            // 0x00E2D480: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D484: STRB w8, [x20, #0x912]     | static_value_03734912 = true;            //  dest_result_addr=57886994
            label_0:
            // 0x00E2D488: LDR x0, [x19, #0xd0]       | X0 = this.OnMouseDownAction; //P2       
            // 0x00E2D48C: CBZ x0, #0xe2d4ac          | if (this.OnMouseDownAction == null) goto label_1;
            if(this.OnMouseDownAction == null)
            {
                goto label_1;
            }
            // 0x00E2D490: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D494: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D498: MOV x1, x19                | X1 = 1152921512978743504 (0x10000001F30100D0);//ML01
            // 0x00E2D49C: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D4A0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D4A4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D4A8: B #0x129b8e0               | this.OnMouseDownAction.Invoke(obj:  this); return;
            this.OnMouseDownAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D4AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D4B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D4B4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D4B8 (14865592), len: 100  VirtAddr: 0x00E2D4B8 RVA: 0x00E2D4B8 token: 100680874 methodIndex: 57272 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseDrag()
        {
            //
            // Disasemble & Code
            // 0x00E2D4B8: STP x20, x19, [sp, #-0x20]! | stack[1152921512978851664] = ???;  stack[1152921512978851672] = ???;  //  dest_result_addr=1152921512978851664 |  dest_result_addr=1152921512978851672
            // 0x00E2D4BC: STP x29, x30, [sp, #0x10]  | stack[1152921512978851680] = ???;  stack[1152921512978851688] = ???;  //  dest_result_addr=1152921512978851680 |  dest_result_addr=1152921512978851688
            // 0x00E2D4C0: ADD x29, sp, #0x10         | X29 = (1152921512978851664 + 16) = 1152921512978851680 (0x10000001F302A760);
            // 0x00E2D4C4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D4C8: LDRB w8, [x20, #0x913]     | W8 = (bool)static_value_03734913;       
            // 0x00E2D4CC: MOV x19, x0                | X19 = 1152921512978863696 (0x10000001F302D650);//ML01
            // 0x00E2D4D0: TBNZ w8, #0, #0xe2d4ec     | if (static_value_03734913 == true) goto label_0;
            // 0x00E2D4D4: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00E2D4D8: LDR x8, [x8, #0xfd8]       | X8 = 0x2B8F1E4;                         
            // 0x00E2D4DC: LDR w0, [x8]               | W0 = 0x133B;                            
            // 0x00E2D4E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x133B, ????);     
            // 0x00E2D4E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D4E8: STRB w8, [x20, #0x913]     | static_value_03734913 = true;            //  dest_result_addr=57886995
            label_0:
            // 0x00E2D4EC: LDR x0, [x19, #0xd8]       | X0 = this.OnMouseDragAction; //P2       
            // 0x00E2D4F0: CBZ x0, #0xe2d510          | if (this.OnMouseDragAction == null) goto label_1;
            if(this.OnMouseDragAction == null)
            {
                goto label_1;
            }
            // 0x00E2D4F4: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D4F8: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D4FC: MOV x1, x19                | X1 = 1152921512978863696 (0x10000001F302D650);//ML01
            // 0x00E2D500: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D504: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D508: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D50C: B #0x129b8e0               | this.OnMouseDragAction.Invoke(obj:  this); return;
            this.OnMouseDragAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D510: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D514: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D518: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D51C (14865692), len: 100  VirtAddr: 0x00E2D51C RVA: 0x00E2D51C token: 100680875 methodIndex: 57273 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseEnter()
        {
            //
            // Disasemble & Code
            // 0x00E2D51C: STP x20, x19, [sp, #-0x20]! | stack[1152921512978971856] = ???;  stack[1152921512978971864] = ???;  //  dest_result_addr=1152921512978971856 |  dest_result_addr=1152921512978971864
            // 0x00E2D520: STP x29, x30, [sp, #0x10]  | stack[1152921512978971872] = ???;  stack[1152921512978971880] = ???;  //  dest_result_addr=1152921512978971872 |  dest_result_addr=1152921512978971880
            // 0x00E2D524: ADD x29, sp, #0x10         | X29 = (1152921512978971856 + 16) = 1152921512978971872 (0x10000001F3047CE0);
            // 0x00E2D528: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D52C: LDRB w8, [x20, #0x914]     | W8 = (bool)static_value_03734914;       
            // 0x00E2D530: MOV x19, x0                | X19 = 1152921512978983888 (0x10000001F304ABD0);//ML01
            // 0x00E2D534: TBNZ w8, #0, #0xe2d550     | if (static_value_03734914 == true) goto label_0;
            // 0x00E2D538: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E2D53C: LDR x8, [x8, #0xe90]       | X8 = 0x2B8F1E8;                         
            // 0x00E2D540: LDR w0, [x8]               | W0 = 0x133C;                            
            // 0x00E2D544: BL #0x2782188              | X0 = sub_2782188( ?? 0x133C, ????);     
            // 0x00E2D548: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D54C: STRB w8, [x20, #0x914]     | static_value_03734914 = true;            //  dest_result_addr=57886996
            label_0:
            // 0x00E2D550: LDR x0, [x19, #0xe0]       | X0 = this.OnMouseEnterAction; //P2      
            // 0x00E2D554: CBZ x0, #0xe2d574          | if (this.OnMouseEnterAction == null) goto label_1;
            if(this.OnMouseEnterAction == null)
            {
                goto label_1;
            }
            // 0x00E2D558: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D55C: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D560: MOV x1, x19                | X1 = 1152921512978983888 (0x10000001F304ABD0);//ML01
            // 0x00E2D564: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D568: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D56C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D570: B #0x129b8e0               | this.OnMouseEnterAction.Invoke(obj:  this); return;
            this.OnMouseEnterAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D574: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D578: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D57C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D580 (14865792), len: 100  VirtAddr: 0x00E2D580 RVA: 0x00E2D580 token: 100680876 methodIndex: 57274 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseExit()
        {
            //
            // Disasemble & Code
            // 0x00E2D580: STP x20, x19, [sp, #-0x20]! | stack[1152921512979092048] = ???;  stack[1152921512979092056] = ???;  //  dest_result_addr=1152921512979092048 |  dest_result_addr=1152921512979092056
            // 0x00E2D584: STP x29, x30, [sp, #0x10]  | stack[1152921512979092064] = ???;  stack[1152921512979092072] = ???;  //  dest_result_addr=1152921512979092064 |  dest_result_addr=1152921512979092072
            // 0x00E2D588: ADD x29, sp, #0x10         | X29 = (1152921512979092048 + 16) = 1152921512979092064 (0x10000001F3065260);
            // 0x00E2D58C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D590: LDRB w8, [x20, #0x915]     | W8 = (bool)static_value_03734915;       
            // 0x00E2D594: MOV x19, x0                | X19 = 1152921512979104080 (0x10000001F3068150);//ML01
            // 0x00E2D598: TBNZ w8, #0, #0xe2d5b4     | if (static_value_03734915 == true) goto label_0;
            // 0x00E2D59C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00E2D5A0: LDR x8, [x8, #0x240]       | X8 = 0x2B8F1EC;                         
            // 0x00E2D5A4: LDR w0, [x8]               | W0 = 0x133D;                            
            // 0x00E2D5A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x133D, ????);     
            // 0x00E2D5AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D5B0: STRB w8, [x20, #0x915]     | static_value_03734915 = true;            //  dest_result_addr=57886997
            label_0:
            // 0x00E2D5B4: LDR x0, [x19, #0xe8]       | X0 = this.OnMouseExitAction; //P2       
            // 0x00E2D5B8: CBZ x0, #0xe2d5d8          | if (this.OnMouseExitAction == null) goto label_1;
            if(this.OnMouseExitAction == null)
            {
                goto label_1;
            }
            // 0x00E2D5BC: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D5C0: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D5C4: MOV x1, x19                | X1 = 1152921512979104080 (0x10000001F3068150);//ML01
            // 0x00E2D5C8: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D5CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D5D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D5D4: B #0x129b8e0               | this.OnMouseExitAction.Invoke(obj:  this); return;
            this.OnMouseExitAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D5D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D5DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D5E0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D5E4 (14865892), len: 100  VirtAddr: 0x00E2D5E4 RVA: 0x00E2D5E4 token: 100680877 methodIndex: 57275 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseOver()
        {
            //
            // Disasemble & Code
            // 0x00E2D5E4: STP x20, x19, [sp, #-0x20]! | stack[1152921512979212240] = ???;  stack[1152921512979212248] = ???;  //  dest_result_addr=1152921512979212240 |  dest_result_addr=1152921512979212248
            // 0x00E2D5E8: STP x29, x30, [sp, #0x10]  | stack[1152921512979212256] = ???;  stack[1152921512979212264] = ???;  //  dest_result_addr=1152921512979212256 |  dest_result_addr=1152921512979212264
            // 0x00E2D5EC: ADD x29, sp, #0x10         | X29 = (1152921512979212240 + 16) = 1152921512979212256 (0x10000001F30827E0);
            // 0x00E2D5F0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D5F4: LDRB w8, [x20, #0x916]     | W8 = (bool)static_value_03734916;       
            // 0x00E2D5F8: MOV x19, x0                | X19 = 1152921512979224272 (0x10000001F30856D0);//ML01
            // 0x00E2D5FC: TBNZ w8, #0, #0xe2d618     | if (static_value_03734916 == true) goto label_0;
            // 0x00E2D600: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00E2D604: LDR x8, [x8, #0xf90]       | X8 = 0x2B8F1F0;                         
            // 0x00E2D608: LDR w0, [x8]               | W0 = 0x133E;                            
            // 0x00E2D60C: BL #0x2782188              | X0 = sub_2782188( ?? 0x133E, ????);     
            // 0x00E2D610: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D614: STRB w8, [x20, #0x916]     | static_value_03734916 = true;            //  dest_result_addr=57886998
            label_0:
            // 0x00E2D618: LDR x0, [x19, #0xf0]       | X0 = this.OnMouseOverAction; //P2       
            // 0x00E2D61C: CBZ x0, #0xe2d63c          | if (this.OnMouseOverAction == null) goto label_1;
            if(this.OnMouseOverAction == null)
            {
                goto label_1;
            }
            // 0x00E2D620: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D624: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D628: MOV x1, x19                | X1 = 1152921512979224272 (0x10000001F30856D0);//ML01
            // 0x00E2D62C: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D630: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D634: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D638: B #0x129b8e0               | this.OnMouseOverAction.Invoke(obj:  this); return;
            this.OnMouseOverAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D63C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D640: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D644: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D648 (14865992), len: 100  VirtAddr: 0x00E2D648 RVA: 0x00E2D648 token: 100680878 methodIndex: 57276 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseUp()
        {
            //
            // Disasemble & Code
            // 0x00E2D648: STP x20, x19, [sp, #-0x20]! | stack[1152921512979332432] = ???;  stack[1152921512979332440] = ???;  //  dest_result_addr=1152921512979332432 |  dest_result_addr=1152921512979332440
            // 0x00E2D64C: STP x29, x30, [sp, #0x10]  | stack[1152921512979332448] = ???;  stack[1152921512979332456] = ???;  //  dest_result_addr=1152921512979332448 |  dest_result_addr=1152921512979332456
            // 0x00E2D650: ADD x29, sp, #0x10         | X29 = (1152921512979332432 + 16) = 1152921512979332448 (0x10000001F309FD60);
            // 0x00E2D654: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D658: LDRB w8, [x20, #0x917]     | W8 = (bool)static_value_03734917;       
            // 0x00E2D65C: MOV x19, x0                | X19 = 1152921512979344464 (0x10000001F30A2C50);//ML01
            // 0x00E2D660: TBNZ w8, #0, #0xe2d67c     | if (static_value_03734917 == true) goto label_0;
            // 0x00E2D664: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00E2D668: LDR x8, [x8, #0x138]       | X8 = 0x2B8F1F4;                         
            // 0x00E2D66C: LDR w0, [x8]               | W0 = 0x133F;                            
            // 0x00E2D670: BL #0x2782188              | X0 = sub_2782188( ?? 0x133F, ????);     
            // 0x00E2D674: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D678: STRB w8, [x20, #0x917]     | static_value_03734917 = true;            //  dest_result_addr=57886999
            label_0:
            // 0x00E2D67C: LDR x0, [x19, #0xf8]       | X0 = this.OnMouseUpAction; //P2         
            // 0x00E2D680: CBZ x0, #0xe2d6a0          | if (this.OnMouseUpAction == null) goto label_1;
            if(this.OnMouseUpAction == null)
            {
                goto label_1;
            }
            // 0x00E2D684: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D688: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D68C: MOV x1, x19                | X1 = 1152921512979344464 (0x10000001F30A2C50);//ML01
            // 0x00E2D690: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D694: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D698: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D69C: B #0x129b8e0               | this.OnMouseUpAction.Invoke(obj:  this); return;
            this.OnMouseUpAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D6A0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D6A4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D6A8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D6AC (14866092), len: 100  VirtAddr: 0x00E2D6AC RVA: 0x00E2D6AC token: 100680879 methodIndex: 57277 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnMouseUpAsButton()
        {
            //
            // Disasemble & Code
            // 0x00E2D6AC: STP x20, x19, [sp, #-0x20]! | stack[1152921512979452624] = ???;  stack[1152921512979452632] = ???;  //  dest_result_addr=1152921512979452624 |  dest_result_addr=1152921512979452632
            // 0x00E2D6B0: STP x29, x30, [sp, #0x10]  | stack[1152921512979452640] = ???;  stack[1152921512979452648] = ???;  //  dest_result_addr=1152921512979452640 |  dest_result_addr=1152921512979452648
            // 0x00E2D6B4: ADD x29, sp, #0x10         | X29 = (1152921512979452624 + 16) = 1152921512979452640 (0x10000001F30BD2E0);
            // 0x00E2D6B8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D6BC: LDRB w8, [x20, #0x918]     | W8 = (bool)static_value_03734918;       
            // 0x00E2D6C0: MOV x19, x0                | X19 = 1152921512979464656 (0x10000001F30C01D0);//ML01
            // 0x00E2D6C4: TBNZ w8, #0, #0xe2d6e0     | if (static_value_03734918 == true) goto label_0;
            // 0x00E2D6C8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00E2D6CC: LDR x8, [x8, #0x888]       | X8 = 0x2B8F1F8;                         
            // 0x00E2D6D0: LDR w0, [x8]               | W0 = 0x1340;                            
            // 0x00E2D6D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1340, ????);     
            // 0x00E2D6D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D6DC: STRB w8, [x20, #0x918]     | static_value_03734918 = true;            //  dest_result_addr=57887000
            label_0:
            // 0x00E2D6E0: LDR x0, [x19, #0x100]      | X0 = this.OnMouseUpAsButtonAction; //P2 
            // 0x00E2D6E4: CBZ x0, #0xe2d704          | if (this.OnMouseUpAsButtonAction == null) goto label_1;
            if(this.OnMouseUpAsButtonAction == null)
            {
                goto label_1;
            }
            // 0x00E2D6E8: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D6EC: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D6F0: MOV x1, x19                | X1 = 1152921512979464656 (0x10000001F30C01D0);//ML01
            // 0x00E2D6F4: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D6F8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D6FC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D700: B #0x129b8e0               | this.OnMouseUpAsButtonAction.Invoke(obj:  this); return;
            this.OnMouseUpAsButtonAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D704: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D708: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D70C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D710 (14866192), len: 120  VirtAddr: 0x00E2D710 RVA: 0x00E2D710 token: 100680880 methodIndex: 57278 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnParticleCollision(UnityEngine.GameObject other)
        {
            //
            // Disasemble & Code
            // 0x00E2D710: STP x22, x21, [sp, #-0x30]! | stack[1152921512979577920] = ???;  stack[1152921512979577928] = ???;  //  dest_result_addr=1152921512979577920 |  dest_result_addr=1152921512979577928
            // 0x00E2D714: STP x20, x19, [sp, #0x10]  | stack[1152921512979577936] = ???;  stack[1152921512979577944] = ???;  //  dest_result_addr=1152921512979577936 |  dest_result_addr=1152921512979577944
            // 0x00E2D718: STP x29, x30, [sp, #0x20]  | stack[1152921512979577952] = ???;  stack[1152921512979577960] = ???;  //  dest_result_addr=1152921512979577952 |  dest_result_addr=1152921512979577960
            // 0x00E2D71C: ADD x29, sp, #0x20         | X29 = (1152921512979577920 + 32) = 1152921512979577952 (0x10000001F30DBC60);
            // 0x00E2D720: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2D724: LDRB w8, [x21, #0x919]     | W8 = (bool)static_value_03734919;       
            // 0x00E2D728: MOV x19, x1                | X19 = other;//m1                        
            // 0x00E2D72C: MOV x20, x0                | X20 = 1152921512979589968 (0x10000001F30DEB50);//ML01
            // 0x00E2D730: TBNZ w8, #0, #0xe2d74c     | if (static_value_03734919 == true) goto label_0;
            // 0x00E2D734: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00E2D738: LDR x8, [x8, #0x28]        | X8 = 0x2B8F1FC;                         
            // 0x00E2D73C: LDR w0, [x8]               | W0 = 0x1341;                            
            // 0x00E2D740: BL #0x2782188              | X0 = sub_2782188( ?? 0x1341, ????);     
            // 0x00E2D744: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D748: STRB w8, [x21, #0x919]     | static_value_03734919 = true;            //  dest_result_addr=57887001
            label_0:
            // 0x00E2D74C: LDR x0, [x20, #0x108]      | X0 = this.OnParticleCollisionAction; //P2 
            // 0x00E2D750: CBZ x0, #0xe2d778          | if (this.OnParticleCollisionAction == null) goto label_1;
            if(this.OnParticleCollisionAction == null)
            {
                goto label_1;
            }
            // 0x00E2D754: ADRP x8, #0x3684000        | X8 = 57163776 (0x3684000);              
            // 0x00E2D758: LDR x8, [x8, #0x2e0]       | X8 = 1152921512979564944;               
            // 0x00E2D75C: MOV x1, x20                | X1 = 1152921512979589968 (0x10000001F30DEB50);//ML01
            // 0x00E2D760: MOV x2, x19                | X2 = other;//m1                         
            // 0x00E2D764: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.GameObject>::Invoke(wxb.BehaviourAction arg1, UnityEngine.GameObject arg2);
            // 0x00E2D768: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D76C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D770: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D774: B #0x12a30fc               | this.OnParticleCollisionAction.Invoke(arg1:  this, arg2:  other); return;
            this.OnParticleCollisionAction.Invoke(arg1:  this, arg2:  other);
            return;
            label_1:
            // 0x00E2D778: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D77C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D780: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2D784: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D788 (14866312), len: 100  VirtAddr: 0x00E2D788 RVA: 0x00E2D788 token: 100680881 methodIndex: 57279 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnParticleTrigger()
        {
            //
            // Disasemble & Code
            // 0x00E2D788: STP x20, x19, [sp, #-0x20]! | stack[1152921512979702224] = ???;  stack[1152921512979702232] = ???;  //  dest_result_addr=1152921512979702224 |  dest_result_addr=1152921512979702232
            // 0x00E2D78C: STP x29, x30, [sp, #0x10]  | stack[1152921512979702240] = ???;  stack[1152921512979702248] = ???;  //  dest_result_addr=1152921512979702240 |  dest_result_addr=1152921512979702248
            // 0x00E2D790: ADD x29, sp, #0x10         | X29 = (1152921512979702224 + 16) = 1152921512979702240 (0x10000001F30FA1E0);
            // 0x00E2D794: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D798: LDRB w8, [x20, #0x91a]     | W8 = (bool)static_value_0373491A;       
            // 0x00E2D79C: MOV x19, x0                | X19 = 1152921512979714256 (0x10000001F30FD0D0);//ML01
            // 0x00E2D7A0: TBNZ w8, #0, #0xe2d7bc     | if (static_value_0373491A == true) goto label_0;
            // 0x00E2D7A4: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00E2D7A8: LDR x8, [x8, #0xe98]       | X8 = 0x2B8F200;                         
            // 0x00E2D7AC: LDR w0, [x8]               | W0 = 0x1342;                            
            // 0x00E2D7B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1342, ????);     
            // 0x00E2D7B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D7B8: STRB w8, [x20, #0x91a]     | static_value_0373491A = true;            //  dest_result_addr=57887002
            label_0:
            // 0x00E2D7BC: LDR x0, [x19, #0x110]      | X0 = this.OnParticleTriggerAction; //P2 
            // 0x00E2D7C0: CBZ x0, #0xe2d7e0          | if (this.OnParticleTriggerAction == null) goto label_1;
            if(this.OnParticleTriggerAction == null)
            {
                goto label_1;
            }
            // 0x00E2D7C4: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D7C8: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D7CC: MOV x1, x19                | X1 = 1152921512979714256 (0x10000001F30FD0D0);//ML01
            // 0x00E2D7D0: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D7D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D7D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D7DC: B #0x129b8e0               | this.OnParticleTriggerAction.Invoke(obj:  this); return;
            this.OnParticleTriggerAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D7E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D7E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D7E8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D7EC (14866412), len: 100  VirtAddr: 0x00E2D7EC RVA: 0x00E2D7EC token: 100680882 methodIndex: 57280 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnPostRender()
        {
            //
            // Disasemble & Code
            // 0x00E2D7EC: STP x20, x19, [sp, #-0x20]! | stack[1152921512979822416] = ???;  stack[1152921512979822424] = ???;  //  dest_result_addr=1152921512979822416 |  dest_result_addr=1152921512979822424
            // 0x00E2D7F0: STP x29, x30, [sp, #0x10]  | stack[1152921512979822432] = ???;  stack[1152921512979822440] = ???;  //  dest_result_addr=1152921512979822432 |  dest_result_addr=1152921512979822440
            // 0x00E2D7F4: ADD x29, sp, #0x10         | X29 = (1152921512979822416 + 16) = 1152921512979822432 (0x10000001F3117760);
            // 0x00E2D7F8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D7FC: LDRB w8, [x20, #0x91b]     | W8 = (bool)static_value_0373491B;       
            // 0x00E2D800: MOV x19, x0                | X19 = 1152921512979834448 (0x10000001F311A650);//ML01
            // 0x00E2D804: TBNZ w8, #0, #0xe2d820     | if (static_value_0373491B == true) goto label_0;
            // 0x00E2D808: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00E2D80C: LDR x8, [x8, #0xb78]       | X8 = 0x2B8F204;                         
            // 0x00E2D810: LDR w0, [x8]               | W0 = 0x1343;                            
            // 0x00E2D814: BL #0x2782188              | X0 = sub_2782188( ?? 0x1343, ????);     
            // 0x00E2D818: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D81C: STRB w8, [x20, #0x91b]     | static_value_0373491B = true;            //  dest_result_addr=57887003
            label_0:
            // 0x00E2D820: LDR x0, [x19, #0x118]      | X0 = this.OnPostRenderAction; //P2      
            // 0x00E2D824: CBZ x0, #0xe2d844          | if (this.OnPostRenderAction == null) goto label_1;
            if(this.OnPostRenderAction == null)
            {
                goto label_1;
            }
            // 0x00E2D828: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D82C: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D830: MOV x1, x19                | X1 = 1152921512979834448 (0x10000001F311A650);//ML01
            // 0x00E2D834: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D838: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D83C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D840: B #0x129b8e0               | this.OnPostRenderAction.Invoke(obj:  this); return;
            this.OnPostRenderAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D844: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D848: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D84C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D850 (14866512), len: 100  VirtAddr: 0x00E2D850 RVA: 0x00E2D850 token: 100680883 methodIndex: 57281 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnPreCull()
        {
            //
            // Disasemble & Code
            // 0x00E2D850: STP x20, x19, [sp, #-0x20]! | stack[1152921512979942608] = ???;  stack[1152921512979942616] = ???;  //  dest_result_addr=1152921512979942608 |  dest_result_addr=1152921512979942616
            // 0x00E2D854: STP x29, x30, [sp, #0x10]  | stack[1152921512979942624] = ???;  stack[1152921512979942632] = ???;  //  dest_result_addr=1152921512979942624 |  dest_result_addr=1152921512979942632
            // 0x00E2D858: ADD x29, sp, #0x10         | X29 = (1152921512979942608 + 16) = 1152921512979942624 (0x10000001F3134CE0);
            // 0x00E2D85C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D860: LDRB w8, [x20, #0x91c]     | W8 = (bool)static_value_0373491C;       
            // 0x00E2D864: MOV x19, x0                | X19 = 1152921512979954640 (0x10000001F3137BD0);//ML01
            // 0x00E2D868: TBNZ w8, #0, #0xe2d884     | if (static_value_0373491C == true) goto label_0;
            // 0x00E2D86C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00E2D870: LDR x8, [x8, #0xc88]       | X8 = 0x2B8F208;                         
            // 0x00E2D874: LDR w0, [x8]               | W0 = 0x1344;                            
            // 0x00E2D878: BL #0x2782188              | X0 = sub_2782188( ?? 0x1344, ????);     
            // 0x00E2D87C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D880: STRB w8, [x20, #0x91c]     | static_value_0373491C = true;            //  dest_result_addr=57887004
            label_0:
            // 0x00E2D884: LDR x0, [x19, #0x120]      | X0 = this.OnPreCullAction; //P2         
            // 0x00E2D888: CBZ x0, #0xe2d8a8          | if (this.OnPreCullAction == null) goto label_1;
            if(this.OnPreCullAction == null)
            {
                goto label_1;
            }
            // 0x00E2D88C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D890: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D894: MOV x1, x19                | X1 = 1152921512979954640 (0x10000001F3137BD0);//ML01
            // 0x00E2D898: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D89C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D8A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D8A4: B #0x129b8e0               | this.OnPreCullAction.Invoke(obj:  this); return;
            this.OnPreCullAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D8A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D8AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D8B0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D8B4 (14866612), len: 100  VirtAddr: 0x00E2D8B4 RVA: 0x00E2D8B4 token: 100680884 methodIndex: 57282 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnPreRender()
        {
            //
            // Disasemble & Code
            // 0x00E2D8B4: STP x20, x19, [sp, #-0x20]! | stack[1152921512980062800] = ???;  stack[1152921512980062808] = ???;  //  dest_result_addr=1152921512980062800 |  dest_result_addr=1152921512980062808
            // 0x00E2D8B8: STP x29, x30, [sp, #0x10]  | stack[1152921512980062816] = ???;  stack[1152921512980062824] = ???;  //  dest_result_addr=1152921512980062816 |  dest_result_addr=1152921512980062824
            // 0x00E2D8BC: ADD x29, sp, #0x10         | X29 = (1152921512980062800 + 16) = 1152921512980062816 (0x10000001F3152260);
            // 0x00E2D8C0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D8C4: LDRB w8, [x20, #0x91d]     | W8 = (bool)static_value_0373491D;       
            // 0x00E2D8C8: MOV x19, x0                | X19 = 1152921512980074832 (0x10000001F3155150);//ML01
            // 0x00E2D8CC: TBNZ w8, #0, #0xe2d8e8     | if (static_value_0373491D == true) goto label_0;
            // 0x00E2D8D0: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00E2D8D4: LDR x8, [x8, #0x3a8]       | X8 = 0x2B8F20C;                         
            // 0x00E2D8D8: LDR w0, [x8]               | W0 = 0x1345;                            
            // 0x00E2D8DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1345, ????);     
            // 0x00E2D8E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D8E4: STRB w8, [x20, #0x91d]     | static_value_0373491D = true;            //  dest_result_addr=57887005
            label_0:
            // 0x00E2D8E8: LDR x0, [x19, #0x128]      | X0 = this.OnPreRenderAction; //P2       
            // 0x00E2D8EC: CBZ x0, #0xe2d90c          | if (this.OnPreRenderAction == null) goto label_1;
            if(this.OnPreRenderAction == null)
            {
                goto label_1;
            }
            // 0x00E2D8F0: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D8F4: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D8F8: MOV x1, x19                | X1 = 1152921512980074832 (0x10000001F3155150);//ML01
            // 0x00E2D8FC: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D900: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D904: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D908: B #0x129b8e0               | this.OnPreRenderAction.Invoke(obj:  this); return;
            this.OnPreRenderAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D90C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D910: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D914: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D918 (14866712), len: 100  VirtAddr: 0x00E2D918 RVA: 0x00E2D918 token: 100680885 methodIndex: 57283 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnRectTransformDimensionsChange()
        {
            //
            // Disasemble & Code
            // 0x00E2D918: STP x20, x19, [sp, #-0x20]! | stack[1152921512980182992] = ???;  stack[1152921512980183000] = ???;  //  dest_result_addr=1152921512980182992 |  dest_result_addr=1152921512980183000
            // 0x00E2D91C: STP x29, x30, [sp, #0x10]  | stack[1152921512980183008] = ???;  stack[1152921512980183016] = ???;  //  dest_result_addr=1152921512980183008 |  dest_result_addr=1152921512980183016
            // 0x00E2D920: ADD x29, sp, #0x10         | X29 = (1152921512980182992 + 16) = 1152921512980183008 (0x10000001F316F7E0);
            // 0x00E2D924: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D928: LDRB w8, [x20, #0x91e]     | W8 = (bool)static_value_0373491E;       
            // 0x00E2D92C: MOV x19, x0                | X19 = 1152921512980195024 (0x10000001F31726D0);//ML01
            // 0x00E2D930: TBNZ w8, #0, #0xe2d94c     | if (static_value_0373491E == true) goto label_0;
            // 0x00E2D934: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00E2D938: LDR x8, [x8, #0x500]       | X8 = 0x2B8F210;                         
            // 0x00E2D93C: LDR w0, [x8]               | W0 = 0x1346;                            
            // 0x00E2D940: BL #0x2782188              | X0 = sub_2782188( ?? 0x1346, ????);     
            // 0x00E2D944: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D948: STRB w8, [x20, #0x91e]     | static_value_0373491E = true;            //  dest_result_addr=57887006
            label_0:
            // 0x00E2D94C: LDR x0, [x19, #0x130]      | X0 = this.OnRectTransformDimensionsChangeAction; //P2 
            // 0x00E2D950: CBZ x0, #0xe2d970          | if (this.OnRectTransformDimensionsChangeAction == null) goto label_1;
            if(this.OnRectTransformDimensionsChangeAction == null)
            {
                goto label_1;
            }
            // 0x00E2D954: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D958: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D95C: MOV x1, x19                | X1 = 1152921512980195024 (0x10000001F31726D0);//ML01
            // 0x00E2D960: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D964: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D968: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D96C: B #0x129b8e0               | this.OnRectTransformDimensionsChangeAction.Invoke(obj:  this); return;
            this.OnRectTransformDimensionsChangeAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D970: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D974: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D978: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D97C (14866812), len: 100  VirtAddr: 0x00E2D97C RVA: 0x00E2D97C token: 100680886 methodIndex: 57284 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnRectTransformRemoved()
        {
            //
            // Disasemble & Code
            // 0x00E2D97C: STP x20, x19, [sp, #-0x20]! | stack[1152921512980303184] = ???;  stack[1152921512980303192] = ???;  //  dest_result_addr=1152921512980303184 |  dest_result_addr=1152921512980303192
            // 0x00E2D980: STP x29, x30, [sp, #0x10]  | stack[1152921512980303200] = ???;  stack[1152921512980303208] = ???;  //  dest_result_addr=1152921512980303200 |  dest_result_addr=1152921512980303208
            // 0x00E2D984: ADD x29, sp, #0x10         | X29 = (1152921512980303184 + 16) = 1152921512980303200 (0x10000001F318CD60);
            // 0x00E2D988: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2D98C: LDRB w8, [x20, #0x91f]     | W8 = (bool)static_value_0373491F;       
            // 0x00E2D990: MOV x19, x0                | X19 = 1152921512980315216 (0x10000001F318FC50);//ML01
            // 0x00E2D994: TBNZ w8, #0, #0xe2d9b0     | if (static_value_0373491F == true) goto label_0;
            // 0x00E2D998: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00E2D99C: LDR x8, [x8, #0xe60]       | X8 = 0x2B8F214;                         
            // 0x00E2D9A0: LDR w0, [x8]               | W0 = 0x1347;                            
            // 0x00E2D9A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1347, ????);     
            // 0x00E2D9A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2D9AC: STRB w8, [x20, #0x91f]     | static_value_0373491F = true;            //  dest_result_addr=57887007
            label_0:
            // 0x00E2D9B0: LDR x0, [x19, #0x138]      | X0 = this.OnRectTransformRemovedAction; //P2 
            // 0x00E2D9B4: CBZ x0, #0xe2d9d4          | if (this.OnRectTransformRemovedAction == null) goto label_1;
            if(this.OnRectTransformRemovedAction == null)
            {
                goto label_1;
            }
            // 0x00E2D9B8: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2D9BC: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2D9C0: MOV x1, x19                | X1 = 1152921512980315216 (0x10000001F318FC50);//ML01
            // 0x00E2D9C4: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2D9C8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D9CC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D9D0: B #0x129b8e0               | this.OnRectTransformRemovedAction.Invoke(obj:  this); return;
            this.OnRectTransformRemovedAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2D9D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2D9D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2D9DC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2D9E0 (14866912), len: 128  VirtAddr: 0x00E2D9E0 RVA: 0x00E2D9E0 token: 100680887 methodIndex: 57285 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
        {
            //
            // Disasemble & Code
            // 0x00E2D9E0: STP x22, x21, [sp, #-0x30]! | stack[1152921512980432576] = ???;  stack[1152921512980432584] = ???;  //  dest_result_addr=1152921512980432576 |  dest_result_addr=1152921512980432584
            // 0x00E2D9E4: STP x20, x19, [sp, #0x10]  | stack[1152921512980432592] = ???;  stack[1152921512980432600] = ???;  //  dest_result_addr=1152921512980432592 |  dest_result_addr=1152921512980432600
            // 0x00E2D9E8: STP x29, x30, [sp, #0x20]  | stack[1152921512980432608] = ???;  stack[1152921512980432616] = ???;  //  dest_result_addr=1152921512980432608 |  dest_result_addr=1152921512980432616
            // 0x00E2D9EC: ADD x29, sp, #0x20         | X29 = (1152921512980432576 + 32) = 1152921512980432608 (0x10000001F31AC6E0);
            // 0x00E2D9F0: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E2D9F4: LDRB w8, [x22, #0x920]     | W8 = (bool)static_value_03734920;       
            // 0x00E2D9F8: MOV x19, x2                | X19 = destination;//m1                  
            // 0x00E2D9FC: MOV x20, x1                | X20 = source;//m1                       
            // 0x00E2DA00: MOV x21, x0                | X21 = 1152921512980444624 (0x10000001F31AF5D0);//ML01
            // 0x00E2DA04: TBNZ w8, #0, #0xe2da20     | if (static_value_03734920 == true) goto label_0;
            // 0x00E2DA08: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00E2DA0C: LDR x8, [x8, #0x448]       | X8 = 0x2B8F218;                         
            // 0x00E2DA10: LDR w0, [x8]               | W0 = 0x1348;                            
            // 0x00E2DA14: BL #0x2782188              | X0 = sub_2782188( ?? 0x1348, ????);     
            // 0x00E2DA18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DA1C: STRB w8, [x22, #0x920]     | static_value_03734920 = true;            //  dest_result_addr=57887008
            label_0:
            // 0x00E2DA20: LDR x0, [x21, #0x140]      | X0 = this.OnRenderImageAction; //P2     
            // 0x00E2DA24: CBZ x0, #0xe2da50          | if (this.OnRenderImageAction == null) goto label_1;
            if(this.OnRenderImageAction == null)
            {
                goto label_1;
            }
            // 0x00E2DA28: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00E2DA2C: LDR x8, [x8, #0xaf0]       | X8 = 1152921512980419600;               
            // 0x00E2DA30: MOV x2, x20                | X2 = source;//m1                        
            // 0x00E2DA34: MOV x3, x19                | X3 = destination;//m1                   
            // 0x00E2DA38: MOV x1, x21                | X1 = 1152921512980444624 (0x10000001F31AF5D0);//ML01
            // 0x00E2DA3C: LDR x4, [x8]               | X4 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.RenderTexture, UnityEngine.RenderTexture>::Invoke(wxb.BehaviourAction arg1, UnityEngine.RenderTexture arg2, UnityEngine.RenderTexture arg3);
            // 0x00E2DA40: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DA44: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DA48: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DA4C: B #0x12a5dbc               | this.OnRenderImageAction.Invoke(arg1:  this, arg2:  source, arg3:  destination); return;
            this.OnRenderImageAction.Invoke(arg1:  this, arg2:  source, arg3:  destination);
            return;
            label_1:
            // 0x00E2DA50: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DA54: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DA58: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DA5C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DA60 (14867040), len: 100  VirtAddr: 0x00E2DA60 RVA: 0x00E2DA60 token: 100680888 methodIndex: 57286 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnRenderObject()
        {
            //
            // Disasemble & Code
            // 0x00E2DA60: STP x20, x19, [sp, #-0x20]! | stack[1152921512980560976] = ???;  stack[1152921512980560984] = ???;  //  dest_result_addr=1152921512980560976 |  dest_result_addr=1152921512980560984
            // 0x00E2DA64: STP x29, x30, [sp, #0x10]  | stack[1152921512980560992] = ???;  stack[1152921512980561000] = ???;  //  dest_result_addr=1152921512980560992 |  dest_result_addr=1152921512980561000
            // 0x00E2DA68: ADD x29, sp, #0x10         | X29 = (1152921512980560976 + 16) = 1152921512980560992 (0x10000001F31CBC60);
            // 0x00E2DA6C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DA70: LDRB w8, [x20, #0x921]     | W8 = (bool)static_value_03734921;       
            // 0x00E2DA74: MOV x19, x0                | X19 = 1152921512980573008 (0x10000001F31CEB50);//ML01
            // 0x00E2DA78: TBNZ w8, #0, #0xe2da94     | if (static_value_03734921 == true) goto label_0;
            // 0x00E2DA7C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00E2DA80: LDR x8, [x8, #0xac8]       | X8 = 0x2B8F21C;                         
            // 0x00E2DA84: LDR w0, [x8]               | W0 = 0x1349;                            
            // 0x00E2DA88: BL #0x2782188              | X0 = sub_2782188( ?? 0x1349, ????);     
            // 0x00E2DA8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DA90: STRB w8, [x20, #0x921]     | static_value_03734921 = true;            //  dest_result_addr=57887009
            label_0:
            // 0x00E2DA94: LDR x0, [x19, #0x148]      | X0 = this.OnRenderObjectAction; //P2    
            // 0x00E2DA98: CBZ x0, #0xe2dab8          | if (this.OnRenderObjectAction == null) goto label_1;
            if(this.OnRenderObjectAction == null)
            {
                goto label_1;
            }
            // 0x00E2DA9C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DAA0: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DAA4: MOV x1, x19                | X1 = 1152921512980573008 (0x10000001F31CEB50);//ML01
            // 0x00E2DAA8: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DAAC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DAB0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DAB4: B #0x129b8e0               | this.OnRenderObjectAction.Invoke(obj:  this); return;
            this.OnRenderObjectAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DAB8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DABC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DAC0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DAC4 (14867140), len: 100  VirtAddr: 0x00E2DAC4 RVA: 0x00E2DAC4 token: 100680889 methodIndex: 57287 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTransformChildrenChanged()
        {
            //
            // Disasemble & Code
            // 0x00E2DAC4: STP x20, x19, [sp, #-0x20]! | stack[1152921512980681168] = ???;  stack[1152921512980681176] = ???;  //  dest_result_addr=1152921512980681168 |  dest_result_addr=1152921512980681176
            // 0x00E2DAC8: STP x29, x30, [sp, #0x10]  | stack[1152921512980681184] = ???;  stack[1152921512980681192] = ???;  //  dest_result_addr=1152921512980681184 |  dest_result_addr=1152921512980681192
            // 0x00E2DACC: ADD x29, sp, #0x10         | X29 = (1152921512980681168 + 16) = 1152921512980681184 (0x10000001F31E91E0);
            // 0x00E2DAD0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DAD4: LDRB w8, [x20, #0x922]     | W8 = (bool)static_value_03734922;       
            // 0x00E2DAD8: MOV x19, x0                | X19 = 1152921512980693200 (0x10000001F31EC0D0);//ML01
            // 0x00E2DADC: TBNZ w8, #0, #0xe2daf8     | if (static_value_03734922 == true) goto label_0;
            // 0x00E2DAE0: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00E2DAE4: LDR x8, [x8, #0x798]       | X8 = 0x2B8F220;                         
            // 0x00E2DAE8: LDR w0, [x8]               | W0 = 0x134A;                            
            // 0x00E2DAEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x134A, ????);     
            // 0x00E2DAF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DAF4: STRB w8, [x20, #0x922]     | static_value_03734922 = true;            //  dest_result_addr=57887010
            label_0:
            // 0x00E2DAF8: LDR x0, [x19, #0x150]      | X0 = this.OnTransformChildrenChangedAction; //P2 
            // 0x00E2DAFC: CBZ x0, #0xe2db1c          | if (this.OnTransformChildrenChangedAction == null) goto label_1;
            if(this.OnTransformChildrenChangedAction == null)
            {
                goto label_1;
            }
            // 0x00E2DB00: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DB04: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DB08: MOV x1, x19                | X1 = 1152921512980693200 (0x10000001F31EC0D0);//ML01
            // 0x00E2DB0C: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DB10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DB14: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DB18: B #0x129b8e0               | this.OnTransformChildrenChangedAction.Invoke(obj:  this); return;
            this.OnTransformChildrenChangedAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DB1C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DB20: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DB24: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DB28 (14867240), len: 100  VirtAddr: 0x00E2DB28 RVA: 0x00E2DB28 token: 100680890 methodIndex: 57288 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTransformParentChanged()
        {
            //
            // Disasemble & Code
            // 0x00E2DB28: STP x20, x19, [sp, #-0x20]! | stack[1152921512980801360] = ???;  stack[1152921512980801368] = ???;  //  dest_result_addr=1152921512980801360 |  dest_result_addr=1152921512980801368
            // 0x00E2DB2C: STP x29, x30, [sp, #0x10]  | stack[1152921512980801376] = ???;  stack[1152921512980801384] = ???;  //  dest_result_addr=1152921512980801376 |  dest_result_addr=1152921512980801384
            // 0x00E2DB30: ADD x29, sp, #0x10         | X29 = (1152921512980801360 + 16) = 1152921512980801376 (0x10000001F3206760);
            // 0x00E2DB34: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DB38: LDRB w8, [x20, #0x923]     | W8 = (bool)static_value_03734923;       
            // 0x00E2DB3C: MOV x19, x0                | X19 = 1152921512980813392 (0x10000001F3209650);//ML01
            // 0x00E2DB40: TBNZ w8, #0, #0xe2db5c     | if (static_value_03734923 == true) goto label_0;
            // 0x00E2DB44: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x00E2DB48: LDR x8, [x8, #0x428]       | X8 = 0x2B8F224;                         
            // 0x00E2DB4C: LDR w0, [x8]               | W0 = 0x134B;                            
            // 0x00E2DB50: BL #0x2782188              | X0 = sub_2782188( ?? 0x134B, ????);     
            // 0x00E2DB54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DB58: STRB w8, [x20, #0x923]     | static_value_03734923 = true;            //  dest_result_addr=57887011
            label_0:
            // 0x00E2DB5C: LDR x0, [x19, #0x158]      | X0 = this.OnTransformParentChangedAction; //P2 
            // 0x00E2DB60: CBZ x0, #0xe2db80          | if (this.OnTransformParentChangedAction == null) goto label_1;
            if(this.OnTransformParentChangedAction == null)
            {
                goto label_1;
            }
            // 0x00E2DB64: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DB68: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DB6C: MOV x1, x19                | X1 = 1152921512980813392 (0x10000001F3209650);//ML01
            // 0x00E2DB70: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DB74: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DB78: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DB7C: B #0x129b8e0               | this.OnTransformParentChangedAction.Invoke(obj:  this); return;
            this.OnTransformParentChangedAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DB80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DB84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DB88: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DB8C (14867340), len: 120  VirtAddr: 0x00E2DB8C RVA: 0x00E2DB8C token: 100680891 methodIndex: 57289 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTriggerEnter(UnityEngine.Collider other)
        {
            //
            // Disasemble & Code
            // 0x00E2DB8C: STP x22, x21, [sp, #-0x30]! | stack[1152921512980926656] = ???;  stack[1152921512980926664] = ???;  //  dest_result_addr=1152921512980926656 |  dest_result_addr=1152921512980926664
            // 0x00E2DB90: STP x20, x19, [sp, #0x10]  | stack[1152921512980926672] = ???;  stack[1152921512980926680] = ???;  //  dest_result_addr=1152921512980926672 |  dest_result_addr=1152921512980926680
            // 0x00E2DB94: STP x29, x30, [sp, #0x20]  | stack[1152921512980926688] = ???;  stack[1152921512980926696] = ???;  //  dest_result_addr=1152921512980926688 |  dest_result_addr=1152921512980926696
            // 0x00E2DB98: ADD x29, sp, #0x20         | X29 = (1152921512980926656 + 32) = 1152921512980926688 (0x10000001F32250E0);
            // 0x00E2DB9C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2DBA0: LDRB w8, [x21, #0x924]     | W8 = (bool)static_value_03734924;       
            // 0x00E2DBA4: MOV x19, x1                | X19 = other;//m1                        
            // 0x00E2DBA8: MOV x20, x0                | X20 = 1152921512980938704 (0x10000001F3227FD0);//ML01
            // 0x00E2DBAC: TBNZ w8, #0, #0xe2dbc8     | if (static_value_03734924 == true) goto label_0;
            // 0x00E2DBB0: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E2DBB4: LDR x8, [x8, #0xf78]       | X8 = 0x2B8F228;                         
            // 0x00E2DBB8: LDR w0, [x8]               | W0 = 0x134C;                            
            // 0x00E2DBBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x134C, ????);     
            // 0x00E2DBC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DBC4: STRB w8, [x21, #0x924]     | static_value_03734924 = true;            //  dest_result_addr=57887012
            label_0:
            // 0x00E2DBC8: LDR x0, [x20, #0x160]      | X0 = this.OnTriggerEnterAction; //P2    
            // 0x00E2DBCC: CBZ x0, #0xe2dbf4          | if (this.OnTriggerEnterAction == null) goto label_1;
            if(this.OnTriggerEnterAction == null)
            {
                goto label_1;
            }
            // 0x00E2DBD0: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00E2DBD4: LDR x8, [x8, #0xb0]        | X8 = 1152921512980913680;               
            // 0x00E2DBD8: MOV x1, x20                | X1 = 1152921512980938704 (0x10000001F3227FD0);//ML01
            // 0x00E2DBDC: MOV x2, x19                | X2 = other;//m1                         
            // 0x00E2DBE0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collider>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collider arg2);
            // 0x00E2DBE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DBE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DBEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DBF0: B #0x12a30fc               | this.OnTriggerEnterAction.Invoke(arg1:  this, arg2:  other); return;
            this.OnTriggerEnterAction.Invoke(arg1:  this, arg2:  other);
            return;
            label_1:
            // 0x00E2DBF4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DBF8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DBFC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DC00: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DC04 (14867460), len: 120  VirtAddr: 0x00E2DC04 RVA: 0x00E2DC04 token: 100680892 methodIndex: 57290 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTriggerEnter2D(UnityEngine.Collider2D collision)
        {
            //
            // Disasemble & Code
            // 0x00E2DC04: STP x22, x21, [sp, #-0x30]! | stack[1152921512981056064] = ???;  stack[1152921512981056072] = ???;  //  dest_result_addr=1152921512981056064 |  dest_result_addr=1152921512981056072
            // 0x00E2DC08: STP x20, x19, [sp, #0x10]  | stack[1152921512981056080] = ???;  stack[1152921512981056088] = ???;  //  dest_result_addr=1152921512981056080 |  dest_result_addr=1152921512981056088
            // 0x00E2DC0C: STP x29, x30, [sp, #0x20]  | stack[1152921512981056096] = ???;  stack[1152921512981056104] = ???;  //  dest_result_addr=1152921512981056096 |  dest_result_addr=1152921512981056104
            // 0x00E2DC10: ADD x29, sp, #0x20         | X29 = (1152921512981056064 + 32) = 1152921512981056096 (0x10000001F3244A60);
            // 0x00E2DC14: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2DC18: LDRB w8, [x21, #0x925]     | W8 = (bool)static_value_03734925;       
            // 0x00E2DC1C: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2DC20: MOV x20, x0                | X20 = 1152921512981068112 (0x10000001F3247950);//ML01
            // 0x00E2DC24: TBNZ w8, #0, #0xe2dc40     | if (static_value_03734925 == true) goto label_0;
            // 0x00E2DC28: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00E2DC2C: LDR x8, [x8, #0x640]       | X8 = 0x2B8F22C;                         
            // 0x00E2DC30: LDR w0, [x8]               | W0 = 0x134D;                            
            // 0x00E2DC34: BL #0x2782188              | X0 = sub_2782188( ?? 0x134D, ????);     
            // 0x00E2DC38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DC3C: STRB w8, [x21, #0x925]     | static_value_03734925 = true;            //  dest_result_addr=57887013
            label_0:
            // 0x00E2DC40: LDR x0, [x20, #0x168]      | X0 = this.OnTriggerEnter2DAction; //P2  
            // 0x00E2DC44: CBZ x0, #0xe2dc6c          | if (this.OnTriggerEnter2DAction == null) goto label_1;
            if(this.OnTriggerEnter2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2DC48: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00E2DC4C: LDR x8, [x8, #0x890]       | X8 = 1152921512981043088;               
            // 0x00E2DC50: MOV x1, x20                | X1 = 1152921512981068112 (0x10000001F3247950);//ML01
            // 0x00E2DC54: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2DC58: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collider2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collider2D arg2);
            // 0x00E2DC5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DC60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DC64: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DC68: B #0x12a30fc               | this.OnTriggerEnter2DAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnTriggerEnter2DAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2DC6C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DC70: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DC74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DC78: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DC7C (14867580), len: 120  VirtAddr: 0x00E2DC7C RVA: 0x00E2DC7C token: 100680893 methodIndex: 57291 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTriggerExit(UnityEngine.Collider other)
        {
            //
            // Disasemble & Code
            // 0x00E2DC7C: STP x22, x21, [sp, #-0x30]! | stack[1152921512981184448] = ???;  stack[1152921512981184456] = ???;  //  dest_result_addr=1152921512981184448 |  dest_result_addr=1152921512981184456
            // 0x00E2DC80: STP x20, x19, [sp, #0x10]  | stack[1152921512981184464] = ???;  stack[1152921512981184472] = ???;  //  dest_result_addr=1152921512981184464 |  dest_result_addr=1152921512981184472
            // 0x00E2DC84: STP x29, x30, [sp, #0x20]  | stack[1152921512981184480] = ???;  stack[1152921512981184488] = ???;  //  dest_result_addr=1152921512981184480 |  dest_result_addr=1152921512981184488
            // 0x00E2DC88: ADD x29, sp, #0x20         | X29 = (1152921512981184448 + 32) = 1152921512981184480 (0x10000001F3263FE0);
            // 0x00E2DC8C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2DC90: LDRB w8, [x21, #0x926]     | W8 = (bool)static_value_03734926;       
            // 0x00E2DC94: MOV x19, x1                | X19 = other;//m1                        
            // 0x00E2DC98: MOV x20, x0                | X20 = 1152921512981196496 (0x10000001F3266ED0);//ML01
            // 0x00E2DC9C: TBNZ w8, #0, #0xe2dcb8     | if (static_value_03734926 == true) goto label_0;
            // 0x00E2DCA0: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x00E2DCA4: LDR x8, [x8, #0x1e0]       | X8 = 0x2B8F230;                         
            // 0x00E2DCA8: LDR w0, [x8]               | W0 = 0x134E;                            
            // 0x00E2DCAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x134E, ????);     
            // 0x00E2DCB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DCB4: STRB w8, [x21, #0x926]     | static_value_03734926 = true;            //  dest_result_addr=57887014
            label_0:
            // 0x00E2DCB8: LDR x0, [x20, #0x170]      | X0 = this.OnTriggerExitAction; //P2     
            // 0x00E2DCBC: CBZ x0, #0xe2dce4          | if (this.OnTriggerExitAction == null) goto label_1;
            if(this.OnTriggerExitAction == null)
            {
                goto label_1;
            }
            // 0x00E2DCC0: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00E2DCC4: LDR x8, [x8, #0xb0]        | X8 = 1152921512980913680;               
            // 0x00E2DCC8: MOV x1, x20                | X1 = 1152921512981196496 (0x10000001F3266ED0);//ML01
            // 0x00E2DCCC: MOV x2, x19                | X2 = other;//m1                         
            // 0x00E2DCD0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collider>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collider arg2);
            // 0x00E2DCD4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DCD8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DCDC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DCE0: B #0x12a30fc               | this.OnTriggerExitAction.Invoke(arg1:  this, arg2:  other); return;
            this.OnTriggerExitAction.Invoke(arg1:  this, arg2:  other);
            return;
            label_1:
            // 0x00E2DCE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DCE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DCEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DCF0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DCF4 (14867700), len: 120  VirtAddr: 0x00E2DCF4 RVA: 0x00E2DCF4 token: 100680894 methodIndex: 57292 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTriggerExit2D(UnityEngine.Collider2D collision)
        {
            //
            // Disasemble & Code
            // 0x00E2DCF4: STP x22, x21, [sp, #-0x30]! | stack[1152921512981312832] = ???;  stack[1152921512981312840] = ???;  //  dest_result_addr=1152921512981312832 |  dest_result_addr=1152921512981312840
            // 0x00E2DCF8: STP x20, x19, [sp, #0x10]  | stack[1152921512981312848] = ???;  stack[1152921512981312856] = ???;  //  dest_result_addr=1152921512981312848 |  dest_result_addr=1152921512981312856
            // 0x00E2DCFC: STP x29, x30, [sp, #0x20]  | stack[1152921512981312864] = ???;  stack[1152921512981312872] = ???;  //  dest_result_addr=1152921512981312864 |  dest_result_addr=1152921512981312872
            // 0x00E2DD00: ADD x29, sp, #0x20         | X29 = (1152921512981312832 + 32) = 1152921512981312864 (0x10000001F3283560);
            // 0x00E2DD04: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2DD08: LDRB w8, [x21, #0x927]     | W8 = (bool)static_value_03734927;       
            // 0x00E2DD0C: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2DD10: MOV x20, x0                | X20 = 1152921512981324880 (0x10000001F3286450);//ML01
            // 0x00E2DD14: TBNZ w8, #0, #0xe2dd30     | if (static_value_03734927 == true) goto label_0;
            // 0x00E2DD18: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00E2DD1C: LDR x8, [x8, #0x1c8]       | X8 = 0x2B8F234;                         
            // 0x00E2DD20: LDR w0, [x8]               | W0 = 0x134F;                            
            // 0x00E2DD24: BL #0x2782188              | X0 = sub_2782188( ?? 0x134F, ????);     
            // 0x00E2DD28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DD2C: STRB w8, [x21, #0x927]     | static_value_03734927 = true;            //  dest_result_addr=57887015
            label_0:
            // 0x00E2DD30: LDR x0, [x20, #0x178]      | X0 = this.OnTriggerExit2DAction; //P2   
            // 0x00E2DD34: CBZ x0, #0xe2dd5c          | if (this.OnTriggerExit2DAction == null) goto label_1;
            if(this.OnTriggerExit2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2DD38: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00E2DD3C: LDR x8, [x8, #0x890]       | X8 = 1152921512981043088;               
            // 0x00E2DD40: MOV x1, x20                | X1 = 1152921512981324880 (0x10000001F3286450);//ML01
            // 0x00E2DD44: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2DD48: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collider2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collider2D arg2);
            // 0x00E2DD4C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DD50: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DD54: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DD58: B #0x12a30fc               | this.OnTriggerExit2DAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnTriggerExit2DAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2DD5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DD60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DD64: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DD68: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DD6C (14867820), len: 120  VirtAddr: 0x00E2DD6C RVA: 0x00E2DD6C token: 100680895 methodIndex: 57293 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTriggerStay(UnityEngine.Collider other)
        {
            //
            // Disasemble & Code
            // 0x00E2DD6C: STP x22, x21, [sp, #-0x30]! | stack[1152921512981441216] = ???;  stack[1152921512981441224] = ???;  //  dest_result_addr=1152921512981441216 |  dest_result_addr=1152921512981441224
            // 0x00E2DD70: STP x20, x19, [sp, #0x10]  | stack[1152921512981441232] = ???;  stack[1152921512981441240] = ???;  //  dest_result_addr=1152921512981441232 |  dest_result_addr=1152921512981441240
            // 0x00E2DD74: STP x29, x30, [sp, #0x20]  | stack[1152921512981441248] = ???;  stack[1152921512981441256] = ???;  //  dest_result_addr=1152921512981441248 |  dest_result_addr=1152921512981441256
            // 0x00E2DD78: ADD x29, sp, #0x20         | X29 = (1152921512981441216 + 32) = 1152921512981441248 (0x10000001F32A2AE0);
            // 0x00E2DD7C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2DD80: LDRB w8, [x21, #0x928]     | W8 = (bool)static_value_03734928;       
            // 0x00E2DD84: MOV x19, x1                | X19 = other;//m1                        
            // 0x00E2DD88: MOV x20, x0                | X20 = 1152921512981453264 (0x10000001F32A59D0);//ML01
            // 0x00E2DD8C: TBNZ w8, #0, #0xe2dda8     | if (static_value_03734928 == true) goto label_0;
            // 0x00E2DD90: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00E2DD94: LDR x8, [x8, #0xdb0]       | X8 = 0x2B8F238;                         
            // 0x00E2DD98: LDR w0, [x8]               | W0 = 0x1350;                            
            // 0x00E2DD9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1350, ????);     
            // 0x00E2DDA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DDA4: STRB w8, [x21, #0x928]     | static_value_03734928 = true;            //  dest_result_addr=57887016
            label_0:
            // 0x00E2DDA8: LDR x0, [x20, #0x180]      | X0 = this.OnTriggerStayAction; //P2     
            // 0x00E2DDAC: CBZ x0, #0xe2ddd4          | if (this.OnTriggerStayAction == null) goto label_1;
            if(this.OnTriggerStayAction == null)
            {
                goto label_1;
            }
            // 0x00E2DDB0: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00E2DDB4: LDR x8, [x8, #0xb0]        | X8 = 1152921512980913680;               
            // 0x00E2DDB8: MOV x1, x20                | X1 = 1152921512981453264 (0x10000001F32A59D0);//ML01
            // 0x00E2DDBC: MOV x2, x19                | X2 = other;//m1                         
            // 0x00E2DDC0: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collider>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collider arg2);
            // 0x00E2DDC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DDC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DDCC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DDD0: B #0x12a30fc               | this.OnTriggerStayAction.Invoke(arg1:  this, arg2:  other); return;
            this.OnTriggerStayAction.Invoke(arg1:  this, arg2:  other);
            return;
            label_1:
            // 0x00E2DDD4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DDD8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DDDC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DDE0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DDE4 (14867940), len: 120  VirtAddr: 0x00E2DDE4 RVA: 0x00E2DDE4 token: 100680896 methodIndex: 57294 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnTriggerStay2D(UnityEngine.Collider2D collision)
        {
            //
            // Disasemble & Code
            // 0x00E2DDE4: STP x22, x21, [sp, #-0x30]! | stack[1152921512981569600] = ???;  stack[1152921512981569608] = ???;  //  dest_result_addr=1152921512981569600 |  dest_result_addr=1152921512981569608
            // 0x00E2DDE8: STP x20, x19, [sp, #0x10]  | stack[1152921512981569616] = ???;  stack[1152921512981569624] = ???;  //  dest_result_addr=1152921512981569616 |  dest_result_addr=1152921512981569624
            // 0x00E2DDEC: STP x29, x30, [sp, #0x20]  | stack[1152921512981569632] = ???;  stack[1152921512981569640] = ???;  //  dest_result_addr=1152921512981569632 |  dest_result_addr=1152921512981569640
            // 0x00E2DDF0: ADD x29, sp, #0x20         | X29 = (1152921512981569600 + 32) = 1152921512981569632 (0x10000001F32C2060);
            // 0x00E2DDF4: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2DDF8: LDRB w8, [x21, #0x929]     | W8 = (bool)static_value_03734929;       
            // 0x00E2DDFC: MOV x19, x1                | X19 = collision;//m1                    
            // 0x00E2DE00: MOV x20, x0                | X20 = 1152921512981581648 (0x10000001F32C4F50);//ML01
            // 0x00E2DE04: TBNZ w8, #0, #0xe2de20     | if (static_value_03734929 == true) goto label_0;
            // 0x00E2DE08: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E2DE0C: LDR x8, [x8, #0x900]       | X8 = 0x2B8F23C;                         
            // 0x00E2DE10: LDR w0, [x8]               | W0 = 0x1351;                            
            // 0x00E2DE14: BL #0x2782188              | X0 = sub_2782188( ?? 0x1351, ????);     
            // 0x00E2DE18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DE1C: STRB w8, [x21, #0x929]     | static_value_03734929 = true;            //  dest_result_addr=57887017
            label_0:
            // 0x00E2DE20: LDR x0, [x20, #0x188]      | X0 = this.OnTriggerStay2DAction; //P2   
            // 0x00E2DE24: CBZ x0, #0xe2de4c          | if (this.OnTriggerStay2DAction == null) goto label_1;
            if(this.OnTriggerStay2DAction == null)
            {
                goto label_1;
            }
            // 0x00E2DE28: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00E2DE2C: LDR x8, [x8, #0x890]       | X8 = 1152921512981043088;               
            // 0x00E2DE30: MOV x1, x20                | X1 = 1152921512981581648 (0x10000001F32C4F50);//ML01
            // 0x00E2DE34: MOV x2, x19                | X2 = collision;//m1                     
            // 0x00E2DE38: LDR x3, [x8]               | X3 = public System.Void System.Action<wxb.BehaviourAction, UnityEngine.Collider2D>::Invoke(wxb.BehaviourAction arg1, UnityEngine.Collider2D arg2);
            // 0x00E2DE3C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DE40: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DE44: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DE48: B #0x12a30fc               | this.OnTriggerStay2DAction.Invoke(arg1:  this, arg2:  collision); return;
            this.OnTriggerStay2DAction.Invoke(arg1:  this, arg2:  collision);
            return;
            label_1:
            // 0x00E2DE4C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DE50: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DE54: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2DE58: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DE5C (14868060), len: 100  VirtAddr: 0x00E2DE5C RVA: 0x00E2DE5C token: 100680897 methodIndex: 57295 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnValidate()
        {
            //
            // Disasemble & Code
            // 0x00E2DE5C: STP x20, x19, [sp, #-0x20]! | stack[1152921512981693904] = ???;  stack[1152921512981693912] = ???;  //  dest_result_addr=1152921512981693904 |  dest_result_addr=1152921512981693912
            // 0x00E2DE60: STP x29, x30, [sp, #0x10]  | stack[1152921512981693920] = ???;  stack[1152921512981693928] = ???;  //  dest_result_addr=1152921512981693920 |  dest_result_addr=1152921512981693928
            // 0x00E2DE64: ADD x29, sp, #0x10         | X29 = (1152921512981693904 + 16) = 1152921512981693920 (0x10000001F32E05E0);
            // 0x00E2DE68: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DE6C: LDRB w8, [x20, #0x92a]     | W8 = (bool)static_value_0373492A;       
            // 0x00E2DE70: MOV x19, x0                | X19 = 1152921512981705936 (0x10000001F32E34D0);//ML01
            // 0x00E2DE74: TBNZ w8, #0, #0xe2de90     | if (static_value_0373492A == true) goto label_0;
            // 0x00E2DE78: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00E2DE7C: LDR x8, [x8, #0x28]        | X8 = 0x2B8F240;                         
            // 0x00E2DE80: LDR w0, [x8]               | W0 = 0x1352;                            
            // 0x00E2DE84: BL #0x2782188              | X0 = sub_2782188( ?? 0x1352, ????);     
            // 0x00E2DE88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DE8C: STRB w8, [x20, #0x92a]     | static_value_0373492A = true;            //  dest_result_addr=57887018
            label_0:
            // 0x00E2DE90: LDR x0, [x19, #0x190]      | X0 = this.OnValidateAction; //P2        
            // 0x00E2DE94: CBZ x0, #0xe2deb4          | if (this.OnValidateAction == null) goto label_1;
            if(this.OnValidateAction == null)
            {
                goto label_1;
            }
            // 0x00E2DE98: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DE9C: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DEA0: MOV x1, x19                | X1 = 1152921512981705936 (0x10000001F32E34D0);//ML01
            // 0x00E2DEA4: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DEA8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DEAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DEB0: B #0x129b8e0               | this.OnValidateAction.Invoke(obj:  this); return;
            this.OnValidateAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DEB4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DEB8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DEBC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DEC0 (14868160), len: 100  VirtAddr: 0x00E2DEC0 RVA: 0x00E2DEC0 token: 100680898 methodIndex: 57296 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnWillRenderObject()
        {
            //
            // Disasemble & Code
            // 0x00E2DEC0: STP x20, x19, [sp, #-0x20]! | stack[1152921512981814096] = ???;  stack[1152921512981814104] = ???;  //  dest_result_addr=1152921512981814096 |  dest_result_addr=1152921512981814104
            // 0x00E2DEC4: STP x29, x30, [sp, #0x10]  | stack[1152921512981814112] = ???;  stack[1152921512981814120] = ???;  //  dest_result_addr=1152921512981814112 |  dest_result_addr=1152921512981814120
            // 0x00E2DEC8: ADD x29, sp, #0x10         | X29 = (1152921512981814096 + 16) = 1152921512981814112 (0x10000001F32FDB60);
            // 0x00E2DECC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DED0: LDRB w8, [x20, #0x92b]     | W8 = (bool)static_value_0373492B;       
            // 0x00E2DED4: MOV x19, x0                | X19 = 1152921512981826128 (0x10000001F3300A50);//ML01
            // 0x00E2DED8: TBNZ w8, #0, #0xe2def4     | if (static_value_0373492B == true) goto label_0;
            // 0x00E2DEDC: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E2DEE0: LDR x8, [x8, #0x5c0]       | X8 = 0x2B8F244;                         
            // 0x00E2DEE4: LDR w0, [x8]               | W0 = 0x1353;                            
            // 0x00E2DEE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1353, ????);     
            // 0x00E2DEEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DEF0: STRB w8, [x20, #0x92b]     | static_value_0373492B = true;            //  dest_result_addr=57887019
            label_0:
            // 0x00E2DEF4: LDR x0, [x19, #0x198]      | X0 = this.OnWillRenderObjectAction; //P2 
            // 0x00E2DEF8: CBZ x0, #0xe2df18          | if (this.OnWillRenderObjectAction == null) goto label_1;
            if(this.OnWillRenderObjectAction == null)
            {
                goto label_1;
            }
            // 0x00E2DEFC: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DF00: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DF04: MOV x1, x19                | X1 = 1152921512981826128 (0x10000001F3300A50);//ML01
            // 0x00E2DF08: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DF0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DF10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DF14: B #0x129b8e0               | this.OnWillRenderObjectAction.Invoke(obj:  this); return;
            this.OnWillRenderObjectAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DF18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DF1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DF20: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DF24 (14868260), len: 100  VirtAddr: 0x00E2DF24 RVA: 0x00E2DF24 token: 100680899 methodIndex: 57297 delegateWrapperIndex: 0 methodInvoker: 0
        private void Start()
        {
            //
            // Disasemble & Code
            // 0x00E2DF24: STP x20, x19, [sp, #-0x20]! | stack[1152921512981934288] = ???;  stack[1152921512981934296] = ???;  //  dest_result_addr=1152921512981934288 |  dest_result_addr=1152921512981934296
            // 0x00E2DF28: STP x29, x30, [sp, #0x10]  | stack[1152921512981934304] = ???;  stack[1152921512981934312] = ???;  //  dest_result_addr=1152921512981934304 |  dest_result_addr=1152921512981934312
            // 0x00E2DF2C: ADD x29, sp, #0x10         | X29 = (1152921512981934288 + 16) = 1152921512981934304 (0x10000001F331B0E0);
            // 0x00E2DF30: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DF34: LDRB w8, [x20, #0x92c]     | W8 = (bool)static_value_0373492C;       
            // 0x00E2DF38: MOV x19, x0                | X19 = 1152921512981946320 (0x10000001F331DFD0);//ML01
            // 0x00E2DF3C: TBNZ w8, #0, #0xe2df58     | if (static_value_0373492C == true) goto label_0;
            // 0x00E2DF40: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00E2DF44: LDR x8, [x8, #0x5e8]       | X8 = 0x2B8F248;                         
            // 0x00E2DF48: LDR w0, [x8]               | W0 = 0x1354;                            
            // 0x00E2DF4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1354, ????);     
            // 0x00E2DF50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DF54: STRB w8, [x20, #0x92c]     | static_value_0373492C = true;            //  dest_result_addr=57887020
            label_0:
            // 0x00E2DF58: LDR x0, [x19, #0x1a0]      | X0 = this.StartAction; //P2             
            // 0x00E2DF5C: CBZ x0, #0xe2df7c          | if (this.StartAction == null) goto label_1;
            if(this.StartAction == null)
            {
                goto label_1;
            }
            // 0x00E2DF60: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DF64: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DF68: MOV x1, x19                | X1 = 1152921512981946320 (0x10000001F331DFD0);//ML01
            // 0x00E2DF6C: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DF70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DF74: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DF78: B #0x129b8e0               | this.StartAction.Invoke(obj:  this); return;
            this.StartAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DF7C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DF80: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DF84: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DF88 (14868360), len: 100  VirtAddr: 0x00E2DF88 RVA: 0x00E2DF88 token: 100680900 methodIndex: 57298 delegateWrapperIndex: 0 methodInvoker: 0
        private void Awake()
        {
            //
            // Disasemble & Code
            // 0x00E2DF88: STP x20, x19, [sp, #-0x20]! | stack[1152921512982054480] = ???;  stack[1152921512982054488] = ???;  //  dest_result_addr=1152921512982054480 |  dest_result_addr=1152921512982054488
            // 0x00E2DF8C: STP x29, x30, [sp, #0x10]  | stack[1152921512982054496] = ???;  stack[1152921512982054504] = ???;  //  dest_result_addr=1152921512982054496 |  dest_result_addr=1152921512982054504
            // 0x00E2DF90: ADD x29, sp, #0x10         | X29 = (1152921512982054480 + 16) = 1152921512982054496 (0x10000001F3338660);
            // 0x00E2DF94: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DF98: LDRB w8, [x20, #0x92d]     | W8 = (bool)static_value_0373492D;       
            // 0x00E2DF9C: MOV x19, x0                | X19 = 1152921512982066512 (0x10000001F333B550);//ML01
            // 0x00E2DFA0: TBNZ w8, #0, #0xe2dfbc     | if (static_value_0373492D == true) goto label_0;
            // 0x00E2DFA4: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00E2DFA8: LDR x8, [x8, #0x248]       | X8 = 0x2B8F178;                         
            // 0x00E2DFAC: LDR w0, [x8]               | W0 = 0x1320;                            
            // 0x00E2DFB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1320, ????);     
            // 0x00E2DFB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2DFB8: STRB w8, [x20, #0x92d]     | static_value_0373492D = true;            //  dest_result_addr=57887021
            label_0:
            // 0x00E2DFBC: LDR x0, [x19, #0x1a8]      | X0 = this.AwakeAction; //P2             
            // 0x00E2DFC0: CBZ x0, #0xe2dfe0          | if (this.AwakeAction == null) goto label_1;
            if(this.AwakeAction == null)
            {
                goto label_1;
            }
            // 0x00E2DFC4: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2DFC8: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2DFCC: MOV x1, x19                | X1 = 1152921512982066512 (0x10000001F333B550);//ML01
            // 0x00E2DFD0: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2DFD4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DFD8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DFDC: B #0x129b8e0               | this.AwakeAction.Invoke(obj:  this); return;
            this.AwakeAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2DFE0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2DFE4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2DFE8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2DFEC (14868460), len: 100  VirtAddr: 0x00E2DFEC RVA: 0x00E2DFEC token: 100680901 methodIndex: 57299 delegateWrapperIndex: 0 methodInvoker: 0
        private void FixedUpdate()
        {
            //
            // Disasemble & Code
            // 0x00E2DFEC: STP x20, x19, [sp, #-0x20]! | stack[1152921512982174672] = ???;  stack[1152921512982174680] = ???;  //  dest_result_addr=1152921512982174672 |  dest_result_addr=1152921512982174680
            // 0x00E2DFF0: STP x29, x30, [sp, #0x10]  | stack[1152921512982174688] = ???;  stack[1152921512982174696] = ???;  //  dest_result_addr=1152921512982174688 |  dest_result_addr=1152921512982174696
            // 0x00E2DFF4: ADD x29, sp, #0x10         | X29 = (1152921512982174672 + 16) = 1152921512982174688 (0x10000001F3355BE0);
            // 0x00E2DFF8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2DFFC: LDRB w8, [x20, #0x92e]     | W8 = (bool)static_value_0373492E;       
            // 0x00E2E000: MOV x19, x0                | X19 = 1152921512982186704 (0x10000001F3358AD0);//ML01
            // 0x00E2E004: TBNZ w8, #0, #0xe2e020     | if (static_value_0373492E == true) goto label_0;
            // 0x00E2E008: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00E2E00C: LDR x8, [x8, #0xc18]       | X8 = 0x2B8F17C;                         
            // 0x00E2E010: LDR w0, [x8]               | W0 = 0x1321;                            
            // 0x00E2E014: BL #0x2782188              | X0 = sub_2782188( ?? 0x1321, ????);     
            // 0x00E2E018: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E01C: STRB w8, [x20, #0x92e]     | static_value_0373492E = true;            //  dest_result_addr=57887022
            label_0:
            // 0x00E2E020: LDR x0, [x19, #0x1b0]      | X0 = this.FixedUpdateAction; //P2       
            // 0x00E2E024: CBZ x0, #0xe2e044          | if (this.FixedUpdateAction == null) goto label_1;
            if(this.FixedUpdateAction == null)
            {
                goto label_1;
            }
            // 0x00E2E028: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2E02C: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2E030: MOV x1, x19                | X1 = 1152921512982186704 (0x10000001F3358AD0);//ML01
            // 0x00E2E034: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2E038: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E03C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E040: B #0x129b8e0               | this.FixedUpdateAction.Invoke(obj:  this); return;
            this.FixedUpdateAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2E044: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E048: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E04C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E050 (14868560), len: 100  VirtAddr: 0x00E2E050 RVA: 0x00E2E050 token: 100680902 methodIndex: 57300 delegateWrapperIndex: 0 methodInvoker: 0
        private void LateUpdate()
        {
            //
            // Disasemble & Code
            // 0x00E2E050: STP x20, x19, [sp, #-0x20]! | stack[1152921512982294864] = ???;  stack[1152921512982294872] = ???;  //  dest_result_addr=1152921512982294864 |  dest_result_addr=1152921512982294872
            // 0x00E2E054: STP x29, x30, [sp, #0x10]  | stack[1152921512982294880] = ???;  stack[1152921512982294888] = ???;  //  dest_result_addr=1152921512982294880 |  dest_result_addr=1152921512982294888
            // 0x00E2E058: ADD x29, sp, #0x10         | X29 = (1152921512982294864 + 16) = 1152921512982294880 (0x10000001F3373160);
            // 0x00E2E05C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2E060: LDRB w8, [x20, #0x92f]     | W8 = (bool)static_value_0373492F;       
            // 0x00E2E064: MOV x19, x0                | X19 = 1152921512982306896 (0x10000001F3376050);//ML01
            // 0x00E2E068: TBNZ w8, #0, #0xe2e084     | if (static_value_0373492F == true) goto label_0;
            // 0x00E2E06C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00E2E070: LDR x8, [x8, #0xab8]       | X8 = 0x2B8F180;                         
            // 0x00E2E074: LDR w0, [x8]               | W0 = 0x1322;                            
            // 0x00E2E078: BL #0x2782188              | X0 = sub_2782188( ?? 0x1322, ????);     
            // 0x00E2E07C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E080: STRB w8, [x20, #0x92f]     | static_value_0373492F = true;            //  dest_result_addr=57887023
            label_0:
            // 0x00E2E084: LDR x0, [x19, #0x1b8]      | X0 = this.LateUpdateAction; //P2        
            // 0x00E2E088: CBZ x0, #0xe2e0a8          | if (this.LateUpdateAction == null) goto label_1;
            if(this.LateUpdateAction == null)
            {
                goto label_1;
            }
            // 0x00E2E08C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2E090: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2E094: MOV x1, x19                | X1 = 1152921512982306896 (0x10000001F3376050);//ML01
            // 0x00E2E098: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2E09C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E0A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E0A4: B #0x129b8e0               | this.LateUpdateAction.Invoke(obj:  this); return;
            this.LateUpdateAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2E0A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E0AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E0B0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2E0B4 (14868660), len: 100  VirtAddr: 0x00E2E0B4 RVA: 0x00E2E0B4 token: 100680903 methodIndex: 57301 delegateWrapperIndex: 0 methodInvoker: 0
        private void Update()
        {
            //
            // Disasemble & Code
            // 0x00E2E0B4: STP x20, x19, [sp, #-0x20]! | stack[1152921512982415056] = ???;  stack[1152921512982415064] = ???;  //  dest_result_addr=1152921512982415056 |  dest_result_addr=1152921512982415064
            // 0x00E2E0B8: STP x29, x30, [sp, #0x10]  | stack[1152921512982415072] = ???;  stack[1152921512982415080] = ???;  //  dest_result_addr=1152921512982415072 |  dest_result_addr=1152921512982415080
            // 0x00E2E0BC: ADD x29, sp, #0x10         | X29 = (1152921512982415056 + 16) = 1152921512982415072 (0x10000001F33906E0);
            // 0x00E2E0C0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2E0C4: LDRB w8, [x20, #0x930]     | W8 = (bool)static_value_03734930;       
            // 0x00E2E0C8: MOV x19, x0                | X19 = 1152921512982427088 (0x10000001F33935D0);//ML01
            // 0x00E2E0CC: TBNZ w8, #0, #0xe2e0e8     | if (static_value_03734930 == true) goto label_0;
            // 0x00E2E0D0: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x00E2E0D4: LDR x8, [x8, #0x478]       | X8 = 0x2B8F24C;                         
            // 0x00E2E0D8: LDR w0, [x8]               | W0 = 0x1355;                            
            // 0x00E2E0DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1355, ????);     
            // 0x00E2E0E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2E0E4: STRB w8, [x20, #0x930]     | static_value_03734930 = true;            //  dest_result_addr=57887024
            label_0:
            // 0x00E2E0E8: LDR x0, [x19, #0x1c0]      | X0 = this.UpdateAction; //P2            
            // 0x00E2E0EC: CBZ x0, #0xe2e10c          | if (this.UpdateAction == null) goto label_1;
            if(this.UpdateAction == null)
            {
                goto label_1;
            }
            // 0x00E2E0F0: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E2E0F4: LDR x8, [x8, #0x318]       | X8 = 1152921512975927824;               
            // 0x00E2E0F8: MOV x1, x19                | X1 = 1152921512982427088 (0x10000001F33935D0);//ML01
            // 0x00E2E0FC: LDR x2, [x8]               | X2 = public System.Void System.Action<wxb.BehaviourAction>::Invoke(wxb.BehaviourAction obj);
            // 0x00E2E100: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E104: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E108: B #0x129b8e0               | this.UpdateAction.Invoke(obj:  this); return;
            this.UpdateAction.Invoke(obj:  this);
            return;
            label_1:
            // 0x00E2E10C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2E110: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2E114: RET                        |  return;                                
            return;
        
        }
    
    }

}
