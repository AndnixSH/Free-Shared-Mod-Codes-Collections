using UnityEngine;
public class ColorChanger : MonoBehaviour
{
    // Fields
    private UnityEngine.Mesh mesh; //  0x00000018
    private UnityEngine.Color[] meshColors; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D862C4 (14181060), len: 8  VirtAddr: 0x00D862C4 RVA: 0x00D862C4 token: 100663297 methodIndex: 25998 delegateWrapperIndex: 0 methodInvoker: 0
    public ColorChanger()
    {
        //
        // Disasemble & Code
        // 0x00D862C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D862C8: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D862CC (14181068), len: 196  VirtAddr: 0x00D862CC RVA: 0x00D862CC token: 100663298 methodIndex: 25999 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        // 0x00D862CC: STP x22, x21, [sp, #-0x30]! | stack[1152921509976418160] = ???;  stack[1152921509976418168] = ???;  //  dest_result_addr=1152921509976418160 |  dest_result_addr=1152921509976418168
        // 0x00D862D0: STP x20, x19, [sp, #0x10]  | stack[1152921509976418176] = ???;  stack[1152921509976418184] = ???;  //  dest_result_addr=1152921509976418176 |  dest_result_addr=1152921509976418184
        // 0x00D862D4: STP x29, x30, [sp, #0x20]  | stack[1152921509976418192] = ???;  stack[1152921509976418200] = ???;  //  dest_result_addr=1152921509976418192 |  dest_result_addr=1152921509976418200
        // 0x00D862D8: ADD x29, sp, #0x20         | X29 = (1152921509976418160 + 32) = 1152921509976418192 (0x10000001400D2790);
        // 0x00D862DC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D862E0: LDRB w8, [x20, #0x43e]     | W8 = (bool)static_value_0373443E;       
        // 0x00D862E4: MOV x19, x0                | X19 = 1152921509976430208 (0x10000001400D5680);//ML01
        // 0x00D862E8: TBNZ w8, #0, #0xd86304     | if (static_value_0373443E == true) goto label_0;
        // 0x00D862EC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00D862F0: LDR x8, [x8, #0x168]       | X8 = 0x2B9170C;                         
        // 0x00D862F4: LDR w0, [x8]               | W0 = 0x1C88;                            
        // 0x00D862F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C88, ????);     
        // 0x00D862FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D86300: STRB w8, [x20, #0x43e]     | static_value_0373443E = true;            //  dest_result_addr=57885758
        label_0:
        // 0x00D86304: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00D86308: LDR x8, [x8, #0x588]       | X8 = 1152921509976360128;               
        // 0x00D8630C: MOV x0, x19                | X0 = 1152921509976430208 (0x10000001400D5680);//ML01
        // 0x00D86310: LDR x1, [x8]               | X1 = public UnityEngine.MeshFilter UnityEngine.Component::GetComponent<UnityEngine.MeshFilter>();
        // 0x00D86314: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.MeshFilter>();
        UnityEngine.MeshFilter val_1 = this.GetComponent<UnityEngine.MeshFilter>();
        // 0x00D86318: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D8631C: CBNZ x20, #0xd86324        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00D86320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00D86324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86328: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D8632C: BL #0x1b76c10              | X0 = val_1.get_mesh();                  
        UnityEngine.Mesh val_2 = val_1.mesh;
        // 0x00D86330: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00D86334: STR x20, [x19, #0x18]      | this.mesh = val_2;                       //  dest_result_addr=1152921509976430232
        this.mesh = val_2;
        // 0x00D86338: CBNZ x20, #0xd86340        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00D8633C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00D86340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86344: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00D86348: BL #0x1b749b8              | X0 = val_2.get_vertices();              
        UnityEngine.Vector3[] val_3 = val_2.vertices;
        // 0x00D8634C: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00D86350: CBNZ x20, #0xd86358        | if (val_3 != null) goto label_3;        
        if(val_3 != null)
        {
            goto label_3;
        }
        // 0x00D86354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00D86358: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00D8635C: LDR x8, [x8, #0x190]       | X8 = 1152921505690746144;               
        // 0x00D86360: LDR w20, [x20, #0x18]      | W20 = val_3.Length; //P2                
        // 0x00D86364: LDR x21, [x8]              | X21 = typeof(UnityEngine.Color[]);      
        // 0x00D86368: MOV x0, x21                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x00D8636C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Color[]), ????);
        // 0x00D86370: MOV x0, x21                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x00D86374: MOV x1, x20                | X1 = val_3.Length;//m1                  
        // 0x00D86378: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Color[]), ????);
        // 0x00D8637C: STR x0, [x19, #0x20]       | this.meshColors = typeof(UnityEngine.Color[]);  //  dest_result_addr=1152921509976430240
        this.meshColors = null;
        // 0x00D86380: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D86384: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D86388: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D8638C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D86390 (14181264), len: 452  VirtAddr: 0x00D86390 RVA: 0x00D86390 token: 100663299 methodIndex: 26000 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_9;
        // 0x00D86390: STP d11, d10, [sp, #-0x50]! | stack[1152921509976693968] = ???;  stack[1152921509976693976] = ???;  //  dest_result_addr=1152921509976693968 |  dest_result_addr=1152921509976693976
        // 0x00D86394: STP d9, d8, [sp, #0x10]    | stack[1152921509976693984] = ???;  stack[1152921509976693992] = ???;  //  dest_result_addr=1152921509976693984 |  dest_result_addr=1152921509976693992
        // 0x00D86398: STP x22, x21, [sp, #0x20]  | stack[1152921509976694000] = ???;  stack[1152921509976694008] = ???;  //  dest_result_addr=1152921509976694000 |  dest_result_addr=1152921509976694008
        // 0x00D8639C: STP x20, x19, [sp, #0x30]  | stack[1152921509976694016] = ???;  stack[1152921509976694024] = ???;  //  dest_result_addr=1152921509976694016 |  dest_result_addr=1152921509976694024
        // 0x00D863A0: STP x29, x30, [sp, #0x40]  | stack[1152921509976694032] = ???;  stack[1152921509976694040] = ???;  //  dest_result_addr=1152921509976694032 |  dest_result_addr=1152921509976694040
        // 0x00D863A4: ADD x29, sp, #0x40         | X29 = (1152921509976693968 + 64) = 1152921509976694032 (0x1000000140115D10);
        // 0x00D863A8: SUB sp, sp, #0x30          | SP = (1152921509976693968 - 48) = 1152921509976693920 (0x1000000140115CA0);
        // 0x00D863AC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D863B0: LDRB w8, [x20, #0x43f]     | W8 = (bool)static_value_0373443F;       
        // 0x00D863B4: MOV x19, x0                | X19 = 1152921509976706048 (0x1000000140118C00);//ML01
        // 0x00D863B8: TBNZ w8, #0, #0xd863d4     | if (static_value_0373443F == true) goto label_0;
        // 0x00D863BC: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00D863C0: LDR x8, [x8, #0x610]       | X8 = 0x2B91710;                         
        // 0x00D863C4: LDR w0, [x8]               | W0 = 0x1C89;                            
        // 0x00D863C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C89, ????);     
        // 0x00D863CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D863D0: STRB w8, [x20, #0x43f]     | static_value_0373443F = true;            //  dest_result_addr=57885759
        label_0:
        // 0x00D863D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D863D8: MOV x0, x19                | X0 = 1152921509976706048 (0x1000000140118C00);//ML01
        // 0x00D863DC: STR wzr, [sp, #0x28]       | stack[1152921509976693960] = 0x0;        //  dest_result_addr=1152921509976693960
        // 0x00D863E0: STP xzr, xzr, [sp, #0x18]  | stack[1152921509976693944] = 0x0;  stack[1152921509976693952] = 0x0;  //  dest_result_addr=1152921509976693944 |  dest_result_addr=1152921509976693952
        // 0x00D863E4: STR xzr, [sp, #0x10]       | stack[1152921509976693936] = 0x0;        //  dest_result_addr=1152921509976693936
        // 0x00D863E8: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00D863EC: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D863F0: CBNZ x20, #0xd863f8        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00D863F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00D863F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D863FC: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D86400: BL #0x2693510              | X0 = val_1.get_position();              
        UnityEngine.Vector3 val_2 = val_1.position;
        // 0x00D86404: ADD x0, sp, #0x20          | X0 = (1152921509976693920 + 32) = 1152921509976693952 (0x1000000140115CC0);
        // 0x00D86408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8640C: STP s0, s1, [sp, #0x20]    | stack[1152921509976693952] = val_2.x;  stack[1152921509976693956] = val_2.y;  //  dest_result_addr=1152921509976693952 |  dest_result_addr=1152921509976693956
        // 0x00D86410: STR s2, [sp, #0x28]        | stack[1152921509976693960] = val_2.z;    //  dest_result_addr=1152921509976693960
        // 0x00D86414: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00D86418: FMOV s1, #3.00000000       | S1 = 3;                                 
        // 0x00D8641C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D86420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86424: FDIV s10, s0, s1           | S10 = (val_2.x / 3f);                   
        float val_3 = val_2.x / 3f;
        // 0x00D86428: BL #0x2690b5c              | X0 = UnityEngine.Time.get_timeSinceLevelLoad();
        float val_4 = UnityEngine.Time.timeSinceLevelLoad;
        // 0x00D8642C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D86430: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D86434: MOV v8.16b, v0.16b         | V8 = val_4;//m1                         
        // 0x00D86438: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D8643C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D86440: TBZ w8, #0, #0xd86450      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00D86444: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D86448: CBNZ w8, #0xd86450         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00D8644C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x00D86450: FADD s0, s8, s10           | S0 = (val_4 + (val_2.x / 3f));          
        val_4 = val_4 + val_3;
        // 0x00D86454: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00D86458: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8645C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86460: FABS s8, s0                | S8 = System.Math.Abs((val_4 + (val_2.x / 3f)));
        float val_9 = System.Math.Abs(val_4);
        // 0x00D86464: BL #0x2690b5c              | X0 = UnityEngine.Time.get_timeSinceLevelLoad();
        float val_5 = UnityEngine.Time.timeSinceLevelLoad;
        // 0x00D86468: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
        // 0x00D8646C: LDR s1, [x8, #0x450]       | S1 = 0.45;                              
        // 0x00D86470: FMUL s0, s0, s1            | S0 = (val_5 * 0.45f);                   
        val_5 = val_5 * 0.45f;
        // 0x00D86474: FADD s0, s10, s0           | S0 = ((val_2.x / 3f) + (val_5 * 0.45f));
        val_5 = val_3 + val_5;
        // 0x00D86478: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
        // 0x00D8647C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D86480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86484: FABS s9, s0                | S9 = System.Math.Abs(((val_2.x / 3f) + (val_5 * 0.45f)));
        float val_10 = System.Math.Abs(val_5);
        // 0x00D86488: BL #0x2690b5c              | X0 = UnityEngine.Time.get_timeSinceLevelLoad();
        float val_6 = UnityEngine.Time.timeSinceLevelLoad;
        // 0x00D8648C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00D86490: LDR s1, [x8, #0x768]       | S1 = 1.2;                               
        // 0x00D86494: FMUL s0, s0, s1            | S0 = (val_6 * 1.2f);                    
        val_6 = val_6 * 1.2f;
        // 0x00D86498: FADD s0, s10, s0           | S0 = ((val_2.x / 3f) + (val_6 * 1.2f)); 
        val_6 = val_3 + val_6;
        // 0x00D8649C: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
        // 0x00D864A0: FABS s2, s0                | S2 = System.Math.Abs(((val_2.x / 3f) + (val_6 * 1.2f)));
        float val_11 = System.Math.Abs(val_6);
        // 0x00D864A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D864A8: ADD x0, sp, #0x10          | X0 = (1152921509976693920 + 16) = 1152921509976693936 (0x1000000140115CB0);
        // 0x00D864AC: MOV v0.16b, v8.16b         | V0 = (val_4 + (val_2.x / 3f));//m1      
        // 0x00D864B0: MOV v1.16b, v9.16b         | V1 = ((val_2.x / 3f) + (val_5 * 0.45f));//m1
        // 0x00D864B4: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x00D864B8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_9 = 0;
        // 0x00D864BC: B #0xd864d0                |  goto label_4;                          
        goto label_4;
        label_9:
        // 0x00D864C0: LDR q0, [sp]               | Q0 = val_7;                              //  find_add[1152921509976682048]
        // 0x00D864C4: ADD x8, x21, x22, lsl #4   | X8 = (X21 + (X22) << 4);                
        var val_8 = X21 + ((X22) << 4);
        // 0x00D864C8: ADD w20, w20, #1           | W20 = (val_9 + 1) = val_9 (0x00000001); 
        val_9 = 1;
        // 0x00D864CC: STR q0, [x8, #0x20]        | mem2[0] = val_7;                         //  dest_result_addr=0
        mem2[0] = val_7;
        label_4:
        // 0x00D864D0: LDR x21, [x19, #0x20]      | X21 = this.meshColors; //P2             
        // 0x00D864D4: CBNZ x21, #0xd864dc        | if (this.meshColors != null) goto label_5;
        if(this.meshColors != null)
        {
            goto label_5;
        }
        // 0x00D864D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000140115CB0, ????);
        label_5:
        // 0x00D864DC: LDR w8, [x21, #0x18]       | W8 = this.meshColors.Length; //P2       
        // 0x00D864E0: CMP w20, w8                | STATE = COMPARE(0x1, this.meshColors.Length)
        // 0x00D864E4: B.GE #0xd8651c             | if (val_9 >= this.meshColors.Length) goto label_6;
        if(val_9 >= this.meshColors.Length)
        {
            goto label_6;
        }
        // 0x00D864E8: LDR x21, [x19, #0x20]      | X21 = this.meshColors; //P2             
        // 0x00D864EC: CBNZ x21, #0xd864f4        | if (this.meshColors != null) goto label_7;
        if(this.meshColors != null)
        {
            goto label_7;
        }
        // 0x00D864F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000140115CB0, ????);
        label_7:
        // 0x00D864F4: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
        // 0x00D864F8: SXTW x22, w20              | X22 = 1 (0x00000001);                   
        // 0x00D864FC: STR q0, [sp]               | val_7 = 0x0;                             //  dest_result_addr=1152921509976693920
        val_7 = 0;
        // 0x00D86500: LDR w8, [x21, #0x18]       | W8 = this.meshColors.Length; //P2       
        // 0x00D86504: CMP w20, w8                | STATE = COMPARE(0x1, this.meshColors.Length)
        // 0x00D86508: B.LO #0xd864c0             | if (val_9 < this.meshColors.Length) goto label_9;
        if(val_9 < this.meshColors.Length)
        {
            goto label_9;
        }
        // 0x00D8650C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000140115CB0, ????);
        // 0x00D86510: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86514: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000140115CB0, ????);
        // 0x00D86518: B #0xd864c0                |  goto label_9;                          
        goto label_9;
        label_6:
        // 0x00D8651C: LDP x20, x19, [x19, #0x18] | X20 = this.mesh; //P2  X19 = this.meshColors; //P2  //  | 
        // 0x00D86520: CBNZ x20, #0xd86528        | if (this.mesh != null) goto label_10;   
        if(this.mesh != null)
        {
            goto label_10;
        }
        // 0x00D86524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000140115CB0, ????);
        label_10:
        // 0x00D86528: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8652C: MOV x0, x20                | X0 = this.mesh;//m1                     
        // 0x00D86530: MOV x1, x19                | X1 = this.meshColors;//m1               
        // 0x00D86534: BL #0x1b74f14              | this.mesh.set_colors(value:  this.meshColors);
        this.mesh.colors = this.meshColors;
        // 0x00D86538: SUB sp, x29, #0x40         | SP = (1152921509976694032 - 64) = 1152921509976693968 (0x1000000140115CD0);
        // 0x00D8653C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00D86540: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00D86544: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00D86548: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00D8654C: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00D86550: RET                        |  return;                                
        return;
    
    }

}
