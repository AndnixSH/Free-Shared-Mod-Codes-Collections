using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286BA38
[Serializable]
public class CameraAniMap : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private readonly System.Collections.Generic.List<CameraAniGroup> _cameraAniGroups; //  0x00000018
    private ProtoBuf.IExtension extensionObject; //  0x00000020
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286BA7C
    [System.ComponentModel.DefaultValueAttribute] // 0x286BA7C
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286BAFC
    public System.Collections.Generic.List<CameraAniGroup> cameraAniGroups { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA70F4 (12218612), len: 112  VirtAddr: 0x00BA70F4 RVA: 0x00BA70F4 token: 100690300 methodIndex: 25649 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAniMap()
    {
        //
        // Disasemble & Code
        // 0x00BA70F4: STP x20, x19, [sp, #-0x20]! | stack[1152921514505504992] = ???;  stack[1152921514505505000] = ???;  //  dest_result_addr=1152921514505504992 |  dest_result_addr=1152921514505505000
        // 0x00BA70F8: STP x29, x30, [sp, #0x10]  | stack[1152921514505505008] = ???;  stack[1152921514505505016] = ???;  //  dest_result_addr=1152921514505505008 |  dest_result_addr=1152921514505505016
        // 0x00BA70FC: ADD x29, sp, #0x10         | X29 = (1152921514505504992 + 16) = 1152921514505505008 (0x100000024E0188F0);
        // 0x00BA7100: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA7104: LDRB w8, [x20, #0xae4]     | W8 = (bool)static_value_03733AE4;       
        // 0x00BA7108: MOV x19, x0                | X19 = 1152921514505517024 (0x100000024E01B7E0);//ML01
        // 0x00BA710C: TBNZ w8, #0, #0xba7128     | if (static_value_03733AE4 == true) goto label_0;
        // 0x00BA7110: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00BA7114: LDR x8, [x8, #0x370]       | X8 = 0x2B90144;                         
        // 0x00BA7118: LDR w0, [x8]               | W0 = 0x1715;                            
        // 0x00BA711C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1715, ????);     
        // 0x00BA7120: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA7124: STRB w8, [x20, #0xae4]     | static_value_03733AE4 = true;            //  dest_result_addr=57883364
        label_0:
        // 0x00BA7128: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00BA712C: LDR x8, [x8, #0x90]        | X8 = 1152921504616644608;               
        // 0x00BA7130: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraAniGroup> val_1 = null;
        // 0x00BA7134: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA7138: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00BA713C: LDR x8, [x8, #0xdf0]       | X8 = 1152921514505492000;               
        // 0x00BA7140: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA7144: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CameraAniGroup>::.ctor();
        // 0x00BA7148: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<CameraAniGroup>();
        // 0x00BA714C: STR x20, [x19, #0x18]      | this._cameraAniGroups = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514505517048
        this._cameraAniGroups = val_1;
        // 0x00BA7150: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7154: MOV x0, x19                | X0 = 1152921514505517024 (0x100000024E01B7E0);//ML01
        // 0x00BA7158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA715C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7160: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6FEC (12218348), len: 8  VirtAddr: 0x00BA6FEC RVA: 0x00BA6FEC token: 100690301 methodIndex: 25650 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00BA6FEC: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00BA6FF0: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7164 (12218724), len: 8  VirtAddr: 0x00BA7164 RVA: 0x00BA7164 token: 100690302 methodIndex: 25651 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA7164: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514505741040
        this._id = value;
        // 0x00BA7168: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA716C (12218732), len: 8  VirtAddr: 0x00BA716C RVA: 0x00BA716C token: 100690303 methodIndex: 25652 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<CameraAniGroup> get_cameraAniGroups()
    {
        //
        // Disasemble & Code
        // 0x00BA716C: LDR x0, [x0, #0x18]        | X0 = this._cameraAniGroups; //P2        
        // 0x00BA7170: RET                        |  return (System.Collections.Generic.List<CameraAniGroup>)this._cameraAniGroups;
        return this._cameraAniGroups;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<CameraAniGroup>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7174 (12218740), len: 24  VirtAddr: 0x00BA7174 RVA: 0x00BA7174 token: 100690304 methodIndex: 25653 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BA7174: ADD x8, x0, #0x20          | X8 = this.extensionObject;//AP2 res_addr=1152921514505973248
        // 0x00BA7178: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BA717C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BA7180: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BA7184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA7188: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
