using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286DEDC
[Serializable]
public class CameraShotCircleCfg : IExtensible
{
    // Fields
    private int _isCircle; //  0x00000010
    private int _heroOrNpcId; //  0x00000014
    private int _isHero; //  0x00000018
    private float _posX; //  0x0000001C
    private float _posY; //  0x00000020
    private float _posZ; //  0x00000024
    private float _speed; //  0x00000028
    private float _distance; //  0x0000002C
    private float _high; //  0x00000030
    private float _angle; //  0x00000034
    private ProtoBuf.IExtension extensionObject; //  0x00000038
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286DF20
    [System.ComponentModel.DefaultValueAttribute] // 0x286DF20
    public int isCircle { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286DFA0
    [System.ComponentModel.DefaultValueAttribute] // 0x286DFA0
    public int heroOrNpcId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E020
    [System.ComponentModel.DefaultValueAttribute] // 0x286E020
    public int isHero { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E0A0
    [System.ComponentModel.DefaultValueAttribute] // 0x286E0A0
    public float posX { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E120
    [System.ComponentModel.DefaultValueAttribute] // 0x286E120
    public float posY { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E1A0
    [System.ComponentModel.DefaultValueAttribute] // 0x286E1A0
    public float posZ { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E220
    [System.ComponentModel.DefaultValueAttribute] // 0x286E220
    public float speed { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E2A0
    [System.ComponentModel.DefaultValueAttribute] // 0x286E2A0
    public float distance { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E320
    [System.ComponentModel.DefaultValueAttribute] // 0x286E320
    public float high { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E3A0
    [System.ComponentModel.DefaultValueAttribute] // 0x286E3A0
    public float angle { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BADB54 (12245844), len: 8  VirtAddr: 0x00BADB54 RVA: 0x00BADB54 token: 100690458 methodIndex: 25725 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotCircleCfg()
    {
        //
        // Disasemble & Code
        // 0x00BADB54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADB58: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB5C (12245852), len: 8  VirtAddr: 0x00BADB5C RVA: 0x00BADB5C token: 100690459 methodIndex: 25726 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isCircle()
    {
        //
        // Disasemble & Code
        // 0x00BADB5C: LDR w0, [x0, #0x10]        | W0 = this._isCircle; //P2               
        // 0x00BADB60: RET                        |  return (System.Int32)this._isCircle;   
        return this._isCircle;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB64 (12245860), len: 8  VirtAddr: 0x00BADB64 RVA: 0x00BADB64 token: 100690460 methodIndex: 25727 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isCircle(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADB64: STR w1, [x0, #0x10]        | this._isCircle = value;                  //  dest_result_addr=1152921514523661744
        this._isCircle = value;
        // 0x00BADB68: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB6C (12245868), len: 8  VirtAddr: 0x00BADB6C RVA: 0x00BADB6C token: 100690461 methodIndex: 25728 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_heroOrNpcId()
    {
        //
        // Disasemble & Code
        // 0x00BADB6C: LDR w0, [x0, #0x14]        | W0 = this._heroOrNpcId; //P2            
        // 0x00BADB70: RET                        |  return (System.Int32)this._heroOrNpcId;
        return this._heroOrNpcId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB74 (12245876), len: 8  VirtAddr: 0x00BADB74 RVA: 0x00BADB74 token: 100690462 methodIndex: 25729 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_heroOrNpcId(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADB74: STR w1, [x0, #0x14]        | this._heroOrNpcId = value;               //  dest_result_addr=1152921514523885748
        this._heroOrNpcId = value;
        // 0x00BADB78: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB7C (12245884), len: 8  VirtAddr: 0x00BADB7C RVA: 0x00BADB7C token: 100690463 methodIndex: 25730 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isHero()
    {
        //
        // Disasemble & Code
        // 0x00BADB7C: LDR w0, [x0, #0x18]        | W0 = this._isHero; //P2                 
        // 0x00BADB80: RET                        |  return (System.Int32)this._isHero;     
        return this._isHero;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB84 (12245892), len: 8  VirtAddr: 0x00BADB84 RVA: 0x00BADB84 token: 100690464 methodIndex: 25731 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isHero(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADB84: STR w1, [x0, #0x18]        | this._isHero = value;                    //  dest_result_addr=1152921514524109752
        this._isHero = value;
        // 0x00BADB88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB8C (12245900), len: 8  VirtAddr: 0x00BADB8C RVA: 0x00BADB8C token: 100690465 methodIndex: 25732 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posX()
    {
        //
        // Disasemble & Code
        // 0x00BADB8C: LDR s0, [x0, #0x1c]        | S0 = this._posX; //P2                   
        // 0x00BADB90: RET                        |  return (System.Single)this._posX;      
        return this._posX;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB94 (12245908), len: 8  VirtAddr: 0x00BADB94 RVA: 0x00BADB94 token: 100690466 methodIndex: 25733 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posX(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADB94: STR s0, [x0, #0x1c]        | this._posX = value;                      //  dest_result_addr=1152921514524333756
        this._posX = value;
        // 0x00BADB98: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADB9C (12245916), len: 8  VirtAddr: 0x00BADB9C RVA: 0x00BADB9C token: 100690467 methodIndex: 25734 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posY()
    {
        //
        // Disasemble & Code
        // 0x00BADB9C: LDR s0, [x0, #0x20]        | S0 = this._posY; //P2                   
        // 0x00BADBA0: RET                        |  return (System.Single)this._posY;      
        return this._posY;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBA4 (12245924), len: 8  VirtAddr: 0x00BADBA4 RVA: 0x00BADBA4 token: 100690468 methodIndex: 25735 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posY(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADBA4: STR s0, [x0, #0x20]        | this._posY = value;                      //  dest_result_addr=1152921514524557760
        this._posY = value;
        // 0x00BADBA8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBAC (12245932), len: 8  VirtAddr: 0x00BADBAC RVA: 0x00BADBAC token: 100690469 methodIndex: 25736 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posZ()
    {
        //
        // Disasemble & Code
        // 0x00BADBAC: LDR s0, [x0, #0x24]        | S0 = this._posZ; //P2                   
        // 0x00BADBB0: RET                        |  return (System.Single)this._posZ;      
        return this._posZ;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBB4 (12245940), len: 8  VirtAddr: 0x00BADBB4 RVA: 0x00BADBB4 token: 100690470 methodIndex: 25737 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posZ(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADBB4: STR s0, [x0, #0x24]        | this._posZ = value;                      //  dest_result_addr=1152921514524781764
        this._posZ = value;
        // 0x00BADBB8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBBC (12245948), len: 8  VirtAddr: 0x00BADBBC RVA: 0x00BADBBC token: 100690471 methodIndex: 25738 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_speed()
    {
        //
        // Disasemble & Code
        // 0x00BADBBC: LDR s0, [x0, #0x28]        | S0 = this._speed; //P2                  
        // 0x00BADBC0: RET                        |  return (System.Single)this._speed;     
        return this._speed;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBC4 (12245956), len: 8  VirtAddr: 0x00BADBC4 RVA: 0x00BADBC4 token: 100690472 methodIndex: 25739 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_speed(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADBC4: STR s0, [x0, #0x28]        | this._speed = value;                     //  dest_result_addr=1152921514525005768
        this._speed = value;
        // 0x00BADBC8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBCC (12245964), len: 8  VirtAddr: 0x00BADBCC RVA: 0x00BADBCC token: 100690473 methodIndex: 25740 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_distance()
    {
        //
        // Disasemble & Code
        // 0x00BADBCC: LDR s0, [x0, #0x2c]        | S0 = this._distance; //P2               
        // 0x00BADBD0: RET                        |  return (System.Single)this._distance;  
        return this._distance;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBD4 (12245972), len: 8  VirtAddr: 0x00BADBD4 RVA: 0x00BADBD4 token: 100690474 methodIndex: 25741 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_distance(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADBD4: STR s0, [x0, #0x2c]        | this._distance = value;                  //  dest_result_addr=1152921514525229772
        this._distance = value;
        // 0x00BADBD8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBDC (12245980), len: 8  VirtAddr: 0x00BADBDC RVA: 0x00BADBDC token: 100690475 methodIndex: 25742 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_high()
    {
        //
        // Disasemble & Code
        // 0x00BADBDC: LDR s0, [x0, #0x30]        | S0 = this._high; //P2                   
        // 0x00BADBE0: RET                        |  return (System.Single)this._high;      
        return this._high;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBE4 (12245988), len: 8  VirtAddr: 0x00BADBE4 RVA: 0x00BADBE4 token: 100690476 methodIndex: 25743 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_high(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADBE4: STR s0, [x0, #0x30]        | this._high = value;                      //  dest_result_addr=1152921514525453776
        this._high = value;
        // 0x00BADBE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBEC (12245996), len: 8  VirtAddr: 0x00BADBEC RVA: 0x00BADBEC token: 100690477 methodIndex: 25744 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_angle()
    {
        //
        // Disasemble & Code
        // 0x00BADBEC: LDR s0, [x0, #0x34]        | S0 = this._angle; //P2                  
        // 0x00BADBF0: RET                        |  return (System.Single)this._angle;     
        return this._angle;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBF4 (12246004), len: 8  VirtAddr: 0x00BADBF4 RVA: 0x00BADBF4 token: 100690478 methodIndex: 25745 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_angle(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADBF4: STR s0, [x0, #0x34]        | this._angle = value;                     //  dest_result_addr=1152921514525677780
        this._angle = value;
        // 0x00BADBF8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADBFC (12246012), len: 24  VirtAddr: 0x00BADBFC RVA: 0x00BADBFC token: 100690479 methodIndex: 25746 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BADBFC: ADD x8, x0, #0x38          | X8 = this.extensionObject;//AP2 res_addr=1152921514525789784
        // 0x00BADC00: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BADC04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BADC08: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BADC0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BADC10: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
