using UnityEngine;
public class ColorChangerVertex : MonoBehaviour
{
    // Fields
    private UnityEngine.Mesh mesh; //  0x00000018
    private UnityEngine.Color[] meshColors; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D86554 (14181716), len: 8  VirtAddr: 0x00D86554 RVA: 0x00D86554 token: 100663300 methodIndex: 26001 delegateWrapperIndex: 0 methodInvoker: 0
    public ColorChangerVertex()
    {
        //
        // Disasemble & Code
        // 0x00D86554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86558: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D8655C (14181724), len: 196  VirtAddr: 0x00D8655C RVA: 0x00D8655C token: 100663301 methodIndex: 26002 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        // 0x00D8655C: STP x22, x21, [sp, #-0x30]! | stack[1152921509977081840] = ???;  stack[1152921509977081848] = ???;  //  dest_result_addr=1152921509977081840 |  dest_result_addr=1152921509977081848
        // 0x00D86560: STP x20, x19, [sp, #0x10]  | stack[1152921509977081856] = ???;  stack[1152921509977081864] = ???;  //  dest_result_addr=1152921509977081856 |  dest_result_addr=1152921509977081864
        // 0x00D86564: STP x29, x30, [sp, #0x20]  | stack[1152921509977081872] = ???;  stack[1152921509977081880] = ???;  //  dest_result_addr=1152921509977081872 |  dest_result_addr=1152921509977081880
        // 0x00D86568: ADD x29, sp, #0x20         | X29 = (1152921509977081840 + 32) = 1152921509977081872 (0x1000000140174810);
        // 0x00D8656C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D86570: LDRB w8, [x20, #0x440]     | W8 = (bool)static_value_03734440;       
        // 0x00D86574: MOV x19, x0                | X19 = 1152921509977093888 (0x1000000140177700);//ML01
        // 0x00D86578: TBNZ w8, #0, #0xd86594     | if (static_value_03734440 == true) goto label_0;
        // 0x00D8657C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00D86580: LDR x8, [x8, #0xd58]       | X8 = 0x2B91714;                         
        // 0x00D86584: LDR w0, [x8]               | W0 = 0x1C8A;                            
        // 0x00D86588: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8A, ????);     
        // 0x00D8658C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D86590: STRB w8, [x20, #0x440]     | static_value_03734440 = true;            //  dest_result_addr=57885760
        label_0:
        // 0x00D86594: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00D86598: LDR x8, [x8, #0x588]       | X8 = 1152921509976360128;               
        // 0x00D8659C: MOV x0, x19                | X0 = 1152921509977093888 (0x1000000140177700);//ML01
        // 0x00D865A0: LDR x1, [x8]               | X1 = public UnityEngine.MeshFilter UnityEngine.Component::GetComponent<UnityEngine.MeshFilter>();
        // 0x00D865A4: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.MeshFilter>();
        UnityEngine.MeshFilter val_1 = this.GetComponent<UnityEngine.MeshFilter>();
        // 0x00D865A8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D865AC: CBNZ x20, #0xd865b4        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00D865B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00D865B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D865B8: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D865BC: BL #0x1b76c10              | X0 = val_1.get_mesh();                  
        UnityEngine.Mesh val_2 = val_1.mesh;
        // 0x00D865C0: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00D865C4: STR x20, [x19, #0x18]      | this.mesh = val_2;                       //  dest_result_addr=1152921509977093912
        this.mesh = val_2;
        // 0x00D865C8: CBNZ x20, #0xd865d0        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00D865CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00D865D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D865D4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00D865D8: BL #0x1b749b8              | X0 = val_2.get_vertices();              
        UnityEngine.Vector3[] val_3 = val_2.vertices;
        // 0x00D865DC: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00D865E0: CBNZ x20, #0xd865e8        | if (val_3 != null) goto label_3;        
        if(val_3 != null)
        {
            goto label_3;
        }
        // 0x00D865E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00D865E8: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00D865EC: LDR x8, [x8, #0x190]       | X8 = 1152921505690746144;               
        // 0x00D865F0: LDR w20, [x20, #0x18]      | W20 = val_3.Length; //P2                
        // 0x00D865F4: LDR x21, [x8]              | X21 = typeof(UnityEngine.Color[]);      
        // 0x00D865F8: MOV x0, x21                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x00D865FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Color[]), ????);
        // 0x00D86600: MOV x0, x21                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x00D86604: MOV x1, x20                | X1 = val_3.Length;//m1                  
        // 0x00D86608: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Color[]), ????);
        // 0x00D8660C: STR x0, [x19, #0x20]       | this.meshColors = typeof(UnityEngine.Color[]);  //  dest_result_addr=1152921509977093920
        this.meshColors = null;
        // 0x00D86610: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D86614: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D86618: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D8661C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D86620 (14181920), len: 484  VirtAddr: 0x00D86620 RVA: 0x00D86620 token: 100663302 methodIndex: 26003 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        float val_1;
        //  | 
        var val_7;
        //  | 
        var val_8;
        // 0x00D86620: STP d13, d12, [sp, #-0x70]! | stack[1152921509977390384] = ???;  stack[1152921509977390392] = ???;  //  dest_result_addr=1152921509977390384 |  dest_result_addr=1152921509977390392
        // 0x00D86624: STP d11, d10, [sp, #0x10]  | stack[1152921509977390400] = ???;  stack[1152921509977390408] = ???;  //  dest_result_addr=1152921509977390400 |  dest_result_addr=1152921509977390408
        // 0x00D86628: STP d9, d8, [sp, #0x20]    | stack[1152921509977390416] = ???;  stack[1152921509977390424] = ???;  //  dest_result_addr=1152921509977390416 |  dest_result_addr=1152921509977390424
        // 0x00D8662C: STP x24, x23, [sp, #0x30]  | stack[1152921509977390432] = ???;  stack[1152921509977390440] = ???;  //  dest_result_addr=1152921509977390432 |  dest_result_addr=1152921509977390440
        // 0x00D86630: STP x22, x21, [sp, #0x40]  | stack[1152921509977390448] = ???;  stack[1152921509977390456] = ???;  //  dest_result_addr=1152921509977390448 |  dest_result_addr=1152921509977390456
        // 0x00D86634: STP x20, x19, [sp, #0x50]  | stack[1152921509977390464] = ???;  stack[1152921509977390472] = ???;  //  dest_result_addr=1152921509977390464 |  dest_result_addr=1152921509977390472
        // 0x00D86638: STP x29, x30, [sp, #0x60]  | stack[1152921509977390480] = ???;  stack[1152921509977390488] = ???;  //  dest_result_addr=1152921509977390480 |  dest_result_addr=1152921509977390488
        // 0x00D8663C: ADD x29, sp, #0x60         | X29 = (1152921509977390384 + 96) = 1152921509977390480 (0x10000001401BFD90);
        // 0x00D86640: SUB sp, sp, #0x20          | SP = (1152921509977390384 - 32) = 1152921509977390352 (0x10000001401BFD10);
        // 0x00D86644: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D86648: LDRB w8, [x20, #0x441]     | W8 = (bool)static_value_03734441;       
        // 0x00D8664C: MOV x19, x0                | X19 = 1152921509977402496 (0x10000001401C2C80);//ML01
        // 0x00D86650: TBNZ w8, #0, #0xd8666c     | if (static_value_03734441 == true) goto label_0;
        // 0x00D86654: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00D86658: LDR x8, [x8, #0x550]       | X8 = 0x2B91718;                         
        // 0x00D8665C: LDR w0, [x8]               | W0 = 0x1C8B;                            
        // 0x00D86660: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C8B, ????);     
        // 0x00D86664: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D86668: STRB w8, [x20, #0x441]     | static_value_03734441 = true;            //  dest_result_addr=57885761
        label_0:
        // 0x00D8666C: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
        // 0x00D86670: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00D86674: ADRP x23, #0x363f000       | X23 = 56881152 (0x363F000);             
        // 0x00D86678: STR xzr, [sp, #0x18]       | stack[1152921509977390376] = 0x0;        //  dest_result_addr=1152921509977390376
        // 0x00D8667C: LDR s11, [x8, #0x450]      | S11 = 0.45;                             
        // 0x00D86680: LDR s12, [x9, #0x768]      | S12 = 1.2;                              
        // 0x00D86684: STR xzr, [sp, #0x10]       | stack[1152921509977390368] = 0x0;        //  dest_result_addr=1152921509977390368
        // 0x00D86688: LDR x23, [x23, #0x3b0]     | X23 = 1152921504695345152;              
        // 0x00D8668C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_8 = 0;
        // 0x00D86690: ORR w22, wzr, #0xc         | W22 = 12(0xC);                          
        // 0x00D86694: B #0xd866a8                |  goto label_1;                          
        goto label_1;
        label_11:
        // 0x00D86698: LDR q0, [sp]               | Q0 = val_1;                              //  find_add[1152921509977378496]
        // 0x00D8669C: ADD x8, x20, x24, lsl #4   | X8 = (57884672 + (X24) << 4);           
        var val_2 = 57884672 + ((X24) << 4);
        // 0x00D866A0: ADD w21, w21, #1           | W21 = (val_8 + 1) = val_8 (0x00000001); 
        val_8 = 1;
        // 0x00D866A4: STR q0, [x8, #0x20]        | mem2[0] = val_1;                         //  dest_result_addr=0
        mem2[0] = val_1;
        label_1:
        // 0x00D866A8: LDR x20, [x19, #0x20]      | X20 = this.meshColors; //P2             
        // 0x00D866AC: CBNZ x20, #0xd866b4        | if (this.meshColors != null) goto label_2;
        if(this.meshColors != null)
        {
            goto label_2;
        }
        // 0x00D866B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C8B, ????);     
        label_2:
        // 0x00D866B4: LDR w8, [x20, #0x18]       | W8 = this.meshColors.Length; //P2       
        // 0x00D866B8: LDR x20, [x19, #0x18]      | X20 = this.mesh; //P2                   
        // 0x00D866BC: CMP w21, w8                | STATE = COMPARE(0x1, this.meshColors.Length)
        // 0x00D866C0: B.GE #0xd867c4             | if (val_8 >= this.meshColors.Length) goto label_3;
        if(val_8 >= this.meshColors.Length)
        {
            goto label_3;
        }
        // 0x00D866C4: CBNZ x20, #0xd866cc        | if (this.mesh != null) goto label_4;    
        if(this.mesh != null)
        {
            goto label_4;
        }
        // 0x00D866C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C8B, ????);     
        label_4:
        // 0x00D866CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D866D0: MOV x0, x20                | X0 = this.mesh;//m1                     
        // 0x00D866D4: BL #0x1b749b8              | X0 = this.mesh.get_vertices();          
        UnityEngine.Vector3[] val_3 = this.mesh.vertices;
        // 0x00D866D8: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00D866DC: CBNZ x20, #0xd866e4        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00D866E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00D866E4: LDR w8, [x20, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00D866E8: SXTW x24, w21              | X24 = 1 (0x00000001);                   
        // 0x00D866EC: CMP w21, w8                | STATE = COMPARE(0x1, val_3.Length)      
        // 0x00D866F0: B.LO #0xd86700             | if (val_8 < val_3.Length) goto label_6; 
        if(val_8 < val_3.Length)
        {
            goto label_6;
        }
        // 0x00D866F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00D866F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D866FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_6:
        // 0x00D86700: MADD x8, x24, x22, x20     | X8 = (1 * 12) + val_3;                  
        var val_4 = val_3 + (1 * 12);
        // 0x00D86704: ADD x0, x8, #0x20          | X0 = ((1 * 12) + val_3 + 32);           
        val_3 = val_4 + 32;
        // 0x00D86708: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8670C: BL #0x2699080              | X0 = label_UnityEngine_Vector3_MoveTowards_GL02699080();
        // 0x00D86710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D86714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86718: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
        // 0x00D8671C: BL #0x2690b5c              | X0 = UnityEngine.Time.get_timeSinceLevelLoad();
        float val_5 = UnityEngine.Time.timeSinceLevelLoad;
        // 0x00D86720: LDR x0, [x23]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D86724: MOV v9.16b, v0.16b         | V9 = val_5;//m1                         
        // 0x00D86728: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D8672C: TBZ w8, #0, #0xd8673c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00D86730: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D86734: CBNZ w8, #0xd8673c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00D86738: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_8:
        // 0x00D8673C: FADD s0, s8, s9            | S0 = (val_1 + val_5);                   
        val_5 = val_1 + val_5;
        // 0x00D86740: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00D86744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D86748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8674C: FABS s9, s0                | S9 = System.Math.Abs((val_1 + val_5));  
        float val_8 = System.Math.Abs(val_5);
        // 0x00D86750: BL #0x2690b5c              | X0 = UnityEngine.Time.get_timeSinceLevelLoad();
        float val_6 = UnityEngine.Time.timeSinceLevelLoad;
        // 0x00D86754: FMUL s0, s0, s11           | S0 = (val_6 * 0.45f);                   
        val_6 = val_6 * 0.45f;
        // 0x00D86758: FADD s0, s8, s0            | S0 = (val_1 + (val_6 * 0.45f));         
        val_6 = val_1 + val_6;
        // 0x00D8675C: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
        // 0x00D86760: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D86764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86768: FABS s10, s0               | S10 = System.Math.Abs((val_1 + (val_6 * 0.45f)));
        float val_9 = System.Math.Abs(val_6);
        // 0x00D8676C: BL #0x2690b5c              | X0 = UnityEngine.Time.get_timeSinceLevelLoad();
        float val_7 = UnityEngine.Time.timeSinceLevelLoad;
        // 0x00D86770: FMUL s0, s0, s12           | S0 = (val_7 * 1.2f);                    
        val_7 = val_7 * 1.2f;
        // 0x00D86774: FADD s0, s8, s0            | S0 = (val_1 + (val_7 * 1.2f));          
        val_7 = val_1 + val_7;
        // 0x00D86778: BL #0x9811b0               | X0 = sub_9811B0( ?? 0x0, ????);         
        // 0x00D8677C: FABS s2, s0                | S2 = System.Math.Abs((val_1 + (val_7 * 1.2f)));
        float val_10 = System.Math.Abs(val_7);
        // 0x00D86780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D86784: ADD x0, sp, #0x10          | X0 = (1152921509977390352 + 16) = 1152921509977390368 (0x10000001401BFD20);
        // 0x00D86788: MOV v0.16b, v9.16b         | V0 = (val_1 + val_5);//m1               
        // 0x00D8678C: MOV v1.16b, v10.16b        | V1 = (val_1 + (val_6 * 0.45f));//m1     
        // 0x00D86790: BL #0x20d3368              | X0 = label_UnityEngine_Color__ctor_GL020D3368();
        // 0x00D86794: LDR x20, [x19, #0x20]      | X20 = this.meshColors; //P2             
        // 0x00D86798: CBNZ x20, #0xd867a0        | if (this.meshColors != null) goto label_9;
        if(this.meshColors != null)
        {
            goto label_9;
        }
        // 0x00D8679C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001401BFD20, ????);
        label_9:
        // 0x00D867A0: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
        // 0x00D867A4: STR q0, [sp]               | val_1 = 0x0;                             //  dest_result_addr=1152921509977390352
        val_1 = 0;
        // 0x00D867A8: LDR w8, [x20, #0x18]       | W8 = this.meshColors.Length; //P2       
        // 0x00D867AC: CMP w21, w8                | STATE = COMPARE(0x1, this.meshColors.Length)
        // 0x00D867B0: B.LO #0xd86698             | if (val_8 < this.meshColors.Length) goto label_11;
        if(val_8 < this.meshColors.Length)
        {
            goto label_11;
        }
        // 0x00D867B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000001401BFD20, ????);
        // 0x00D867B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D867BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000001401BFD20, ????);
        // 0x00D867C0: B #0xd86698                |  goto label_11;                         
        goto label_11;
        label_3:
        // 0x00D867C4: LDR x19, [x19, #0x20]      | X19 = this.meshColors; //P2             
        // 0x00D867C8: CBNZ x20, #0xd867d0        | if (this.mesh != null) goto label_12;   
        if(this.mesh != null)
        {
            goto label_12;
        }
        // 0x00D867CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C8B, ????);     
        label_12:
        // 0x00D867D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D867D4: MOV x0, x20                | X0 = this.mesh;//m1                     
        // 0x00D867D8: MOV x1, x19                | X1 = this.meshColors;//m1               
        // 0x00D867DC: BL #0x1b74f14              | this.mesh.set_colors(value:  this.meshColors);
        this.mesh.colors = this.meshColors;
        // 0x00D867E0: SUB sp, x29, #0x60         | SP = (1152921509977390480 - 96) = 1152921509977390384 (0x10000001401BFD30);
        // 0x00D867E4: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00D867E8: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00D867EC: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00D867F0: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00D867F4: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00D867F8: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00D867FC: LDP d13, d12, [sp], #0x70  | D13 = ; D12 = ;                          //  | 
        // 0x00D86800: RET                        |  return;                                
        return;
    
    }

}
