using UnityEngine;

namespace Iteedee.ApkReader
{
    public class APKManifest
    {
        // Fields
        private string result; //  0x00000010
        private bool isUtf8; //  0x00000018
        public static int startDocTag; // static_offset: 0x00000000
        public static int endDocTag; // static_offset: 0x00000004
        public static int startTag; // static_offset: 0x00000008
        public static int endTag; // static_offset: 0x0000000C
        public static int textTag; // static_offset: 0x00000010
        public static string spaces; // static_offset: 0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x017B8588 (24872328), len: 120  VirtAddr: 0x017B8588 RVA: 0x017B8588 token: 100684408 methodIndex: 45978 delegateWrapperIndex: 0 methodInvoker: 0
        public APKManifest()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x017B8588: STP x20, x19, [sp, #-0x20]! | stack[1152921513630676592] = ???;  stack[1152921513630676600] = ???;  //  dest_result_addr=1152921513630676592 |  dest_result_addr=1152921513630676600
            // 0x017B858C: STP x29, x30, [sp, #0x10]  | stack[1152921513630676608] = ???;  stack[1152921513630676616] = ???;  //  dest_result_addr=1152921513630676608 |  dest_result_addr=1152921513630676616
            // 0x017B8590: ADD x29, sp, #0x10         | X29 = (1152921513630676592 + 16) = 1152921513630676608 (0x1000000219DCB680);
            // 0x017B8594: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017B8598: LDRB w8, [x20, #0x94e]     | W8 = (bool)static_value_0373894E;       
            // 0x017B859C: MOV x19, x0                | X19 = 1152921513630688624 (0x1000000219DCE570);//ML01
            // 0x017B85A0: TBNZ w8, #0, #0x17b85bc    | if (static_value_0373894E == true) goto label_0;
            // 0x017B85A4: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x017B85A8: LDR x8, [x8, #0xd8]        | X8 = 0x2B8B000;                         
            // 0x017B85AC: LDR w0, [x8]               | W0 = 0x2BE;                             
            // 0x017B85B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2BE, ????);      
            // 0x017B85B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B85B8: STRB w8, [x20, #0x94e]     | static_value_0373894E = true;            //  dest_result_addr=57903438
            label_0:
            // 0x017B85BC: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
            // 0x017B85C0: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
            // 0x017B85C4: LDR x0, [x20]              | X0 = typeof(System.String);             
            val_1 = null;
            // 0x017B85C8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017B85CC: TBZ w8, #0, #0x17b85e0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x017B85D0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B85D4: CBNZ w8, #0x17b85e0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x017B85D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017B85DC: LDR x0, [x20]              | X0 = typeof(System.String);             
            val_1 = null;
            label_2:
            // 0x017B85E0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017B85E4: MOV x0, x19                | X0 = 1152921513630688624 (0x1000000219DCE570);//ML01
            // 0x017B85E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B85EC: LDR x8, [x8]               | X8 = System.String.Empty;               
            // 0x017B85F0: STR x8, [x19, #0x10]       | this.result = System.String.Empty;       //  dest_result_addr=1152921513630688640
            this.result = System.String.Empty;
            // 0x017B85F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B85F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B85FC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B8600 (24872448), len: 2440  VirtAddr: 0x017B8600 RVA: 0x017B8600 token: 100684409 methodIndex: 45979 delegateWrapperIndex: 0 methodInvoker: 0
        public string ReadManifestFileIntoXml(byte[] manifestFileData)
        {
            //
            // Disasemble & Code
            //  | 
            int val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            int val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            // 0x017B8600: STP x28, x27, [sp, #-0x60]! | stack[1152921513630876528] = ???;  stack[1152921513630876536] = ???;  //  dest_result_addr=1152921513630876528 |  dest_result_addr=1152921513630876536
            // 0x017B8604: STP x26, x25, [sp, #0x10]  | stack[1152921513630876544] = ???;  stack[1152921513630876552] = ???;  //  dest_result_addr=1152921513630876544 |  dest_result_addr=1152921513630876552
            // 0x017B8608: STP x24, x23, [sp, #0x20]  | stack[1152921513630876560] = ???;  stack[1152921513630876568] = ???;  //  dest_result_addr=1152921513630876560 |  dest_result_addr=1152921513630876568
            // 0x017B860C: STP x22, x21, [sp, #0x30]  | stack[1152921513630876576] = ???;  stack[1152921513630876584] = ???;  //  dest_result_addr=1152921513630876576 |  dest_result_addr=1152921513630876584
            // 0x017B8610: STP x20, x19, [sp, #0x40]  | stack[1152921513630876592] = ???;  stack[1152921513630876600] = ???;  //  dest_result_addr=1152921513630876592 |  dest_result_addr=1152921513630876600
            // 0x017B8614: STP x29, x30, [sp, #0x50]  | stack[1152921513630876608] = ???;  stack[1152921513630876616] = ???;  //  dest_result_addr=1152921513630876608 |  dest_result_addr=1152921513630876616
            // 0x017B8618: ADD x29, sp, #0x50         | X29 = (1152921513630876528 + 80) = 1152921513630876608 (0x1000000219DFC3C0);
            // 0x017B861C: SUB sp, sp, #0x30          | SP = (1152921513630876528 - 48) = 1152921513630876480 (0x1000000219DFC340);
            // 0x017B8620: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017B8624: LDRB w8, [x19, #0x94f]     | W8 = (bool)static_value_0373894F;       
            // 0x017B8628: MOV x21, x1                | X21 = manifestFileData;//m1             
            // 0x017B862C: MOV x27, x0                | X27 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8630: TBNZ w8, #0, #0x17b864c    | if (static_value_0373894F == true) goto label_0;
            // 0x017B8634: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x017B8638: LDR x8, [x8, #0x930]       | X8 = 0x2B8B010;                         
            // 0x017B863C: LDR w0, [x8]               | W0 = 0x2C2;                             
            // 0x017B8640: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C2, ????);      
            // 0x017B8644: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B8648: STRB w8, [x19, #0x94f]     | static_value_0373894F = true;            //  dest_result_addr=57903439
            label_0:
            // 0x017B864C: STP wzr, wzr, [sp, #0x28]  | stack[1152921513630876520] = 0x0;  stack[1152921513630876524] = 0x0;  //  dest_result_addr=1152921513630876520 |  dest_result_addr=1152921513630876524
            // 0x017B8650: CBNZ x21, #0x17b8658       | if (manifestFileData != null) goto label_1;
            if(manifestFileData != null)
            {
                goto label_1;
            }
            // 0x017B8654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2C2, ????);      
            label_1:
            // 0x017B8658: LDR w8, [x21, #0x18]       | W8 = manifestFileData.Length; //P2      
            // 0x017B865C: CBZ w8, #0x17b8f6c         | if (manifestFileData.Length == 0) goto label_2;
            if(manifestFileData.Length == 0)
            {
                goto label_2;
            }
            // 0x017B8660: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x017B8664: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8668: BL #0x17b8f88              | X0 = this.LEW(arr:  manifestFileData, off:  16);
            int val_1 = this.LEW(arr:  manifestFileData, off:  16);
            // 0x017B866C: LSL w8, w0, #2             | W8 = (val_1 << 2);                      
            int val_2 = val_1 << 2;
            // 0x017B8670: ORR w2, wzr, #0xc          | W2 = 12(0xC);                           
            // 0x017B8674: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8678: ADD w19, w8, #0x24         | W19 = ((val_1 << 2) + 36);              
            int val_3 = val_2 + 36;
            // 0x017B867C: BL #0x17b8f88              | X0 = val_1.LEW(arr:  manifestFileData, off:  12);
            int val_4 = val_1.LEW(arr:  manifestFileData, off:  12);
            // 0x017B8680: ORR w2, wzr, #0x18         | W2 = 24(0x18);                          
            // 0x017B8684: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8688: MOV w23, w0                | W23 = val_4;//m1                        
            // 0x017B868C: BL #0x17b8f88              | X0 = val_4.LEW(arr:  manifestFileData, off:  24);
            int val_5 = val_4.LEW(arr:  manifestFileData, off:  24);
            // 0x017B8690: UBFX w8, w0, #8, #1        | W8 = (uint)((val_5>>8) & 0x1);          
            // 0x017B8694: STRB w8, [x27, #0x18]      | this.isUtf8 = (uint)((val_5>>8) & 0x1);  //  dest_result_addr=1152921513630888648
            this.isUtf8 = (uint)(val_5 >> 8) & 1;
            // 0x017B8698: ADRP x26, #0x35ff000       | X26 = 56619008 (0x35FF000);             
            // 0x017B869C: LDR x26, [x26, #0x7e8]     | X26 = 1152921504856580096;              
            // 0x017B86A0: MOV w20, w23               | W20 = val_4;//m1                        
            val_43 = val_4;
            // 0x017B86A4: B #0x17b86ac               |  goto label_3;                          
            goto label_3;
            label_8:
            // 0x017B86A8: ADD w20, w20, #4           | W20 = (val_4 + 4);                      
            val_43 = val_43 + 4;
            label_3:
            // 0x017B86AC: CBNZ x21, #0x17b86b4       | if (manifestFileData != null) goto label_4;
            if(manifestFileData != null)
            {
                goto label_4;
            }
            // 0x017B86B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x017B86B4: LDR w8, [x21, #0x18]       | W8 = manifestFileData.Length; //P2      
            int val_43 = manifestFileData.Length;
            // 0x017B86B8: SUB w8, w8, #4             | W8 = (manifestFileData.Length - 4);     
            val_43 = val_43 - 4;
            // 0x017B86BC: CMP w20, w8                | STATE = COMPARE((val_4 + 4), (manifestFileData.Length - 4))
            // 0x017B86C0: B.GE #0x17b8710            | if (val_43 >= manifestFileData.Length) goto label_5;
            if(val_43 >= val_43)
            {
                goto label_5;
            }
            // 0x017B86C4: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B86C8: MOV w2, w20                | W2 = (val_4 + 4);//m1                   
            // 0x017B86CC: BL #0x17b8f88              | X0 = val_5.LEW(arr:  manifestFileData, off:  val_43);
            int val_6 = val_5.LEW(arr:  manifestFileData, off:  val_43);
            // 0x017B86D0: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_44 = null;
            // 0x017B86D4: MOV w24, w0                | W24 = val_6;//m1                        
            // 0x017B86D8: LDRB w9, [x8, #0x10a]      | W9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B86DC: TBZ w9, #0, #0x17b86f4     | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x017B86E0: LDR w9, [x8, #0xbc]        | W9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B86E4: CBNZ w9, #0x17b86f4        | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x017B86E8: MOV x0, x8                 | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            // 0x017B86EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B86F0: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_44 = null;
            label_7:
            // 0x017B86F4: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B86F8: LDR w8, [x8, #8]           | W8 = Iteedee.ApkReader.APKManifest.startTag;
            // 0x017B86FC: CMP w24, w8                | STATE = COMPARE(val_6, Iteedee.ApkReader.APKManifest.startTag)
            // 0x017B8700: B.NE #0x17b86a8            | if (val_6 != Iteedee.ApkReader.APKManifest.startTag) goto label_8;
            if(val_6 != Iteedee.ApkReader.APKManifest.startTag)
            {
                goto label_8;
            }
            // 0x017B8704: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x017B8708: ORR w28, wzr, #1           | W28 = 1(0x1);                           
            // 0x017B870C: B #0x17b8d4c               |  goto label_11;                         
            goto label_11;
            label_5:
            // 0x017B8710: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x017B8714: ORR w28, wzr, #1           | W28 = 1(0x1);                           
            // 0x017B8718: MOV w20, w23               | W20 = val_4;//m1                        
            int val_44 = val_4;
            // 0x017B871C: B #0x17b8d4c               |  goto label_11;                         
            goto label_11;
            label_21:
            // 0x017B8720: ADD w28, w28, #1           | W28 = (1 + 1) = 2 (0x00000002);         
            // 0x017B8724: ADD w20, w20, #4           | W20 = (val_4 + 4);                      
            val_44 = val_44 + 4;
            // 0x017B8728: B #0x17b8d4c               |  goto label_11;                         
            goto label_11;
            label_69:
            // 0x017B872C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x017B8730: LDR x8, [x8, #0x358]       | X8 = (string**)(1152921509408419392)("<");
            // 0x017B8734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B8738: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x017B873C: MOV x2, x23                | X2 = val_4;//m1                         
            // 0x017B8740: LDR x1, [x8]               | X1 = "<";                               
            // 0x017B8744: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x017B8748: LDR x8, [x8, #0xb98]       | X8 = (string**)(1152921509408435936)(">");
            // 0x017B874C: MOV x3, x24                | X3 = X24;//m1                           
            // 0x017B8750: LDR x4, [x8]               | X4 = ">";                               
            // 0x017B8754: BL #0x18b0400              | X0 = System.String.Concat(str0:  0, str1:  "<", str2:  val_4, str3:  X24);
            string val_7 = System.String.Concat(str0:  0, str1:  "<", str2:  val_4, str3:  X24);
            // 0x017B8758: MOV x2, x0                 | X2 = val_7;//m1                         
            // 0x017B875C: MOV x0, x27                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8760: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x017B8764: BL #0x17b90c8              | this.prtIndent(indent:  0, str:  val_7);
            this.prtIndent(indent:  0, str:  val_7);
            // 0x017B8768: ADD w25, w25, #1           | W25 = (0 + 1) = 1 (0x00000001);         
            // 0x017B876C: B #0x17b88f4               |  goto label_71;                         
            goto label_71;
            label_34:
            // 0x017B8770: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8774: MOV w2, w20                | W2 = (val_4 + 4);//m1                   
            // 0x017B8778: BL #0x17b8f88              | X0 = this.LEW(arr:  manifestFileData, off:  val_4);
            int val_8 = this.LEW(arr:  manifestFileData, off:  val_44);
            // 0x017B877C: MOV w24, w0                | W24 = val_8;//m1                        
            // 0x017B8780: ADD w2, w20, #8            | W2 = ((val_4 + 4) + 8);                 
            int val_9 = val_44 + 8;
            // 0x017B8784: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8788: STR w24, [sp, #0x2c]       | stack[1152921513630876524] = val_8;      //  dest_result_addr=1152921513630876524
            // 0x017B878C: BL #0x17b8f88              | X0 = val_8.LEW(arr:  manifestFileData, off:  int val_9 = val_4 + 8);
            int val_10 = val_8.LEW(arr:  manifestFileData, off:  val_9);
            // 0x017B8790: ADD w2, w20, #0x10         | W2 = ((val_4 + 4) + 16);                
            int val_11 = val_44 + 16;
            // 0x017B8794: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8798: BL #0x17b8f88              | X0 = val_10.LEW(arr:  manifestFileData, off:  int val_11 = val_4 + 16);
            int val_12 = val_10.LEW(arr:  manifestFileData, off:  val_11);
            // 0x017B879C: ADD w2, w20, #0x14         | W2 = ((val_4 + 4) + 20);                
            int val_13 = val_44 + 20;
            // 0x017B87A0: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B87A4: BL #0x17b8f88              | X0 = val_12.LEW(arr:  manifestFileData, off:  int val_13 = val_4 + 20);
            int val_14 = val_12.LEW(arr:  manifestFileData, off:  val_13);
            // 0x017B87A8: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_45 = null;
            // 0x017B87AC: MOV w23, w0                | W23 = val_14;//m1                       
            // 0x017B87B0: LDRB w9, [x8, #0x10a]      | W9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B87B4: TBZ w9, #0, #0x17b87cc     | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x017B87B8: LDR w9, [x8, #0xbc]        | W9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B87BC: CBNZ w9, #0x17b87cc        | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x017B87C0: MOV x0, x8                 | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            val_46 = val_45;
            // 0x017B87C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B87C8: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_45 = null;
            label_14:
            // 0x017B87CC: LDR x9, [x8, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B87D0: LDR w10, [x9, #8]          | W10 = Iteedee.ApkReader.APKManifest.startTag;
            // 0x017B87D4: CMP w24, w10               | STATE = COMPARE(val_8, Iteedee.ApkReader.APKManifest.startTag)
            // 0x017B87D8: B.EQ #0x17b890c            | if (val_8 == Iteedee.ApkReader.APKManifest.startTag) goto label_15;
            if(val_8 == Iteedee.ApkReader.APKManifest.startTag)
            {
                goto label_15;
            }
            // 0x017B87DC: LDR w24, [sp, #0x2c]       | W24 = val_8;                            
            // 0x017B87E0: LDRB w10, [x8, #0x10a]     | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B87E4: TBZ w10, #0, #0x17b8800    | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x017B87E8: LDR w10, [x8, #0xbc]       | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B87EC: CBNZ w10, #0x17b8800       | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x017B87F0: MOV x0, x8                 | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            val_46 = val_45;
            // 0x017B87F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B87F8: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_45 = null;
            // 0x017B87FC: LDR x9, [x8, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            label_17:
            // 0x017B8800: LDR w10, [x9, #0xc]        | W10 = Iteedee.ApkReader.APKManifest.endTag;
            // 0x017B8804: CMP w24, w10               | STATE = COMPARE(val_8, Iteedee.ApkReader.APKManifest.endTag)
            // 0x017B8808: B.EQ #0x17b8968            | if (val_8 == Iteedee.ApkReader.APKManifest.endTag) goto label_18;
            if(val_8 == Iteedee.ApkReader.APKManifest.endTag)
            {
                goto label_18;
            }
            // 0x017B880C: LDR w23, [sp, #0x2c]       | W23 = val_8;                            
            // 0x017B8810: LDRB w10, [x8, #0x10a]     | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B8814: TBZ w10, #0, #0x17b8830    | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x017B8818: LDR w10, [x8, #0xbc]       | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B881C: CBNZ w10, #0x17b8830       | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x017B8820: MOV x0, x8                 | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            val_46 = val_45;
            // 0x017B8824: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B8828: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_45 = null;
            // 0x017B882C: LDR x9, [x8, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            label_20:
            // 0x017B8830: LDR w10, [x9]              | W10 = Iteedee.ApkReader.APKManifest.startDocTag;
            // 0x017B8834: CMP w23, w10               | STATE = COMPARE(val_8, Iteedee.ApkReader.APKManifest.startDocTag)
            // 0x017B8838: B.EQ #0x17b8720            | if (val_8 == Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields) goto label_21;
            // 0x017B883C: LDR w23, [sp, #0x2c]       | W23 = val_8;                            
            val_48 = val_8;
            // 0x017B8840: LDRB w10, [x8, #0x10a]     | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B8844: TBZ w10, #0, #0x17b8860    | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x017B8848: LDR w10, [x8, #0xbc]       | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B884C: CBNZ w10, #0x17b8860       | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x017B8850: MOV x0, x8                 | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            val_46 = val_45;
            // 0x017B8854: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B8858: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            val_45 = null;
            // 0x017B885C: LDR x9, [x8, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            label_23:
            // 0x017B8860: LDR w10, [x9, #4]          | W10 = Iteedee.ApkReader.APKManifest.endDocTag;
            // 0x017B8864: CMP w23, w10               | STATE = COMPARE(val_8, Iteedee.ApkReader.APKManifest.endDocTag)
            // 0x017B8868: B.EQ #0x17b8d44            | if (val_48 == Iteedee.ApkReader.APKManifest.endDocTag) goto label_24;
            if(val_48 == Iteedee.ApkReader.APKManifest.endDocTag)
            {
                goto label_24;
            }
            // 0x017B886C: LDR w23, [sp, #0x2c]       | W23 = val_8;                            
            val_48 = val_8;
            // 0x017B8870: LDRB w10, [x8, #0x10a]     | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B8874: TBZ w10, #0, #0x17b8890    | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x017B8878: LDR w10, [x8, #0xbc]       | W10 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B887C: CBNZ w10, #0x17b8890       | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x017B8880: MOV x0, x8                 | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            val_46 = val_45;
            // 0x017B8884: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B8888: LDR x8, [x26]              | X8 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B888C: LDR x9, [x8, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            label_26:
            // 0x017B8890: LDR w8, [x9, #0x10]        | W8 = Iteedee.ApkReader.APKManifest.textTag;
            // 0x017B8894: CMP w23, w8                | STATE = COMPARE(val_8, Iteedee.ApkReader.APKManifest.textTag)
            // 0x017B8898: B.NE #0x17b8d54            | if (val_48 != Iteedee.ApkReader.APKManifest.textTag) goto label_27;
            if(val_48 != Iteedee.ApkReader.APKManifest.textTag)
            {
                goto label_27;
            }
            // 0x017B889C: MOVN w23, #0               | W23 = 0 (0x0);//ML01                    
            val_48 = 0;
            label_32:
            // 0x017B88A0: CBNZ x21, #0x17b88a8       | if (manifestFileData != null) goto label_28;
            if(manifestFileData != null)
            {
                goto label_28;
            }
            // 0x017B88A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            label_28:
            // 0x017B88A8: LDR w8, [x21, #0x18]       | W8 = manifestFileData.Length; //P2      
            // 0x017B88AC: CMP w20, w8                | STATE = COMPARE((val_4 + 4), manifestFileData.Length)
            // 0x017B88B0: B.GE #0x17b88f4            | if (val_4 >= manifestFileData.Length) goto label_71;
            if(val_44 >= manifestFileData.Length)
            {
                goto label_71;
            }
            // 0x017B88B4: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B88B8: MOV w2, w20                | W2 = (val_4 + 4);//m1                   
            // 0x017B88BC: BL #0x17b8f88              | X0 = LEW(arr:  manifestFileData, off:  val_4);
            int val_15 = LEW(arr:  manifestFileData, off:  val_44);
            // 0x017B88C0: LDR w8, [x21, #0x18]       | W8 = manifestFileData.Length; //P2      
            // 0x017B88C4: ADD w20, w20, #4           | W20 = ((val_4 + 4) + 4);                
            val_44 = val_44 + 4;
            // 0x017B88C8: CMP w20, w8                | STATE = COMPARE(((val_4 + 4) + 4), manifestFileData.Length)
            // 0x017B88CC: B.GT #0x17b8f2c            | if (val_4 > manifestFileData.Length) goto label_30;
            if(val_44 > manifestFileData.Length)
            {
                goto label_30;
            }
            // 0x017B88D0: CMP w0, w23                | STATE = COMPARE(val_15, 0x0)            
            // 0x017B88D4: CSET w8, ne                | W8 = val_15 != val_48 ? 1 : 0;          
            var val_16 = (val_15 != val_48) ? 1 : 0;
            // 0x017B88D8: CCMP w23, w22, #0, eq      | 
            // 0x017B88DC: CSEL w9, wzr, w23, eq      | W9 = val_15 == val_48 ? 0 : val_48;     
            var val_17 = (val_15 == val_48) ? 0 : (val_48);
            // 0x017B88E0: CMN w23, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x017B88E4: MOV w23, w9                | W23 = val_15 == val_48 ? 0 : val_48;//m1
            // 0x017B88E8: B.EQ #0x17b88a0            | if (val_48 == 0x1) goto label_32;       
            if(val_48 == 1)
            {
                goto label_32;
            }
            // 0x017B88EC: MOV w23, w9                | W23 = val_15 == val_48 ? 0 : val_48;//m1
            val_48 = val_17;
            // 0x017B88F0: CBNZ w8, #0x17b88a0        | if (val_15 != val_48 ? 1 : 0 != 0) goto label_32;
            if(val_16 != 0)
            {
                goto label_32;
            }
            label_71:
            // 0x017B88F4: CBNZ x21, #0x17b88fc       | if (manifestFileData != null) goto label_33;
            if(manifestFileData != null)
            {
                goto label_33;
            }
            // 0x017B88F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_33:
            // 0x017B88FC: LDR w8, [x21, #0x18]       | W8 = manifestFileData.Length; //P2      
            // 0x017B8900: CMP w20, w8                | STATE = COMPARE(((val_4 + 4) + 4), manifestFileData.Length)
            // 0x017B8904: B.LT #0x17b8770            | if (val_4 < manifestFileData.Length) goto label_34;
            if(val_44 < manifestFileData.Length)
            {
                goto label_34;
            }
            // 0x017B8908: B #0x17b8f08               |  goto label_70;                         
            goto label_70;
            label_15:
            // 0x017B890C: ADD w2, w20, #0x18         | W2 = ((val_4 + 4) + 24);                
            int val_18 = val_44 + 24;
            // 0x017B8910: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8914: STR w25, [sp, #0x1c]       | stack[1152921513630876508] = 0x1;        //  dest_result_addr=1152921513630876508
            // 0x017B8918: BL #0x17b8f88              | X0 = LEW(arr:  manifestFileData, off:  int val_18 = val_4 + 24);
            int val_19 = LEW(arr:  manifestFileData, off:  val_18);
            // 0x017B891C: ADD w2, w20, #0x1c         | W2 = ((val_4 + 4) + 28);                
            int val_20 = val_44 + 28;
            // 0x017B8920: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8924: BL #0x17b8f88              | X0 = val_19.LEW(arr:  manifestFileData, off:  int val_20 = val_4 + 28);
            int val_21 = val_19.LEW(arr:  manifestFileData, off:  val_20);
            // 0x017B8928: MOV w25, w0                | W25 = val_21;//m1                       
            val_49 = val_21;
            // 0x017B892C: MOVZ w2, #0x24             | W2 = 36 (0x24);//ML01                   
            // 0x017B8930: MOV x0, x27                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8934: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8938: MOV w3, w19                | W3 = ((val_1 << 2) + 36);//m1           
            // 0x017B893C: MOV w4, w23                | W4 = val_14;//m1                        
            // 0x017B8940: ADD w20, w20, #0x24        | W20 = ((val_4 + 4) + 36);               
            val_44 = val_44 + 36;
            // 0x017B8944: BL #0x17b906c              | X0 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_14);
            string val_22 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_14);
            // 0x017B8948: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B894C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B8950: MOV x23, x0                | X23 = val_22;//m1                       
            // 0x017B8954: LDR x8, [x8]               | X8 = typeof(System.String);             
            val_51 = null;
            // 0x017B8958: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x017B895C: TBNZ w9, #0, #0x17b89ec    | if (System.String.__il2cppRuntimeField_has_cctor != 0) goto label_36;
            // 0x017B8960: STR w28, [sp, #0x18]       | stack[1152921513630876504] = 0x2;        //  dest_result_addr=1152921513630876504
            // 0x017B8964: B #0x17b8a0c               |  goto label_41;                         
            goto label_41;
            label_18:
            // 0x017B8968: MOVZ w2, #0x24             | W2 = 36 (0x24);//ML01                   
            // 0x017B896C: MOV x0, x27                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8970: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8974: MOV w3, w19                | W3 = ((val_1 << 2) + 36);//m1           
            // 0x017B8978: MOV w4, w23                | W4 = val_14;//m1                        
            // 0x017B897C: SUB w25, w25, #1           | W25 = (1 - 1) = 0 (0x00000000);         
            // 0x017B8980: ADD w20, w20, #0x18        | W20 = ((val_4 + 4) + 24);               
            val_44 = val_44 + 24;
            // 0x017B8984: BL #0x17b906c              | X0 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_14);
            string val_23 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_14);
            // 0x017B8988: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B898C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B8990: MOV x23, x0                | X23 = val_23;//m1                       
            // 0x017B8994: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x017B8998: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x017B899C: TBZ w9, #0, #0x17b89b0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_39;
            // 0x017B89A0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B89A4: CBNZ w9, #0x17b89b0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
            // 0x017B89A8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x017B89AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_39:
            // 0x017B89B0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017B89B4: LDR x8, [x8, #0x58]        | X8 = (string**)(1152921513630825776)("</");
            // 0x017B89B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B89BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x017B89C0: MOV x2, x23                | X2 = val_23;//m1                        
            // 0x017B89C4: LDR x1, [x8]               | X1 = "</";                              
            // 0x017B89C8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x017B89CC: LDR x8, [x8, #0xc78]       | X8 = (string**)(1152921513630825856)(">  \r\n");
            // 0x017B89D0: LDR x3, [x8]               | X3 = ">  \r\n";                         
            // 0x017B89D4: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "</", str2:  val_23);
            string val_24 = System.String.Concat(str0:  0, str1:  "</", str2:  val_23);
            // 0x017B89D8: MOV x2, x0                 | X2 = val_24;//m1                        
            // 0x017B89DC: MOV x0, x27                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B89E0: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
            // 0x017B89E4: BL #0x17b90c8              | this.prtIndent(indent:  0, str:  val_24);
            this.prtIndent(indent:  0, str:  val_24);
            // 0x017B89E8: B #0x17b88f4               |  goto label_71;                         
            goto label_71;
            label_36:
            // 0x017B89EC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B89F0: STR w28, [sp, #0x18]       | stack[1152921513630876504] = 0x2;        //  dest_result_addr=1152921513630876504
            // 0x017B89F4: CBNZ w9, #0x17b8a0c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x017B89F8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            val_50 = val_51;
            // 0x017B89FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017B8A00: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B8A04: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B8A08: LDR x8, [x8]               | X8 = typeof(System.String);             
            val_51 = null;
            label_41:
            // 0x017B8A0C: LDR x9, [x8, #0xa0]        | X9 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017B8A10: CMP w25, #1                | STATE = COMPARE(val_21, 0x1)            
            // 0x017B8A14: LDR x24, [x9]              | X24 = System.String.Empty;              
            // 0x017B8A18: B.LT #0x17b8d24            | if (val_49 < 1) goto label_42;          
            if(val_49 < 1)
            {
                goto label_42;
            }
            // 0x017B8A1C: MOVZ w8, #0x14             | W8 = 20 (0x14);//ML01                   
            // 0x017B8A20: STR x23, [sp, #0x10]       | stack[1152921513630876496] = val_22;     //  dest_result_addr=1152921513630876496
            // 0x017B8A24: MOV w26, w19               | W26 = ((val_1 << 2) + 36);//m1          
            // 0x017B8A28: MOV x19, x27               | X19 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8A2C: MUL w8, w25, w8            | W8 = (val_21 * 20);                     
            int val_25 = val_49 * 20;
            // 0x017B8A30: MOV w23, w20               | W23 = ((val_4 + 4) + 36);//m1           
            // 0x017B8A34: STR w8, [sp, #0xc]         | stack[1152921513630876492] = (val_21 * 20);  //  dest_result_addr=1152921513630876492
            label_66:
            // 0x017B8A38: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8A3C: MOV w2, w23                | W2 = ((val_4 + 4) + 36);//m1            
            // 0x017B8A40: BL #0x17b8f88              | X0 = LEW(arr:  manifestFileData, off:  val_4);
            int val_26 = LEW(arr:  manifestFileData, off:  val_44);
            // 0x017B8A44: ADD w2, w23, #4            | W2 = (((val_4 + 4) + 36) + 4);          
            int val_27 = val_44 + 4;
            // 0x017B8A48: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8A4C: BL #0x17b8f88              | X0 = val_26.LEW(arr:  manifestFileData, off:  int val_27 = val_4 + 4);
            int val_28 = val_26.LEW(arr:  manifestFileData, off:  val_27);
            // 0x017B8A50: ADD w2, w23, #8            | W2 = (((val_4 + 4) + 36) + 8);          
            int val_29 = val_44 + 8;
            // 0x017B8A54: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8A58: MOV w28, w0                | W28 = val_28;//m1                       
            // 0x017B8A5C: BL #0x17b8f88              | X0 = val_28.LEW(arr:  manifestFileData, off:  int val_29 = val_4 + 8);
            int val_30 = val_28.LEW(arr:  manifestFileData, off:  val_29);
            // 0x017B8A60: ADD w2, w23, #0xc          | W2 = (((val_4 + 4) + 36) + 12);         
            int val_31 = val_44 + 12;
            // 0x017B8A64: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8A68: MOV w27, w0                | W27 = val_30;//m1                       
            // 0x017B8A6C: BL #0x17b8f88              | X0 = val_30.LEW(arr:  manifestFileData, off:  int val_31 = val_4 + 12);
            int val_32 = val_30.LEW(arr:  manifestFileData, off:  val_31);
            // 0x017B8A70: ADD w2, w23, #0x10         | W2 = (((val_4 + 4) + 36) + 16);         
            int val_33 = val_44 + 16;
            // 0x017B8A74: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8A78: STR w2, [sp, #0x20]        | stack[1152921513630876512] = (((val_4 + 4) + 36) + 16);  //  dest_result_addr=1152921513630876512
            // 0x017B8A7C: BL #0x17b8f88              | X0 = val_32.LEW(arr:  manifestFileData, off:  int val_33 = val_4 + 16);
            int val_34 = val_32.LEW(arr:  manifestFileData, off:  val_33);
            // 0x017B8A80: STR w0, [sp, #0x28]        | stack[1152921513630876520] = val_34;     //  dest_result_addr=1152921513630876520
            // 0x017B8A84: MOVZ w2, #0x24             | W2 = 36 (0x24);//ML01                   
            // 0x017B8A88: MOV x0, x19                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8A8C: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8A90: MOV w3, w26                | W3 = ((val_1 << 2) + 36);//m1           
            // 0x017B8A94: MOV w4, w28                | W4 = val_28;//m1                        
            // 0x017B8A98: BL #0x17b906c              | X0 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_28);
            string val_35 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_28);
            // 0x017B8A9C: MOV x23, x0                | X23 = val_35;//m1                       
            // 0x017B8AA0: CMN w27, #1                | STATE = COMPARE(val_30, 0x1)            
            // 0x017B8AA4: B.EQ #0x17b8ac4            | if (val_30 == 1) goto label_43;         
            if(val_30 == 1)
            {
                goto label_43;
            }
            // 0x017B8AA8: MOVZ w2, #0x24             | W2 = 36 (0x24);//ML01                   
            // 0x017B8AAC: MOV x0, x19                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8AB0: MOV x1, x21                | X1 = manifestFileData;//m1              
            // 0x017B8AB4: MOV w3, w26                | W3 = ((val_1 << 2) + 36);//m1           
            // 0x017B8AB8: MOV w4, w27                | W4 = val_30;//m1                        
            // 0x017B8ABC: BL #0x17b906c              | X0 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_30);
            string val_36 = this.compXmlString(xml:  manifestFileData, sitOff:  36, stOff:  val_3, strInd:  val_30);
            // 0x017B8AC0: B #0x17b8ad0               |  goto label_44;                         
            goto label_44;
            label_43:
            // 0x017B8AC4: ADD x0, sp, #0x28          | X0 = (1152921513630876480 + 40) = 1152921513630876520 (0x1000000219DFC368);
            // 0x017B8AC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8ACC: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
            label_44:
            // 0x017B8AD0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x017B8AD4: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
            // 0x017B8AD8: MOV x28, x0                | X28 = 1152921513630876520 (0x1000000219DFC368);//ML01
            // 0x017B8ADC: LDR x27, [x8]              | X27 = typeof(System.String[]);          
            // 0x017B8AE0: MOV x0, x27                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B8AE4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x017B8AE8: ORR w1, wzr, #6            | W1 = 6(0x6);                            
            // 0x017B8AEC: MOV x0, x27                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B8AF0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x017B8AF4: MOV x27, x0                | X27 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B8AF8: CBNZ x27, #0x17b8b00       | if ( != null) goto label_45;            
            if(null != null)
            {
                goto label_45;
            }
            // 0x017B8AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_45:
            // 0x017B8B00: CBZ x24, #0x17b8b24        | if (System.String.Empty == null) goto label_47;
            if(System.String.Empty == null)
            {
                goto label_47;
            }
            // 0x017B8B04: LDR x8, [x27]              | X8 = ;                                  
            // 0x017B8B08: MOV x0, x24                | X0 = System.String.Empty;//m1           
            // 0x017B8B0C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8B10: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x017B8B14: CBNZ x0, #0x17b8b24        | if (System.String.Empty != null) goto label_47;
            if(System.String.Empty != null)
            {
                goto label_47;
            }
            // 0x017B8B18: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x017B8B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8B20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_47:
            // 0x017B8B24: LDR w8, [x27, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B8B28: CBNZ w8, #0x17b8b38        | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_48;
            // 0x017B8B2C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x017B8B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8B34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_48:
            // 0x017B8B38: STR x24, [x27, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = System.String.Empty;  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = System.String.Empty;
            // 0x017B8B3C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x017B8B40: LDR x8, [x8, #0x770]       | X8 = (string**)(1152921509470674944)(" ");
            // 0x017B8B44: LDR x0, [x8]               | X0 = " ";                               
            // 0x017B8B48: CBZ x0, #0x17b8b68         | if (" " == null) goto label_50;         
            // 0x017B8B4C: LDR x8, [x27]              | X8 = ;                                  
            // 0x017B8B50: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8B54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " ", ????);        
            // 0x017B8B58: CBNZ x0, #0x17b8b68        | if (" " != null) goto label_50;         
            if(" " != null)
            {
                goto label_50;
            }
            // 0x017B8B5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " ", ????);        
            // 0x017B8B60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8B64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ", ????);        
            label_50:
            // 0x017B8B68: ADRP x9, #0x35f1000        | X9 = 56561664 (0x35F1000);              
            // 0x017B8B6C: LDR w8, [x27, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B8B70: LDR x9, [x9, #0x770]       | X9 = (string**)(1152921509470674944)(" ");
            // 0x017B8B74: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x017B8B78: LDR x24, [x9]              | X24 = " ";                              
            // 0x017B8B7C: B.HI #0x17b8b8c            | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_51;
            // 0x017B8B80: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " ", ????);        
            // 0x017B8B84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8B88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " ", ????);        
            label_51:
            // 0x017B8B8C: STR x24, [x27, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = " ";  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = " ";
            // 0x017B8B90: CBZ x23, #0x17b8bb4        | if (val_35 == null) goto label_53;      
            if(val_35 == null)
            {
                goto label_53;
            }
            // 0x017B8B94: LDR x8, [x27]              | X8 = ;                                  
            // 0x017B8B98: MOV x0, x23                | X0 = val_35;//m1                        
            // 0x017B8B9C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8BA0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_35, ????);     
            // 0x017B8BA4: CBNZ x0, #0x17b8bb4        | if (val_35 != null) goto label_53;      
            if(val_35 != null)
            {
                goto label_53;
            }
            // 0x017B8BA8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_35, ????);     
            // 0x017B8BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8BB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_53:
            // 0x017B8BB4: LDR w8, [x27, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B8BB8: CMP w8, #2                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x017B8BBC: B.HI #0x17b8bcc            | if (System.String[].__il2cppRuntimeField_namespaze > 0x2) goto label_54;
            // 0x017B8BC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_35, ????);     
            // 0x017B8BC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8BC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_54:
            // 0x017B8BCC: STR x23, [x27, #0x30]      | typeof(System.String[]).__il2cppRuntimeField_30 = val_35;  //  dest_result_addr=1152921504948897216
            typeof(System.String[]).__il2cppRuntimeField_30 = val_35;
            // 0x017B8BD0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x017B8BD4: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921513630838240)("=\"");
            // 0x017B8BD8: LDR x0, [x8]               | X0 = "=\"";                             
            // 0x017B8BDC: CBZ x0, #0x17b8bfc         | if ("=\"" == null) goto label_56;       
            // 0x017B8BE0: LDR x8, [x27]              | X8 = ;                                  
            // 0x017B8BE4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8BE8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "=\"", ????);      
            // 0x017B8BEC: CBNZ x0, #0x17b8bfc        | if ("=\"" != null) goto label_56;       
            if(("=\"") != null)
            {
                goto label_56;
            }
            // 0x017B8BF0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "=\"", ????);      
            // 0x017B8BF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8BF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "=\"", ????);      
            label_56:
            // 0x017B8BFC: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x017B8C00: LDR w8, [x27, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B8C04: LDR x9, [x9, #0x558]       | X9 = (string**)(1152921513630838240)("=\"");
            // 0x017B8C08: CMP w8, #3                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x017B8C0C: LDR x23, [x9]              | X23 = "=\"";                            
            // 0x017B8C10: B.HI #0x17b8c20            | if (System.String[].__il2cppRuntimeField_namespaze > 0x3) goto label_57;
            // 0x017B8C14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "=\"", ????);      
            // 0x017B8C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8C1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "=\"", ????);      
            label_57:
            // 0x017B8C20: STR x23, [x27, #0x38]      | typeof(System.String[]).__il2cppRuntimeField_38 = "=\"";  //  dest_result_addr=1152921504948897224
            typeof(System.String[]).__il2cppRuntimeField_38 = "=\"";
            // 0x017B8C24: CBZ x28, #0x17b8c48        | if (val_34 == 0) goto label_59;         
            if(val_34 == 0)
            {
                goto label_59;
            }
            // 0x017B8C28: LDR x8, [x27]              | X8 = ;                                  
            // 0x017B8C2C: MOV x0, x28                | X0 = 1152921513630876520 (0x1000000219DFC368);//ML01
            // 0x017B8C30: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8C34: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000219DFC368, ????);
            // 0x017B8C38: CBNZ x0, #0x17b8c48        | if (val_34 != 0) goto label_59;         
            if(val_34 != 0)
            {
                goto label_59;
            }
            // 0x017B8C3C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000219DFC368, ????);
            // 0x017B8C40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8C44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000219DFC368, ????);
            label_59:
            // 0x017B8C48: LDR w8, [x27, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B8C4C: CMP w8, #4                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x017B8C50: B.HI #0x17b8c60            | if (System.String[].__il2cppRuntimeField_namespaze > 0x4) goto label_60;
            // 0x017B8C54: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000219DFC368, ????);
            // 0x017B8C58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8C5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000219DFC368, ????);
            label_60:
            // 0x017B8C60: STR x28, [x27, #0x40]      | typeof(System.String[]).__il2cppRuntimeField_40 = 0x1000000219DFC368;  //  dest_result_addr=1152921504948897232
            typeof(System.String[]).__il2cppRuntimeField_40 = ;
            // 0x017B8C64: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x017B8C68: LDR x8, [x8, #0x6a0]       | X8 = (string**)(1152921513630838320)("\"");
            // 0x017B8C6C: LDR x0, [x8]               | X0 = "\"";                              
            // 0x017B8C70: CBZ x0, #0x17b8c90         | if ("\"" == null) goto label_62;        
            // 0x017B8C74: LDR x8, [x27]              | X8 = ;                                  
            // 0x017B8C78: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8C7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "\"", ????);       
            // 0x017B8C80: CBNZ x0, #0x17b8c90        | if ("\"" != null) goto label_62;        
            if("\"" != null)
            {
                goto label_62;
            }
            // 0x017B8C84: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "\"", ????);       
            // 0x017B8C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8C8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\"", ????);       
            label_62:
            // 0x017B8C90: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x017B8C94: LDR w8, [x27, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B8C98: LDR x9, [x9, #0x6a0]       | X9 = (string**)(1152921513630838320)("\"");
            // 0x017B8C9C: CMP w8, #5                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x5)
            // 0x017B8CA0: LDR x23, [x9]              | X23 = "\"";                             
            // 0x017B8CA4: B.HI #0x17b8cb4            | if (System.String[].__il2cppRuntimeField_namespaze > 0x5) goto label_63;
            // 0x017B8CA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "\"", ????);       
            // 0x017B8CAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8CB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\"", ????);       
            label_63:
            // 0x017B8CB4: STR x23, [x27, #0x48]      | typeof(System.String[]).__il2cppRuntimeField_48 = "\"";  //  dest_result_addr=1152921504948897240
            typeof(System.String[]).__il2cppRuntimeField_48 = "\"";
            // 0x017B8CB8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B8CBC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B8CC0: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017B8CC4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017B8CC8: TBZ w8, #0, #0x17b8cd8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
            // 0x017B8CCC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B8CD0: CBNZ w8, #0x17b8cd8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
            // 0x017B8CD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_65:
            // 0x017B8CD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B8CDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8CE0: MOV x1, x27                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B8CE4: BL #0x18b0b80              | X0 = System.String.Concat(values:  0);  
            string val_37 = System.String.Concat(values:  0);
            // 0x017B8CE8: LDR w8, [sp, #0x20]        | W8 = (((val_4 + 4) + 36) + 16);         
            // 0x017B8CEC: MOV x24, x0                | X24 = val_37;//m1                       
            // 0x017B8CF0: SUB w25, w25, #1           | W25 = (val_21 - 1);                     
            val_49 = val_49 - 1;
            // 0x017B8CF4: ADD w23, w8, #4            | W23 = ((((val_4 + 4) + 36) + 16) + 4);  
            int val_38 = val_33 + 4;
            // 0x017B8CF8: CBNZ w25, #0x17b8a38       | if ((val_21 - 1) != 0) goto label_66;   
            if(val_49 != 0)
            {
                goto label_66;
            }
            // 0x017B8CFC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B8D00: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B8D04: LDR w9, [sp, #0xc]         | W9 = (val_21 * 20);                     
            // 0x017B8D08: MOV x27, x19               | X27 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8D0C: MOV w19, w26               | W19 = ((val_1 << 2) + 36);//m1          
            // 0x017B8D10: ADRP x26, #0x35ff000       | X26 = 56619008 (0x35FF000);             
            // 0x017B8D14: LDR x8, [x8]               | X8 = typeof(System.String);             
            val_51 = null;
            // 0x017B8D18: LDR x26, [x26, #0x7e8]     | X26 = 1152921504856580096;              
            // 0x017B8D1C: LDR x23, [sp, #0x10]       | X23 = val_22;                           
            // 0x017B8D20: ADD w20, w20, w9           | W20 = (((val_4 + 4) + 36) + (val_21 * 20));
            val_44 = val_44 + val_25;
            label_42:
            // 0x017B8D24: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x017B8D28: LDP w28, w25, [sp, #0x18]  | W28 = 0x2; W25 = 0x1;                    //  | 
            // 0x017B8D2C: TBZ w9, #0, #0x17b872c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_69;
            // 0x017B8D30: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B8D34: CBNZ w9, #0x17b872c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
            // 0x017B8D38: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x017B8D3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017B8D40: B #0x17b872c               |  goto label_69;                         
            goto label_69;
            label_24:
            // 0x017B8D44: SUB w28, w28, #1           | W28 = (2 - 1) = 1 (0x00000001);         
            // 0x017B8D48: CBZ w28, #0x17b8f08        | if (0x1 == 0) goto label_70;            
            if(1 == 0)
            {
                goto label_70;
            }
            label_11:
            // 0x017B8D4C: MOVN w22, #0               | W22 = 0 (0x0);//ML01                    
            // 0x017B8D50: B #0x17b88f4               |  goto label_71;                         
            goto label_71;
            label_27:
            // 0x017B8D54: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x017B8D58: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x017B8D5C: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x017B8D60: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x017B8D64: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x017B8D68: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x017B8D6C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x017B8D70: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x017B8D74: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x017B8D78: CBNZ x21, #0x17b8d80       | if ( != null) goto label_72;            
            if(null != null)
            {
                goto label_72;
            }
            // 0x017B8D7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_72:
            // 0x017B8D80: ADRP x19, #0x35b9000       | X19 = 56332288 (0x35B9000);             
            // 0x017B8D84: LDR x19, [x19, #0x190]     | X19 = (string**)(1152921513630842496)("  Unrecognized tag code \'");
            // 0x017B8D88: LDR x0, [x19]              | X0 = "  Unrecognized tag code \'";      
            // 0x017B8D8C: CBZ x0, #0x17b8dac         | if ("  Unrecognized tag code \'" == null) goto label_74;
            // 0x017B8D90: LDR x8, [x21]              | X8 = ;                                  
            // 0x017B8D94: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8D98: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "  Unrecognized tag code \'", ????);
            // 0x017B8D9C: CBNZ x0, #0x17b8dac        | if ("  Unrecognized tag code \'" != null) goto label_74;
            if("  Unrecognized tag code \'" != null)
            {
                goto label_74;
            }
            // 0x017B8DA0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "  Unrecognized tag code \'", ????);
            // 0x017B8DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8DA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "  Unrecognized tag code \'", ????);
            label_74:
            // 0x017B8DAC: LDR x19, [x19]             | X19 = "  Unrecognized tag code \'";     
            // 0x017B8DB0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x017B8DB4: CBNZ w8, #0x17b8dc4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_75;
            // 0x017B8DB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "  Unrecognized tag code \'", ????);
            // 0x017B8DBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8DC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "  Unrecognized tag code \'", ????);
            label_75:
            // 0x017B8DC4: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "  Unrecognized tag code \'";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "  Unrecognized tag code \'";
            // 0x017B8DC8: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x017B8DCC: LDR x8, [x8, #0xac8]       | X8 = (string**)(1152921513630842624)("X");
            // 0x017B8DD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8DD4: ADD x0, sp, #0x2c          | X0 = (1152921513630876480 + 44) = 1152921513630876524 (0x1000000219DFC36C);
            // 0x017B8DD8: LDR x1, [x8]               | X1 = "X";                               
            // 0x017B8DDC: BL #0x1e63df8              | X0 = val_8.ToString(format:  "X");      
            string val_39 = val_8.ToString(format:  "X");
            // 0x017B8DE0: MOV x22, x0                | X22 = val_39;//m1                       
            // 0x017B8DE4: CBZ x22, #0x17b8e08        | if (val_39 == null) goto label_77;      
            if(val_39 == null)
            {
                goto label_77;
            }
            // 0x017B8DE8: LDR x8, [x21]              | X8 = ;                                  
            // 0x017B8DEC: MOV x0, x22                | X0 = val_39;//m1                        
            // 0x017B8DF0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8DF4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_39, ????);     
            // 0x017B8DF8: CBNZ x0, #0x17b8e08        | if (val_39 != null) goto label_77;      
            if(val_39 != null)
            {
                goto label_77;
            }
            // 0x017B8DFC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_39, ????);     
            // 0x017B8E00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8E04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            label_77:
            // 0x017B8E08: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x017B8E0C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x017B8E10: B.HI #0x17b8e20            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_78;
            // 0x017B8E14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_39, ????);     
            // 0x017B8E18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8E1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            label_78:
            // 0x017B8E20: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_39;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_39;
            // 0x017B8E24: ADRP x19, #0x367b000       | X19 = 57126912 (0x367B000);             
            // 0x017B8E28: LDR x19, [x19, #0x840]     | X19 = (string**)(1152921513630846800)("\' at offset ");
            // 0x017B8E2C: LDR x0, [x19]              | X0 = "\' at offset ";                   
            // 0x017B8E30: CBZ x0, #0x17b8e50         | if ("\' at offset " == null) goto label_80;
            // 0x017B8E34: LDR x8, [x21]              | X8 = ;                                  
            // 0x017B8E38: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8E3C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "\' at offset ", ????);
            // 0x017B8E40: CBNZ x0, #0x17b8e50        | if ("\' at offset " != null) goto label_80;
            if("\' at offset " != null)
            {
                goto label_80;
            }
            // 0x017B8E44: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "\' at offset ", ????);
            // 0x017B8E48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8E4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\' at offset ", ????);
            label_80:
            // 0x017B8E50: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x017B8E54: LDR x19, [x19]             | X19 = "\' at offset ";                  
            // 0x017B8E58: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x017B8E5C: B.HI #0x17b8e6c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_81;
            // 0x017B8E60: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "\' at offset ", ????);
            // 0x017B8E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8E68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\' at offset ", ????);
            label_81:
            // 0x017B8E6C: STR x19, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "\' at offset ";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = "\' at offset ";
            // 0x017B8E70: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x017B8E74: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x017B8E78: ADD x1, sp, #0x24          | X1 = (1152921513630876480 + 36) = 1152921513630876516 (0x1000000219DFC364);
            // 0x017B8E7C: STR w20, [sp, #0x24]       | stack[1152921513630876516] = (val_4 + 4);  //  dest_result_addr=1152921513630876516
            // 0x017B8E80: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x017B8E84: BL #0x27bc028              | X0 = 1152921513630990256 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (val_4 + 4));
            // 0x017B8E88: MOV x20, x0                | X20 = 1152921513630990256 (0x1000000219E17FB0);//ML01
            // 0x017B8E8C: CBZ x20, #0x17b8eb0        | if ((val_4 + 4) == 0) goto label_83;    
            if(val_44 == 0)
            {
                goto label_83;
            }
            // 0x017B8E90: LDR x8, [x21]              | X8 = ;                                  
            // 0x017B8E94: MOV x0, x20                | X0 = 1152921513630990256 (0x1000000219E17FB0);//ML01
            // 0x017B8E98: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B8E9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (val_4 + 4), ????);
            // 0x017B8EA0: CBNZ x0, #0x17b8eb0        | if ((val_4 + 4) != 0) goto label_83;    
            if(val_44 != 0)
            {
                goto label_83;
            }
            // 0x017B8EA4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (val_4 + 4), ????);
            // 0x017B8EA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8EAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_4 + 4), ????);
            label_83:
            // 0x017B8EB0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x017B8EB4: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x017B8EB8: B.HI #0x17b8ec8            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_84;
            // 0x017B8EBC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (val_4 + 4), ????);
            // 0x017B8EC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8EC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_4 + 4), ????);
            label_84:
            // 0x017B8EC8: STR x20, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = (val_4 + 4); typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
            typeof(System.Object[]).__il2cppRuntimeField_38 = val_44;
            typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
            // 0x017B8ECC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B8ED0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B8ED4: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017B8ED8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017B8EDC: TBZ w8, #0, #0x17b8eec     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_86;
            // 0x017B8EE0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B8EE4: CBNZ w8, #0x17b8eec        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
            // 0x017B8EE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_86:
            // 0x017B8EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B8EF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8EF4: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x017B8EF8: BL #0x18b07f0              | X0 = System.String.Concat(args:  0);    
            string val_40 = System.String.Concat(args:  0);
            // 0x017B8EFC: MOV x1, x0                 | X1 = val_40;//m1                        
            // 0x017B8F00: MOV x0, x27                | X0 = 1152921513630888624 (0x1000000219DFF2B0);//ML01
            // 0x017B8F04: BL #0x17b91d0              | this.prt(p:  val_40);                   
            this.prt(p:  val_40);
            label_70:
            // 0x017B8F08: LDR x0, [x27, #0x10]       | X0 = this.result; //P2                  
            // 0x017B8F0C: SUB sp, x29, #0x50         | SP = (1152921513630876608 - 80) = 1152921513630876528 (0x1000000219DFC370);
            // 0x017B8F10: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x017B8F14: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x017B8F18: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x017B8F1C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x017B8F20: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x017B8F24: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x017B8F28: RET                        |  return (System.String)this.result;     
            return this.result;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_30:
            // 0x017B8F2C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017B8F30: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017B8F34: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_41 = null;
            // 0x017B8F38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017B8F3C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x017B8F40: LDR x8, [x8, #0x238]       | X8 = (string**)(1152921513630859184)("Sentinal not found before end of file");
            label_87:
            // 0x017B8F44: LDR x1, [x8]               | X1 = "Sentinal not found before end of file";
            // 0x017B8F48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8F4C: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017B8F50: BL #0x1c32b48              | .ctor(message:  "Sentinal not found before end of file");
            val_41 = new System.Exception(message:  "Sentinal not found before end of file");
            // 0x017B8F54: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x017B8F58: LDR x8, [x8, #0xa68]       | X8 = 1152921513630859328;               
            // 0x017B8F5C: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017B8F60: LDR x1, [x8]               | X1 = public System.String Iteedee.ApkReader.APKManifest::ReadManifestFileIntoXml(byte[] manifestFileData);
            // 0x017B8F64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017B8F68: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_42 = System.Collections.IEnumerable.GetEnumerator();
            label_2:
            // 0x017B8F6C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017B8F70: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017B8F74: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017B8F78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017B8F7C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x017B8F80: LDR x8, [x8, #0x4d8]       | X8 = (string**)(1152921513630864448)("Failed to read manifest data.  Byte array was empty");
            // 0x017B8F84: B #0x17b8f44               |  goto label_87;                         
            goto label_87;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B906C (24875116), len: 92  VirtAddr: 0x017B906C RVA: 0x017B906C token: 100684410 methodIndex: 45980 delegateWrapperIndex: 0 methodInvoker: 0
        public string compXmlString(byte[] xml, int sitOff, int stOff, int strInd)
        {
            //
            // Disasemble & Code
            // 0x017B906C: STP x22, x21, [sp, #-0x30]! | stack[1152921513631111456] = ???;  stack[1152921513631111464] = ???;  //  dest_result_addr=1152921513631111456 |  dest_result_addr=1152921513631111464
            // 0x017B9070: STP x20, x19, [sp, #0x10]  | stack[1152921513631111472] = ???;  stack[1152921513631111480] = ???;  //  dest_result_addr=1152921513631111472 |  dest_result_addr=1152921513631111480
            // 0x017B9074: STP x29, x30, [sp, #0x20]  | stack[1152921513631111488] = ???;  stack[1152921513631111496] = ???;  //  dest_result_addr=1152921513631111488 |  dest_result_addr=1152921513631111496
            // 0x017B9078: ADD x29, sp, #0x20         | X29 = (1152921513631111456 + 32) = 1152921513631111488 (0x1000000219E35940);
            // 0x017B907C: MOV w20, w3                | W20 = stOff;//m1                        
            // 0x017B9080: MOV x19, x1                | X19 = xml;//m1                          
            // 0x017B9084: MOV x21, x0                | X21 = 1152921513631123504 (0x1000000219E38830);//ML01
            // 0x017B9088: TBNZ w4, #0x1f, #0x17b90b4 | if ((strInd & 0x80000000) != 0) goto label_0;
            if((strInd & 2147483648) != 0)
            {
                goto label_0;
            }
            // 0x017B908C: ADD w2, w2, w4, lsl #2     | W2 = (sitOff + (strInd) << 2);          
            sitOff = sitOff + (strInd << 2);
            // 0x017B9090: MOV x1, x19                | X1 = xml;//m1                           
            // 0x017B9094: BL #0x17b8f88              | X0 = this.LEW(arr:  xml, off:  sitOff = sitOff + (strInd << 2));
            int val_1 = this.LEW(arr:  xml, off:  sitOff);
            // 0x017B9098: ADD w2, w0, w20            | W2 = (val_1 + stOff);                   
            sitOff = val_1 + stOff;
            // 0x017B909C: MOV x1, x19                | X1 = xml;//m1                           
            // 0x017B90A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B90A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B90A8: MOV x0, x21                | X0 = 1152921513631123504 (0x1000000219E38830);//ML01
            // 0x017B90AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B90B0: B #0x17b9258               | return this.compXmlStringAt(arr:  xml, strOff:  sitOff = val_1 + stOff);
            return this.compXmlStringAt(arr:  xml, strOff:  sitOff);
            label_0:
            // 0x017B90B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B90B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B90BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B90C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B90C4: RET                        |  return (System.String)null;            
            return (string)0;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B90C8 (24875208), len: 264  VirtAddr: 0x017B90C8 RVA: 0x017B90C8 token: 100684411 methodIndex: 45981 delegateWrapperIndex: 0 methodInvoker: 0
        public void prtIndent(int indent, string str)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            // 0x017B90C8: STP x22, x21, [sp, #-0x30]! | stack[1152921513631272608] = ???;  stack[1152921513631272616] = ???;  //  dest_result_addr=1152921513631272608 |  dest_result_addr=1152921513631272616
            // 0x017B90CC: STP x20, x19, [sp, #0x10]  | stack[1152921513631272624] = ???;  stack[1152921513631272632] = ???;  //  dest_result_addr=1152921513631272624 |  dest_result_addr=1152921513631272632
            // 0x017B90D0: STP x29, x30, [sp, #0x20]  | stack[1152921513631272640] = ???;  stack[1152921513631272648] = ???;  //  dest_result_addr=1152921513631272640 |  dest_result_addr=1152921513631272648
            // 0x017B90D4: ADD x29, sp, #0x20         | X29 = (1152921513631272608 + 32) = 1152921513631272640 (0x1000000219E5CEC0);
            // 0x017B90D8: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x017B90DC: LDRB w8, [x22, #0x950]     | W8 = (bool)static_value_03738950;       
            // 0x017B90E0: MOV x20, x2                | X20 = str;//m1                          
            // 0x017B90E4: MOV w21, w1                | W21 = indent;//m1                       
            // 0x017B90E8: MOV x19, x0                | X19 = 1152921513631284656 (0x1000000219E5FDB0);//ML01
            // 0x017B90EC: TBNZ w8, #0, #0x17b9108    | if (static_value_03738950 == true) goto label_0;
            // 0x017B90F0: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x017B90F4: LDR x8, [x8, #0x2c0]       | X8 = 0x2B8B00C;                         
            // 0x017B90F8: LDR w0, [x8]               | W0 = 0x2C1;                             
            // 0x017B90FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C1, ????);      
            // 0x017B9100: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9104: STRB w8, [x22, #0x950]     | static_value_03738950 = true;            //  dest_result_addr=57903440
            label_0:
            // 0x017B9108: ADRP x22, #0x35ff000       | X22 = 56619008 (0x35FF000);             
            // 0x017B910C: LDR x22, [x22, #0x7e8]     | X22 = 1152921504856580096;              
            // 0x017B9110: LDR x0, [x22]              | X0 = typeof(Iteedee.ApkReader.APKManifest);
            val_6 = null;
            // 0x017B9114: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_10A;
            // 0x017B9118: TBZ w8, #0, #0x17b912c     | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x017B911C: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished;
            // 0x017B9120: CBNZ w8, #0x17b912c        | if (Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x017B9124: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017B9128: LDR x0, [x22]              | X0 = typeof(Iteedee.ApkReader.APKManifest);
            val_6 = null;
            label_2:
            // 0x017B912C: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B9130: LDR x22, [x8, #0x18]       | X22 = Iteedee.ApkReader.APKManifest.spaces;
            // 0x017B9134: CBNZ x22, #0x17b913c       | if (Iteedee.ApkReader.APKManifest.spaces != null) goto label_3;
            if(Iteedee.ApkReader.APKManifest.spaces != null)
            {
                goto label_3;
            }
            // 0x017B9138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            label_3:
            // 0x017B913C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9140: MOV x0, x22                | X0 = Iteedee.ApkReader.APKManifest.spaces;//m1
            // 0x017B9144: BL #0x18a4460              | X0 = Iteedee.ApkReader.APKManifest.spaces.get_Length();
            int val_1 = Iteedee.ApkReader.APKManifest.spaces.Length;
            // 0x017B9148: MOV w2, w0                 | W2 = val_1;//m1                         
            // 0x017B914C: LSL w1, w21, #1            | W1 = (indent << 1);                     
            int val_2 = indent << 1;
            // 0x017B9150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B9154: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017B9158: BL #0x16f965c              | X0 = System.Math.Min(val1:  0, val2:  int val_2 = indent << 1);
            int val_3 = System.Math.Min(val1:  0, val2:  val_2);
            // 0x017B915C: MOV w21, w0                | W21 = val_3;//m1                        
            // 0x017B9160: CBNZ x22, #0x17b9168       | if (Iteedee.ApkReader.APKManifest.spaces != null) goto label_4;
            if(Iteedee.ApkReader.APKManifest.spaces != null)
            {
                goto label_4;
            }
            // 0x017B9164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_4:
            // 0x017B9168: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x017B916C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017B9170: MOV x0, x22                | X0 = Iteedee.ApkReader.APKManifest.spaces;//m1
            // 0x017B9174: MOV w2, w21                | W2 = val_3;//m1                         
            // 0x017B9178: BL #0x18a920c              | X0 = Iteedee.ApkReader.APKManifest.spaces.Substring(startIndex:  0, length:  val_3);
            string val_4 = Iteedee.ApkReader.APKManifest.spaces.Substring(startIndex:  0, length:  val_3);
            // 0x017B917C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B9180: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B9184: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x017B9188: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x017B918C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x017B9190: TBZ w9, #0, #0x17b91a4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x017B9194: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B9198: CBNZ w9, #0x17b91a4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x017B919C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x017B91A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_6:
            // 0x017B91A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B91A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017B91AC: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x017B91B0: MOV x2, x20                | X2 = str;//m1                           
            // 0x017B91B4: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_4);
            string val_5 = System.String.Concat(str0:  0, str1:  val_4);
            // 0x017B91B8: MOV x1, x0                 | X1 = val_5;//m1                         
            // 0x017B91BC: MOV x0, x19                | X0 = 1152921513631284656 (0x1000000219E5FDB0);//ML01
            // 0x017B91C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B91C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B91C8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B91CC: B #0x17b91d0               | this.prt(p:  val_5); return;            
            this.prt(p:  val_5);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B91D0 (24875472), len: 136  VirtAddr: 0x017B91D0 RVA: 0x017B91D0 token: 100684412 methodIndex: 45982 delegateWrapperIndex: 0 methodInvoker: 0
        private void prt(string p)
        {
            //
            // Disasemble & Code
            // 0x017B91D0: STP x22, x21, [sp, #-0x30]! | stack[1152921513631409184] = ???;  stack[1152921513631409192] = ???;  //  dest_result_addr=1152921513631409184 |  dest_result_addr=1152921513631409192
            // 0x017B91D4: STP x20, x19, [sp, #0x10]  | stack[1152921513631409200] = ???;  stack[1152921513631409208] = ???;  //  dest_result_addr=1152921513631409200 |  dest_result_addr=1152921513631409208
            // 0x017B91D8: STP x29, x30, [sp, #0x20]  | stack[1152921513631409216] = ???;  stack[1152921513631409224] = ???;  //  dest_result_addr=1152921513631409216 |  dest_result_addr=1152921513631409224
            // 0x017B91DC: ADD x29, sp, #0x20         | X29 = (1152921513631409184 + 32) = 1152921513631409216 (0x1000000219E7E440);
            // 0x017B91E0: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x017B91E4: LDRB w8, [x21, #0x951]     | W8 = (bool)static_value_03738951;       
            // 0x017B91E8: MOV x20, x1                | X20 = p;//m1                            
            // 0x017B91EC: MOV x19, x0                | X19 = 1152921513631421232 (0x1000000219E81330);//ML01
            // 0x017B91F0: TBNZ w8, #0, #0x17b920c    | if (static_value_03738951 == true) goto label_0;
            // 0x017B91F4: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x017B91F8: LDR x8, [x8, #0xa0]        | X8 = 0x2B8B008;                         
            // 0x017B91FC: LDR w0, [x8]               | W0 = 0x2C0;                             
            // 0x017B9200: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C0, ????);      
            // 0x017B9204: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9208: STRB w8, [x21, #0x951]     | static_value_03738951 = true;            //  dest_result_addr=57903441
            label_0:
            // 0x017B920C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017B9210: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017B9214: LDR x21, [x19, #0x10]      | X21 = this.result; //P2                 
            // 0x017B9218: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017B921C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017B9220: TBZ w8, #0, #0x17b9230     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x017B9224: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017B9228: CBNZ w8, #0x17b9230        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x017B922C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x017B9230: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B9234: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017B9238: MOV x1, x21                | X1 = this.result;//m1                   
            // 0x017B923C: MOV x2, x20                | X2 = p;//m1                             
            // 0x017B9240: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  this.result);
            string val_1 = System.String.Concat(str0:  0, str1:  this.result);
            // 0x017B9244: STR x0, [x19, #0x10]       | this.result = val_1;                     //  dest_result_addr=1152921513631421248
            this.result = val_1;
            // 0x017B9248: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B924C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9250: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B9254: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9258 (24875608), len: 476  VirtAddr: 0x017B9258 RVA: 0x017B9258 token: 100684413 methodIndex: 45983 delegateWrapperIndex: 0 methodInvoker: 0
        public string compXmlStringAt(byte[] arr, int strOff)
        {
            //
            // Disasemble & Code
            //  | 
            byte val_5;
            //  | 
            var val_6;
            // 0x017B9258: STP x26, x25, [sp, #-0x50]! | stack[1152921513631574480] = ???;  stack[1152921513631574488] = ???;  //  dest_result_addr=1152921513631574480 |  dest_result_addr=1152921513631574488
            // 0x017B925C: STP x24, x23, [sp, #0x10]  | stack[1152921513631574496] = ???;  stack[1152921513631574504] = ???;  //  dest_result_addr=1152921513631574496 |  dest_result_addr=1152921513631574504
            // 0x017B9260: STP x22, x21, [sp, #0x20]  | stack[1152921513631574512] = ???;  stack[1152921513631574520] = ???;  //  dest_result_addr=1152921513631574512 |  dest_result_addr=1152921513631574520
            // 0x017B9264: STP x20, x19, [sp, #0x30]  | stack[1152921513631574528] = ???;  stack[1152921513631574536] = ???;  //  dest_result_addr=1152921513631574528 |  dest_result_addr=1152921513631574536
            // 0x017B9268: STP x29, x30, [sp, #0x40]  | stack[1152921513631574544] = ???;  stack[1152921513631574552] = ???;  //  dest_result_addr=1152921513631574544 |  dest_result_addr=1152921513631574552
            // 0x017B926C: ADD x29, sp, #0x40         | X29 = (1152921513631574480 + 64) = 1152921513631574544 (0x1000000219EA6A10);
            // 0x017B9270: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x017B9274: LDRB w8, [x21, #0x952]     | W8 = (bool)static_value_03738952;       
            // 0x017B9278: MOV w22, w2                | W22 = strOff;//m1                       
            int val_7 = strOff;
            // 0x017B927C: MOV x19, x1                | X19 = arr;//m1                          
            // 0x017B9280: MOV x20, x0                | X20 = 1152921513631586560 (0x1000000219EA9900);//ML01
            // 0x017B9284: TBNZ w8, #0, #0x17b92a0    | if (static_value_03738952 == true) goto label_0;
            // 0x017B9288: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x017B928C: LDR x8, [x8, #0xc68]       | X8 = 0x2B8B004;                         
            // 0x017B9290: LDR w0, [x8]               | W0 = 0x2BF;                             
            // 0x017B9294: BL #0x2782188              | X0 = sub_2782188( ?? 0x2BF, ????);      
            // 0x017B9298: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B929C: STRB w8, [x21, #0x952]     | static_value_03738952 = true;            //  dest_result_addr=57903442
            label_0:
            // 0x017B92A0: CBNZ x19, #0x17b92a8       | if (arr != null) goto label_1;          
            if(arr != null)
            {
                goto label_1;
            }
            // 0x017B92A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2BF, ????);      
            label_1:
            // 0x017B92A8: LDR w8, [x19, #0x18]       | W8 = arr.Length; //P2                   
            // 0x017B92AC: SXTW x21, w22              | X21 = (long)(int)(strOff);              
            // 0x017B92B0: CMP w8, w22                | STATE = COMPARE(arr.Length, strOff)     
            // 0x017B92B4: B.HI #0x17b92c4            | if (arr.Length > strOff) goto label_2;  
            if(arr.Length > val_7)
            {
                goto label_2;
            }
            // 0x017B92B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x2BF, ????);      
            // 0x017B92BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B92C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x2BF, ????);      
            label_2:
            // 0x017B92C4: ADD x8, x19, x21           | X8 = arr[(long)(int)(strOff)]; //PARR1  
            // 0x017B92C8: LDRB w23, [x8, #0x20]      | W23 = arr[(long)(int)(strOff)][0]       
            val_5 = arr[(long)val_7];
            // 0x017B92CC: TBZ w23, #7, #0x17b9300    | if ((arr[(long)(int)(strOff)][0] & 0x80) == 0) goto label_3;
            if((val_5 & 128) == 0)
            {
                goto label_3;
            }
            // 0x017B92D0: LDR w8, [x19, #0x18]       | W8 = arr.Length; //P2                   
            // 0x017B92D4: ADD w9, w22, #1            | W9 = (strOff + 1);                      
            int val_1 = val_7 + 1;
            // 0x017B92D8: SXTW x21, w9               | X21 = (long)(int)((strOff + 1));        
            // 0x017B92DC: CMP w9, w8                 | STATE = COMPARE((strOff + 1), arr.Length)
            // 0x017B92E0: B.LO #0x17b92f0            | if (val_1 < arr.Length) goto label_4;   
            if(val_1 < arr.Length)
            {
                goto label_4;
            }
            // 0x017B92E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x2BF, ????);      
            // 0x017B92E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B92EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x2BF, ????);      
            label_4:
            // 0x017B92F0: ADD x8, x19, x21           | X8 = arr[(long)(int)((strOff + 1))]; //PARR1 
            // 0x017B92F4: LDRB w8, [x8, #0x20]       | W8 = arr[(long)(int)((strOff + 1))][0]  
            byte val_5 = arr[(long)val_1];
            // 0x017B92F8: BFI w8, w23, #8, #7        | W8 = arr[(long)(int)((strOff + 1))][0] | arr[(long)(int)(strOff)][0]
            // 0x017B92FC: MOV w23, w8                | W23 = arr[(long)(int)((strOff + 1))][0];//m1
            val_5 = val_5;
            label_3:
            // 0x017B9300: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x017B9304: LDRB w8, [x20, #0x18]      | W8 = this.isUtf8; //P2                  
            bool val_6 = this.isUtf8;
            // 0x017B9308: LDR x9, [x9, #0xf00]       | X9 = 1152921504996170800;               
            // 0x017B930C: EOR w8, w8, #1             | W8 = (this.isUtf8 ^ 1);                 
            val_6 = val_6 ^ 1;
            // 0x017B9310: LDR x21, [x9]              | X21 = typeof(System.Byte[]);            
            // 0x017B9314: AND x8, x8, #0xff          | X8 = ((this.isUtf8 ^ 1) & 255);         
            val_6 = val_6 & 255;
            // 0x017B9318: LSL w23, w23, w8           | W23 = (arr[(long)(int)((strOff + 1))][0] << ((this.isUtf8 ^ 1) & 255));
            val_6 = val_5 << val_6;
            // 0x017B931C: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017B9320: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x017B9324: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017B9328: MOV x1, x23                | X1 = (arr[(long)(int)((strOff + 1))][0] << ((this.isUtf8 ^ 1) & 255));//m1
            // 0x017B932C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x017B9330: MOV x21, x0                | X21 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017B9334: CMP w23, #1                | STATE = COMPARE((arr[(long)(int)((strOff + 1))][0] << ((this.isUtf8 ^ 1) & 255)), 0x1)
            // 0x017B9338: B.LT #0x17b93ac            | if (val_6 < 1) goto label_5;            
            if(val_6 < 1)
            {
                goto label_5;
            }
            // 0x017B933C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x017B9340: ADD w22, w22, #2           | W22 = (strOff + 2);                     
            val_7 = val_7 + 2;
            // 0x017B9344: ADD x25, x21, #0x20        | X25 = (null + 32) = 1152921504996170832 (0x1000000017349C50);
            // 0x017B9348: MOV w23, w23               | W23 = (arr[(long)(int)((strOff + 1))][0] << ((this.isUtf8 ^ 1) & 255));//m1
            val_6 = val_6;
            label_10:
            // 0x017B934C: CBNZ x19, #0x17b9354       | if (arr != null) goto label_6;          
            if(arr != null)
            {
                goto label_6;
            }
            // 0x017B9350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_6:
            // 0x017B9354: LDR w8, [x19, #0x18]       | W8 = arr.Length; //P2                   
            // 0x017B9358: ADD x9, x22, x24           | X9 = ((strOff + 2) + 0);                
            int val_2 = val_7 + val_9;
            // 0x017B935C: SXTW x26, w9               | X26 = (long)(int)(((strOff + 2) + 0));  
            // 0x017B9360: CMP w9, w8                 | STATE = COMPARE(((strOff + 2) + 0), arr.Length)
            // 0x017B9364: B.LO #0x17b9374            | if (val_2 < arr.Length) goto label_7;   
            if(val_2 < arr.Length)
            {
                goto label_7;
            }
            // 0x017B9368: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x017B936C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9370: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_7:
            // 0x017B9374: ADD x8, x19, x26           | X8 = arr[(long)(int)(((strOff + 2) + 0))]; //PARR1 
            // 0x017B9378: LDRB w26, [x8, #0x20]      | W26 = arr[(long)(int)(((strOff + 2) + 0))][0]
            byte val_8 = arr[(long)val_2];
            // 0x017B937C: CBNZ x21, #0x17b9384       | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x017B9380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_8:
            // 0x017B9384: LDR w8, [x21, #0x18]       | W8 = System.Byte[].__il2cppRuntimeField_namespaze;
            // 0x017B9388: CMP x24, x8                | STATE = COMPARE(0x0, System.Byte[].__il2cppRuntimeField_namespaze)
            // 0x017B938C: B.LO #0x17b939c            | if (0 < System.Byte[].__il2cppRuntimeField_namespaze) goto label_9;
            // 0x017B9390: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x017B9394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9398: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_9:
            // 0x017B939C: STRB w26, [x25, x24]       | System.Byte[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = arr[(long)(int)(((strOff + 2) + 0))][0];  //  dest_result_addr=1152921504996170832
            System.Byte[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_8;
            // 0x017B93A0: ADD x24, x24, #1           | X24 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x017B93A4: CMP w23, w24               | STATE = COMPARE((arr[(long)(int)((strOff + 1))][0] << ((this.isUtf8 ^ 1) & 255)), (0 + 1))
            // 0x017B93A8: B.NE #0x17b934c            | if (val_6 != 0) goto label_10;          
            if(val_6 != val_9)
            {
                goto label_10;
            }
            label_5:
            // 0x017B93AC: ADRP x9, #0x3669000        | X9 = 57053184 (0x3669000);              
            // 0x017B93B0: ADRP x10, #0x35e7000       | X10 = 56520704 (0x35E7000);             
            // 0x017B93B4: ADRP x11, #0x365a000       | X11 = 56991744 (0x365A000);             
            // 0x017B93B8: LDRB w8, [x20, #0x18]      | W8 = this.isUtf8; //P2                  
            // 0x017B93BC: LDR x9, [x9, #0x468]       | X9 = (string**)(1152921509632465920)("UTF-8");
            // 0x017B93C0: LDR x10, [x10, #0x568]     | X10 = (string**)(1152921513631558384)("UTF-16");
            // 0x017B93C4: LDR x11, [x11, #0xd48]     | X11 = 1152921504649285632;              
            // 0x017B93C8: CMP w8, #0                 | STATE = COMPARE(this.isUtf8, 0x0)       
            // 0x017B93CC: CSEL x8, x9, x10, ne       | X8 = this.isUtf8 == true ? "UTF-8" : "UTF-16";
            var val_3 = (this.isUtf8 == true) ? ("UTF-8") : ("UTF-16");
            // 0x017B93D0: LDR x0, [x11]              | X0 = typeof(System.Text.Encoding);      
            // 0x017B93D4: LDR x19, [x8]              | X19 = this.isUtf8 == true ? "UTF-8" : "UTF-16";
            // 0x017B93D8: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x017B93DC: TBZ w8, #0, #0x17b93ec     | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x017B93E0: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x017B93E4: CBNZ w8, #0x17b93ec        | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x017B93E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_12:
            // 0x017B93EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B93F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B93F4: MOV x1, x19                | X1 = this.isUtf8 == true ? "UTF-8" : "UTF-16";//m1
            // 0x017B93F8: BL #0x1b571f8              | X0 = System.Text.Encoding.GetEncoding(name:  0);
            System.Text.Encoding val_4 = System.Text.Encoding.GetEncoding(name:  0);
            // 0x017B93FC: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x017B9400: CBNZ x19, #0x17b9408       | if (val_4 != null) goto label_13;       
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x017B9404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x017B9408: LDR x8, [x19]              | X8 = typeof(System.Text.Encoding);      
            // 0x017B940C: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x017B9410: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x017B9414: LDR x3, [x8, #0x2c0]       | X3 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C0;
            // 0x017B9418: LDR x2, [x8, #0x2c8]       | X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_2C8;
            // 0x017B941C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9420: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9424: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x017B9428: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x017B942C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x017B9430: BR x3                      | goto typeof(System.Text.Encoding).__il2cppRuntimeField_2C0;
            goto typeof(System.Text.Encoding).__il2cppRuntimeField_2C0;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B8F88 (24874888), len: 228  VirtAddr: 0x017B8F88 RVA: 0x017B8F88 token: 100684414 methodIndex: 45984 delegateWrapperIndex: 0 methodInvoker: 0
        public int LEW(byte[] arr, int off)
        {
            //
            // Disasemble & Code
            //  | 
            int val_6;
            // 0x017B8F88: STP x24, x23, [sp, #-0x40]! | stack[1152921513631764320] = ???;  stack[1152921513631764328] = ???;  //  dest_result_addr=1152921513631764320 |  dest_result_addr=1152921513631764328
            // 0x017B8F8C: STP x22, x21, [sp, #0x10]  | stack[1152921513631764336] = ???;  stack[1152921513631764344] = ???;  //  dest_result_addr=1152921513631764336 |  dest_result_addr=1152921513631764344
            // 0x017B8F90: STP x20, x19, [sp, #0x20]  | stack[1152921513631764352] = ???;  stack[1152921513631764360] = ???;  //  dest_result_addr=1152921513631764352 |  dest_result_addr=1152921513631764360
            // 0x017B8F94: STP x29, x30, [sp, #0x30]  | stack[1152921513631764368] = ???;  stack[1152921513631764376] = ???;  //  dest_result_addr=1152921513631764368 |  dest_result_addr=1152921513631764376
            // 0x017B8F98: ADD x29, sp, #0x30         | X29 = (1152921513631764320 + 48) = 1152921513631764368 (0x1000000219ED4F90);
            // 0x017B8F9C: MOV w20, w2                | W20 = off;//m1                          
            // 0x017B8FA0: MOV x19, x1                | X19 = arr;//m1                          
            // 0x017B8FA4: CBNZ x19, #0x17b8fac       | if (arr != null) goto label_0;          
            if(arr != null)
            {
                goto label_0;
            }
            // 0x017B8FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x017B8FAC: LDR x8, [x19, #0x18]       | X8 = arr.Length; //P2                   
            val_6 = arr.Length;
            // 0x017B8FB0: ADD w9, w20, #3            | W9 = (off + 3);                         
            int val_1 = off + 3;
            // 0x017B8FB4: SXTW x21, w9               | X21 = (long)(int)((off + 3));           
            // 0x017B8FB8: CMP w9, w8                 | STATE = COMPARE((off + 3), arr.Length)  
            // 0x017B8FBC: B.LO #0x17b8fd0            | if (val_1 < val_6) goto label_1;        
            if(val_1 < val_6)
            {
                goto label_1;
            }
            // 0x017B8FC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x017B8FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            // 0x017B8FCC: LDR x8, [x19, #0x18]       | X8 = arr.Length; //P2                   
            val_6 = arr.Length;
            label_1:
            // 0x017B8FD0: ADD x9, x19, x21           | X9 = arr[(long)(int)((off + 3))]; //PARR1 
            // 0x017B8FD4: LDRB w21, [x9, #0x20]      | W21 = arr[(long)(int)((off + 3))][0]    
            byte val_6 = arr[(long)val_1];
            // 0x017B8FD8: ADD w9, w20, #2            | W9 = (off + 2);                         
            int val_2 = off + 2;
            // 0x017B8FDC: SXTW x22, w9               | X22 = (long)(int)((off + 2));           
            // 0x017B8FE0: CMP w9, w8                 | STATE = COMPARE((off + 2), arr.Length)  
            // 0x017B8FE4: B.LO #0x17b8ff8            | if (val_2 < val_6) goto label_2;        
            if(val_2 < val_6)
            {
                goto label_2;
            }
            // 0x017B8FE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x017B8FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8FF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            // 0x017B8FF4: LDR x8, [x19, #0x18]       | X8 = arr.Length; //P2                   
            val_6 = arr.Length;
            label_2:
            // 0x017B8FF8: ADD x9, x19, x22           | X9 = arr[(long)(int)((off + 2))]; //PARR1 
            // 0x017B8FFC: LDRB w22, [x9, #0x20]      | W22 = arr[(long)(int)((off + 2))][0]    
            byte val_7 = arr[(long)val_2];
            // 0x017B9000: ADD w9, w20, #1            | W9 = (off + 1);                         
            int val_3 = off + 1;
            // 0x017B9004: SXTW x23, w9               | X23 = (long)(int)((off + 1));           
            // 0x017B9008: CMP w9, w8                 | STATE = COMPARE((off + 1), arr.Length)  
            // 0x017B900C: B.LO #0x17b9020            | if (val_3 < val_6) goto label_3;        
            if(val_3 < val_6)
            {
                goto label_3;
            }
            // 0x017B9010: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x017B9014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9018: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            // 0x017B901C: LDR x8, [x19, #0x18]       | X8 = arr.Length; //P2                   
            val_6 = arr.Length;
            label_3:
            // 0x017B9020: ADD x9, x19, x23           | X9 = arr[(long)(int)((off + 1))]; //PARR1 
            // 0x017B9024: LDRB w23, [x9, #0x20]      | W23 = arr[(long)(int)((off + 1))][0]    
            byte val_8 = arr[(long)val_3];
            // 0x017B9028: SXTW x24, w20              | X24 = (long)(int)(off);                 
            // 0x017B902C: CMP w8, w20                | STATE = COMPARE(arr.Length, off)        
            // 0x017B9030: B.HI #0x17b9040            | if (val_6 > off) goto label_4;          
            if(val_6 > off)
            {
                goto label_4;
            }
            // 0x017B9034: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x017B9038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B903C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_4:
            // 0x017B9040: ADD x8, x19, x24           | X8 = arr[(long)(int)(off)]; //PARR1     
            // 0x017B9044: LDRB w8, [x8, #0x20]       | W8 = arr[(long)(int)(off)][0]           
            byte val_9 = arr[(long)off];
            // 0x017B9048: LSL w9, w21, #0x18         | W9 = (arr[(long)(int)((off + 3))][0] << 24);
            byte val_4 = val_6 << 24;
            // 0x017B904C: BFI w9, w22, #0x10, #8     | W9 = (arr[(long)(int)((off + 3))][0] << 24) | arr[(long)(int)((off + 2))][0]
            // 0x017B9050: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9054: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9058: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x017B905C: BFI w9, w23, #8, #8        | W9 = (arr[(long)(int)((off + 3))][0] << 24) | arr[(long)(int)((off + 1))][0]
            // 0x017B9060: ORR w0, w9, w8             | W0 = ((arr[(long)(int)((off + 3))][0] << 24) | arr[(long)(int)(off)][0]);
            byte val_5 = val_4 | val_9;
            // 0x017B9064: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x017B9068: RET                        |  return (System.Int32)((arr[(long)(int)((off + 3))][0] << 24) | arr[(long)(int)(off)][0]);
            return (int)val_5;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9434 (24876084), len: 176  VirtAddr: 0x017B9434 RVA: 0x017B9434 token: 100684415 methodIndex: 45985 delegateWrapperIndex: 0 methodInvoker: 0
        private static APKManifest()
        {
            //
            // Disasemble & Code
            // 0x017B9434: STP x20, x19, [sp, #-0x20]! | stack[1152921513631913376] = ???;  stack[1152921513631913384] = ???;  //  dest_result_addr=1152921513631913376 |  dest_result_addr=1152921513631913384
            // 0x017B9438: STP x29, x30, [sp, #0x10]  | stack[1152921513631913392] = ???;  stack[1152921513631913400] = ???;  //  dest_result_addr=1152921513631913392 |  dest_result_addr=1152921513631913400
            // 0x017B943C: ADD x29, sp, #0x10         | X29 = (1152921513631913376 + 16) = 1152921513631913392 (0x1000000219EF95B0);
            // 0x017B9440: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017B9444: LDRB w8, [x19, #0x953]     | W8 = (bool)static_value_03738953;       
            // 0x017B9448: TBNZ w8, #0, #0x17b9464    | if (static_value_03738953 == true) goto label_0;
            // 0x017B944C: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x017B9450: LDR x8, [x8, #0xd20]       | X8 = 0x2B8AFFC;                         
            // 0x017B9454: LDR w0, [x8]               | W0 = 0x2BD;                             
            // 0x017B9458: BL #0x2782188              | X0 = sub_2782188( ?? 0x2BD, ????);      
            // 0x017B945C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9460: STRB w8, [x19, #0x953]     | static_value_03738953 = true;            //  dest_result_addr=57903443
            label_0:
            // 0x017B9464: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x017B9468: LDR x8, [x8, #0x7e8]       | X8 = 1152921504856580096;               
            // 0x017B946C: MOVZ w10, #0x10, lsl #16   | W10 = 1048576 (0x100000);//ML01         
            // 0x017B9470: MOVK w10, #0x100           | W10 = 1048832 (0x100100);               
            // 0x017B9474: ORR w11, w10, #1           | W11 = (1048832 | 1) = 1048833 (0x00100101);
            // 0x017B9478: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B947C: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B9480: STR w10, [x9]              | Iteedee.ApkReader.APKManifest.startDocTag = 1048832;  //  dest_result_addr=1152921504856584192
            Iteedee.ApkReader.APKManifest.startDocTag = 1048832;
            // 0x017B9484: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B9488: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B948C: STR w11, [x9, #4]          | Iteedee.ApkReader.APKManifest.endDocTag = 1048833;  //  dest_result_addr=1152921504856584196
            Iteedee.ApkReader.APKManifest.endDocTag = 1048833;
            // 0x017B9490: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B9494: ORR w11, w10, #2           | W11 = (1048832 | 2) = 1048834 (0x00100102);
            // 0x017B9498: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B949C: STR w11, [x9, #8]          | Iteedee.ApkReader.APKManifest.startTag = 1048834;  //  dest_result_addr=1152921504856584200
            Iteedee.ApkReader.APKManifest.startTag = 1048834;
            // 0x017B94A0: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B94A4: ORR w11, w10, #3           | W11 = (1048832 | 3) = 1048835 (0x00100103);
            // 0x017B94A8: ORR w10, w10, #4           | W10 = (1048832 | 4) = 1048836 (0x00100104);
            // 0x017B94AC: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B94B0: STR w11, [x9, #0xc]        | Iteedee.ApkReader.APKManifest.endTag = 1048835;  //  dest_result_addr=1152921504856584204
            Iteedee.ApkReader.APKManifest.endTag = 1048835;
            // 0x017B94B4: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B94B8: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B94BC: STR w10, [x9, #0x10]       | Iteedee.ApkReader.APKManifest.textTag = 1048836;  //  dest_result_addr=1152921504856584208
            Iteedee.ApkReader.APKManifest.textTag = 1048836;
            // 0x017B94C0: ADRP x9, #0x3619000        | X9 = 56725504 (0x3619000);              
            // 0x017B94C4: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.APKManifest);
            // 0x017B94C8: LDR x9, [x9, #0x888]       | X9 = (string**)(1152921513631901248)("                                             ");
            // 0x017B94CC: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.APKManifest.__il2cppRuntimeField_static_fields;
            // 0x017B94D0: LDR x9, [x9]               | X9 = "                                             ";
            // 0x017B94D4: STR x9, [x8, #0x18]        | Iteedee.ApkReader.APKManifest.spaces = "                                             ";  //  dest_result_addr=1152921504856584216
            Iteedee.ApkReader.APKManifest.spaces = "                                             ";
            // 0x017B94D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B94DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B94E0: RET                        |  return;                                
            return;
        
        }
    
    }

}
