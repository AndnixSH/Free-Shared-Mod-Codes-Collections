using UnityEngine;
public enum GridGraph.TextureData.ChannelUse
{
    // Fields
    None = 0
    ,Penalty = 1
    ,Position = 2
    ,WalkablePenalty = 3
    

}
