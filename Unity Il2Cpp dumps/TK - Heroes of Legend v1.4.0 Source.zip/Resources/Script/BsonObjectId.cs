using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    public class BsonObjectId
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285E858
        private byte[] <Value>k__BackingField; //  0x00000010
        
        // Properties
        public byte[] Value { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD1DA8 (11345320), len: 204  VirtAddr: 0x00AD1DA8 RVA: 0x00AD1DA8 token: 100684721 methodIndex: 47376 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonObjectId(byte[] value)
        {
            //
            // Disasemble & Code
            // 0x00AD1DA8: STP x22, x21, [sp, #-0x30]! | stack[1152921513715285280] = ???;  stack[1152921513715285288] = ???;  //  dest_result_addr=1152921513715285280 |  dest_result_addr=1152921513715285288
            // 0x00AD1DAC: STP x20, x19, [sp, #0x10]  | stack[1152921513715285296] = ???;  stack[1152921513715285304] = ???;  //  dest_result_addr=1152921513715285296 |  dest_result_addr=1152921513715285304
            // 0x00AD1DB0: STP x29, x30, [sp, #0x20]  | stack[1152921513715285312] = ???;  stack[1152921513715285320] = ???;  //  dest_result_addr=1152921513715285312 |  dest_result_addr=1152921513715285320
            // 0x00AD1DB4: ADD x29, sp, #0x20         | X29 = (1152921513715285280 + 32) = 1152921513715285312 (0x100000021EE7BD40);
            // 0x00AD1DB8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD1DBC: LDRB w8, [x21, #0x4ce]     | W8 = (bool)static_value_037334CE;       
            // 0x00AD1DC0: MOV x19, x1                | X19 = value;//m1                        
            // 0x00AD1DC4: MOV x20, x0                | X20 = 1152921513715297328 (0x100000021EE7EC30);//ML01
            // 0x00AD1DC8: TBNZ w8, #0, #0xad1de4     | if (static_value_037334CE == true) goto label_0;
            // 0x00AD1DCC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00AD1DD0: LDR x8, [x8, #0x2f0]       | X8 = 0x2B8F984;                         
            // 0x00AD1DD4: LDR w0, [x8]               | W0 = 0x1525;                            
            // 0x00AD1DD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1525, ????);     
            // 0x00AD1DDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1DE0: STRB w8, [x21, #0x4ce]     | static_value_037334CE = true;            //  dest_result_addr=57881806
            label_0:
            // 0x00AD1DE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1DE8: MOV x0, x20                | X0 = 1152921513715297328 (0x100000021EE7EC30);//ML01
            // 0x00AD1DEC: BL #0x16f59f0              | this..ctor();                           
            // 0x00AD1DF0: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00AD1DF4: LDR x8, [x8, #0x400]       | X8 = (string**)(1152921511191786896)("value");
            // 0x00AD1DF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD1DFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD1E00: MOV x1, x19                | X1 = value;//m1                         
            // 0x00AD1E04: LDR x2, [x8]               | X2 = "value";                           
            // 0x00AD1E08: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  value);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  0, parameterName:  value);
            // 0x00AD1E0C: CBNZ x19, #0xad1e14        | if (value != null) goto label_1;        
            if(value != null)
            {
                goto label_1;
            }
            // 0x00AD1E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_1:
            // 0x00AD1E14: LDR w8, [x19, #0x18]       | W8 = value.Length; //P2                 
            // 0x00AD1E18: CMP w8, #0xc               | STATE = COMPARE(value.Length, 0xC)      
            // 0x00AD1E1C: B.NE #0xad1e34             | if (value.Length != 12) goto label_2;   
            if(value.Length != 12)
            {
                goto label_2;
            }
            // 0x00AD1E20: STR x19, [x20, #0x10]      | this.<Value>k__BackingField = value;     //  dest_result_addr=1152921513715297344
            this.<Value>k__BackingField = value;
            // 0x00AD1E24: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1E28: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1E2C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD1E30: RET                        |  return;                                
            return;
            label_2:
            // 0x00AD1E34: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00AD1E38: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00AD1E3C: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x00AD1E40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00AD1E44: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00AD1E48: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921513715272176)("An ObjectId must be 12 bytes");
            // 0x00AD1E4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD1E50: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00AD1E54: LDR x1, [x8]               | X1 = "An ObjectId must be 12 bytes";    
            // 0x00AD1E58: BL #0x1c32b48              | .ctor(message:  "An ObjectId must be 12 bytes");
            val_1 = new System.Exception(message:  "An ObjectId must be 12 bytes");
            // 0x00AD1E5C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x00AD1E60: LDR x8, [x8, #0x388]       | X8 = 1152921513715272304;               
            // 0x00AD1E64: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00AD1E68: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Bson.BsonObjectId::.ctor(byte[] value);
            // 0x00AD1E6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00AD1E70: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1E7C (11345532), len: 8  VirtAddr: 0x00AD1E7C RVA: 0x00AD1E7C token: 100684722 methodIndex: 47377 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] get_Value()
        {
            //
            // Disasemble & Code
            // 0x00AD1E7C: LDR x0, [x0, #0x10]        | X0 = this.<Value>k__BackingField; //P2  
            // 0x00AD1E80: RET                        |  return (System.Byte[])this.<Value>k__BackingField;
            return this.<Value>k__BackingField;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1E74 (11345524), len: 8  VirtAddr: 0x00AD1E74 RVA: 0x00AD1E74 token: 100684723 methodIndex: 47378 delegateWrapperIndex: 0 methodInvoker: 0
        private void set_Value(byte[] value)
        {
            //
            // Disasemble & Code
            // 0x00AD1E74: STR x1, [x0, #0x10]        | this.<Value>k__BackingField = value;     //  dest_result_addr=1152921513715668800
            this.<Value>k__BackingField = value;
            // 0x00AD1E78: RET                        |  return;                                
            return;
        
        }
    
    }

}
