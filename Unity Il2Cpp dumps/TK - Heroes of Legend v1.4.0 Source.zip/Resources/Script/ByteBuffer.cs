using UnityEngine;

namespace ILRuntime.Mono.Cecil.PE
{
    internal class ByteBuffer
    {
        // Fields
        internal byte[] buffer; //  0x00000010
        internal int length; //  0x00000018
        internal int position; //  0x0000001C
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x011E07EC (18745324), len: 164  VirtAddr: 0x011E07EC RVA: 0x011E07EC token: 100664533 methodIndex: 20292 delegateWrapperIndex: 0 methodInvoker: 0
        public ByteBuffer(byte[] buffer)
        {
            //
            // Disasemble & Code
            //  | 
            T[] val_1;
            //  | 
            var val_2;
            // 0x011E07EC: STP x22, x21, [sp, #-0x30]! | stack[1152921509561829072] = ???;  stack[1152921509561829080] = ???;  //  dest_result_addr=1152921509561829072 |  dest_result_addr=1152921509561829080
            // 0x011E07F0: STP x20, x19, [sp, #0x10]  | stack[1152921509561829088] = ???;  stack[1152921509561829096] = ???;  //  dest_result_addr=1152921509561829088 |  dest_result_addr=1152921509561829096
            // 0x011E07F4: STP x29, x30, [sp, #0x20]  | stack[1152921509561829104] = ???;  stack[1152921509561829112] = ???;  //  dest_result_addr=1152921509561829104 |  dest_result_addr=1152921509561829112
            // 0x011E07F8: ADD x29, sp, #0x20         | X29 = (1152921509561829072 + 32) = 1152921509561829104 (0x10000001275706F0);
            // 0x011E07FC: ADRP x21, #0x3736000       | X21 = 57892864 (0x3736000);             
            // 0x011E0800: LDRB w8, [x21, #0xcd]      | W8 = (bool)static_value_037360CD;       
            // 0x011E0804: MOV x20, x1                | X20 = buffer;//m1                       
            val_1 = buffer;
            // 0x011E0808: MOV x19, x0                | X19 = 1152921509561841120 (0x10000001275735E0);//ML01
            // 0x011E080C: TBNZ w8, #0, #0x11e0828    | if (static_value_037360CD == true) goto label_0;
            // 0x011E0810: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x011E0814: LDR x8, [x8, #0xfb0]       | X8 = 0x2B8FF6C;                         
            // 0x011E0818: LDR w0, [x8]               | W0 = 0x169F;                            
            // 0x011E081C: BL #0x2782188              | X0 = sub_2782188( ?? 0x169F, ????);     
            // 0x011E0820: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x011E0824: STRB w8, [x21, #0xcd]      | static_value_037360CD = true;            //  dest_result_addr=57893069
            label_0:
            // 0x011E0828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E082C: MOV x0, x19                | X0 = 1152921509561841120 (0x10000001275735E0);//ML01
            // 0x011E0830: BL #0x16f59f0              | this..ctor();                           
            // 0x011E0834: CBNZ x20, #0x11e0864       | if (buffer != null) goto label_1;       
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x011E0838: ADRP x20, #0x365b000       | X20 = 56995840 (0x365B000);             
            // 0x011E083C: LDR x20, [x20, #0x618]     | X20 = 1152921504736825344;              
            // 0x011E0840: LDR x0, [x20]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_2 = null;
            // 0x011E0844: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_10A;
            // 0x011E0848: TBZ w8, #0, #0x11e085c     | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x011E084C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished;
            // 0x011E0850: CBNZ w8, #0x11e085c        | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x011E0854: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            // 0x011E0858: LDR x0, [x20]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_2 = null;
            label_3:
            // 0x011E085C: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_static_fields;
            // 0x011E0860: LDR x20, [x8]              | X20 = ILRuntime.Mono.Empty<T>.Array;    
            val_1 = ILRuntime.Mono.Empty<T>.Array;
            label_1:
            // 0x011E0864: CBNZ x19, #0x11e086c       | if (this != null) goto label_4;         
            if(this != null)
            {
                goto label_4;
            }
            // 0x011E0868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            label_4:
            // 0x011E086C: STR x20, [x19, #0x10]      | this.buffer = ILRuntime.Mono.Empty<T>.Array;  //  dest_result_addr=1152921509561841136
            this.buffer = val_1;
            // 0x011E0870: CBNZ x20, #0x11e0878       | if (ILRuntime.Mono.Empty<T>.Array != null) goto label_5;
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x011E0874: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            label_5:
            // 0x011E0878: LDR x8, [x20, #0x18]       | X8 = ILRuntime.Mono.Empty<T>.Array.Length;
            // 0x011E087C: STR w8, [x19, #0x18]       | this.length = ILRuntime.Mono.Empty<T>.Array.Length;  //  dest_result_addr=1152921509561841144
            this.length = ILRuntime.Mono.Empty<T>.Array.Length;
            // 0x011E0880: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0884: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0888: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E088C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0890 (18745488), len: 16  VirtAddr: 0x011E0890 RVA: 0x011E0890 token: 100664534 methodIndex: 20293 delegateWrapperIndex: 0 methodInvoker: 0
        public void Advance(int length)
        {
            //
            // Disasemble & Code
            // 0x011E0890: LDR w8, [x0, #0x1c]        | W8 = this.position; //P2                
            int val_1 = this.position;
            // 0x011E0894: ADD w8, w8, w1             | W8 = (this.position + length);          
            val_1 = val_1 + length;
            // 0x011E0898: STR w8, [x0, #0x1c]        | this.position = (this.position + length);  //  dest_result_addr=1152921509561990012
            this.position = val_1;
            // 0x011E089C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E08A0 (18745504), len: 80  VirtAddr: 0x011E08A0 RVA: 0x011E08A0 token: 100664535 methodIndex: 20294 delegateWrapperIndex: 0 methodInvoker: 0
        public byte ReadByte()
        {
            //
            // Disasemble & Code
            // 0x011E08A0: STP x20, x19, [sp, #-0x20]! | stack[1152921509562126816] = ???;  stack[1152921509562126824] = ???;  //  dest_result_addr=1152921509562126816 |  dest_result_addr=1152921509562126824
            // 0x011E08A4: STP x29, x30, [sp, #0x10]  | stack[1152921509562126832] = ???;  stack[1152921509562126840] = ???;  //  dest_result_addr=1152921509562126832 |  dest_result_addr=1152921509562126840
            // 0x011E08A8: ADD x29, sp, #0x10         | X29 = (1152921509562126816 + 16) = 1152921509562126832 (0x10000001275B91F0);
            // 0x011E08AC: LDRSW x19, [x0, #0x1c]     | X19 = this.position; //P2               
            // 0x011E08B0: LDR x20, [x0, #0x10]       | X20 = this.buffer; //P2                 
            // 0x011E08B4: ADD w8, w19, #1            | W8 = (this.position + 1);               
            int val_1 = this.position + 1;
            // 0x011E08B8: STR w8, [x0, #0x1c]        | this.position = (this.position + 1);     //  dest_result_addr=1152921509562138876
            this.position = val_1;
            // 0x011E08BC: CBNZ x20, #0x11e08c4       | if (this.buffer != null) goto label_0;  
            if(this.buffer != null)
            {
                goto label_0;
            }
            // 0x011E08C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x011E08C4: LDR w8, [x20, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E08C8: CMP w19, w8                | STATE = COMPARE(this.position, this.buffer.Length)
            // 0x011E08CC: B.LO #0x11e08dc            | if (this.position < this.buffer.Length) goto label_1;
            if(this.position < this.buffer.Length)
            {
                goto label_1;
            }
            // 0x011E08D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E08D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E08D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x011E08DC: ADD x8, x20, x19           | X8 = this.buffer[this.position]; //PARR1 
            // 0x011E08E0: LDRB w0, [x8, #0x20]       | W0 = this.buffer[this.position][0]      
            byte val_2 = this.buffer[this.position];
            // 0x011E08E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E08E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E08EC: RET                        |  return (System.Byte)this.buffer[this.position][0];
            return val_2;
            //  |  // // {name=val_0, type=System.Byte, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E08F0 (18745584), len: 160  VirtAddr: 0x011E08F0 RVA: 0x011E08F0 token: 100664536 methodIndex: 20295 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] ReadBytes(int length)
        {
            //
            // Disasemble & Code
            // 0x011E08F0: STP x22, x21, [sp, #-0x30]! | stack[1152921509562312528] = ???;  stack[1152921509562312536] = ???;  //  dest_result_addr=1152921509562312528 |  dest_result_addr=1152921509562312536
            // 0x011E08F4: STP x20, x19, [sp, #0x10]  | stack[1152921509562312544] = ???;  stack[1152921509562312552] = ???;  //  dest_result_addr=1152921509562312544 |  dest_result_addr=1152921509562312552
            // 0x011E08F8: STP x29, x30, [sp, #0x20]  | stack[1152921509562312560] = ???;  stack[1152921509562312568] = ???;  //  dest_result_addr=1152921509562312560 |  dest_result_addr=1152921509562312568
            // 0x011E08FC: ADD x29, sp, #0x20         | X29 = (1152921509562312528 + 32) = 1152921509562312560 (0x10000001275E6770);
            // 0x011E0900: ADRP x21, #0x3736000       | X21 = 57892864 (0x3736000);             
            // 0x011E0904: LDRB w8, [x21, #0xce]      | W8 = (bool)static_value_037360CE;       
            // 0x011E0908: MOV w19, w1                | W19 = length;//m1                       
            // 0x011E090C: MOV x20, x0                | X20 = 1152921509562324576 (0x10000001275E9660);//ML01
            // 0x011E0910: TBNZ w8, #0, #0x11e092c    | if (static_value_037360CE == true) goto label_0;
            // 0x011E0914: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x011E0918: LDR x8, [x8, #0x888]       | X8 = 0x2B8FF70;                         
            // 0x011E091C: LDR w0, [x8]               | W0 = 0x16A0;                            
            // 0x011E0920: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A0, ????);     
            // 0x011E0924: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x011E0928: STRB w8, [x21, #0xce]      | static_value_037360CE = true;            //  dest_result_addr=57893070
            label_0:
            // 0x011E092C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x011E0930: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x011E0934: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
            // 0x011E0938: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x011E093C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x011E0940: MOV w1, w19                | W1 = length;//m1                        
            // 0x011E0944: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x011E0948: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x011E094C: LDR x1, [x20, #0x10]       | X1 = this.buffer; //P2                  
            // 0x011E0950: LDR w2, [x20, #0x1c]       | W2 = this.position; //P2                
            // 0x011E0954: MOV x21, x0                | X21 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x011E0958: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E095C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x011E0960: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x011E0964: MOV x3, x21                | X3 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x011E0968: MOV w5, w19                | W5 = length;//m1                        
            // 0x011E096C: BL #0x18b30e0              | System.Buffer.BlockCopy(src:  0, srcOffset:  this.buffer, dst:  this.position, dstOffset:  389323824, count:  0);
            System.Buffer.BlockCopy(src:  0, srcOffset:  this.buffer, dst:  this.position, dstOffset:  389323824, count:  0);
            // 0x011E0970: LDR w8, [x20, #0x1c]       | W8 = this.position; //P2                
            int val_1 = this.position;
            // 0x011E0974: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x011E0978: ADD w8, w8, w19            | W8 = (this.position + length);          
            val_1 = val_1 + length;
            // 0x011E097C: STR w8, [x20, #0x1c]       | this.position = (this.position + length);  //  dest_result_addr=1152921509562324604
            this.position = val_1;
            // 0x011E0980: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0984: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0988: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E098C: RET                        |  return (System.Byte[])typeof(System.Byte[]);
            return (System.Byte[])null;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0990 (18745744), len: 160  VirtAddr: 0x011E0990 RVA: 0x011E0990 token: 100664537 methodIndex: 20296 delegateWrapperIndex: 0 methodInvoker: 0
        public ushort ReadUInt16()
        {
            //
            // Disasemble & Code
            // 0x011E0990: STP x22, x21, [sp, #-0x30]! | stack[1152921509562535120] = ???;  stack[1152921509562535128] = ???;  //  dest_result_addr=1152921509562535120 |  dest_result_addr=1152921509562535128
            // 0x011E0994: STP x20, x19, [sp, #0x10]  | stack[1152921509562535136] = ???;  stack[1152921509562535144] = ???;  //  dest_result_addr=1152921509562535136 |  dest_result_addr=1152921509562535144
            // 0x011E0998: STP x29, x30, [sp, #0x20]  | stack[1152921509562535152] = ???;  stack[1152921509562535160] = ???;  //  dest_result_addr=1152921509562535152 |  dest_result_addr=1152921509562535160
            // 0x011E099C: ADD x29, sp, #0x20         | X29 = (1152921509562535120 + 32) = 1152921509562535152 (0x100000012761CCF0);
            // 0x011E09A0: MOV x19, x0                | X19 = 1152921509562547168 (0x100000012761FBE0);//ML01
            // 0x011E09A4: LDR x20, [x19, #0x10]      | X20 = this.buffer; //P2                 
            // 0x011E09A8: LDRSW x21, [x19, #0x1c]    | X21 = this.position; //P2               
            // 0x011E09AC: CBNZ x20, #0x11e09b4       | if (this.buffer != null) goto label_0;  
            if(this.buffer != null)
            {
                goto label_0;
            }
            // 0x011E09B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x011E09B4: LDR w8, [x20, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E09B8: CMP w21, w8                | STATE = COMPARE(this.position, this.buffer.Length)
            // 0x011E09BC: B.LO #0x11e09cc            | if (this.position < this.buffer.Length) goto label_1;
            if(this.position < this.buffer.Length)
            {
                goto label_1;
            }
            // 0x011E09C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E09C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E09C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x011E09CC: ADD x8, x20, x21           | X8 = this.buffer[this.position]; //PARR1 
            // 0x011E09D0: LDR x21, [x19, #0x10]      | X21 = this.buffer; //P2                 
            // 0x011E09D4: LDRB w20, [x8, #0x20]      | W20 = this.buffer[this.position][0]     
            byte val_2 = this.buffer[this.position];
            // 0x011E09D8: LDR w22, [x19, #0x1c]      | W22 = this.position; //P2               
            // 0x011E09DC: CBNZ x21, #0x11e09e4       | if (this.buffer != null) goto label_2;  
            if(this.buffer != null)
            {
                goto label_2;
            }
            // 0x011E09E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x011E09E4: LDR w8, [x21, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E09E8: ADD w9, w22, #1            | W9 = (this.position + 1);               
            int val_1 = this.position + 1;
            // 0x011E09EC: SXTW x22, w9               | X22 = (long)(int)((this.position + 1)); 
            // 0x011E09F0: CMP w9, w8                 | STATE = COMPARE((this.position + 1), this.buffer.Length)
            // 0x011E09F4: B.LO #0x11e0a04            | if (val_1 < this.buffer.Length) goto label_3;
            if(val_1 < this.buffer.Length)
            {
                goto label_3;
            }
            // 0x011E09F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E09FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E0A00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_3:
            // 0x011E0A04: ADD x8, x21, x22           | X8 = this.buffer[(long)(int)((this.position + 1))]; //PARR1 
            // 0x011E0A08: LDR w9, [x19, #0x1c]       | W9 = this.position; //P2                
            int val_4 = this.position;
            // 0x011E0A0C: LDRB w8, [x8, #0x20]       | W8 = this.buffer[(long)(int)((this.position + 1))][0]
            byte val_3 = this.buffer[(long)val_1];
            // 0x011E0A10: ADD w9, w9, #2             | W9 = (this.position + 2);               
            val_4 = val_4 + 2;
            // 0x011E0A14: BFI w20, w8, #8, #8        | W20 = this.buffer[this.position][0] | this.buffer[(long)(int)((this.position + 1))][0]
            // 0x011E0A18: STR w9, [x19, #0x1c]       | this.position = (this.position + 2);     //  dest_result_addr=1152921509562547196
            this.position = val_4;
            // 0x011E0A1C: MOV w0, w20                | W0 = this.buffer[this.position][0];//m1 
            // 0x011E0A20: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0A24: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0A28: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0A2C: RET                        |  return (System.UInt16)this.buffer[this.position][0];
            return (ushort)val_2;
            //  |  // // {name=val_0, type=System.UInt16, size=2, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0A30 (18745904), len: 4  VirtAddr: 0x011E0A30 RVA: 0x011E0A30 token: 100664538 methodIndex: 20297 delegateWrapperIndex: 0 methodInvoker: 0
        public short ReadInt16()
        {
            //
            // Disasemble & Code
            // 0x011E0A30: B #0x11e0990               | return this.ReadUInt16();               
            return this.ReadUInt16();
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0A34 (18745908), len: 288  VirtAddr: 0x011E0A34 RVA: 0x011E0A34 token: 100664539 methodIndex: 20298 delegateWrapperIndex: 0 methodInvoker: 0
        public uint ReadUInt32()
        {
            //
            // Disasemble & Code
            // 0x011E0A34: STP x24, x23, [sp, #-0x40]! | stack[1152921509562980288] = ???;  stack[1152921509562980296] = ???;  //  dest_result_addr=1152921509562980288 |  dest_result_addr=1152921509562980296
            // 0x011E0A38: STP x22, x21, [sp, #0x10]  | stack[1152921509562980304] = ???;  stack[1152921509562980312] = ???;  //  dest_result_addr=1152921509562980304 |  dest_result_addr=1152921509562980312
            // 0x011E0A3C: STP x20, x19, [sp, #0x20]  | stack[1152921509562980320] = ???;  stack[1152921509562980328] = ???;  //  dest_result_addr=1152921509562980320 |  dest_result_addr=1152921509562980328
            // 0x011E0A40: STP x29, x30, [sp, #0x30]  | stack[1152921509562980336] = ???;  stack[1152921509562980344] = ???;  //  dest_result_addr=1152921509562980336 |  dest_result_addr=1152921509562980344
            // 0x011E0A44: ADD x29, sp, #0x30         | X29 = (1152921509562980288 + 48) = 1152921509562980336 (0x10000001276897F0);
            // 0x011E0A48: MOV x19, x0                | X19 = 1152921509562992352 (0x100000012768C6E0);//ML01
            // 0x011E0A4C: LDR x20, [x19, #0x10]      | X20 = this.buffer; //P2                 
            // 0x011E0A50: LDRSW x21, [x19, #0x1c]    | X21 = this.position; //P2               
            // 0x011E0A54: CBNZ x20, #0x11e0a5c       | if (this.buffer != null) goto label_0;  
            if(this.buffer != null)
            {
                goto label_0;
            }
            // 0x011E0A58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x011E0A5C: LDR w8, [x20, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E0A60: CMP w21, w8                | STATE = COMPARE(this.position, this.buffer.Length)
            // 0x011E0A64: B.LO #0x11e0a74            | if (this.position < this.buffer.Length) goto label_1;
            if(this.position < this.buffer.Length)
            {
                goto label_1;
            }
            // 0x011E0A68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E0A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E0A70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x011E0A74: ADD x8, x20, x21           | X8 = this.buffer[this.position]; //PARR1 
            // 0x011E0A78: LDR x21, [x19, #0x10]      | X21 = this.buffer; //P2                 
            // 0x011E0A7C: LDRB w20, [x8, #0x20]      | W20 = this.buffer[this.position][0]     
            byte val_4 = this.buffer[this.position];
            // 0x011E0A80: LDR w22, [x19, #0x1c]      | W22 = this.position; //P2               
            // 0x011E0A84: CBNZ x21, #0x11e0a8c       | if (this.buffer != null) goto label_2;  
            if(this.buffer != null)
            {
                goto label_2;
            }
            // 0x011E0A88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x011E0A8C: LDR w8, [x21, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E0A90: ADD w9, w22, #1            | W9 = (this.position + 1);               
            int val_1 = this.position + 1;
            // 0x011E0A94: SXTW x22, w9               | X22 = (long)(int)((this.position + 1)); 
            // 0x011E0A98: CMP w9, w8                 | STATE = COMPARE((this.position + 1), this.buffer.Length)
            // 0x011E0A9C: B.LO #0x11e0aac            | if (val_1 < this.buffer.Length) goto label_3;
            if(val_1 < this.buffer.Length)
            {
                goto label_3;
            }
            // 0x011E0AA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E0AA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E0AA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_3:
            // 0x011E0AAC: ADD x8, x21, x22           | X8 = this.buffer[(long)(int)((this.position + 1))]; //PARR1 
            // 0x011E0AB0: LDR x22, [x19, #0x10]      | X22 = this.buffer; //P2                 
            // 0x011E0AB4: LDRB w21, [x8, #0x20]      | W21 = this.buffer[(long)(int)((this.position + 1))][0]
            byte val_5 = this.buffer[(long)val_1];
            // 0x011E0AB8: LDR w23, [x19, #0x1c]      | W23 = this.position; //P2               
            // 0x011E0ABC: CBNZ x22, #0x11e0ac4       | if (this.buffer != null) goto label_4;  
            if(this.buffer != null)
            {
                goto label_4;
            }
            // 0x011E0AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x011E0AC4: LDR w8, [x22, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E0AC8: ADD w9, w23, #2            | W9 = (this.position + 2);               
            int val_2 = this.position + 2;
            // 0x011E0ACC: SXTW x23, w9               | X23 = (long)(int)((this.position + 2)); 
            // 0x011E0AD0: CMP w9, w8                 | STATE = COMPARE((this.position + 2), this.buffer.Length)
            // 0x011E0AD4: B.LO #0x11e0ae4            | if (val_2 < this.buffer.Length) goto label_5;
            if(val_2 < this.buffer.Length)
            {
                goto label_5;
            }
            // 0x011E0AD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E0ADC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E0AE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_5:
            // 0x011E0AE4: ADD x8, x22, x23           | X8 = this.buffer[(long)(int)((this.position + 2))]; //PARR1 
            // 0x011E0AE8: LDR x23, [x19, #0x10]      | X23 = this.buffer; //P2                 
            // 0x011E0AEC: LDRB w22, [x8, #0x20]      | W22 = this.buffer[(long)(int)((this.position + 2))][0]
            byte val_6 = this.buffer[(long)val_2];
            // 0x011E0AF0: LDR w24, [x19, #0x1c]      | W24 = this.position; //P2               
            // 0x011E0AF4: CBNZ x23, #0x11e0afc       | if (this.buffer != null) goto label_6;  
            if(this.buffer != null)
            {
                goto label_6;
            }
            // 0x011E0AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x011E0AFC: LDR w8, [x23, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E0B00: ADD w9, w24, #3            | W9 = (this.position + 3);               
            int val_3 = this.position + 3;
            // 0x011E0B04: SXTW x24, w9               | X24 = (long)(int)((this.position + 3)); 
            // 0x011E0B08: CMP w9, w8                 | STATE = COMPARE((this.position + 3), this.buffer.Length)
            // 0x011E0B0C: B.LO #0x11e0b1c            | if (val_3 < this.buffer.Length) goto label_7;
            if(val_3 < this.buffer.Length)
            {
                goto label_7;
            }
            // 0x011E0B10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E0B14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E0B18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_7:
            // 0x011E0B1C: LDR w8, [x19, #0x1c]       | W8 = this.position; //P2                
            int val_8 = this.position;
            // 0x011E0B20: ADD x9, x23, x24           | X9 = this.buffer[(long)(int)((this.position + 3))]; //PARR1 
            // 0x011E0B24: LDRB w9, [x9, #0x20]       | W9 = this.buffer[(long)(int)((this.position + 3))][0]
            byte val_7 = this.buffer[(long)val_3];
            // 0x011E0B28: BFI w20, w21, #8, #8       | W20 = this.buffer[this.position][0] | this.buffer[(long)(int)((this.position + 1))][0]
            // 0x011E0B2C: ADD w8, w8, #4             | W8 = (this.position + 4);               
            val_8 = val_8 + 4;
            // 0x011E0B30: BFI w20, w22, #0x10, #8    | W20 = this.buffer[this.position][0] | this.buffer[(long)(int)((this.position + 2))][0]
            // 0x011E0B34: BFI w20, w9, #0x18, #8     | W20 = this.buffer[this.position][0] | this.buffer[(long)(int)((this.position + 3))][0]
            // 0x011E0B38: STR w8, [x19, #0x1c]       | this.position = (this.position + 4);     //  dest_result_addr=1152921509562992380
            this.position = val_8;
            // 0x011E0B3C: MOV w0, w20                | W0 = this.buffer[this.position][0];//m1 
            // 0x011E0B40: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0B44: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0B48: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x011E0B4C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x011E0B50: RET                        |  return (System.UInt32)this.buffer[this.position][0];
            return (uint)val_4;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0B54 (18746196), len: 4  VirtAddr: 0x011E0B54 RVA: 0x011E0B54 token: 100664540 methodIndex: 20299 delegateWrapperIndex: 0 methodInvoker: 0
        public int ReadInt32()
        {
            //
            // Disasemble & Code
            // 0x011E0B54: B #0x11e0a34               | return this.ReadUInt32();               
            return this.ReadUInt32();
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0B58 (18746200), len: 56  VirtAddr: 0x011E0B58 RVA: 0x011E0B58 token: 100664541 methodIndex: 20300 delegateWrapperIndex: 0 methodInvoker: 0
        public ulong ReadUInt64()
        {
            //
            // Disasemble & Code
            // 0x011E0B58: STP x20, x19, [sp, #-0x20]! | stack[1152921509563351776] = ???;  stack[1152921509563351784] = ???;  //  dest_result_addr=1152921509563351776 |  dest_result_addr=1152921509563351784
            // 0x011E0B5C: STP x29, x30, [sp, #0x10]  | stack[1152921509563351792] = ???;  stack[1152921509563351800] = ???;  //  dest_result_addr=1152921509563351792 |  dest_result_addr=1152921509563351800
            // 0x011E0B60: ADD x29, sp, #0x10         | X29 = (1152921509563351776 + 16) = 1152921509563351792 (0x10000001276E42F0);
            // 0x011E0B64: MOV x19, x0                | X19 = 1152921509563363808 (0x10000001276E71E0);//ML01
            // 0x011E0B68: BL #0x11e0a34              | X0 = this.ReadUInt32();                 
            uint val_1 = this.ReadUInt32();
            // 0x011E0B6C: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x011E0B70: MOV x0, x19                | X0 = 1152921509563363808 (0x10000001276E71E0);//ML01
            // 0x011E0B74: BL #0x11e0a34              | X0 = this.ReadUInt32();                 
            uint val_2 = this.ReadUInt32();
            // 0x011E0B78: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0B7C: MOV w8, w20                | W8 = val_1;//m1                         
            // 0x011E0B80: BFI x8, x0, #0x20, #0x20   | X8 = val_1 | val_2                      
            // 0x011E0B84: MOV x0, x8                 | X0 = val_1;//m1                         
            // 0x011E0B88: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E0B8C: RET                        |  return (System.UInt64)val_1;           
            return (ulong)val_1;
            //  |  // // {name=val_0, type=System.UInt64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0B90 (18746256), len: 56  VirtAddr: 0x011E0B90 RVA: 0x011E0B90 token: 100664542 methodIndex: 20301 delegateWrapperIndex: 0 methodInvoker: 0
        public long ReadInt64()
        {
            //
            // Disasemble & Code
            // 0x011E0B90: STP x20, x19, [sp, #-0x20]! | stack[1152921509563463776] = ???;  stack[1152921509563463784] = ???;  //  dest_result_addr=1152921509563463776 |  dest_result_addr=1152921509563463784
            // 0x011E0B94: STP x29, x30, [sp, #0x10]  | stack[1152921509563463792] = ???;  stack[1152921509563463800] = ???;  //  dest_result_addr=1152921509563463792 |  dest_result_addr=1152921509563463800
            // 0x011E0B98: ADD x29, sp, #0x10         | X29 = (1152921509563463776 + 16) = 1152921509563463792 (0x10000001276FF870);
            // 0x011E0B9C: MOV x19, x0                | X19 = 1152921509563475808 (0x1000000127702760);//ML01
            // 0x011E0BA0: BL #0x11e0a34              | X0 = this.ReadUInt32();                 
            uint val_1 = this.ReadUInt32();
            // 0x011E0BA4: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x011E0BA8: MOV x0, x19                | X0 = 1152921509563475808 (0x1000000127702760);//ML01
            // 0x011E0BAC: BL #0x11e0a34              | X0 = this.ReadUInt32();                 
            uint val_2 = this.ReadUInt32();
            // 0x011E0BB0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0BB4: MOV w8, w20                | W8 = val_1;//m1                         
            // 0x011E0BB8: BFI x8, x0, #0x20, #0x20   | X8 = val_1 | val_2                      
            // 0x011E0BBC: MOV x0, x8                 | X0 = val_1;//m1                         
            // 0x011E0BC0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E0BC4: RET                        |  return (System.Int64)val_1;            
            return (long)val_1;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0BC8 (18746312), len: 128  VirtAddr: 0x011E0BC8 RVA: 0x011E0BC8 token: 100664543 methodIndex: 20302 delegateWrapperIndex: 0 methodInvoker: 0
        public uint ReadCompressedUInt32()
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            // 0x011E0BC8: STP x22, x21, [sp, #-0x30]! | stack[1152921509563575760] = ???;  stack[1152921509563575768] = ???;  //  dest_result_addr=1152921509563575760 |  dest_result_addr=1152921509563575768
            // 0x011E0BCC: STP x20, x19, [sp, #0x10]  | stack[1152921509563575776] = ???;  stack[1152921509563575784] = ???;  //  dest_result_addr=1152921509563575776 |  dest_result_addr=1152921509563575784
            // 0x011E0BD0: STP x29, x30, [sp, #0x20]  | stack[1152921509563575792] = ???;  stack[1152921509563575800] = ???;  //  dest_result_addr=1152921509563575792 |  dest_result_addr=1152921509563575800
            // 0x011E0BD4: ADD x29, sp, #0x20         | X29 = (1152921509563575760 + 32) = 1152921509563575792 (0x100000012771ADF0);
            // 0x011E0BD8: MOV x20, x0                | X20 = 1152921509563587808 (0x100000012771DCE0);//ML01
            // 0x011E0BDC: BL #0x11e08a0              | X0 = this.ReadByte();                   
            byte val_1 = this.ReadByte();
            // 0x011E0BE0: AND w19, w0, #0xff         | W19 = (val_1 & 255);                    
            val_9 = val_1 & 255;
            // 0x011E0BE4: TBZ w0, #7, #0x11e0c34     | if ((val_1 & 0x80) == 0) goto label_2;  
            if((val_1 & 128) == 0)
            {
                goto label_2;
            }
            // 0x011E0BE8: MOV x0, x20                | X0 = 1152921509563587808 (0x100000012771DCE0);//ML01
            // 0x011E0BEC: BL #0x11e08a0              | X0 = this.ReadByte();                   
            byte val_2 = this.ReadByte();
            // 0x011E0BF0: MOV w21, w0                | W21 = val_2;//m1                        
            // 0x011E0BF4: TBNZ w19, #6, #0x11e0c08   | if (((val_1 & 255) & 0x40) != 0) goto label_1;
            if((val_9 & 64) != 0)
            {
                goto label_1;
            }
            // 0x011E0BF8: AND w8, w21, #0xff         | W8 = (val_2 & 255);                     
            byte val_3 = val_2 & 255;
            // 0x011E0BFC: BFI w8, w19, #8, #7        | W8 = (val_2 & 255) | (val_1 & 255)      
            // 0x011E0C00: MOV w19, w8                | W19 = (val_2 & 255);//m1                
            val_9 = val_3;
            // 0x011E0C04: B #0x11e0c34               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x011E0C08: MOV x0, x20                | X0 = 1152921509563587808 (0x100000012771DCE0);//ML01
            // 0x011E0C0C: BL #0x11e08a0              | X0 = this.ReadByte();                   
            byte val_4 = this.ReadByte();
            // 0x011E0C10: MOV w22, w0                | W22 = val_4;//m1                        
            // 0x011E0C14: MOV x0, x20                | X0 = 1152921509563587808 (0x100000012771DCE0);//ML01
            // 0x011E0C18: BL #0x11e08a0              | X0 = this.ReadByte();                   
            byte val_5 = this.ReadByte();
            // 0x011E0C1C: UBFIZ w19, w19, #0x18, #6  | 
            // 0x011E0C20: AND w8, w21, #0xff         | W8 = (val_2 & 255);                     
            byte val_6 = val_2 & 255;
            // 0x011E0C24: BFI w19, w8, #0x10, #8     | W19 = (val_1 & 255) | (val_2 & 255)     
            // 0x011E0C28: AND w8, w22, #0xff         | W8 = (val_4 & 255);                     
            byte val_7 = val_4 & 255;
            // 0x011E0C2C: BFI w19, w8, #8, #8        | W19 = (val_1 & 255) | (val_4 & 255)     
            // 0x011E0C30: BFXIL w19, w0, #0, #8      | 
            label_2:
            // 0x011E0C34: MOV w0, w19                | W0 = (val_1 & 255);//m1                 
            // 0x011E0C38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0C3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0C40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0C44: RET                        |  return (System.UInt32)(val_1 & 255);   
            return (uint)val_9;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0C48 (18746440), len: 152  VirtAddr: 0x011E0C48 RVA: 0x011E0C48 token: 100664544 methodIndex: 20303 delegateWrapperIndex: 0 methodInvoker: 0
        public int ReadCompressedInt32()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x011E0C48: STP x22, x21, [sp, #-0x30]! | stack[1152921509563724624] = ???;  stack[1152921509563724632] = ???;  //  dest_result_addr=1152921509563724624 |  dest_result_addr=1152921509563724632
            // 0x011E0C4C: STP x20, x19, [sp, #0x10]  | stack[1152921509563724640] = ???;  stack[1152921509563724648] = ???;  //  dest_result_addr=1152921509563724640 |  dest_result_addr=1152921509563724648
            // 0x011E0C50: STP x29, x30, [sp, #0x20]  | stack[1152921509563724656] = ???;  stack[1152921509563724664] = ???;  //  dest_result_addr=1152921509563724656 |  dest_result_addr=1152921509563724664
            // 0x011E0C54: ADD x29, sp, #0x20         | X29 = (1152921509563724624 + 32) = 1152921509563724656 (0x100000012773F370);
            // 0x011E0C58: MOV x19, x0                | X19 = 1152921509563736672 (0x1000000127742260);//ML01
            // 0x011E0C5C: LDR x20, [x19, #0x10]      | X20 = this.buffer; //P2                 
            // 0x011E0C60: LDRSW x21, [x19, #0x1c]    | X21 = this.position; //P2               
            // 0x011E0C64: CBNZ x20, #0x11e0c6c       | if (this.buffer != null) goto label_0;  
            if(this.buffer != null)
            {
                goto label_0;
            }
            // 0x011E0C68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x011E0C6C: LDR w8, [x20, #0x18]       | W8 = this.buffer.Length; //P2           
            // 0x011E0C70: CMP w21, w8                | STATE = COMPARE(this.position, this.buffer.Length)
            // 0x011E0C74: B.LO #0x11e0c84            | if (this.position < this.buffer.Length) goto label_1;
            if(this.position < this.buffer.Length)
            {
                goto label_1;
            }
            // 0x011E0C78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x011E0C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011E0C80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x011E0C84: ADD x8, x20, x21           | X8 = this.buffer[this.position]; //PARR1 
            // 0x011E0C88: LDRB w20, [x8, #0x20]      | W20 = this.buffer[this.position][0]     
            byte val_3 = this.buffer[this.position];
            // 0x011E0C8C: MOV x0, x19                | X0 = 1152921509563736672 (0x1000000127742260);//ML01
            // 0x011E0C90: BL #0x11e0bc8              | X0 = this.ReadCompressedUInt32();       
            uint val_1 = this.ReadCompressedUInt32();
            // 0x011E0C94: MOV w8, w0                 | W8 = val_1;//m1                         
            // 0x011E0C98: ASR w0, w8, #1             | W0 = (val_1 >> 1);                      
            val_3 = val_1 >> 1;
            // 0x011E0C9C: TBZ w8, #0, #0x11e0cd0     | if ((val_1 & 0x1) == 0) goto label_7;   
            if((val_1 & 1) == 0)
            {
                goto label_7;
            }
            // 0x011E0CA0: AND w8, w20, #0xc0         | W8 = (this.buffer[this.position][0] & 192);
            byte val_2 = val_3 & 192;
            // 0x011E0CA4: CBZ w8, #0x11e0cb8         | if ((this.buffer[this.position][0] & 192) == 0) goto label_3;
            if(val_2 == 0)
            {
                goto label_3;
            }
            // 0x011E0CA8: CMP w8, #0x80              | STATE = COMPARE((this.buffer[this.position][0] & 192), 0x80)
            // 0x011E0CAC: B.EQ #0x11e0cc0            | if (val_2 == 128) goto label_4;         
            if(val_2 == 128)
            {
                goto label_4;
            }
            // 0x011E0CB0: CMP w8, #0x40              | STATE = COMPARE((this.buffer[this.position][0] & 192), 0x40)
            // 0x011E0CB4: B.NE #0x11e0cc8            | if (val_2 != 64) goto label_5;          
            if(val_2 != 64)
            {
                goto label_5;
            }
            label_3:
            // 0x011E0CB8: SUB w0, w0, #0x40          | W0 = ((val_1 >> 1) - 64);               
            val_3 = val_3 - 64;
            // 0x011E0CBC: B #0x11e0cd0               |  goto label_7;                          
            goto label_7;
            label_4:
            // 0x011E0CC0: SUB w0, w0, #2, lsl #12    | W0 = ((val_1 >> 1) - 8192);             
            val_3 = val_3 - 8192;
            // 0x011E0CC4: B #0x11e0cd0               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x011E0CC8: ORR w8, wzr, #0xf0000000   | W8 = -268435456(0xFFFFFFFFF0000000);    
            // 0x011E0CCC: ADD w0, w0, w8             | W0 = ((val_1 >> 1) + -268435456);       
            val_3 = val_3 + (-268435456);
            label_7:
            // 0x011E0CD0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0CD4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0CD8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0CDC: RET                        |  return (System.Int32)((val_1 >> 1) + -268435456);
            return (int)val_3;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0CE0 (18746592), len: 268  VirtAddr: 0x011E0CE0 RVA: 0x011E0CE0 token: 100664545 methodIndex: 20304 delegateWrapperIndex: 0 methodInvoker: 0
        public float ReadSingle()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x011E0CE0: STP x22, x21, [sp, #-0x30]! | stack[1152921509563947216] = ???;  stack[1152921509563947224] = ???;  //  dest_result_addr=1152921509563947216 |  dest_result_addr=1152921509563947224
            // 0x011E0CE4: STP x20, x19, [sp, #0x10]  | stack[1152921509563947232] = ???;  stack[1152921509563947240] = ???;  //  dest_result_addr=1152921509563947232 |  dest_result_addr=1152921509563947240
            // 0x011E0CE8: STP x29, x30, [sp, #0x20]  | stack[1152921509563947248] = ???;  stack[1152921509563947256] = ???;  //  dest_result_addr=1152921509563947248 |  dest_result_addr=1152921509563947256
            // 0x011E0CEC: ADD x29, sp, #0x20         | X29 = (1152921509563947216 + 32) = 1152921509563947248 (0x10000001277758F0);
            // 0x011E0CF0: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x011E0CF4: LDRB w8, [x20, #0xcf]      | W8 = (bool)static_value_037360CF;       
            // 0x011E0CF8: MOV x19, x0                | X19 = 1152921509563959264 (0x10000001277787E0);//ML01
            // 0x011E0CFC: TBNZ w8, #0, #0x11e0d18    | if (static_value_037360CF == true) goto label_0;
            // 0x011E0D00: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x011E0D04: LDR x8, [x8, #0x250]       | X8 = 0x2B8FF78;                         
            // 0x011E0D08: LDR w0, [x8]               | W0 = 0x16A2;                            
            // 0x011E0D0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A2, ????);     
            // 0x011E0D10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x011E0D14: STRB w8, [x20, #0xcf]      | static_value_037360CF = true;            //  dest_result_addr=57893071
            label_0:
            // 0x011E0D18: ADRP x20, #0x3679000       | X20 = 57118720 (0x3679000);             
            // 0x011E0D1C: LDR x20, [x20, #0xe08]     | X20 = 1152921504652320768;              
            // 0x011E0D20: LDR x0, [x20]              | X0 = typeof(System.BitConverter);       
            val_3 = null;
            // 0x011E0D24: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
            // 0x011E0D28: TBZ w8, #0, #0x11e0d3c     | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x011E0D2C: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
            // 0x011E0D30: CBNZ w8, #0x11e0d3c        | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x011E0D34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
            // 0x011E0D38: LDR x0, [x20]              | X0 = typeof(System.BitConverter);       
            val_3 = null;
            label_2:
            // 0x011E0D3C: LDR x8, [x0, #0xa0]        | X8 = System.BitConverter.__il2cppRuntimeField_static_fields;
            // 0x011E0D40: LDRB w8, [x8, #1]          | W8 = System.BitConverter.IsLittleEndian;
            // 0x011E0D44: CBZ w8, #0x11e0d94         | if (System.BitConverter.IsLittleEndian == false) goto label_3;
            if(System.BitConverter.IsLittleEndian == false)
            {
                goto label_3;
            }
            // 0x011E0D48: LDR x20, [x19, #0x10]      | X20 = this.buffer; //P2                 
            // 0x011E0D4C: LDR w21, [x19, #0x1c]      | W21 = this.position; //P2               
            // 0x011E0D50: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
            // 0x011E0D54: TBZ w8, #0, #0x11e0d64     | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x011E0D58: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
            // 0x011E0D5C: CBNZ w8, #0x11e0d64        | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x011E0D60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
            label_5:
            // 0x011E0D64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E0D68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x011E0D6C: MOV x1, x20                | X1 = this.buffer;//m1                   
            // 0x011E0D70: MOV w2, w21                | W2 = this.position;//m1                 
            // 0x011E0D74: BL #0x18d3c44              | X0 = System.BitConverter.ToSingle(value:  0, startIndex:  this.buffer);
            float val_1 = System.BitConverter.ToSingle(value:  0, startIndex:  this.buffer);
            // 0x011E0D78: LDR w8, [x19, #0x1c]       | W8 = this.position; //P2                
            int val_3 = this.position;
            // 0x011E0D7C: ADD w8, w8, #4             | W8 = (this.position + 4);               
            val_3 = val_3 + 4;
            // 0x011E0D80: STR w8, [x19, #0x1c]       | this.position = (this.position + 4);     //  dest_result_addr=1152921509563959292
            this.position = val_3;
            // 0x011E0D84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0D88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0D8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0D90: RET                        |  return (System.Single)val_1;           
            return val_1;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
            label_3:
            // 0x011E0D94: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x011E0D98: MOV x0, x19                | X0 = 1152921509563959264 (0x10000001277787E0);//ML01
            // 0x011E0D9C: BL #0x11e08f0              | X0 = this.ReadBytes(length:  4);        
            System.Byte[] val_2 = this.ReadBytes(length:  4);
            // 0x011E0DA0: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x011E0DA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E0DA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011E0DAC: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x011E0DB0: BL #0x18cf8b8              | System.Array.Reverse(array:  0);        
            System.Array.Reverse(array:  0);
            // 0x011E0DB4: LDR x0, [x20]              | X0 = typeof(System.BitConverter);       
            // 0x011E0DB8: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
            // 0x011E0DBC: TBZ w8, #0, #0x11e0dcc     | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x011E0DC0: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
            // 0x011E0DC4: CBNZ w8, #0x11e0dcc        | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x011E0DC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
            label_7:
            // 0x011E0DCC: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x011E0DD0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0DD4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0DD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E0DDC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x011E0DE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x011E0DE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0DE8: B #0x18d3c44               | return System.BitConverter.ToSingle(value:  0, startIndex:  val_2);
            return System.BitConverter.ToSingle(value:  0, startIndex:  val_2);
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0DEC (18746860), len: 268  VirtAddr: 0x011E0DEC RVA: 0x011E0DEC token: 100664546 methodIndex: 20305 delegateWrapperIndex: 0 methodInvoker: 0
        public double ReadDouble()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x011E0DEC: STP x22, x21, [sp, #-0x30]! | stack[1152921509564206672] = ???;  stack[1152921509564206680] = ???;  //  dest_result_addr=1152921509564206672 |  dest_result_addr=1152921509564206680
            // 0x011E0DF0: STP x20, x19, [sp, #0x10]  | stack[1152921509564206688] = ???;  stack[1152921509564206696] = ???;  //  dest_result_addr=1152921509564206688 |  dest_result_addr=1152921509564206696
            // 0x011E0DF4: STP x29, x30, [sp, #0x20]  | stack[1152921509564206704] = ???;  stack[1152921509564206712] = ???;  //  dest_result_addr=1152921509564206704 |  dest_result_addr=1152921509564206712
            // 0x011E0DF8: ADD x29, sp, #0x20         | X29 = (1152921509564206672 + 32) = 1152921509564206704 (0x10000001277B4E70);
            // 0x011E0DFC: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x011E0E00: LDRB w8, [x20, #0xd0]      | W8 = (bool)static_value_037360D0;       
            // 0x011E0E04: MOV x19, x0                | X19 = 1152921509564218720 (0x10000001277B7D60);//ML01
            // 0x011E0E08: TBNZ w8, #0, #0x11e0e24    | if (static_value_037360D0 == true) goto label_0;
            // 0x011E0E0C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x011E0E10: LDR x8, [x8, #0xc0]        | X8 = 0x2B8FF74;                         
            // 0x011E0E14: LDR w0, [x8]               | W0 = 0x16A1;                            
            // 0x011E0E18: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A1, ????);     
            // 0x011E0E1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x011E0E20: STRB w8, [x20, #0xd0]      | static_value_037360D0 = true;            //  dest_result_addr=57893072
            label_0:
            // 0x011E0E24: ADRP x20, #0x3679000       | X20 = 57118720 (0x3679000);             
            // 0x011E0E28: LDR x20, [x20, #0xe08]     | X20 = 1152921504652320768;              
            // 0x011E0E2C: LDR x0, [x20]              | X0 = typeof(System.BitConverter);       
            val_3 = null;
            // 0x011E0E30: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
            // 0x011E0E34: TBZ w8, #0, #0x11e0e48     | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x011E0E38: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
            // 0x011E0E3C: CBNZ w8, #0x11e0e48        | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x011E0E40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
            // 0x011E0E44: LDR x0, [x20]              | X0 = typeof(System.BitConverter);       
            val_3 = null;
            label_2:
            // 0x011E0E48: LDR x8, [x0, #0xa0]        | X8 = System.BitConverter.__il2cppRuntimeField_static_fields;
            // 0x011E0E4C: LDRB w8, [x8, #1]          | W8 = System.BitConverter.IsLittleEndian;
            // 0x011E0E50: CBZ w8, #0x11e0ea0         | if (System.BitConverter.IsLittleEndian == false) goto label_3;
            if(System.BitConverter.IsLittleEndian == false)
            {
                goto label_3;
            }
            // 0x011E0E54: LDR x20, [x19, #0x10]      | X20 = this.buffer; //P2                 
            // 0x011E0E58: LDR w21, [x19, #0x1c]      | W21 = this.position; //P2               
            // 0x011E0E5C: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
            // 0x011E0E60: TBZ w8, #0, #0x11e0e70     | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x011E0E64: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
            // 0x011E0E68: CBNZ w8, #0x11e0e70        | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x011E0E6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
            label_5:
            // 0x011E0E70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E0E74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x011E0E78: MOV x1, x20                | X1 = this.buffer;//m1                   
            // 0x011E0E7C: MOV w2, w21                | W2 = this.position;//m1                 
            // 0x011E0E80: BL #0x18d31a0              | X0 = System.BitConverter.ToDouble(value:  0, startIndex:  this.buffer);
            double val_1 = System.BitConverter.ToDouble(value:  0, startIndex:  this.buffer);
            // 0x011E0E84: LDR w8, [x19, #0x1c]       | W8 = this.position; //P2                
            int val_3 = this.position;
            // 0x011E0E88: ADD w8, w8, #8             | W8 = (this.position + 8);               
            val_3 = val_3 + 8;
            // 0x011E0E8C: STR w8, [x19, #0x1c]       | this.position = (this.position + 8);     //  dest_result_addr=1152921509564218748
            this.position = val_3;
            // 0x011E0E90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0E94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0E98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0E9C: RET                        |  return (System.Double)val_1;           
            return val_1;
            //  |  // // {name=val_0, type=System.Double, size=8, nSRN=0 }
            label_3:
            // 0x011E0EA0: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x011E0EA4: MOV x0, x19                | X0 = 1152921509564218720 (0x10000001277B7D60);//ML01
            // 0x011E0EA8: BL #0x11e08f0              | X0 = this.ReadBytes(length:  8);        
            System.Byte[] val_2 = this.ReadBytes(length:  8);
            // 0x011E0EAC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x011E0EB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E0EB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011E0EB8: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x011E0EBC: BL #0x18cf8b8              | System.Array.Reverse(array:  0);        
            System.Array.Reverse(array:  0);
            // 0x011E0EC0: LDR x0, [x20]              | X0 = typeof(System.BitConverter);       
            // 0x011E0EC4: LDRB w8, [x0, #0x10a]      | W8 = System.BitConverter.__il2cppRuntimeField_10A;
            // 0x011E0EC8: TBZ w8, #0, #0x11e0ed8     | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x011E0ECC: LDR w8, [x0, #0xbc]        | W8 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
            // 0x011E0ED0: CBNZ w8, #0x11e0ed8        | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x011E0ED4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
            label_7:
            // 0x011E0ED8: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x011E0EDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0EE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011E0EE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011E0EE8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x011E0EEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x011E0EF0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011E0EF4: B #0x18d31a0               | return System.BitConverter.ToDouble(value:  0, startIndex:  val_2);
            return System.BitConverter.ToDouble(value:  0, startIndex:  val_2);
        
        }
    
    }

}
