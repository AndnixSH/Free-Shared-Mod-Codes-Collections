using UnityEngine;
private enum PluginMihua.BigPayType
{
    // Fields
    mihua = 1
    ,xima = 2
    ,xima_new = 3
    

}
