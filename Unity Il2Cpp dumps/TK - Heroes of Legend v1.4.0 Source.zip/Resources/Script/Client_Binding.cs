using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class Client_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00A1DBA8 (10607528), len: 8  VirtAddr: 0x00A1DBA8 RVA: 0x00A1DBA8 token: 100664466 methodIndex: 30513 delegateWrapperIndex: 0 methodInvoker: 0
        public Client_Binding()
        {
            //
            // Disasemble & Code
            // 0x00A1DBA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DBAC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1DBB0 (10607536), len: 3648  VirtAddr: 0x00A1DBB0 RVA: 0x00A1DBB0 token: 100664467 methodIndex: 30514 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_45;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_46;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_47;
            // 0x00A1DBB0: STP x28, x27, [sp, #-0x60]! | stack[1152921510153388720] = ???;  stack[1152921510153388728] = ???;  //  dest_result_addr=1152921510153388720 |  dest_result_addr=1152921510153388728
            // 0x00A1DBB4: STP x26, x25, [sp, #0x10]  | stack[1152921510153388736] = ???;  stack[1152921510153388744] = ???;  //  dest_result_addr=1152921510153388736 |  dest_result_addr=1152921510153388744
            // 0x00A1DBB8: STP x24, x23, [sp, #0x20]  | stack[1152921510153388752] = ???;  stack[1152921510153388760] = ???;  //  dest_result_addr=1152921510153388752 |  dest_result_addr=1152921510153388760
            // 0x00A1DBBC: STP x22, x21, [sp, #0x30]  | stack[1152921510153388768] = ???;  stack[1152921510153388776] = ???;  //  dest_result_addr=1152921510153388768 |  dest_result_addr=1152921510153388776
            // 0x00A1DBC0: STP x20, x19, [sp, #0x40]  | stack[1152921510153388784] = ???;  stack[1152921510153388792] = ???;  //  dest_result_addr=1152921510153388784 |  dest_result_addr=1152921510153388792
            // 0x00A1DBC4: STP x29, x30, [sp, #0x50]  | stack[1152921510153388800] = ???;  stack[1152921510153388808] = ???;  //  dest_result_addr=1152921510153388800 |  dest_result_addr=1152921510153388808
            // 0x00A1DBC8: ADD x29, sp, #0x50         | X29 = (1152921510153388720 + 80) = 1152921510153388800 (0x100000014A998300);
            // 0x00A1DBCC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A1DBD0: LDRB w8, [x20, #0x140]     | W8 = (bool)static_value_03733140;       
            // 0x00A1DBD4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A1DBD8: TBNZ w8, #0, #0xa1dbf4     | if (static_value_03733140 == true) goto label_0;
            // 0x00A1DBDC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00A1DBE0: LDR x8, [x8, #0x488]       | X8 = 0x2B90B40;                         
            // 0x00A1DBE4: LDR w0, [x8]               | W0 = 0x1994;                            
            // 0x00A1DBE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1994, ????);     
            // 0x00A1DBEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1DBF0: STRB w8, [x20, #0x140]     | static_value_03733140 = true;            //  dest_result_addr=57880896
            label_0:
            // 0x00A1DBF4: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00A1DBF8: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x00A1DBFC: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00A1DC00: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00A1DC04: LDR x8, [x8, #0x520]       | X8 = 1152921504912277504;               
            // 0x00A1DC08: LDR x20, [x8]              | X20 = typeof(Client);                   
            // 0x00A1DC0C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1DC10: TBZ w8, #0, #0xa1dc20      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00A1DC14: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1DC18: CBNZ w8, #0xa1dc20         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00A1DC1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00A1DC20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1DC24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1DC28: MOV x1, x20                | X1 = 1152921504912277504 (0x1000000012348000);//ML01
            // 0x00A1DC2C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1DC30: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x00A1DC34: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x00A1DC38: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00A1DC3C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1DC40: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DC44: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1DC48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DC4C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DC50: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1DC54: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DC58: CBNZ x20, #0xa1dc60        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00A1DC5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x00A1DC60: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00A1DC64: LDR x8, [x8, #0xe18]       | X8 = (string**)(1152921510153277680)("get_IsNetConnected");
            // 0x00A1DC68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DC6C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1DC70: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1DC74: LDR x1, [x8]               | X1 = "get_IsNetConnected";              
            // 0x00A1DC78: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1DC7C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DC80: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1DC84: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_IsNetConnected", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_IsNetConnected", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1DC88: ADRP x24, #0x3601000       | X24 = 56627200 (0x3601000);             
            // 0x00A1DC8C: LDR x24, [x24, #0xf88]     | X24 = 1152921504784003072;              
            // 0x00A1DC90: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00A1DC94: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DC98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DC9C: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache0;
            val_35 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache0;
            // 0x00A1DCA0: CBNZ x22, #0xa1dcec        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_35 != null)
            {
                goto label_4;
            }
            // 0x00A1DCA4: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x00A1DCA8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1DCAC: LDR x8, [x8, #0x758]       | X8 = 1152921510153281888;               
            // 0x00A1DCB0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1DCB4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::get_IsNetConnected_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1DCB8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x00A1DCBC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1DCC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DCC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DCC8: MOV x2, x22                | X2 = 1152921510153281888 (0x100000014A97E160);//ML01
            // 0x00A1DCCC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_3;
            // 0x00A1DCD0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::get_IsNetConnected_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::get_IsNetConnected_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1DCD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DCD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DCDC: STR x23, [x8]              | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007168
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache0 = val_36;
            // 0x00A1DCE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DCE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DCE8: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_35 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache0;
            label_4:
            // 0x00A1DCEC: CBNZ x19, #0xa1dcf4        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00A1DCF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::get_IsNetConnected_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x00A1DCF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DCF8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1DCFC: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00A1DD00: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1DD04: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_35);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_35);
            // 0x00A1DD08: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1DD0C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DD10: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1DD14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DD18: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DD1C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1DD20: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DD24: CBNZ x20, #0xa1dd2c        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00A1DD28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x00A1DD2C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00A1DD30: LDR x8, [x8, #0xae8]       | X8 = (string**)(1152921510153282912)("CloseNetState");
            // 0x00A1DD34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DD38: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1DD3C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1DD40: LDR x1, [x8]               | X1 = "CloseNetState";                   
            // 0x00A1DD44: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1DD48: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DD4C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1DD50: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "CloseNetState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "CloseNetState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1DD54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DD58: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00A1DD5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DD60: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache1;
            val_37 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache1;
            // 0x00A1DD64: CBNZ x22, #0xa1ddb0        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache1 != null) goto label_7;
            if(val_37 != null)
            {
                goto label_7;
            }
            // 0x00A1DD68: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00A1DD6C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1DD70: LDR x8, [x8, #0x538]       | X8 = 1152921510153287104;               
            // 0x00A1DD74: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1DD78: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::CloseNetState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1DD7C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x00A1DD80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1DD84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DD88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DD8C: MOV x2, x22                | X2 = 1152921510153287104 (0x100000014A97F5C0);//ML01
            // 0x00A1DD90: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_5;
            // 0x00A1DD94: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::CloseNetState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::CloseNetState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1DD98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DD9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DDA0: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007176
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache1 = val_36;
            // 0x00A1DDA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DDA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DDAC: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_37 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache1;
            label_7:
            // 0x00A1DDB0: CBNZ x19, #0xa1ddb8        | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x00A1DDB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::CloseNetState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_8:
            // 0x00A1DDB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DDBC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1DDC0: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00A1DDC4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1DDC8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_37);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_37);
            // 0x00A1DDCC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1DDD0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DDD4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1DDD8: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00A1DDDC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DDE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1DDE4: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x00A1DDE8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00A1DDEC: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            // 0x00A1DDF0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DDF4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1DDF8: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00A1DDFC: TBZ w9, #0, #0xa1de10      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00A1DE00: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1DE04: CBNZ w9, #0xa1de10         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00A1DE08: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1DE0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x00A1DE10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1DE14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1DE18: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1DE1C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1DE20: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00A1DE24: CBNZ x21, #0xa1de2c        | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x00A1DE28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_11:
            // 0x00A1DE2C: CBZ x22, #0xa1de50         | if (val_6 == null) goto label_13;       
            if(val_6 == null)
            {
                goto label_13;
            }
            // 0x00A1DE30: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1DE34: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x00A1DE38: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1DE3C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x00A1DE40: CBNZ x0, #0xa1de50         | if (val_6 != null) goto label_13;       
            if(val_6 != null)
            {
                goto label_13;
            }
            // 0x00A1DE44: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x00A1DE48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DE4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_13:
            // 0x00A1DE50: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1DE54: CBNZ w8, #0xa1de64         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_14;
            // 0x00A1DE58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x00A1DE5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DE60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_14:
            // 0x00A1DE64: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;
            // 0x00A1DE68: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00A1DE6C: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x00A1DE70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1DE74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1DE78: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x00A1DE7C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1DE80: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00A1DE84: CBZ x22, #0xa1dea8         | if (val_7 == null) goto label_16;       
            if(val_7 == null)
            {
                goto label_16;
            }
            // 0x00A1DE88: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1DE8C: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x00A1DE90: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1DE94: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x00A1DE98: CBNZ x0, #0xa1dea8         | if (val_7 != null) goto label_16;       
            if(val_7 != null)
            {
                goto label_16;
            }
            // 0x00A1DE9C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x00A1DEA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DEA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_16:
            // 0x00A1DEA8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1DEAC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00A1DEB0: B.HI #0xa1dec0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_17;
            // 0x00A1DEB4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x00A1DEB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DEBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_17:
            // 0x00A1DEC0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;
            // 0x00A1DEC4: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00A1DEC8: LDR x8, [x8, #0xf68]       | X8 = 1152921504912330752;               
            // 0x00A1DECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1DED0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1DED4: LDR x1, [x8]               | X1 = typeof(Client.ResponseCallBack);   
            // 0x00A1DED8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1DEDC: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00A1DEE0: CBZ x22, #0xa1df04         | if (val_8 == null) goto label_19;       
            if(val_8 == null)
            {
                goto label_19;
            }
            // 0x00A1DEE4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1DEE8: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x00A1DEEC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1DEF0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x00A1DEF4: CBNZ x0, #0xa1df04         | if (val_8 != null) goto label_19;       
            if(val_8 != null)
            {
                goto label_19;
            }
            // 0x00A1DEF8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x00A1DEFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DF00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_19:
            // 0x00A1DF04: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1DF08: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00A1DF0C: B.HI #0xa1df1c             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_20;
            // 0x00A1DF10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x00A1DF14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DF18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_20:
            // 0x00A1DF1C: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_8;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_8;
            // 0x00A1DF20: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00A1DF24: LDR x8, [x8, #0xaf8]       | X8 = 1152921504912384000;               
            // 0x00A1DF28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1DF2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1DF30: LDR x1, [x8]               | X1 = typeof(Client.PushCallBack);       
            // 0x00A1DF34: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1DF38: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00A1DF3C: CBZ x22, #0xa1df60         | if (val_9 == null) goto label_22;       
            if(val_9 == null)
            {
                goto label_22;
            }
            // 0x00A1DF40: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1DF44: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00A1DF48: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1DF4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00A1DF50: CBNZ x0, #0xa1df60         | if (val_9 != null) goto label_22;       
            if(val_9 != null)
            {
                goto label_22;
            }
            // 0x00A1DF54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x00A1DF58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DF5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_22:
            // 0x00A1DF60: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1DF64: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00A1DF68: B.HI #0xa1df78             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_23;
            // 0x00A1DF6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x00A1DF70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DF74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_23:
            // 0x00A1DF78: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_9;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_9;
            // 0x00A1DF7C: CBNZ x20, #0xa1df84        | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x00A1DF80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_24:
            // 0x00A1DF84: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00A1DF88: LDR x8, [x8, #0xf68]       | X8 = (string**)(1152921510153304512)("Run");
            // 0x00A1DF8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DF90: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1DF94: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1DF98: LDR x1, [x8]               | X1 = "Run";                             
            // 0x00A1DF9C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1DFA0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1DFA4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1DFA8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Run", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "Run", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1DFAC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DFB0: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x00A1DFB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DFB8: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache2;
            val_38 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache2;
            // 0x00A1DFBC: CBNZ x22, #0xa1e008        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache2 != null) goto label_25;
            if(val_38 != null)
            {
                goto label_25;
            }
            // 0x00A1DFC0: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00A1DFC4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1DFC8: LDR x8, [x8, #0x660]       | X8 = 1152921510153308688;               
            // 0x00A1DFCC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1DFD0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Run_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1DFD4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x00A1DFD8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1DFDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1DFE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1DFE4: MOV x2, x22                | X2 = 1152921510153308688 (0x100000014A984A10);//ML01
            // 0x00A1DFE8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_11;
            // 0x00A1DFEC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Run_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Run_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1DFF0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1DFF4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1DFF8: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007184
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache2 = val_36;
            // 0x00A1DFFC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E000: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E004: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_38 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache2;
            label_25:
            // 0x00A1E008: CBNZ x19, #0xa1e010        | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x00A1E00C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Run_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_26:
            // 0x00A1E010: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E014: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E018: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x00A1E01C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E020: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_38);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_38);
            // 0x00A1E024: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1E028: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E02C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1E030: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00A1E034: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E038: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1E03C: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00A1E040: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00A1E044: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E048: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1E04C: TBZ w9, #0, #0xa1e060      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x00A1E050: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1E054: CBNZ w9, #0xa1e060         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x00A1E058: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1E05C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x00A1E060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E064: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E068: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1E06C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E070: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x00A1E074: CBNZ x21, #0xa1e07c        | if ( != null) goto label_29;            
            if(null != null)
            {
                goto label_29;
            }
            // 0x00A1E078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_29:
            // 0x00A1E07C: CBZ x22, #0xa1e0a0         | if (val_12 == null) goto label_31;      
            if(val_12 == null)
            {
                goto label_31;
            }
            // 0x00A1E080: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E084: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x00A1E088: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E08C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x00A1E090: CBNZ x0, #0xa1e0a0         | if (val_12 != null) goto label_31;      
            if(val_12 != null)
            {
                goto label_31;
            }
            // 0x00A1E094: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x00A1E098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E09C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_31:
            // 0x00A1E0A0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E0A4: CBNZ w8, #0xa1e0b4         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_32;
            // 0x00A1E0A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x00A1E0AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E0B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_32:
            // 0x00A1E0B4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_12;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_12;
            // 0x00A1E0B8: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00A1E0BC: LDR x8, [x8, #0xde8]       | X8 = 1152921504861265920;               
            // 0x00A1E0C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E0C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E0C8: LDR x1, [x8]               | X1 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00A1E0CC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E0D0: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00A1E0D4: CBZ x22, #0xa1e0f8         | if (val_13 == null) goto label_34;      
            if(val_13 == null)
            {
                goto label_34;
            }
            // 0x00A1E0D8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E0DC: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x00A1E0E0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E0E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x00A1E0E8: CBNZ x0, #0xa1e0f8         | if (val_13 != null) goto label_34;      
            if(val_13 != null)
            {
                goto label_34;
            }
            // 0x00A1E0EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x00A1E0F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E0F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_34:
            // 0x00A1E0F8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E0FC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00A1E100: B.HI #0xa1e110             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_35;
            // 0x00A1E104: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x00A1E108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E10C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_35:
            // 0x00A1E110: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_13;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_13;
            // 0x00A1E114: CBNZ x20, #0xa1e11c        | if (val_1 != null) goto label_36;       
            if(val_1 != null)
            {
                goto label_36;
            }
            // 0x00A1E118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_36:
            // 0x00A1E11C: ADRP x28, #0x3650000       | X28 = 56950784 (0x3650000);             
            // 0x00A1E120: LDR x28, [x28, #0x2b0]     | X28 = (string**)(1152921510153317904)("Request");
            // 0x00A1E124: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E128: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1E12C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E130: LDR x1, [x28]              | X1 = "Request";                         
            // 0x00A1E134: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E138: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E13C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1E140: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Request", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "Request", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1E144: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E148: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00A1E14C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E150: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache3;
            val_39 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache3;
            // 0x00A1E154: CBNZ x22, #0xa1e1a0        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache3 != null) goto label_37;
            if(val_39 != null)
            {
                goto label_37;
            }
            // 0x00A1E158: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00A1E15C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1E160: LDR x8, [x8, #0xc40]       | X8 = 1152921510153322096;               
            // 0x00A1E164: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1E168: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1E16C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x00A1E170: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1E174: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E178: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E17C: MOV x2, x22                | X2 = 1152921510153322096 (0x100000014A987E70);//ML01
            // 0x00A1E180: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_15;
            // 0x00A1E184: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1E188: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E18C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E190: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007192
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache3 = val_36;
            // 0x00A1E194: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E198: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E19C: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_39 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache3;
            label_37:
            // 0x00A1E1A0: CBNZ x19, #0xa1e1a8        | if (X1 != 0) goto label_38;             
            if(X1 != 0)
            {
                goto label_38;
            }
            // 0x00A1E1A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_38:
            // 0x00A1E1A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E1AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E1B0: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x00A1E1B4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E1B8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_39);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_39);
            // 0x00A1E1BC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1E1C0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E1C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1E1C8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00A1E1CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E1D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1E1D4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00A1E1D8: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00A1E1DC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E1E0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1E1E4: TBZ w9, #0, #0xa1e1f8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_40;
            // 0x00A1E1E8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1E1EC: CBNZ w9, #0xa1e1f8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
            // 0x00A1E1F0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1E1F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_40:
            // 0x00A1E1F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E1FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E200: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1E204: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E208: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x00A1E20C: CBNZ x21, #0xa1e214        | if ( != null) goto label_41;            
            if(null != null)
            {
                goto label_41;
            }
            // 0x00A1E210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_41:
            // 0x00A1E214: CBZ x22, #0xa1e238         | if (val_16 == null) goto label_43;      
            if(val_16 == null)
            {
                goto label_43;
            }
            // 0x00A1E218: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E21C: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x00A1E220: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E224: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x00A1E228: CBNZ x0, #0xa1e238         | if (val_16 != null) goto label_43;      
            if(val_16 != null)
            {
                goto label_43;
            }
            // 0x00A1E22C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x00A1E230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E234: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_43:
            // 0x00A1E238: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E23C: CBNZ w8, #0xa1e24c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_44;
            // 0x00A1E240: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x00A1E244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E248: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_44:
            // 0x00A1E24C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;
            // 0x00A1E250: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00A1E254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E258: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E25C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E260: MOV x22, x0                | X22 = val_17;//m1                       
            // 0x00A1E264: CBZ x22, #0xa1e288         | if (val_17 == null) goto label_46;      
            if(val_17 == null)
            {
                goto label_46;
            }
            // 0x00A1E268: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E26C: MOV x0, x22                | X0 = val_17;//m1                        
            // 0x00A1E270: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E274: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x00A1E278: CBNZ x0, #0xa1e288         | if (val_17 != null) goto label_46;      
            if(val_17 != null)
            {
                goto label_46;
            }
            // 0x00A1E27C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x00A1E280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E284: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_46:
            // 0x00A1E288: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E28C: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00A1E290: B.HI #0xa1e2a0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_47;
            // 0x00A1E294: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x00A1E298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E29C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_47:
            // 0x00A1E2A0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_17;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_17;
            // 0x00A1E2A4: CBNZ x20, #0xa1e2ac        | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x00A1E2A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_48:
            // 0x00A1E2AC: LDR x1, [x28]              | X1 = "Request";                         
            // 0x00A1E2B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E2B4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1E2B8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E2BC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E2C0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E2C4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1E2C8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Request", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_18 = val_1.GetMethod(name:  "Request", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1E2CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E2D0: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x00A1E2D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E2D8: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache4;
            val_40 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache4;
            // 0x00A1E2DC: CBNZ x22, #0xa1e328        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache4 != null) goto label_49;
            if(val_40 != null)
            {
                goto label_49;
            }
            // 0x00A1E2E0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00A1E2E4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1E2E8: LDR x8, [x8, #0x8c8]       | X8 = 1152921510153335408;               
            // 0x00A1E2EC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1E2F0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1E2F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_19 = null;
            // 0x00A1E2F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1E2FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E300: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E304: MOV x2, x22                | X2 = 1152921510153335408 (0x100000014A98B270);//ML01
            // 0x00A1E308: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_19;
            // 0x00A1E30C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1E310: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E314: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E318: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007200
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache4 = val_36;
            // 0x00A1E31C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E320: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E324: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_40 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache4;
            label_49:
            // 0x00A1E328: CBNZ x19, #0xa1e330        | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x00A1E32C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Request_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_50:
            // 0x00A1E330: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E334: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E338: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x00A1E33C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E340: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_40);
            X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_40);
            // 0x00A1E344: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1E348: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E34C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1E350: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00A1E354: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E358: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1E35C: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00A1E360: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00A1E364: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E368: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1E36C: TBZ w9, #0, #0xa1e380      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_52;
            // 0x00A1E370: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1E374: CBNZ w9, #0xa1e380         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
            // 0x00A1E378: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1E37C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_52:
            // 0x00A1E380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E388: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1E38C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_20 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E390: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x00A1E394: CBNZ x21, #0xa1e39c        | if ( != null) goto label_53;            
            if(null != null)
            {
                goto label_53;
            }
            // 0x00A1E398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_53:
            // 0x00A1E39C: CBZ x22, #0xa1e3c0         | if (val_20 == null) goto label_55;      
            if(val_20 == null)
            {
                goto label_55;
            }
            // 0x00A1E3A0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E3A4: MOV x0, x22                | X0 = val_20;//m1                        
            // 0x00A1E3A8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E3AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
            // 0x00A1E3B0: CBNZ x0, #0xa1e3c0         | if (val_20 != null) goto label_55;      
            if(val_20 != null)
            {
                goto label_55;
            }
            // 0x00A1E3B4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
            // 0x00A1E3B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E3BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_55:
            // 0x00A1E3C0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E3C4: CBNZ w8, #0xa1e3d4         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_56;
            // 0x00A1E3C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
            // 0x00A1E3CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E3D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_56:
            // 0x00A1E3D4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_20;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_20;
            // 0x00A1E3D8: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00A1E3DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E3E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E3E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_21 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E3E8: MOV x22, x0                | X22 = val_21;//m1                       
            // 0x00A1E3EC: CBZ x22, #0xa1e410         | if (val_21 == null) goto label_58;      
            if(val_21 == null)
            {
                goto label_58;
            }
            // 0x00A1E3F0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E3F4: MOV x0, x22                | X0 = val_21;//m1                        
            // 0x00A1E3F8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E3FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_21, ????);     
            // 0x00A1E400: CBNZ x0, #0xa1e410         | if (val_21 != null) goto label_58;      
            if(val_21 != null)
            {
                goto label_58;
            }
            // 0x00A1E404: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_21, ????);     
            // 0x00A1E408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E40C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_58:
            // 0x00A1E410: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E414: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00A1E418: B.HI #0xa1e428             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_59;
            // 0x00A1E41C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
            // 0x00A1E420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E424: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_59:
            // 0x00A1E428: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_21;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_21;
            // 0x00A1E42C: CBNZ x20, #0xa1e434        | if (val_1 != null) goto label_60;       
            if(val_1 != null)
            {
                goto label_60;
            }
            // 0x00A1E430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_60:
            // 0x00A1E434: ADRP x28, #0x35bb000       | X28 = 56340480 (0x35BB000);             
            // 0x00A1E438: LDR x28, [x28, #0xc0]      | X28 = (string**)(1152921510153344624)("Notify");
            // 0x00A1E43C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E440: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1E444: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E448: LDR x1, [x28]              | X1 = "Notify";                          
            // 0x00A1E44C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E450: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E454: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1E458: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Notify", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_22 = val_1.GetMethod(name:  "Notify", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1E45C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E460: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x00A1E464: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E468: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache5;
            val_41 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache5;
            // 0x00A1E46C: CBNZ x22, #0xa1e4b8        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache5 != null) goto label_61;
            if(val_41 != null)
            {
                goto label_61;
            }
            // 0x00A1E470: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x00A1E474: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1E478: LDR x8, [x8, #0x2a0]       | X8 = 1152921510153348800;               
            // 0x00A1E47C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1E480: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1E484: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23 = null;
            // 0x00A1E488: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1E48C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E490: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E494: MOV x2, x22                | X2 = 1152921510153348800 (0x100000014A98E6C0);//ML01
            // 0x00A1E498: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_23;
            // 0x00A1E49C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1E4A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E4A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E4A8: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007208
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache5 = val_36;
            // 0x00A1E4AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E4B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E4B4: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_41 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache5;
            label_61:
            // 0x00A1E4B8: CBNZ x19, #0xa1e4c0        | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x00A1E4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_62:
            // 0x00A1E4C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E4C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E4C8: MOV x1, x21                | X1 = val_22;//m1                        
            // 0x00A1E4CC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E4D0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_41);
            X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_41);
            // 0x00A1E4D4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1E4D8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E4DC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1E4E0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00A1E4E4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E4E8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1E4EC: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00A1E4F0: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00A1E4F4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E4F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1E4FC: TBZ w9, #0, #0xa1e510      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_64;
            // 0x00A1E500: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1E504: CBNZ w9, #0xa1e510         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_64;
            // 0x00A1E508: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1E50C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_64:
            // 0x00A1E510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E518: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1E51C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_24 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E520: MOV x22, x0                | X22 = val_24;//m1                       
            // 0x00A1E524: CBNZ x21, #0xa1e52c        | if ( != null) goto label_65;            
            if(null != null)
            {
                goto label_65;
            }
            // 0x00A1E528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_65:
            // 0x00A1E52C: CBZ x22, #0xa1e550         | if (val_24 == null) goto label_67;      
            if(val_24 == null)
            {
                goto label_67;
            }
            // 0x00A1E530: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E534: MOV x0, x22                | X0 = val_24;//m1                        
            // 0x00A1E538: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E53C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_24, ????);     
            // 0x00A1E540: CBNZ x0, #0xa1e550         | if (val_24 != null) goto label_67;      
            if(val_24 != null)
            {
                goto label_67;
            }
            // 0x00A1E544: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_24, ????);     
            // 0x00A1E548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E54C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            label_67:
            // 0x00A1E550: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E554: CBNZ w8, #0xa1e564         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_68;
            // 0x00A1E558: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_24, ????);     
            // 0x00A1E55C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E560: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            label_68:
            // 0x00A1E564: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_24;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_24;
            // 0x00A1E568: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00A1E56C: LDR x8, [x8, #0xde8]       | X8 = 1152921504861265920;               
            // 0x00A1E570: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1E574: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1E578: LDR x1, [x8]               | X1 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00A1E57C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_25 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1E580: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x00A1E584: CBZ x22, #0xa1e5a8         | if (val_25 == null) goto label_70;      
            if(val_25 == null)
            {
                goto label_70;
            }
            // 0x00A1E588: LDR x8, [x21]              | X8 = ;                                  
            // 0x00A1E58C: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x00A1E590: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00A1E594: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x00A1E598: CBNZ x0, #0xa1e5a8         | if (val_25 != null) goto label_70;      
            if(val_25 != null)
            {
                goto label_70;
            }
            // 0x00A1E59C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_25, ????);     
            // 0x00A1E5A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E5A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_70:
            // 0x00A1E5A8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00A1E5AC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00A1E5B0: B.HI #0xa1e5c0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_71;
            // 0x00A1E5B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_25, ????);     
            // 0x00A1E5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E5BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_71:
            // 0x00A1E5C0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_25;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_25;
            // 0x00A1E5C4: CBNZ x20, #0xa1e5cc        | if (val_1 != null) goto label_72;       
            if(val_1 != null)
            {
                goto label_72;
            }
            // 0x00A1E5C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_72:
            // 0x00A1E5CC: LDR x1, [x28]              | X1 = "Notify";                          
            // 0x00A1E5D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E5D4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1E5D8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E5DC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E5E0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E5E4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1E5E8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Notify", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_26 = val_1.GetMethod(name:  "Notify", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1E5EC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E5F0: MOV x21, x0                | X21 = val_26;//m1                       
            // 0x00A1E5F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E5F8: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache6;
            val_42 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache6;
            // 0x00A1E5FC: CBNZ x22, #0xa1e648        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache6 != null) goto label_73;
            if(val_42 != null)
            {
                goto label_73;
            }
            // 0x00A1E600: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x00A1E604: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1E608: LDR x8, [x8, #0x470]       | X8 = 1152921510153362112;               
            // 0x00A1E60C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1E610: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1E614: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27 = null;
            // 0x00A1E618: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1E61C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E620: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E624: MOV x2, x22                | X2 = 1152921510153362112 (0x100000014A991AC0);//ML01
            // 0x00A1E628: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_27;
            // 0x00A1E62C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1E630: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E634: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E638: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007216
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache6 = val_36;
            // 0x00A1E63C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E640: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E644: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_42 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache6;
            label_73:
            // 0x00A1E648: CBNZ x19, #0xa1e650        | if (X1 != 0) goto label_74;             
            if(X1 != 0)
            {
                goto label_74;
            }
            // 0x00A1E64C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Notify_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_74:
            // 0x00A1E650: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E654: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E658: MOV x1, x21                | X1 = val_26;//m1                        
            // 0x00A1E65C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E660: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_42);
            X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_42);
            // 0x00A1E664: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1E668: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E66C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1E670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E674: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E678: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1E67C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E680: CBNZ x20, #0xa1e688        | if (val_1 != null) goto label_75;       
            if(val_1 != null)
            {
                goto label_75;
            }
            // 0x00A1E684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_75:
            // 0x00A1E688: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x00A1E68C: LDR x8, [x8, #0x730]       | X8 = (string**)(1152921510153363136)("OnDisconnect");
            // 0x00A1E690: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E694: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1E698: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E69C: LDR x1, [x8]               | X1 = "OnDisconnect";                    
            // 0x00A1E6A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E6A4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E6A8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1E6AC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnDisconnect", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_28 = val_1.GetMethod(name:  "OnDisconnect", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1E6B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E6B4: MOV x21, x0                | X21 = val_28;//m1                       
            // 0x00A1E6B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E6BC: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache7;
            val_43 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache7;
            // 0x00A1E6C0: CBNZ x22, #0xa1e70c        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache7 != null) goto label_76;
            if(val_43 != null)
            {
                goto label_76;
            }
            // 0x00A1E6C4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00A1E6C8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1E6CC: LDR x8, [x8, #0xd70]       | X8 = 1152921510153367328;               
            // 0x00A1E6D0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1E6D4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::OnDisconnect_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1E6D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29 = null;
            // 0x00A1E6DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1E6E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E6E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E6E8: MOV x2, x22                | X2 = 1152921510153367328 (0x100000014A992F20);//ML01
            // 0x00A1E6EC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_29;
            // 0x00A1E6F0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::OnDisconnect_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::OnDisconnect_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1E6F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E6F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E6FC: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007224
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache7 = val_36;
            // 0x00A1E700: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E704: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E708: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_43 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache7;
            label_76:
            // 0x00A1E70C: CBNZ x19, #0xa1e714        | if (X1 != 0) goto label_77;             
            if(X1 != 0)
            {
                goto label_77;
            }
            // 0x00A1E710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::OnDisconnect_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_77:
            // 0x00A1E714: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E718: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E71C: MOV x1, x21                | X1 = val_28;//m1                        
            // 0x00A1E720: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E724: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_28, func:  val_43);
            X1.RegisterCLRMethodRedirection(mi:  val_28, func:  val_43);
            // 0x00A1E728: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00A1E72C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E730: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00A1E734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E738: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E73C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00A1E740: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E744: CBNZ x20, #0xa1e74c        | if (val_1 != null) goto label_78;       
            if(val_1 != null)
            {
                goto label_78;
            }
            // 0x00A1E748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_78:
            // 0x00A1E74C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00A1E750: LDR x8, [x8, #0x8d8]       | X8 = (string**)(1152921510153368352)("Logout");
            // 0x00A1E754: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E758: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1E75C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E760: LDR x1, [x8]               | X1 = "Logout";                          
            // 0x00A1E764: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E768: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00A1E76C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00A1E770: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Logout", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_30 = val_1.GetMethod(name:  "Logout", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00A1E774: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E778: MOV x21, x0                | X21 = val_30;//m1                       
            // 0x00A1E77C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E780: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache8;
            val_44 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache8;
            // 0x00A1E784: CBNZ x22, #0xa1e7d0        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache8 != null) goto label_79;
            if(val_44 != null)
            {
                goto label_79;
            }
            // 0x00A1E788: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00A1E78C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00A1E790: LDR x8, [x8, #0x350]       | X8 = 1152921510153372528;               
            // 0x00A1E794: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00A1E798: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Logout_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00A1E79C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31 = null;
            // 0x00A1E7A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00A1E7A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E7A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E7AC: MOV x2, x22                | X2 = 1152921510153372528 (0x100000014A994370);//ML01
            // 0x00A1E7B0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_36 = val_31;
            // 0x00A1E7B4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Logout_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Logout_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00A1E7B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E7BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E7C0: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504784007232
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache8 = val_36;
            // 0x00A1E7C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E7C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E7CC: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_44 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache8;
            label_79:
            // 0x00A1E7D0: CBNZ x19, #0xa1e7d8        | if (X1 != 0) goto label_80;             
            if(X1 != 0)
            {
                goto label_80;
            }
            // 0x00A1E7D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Client_Binding::Logout_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_80:
            // 0x00A1E7D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E7DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E7E0: MOV x1, x21                | X1 = val_30;//m1                        
            // 0x00A1E7E4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00A1E7E8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_44);
            X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_44);
            // 0x00A1E7EC: CBNZ x20, #0xa1e7f4        | if (val_1 != null) goto label_81;       
            if(val_1 != null)
            {
                goto label_81;
            }
            // 0x00A1E7F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_81:
            // 0x00A1E7F4: ADRP x9, #0x362e000        | X9 = 56811520 (0x362E000);              
            // 0x00A1E7F8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00A1E7FC: LDR x9, [x9, #0x780]       | X9 = (string**)(1152921510153373552)("LOGIN_SERVER");
            // 0x00A1E800: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E804: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E808: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00A1E80C: LDR x1, [x9]               | X1 = "LOGIN_SERVER";                    
            // 0x00A1E810: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00A1E814: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00A1E818: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E81C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00A1E820: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E824: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache9;
            val_45 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache9;
            // 0x00A1E828: CBNZ x22, #0xa1e874        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache9 != null) goto label_82;
            if(val_45 != null)
            {
                goto label_82;
            }
            // 0x00A1E82C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00A1E830: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00A1E834: LDR x8, [x8, #0xd10]       | X8 = 1152921510153373648;               
            // 0x00A1E838: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00A1E83C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_LOGIN_SERVER_0(ref object o);
            // 0x00A1E840: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32 = null;
            // 0x00A1E844: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00A1E848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E84C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E850: MOV x2, x22                | X2 = 1152921510153373648 (0x100000014A9947D0);//ML01
            // 0x00A1E854: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_36 = val_32;
            // 0x00A1E858: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_LOGIN_SERVER_0(ref object o));
            val_32 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_LOGIN_SERVER_0(ref object o));
            // 0x00A1E85C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E860: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E864: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784007240
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache9 = val_36;
            // 0x00A1E868: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E86C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E870: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_45 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cache9;
            label_82:
            // 0x00A1E874: CBNZ x19, #0xa1e87c        | if (X1 != 0) goto label_83;             
            if(X1 != 0)
            {
                goto label_83;
            }
            // 0x00A1E878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_LOGIN_SERVER_0(ref object o)), ????);
            label_83:
            // 0x00A1E87C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E880: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E884: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00A1E888: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00A1E88C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_45);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_45);
            // 0x00A1E890: CBNZ x20, #0xa1e898        | if (val_1 != null) goto label_84;       
            if(val_1 != null)
            {
                goto label_84;
            }
            // 0x00A1E894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_84:
            // 0x00A1E898: ADRP x9, #0x35f4000        | X9 = 56573952 (0x35F4000);              
            // 0x00A1E89C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00A1E8A0: LDR x9, [x9, #0x478]       | X9 = (string**)(1152921510153374672)("CONNECT_SERVER");
            // 0x00A1E8A4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E8A8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E8AC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00A1E8B0: LDR x1, [x9]               | X1 = "CONNECT_SERVER";                  
            // 0x00A1E8B4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00A1E8B8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00A1E8BC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E8C0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00A1E8C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E8C8: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheA;
            val_46 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheA;
            // 0x00A1E8CC: CBNZ x22, #0xa1e918        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheA != null) goto label_85;
            if(val_46 != null)
            {
                goto label_85;
            }
            // 0x00A1E8D0: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00A1E8D4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00A1E8D8: LDR x8, [x8, #0x28]        | X8 = 1152921510153374768;               
            // 0x00A1E8DC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00A1E8E0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_CONNECT_SERVER_1(ref object o);
            // 0x00A1E8E4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33 = null;
            // 0x00A1E8E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00A1E8EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E8F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E8F4: MOV x2, x22                | X2 = 1152921510153374768 (0x100000014A994C30);//ML01
            // 0x00A1E8F8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_36 = val_33;
            // 0x00A1E8FC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_CONNECT_SERVER_1(ref object o));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_CONNECT_SERVER_1(ref object o));
            // 0x00A1E900: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E904: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E908: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784007248
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheA = val_36;
            // 0x00A1E90C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E910: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E914: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_46 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheA;
            label_85:
            // 0x00A1E918: CBNZ x19, #0xa1e920        | if (X1 != 0) goto label_86;             
            if(X1 != 0)
            {
                goto label_86;
            }
            // 0x00A1E91C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_CONNECT_SERVER_1(ref object o)), ????);
            label_86:
            // 0x00A1E920: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E924: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E928: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00A1E92C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00A1E930: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_46);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_46);
            // 0x00A1E934: CBNZ x20, #0xa1e93c        | if (val_1 != null) goto label_87;       
            if(val_1 != null)
            {
                goto label_87;
            }
            // 0x00A1E938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_87:
            // 0x00A1E93C: ADRP x9, #0x3671000        | X9 = 57085952 (0x3671000);              
            // 0x00A1E940: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00A1E944: LDR x9, [x9, #0x508]       | X9 = (string**)(1152921510108585200)("instance");
            // 0x00A1E948: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00A1E94C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00A1E950: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00A1E954: LDR x1, [x9]               | X1 = "instance";                        
            // 0x00A1E958: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00A1E95C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00A1E960: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E964: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00A1E968: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E96C: LDR x21, [x8, #0x58]       | X21 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheB;
            val_47 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheB;
            // 0x00A1E970: CBNZ x21, #0xa1e9bc        | if (ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheB != null) goto label_88;
            if(val_47 != null)
            {
                goto label_88;
            }
            // 0x00A1E974: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x00A1E978: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00A1E97C: LDR x8, [x8, #0xa08]       | X8 = 1152921510153375792;               
            // 0x00A1E980: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00A1E984: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_instance_2(ref object o);
            // 0x00A1E988: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_34 = null;
            // 0x00A1E98C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00A1E990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1E994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E998: MOV x2, x21                | X2 = 1152921510153375792 (0x100000014A995030);//ML01
            // 0x00A1E99C: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00A1E9A0: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_instance_2(ref object o));
            val_34 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_instance_2(ref object o));
            // 0x00A1E9A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E9A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E9AC: STR x22, [x8, #0x58]       | ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504784007256
            ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheB = val_34;
            // 0x00A1E9B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Client_Binding);
            // 0x00A1E9B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Client_Binding.__il2cppRuntimeField_static_fields;
            // 0x00A1E9B8: LDR x21, [x8, #0x58]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_47 = ILRuntime.Runtime.Generated.Client_Binding.<>f__mg$cacheB;
            label_88:
            // 0x00A1E9BC: CBNZ x19, #0xa1e9c4        | if (X1 != 0) goto label_89;             
            if(X1 != 0)
            {
                goto label_89;
            }
            // 0x00A1E9C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Client_Binding::get_instance_2(ref object o)), ????);
            label_89:
            // 0x00A1E9C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1E9C8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00A1E9CC: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00A1E9D0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1E9D4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1E9D8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1E9DC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00A1E9E0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00A1E9E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1E9E8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00A1E9EC: B #0x28e5914               | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_47); return;
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_47);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1E9F0 (10611184), len: 612  VirtAddr: 0x00A1E9F0 RVA: 0x00A1E9F0 token: 100664468 methodIndex: 30515 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_IsNetConnected_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x00A1E9F0: STP x26, x25, [sp, #-0x50]! | stack[1152921510153623616] = ???;  stack[1152921510153623624] = ???;  //  dest_result_addr=1152921510153623616 |  dest_result_addr=1152921510153623624
            // 0x00A1E9F4: STP x24, x23, [sp, #0x10]  | stack[1152921510153623632] = ???;  stack[1152921510153623640] = ???;  //  dest_result_addr=1152921510153623632 |  dest_result_addr=1152921510153623640
            // 0x00A1E9F8: STP x22, x21, [sp, #0x20]  | stack[1152921510153623648] = ???;  stack[1152921510153623656] = ???;  //  dest_result_addr=1152921510153623648 |  dest_result_addr=1152921510153623656
            // 0x00A1E9FC: STP x20, x19, [sp, #0x30]  | stack[1152921510153623664] = ???;  stack[1152921510153623672] = ???;  //  dest_result_addr=1152921510153623664 |  dest_result_addr=1152921510153623672
            // 0x00A1EA00: STP x29, x30, [sp, #0x40]  | stack[1152921510153623680] = ???;  stack[1152921510153623688] = ???;  //  dest_result_addr=1152921510153623680 |  dest_result_addr=1152921510153623688
            // 0x00A1EA04: ADD x29, sp, #0x40         | X29 = (1152921510153623616 + 64) = 1152921510153623680 (0x100000014A9D1880);
            // 0x00A1EA08: SUB sp, sp, #0x10          | SP = (1152921510153623616 - 16) = 1152921510153623600 (0x100000014A9D1830);
            // 0x00A1EA0C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00A1EA10: LDRB w8, [x19, #0x141]     | W8 = (bool)static_value_03733141;       
            // 0x00A1EA14: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00A1EA18: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00A1EA1C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00A1EA20: TBNZ w8, #0, #0xa1ea3c     | if (static_value_03733141 == true) goto label_0;
            // 0x00A1EA24: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x00A1EA28: LDR x8, [x8, #0x58]        | X8 = 0x2B90B28;                         
            // 0x00A1EA2C: LDR w0, [x8]               | W0 = 0x198E;                            
            // 0x00A1EA30: BL #0x2782188              | X0 = sub_2782188( ?? 0x198E, ????);     
            // 0x00A1EA34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1EA38: STRB w8, [x19, #0x141]     | static_value_03733141 = true;            //  dest_result_addr=57880897
            label_0:
            // 0x00A1EA3C: CBNZ x20, #0xa1ea44        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1EA40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x198E, ????);     
            label_1:
            // 0x00A1EA44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EA48: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00A1EA4C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1EA50: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1EA54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EA58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1EA5C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1EA60: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A1EA64: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1EA68: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00A1EA6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EA70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1EA74: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1EA78: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A1EA7C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1EA80: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1EA84: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1EA88: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x00A1EA8C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00A1EA90: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1EA94: LDR x9, [x9, #0x520]       | X9 = 1152921504912277504;               
            // 0x00A1EA98: LDR x24, [x9]              | X24 = typeof(Client);                   
            // 0x00A1EA9C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1EAA0: TBZ w9, #0, #0xa1eab4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1EAA4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1EAA8: CBNZ w9, #0xa1eab4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1EAAC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1EAB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1EAB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EAB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1EABC: MOV x1, x24                | X1 = 1152921504912277504 (0x1000000012348000);//ML01
            // 0x00A1EAC0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1EAC4: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00A1EAC8: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00A1EACC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1EAD0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1EAD4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1EAD8: TBZ w9, #0, #0xa1eaec      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1EADC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1EAE0: CBNZ w9, #0xa1eaec         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1EAE4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1EAE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1EAEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EAF0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1EAF4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A1EAF8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1EAFC: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00A1EB00: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00A1EB04: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1EB08: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1EB0C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00A1EB10: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1EB14: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1EB18: TBZ w9, #0, #0xa1eb2c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1EB1C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1EB20: CBNZ w9, #0xa1eb2c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1EB24: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1EB28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1EB2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EB30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1EB34: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1EB38: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00A1EB3C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1EB40: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00A1EB44: CBZ x0, #0xa1eba8          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00A1EB48: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A1EB4C: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A1EB50: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1EB54: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A1EB58: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1EB5C: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1EB60: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1EB64: B.LO #0xa1eb80             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00A1EB68: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1EB6C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A1EB70: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1EB74: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A1EB78: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x00A1EB7C: B.EQ #0xa1eba8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00A1EB80: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1EB84: ADD x8, sp, #8             | X8 = (1152921510153623600 + 8) = 1152921510153623608 (0x100000014A9D1838);
            // 0x00A1EB88: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1EB8C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510153611696]
            // 0x00A1EB90: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00A1EB94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EB98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00A1EB9C: ADD x0, sp, #8             | X0 = (1152921510153623600 + 8) = 1152921510153623608 (0x100000014A9D1838);
            // 0x00A1EBA0: BL #0x299a140              | 
            // 0x00A1EBA4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x00A1EBA8: CBNZ x20, #0xa1ebb0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00A1EBAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014A9D1838, ????);
            label_11:
            // 0x00A1EBB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1EBB4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00A1EBB8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A1EBBC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1EBC0: CBNZ x22, #0xa1ebc8        | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x00A1EBC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00A1EBC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EBCC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EBD0: BL #0xd84610               | X0 = val_13.get_IsNetConnected();       
            bool val_9 = val_13.IsNetConnected;
            // 0x00A1EBD4: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x00A1EBD8: CBZ x19, #0xa1ebec         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00A1EBDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1EBE0: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00A1EBE4: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x00A1EBE8: B #0xa1ec00                |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x00A1EBEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00A1EBF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1EBF4: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00A1EBF8: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x00A1EBFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x00A1EC00: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x00A1EC04: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1EC08: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x00A1EC0C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00A1EC10: TBZ w9, #0, #0xa1ec20      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00A1EC14: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00A1EC18: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00A1EC1C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x00A1EC20: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x00A1EC24: SUB sp, x29, #0x40         | SP = (1152921510153623680 - 64) = 1152921510153623616 (0x100000014A9D1840);
            // 0x00A1EC28: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1EC2C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1EC30: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1EC34: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00A1EC38: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00A1EC3C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A1EC40: MOV x19, x0                | 
            // 0x00A1EC44: ADD x0, sp, #8             | 
            // 0x00A1EC48: BL #0x299a140              | 
            // 0x00A1EC4C: MOV x0, x19                | 
            // 0x00A1EC50: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1EC54 (10611796), len: 528  VirtAddr: 0x00A1EC54 RVA: 0x00A1EC54 token: 100664469 methodIndex: 30516 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* CloseNetState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00A1EC54: STP x24, x23, [sp, #-0x40]! | stack[1152921510153792976] = ???;  stack[1152921510153792984] = ???;  //  dest_result_addr=1152921510153792976 |  dest_result_addr=1152921510153792984
            // 0x00A1EC58: STP x22, x21, [sp, #0x10]  | stack[1152921510153792992] = ???;  stack[1152921510153793000] = ???;  //  dest_result_addr=1152921510153792992 |  dest_result_addr=1152921510153793000
            // 0x00A1EC5C: STP x20, x19, [sp, #0x20]  | stack[1152921510153793008] = ???;  stack[1152921510153793016] = ???;  //  dest_result_addr=1152921510153793008 |  dest_result_addr=1152921510153793016
            // 0x00A1EC60: STP x29, x30, [sp, #0x30]  | stack[1152921510153793024] = ???;  stack[1152921510153793032] = ???;  //  dest_result_addr=1152921510153793024 |  dest_result_addr=1152921510153793032
            // 0x00A1EC64: ADD x29, sp, #0x30         | X29 = (1152921510153792976 + 48) = 1152921510153793024 (0x100000014A9FAE00);
            // 0x00A1EC68: SUB sp, sp, #0x10          | SP = (1152921510153792976 - 16) = 1152921510153792960 (0x100000014A9FADC0);
            // 0x00A1EC6C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A1EC70: LDRB w8, [x20, #0x142]     | W8 = (bool)static_value_03733142;       
            // 0x00A1EC74: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00A1EC78: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00A1EC7C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A1EC80: TBNZ w8, #0, #0xa1ec9c     | if (static_value_03733142 == true) goto label_0;
            // 0x00A1EC84: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00A1EC88: LDR x8, [x8, #0x8d8]       | X8 = 0x2B90B1C;                         
            // 0x00A1EC8C: LDR w0, [x8]               | W0 = 0x198B;                            
            // 0x00A1EC90: BL #0x2782188              | X0 = sub_2782188( ?? 0x198B, ????);     
            // 0x00A1EC94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1EC98: STRB w8, [x20, #0x142]     | static_value_03733142 = true;            //  dest_result_addr=57880898
            label_0:
            // 0x00A1EC9C: CBNZ x19, #0xa1eca4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1ECA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x198B, ????);     
            label_1:
            // 0x00A1ECA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1ECA8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1ECAC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1ECB0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1ECB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1ECB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1ECBC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1ECC0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A1ECC4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1ECC8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A1ECCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1ECD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1ECD4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1ECD8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A1ECDC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1ECE0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1ECE4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1ECE8: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x00A1ECEC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00A1ECF0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1ECF4: LDR x9, [x9, #0x520]       | X9 = 1152921504912277504;               
            // 0x00A1ECF8: LDR x24, [x9]              | X24 = typeof(Client);                   
            // 0x00A1ECFC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1ED00: TBZ w9, #0, #0xa1ed14      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1ED04: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1ED08: CBNZ w9, #0xa1ed14         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1ED0C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1ED10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1ED14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1ED18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1ED1C: MOV x1, x24                | X1 = 1152921504912277504 (0x1000000012348000);//ML01
            // 0x00A1ED20: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1ED24: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1ED28: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1ED2C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1ED30: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1ED34: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1ED38: TBZ w9, #0, #0xa1ed4c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1ED3C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1ED40: CBNZ w9, #0xa1ed4c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1ED44: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1ED48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1ED4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1ED50: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1ED54: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A1ED58: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1ED5C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00A1ED60: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00A1ED64: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1ED68: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1ED6C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00A1ED70: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1ED74: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1ED78: TBZ w9, #0, #0xa1ed8c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1ED7C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1ED80: CBNZ w9, #0xa1ed8c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1ED84: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1ED88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1ED8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1ED90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1ED94: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1ED98: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00A1ED9C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1EDA0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00A1EDA4: CBZ x0, #0xa1ee08          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00A1EDA8: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A1EDAC: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A1EDB0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1EDB4: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A1EDB8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1EDBC: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1EDC0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1EDC4: B.LO #0xa1ede0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00A1EDC8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1EDCC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A1EDD0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1EDD4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A1EDD8: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00A1EDDC: B.EQ #0xa1ee08             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00A1EDE0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1EDE4: ADD x8, sp, #8             | X8 = (1152921510153792960 + 8) = 1152921510153792968 (0x100000014A9FADC8);
            // 0x00A1EDE8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1EDEC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510153781040]
            // 0x00A1EDF0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00A1EDF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EDF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00A1EDFC: ADD x0, sp, #8             | X0 = (1152921510153792960 + 8) = 1152921510153792968 (0x100000014A9FADC8);
            // 0x00A1EE00: BL #0x299a140              | 
            // 0x00A1EE04: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00A1EE08: CBNZ x19, #0xa1ee10        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00A1EE0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014A9FADC8, ????);
            label_11:
            // 0x00A1EE10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1EE14: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1EE18: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A1EE1C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1EE20: CBNZ x22, #0xa1ee28        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00A1EE24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00A1EE28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EE2C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EE30: BL #0xd84624               | val_9.CloseNetState();                  
            val_9.CloseNetState();
            // 0x00A1EE34: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A1EE38: SUB sp, x29, #0x30         | SP = (1152921510153793024 - 48) = 1152921510153792976 (0x100000014A9FADD0);
            // 0x00A1EE3C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1EE40: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1EE44: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1EE48: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00A1EE4C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A1EE50: MOV x19, x0                | 
            // 0x00A1EE54: ADD x0, sp, #8             | 
            // 0x00A1EE58: BL #0x299a140              | 
            // 0x00A1EE5C: MOV x0, x19                | 
            // 0x00A1EE60: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1EE64 (10612324), len: 1220  VirtAddr: 0x00A1EE64 RVA: 0x00A1EE64 token: 100664470 methodIndex: 30517 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Run_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_18;
            //  | 
            var val_24;
            //  | 
            PushCallBack val_25;
            //  | 
            ResponseCallBack val_26;
            //  | 
            string val_27;
            //  | 
            var val_28;
            // 0x00A1EE64: STP x28, x27, [sp, #-0x60]! | stack[1152921510153999152] = ???;  stack[1152921510153999160] = ???;  //  dest_result_addr=1152921510153999152 |  dest_result_addr=1152921510153999160
            // 0x00A1EE68: STP x26, x25, [sp, #0x10]  | stack[1152921510153999168] = ???;  stack[1152921510153999176] = ???;  //  dest_result_addr=1152921510153999168 |  dest_result_addr=1152921510153999176
            // 0x00A1EE6C: STP x24, x23, [sp, #0x20]  | stack[1152921510153999184] = ???;  stack[1152921510153999192] = ???;  //  dest_result_addr=1152921510153999184 |  dest_result_addr=1152921510153999192
            // 0x00A1EE70: STP x22, x21, [sp, #0x30]  | stack[1152921510153999200] = ???;  stack[1152921510153999208] = ???;  //  dest_result_addr=1152921510153999200 |  dest_result_addr=1152921510153999208
            // 0x00A1EE74: STP x20, x19, [sp, #0x40]  | stack[1152921510153999216] = ???;  stack[1152921510153999224] = ???;  //  dest_result_addr=1152921510153999216 |  dest_result_addr=1152921510153999224
            // 0x00A1EE78: STP x29, x30, [sp, #0x50]  | stack[1152921510153999232] = ???;  stack[1152921510153999240] = ???;  //  dest_result_addr=1152921510153999232 |  dest_result_addr=1152921510153999240
            // 0x00A1EE7C: ADD x29, sp, #0x50         | X29 = (1152921510153999152 + 80) = 1152921510153999232 (0x100000014AA2D380);
            // 0x00A1EE80: SUB sp, sp, #0x20          | SP = (1152921510153999152 - 32) = 1152921510153999120 (0x100000014AA2D310);
            // 0x00A1EE84: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A1EE88: LDRB w8, [x20, #0x143]     | W8 = (bool)static_value_03733143;       
            // 0x00A1EE8C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00A1EE90: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00A1EE94: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A1EE98: TBNZ w8, #0, #0xa1eeb4     | if (static_value_03733143 == true) goto label_0;
            // 0x00A1EE9C: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00A1EEA0: LDR x8, [x8, #0xbb0]       | X8 = 0x2B90B4C;                         
            // 0x00A1EEA4: LDR w0, [x8]               | W0 = 0x1997;                            
            // 0x00A1EEA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1997, ????);     
            // 0x00A1EEAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1EEB0: STRB w8, [x20, #0x143]     | static_value_03733143 = true;            //  dest_result_addr=57880899
            label_0:
            // 0x00A1EEB4: CBNZ x19, #0xa1eebc        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1EEB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1997, ????);     
            label_1:
            // 0x00A1EEBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EEC0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1EEC4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1EEC8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1EECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EED0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1EED4: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00A1EED8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1EEDC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1EEE0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A1EEE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EEE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1EEEC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1EEF0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1EEF4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1EEF8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1EEFC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1EF00: ADRP x9, #0x3667000        | X9 = 57044992 (0x3667000);              
            // 0x00A1EF04: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00A1EF08: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1EF0C: LDR x9, [x9, #0xaf8]       | X9 = 1152921504912384000;               
            // 0x00A1EF10: LDR x24, [x9]              | X24 = typeof(Client.PushCallBack);      
            // 0x00A1EF14: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1EF18: TBZ w9, #0, #0xa1ef2c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1EF1C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1EF20: CBNZ w9, #0xa1ef2c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1EF24: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1EF28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1EF2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EF30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1EF34: MOV x1, x24                | X1 = 1152921504912384000 (0x1000000012362000);//ML01
            // 0x00A1EF38: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1EF3C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1EF40: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1EF44: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1EF48: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1EF4C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1EF50: TBZ w9, #0, #0xa1ef64      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1EF54: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1EF58: CBNZ w9, #0xa1ef64         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1EF5C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1EF60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1EF64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EF68: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1EF6C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1EF70: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1EF74: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1EF78: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1EF7C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1EF80: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1EF84: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00A1EF88: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1EF8C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1EF90: TBZ w9, #0, #0xa1efa4      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1EF94: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1EF98: CBNZ w9, #0xa1efa4         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1EF9C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1EFA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1EFA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1EFA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1EFAC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1EFB0: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00A1EFB4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1EFB8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x00A1EFBC: CBZ x0, #0xa1f004          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00A1EFC0: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00A1EFC4: LDR x8, [x8, #0xac8]       | X8 = 1152921504912384000;               
            // 0x00A1EFC8: LDR x1, [x8]               | X1 = typeof(Client.PushCallBack);       
            // 0x00A1EFCC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1EFD0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(Client.PushCallBack))
            // 0x00A1EFD4: MOV x24, x0                | X24 = val_6;//m1                        
            val_25 = val_6;
            // 0x00A1EFD8: B.EQ #0xa1f004             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00A1EFDC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1EFE0: MOV x8, sp                 | X8 = 1152921510153999120 (0x100000014AA2D310);//ML01
            // 0x00A1EFE4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1EFE8: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510153987248]
            // 0x00A1EFEC: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00A1EFF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1EFF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00A1EFF8: MOV x0, sp                 | X0 = 1152921510153999120 (0x100000014AA2D310);//ML01
            // 0x00A1EFFC: BL #0x299a140              | 
            // 0x00A1F000: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_25 = 0;
            label_9:
            // 0x00A1F004: CBNZ x19, #0xa1f00c        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00A1F008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA2D310, ????);
            label_10:
            // 0x00A1F00C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F010: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F014: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1F018: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F01C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F020: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F024: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00A1F028: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F02C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F030: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00A1F034: LDR x8, [x8, #0xf68]       | X8 = 1152921504912330752;               
            // 0x00A1F038: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00A1F03C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F040: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F044: LDR x1, [x8]               | X1 = typeof(Client.ResponseCallBack);   
            // 0x00A1F048: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F04C: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00A1F050: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F054: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F058: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00A1F05C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F060: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F064: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F068: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00A1F06C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F070: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F074: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00A1F078: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00A1F07C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_26 = 0;
            // 0x00A1F080: CBZ x0, #0xa1f0c8          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00A1F084: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00A1F088: LDR x8, [x8, #0x770]       | X8 = 1152921504912330752;               
            // 0x00A1F08C: LDR x1, [x8]               | X1 = typeof(Client.ResponseCallBack);   
            // 0x00A1F090: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F094: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(Client.ResponseCallBack))
            // 0x00A1F098: MOV x25, x0                | X25 = val_11;//m1                       
            val_26 = val_11;
            // 0x00A1F09C: B.EQ #0xa1f0c8             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00A1F0A0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F0A4: ADD x8, sp, #8             | X8 = (1152921510153999120 + 8) = 1152921510153999128 (0x100000014AA2D318);
            // 0x00A1F0A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F0AC: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510153987248]
            // 0x00A1F0B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00A1F0B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F0B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00A1F0BC: ADD x0, sp, #8             | X0 = (1152921510153999120 + 8) = 1152921510153999128 (0x100000014AA2D318);
            // 0x00A1F0C0: BL #0x299a140              | 
            // 0x00A1F0C4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_26 = 0;
            label_12:
            // 0x00A1F0C8: CBNZ x19, #0xa1f0d0        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00A1F0CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA2D318, ????);
            label_13:
            // 0x00A1F0D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F0D4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F0D8: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00A1F0DC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F0E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F0E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F0E8: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1F0EC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F0F0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F0F4: MOV x26, x0                | X26 = val_13;//m1                       
            // 0x00A1F0F8: CBNZ x26, #0xa1f100        | if (val_13 != 0) goto label_14;         
            if(val_13 != 0)
            {
                goto label_14;
            }
            // 0x00A1F0FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_14:
            // 0x00A1F100: LDR w26, [x26, #4]         | W26 = val_13 + 4;                       
            // 0x00A1F104: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F108: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F10C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00A1F110: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F114: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F118: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00A1F11C: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00A1F120: MOV x28, x0                | X28 = val_14;//m1                       
            // 0x00A1F124: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F128: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F12C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00A1F130: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F134: MOV x27, x0                | X27 = val_15;//m1                       
            // 0x00A1F138: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F13C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F140: MOV x1, x28                | X1 = val_14;//m1                        
            // 0x00A1F144: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F148: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F14C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F150: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x00A1F154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F158: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F15C: MOV x1, x27                | X1 = val_15;//m1                        
            // 0x00A1F160: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x00A1F164: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_27 = 0;
            // 0x00A1F168: CBZ x0, #0xa1f1b0          | if (val_17 == null) goto label_16;      
            if(val_17 == null)
            {
                goto label_16;
            }
            // 0x00A1F16C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00A1F170: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00A1F174: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00A1F178: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F17C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A1F180: MOV x27, x0                | X27 = val_17;//m1                       
            val_27 = val_17;
            // 0x00A1F184: B.EQ #0xa1f1b0             | if (typeof(System.Object) == null) goto label_16;
            if(null == null)
            {
                goto label_16;
            }
            // 0x00A1F188: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F18C: ADD x8, sp, #0x10          | X8 = (1152921510153999120 + 16) = 1152921510153999136 (0x100000014AA2D320);
            // 0x00A1F190: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F194: LDR x0, [sp, #0x10]        | X0 = val_18;                             //  find_add[1152921510153987248]
            // 0x00A1F198: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x00A1F19C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F1A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x00A1F1A4: ADD x0, sp, #0x10          | X0 = (1152921510153999120 + 16) = 1152921510153999136 (0x100000014AA2D320);
            // 0x00A1F1A8: BL #0x299a140              | 
            // 0x00A1F1AC: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_27 = 0;
            label_16:
            // 0x00A1F1B0: CBNZ x19, #0xa1f1b8        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00A1F1B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA2D320, ????);
            label_17:
            // 0x00A1F1B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F1BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F1C0: MOV x1, x28                | X1 = val_14;//m1                        
            // 0x00A1F1C4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F1C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F1CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F1D0: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00A1F1D4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F1D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_19 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F1DC: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00A1F1E0: LDR x8, [x8, #0x520]       | X8 = 1152921504912277504;               
            // 0x00A1F1E4: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x00A1F1E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F1EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F1F0: LDR x1, [x8]               | X1 = typeof(Client);                    
            // 0x00A1F1F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_20 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F1F8: MOV x28, x0                | X28 = val_20;//m1                       
            // 0x00A1F1FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F200: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F204: MOV x1, x22                | X1 = val_19;//m1                        
            // 0x00A1F208: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F20C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F210: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_21 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F214: MOV x2, x0                 | X2 = val_21;//m1                        
            // 0x00A1F218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F21C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F220: MOV x1, x28                | X1 = val_20;//m1                        
            // 0x00A1F224: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_20);
            object val_22 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_20);
            // 0x00A1F228: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x00A1F22C: CBZ x0, #0xa1f290          | if (val_22 == null) goto label_20;      
            if(val_22 == null)
            {
                goto label_20;
            }
            // 0x00A1F230: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A1F234: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A1F238: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F23C: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A1F240: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F244: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F248: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1F24C: B.LO #0xa1f268             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_19;
            // 0x00A1F250: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1F254: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A1F258: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1F25C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A1F260: MOV x21, x0                | X21 = val_22;//m1                       
            val_28 = val_22;
            // 0x00A1F264: B.EQ #0xa1f290             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_20;
            label_19:
            // 0x00A1F268: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F26C: ADD x8, sp, #0x18          | X8 = (1152921510153999120 + 24) = 1152921510153999144 (0x100000014AA2D328);
            // 0x00A1F270: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F274: LDR x0, [sp, #0x18]        | X0 = val_24;                             //  find_add[1152921510153987248]
            // 0x00A1F278: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
            // 0x00A1F27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F280: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x00A1F284: ADD x0, sp, #0x18          | X0 = (1152921510153999120 + 24) = 1152921510153999144 (0x100000014AA2D328);
            // 0x00A1F288: BL #0x299a140              | 
            // 0x00A1F28C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_28 = 0;
            label_20:
            // 0x00A1F290: CBNZ x19, #0xa1f298        | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x00A1F294: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA2D328, ????);
            label_21:
            // 0x00A1F298: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F29C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F2A0: MOV x1, x22                | X1 = val_19;//m1                        
            // 0x00A1F2A4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F2A8: CBNZ x21, #0xa1f2b0        | if (0x0 != 0) goto label_22;            
            if(val_28 != 0)
            {
                goto label_22;
            }
            // 0x00A1F2AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_22:
            // 0x00A1F2B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00A1F2B4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F2B8: MOV x1, x27                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F2BC: MOV w2, w26                | W2 = val_13 + 4;//m1                    
            // 0x00A1F2C0: MOV x3, x25                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F2C4: MOV x4, x24                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F2C8: BL #0xd84658               | val_28.Run(host:  val_27, port:  val_13 + 4, responseFun:  val_26, pushFun:  val_25);
            val_28.Run(host:  val_27, port:  val_13 + 4, responseFun:  val_26, pushFun:  val_25);
            // 0x00A1F2CC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A1F2D0: SUB sp, x29, #0x50         | SP = (1152921510153999232 - 80) = 1152921510153999152 (0x100000014AA2D330);
            // 0x00A1F2D4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1F2D8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1F2DC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1F2E0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00A1F2E4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00A1F2E8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00A1F2EC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A1F2F0: MOV x19, x0                | 
            // 0x00A1F2F4: ADD x0, sp, #0x18          | 
            // 0x00A1F2F8: B #0xa1f31c                | 
            // 0x00A1F2FC: MOV x19, x0                | 
            // 0x00A1F300: MOV x0, sp                 | 
            // 0x00A1F304: B #0xa1f31c                | 
            // 0x00A1F308: MOV x19, x0                | 
            // 0x00A1F30C: ADD x0, sp, #8             | 
            // 0x00A1F310: B #0xa1f31c                | 
            // 0x00A1F314: MOV x19, x0                | 
            // 0x00A1F318: ADD x0, sp, #0x10          | 
            label_25:
            // 0x00A1F31C: BL #0x299a140              | 
            // 0x00A1F320: MOV x0, x19                | 
            // 0x00A1F324: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1F328 (10613544), len: 988  VirtAddr: 0x00A1F328 RVA: 0x00A1F328 token: 100664471 methodIndex: 30518 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Request_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_19;
            //  | 
            Newtonsoft.Json.Linq.JObject val_20;
            //  | 
            string val_21;
            //  | 
            var val_22;
            // 0x00A1F328: STP x26, x25, [sp, #-0x50]! | stack[1152921510154229952] = ???;  stack[1152921510154229960] = ???;  //  dest_result_addr=1152921510154229952 |  dest_result_addr=1152921510154229960
            // 0x00A1F32C: STP x24, x23, [sp, #0x10]  | stack[1152921510154229968] = ???;  stack[1152921510154229976] = ???;  //  dest_result_addr=1152921510154229968 |  dest_result_addr=1152921510154229976
            // 0x00A1F330: STP x22, x21, [sp, #0x20]  | stack[1152921510154229984] = ???;  stack[1152921510154229992] = ???;  //  dest_result_addr=1152921510154229984 |  dest_result_addr=1152921510154229992
            // 0x00A1F334: STP x20, x19, [sp, #0x30]  | stack[1152921510154230000] = ???;  stack[1152921510154230008] = ???;  //  dest_result_addr=1152921510154230000 |  dest_result_addr=1152921510154230008
            // 0x00A1F338: STP x29, x30, [sp, #0x40]  | stack[1152921510154230016] = ???;  stack[1152921510154230024] = ???;  //  dest_result_addr=1152921510154230016 |  dest_result_addr=1152921510154230024
            // 0x00A1F33C: ADD x29, sp, #0x40         | X29 = (1152921510154229952 + 64) = 1152921510154230016 (0x100000014AA65900);
            // 0x00A1F340: SUB sp, sp, #0x20          | SP = (1152921510154229952 - 32) = 1152921510154229920 (0x100000014AA658A0);
            // 0x00A1F344: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A1F348: LDRB w8, [x20, #0x144]     | W8 = (bool)static_value_03733144;       
            // 0x00A1F34C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00A1F350: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00A1F354: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A1F358: TBNZ w8, #0, #0xa1f374     | if (static_value_03733144 == true) goto label_0;
            // 0x00A1F35C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00A1F360: LDR x8, [x8, #0x230]       | X8 = 0x2B90B44;                         
            // 0x00A1F364: LDR w0, [x8]               | W0 = 0x1995;                            
            // 0x00A1F368: BL #0x2782188              | X0 = sub_2782188( ?? 0x1995, ????);     
            // 0x00A1F36C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1F370: STRB w8, [x20, #0x144]     | static_value_03733144 = true;            //  dest_result_addr=57880900
            label_0:
            // 0x00A1F374: CBNZ x19, #0xa1f37c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1F378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1995, ????);     
            label_1:
            // 0x00A1F37C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F380: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F384: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1F388: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1F38C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F390: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F394: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1F398: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F39C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F3A0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A1F3A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F3A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F3AC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1F3B0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F3B4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F3B8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1F3BC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1F3C0: ADRP x9, #0x35e7000        | X9 = 56520704 (0x35E7000);              
            // 0x00A1F3C4: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00A1F3C8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1F3CC: LDR x9, [x9, #0xde8]       | X9 = 1152921504861265920;               
            // 0x00A1F3D0: LDR x24, [x9]              | X24 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00A1F3D4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1F3D8: TBZ w9, #0, #0xa1f3ec      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1F3DC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1F3E0: CBNZ w9, #0xa1f3ec         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1F3E4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1F3E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1F3EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F3F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F3F4: MOV x1, x24                | X1 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00A1F3F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F3FC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1F400: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1F404: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1F408: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1F40C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1F410: TBZ w9, #0, #0xa1f424      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1F414: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1F418: CBNZ w9, #0xa1f424         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1F41C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1F420: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1F424: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F428: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F42C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1F430: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F434: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F438: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F43C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1F440: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1F444: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00A1F448: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1F44C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1F450: TBZ w9, #0, #0xa1f464      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1F454: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1F458: CBNZ w9, #0xa1f464         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1F45C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1F460: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1F464: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F468: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F46C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1F470: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00A1F474: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1F478: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x00A1F47C: CBZ x0, #0xa1f4e0          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00A1F480: ADRP x9, #0x35e7000        | X9 = 56520704 (0x35E7000);              
            // 0x00A1F484: LDR x9, [x9, #0x5f0]       | X9 = 1152921504861265920;               
            // 0x00A1F488: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F48C: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00A1F490: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F494: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F498: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1F49C: B.LO #0xa1f4b8             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00A1F4A0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1F4A4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRunti
            // 0x00A1F4A8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1F4AC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Linq.JObject))
            // 0x00A1F4B0: MOV x24, x0                | X24 = val_6;//m1                        
            val_20 = val_6;
            // 0x00A1F4B4: B.EQ #0xa1f4e0             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00A1F4B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F4BC: ADD x8, sp, #8             | X8 = (1152921510154229920 + 8) = 1152921510154229928 (0x100000014AA658A8);
            // 0x00A1F4C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F4C4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510154218032]
            // 0x00A1F4C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00A1F4CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F4D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00A1F4D4: ADD x0, sp, #8             | X0 = (1152921510154229920 + 8) = 1152921510154229928 (0x100000014AA658A8);
            // 0x00A1F4D8: BL #0x299a140              | 
            // 0x00A1F4DC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_10:
            // 0x00A1F4E0: CBNZ x19, #0xa1f4e8        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00A1F4E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA658A8, ????);
            label_11:
            // 0x00A1F4E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F4EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F4F0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1F4F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F4F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F4FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F500: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00A1F504: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F508: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F50C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00A1F510: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00A1F514: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x00A1F518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F51C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F520: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00A1F524: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F528: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00A1F52C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F530: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F534: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00A1F538: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F53C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F540: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F544: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00A1F548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F54C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F550: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x00A1F554: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00A1F558: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00A1F55C: CBZ x0, #0xa1f5a4          | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x00A1F560: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00A1F564: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00A1F568: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00A1F56C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F570: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A1F574: MOV x25, x0                | X25 = val_12;//m1                       
            val_21 = val_12;
            // 0x00A1F578: B.EQ #0xa1f5a4             | if (typeof(System.Object) == null) goto label_13;
            if(null == null)
            {
                goto label_13;
            }
            // 0x00A1F57C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F580: ADD x8, sp, #0x10          | X8 = (1152921510154229920 + 16) = 1152921510154229936 (0x100000014AA658B0);
            // 0x00A1F584: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F588: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510154218032]
            // 0x00A1F58C: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00A1F590: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F594: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00A1F598: ADD x0, sp, #0x10          | X0 = (1152921510154229920 + 16) = 1152921510154229936 (0x100000014AA658B0);
            // 0x00A1F59C: BL #0x299a140              | 
            // 0x00A1F5A0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_13:
            // 0x00A1F5A4: CBNZ x19, #0xa1f5ac        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00A1F5A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA658B0, ????);
            label_14:
            // 0x00A1F5AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F5B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F5B4: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00A1F5B8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F5BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F5C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F5C4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1F5C8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F5CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F5D0: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00A1F5D4: LDR x8, [x8, #0x520]       | X8 = 1152921504912277504;               
            // 0x00A1F5D8: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00A1F5DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F5E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F5E4: LDR x1, [x8]               | X1 = typeof(Client);                    
            // 0x00A1F5E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F5EC: MOV x26, x0                | X26 = val_15;//m1                       
            // 0x00A1F5F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F5F4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F5F8: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x00A1F5FC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F600: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F604: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F608: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x00A1F60C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F610: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F614: MOV x1, x26                | X1 = val_15;//m1                        
            // 0x00A1F618: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x00A1F61C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00A1F620: CBZ x0, #0xa1f684          | if (val_17 == null) goto label_17;      
            if(val_17 == null)
            {
                goto label_17;
            }
            // 0x00A1F624: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A1F628: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A1F62C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F630: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A1F634: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F638: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F63C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1F640: B.LO #0xa1f65c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x00A1F644: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1F648: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A1F64C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1F650: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A1F654: MOV x21, x0                | X21 = val_17;//m1                       
            val_22 = val_17;
            // 0x00A1F658: B.EQ #0xa1f684             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x00A1F65C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F660: ADD x8, sp, #0x18          | X8 = (1152921510154229920 + 24) = 1152921510154229944 (0x100000014AA658B8);
            // 0x00A1F664: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F668: LDR x0, [sp, #0x18]        | X0 = val_19;                             //  find_add[1152921510154218032]
            // 0x00A1F66C: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x00A1F670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F674: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x00A1F678: ADD x0, sp, #0x18          | X0 = (1152921510154229920 + 24) = 1152921510154229944 (0x100000014AA658B8);
            // 0x00A1F67C: BL #0x299a140              | 
            // 0x00A1F680: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_17:
            // 0x00A1F684: CBNZ x19, #0xa1f68c        | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x00A1F688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA658B8, ????);
            label_18:
            // 0x00A1F68C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F690: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1F694: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x00A1F698: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F69C: CBNZ x21, #0xa1f6a4        | if (0x0 != 0) goto label_19;            
            if(val_22 != 0)
            {
                goto label_19;
            }
            // 0x00A1F6A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_19:
            // 0x00A1F6A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F6A8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F6AC: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F6B0: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F6B4: BL #0xd84a8c               | val_22.Request(route:  val_21, msg:  val_20);
            val_22.Request(route:  val_21, msg:  val_20);
            // 0x00A1F6B8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A1F6BC: SUB sp, x29, #0x40         | SP = (1152921510154230016 - 64) = 1152921510154229952 (0x100000014AA658C0);
            // 0x00A1F6C0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1F6C4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1F6C8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1F6CC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00A1F6D0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00A1F6D4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A1F6D8: MOV x19, x0                | 
            // 0x00A1F6DC: ADD x0, sp, #8             | 
            // 0x00A1F6E0: B #0xa1f6f8                | 
            // 0x00A1F6E4: MOV x19, x0                | 
            // 0x00A1F6E8: ADD x0, sp, #0x18          | 
            // 0x00A1F6EC: B #0xa1f6f8                | 
            // 0x00A1F6F0: MOV x19, x0                | 
            // 0x00A1F6F4: ADD x0, sp, #0x10          | 
            label_21:
            // 0x00A1F6F8: BL #0x299a140              | 
            // 0x00A1F6FC: MOV x0, x19                | 
            // 0x00A1F700: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1F704 (10614532), len: 1008  VirtAddr: 0x00A1F704 RVA: 0x00A1F704 token: 100664472 methodIndex: 30519 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Request_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_18;
            //  | 
            string val_21;
            //  | 
            string val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x00A1F704: STP x28, x27, [sp, #-0x60]! | stack[1152921510154448432] = ???;  stack[1152921510154448440] = ???;  //  dest_result_addr=1152921510154448432 |  dest_result_addr=1152921510154448440
            // 0x00A1F708: STP x26, x25, [sp, #0x10]  | stack[1152921510154448448] = ???;  stack[1152921510154448456] = ???;  //  dest_result_addr=1152921510154448448 |  dest_result_addr=1152921510154448456
            // 0x00A1F70C: STP x24, x23, [sp, #0x20]  | stack[1152921510154448464] = ???;  stack[1152921510154448472] = ???;  //  dest_result_addr=1152921510154448464 |  dest_result_addr=1152921510154448472
            // 0x00A1F710: STP x22, x21, [sp, #0x30]  | stack[1152921510154448480] = ???;  stack[1152921510154448488] = ???;  //  dest_result_addr=1152921510154448480 |  dest_result_addr=1152921510154448488
            // 0x00A1F714: STP x20, x19, [sp, #0x40]  | stack[1152921510154448496] = ???;  stack[1152921510154448504] = ???;  //  dest_result_addr=1152921510154448496 |  dest_result_addr=1152921510154448504
            // 0x00A1F718: STP x29, x30, [sp, #0x50]  | stack[1152921510154448512] = ???;  stack[1152921510154448520] = ???;  //  dest_result_addr=1152921510154448512 |  dest_result_addr=1152921510154448520
            // 0x00A1F71C: ADD x29, sp, #0x50         | X29 = (1152921510154448432 + 80) = 1152921510154448512 (0x100000014AA9AE80);
            // 0x00A1F720: SUB sp, sp, #0x20          | SP = (1152921510154448432 - 32) = 1152921510154448400 (0x100000014AA9AE10);
            // 0x00A1F724: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00A1F728: LDRB w8, [x19, #0x145]     | W8 = (bool)static_value_03733145;       
            // 0x00A1F72C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00A1F730: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00A1F734: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00A1F738: TBNZ w8, #0, #0xa1f754     | if (static_value_03733145 == true) goto label_0;
            // 0x00A1F73C: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00A1F740: LDR x8, [x8, #0x338]       | X8 = 0x2B90B48;                         
            // 0x00A1F744: LDR w0, [x8]               | W0 = 0x1996;                            
            // 0x00A1F748: BL #0x2782188              | X0 = sub_2782188( ?? 0x1996, ????);     
            // 0x00A1F74C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1F750: STRB w8, [x19, #0x145]     | static_value_03733145 = true;            //  dest_result_addr=57880901
            label_0:
            // 0x00A1F754: CBNZ x20, #0xa1f75c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1F758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1996, ????);     
            label_1:
            // 0x00A1F75C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F760: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00A1F764: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1F768: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1F76C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F770: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F774: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1F778: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F77C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F780: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00A1F784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F78C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1F790: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F794: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F798: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1F79C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1F7A0: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00A1F7A4: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00A1F7A8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1F7AC: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            // 0x00A1F7B0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1F7B4: LDR x24, [x28]             | X24 = typeof(System.String);            
            // 0x00A1F7B8: TBZ w9, #0, #0xa1f7cc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1F7BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1F7C0: CBNZ w9, #0xa1f7cc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1F7C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1F7C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1F7CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F7D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F7D4: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1F7D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F7DC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1F7E0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1F7E4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1F7E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1F7EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1F7F0: TBZ w9, #0, #0xa1f804      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1F7F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1F7F8: CBNZ w9, #0xa1f804         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1F7FC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1F800: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1F804: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F808: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F80C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1F810: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F814: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F818: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F81C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1F820: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1F824: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00A1F828: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1F82C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1F830: TBZ w9, #0, #0xa1f844      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1F834: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1F838: CBNZ w9, #0xa1f844         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1F83C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1F840: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1F844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F84C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1F850: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00A1F854: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1F858: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
            // 0x00A1F85C: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
            // 0x00A1F860: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00A1F864: CBZ x0, #0xa1f8a4          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00A1F868: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00A1F86C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F870: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A1F874: MOV x24, x0                | X24 = val_6;//m1                        
            val_21 = val_6;
            // 0x00A1F878: B.EQ #0xa1f8a4             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00A1F87C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F880: ADD x8, sp, #8             | X8 = (1152921510154448400 + 8) = 1152921510154448408 (0x100000014AA9AE18);
            // 0x00A1F884: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F888: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510154436528]
            // 0x00A1F88C: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00A1F890: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F894: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00A1F898: ADD x0, sp, #8             | X0 = (1152921510154448400 + 8) = 1152921510154448408 (0x100000014AA9AE18);
            // 0x00A1F89C: BL #0x299a140              | 
            // 0x00A1F8A0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_9:
            // 0x00A1F8A4: CBNZ x20, #0xa1f8ac        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00A1F8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA9AE18, ????);
            label_10:
            // 0x00A1F8AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F8B0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00A1F8B4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1F8B8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F8BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F8C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F8C4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00A1F8C8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F8CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F8D0: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00A1F8D4: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00A1F8D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F8DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F8E0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F8E4: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00A1F8E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F8EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F8F0: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00A1F8F4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F8F8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F8FC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F900: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00A1F904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F908: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F90C: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00A1F910: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00A1F914: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00A1F918: CBZ x0, #0xa1f958          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00A1F91C: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00A1F920: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F924: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A1F928: MOV x25, x0                | X25 = val_11;//m1                       
            val_22 = val_11;
            // 0x00A1F92C: B.EQ #0xa1f958             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00A1F930: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1F934: ADD x8, sp, #0x10          | X8 = (1152921510154448400 + 16) = 1152921510154448416 (0x100000014AA9AE20);
            // 0x00A1F938: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1F93C: LDR x0, [sp, #0x10]        | X0 = val_12;                             //  find_add[1152921510154436528]
            // 0x00A1F940: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00A1F944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1F948: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00A1F94C: ADD x0, sp, #0x10          | X0 = (1152921510154448400 + 16) = 1152921510154448416 (0x100000014AA9AE20);
            // 0x00A1F950: BL #0x299a140              | 
            // 0x00A1F954: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_12:
            // 0x00A1F958: CBNZ x20, #0xa1f960        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00A1F95C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA9AE20, ????);
            label_13:
            // 0x00A1F960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F964: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00A1F968: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00A1F96C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1F970: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F974: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F978: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1F97C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1F980: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1F984: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00A1F988: LDR x8, [x8, #0x520]       | X8 = 1152921504912277504;               
            // 0x00A1F98C: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00A1F990: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F994: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1F998: LDR x1, [x8]               | X1 = typeof(Client);                    
            // 0x00A1F99C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1F9A0: MOV x26, x0                | X26 = val_14;//m1                       
            // 0x00A1F9A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F9A8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1F9AC: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00A1F9B0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1F9B4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1F9B8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_15 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1F9BC: MOV x2, x0                 | X2 = val_15;//m1                        
            // 0x00A1F9C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1F9C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1F9C8: MOV x1, x26                | X1 = val_14;//m1                        
            // 0x00A1F9CC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            object val_16 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            // 0x00A1F9D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00A1F9D4: CBZ x0, #0xa1fa38          | if (val_16 == null) goto label_16;      
            if(val_16 == null)
            {
                goto label_16;
            }
            // 0x00A1F9D8: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A1F9DC: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A1F9E0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1F9E4: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A1F9E8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F9EC: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1F9F0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1F9F4: B.LO #0xa1fa10             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x00A1F9F8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1F9FC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A1FA00: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1FA04: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A1FA08: MOV x21, x0                | X21 = val_16;//m1                       
            val_23 = val_16;
            // 0x00A1FA0C: B.EQ #0xa1fa38             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x00A1FA10: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1FA14: ADD x8, sp, #0x18          | X8 = (1152921510154448400 + 24) = 1152921510154448424 (0x100000014AA9AE28);
            // 0x00A1FA18: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1FA1C: LDR x0, [sp, #0x18]        | X0 = val_18;                             //  find_add[1152921510154436528]
            // 0x00A1FA20: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x00A1FA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FA28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x00A1FA2C: ADD x0, sp, #0x18          | X0 = (1152921510154448400 + 24) = 1152921510154448424 (0x100000014AA9AE28);
            // 0x00A1FA30: BL #0x299a140              | 
            // 0x00A1FA34: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_16:
            // 0x00A1FA38: CBNZ x20, #0xa1fa40        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00A1FA3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AA9AE28, ????);
            label_17:
            // 0x00A1FA40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FA44: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00A1FA48: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00A1FA4C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1FA50: CBNZ x21, #0xa1fa58        | if (0x0 != 0) goto label_18;            
            if(val_23 != 0)
            {
                goto label_18;
            }
            // 0x00A1FA54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x00A1FA58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FA5C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FA60: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FA64: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FA68: BL #0xd84b8c               | X0 = val_23.Request(route:  val_22, msg:  val_21);
            uint val_19 = val_23.Request(route:  val_22, msg:  val_21);
            // 0x00A1FA6C: CBZ x19, #0xa1facc         | if (val_2 == 0) goto label_19;          
            if(val_2 == 0)
            {
                goto label_19;
            }
            // 0x00A1FA70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1FA74: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_19;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_19;
            // 0x00A1FA78: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1FA7C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1FA80: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1FA84: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_24 = 8;
            // 0x00A1FA88: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00A1FA8C: TBZ w9, #0, #0xa1fa9c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_20;
            // 0x00A1FA90: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00A1FA94: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00A1FA98: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_24 = 219381744;
            label_20:
            // 0x00A1FA9C: ADD x0, x8, x19            | X0 = (val_24 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_20 = val_24 + val_2;
            // 0x00A1FAA0: SUB sp, x29, #0x50         | SP = (1152921510154448512 - 80) = 1152921510154448432 (0x100000014AA9AE30);
            // 0x00A1FAA4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1FAA8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1FAAC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1FAB0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00A1FAB4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00A1FAB8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00A1FABC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_24 + val_2);
            return val_20;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A1FAC0: MOV x19, x0                | X19 = (val_24 + val_2);//m1             
            val_25 = val_20;
            // 0x00A1FAC4: ADD x0, sp, #0x18          | X0 = (1152921510154448528 + 24) = 1152921510154448552 (0x100000014AA9AEA8);
            // 0x00A1FAC8: B #0xa1fae8                |  goto label_22;                         
            goto label_22;
            label_19:
            // 0x00A1FACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            // 0x00A1FAD0: BRK #0x1                   | 
            // 0x00A1FAD4: MOV x19, x0                | X19 = val_19;//m1                       
            val_25 = val_19;
            // 0x00A1FAD8: ADD x0, sp, #8             | X0 = (1152921510154448400 + 8) = 1152921510154448408 (0x100000014AA9AE18);
            // 0x00A1FADC: B #0xa1fae8                |  goto label_22;                         
            goto label_22;
            // 0x00A1FAE0: MOV x19, x0                | X19 = 1152921510154448408 (0x100000014AA9AE18);//ML01
            val_25;
            // 0x00A1FAE4: ADD x0, sp, #0x10          | X0 = (1152921510154448400 + 16) = 1152921510154448416 (0x100000014AA9AE20);
            label_22:
            // 0x00A1FAE8: BL #0x299a140              | 
            // 0x00A1FAEC: MOV x0, x19                | X0 = 1152921510154448408 (0x100000014AA9AE18);//ML01
            // 0x00A1FAF0: BL #0x980800               | X0 = sub_980800( ?? 0x100000014AA9AE18, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1FAF4 (10615540), len: 952  VirtAddr: 0x00A1FAF4 RVA: 0x00A1FAF4 token: 100664473 methodIndex: 30520 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Notify_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_18;
            //  | 
            string val_19;
            //  | 
            string val_20;
            //  | 
            var val_21;
            // 0x00A1FAF4: STP x28, x27, [sp, #-0x60]! | stack[1152921510154666928] = ???;  stack[1152921510154666936] = ???;  //  dest_result_addr=1152921510154666928 |  dest_result_addr=1152921510154666936
            // 0x00A1FAF8: STP x26, x25, [sp, #0x10]  | stack[1152921510154666944] = ???;  stack[1152921510154666952] = ???;  //  dest_result_addr=1152921510154666944 |  dest_result_addr=1152921510154666952
            // 0x00A1FAFC: STP x24, x23, [sp, #0x20]  | stack[1152921510154666960] = ???;  stack[1152921510154666968] = ???;  //  dest_result_addr=1152921510154666960 |  dest_result_addr=1152921510154666968
            // 0x00A1FB00: STP x22, x21, [sp, #0x30]  | stack[1152921510154666976] = ???;  stack[1152921510154666984] = ???;  //  dest_result_addr=1152921510154666976 |  dest_result_addr=1152921510154666984
            // 0x00A1FB04: STP x20, x19, [sp, #0x40]  | stack[1152921510154666992] = ???;  stack[1152921510154667000] = ???;  //  dest_result_addr=1152921510154666992 |  dest_result_addr=1152921510154667000
            // 0x00A1FB08: STP x29, x30, [sp, #0x50]  | stack[1152921510154667008] = ???;  stack[1152921510154667016] = ???;  //  dest_result_addr=1152921510154667008 |  dest_result_addr=1152921510154667016
            // 0x00A1FB0C: ADD x29, sp, #0x50         | X29 = (1152921510154666928 + 80) = 1152921510154667008 (0x100000014AAD0400);
            // 0x00A1FB10: SUB sp, sp, #0x20          | SP = (1152921510154666928 - 32) = 1152921510154666896 (0x100000014AAD0390);
            // 0x00A1FB14: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A1FB18: LDRB w8, [x20, #0x146]     | W8 = (bool)static_value_03733146;       
            // 0x00A1FB1C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00A1FB20: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00A1FB24: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A1FB28: TBNZ w8, #0, #0xa1fb44     | if (static_value_03733146 == true) goto label_0;
            // 0x00A1FB2C: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x00A1FB30: LDR x8, [x8, #0x238]       | X8 = 0x2B90B34;                         
            // 0x00A1FB34: LDR w0, [x8]               | W0 = 0x1991;                            
            // 0x00A1FB38: BL #0x2782188              | X0 = sub_2782188( ?? 0x1991, ????);     
            // 0x00A1FB3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1FB40: STRB w8, [x20, #0x146]     | static_value_03733146 = true;            //  dest_result_addr=57880902
            label_0:
            // 0x00A1FB44: CBNZ x19, #0xa1fb4c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1FB48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1991, ????);     
            label_1:
            // 0x00A1FB4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FB50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1FB54: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1FB58: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1FB5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FB60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FB64: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1FB68: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1FB6C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1FB70: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A1FB74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FB78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FB7C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1FB80: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1FB84: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1FB88: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1FB8C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1FB90: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x00A1FB94: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00A1FB98: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1FB9C: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            // 0x00A1FBA0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1FBA4: LDR x24, [x27]             | X24 = typeof(System.String);            
            // 0x00A1FBA8: TBZ w9, #0, #0xa1fbbc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1FBAC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1FBB0: CBNZ w9, #0xa1fbbc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1FBB4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1FBB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1FBBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FBC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FBC4: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00A1FBC8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1FBCC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1FBD0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1FBD4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1FBD8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1FBDC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1FBE0: TBZ w9, #0, #0xa1fbf4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1FBE4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1FBE8: CBNZ w9, #0xa1fbf4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1FBEC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1FBF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1FBF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FBF8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1FBFC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1FC00: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1FC04: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1FC08: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1FC0C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1FC10: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1FC14: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00A1FC18: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1FC1C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1FC20: TBZ w9, #0, #0xa1fc34      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1FC24: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1FC28: CBNZ w9, #0xa1fc34         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1FC2C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1FC30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1FC34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FC38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FC3C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1FC40: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00A1FC44: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1FC48: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
            // 0x00A1FC4C: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
            // 0x00A1FC50: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x00A1FC54: CBZ x0, #0xa1fc94          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00A1FC58: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00A1FC5C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1FC60: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A1FC64: MOV x24, x0                | X24 = val_6;//m1                        
            val_19 = val_6;
            // 0x00A1FC68: B.EQ #0xa1fc94             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00A1FC6C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1FC70: ADD x8, sp, #8             | X8 = (1152921510154666896 + 8) = 1152921510154666904 (0x100000014AAD0398);
            // 0x00A1FC74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1FC78: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510154655024]
            // 0x00A1FC7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00A1FC80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FC84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00A1FC88: ADD x0, sp, #8             | X0 = (1152921510154666896 + 8) = 1152921510154666904 (0x100000014AAD0398);
            // 0x00A1FC8C: BL #0x299a140              | 
            // 0x00A1FC90: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_9:
            // 0x00A1FC94: CBNZ x19, #0xa1fc9c        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00A1FC98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AAD0398, ????);
            label_10:
            // 0x00A1FC9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FCA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1FCA4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1FCA8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1FCAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FCB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FCB4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00A1FCB8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1FCBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1FCC0: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00A1FCC4: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00A1FCC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FCCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FCD0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1FCD4: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00A1FCD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FCDC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1FCE0: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00A1FCE4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1FCE8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1FCEC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1FCF0: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00A1FCF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FCF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FCFC: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00A1FD00: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00A1FD04: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x00A1FD08: CBZ x0, #0xa1fd48          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00A1FD0C: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00A1FD10: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1FD14: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A1FD18: MOV x25, x0                | X25 = val_11;//m1                       
            val_20 = val_11;
            // 0x00A1FD1C: B.EQ #0xa1fd48             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00A1FD20: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1FD24: ADD x8, sp, #0x10          | X8 = (1152921510154666896 + 16) = 1152921510154666912 (0x100000014AAD03A0);
            // 0x00A1FD28: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1FD2C: LDR x0, [sp, #0x10]        | X0 = val_12;                             //  find_add[1152921510154655024]
            // 0x00A1FD30: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00A1FD34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FD38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00A1FD3C: ADD x0, sp, #0x10          | X0 = (1152921510154666896 + 16) = 1152921510154666912 (0x100000014AAD03A0);
            // 0x00A1FD40: BL #0x299a140              | 
            // 0x00A1FD44: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_12:
            // 0x00A1FD48: CBNZ x19, #0xa1fd50        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00A1FD4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AAD03A0, ????);
            label_13:
            // 0x00A1FD50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FD54: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1FD58: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00A1FD5C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1FD60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FD64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FD68: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1FD6C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1FD70: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1FD74: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00A1FD78: LDR x8, [x8, #0x520]       | X8 = 1152921504912277504;               
            // 0x00A1FD7C: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00A1FD80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FD84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FD88: LDR x1, [x8]               | X1 = typeof(Client);                    
            // 0x00A1FD8C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1FD90: MOV x26, x0                | X26 = val_14;//m1                       
            // 0x00A1FD94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FD98: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1FD9C: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00A1FDA0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1FDA4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1FDA8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_15 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1FDAC: MOV x2, x0                 | X2 = val_15;//m1                        
            // 0x00A1FDB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FDB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FDB8: MOV x1, x26                | X1 = val_14;//m1                        
            // 0x00A1FDBC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            object val_16 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            // 0x00A1FDC0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00A1FDC4: CBZ x0, #0xa1fe28          | if (val_16 == null) goto label_16;      
            if(val_16 == null)
            {
                goto label_16;
            }
            // 0x00A1FDC8: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A1FDCC: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A1FDD0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A1FDD4: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A1FDD8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1FDDC: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A1FDE0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A1FDE4: B.LO #0xa1fe00             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x00A1FDE8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A1FDEC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A1FDF0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A1FDF4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A1FDF8: MOV x21, x0                | X21 = val_16;//m1                       
            val_21 = val_16;
            // 0x00A1FDFC: B.EQ #0xa1fe28             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x00A1FE00: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A1FE04: ADD x8, sp, #0x18          | X8 = (1152921510154666896 + 24) = 1152921510154666920 (0x100000014AAD03A8);
            // 0x00A1FE08: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A1FE0C: LDR x0, [sp, #0x18]        | X0 = val_18;                             //  find_add[1152921510154655024]
            // 0x00A1FE10: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x00A1FE14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FE18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x00A1FE1C: ADD x0, sp, #0x18          | X0 = (1152921510154666896 + 24) = 1152921510154666920 (0x100000014AAD03A8);
            // 0x00A1FE20: BL #0x299a140              | 
            // 0x00A1FE24: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_16:
            // 0x00A1FE28: CBNZ x19, #0xa1fe30        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00A1FE2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AAD03A8, ????);
            label_17:
            // 0x00A1FE30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FE34: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1FE38: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00A1FE3C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A1FE40: CBNZ x21, #0xa1fe48        | if (0x0 != 0) goto label_18;            
            if(val_21 != 0)
            {
                goto label_18;
            }
            // 0x00A1FE44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x00A1FE48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FE4C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FE50: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FE54: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FE58: BL #0xd84ccc               | val_21.Notify(route:  val_20, msg:  val_19);
            val_21.Notify(route:  val_20, msg:  val_19);
            // 0x00A1FE5C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A1FE60: SUB sp, x29, #0x50         | SP = (1152921510154667008 - 80) = 1152921510154666928 (0x100000014AAD03B0);
            // 0x00A1FE64: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00A1FE68: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00A1FE6C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00A1FE70: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00A1FE74: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00A1FE78: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00A1FE7C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A1FE80: MOV x19, x0                | 
            // 0x00A1FE84: ADD x0, sp, #0x18          | 
            // 0x00A1FE88: B #0xa1fea0                | 
            // 0x00A1FE8C: MOV x19, x0                | 
            // 0x00A1FE90: ADD x0, sp, #8             | 
            // 0x00A1FE94: B #0xa1fea0                | 
            // 0x00A1FE98: MOV x19, x0                | 
            // 0x00A1FE9C: ADD x0, sp, #0x10          | 
            label_20:
            // 0x00A1FEA0: BL #0x299a140              | 
            // 0x00A1FEA4: MOV x0, x19                | 
            // 0x00A1FEA8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A1FEAC (10616492), len: 988  VirtAddr: 0x00A1FEAC RVA: 0x00A1FEAC token: 100664474 methodIndex: 30521 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Notify_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_19;
            //  | 
            Newtonsoft.Json.Linq.JObject val_20;
            //  | 
            string val_21;
            //  | 
            var val_22;
            // 0x00A1FEAC: STP x26, x25, [sp, #-0x50]! | stack[1152921510154885440] = ???;  stack[1152921510154885448] = ???;  //  dest_result_addr=1152921510154885440 |  dest_result_addr=1152921510154885448
            // 0x00A1FEB0: STP x24, x23, [sp, #0x10]  | stack[1152921510154885456] = ???;  stack[1152921510154885464] = ???;  //  dest_result_addr=1152921510154885456 |  dest_result_addr=1152921510154885464
            // 0x00A1FEB4: STP x22, x21, [sp, #0x20]  | stack[1152921510154885472] = ???;  stack[1152921510154885480] = ???;  //  dest_result_addr=1152921510154885472 |  dest_result_addr=1152921510154885480
            // 0x00A1FEB8: STP x20, x19, [sp, #0x30]  | stack[1152921510154885488] = ???;  stack[1152921510154885496] = ???;  //  dest_result_addr=1152921510154885488 |  dest_result_addr=1152921510154885496
            // 0x00A1FEBC: STP x29, x30, [sp, #0x40]  | stack[1152921510154885504] = ???;  stack[1152921510154885512] = ???;  //  dest_result_addr=1152921510154885504 |  dest_result_addr=1152921510154885512
            // 0x00A1FEC0: ADD x29, sp, #0x40         | X29 = (1152921510154885440 + 64) = 1152921510154885504 (0x100000014AB05980);
            // 0x00A1FEC4: SUB sp, sp, #0x20          | SP = (1152921510154885440 - 32) = 1152921510154885408 (0x100000014AB05920);
            // 0x00A1FEC8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A1FECC: LDRB w8, [x20, #0x147]     | W8 = (bool)static_value_03733147;       
            // 0x00A1FED0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00A1FED4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00A1FED8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A1FEDC: TBNZ w8, #0, #0xa1fef8     | if (static_value_03733147 == true) goto label_0;
            // 0x00A1FEE0: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00A1FEE4: LDR x8, [x8, #0x668]       | X8 = 0x2B90B38;                         
            // 0x00A1FEE8: LDR w0, [x8]               | W0 = 0x1992;                            
            // 0x00A1FEEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1992, ????);     
            // 0x00A1FEF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A1FEF4: STRB w8, [x20, #0x147]     | static_value_03733147 = true;            //  dest_result_addr=57880903
            label_0:
            // 0x00A1FEF8: CBNZ x19, #0xa1ff00        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A1FEFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1992, ????);     
            label_1:
            // 0x00A1FF00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A1FF04: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A1FF08: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A1FF0C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A1FF10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FF14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FF18: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A1FF1C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1FF20: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1FF24: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A1FF28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FF2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FF30: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A1FF34: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A1FF38: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A1FF3C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A1FF40: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A1FF44: ADRP x9, #0x35e7000        | X9 = 56520704 (0x35E7000);              
            // 0x00A1FF48: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00A1FF4C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A1FF50: LDR x9, [x9, #0xde8]       | X9 = 1152921504861265920;               
            // 0x00A1FF54: LDR x24, [x9]              | X24 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00A1FF58: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A1FF5C: TBZ w9, #0, #0xa1ff70      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A1FF60: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A1FF64: CBNZ w9, #0xa1ff70         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A1FF68: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A1FF6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A1FF70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FF74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A1FF78: MOV x1, x24                | X1 = 1152921504861265920 (0x100000000F2A2000);//ML01
            // 0x00A1FF7C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A1FF80: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A1FF84: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A1FF88: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A1FF8C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A1FF90: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A1FF94: TBZ w9, #0, #0xa1ffa8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A1FF98: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A1FF9C: CBNZ w9, #0xa1ffa8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A1FFA0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A1FFA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A1FFA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FFAC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A1FFB0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A1FFB4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A1FFB8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A1FFBC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A1FFC0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A1FFC4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A1FFC8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00A1FFCC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A1FFD0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A1FFD4: TBZ w9, #0, #0xa1ffe8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A1FFD8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A1FFDC: CBNZ w9, #0xa1ffe8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A1FFE0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A1FFE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A1FFE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A1FFEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A1FFF0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A1FFF4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00A1FFF8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A1FFFC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x00A20000: CBZ x0, #0xa20064          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00A20004: ADRP x9, #0x35e7000        | X9 = 56520704 (0x35E7000);              
            // 0x00A20008: LDR x9, [x9, #0x5f0]       | X9 = 1152921504861265920;               
            // 0x00A2000C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A20010: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Linq.JObject);
            // 0x00A20014: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A20018: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A2001C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A20020: B.LO #0xa2003c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00A20024: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A20028: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRunti
            // 0x00A2002C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A20030: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Linq.JObject))
            // 0x00A20034: MOV x24, x0                | X24 = val_6;//m1                        
            val_20 = val_6;
            // 0x00A20038: B.EQ #0xa20064             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Linq.JObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00A2003C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A20040: ADD x8, sp, #8             | X8 = (1152921510154885408 + 8) = 1152921510154885416 (0x100000014AB05928);
            // 0x00A20044: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A20048: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510154873520]
            // 0x00A2004C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00A20050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A20054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00A20058: ADD x0, sp, #8             | X0 = (1152921510154885408 + 8) = 1152921510154885416 (0x100000014AB05928);
            // 0x00A2005C: BL #0x299a140              | 
            // 0x00A20060: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_10:
            // 0x00A20064: CBNZ x19, #0xa2006c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00A20068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AB05928, ????);
            label_11:
            // 0x00A2006C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20070: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A20074: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00A20078: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A2007C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20080: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A20084: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00A20088: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A2008C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A20090: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00A20094: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00A20098: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x00A2009C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A200A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A200A4: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00A200A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A200AC: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00A200B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A200B4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A200B8: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00A200BC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A200C0: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A200C4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A200C8: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00A200CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A200D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A200D4: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x00A200D8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00A200DC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00A200E0: CBZ x0, #0xa20128          | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x00A200E4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00A200E8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00A200EC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00A200F0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A200F4: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00A200F8: MOV x25, x0                | X25 = val_12;//m1                       
            val_21 = val_12;
            // 0x00A200FC: B.EQ #0xa20128             | if (typeof(System.Object) == null) goto label_13;
            if(null == null)
            {
                goto label_13;
            }
            // 0x00A20100: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A20104: ADD x8, sp, #0x10          | X8 = (1152921510154885408 + 16) = 1152921510154885424 (0x100000014AB05930);
            // 0x00A20108: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A2010C: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510154873520]
            // 0x00A20110: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00A20114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A20118: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00A2011C: ADD x0, sp, #0x10          | X0 = (1152921510154885408 + 16) = 1152921510154885424 (0x100000014AB05930);
            // 0x00A20120: BL #0x299a140              | 
            // 0x00A20124: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_13:
            // 0x00A20128: CBNZ x19, #0xa20130        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00A2012C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AB05930, ????);
            label_14:
            // 0x00A20130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20134: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A20138: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00A2013C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A20140: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20144: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A20148: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00A2014C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00A20150: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A20154: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00A20158: LDR x8, [x8, #0x520]       | X8 = 1152921504912277504;               
            // 0x00A2015C: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00A20160: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20164: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20168: LDR x1, [x8]               | X1 = typeof(Client);                    
            // 0x00A2016C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A20170: MOV x26, x0                | X26 = val_15;//m1                       
            // 0x00A20174: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20178: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A2017C: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x00A20180: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A20184: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00A20188: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00A2018C: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x00A20190: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20194: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A20198: MOV x1, x26                | X1 = val_15;//m1                        
            // 0x00A2019C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x00A201A0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00A201A4: CBZ x0, #0xa20208          | if (val_17 == null) goto label_17;      
            if(val_17 == null)
            {
                goto label_17;
            }
            // 0x00A201A8: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A201AC: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A201B0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A201B4: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A201B8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A201BC: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A201C0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A201C4: B.LO #0xa201e0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x00A201C8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A201CC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A201D0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A201D4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A201D8: MOV x21, x0                | X21 = val_17;//m1                       
            val_22 = val_17;
            // 0x00A201DC: B.EQ #0xa20208             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x00A201E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A201E4: ADD x8, sp, #0x18          | X8 = (1152921510154885408 + 24) = 1152921510154885432 (0x100000014AB05938);
            // 0x00A201E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A201EC: LDR x0, [sp, #0x18]        | X0 = val_19;                             //  find_add[1152921510154873520]
            // 0x00A201F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x00A201F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A201F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x00A201FC: ADD x0, sp, #0x18          | X0 = (1152921510154885408 + 24) = 1152921510154885432 (0x100000014AB05938);
            // 0x00A20200: BL #0x299a140              | 
            // 0x00A20204: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_17:
            // 0x00A20208: CBNZ x19, #0xa20210        | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x00A2020C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AB05938, ????);
            label_18:
            // 0x00A20210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20214: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A20218: MOV x1, x22                | X1 = val_14;//m1                        
            // 0x00A2021C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A20220: CBNZ x21, #0xa20228        | if (0x0 != 0) goto label_19;            
            if(val_22 != 0)
            {
                goto label_19;
            }
            // 0x00A20224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_19:
            // 0x00A20228: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A2022C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00A20230: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00A20234: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00A20238: BL #0xd84d74               | val_22.Notify(route:  val_21, msg:  val_20);
            val_22.Notify(route:  val_21, msg:  val_20);
            // 0x00A2023C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A20240: SUB sp, x29, #0x40         | SP = (1152921510154885504 - 64) = 1152921510154885440 (0x100000014AB05940);
            // 0x00A20244: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00A20248: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00A2024C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00A20250: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00A20254: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00A20258: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A2025C: MOV x19, x0                | 
            // 0x00A20260: ADD x0, sp, #8             | 
            // 0x00A20264: B #0xa2027c                | 
            // 0x00A20268: MOV x19, x0                | 
            // 0x00A2026C: ADD x0, sp, #0x18          | 
            // 0x00A20270: B #0xa2027c                | 
            // 0x00A20274: MOV x19, x0                | 
            // 0x00A20278: ADD x0, sp, #0x10          | 
            label_21:
            // 0x00A2027C: BL #0x299a140              | 
            // 0x00A20280: MOV x0, x19                | 
            // 0x00A20284: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A20288 (10617480), len: 528  VirtAddr: 0x00A20288 RVA: 0x00A20288 token: 100664475 methodIndex: 30522 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnDisconnect_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00A20288: STP x24, x23, [sp, #-0x40]! | stack[1152921510155079376] = ???;  stack[1152921510155079384] = ???;  //  dest_result_addr=1152921510155079376 |  dest_result_addr=1152921510155079384
            // 0x00A2028C: STP x22, x21, [sp, #0x10]  | stack[1152921510155079392] = ???;  stack[1152921510155079400] = ???;  //  dest_result_addr=1152921510155079392 |  dest_result_addr=1152921510155079400
            // 0x00A20290: STP x20, x19, [sp, #0x20]  | stack[1152921510155079408] = ???;  stack[1152921510155079416] = ???;  //  dest_result_addr=1152921510155079408 |  dest_result_addr=1152921510155079416
            // 0x00A20294: STP x29, x30, [sp, #0x30]  | stack[1152921510155079424] = ???;  stack[1152921510155079432] = ???;  //  dest_result_addr=1152921510155079424 |  dest_result_addr=1152921510155079432
            // 0x00A20298: ADD x29, sp, #0x30         | X29 = (1152921510155079376 + 48) = 1152921510155079424 (0x100000014AB34F00);
            // 0x00A2029C: SUB sp, sp, #0x10          | SP = (1152921510155079376 - 16) = 1152921510155079360 (0x100000014AB34EC0);
            // 0x00A202A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A202A4: LDRB w8, [x20, #0x148]     | W8 = (bool)static_value_03733148;       
            // 0x00A202A8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00A202AC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00A202B0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A202B4: TBNZ w8, #0, #0xa202d0     | if (static_value_03733148 == true) goto label_0;
            // 0x00A202B8: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00A202BC: LDR x8, [x8, #0xff8]       | X8 = 0x2B90B3C;                         
            // 0x00A202C0: LDR w0, [x8]               | W0 = 0x1993;                            
            // 0x00A202C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1993, ????);     
            // 0x00A202C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A202CC: STRB w8, [x20, #0x148]     | static_value_03733148 = true;            //  dest_result_addr=57880904
            label_0:
            // 0x00A202D0: CBNZ x19, #0xa202d8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A202D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1993, ????);     
            label_1:
            // 0x00A202D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A202DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A202E0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A202E4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A202E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A202EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A202F0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A202F4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A202F8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A202FC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A20300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20304: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A20308: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A2030C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A20310: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A20314: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A20318: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A2031C: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x00A20320: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00A20324: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A20328: LDR x9, [x9, #0x520]       | X9 = 1152921504912277504;               
            // 0x00A2032C: LDR x24, [x9]              | X24 = typeof(Client);                   
            // 0x00A20330: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A20334: TBZ w9, #0, #0xa20348      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A20338: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A2033C: CBNZ w9, #0xa20348         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A20340: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A20344: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A20348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A2034C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20350: MOV x1, x24                | X1 = 1152921504912277504 (0x1000000012348000);//ML01
            // 0x00A20354: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A20358: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A2035C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A20360: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A20364: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A20368: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A2036C: TBZ w9, #0, #0xa20380      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A20370: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A20374: CBNZ w9, #0xa20380         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A20378: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A2037C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A20380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20384: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A20388: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A2038C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A20390: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00A20394: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00A20398: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A2039C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A203A0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00A203A4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A203A8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A203AC: TBZ w9, #0, #0xa203c0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A203B0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A203B4: CBNZ w9, #0xa203c0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A203B8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A203BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A203C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A203C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A203C8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A203CC: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00A203D0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A203D4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00A203D8: CBZ x0, #0xa2043c          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00A203DC: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A203E0: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A203E4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A203E8: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A203EC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A203F0: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A203F4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A203F8: B.LO #0xa20414             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00A203FC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A20400: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A20404: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A20408: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A2040C: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00A20410: B.EQ #0xa2043c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00A20414: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A20418: ADD x8, sp, #8             | X8 = (1152921510155079360 + 8) = 1152921510155079368 (0x100000014AB34EC8);
            // 0x00A2041C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A20420: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510155067440]
            // 0x00A20424: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00A20428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A2042C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00A20430: ADD x0, sp, #8             | X0 = (1152921510155079360 + 8) = 1152921510155079368 (0x100000014AB34EC8);
            // 0x00A20434: BL #0x299a140              | 
            // 0x00A20438: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00A2043C: CBNZ x19, #0xa20444        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00A20440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AB34EC8, ????);
            label_11:
            // 0x00A20444: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20448: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A2044C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A20450: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A20454: CBNZ x22, #0xa2045c        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00A20458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00A2045C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A20460: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00A20464: BL #0xd850c8               | val_9.OnDisconnect();                   
            val_9.OnDisconnect();
            // 0x00A20468: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A2046C: SUB sp, x29, #0x30         | SP = (1152921510155079424 - 48) = 1152921510155079376 (0x100000014AB34ED0);
            // 0x00A20470: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00A20474: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00A20478: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00A2047C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00A20480: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A20484: MOV x19, x0                | 
            // 0x00A20488: ADD x0, sp, #8             | 
            // 0x00A2048C: BL #0x299a140              | 
            // 0x00A20490: MOV x0, x19                | 
            // 0x00A20494: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A20498 (10618008), len: 528  VirtAddr: 0x00A20498 RVA: 0x00A20498 token: 100664476 methodIndex: 30523 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Logout_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00A20498: STP x24, x23, [sp, #-0x40]! | stack[1152921510155248720] = ???;  stack[1152921510155248728] = ???;  //  dest_result_addr=1152921510155248720 |  dest_result_addr=1152921510155248728
            // 0x00A2049C: STP x22, x21, [sp, #0x10]  | stack[1152921510155248736] = ???;  stack[1152921510155248744] = ???;  //  dest_result_addr=1152921510155248736 |  dest_result_addr=1152921510155248744
            // 0x00A204A0: STP x20, x19, [sp, #0x20]  | stack[1152921510155248752] = ???;  stack[1152921510155248760] = ???;  //  dest_result_addr=1152921510155248752 |  dest_result_addr=1152921510155248760
            // 0x00A204A4: STP x29, x30, [sp, #0x30]  | stack[1152921510155248768] = ???;  stack[1152921510155248776] = ???;  //  dest_result_addr=1152921510155248768 |  dest_result_addr=1152921510155248776
            // 0x00A204A8: ADD x29, sp, #0x30         | X29 = (1152921510155248720 + 48) = 1152921510155248768 (0x100000014AB5E480);
            // 0x00A204AC: SUB sp, sp, #0x10          | SP = (1152921510155248720 - 16) = 1152921510155248704 (0x100000014AB5E440);
            // 0x00A204B0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00A204B4: LDRB w8, [x20, #0x149]     | W8 = (bool)static_value_03733149;       
            // 0x00A204B8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00A204BC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00A204C0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00A204C4: TBNZ w8, #0, #0xa204e0     | if (static_value_03733149 == true) goto label_0;
            // 0x00A204C8: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00A204CC: LDR x8, [x8, #0xdc0]       | X8 = 0x2B90B30;                         
            // 0x00A204D0: LDR w0, [x8]               | W0 = 0x1990;                            
            // 0x00A204D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1990, ????);     
            // 0x00A204D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A204DC: STRB w8, [x20, #0x149]     | static_value_03733149 = true;            //  dest_result_addr=57880905
            label_0:
            // 0x00A204E0: CBNZ x19, #0xa204e8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00A204E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1990, ????);     
            label_1:
            // 0x00A204E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A204EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A204F0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00A204F4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00A204F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A204FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A20500: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A20504: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A20508: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A2050C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00A20510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20514: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A20518: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00A2051C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00A20520: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00A20524: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00A20528: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00A2052C: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x00A20530: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00A20534: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00A20538: LDR x9, [x9, #0x520]       | X9 = 1152921504912277504;               
            // 0x00A2053C: LDR x24, [x9]              | X24 = typeof(Client);                   
            // 0x00A20540: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00A20544: TBZ w9, #0, #0xa20558      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00A20548: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00A2054C: CBNZ w9, #0xa20558         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00A20550: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00A20554: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00A20558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A2055C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20560: MOV x1, x24                | X1 = 1152921504912277504 (0x1000000012348000);//ML01
            // 0x00A20564: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00A20568: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00A2056C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00A20570: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00A20574: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00A20578: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00A2057C: TBZ w9, #0, #0xa20590      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00A20580: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00A20584: CBNZ w9, #0xa20590         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00A20588: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00A2058C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00A20590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A20594: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00A20598: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A2059C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00A205A0: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00A205A4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00A205A8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A205AC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00A205B0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00A205B4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00A205B8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00A205BC: TBZ w9, #0, #0xa205d0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00A205C0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00A205C4: CBNZ w9, #0xa205d0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00A205C8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00A205CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00A205D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A205D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00A205D8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00A205DC: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00A205E0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00A205E4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00A205E8: CBZ x0, #0xa2064c          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00A205EC: ADRP x9, #0x3631000        | X9 = 56823808 (0x3631000);              
            // 0x00A205F0: LDR x9, [x9, #0x370]       | X9 = 1152921504912277504;               
            // 0x00A205F4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00A205F8: LDR x1, [x9]               | X1 = typeof(Client);                    
            // 0x00A205FC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A20600: LDRB w9, [x1, #0x104]      | W9 = Client.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00A20604: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Client.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00A20608: B.LO #0xa20624             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Client.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00A2060C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00A20610: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyD
            // 0x00A20614: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00A20618: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Client))
            // 0x00A2061C: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00A20620: B.EQ #0xa2064c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Client.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00A20624: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00A20628: ADD x8, sp, #8             | X8 = (1152921510155248704 + 8) = 1152921510155248712 (0x100000014AB5E448);
            // 0x00A2062C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00A20630: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510155236784]
            // 0x00A20634: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00A20638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A2063C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00A20640: ADD x0, sp, #8             | X0 = (1152921510155248704 + 8) = 1152921510155248712 (0x100000014AB5E448);
            // 0x00A20644: BL #0x299a140              | 
            // 0x00A20648: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00A2064C: CBNZ x19, #0xa20654        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00A20650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014AB5E448, ????);
            label_11:
            // 0x00A20654: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A20658: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00A2065C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00A20660: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00A20664: CBNZ x22, #0xa2066c        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00A20668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00A2066C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A20670: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00A20674: BL #0xd8521c               | val_9.Logout();                         
            val_9.Logout();
            // 0x00A20678: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00A2067C: SUB sp, x29, #0x30         | SP = (1152921510155248768 - 48) = 1152921510155248720 (0x100000014AB5E450);
            // 0x00A20680: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00A20684: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00A20688: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00A2068C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00A20690: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00A20694: MOV x19, x0                | 
            // 0x00A20698: ADD x0, sp, #8             | 
            // 0x00A2069C: BL #0x299a140              | 
            // 0x00A206A0: MOV x0, x19                | 
            // 0x00A206A4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00A206A8 (10618536), len: 72  VirtAddr: 0x00A206A8 RVA: 0x00A206A8 token: 100664477 methodIndex: 30524 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_LOGIN_SERVER_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00A206A8: STP x20, x19, [sp, #-0x20]! | stack[1152921510155393440] = ???;  stack[1152921510155393448] = ???;  //  dest_result_addr=1152921510155393440 |  dest_result_addr=1152921510155393448
            // 0x00A206AC: STP x29, x30, [sp, #0x10]  | stack[1152921510155393456] = ???;  stack[1152921510155393464] = ???;  //  dest_result_addr=1152921510155393456 |  dest_result_addr=1152921510155393464
            // 0x00A206B0: ADD x29, sp, #0x10         | X29 = (1152921510155393440 + 16) = 1152921510155393456 (0x100000014AB819B0);
            // 0x00A206B4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00A206B8: LDRB w8, [x19, #0x14a]     | W8 = (bool)static_value_0373314A;       
            // 0x00A206BC: TBNZ w8, #0, #0xa206d8     | if (static_value_0373314A == true) goto label_0;
            // 0x00A206C0: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00A206C4: LDR x8, [x8, #0xe00]       | X8 = 0x2B90B2C;                         
            // 0x00A206C8: LDR w0, [x8]               | W0 = 0x198F;                            
            // 0x00A206CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x198F, ????);     
            // 0x00A206D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A206D4: STRB w8, [x19, #0x14a]     | static_value_0373314A = true;            //  dest_result_addr=57880906
            label_0:
            // 0x00A206D8: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00A206DC: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921510153373552)("LOGIN_SERVER");
            // 0x00A206E0: LDR x0, [x8]               | X0 = "LOGIN_SERVER";                    
            // 0x00A206E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00A206E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00A206EC: RET                        |  return (System.Object)"LOGIN_SERVER";  
            return (object)"LOGIN_SERVER";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00A206F0 (10618608), len: 72  VirtAddr: 0x00A206F0 RVA: 0x00A206F0 token: 100664478 methodIndex: 30525 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_CONNECT_SERVER_1(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00A206F0: STP x20, x19, [sp, #-0x20]! | stack[1152921510155513472] = ???;  stack[1152921510155513480] = ???;  //  dest_result_addr=1152921510155513472 |  dest_result_addr=1152921510155513480
            // 0x00A206F4: STP x29, x30, [sp, #0x10]  | stack[1152921510155513488] = ???;  stack[1152921510155513496] = ???;  //  dest_result_addr=1152921510155513488 |  dest_result_addr=1152921510155513496
            // 0x00A206F8: ADD x29, sp, #0x10         | X29 = (1152921510155513472 + 16) = 1152921510155513488 (0x100000014AB9EE90);
            // 0x00A206FC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00A20700: LDRB w8, [x19, #0x14b]     | W8 = (bool)static_value_0373314B;       
            // 0x00A20704: TBNZ w8, #0, #0xa20720     | if (static_value_0373314B == true) goto label_0;
            // 0x00A20708: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00A2070C: LDR x8, [x8, #0xec8]       | X8 = 0x2B90B20;                         
            // 0x00A20710: LDR w0, [x8]               | W0 = 0x198C;                            
            // 0x00A20714: BL #0x2782188              | X0 = sub_2782188( ?? 0x198C, ????);     
            // 0x00A20718: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A2071C: STRB w8, [x19, #0x14b]     | static_value_0373314B = true;            //  dest_result_addr=57880907
            label_0:
            // 0x00A20720: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x00A20724: LDR x8, [x8, #0x478]       | X8 = (string**)(1152921510153374672)("CONNECT_SERVER");
            // 0x00A20728: LDR x0, [x8]               | X0 = "CONNECT_SERVER";                  
            // 0x00A2072C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00A20730: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00A20734: RET                        |  return (System.Object)"CONNECT_SERVER";
            return (object)"CONNECT_SERVER";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00A20738 (10618680), len: 104  VirtAddr: 0x00A20738 RVA: 0x00A20738 token: 100664479 methodIndex: 30526 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_instance_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00A20738: STP x20, x19, [sp, #-0x20]! | stack[1152921510155633504] = ???;  stack[1152921510155633512] = ???;  //  dest_result_addr=1152921510155633504 |  dest_result_addr=1152921510155633512
            // 0x00A2073C: STP x29, x30, [sp, #0x10]  | stack[1152921510155633520] = ???;  stack[1152921510155633528] = ???;  //  dest_result_addr=1152921510155633520 |  dest_result_addr=1152921510155633528
            // 0x00A20740: ADD x29, sp, #0x10         | X29 = (1152921510155633504 + 16) = 1152921510155633520 (0x100000014ABBC370);
            // 0x00A20744: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00A20748: LDRB w8, [x19, #0x14c]     | W8 = (bool)static_value_0373314C;       
            // 0x00A2074C: TBNZ w8, #0, #0xa20768     | if (static_value_0373314C == true) goto label_0;
            // 0x00A20750: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00A20754: LDR x8, [x8, #0x2d8]       | X8 = 0x2B90B24;                         
            // 0x00A20758: LDR w0, [x8]               | W0 = 0x198D;                            
            // 0x00A2075C: BL #0x2782188              | X0 = sub_2782188( ?? 0x198D, ????);     
            // 0x00A20760: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A20764: STRB w8, [x19, #0x14c]     | static_value_0373314C = true;            //  dest_result_addr=57880908
            label_0:
            // 0x00A20768: ADRP x19, #0x3631000       | X19 = 56823808 (0x3631000);             
            // 0x00A2076C: LDR x19, [x19, #0x370]     | X19 = 1152921504912277504;              
            // 0x00A20770: LDR x0, [x19]              | X0 = typeof(Client);                    
            val_1 = null;
            // 0x00A20774: LDRB w8, [x0, #0x10a]      | W8 = Client.__il2cppRuntimeField_10A;   
            // 0x00A20778: TBZ w8, #0, #0xa2078c      | if (Client.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00A2077C: LDR w8, [x0, #0xbc]        | W8 = Client.__il2cppRuntimeField_cctor_finished;
            // 0x00A20780: CBNZ w8, #0xa2078c         | if (Client.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00A20784: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Client), ????);
            // 0x00A20788: LDR x0, [x19]              | X0 = typeof(Client);                    
            val_1 = null;
            label_2:
            // 0x00A2078C: LDR x8, [x0, #0xa0]        | X8 = Client.__il2cppRuntimeField_static_fields;
            // 0x00A20790: LDR x0, [x8]               | X0 = Client.instance;                   
            // 0x00A20794: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00A20798: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00A2079C: RET                        |  return (System.Object)Client.instance; 
            return (object)Client.instance;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
