using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class BMFont_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000098
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BCB564 (12367204), len: 8  VirtAddr: 0x00BCB564 RVA: 0x00BCB564 token: 100663859 methodIndex: 29904 delegateWrapperIndex: 0 methodInvoker: 0
        public BMFont_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BCB564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB568: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCB56C (12367212), len: 5232  VirtAddr: 0x00BCB56C RVA: 0x00BCB56C token: 100663860 methodIndex: 29905 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_52;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_53;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_54;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_55;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_56;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_57;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_58;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_59;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_60;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_61;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_62;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_63;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_64;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_65;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_66;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_67;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_68;
            // 0x00BCB56C: STP x28, x27, [sp, #-0x60]! | stack[1152921510060656688] = ???;  stack[1152921510060656696] = ???;  //  dest_result_addr=1152921510060656688 |  dest_result_addr=1152921510060656696
            // 0x00BCB570: STP x26, x25, [sp, #0x10]  | stack[1152921510060656704] = ???;  stack[1152921510060656712] = ???;  //  dest_result_addr=1152921510060656704 |  dest_result_addr=1152921510060656712
            // 0x00BCB574: STP x24, x23, [sp, #0x20]  | stack[1152921510060656720] = ???;  stack[1152921510060656728] = ???;  //  dest_result_addr=1152921510060656720 |  dest_result_addr=1152921510060656728
            // 0x00BCB578: STP x22, x21, [sp, #0x30]  | stack[1152921510060656736] = ???;  stack[1152921510060656744] = ???;  //  dest_result_addr=1152921510060656736 |  dest_result_addr=1152921510060656744
            // 0x00BCB57C: STP x20, x19, [sp, #0x40]  | stack[1152921510060656752] = ???;  stack[1152921510060656760] = ???;  //  dest_result_addr=1152921510060656752 |  dest_result_addr=1152921510060656760
            // 0x00BCB580: STP x29, x30, [sp, #0x50]  | stack[1152921510060656768] = ???;  stack[1152921510060656776] = ???;  //  dest_result_addr=1152921510060656768 |  dest_result_addr=1152921510060656776
            // 0x00BCB584: ADD x29, sp, #0x50         | X29 = (1152921510060656688 + 80) = 1152921510060656768 (0x1000000145128880);
            // 0x00BCB588: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCB58C: LDRB w8, [x20, #0xbba]     | W8 = (bool)static_value_03733BBA;       
            // 0x00BCB590: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCB594: TBNZ w8, #0, #0xbcb5b0     | if (static_value_03733BBA == true) goto label_0;
            // 0x00BCB598: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BCB59C: LDR x8, [x8, #0x7e0]       | X8 = 0x2B8F724;                         
            // 0x00BCB5A0: LDR w0, [x8]               | W0 = 0x148D;                            
            // 0x00BCB5A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x148D, ????);     
            // 0x00BCB5A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCB5AC: STRB w8, [x20, #0xbba]     | static_value_03733BBA = true;            //  dest_result_addr=57883578
            label_0:
            // 0x00BCB5B0: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00BCB5B4: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x00BCB5B8: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BCB5BC: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00BCB5C0: LDR x8, [x8, #0x778]       | X8 = 1152921504875909120;               
            // 0x00BCB5C4: LDR x20, [x8]              | X20 = typeof(BMFont);                   
            // 0x00BCB5C8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCB5CC: TBZ w8, #0, #0xbcb5dc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BCB5D0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB5D4: CBNZ w8, #0xbcb5dc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BCB5D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BCB5DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB5E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB5E4: MOV x1, x20                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCB5E8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCB5EC: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x00BCB5F0: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x00BCB5F4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BCB5F8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCB5FC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB600: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCB604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB608: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB60C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCB610: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB614: CBNZ x20, #0xbcb61c        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BCB618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x00BCB61C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00BCB620: LDR x8, [x8, #0xbb0]       | X8 = (string**)(1152921510060500000)("get_isValid");
            // 0x00BCB624: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB628: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCB62C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCB630: LDR x1, [x8]               | X1 = "get_isValid";                     
            // 0x00BCB634: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCB638: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB63C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCB640: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isValid", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_isValid", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCB644: ADRP x24, #0x35f7000       | X24 = 56586240 (0x35F7000);             
            // 0x00BCB648: LDR x24, [x24, #0xc60]     | X24 = 1152921504783151104;              
            // 0x00BCB64C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BCB650: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB654: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB658: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0;
            // 0x00BCB65C: CBNZ x22, #0xbcb6a8        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0) != null)
            {
                goto label_4;
            }
            // 0x00BCB660: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BCB664: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCB668: LDR x8, [x8, #0x790]       | X8 = 1152921510060504192;               
            // 0x00BCB66C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCB670: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_isValid_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCB674: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x00BCB678: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCB67C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB680: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB684: MOV x2, x22                | X2 = 1152921510060504192 (0x1000000145103480);//ML01
            // 0x00BCB688: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_3;
            // 0x00BCB68C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_isValid_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_isValid_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCB690: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB694: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB698: STR x23, [x8]              | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155200
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0 = val_52;
            // 0x00BCB69C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB6A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB6A4: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_4:
            // 0x00BCB6A8: CBNZ x19, #0xbcb6b0        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BCB6AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_isValid_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x00BCB6B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB6B4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB6B8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BCB6BC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCB6C0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache0);
            // 0x00BCB6C4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCB6C8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB6CC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCB6D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB6D4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB6D8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCB6DC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB6E0: CBNZ x20, #0xbcb6e8        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00BCB6E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x00BCB6E8: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x00BCB6EC: LDR x8, [x8, #0x4d8]       | X8 = (string**)(1152921510060505216)("get_charSize");
            // 0x00BCB6F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB6F4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCB6F8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCB6FC: LDR x1, [x8]               | X1 = "get_charSize";                    
            // 0x00BCB700: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCB704: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB708: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCB70C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_charSize", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "get_charSize", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCB710: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB714: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00BCB718: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB71C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1;
            // 0x00BCB720: CBNZ x22, #0xbcb76c        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1 != null) goto label_7;
            if((ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1) != null)
            {
                goto label_7;
            }
            // 0x00BCB724: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00BCB728: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCB72C: LDR x8, [x8, #0x950]       | X8 = 1152921510060509408;               
            // 0x00BCB730: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCB734: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_charSize_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCB738: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x00BCB73C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCB740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB744: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB748: MOV x2, x22                | X2 = 1152921510060509408 (0x10000001451048E0);//ML01
            // 0x00BCB74C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_5;
            // 0x00BCB750: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_charSize_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_charSize_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCB754: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB758: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB75C: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155208
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1 = val_52;
            // 0x00BCB760: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB764: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB768: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_7:
            // 0x00BCB76C: CBNZ x19, #0xbcb774        | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x00BCB770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_charSize_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_8:
            // 0x00BCB774: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB778: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB77C: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00BCB780: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCB784: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache1);
            // 0x00BCB788: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCB78C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB790: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCB794: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCB798: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB79C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCB7A0: ADRP x27, #0x3611000       | X27 = 56692736 (0x3611000);             
            // 0x00BCB7A4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCB7A8: LDR x27, [x27, #0x9a8]     | X27 = 1152921504607113216;              
            // 0x00BCB7AC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB7B0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCB7B4: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCB7B8: TBZ w9, #0, #0xbcb7cc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00BCB7BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB7C0: CBNZ w9, #0xbcb7cc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00BCB7C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCB7C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x00BCB7CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB7D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB7D4: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCB7D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCB7DC: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00BCB7E0: CBNZ x21, #0xbcb7e8        | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x00BCB7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_11:
            // 0x00BCB7E8: CBZ x22, #0xbcb80c         | if (val_6 == null) goto label_13;       
            if(val_6 == null)
            {
                goto label_13;
            }
            // 0x00BCB7EC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCB7F0: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x00BCB7F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCB7F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x00BCB7FC: CBNZ x0, #0xbcb80c         | if (val_6 != null) goto label_13;       
            if(val_6 != null)
            {
                goto label_13;
            }
            // 0x00BCB800: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x00BCB804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB808: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_13:
            // 0x00BCB80C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCB810: CBNZ w8, #0xbcb820         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_14;
            // 0x00BCB814: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x00BCB818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB81C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_14:
            // 0x00BCB820: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;
            // 0x00BCB824: CBNZ x20, #0xbcb82c        | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x00BCB828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x00BCB82C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00BCB830: LDR x8, [x8, #0x4c0]       | X8 = (string**)(1152921510060514528)("set_charSize");
            // 0x00BCB834: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB838: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCB83C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCB840: LDR x1, [x8]               | X1 = "set_charSize";                    
            // 0x00BCB844: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCB848: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB84C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCB850: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_charSize", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_7 = val_1.GetMethod(name:  "set_charSize", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCB854: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB858: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x00BCB85C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB860: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2;
            // 0x00BCB864: CBNZ x22, #0xbcb8b0        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2 != null) goto label_16;
            if((ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2) != null)
            {
                goto label_16;
            }
            // 0x00BCB868: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x00BCB86C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCB870: LDR x8, [x8, #0xa68]       | X8 = 1152921510060518720;               
            // 0x00BCB874: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCB878: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_charSize_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCB87C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = null;
            // 0x00BCB880: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCB884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB888: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB88C: MOV x2, x22                | X2 = 1152921510060518720 (0x1000000145106D40);//ML01
            // 0x00BCB890: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_8;
            // 0x00BCB894: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_charSize_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_charSize_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCB898: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB89C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB8A0: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155216
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2 = val_52;
            // 0x00BCB8A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB8A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB8AC: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_16:
            // 0x00BCB8B0: CBNZ x19, #0xbcb8b8        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BCB8B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_charSize_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_17:
            // 0x00BCB8B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB8BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB8C0: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x00BCB8C4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCB8C8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2);
            X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache2);
            // 0x00BCB8CC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCB8D0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB8D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCB8D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB8DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB8E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCB8E4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB8E8: CBNZ x20, #0xbcb8f0        | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x00BCB8EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_18:
            // 0x00BCB8F0: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00BCB8F4: LDR x8, [x8, #0xc0]        | X8 = (string**)(1152921510060519744)("get_baseOffset");
            // 0x00BCB8F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB8FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCB900: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCB904: LDR x1, [x8]               | X1 = "get_baseOffset";                  
            // 0x00BCB908: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCB90C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB910: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCB914: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_baseOffset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_9 = val_1.GetMethod(name:  "get_baseOffset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCB918: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB91C: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x00BCB920: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB924: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3;
            // 0x00BCB928: CBNZ x22, #0xbcb974        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3 != null) goto label_19;
            if((ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3) != null)
            {
                goto label_19;
            }
            // 0x00BCB92C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00BCB930: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCB934: LDR x8, [x8, #0x38]        | X8 = 1152921510060523936;               
            // 0x00BCB938: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCB93C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_baseOffset_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCB940: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_10 = null;
            // 0x00BCB944: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCB948: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB94C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB950: MOV x2, x22                | X2 = 1152921510060523936 (0x10000001451081A0);//ML01
            // 0x00BCB954: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_10;
            // 0x00BCB958: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_baseOffset_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_baseOffset_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCB95C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB960: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB964: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155224
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3 = val_52;
            // 0x00BCB968: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCB96C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCB970: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_19:
            // 0x00BCB974: CBNZ x19, #0xbcb97c        | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x00BCB978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_baseOffset_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_20:
            // 0x00BCB97C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB980: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB984: MOV x1, x21                | X1 = val_9;//m1                         
            // 0x00BCB988: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCB98C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_9, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3);
            X1.RegisterCLRMethodRedirection(mi:  val_9, func:  ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache3);
            // 0x00BCB990: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCB994: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB998: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCB99C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCB9A0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB9A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCB9A8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCB9AC: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCB9B0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCB9B4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCB9B8: TBZ w9, #0, #0xbcb9cc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00BCB9BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB9C0: CBNZ w9, #0xbcb9cc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00BCB9C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCB9C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_22:
            // 0x00BCB9CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB9D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB9D4: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCB9D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCB9DC: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x00BCB9E0: CBNZ x21, #0xbcb9e8        | if ( != null) goto label_23;            
            if(null != null)
            {
                goto label_23;
            }
            // 0x00BCB9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_23:
            // 0x00BCB9E8: CBZ x22, #0xbcba0c         | if (val_11 == null) goto label_25;      
            if(val_11 == null)
            {
                goto label_25;
            }
            // 0x00BCB9EC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCB9F0: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x00BCB9F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCB9F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x00BCB9FC: CBNZ x0, #0xbcba0c         | if (val_11 != null) goto label_25;      
            if(val_11 != null)
            {
                goto label_25;
            }
            // 0x00BCBA00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x00BCBA04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBA08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_25:
            // 0x00BCBA0C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCBA10: CBNZ w8, #0xbcba20         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_26;
            // 0x00BCBA14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x00BCBA18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBA1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_26:
            // 0x00BCBA20: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;
            // 0x00BCBA24: CBNZ x20, #0xbcba2c        | if (val_1 != null) goto label_27;       
            if(val_1 != null)
            {
                goto label_27;
            }
            // 0x00BCBA28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_27:
            // 0x00BCBA2C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00BCBA30: LDR x8, [x8, #0x1a0]       | X8 = (string**)(1152921510060529056)("set_baseOffset");
            // 0x00BCBA34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBA38: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBA3C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBA40: LDR x1, [x8]               | X1 = "set_baseOffset";                  
            // 0x00BCBA44: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBA48: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBA4C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBA50: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_baseOffset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_12 = val_1.GetMethod(name:  "set_baseOffset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBA54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBA58: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x00BCBA5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBA60: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache4;
            val_53 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache4;
            // 0x00BCBA64: CBNZ x22, #0xbcbab0        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache4 != null) goto label_28;
            if(val_53 != null)
            {
                goto label_28;
            }
            // 0x00BCBA68: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00BCBA6C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBA70: LDR x8, [x8, #0xab0]       | X8 = 1152921510060533248;               
            // 0x00BCBA74: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCBA78: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_baseOffset_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCBA7C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13 = null;
            // 0x00BCBA80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCBA84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBA88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBA8C: MOV x2, x22                | X2 = 1152921510060533248 (0x100000014510A600);//ML01
            // 0x00BCBA90: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_13;
            // 0x00BCBA94: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_baseOffset_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_baseOffset_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCBA98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBA9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBAA0: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155232
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache4 = val_52;
            // 0x00BCBAA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBAA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBAAC: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_53 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache4;
            label_28:
            // 0x00BCBAB0: CBNZ x19, #0xbcbab8        | if (X1 != 0) goto label_29;             
            if(X1 != 0)
            {
                goto label_29;
            }
            // 0x00BCBAB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_baseOffset_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_29:
            // 0x00BCBAB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBABC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCBAC0: MOV x1, x21                | X1 = val_12;//m1                        
            // 0x00BCBAC4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCBAC8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_53);
            X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_53);
            // 0x00BCBACC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCBAD0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBAD4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCBAD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBADC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBAE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCBAE4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBAE8: CBNZ x20, #0xbcbaf0        | if (val_1 != null) goto label_30;       
            if(val_1 != null)
            {
                goto label_30;
            }
            // 0x00BCBAEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_30:
            // 0x00BCBAF0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BCBAF4: LDR x8, [x8, #0xbb8]       | X8 = (string**)(1152921510060534272)("get_texWidth");
            // 0x00BCBAF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBAFC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBB00: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBB04: LDR x1, [x8]               | X1 = "get_texWidth";                    
            // 0x00BCBB08: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBB0C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBB10: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBB14: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_texWidth", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "get_texWidth", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBB18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBB1C: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00BCBB20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBB24: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache5;
            val_54 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache5;
            // 0x00BCBB28: CBNZ x22, #0xbcbb74        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache5 != null) goto label_31;
            if(val_54 != null)
            {
                goto label_31;
            }
            // 0x00BCBB2C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BCBB30: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBB34: LDR x8, [x8, #0xaa0]       | X8 = 1152921510060538464;               
            // 0x00BCBB38: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCBB3C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texWidth_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCBB40: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x00BCBB44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCBB48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBB4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBB50: MOV x2, x22                | X2 = 1152921510060538464 (0x100000014510BA60);//ML01
            // 0x00BCBB54: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_15;
            // 0x00BCBB58: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texWidth_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texWidth_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCBB5C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBB60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBB64: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155240
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache5 = val_52;
            // 0x00BCBB68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBB6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBB70: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_54 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache5;
            label_31:
            // 0x00BCBB74: CBNZ x19, #0xbcbb7c        | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x00BCBB78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texWidth_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_32:
            // 0x00BCBB7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBB80: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCBB84: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x00BCBB88: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCBB8C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_54);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_54);
            // 0x00BCBB90: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCBB94: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBB98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCBB9C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCBBA0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBBA4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCBBA8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCBBAC: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCBBB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBBB4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCBBB8: TBZ w9, #0, #0xbcbbcc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x00BCBBBC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCBBC0: CBNZ w9, #0xbcbbcc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x00BCBBC4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCBBC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x00BCBBCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCBBD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCBBD4: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCBBD8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCBBDC: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x00BCBBE0: CBNZ x21, #0xbcbbe8        | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x00BCBBE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_35:
            // 0x00BCBBE8: CBZ x22, #0xbcbc0c         | if (val_16 == null) goto label_37;      
            if(val_16 == null)
            {
                goto label_37;
            }
            // 0x00BCBBEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCBBF0: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x00BCBBF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCBBF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x00BCBBFC: CBNZ x0, #0xbcbc0c         | if (val_16 != null) goto label_37;      
            if(val_16 != null)
            {
                goto label_37;
            }
            // 0x00BCBC00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x00BCBC04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBC08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_37:
            // 0x00BCBC0C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCBC10: CBNZ w8, #0xbcbc20         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x00BCBC14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x00BCBC18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBC1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_38:
            // 0x00BCBC20: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;
            // 0x00BCBC24: CBNZ x20, #0xbcbc2c        | if (val_1 != null) goto label_39;       
            if(val_1 != null)
            {
                goto label_39;
            }
            // 0x00BCBC28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_39:
            // 0x00BCBC2C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00BCBC30: LDR x8, [x8, #0xf8]        | X8 = (string**)(1152921510060543584)("set_texWidth");
            // 0x00BCBC34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBC38: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBC3C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBC40: LDR x1, [x8]               | X1 = "set_texWidth";                    
            // 0x00BCBC44: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBC48: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBC4C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBC50: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_texWidth", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "set_texWidth", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBC54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBC58: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x00BCBC5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBC60: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache6;
            val_55 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache6;
            // 0x00BCBC64: CBNZ x22, #0xbcbcb0        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache6 != null) goto label_40;
            if(val_55 != null)
            {
                goto label_40;
            }
            // 0x00BCBC68: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00BCBC6C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBC70: LDR x8, [x8, #0xcb8]       | X8 = 1152921510060547776;               
            // 0x00BCBC74: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCBC78: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texWidth_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCBC7C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x00BCBC80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCBC84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBC88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBC8C: MOV x2, x22                | X2 = 1152921510060547776 (0x100000014510DEC0);//ML01
            // 0x00BCBC90: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_18;
            // 0x00BCBC94: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texWidth_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texWidth_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCBC98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBC9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBCA0: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155248
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache6 = val_52;
            // 0x00BCBCA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBCA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBCAC: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_55 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache6;
            label_40:
            // 0x00BCBCB0: CBNZ x19, #0xbcbcb8        | if (X1 != 0) goto label_41;             
            if(X1 != 0)
            {
                goto label_41;
            }
            // 0x00BCBCB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texWidth_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_41:
            // 0x00BCBCB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBCBC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCBCC0: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x00BCBCC4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCBCC8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_55);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_55);
            // 0x00BCBCCC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCBCD0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBCD4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCBCD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBCDC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBCE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCBCE4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBCE8: CBNZ x20, #0xbcbcf0        | if (val_1 != null) goto label_42;       
            if(val_1 != null)
            {
                goto label_42;
            }
            // 0x00BCBCEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_42:
            // 0x00BCBCF0: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00BCBCF4: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921510060548800)("get_texHeight");
            // 0x00BCBCF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBCFC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBD00: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBD04: LDR x1, [x8]               | X1 = "get_texHeight";                   
            // 0x00BCBD08: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBD0C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBD10: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBD14: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_texHeight", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_1.GetMethod(name:  "get_texHeight", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBD18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBD1C: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x00BCBD20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBD24: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache7;
            val_56 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache7;
            // 0x00BCBD28: CBNZ x22, #0xbcbd74        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache7 != null) goto label_43;
            if(val_56 != null)
            {
                goto label_43;
            }
            // 0x00BCBD2C: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00BCBD30: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBD34: LDR x8, [x8, #0xad8]       | X8 = 1152921510060552992;               
            // 0x00BCBD38: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCBD3C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texHeight_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCBD40: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_20 = null;
            // 0x00BCBD44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCBD48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBD4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBD50: MOV x2, x22                | X2 = 1152921510060552992 (0x100000014510F320);//ML01
            // 0x00BCBD54: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_20;
            // 0x00BCBD58: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texHeight_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texHeight_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCBD5C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBD60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBD64: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155256
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache7 = val_52;
            // 0x00BCBD68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBD6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBD70: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_56 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache7;
            label_43:
            // 0x00BCBD74: CBNZ x19, #0xbcbd7c        | if (X1 != 0) goto label_44;             
            if(X1 != 0)
            {
                goto label_44;
            }
            // 0x00BCBD78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_texHeight_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_44:
            // 0x00BCBD7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBD80: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCBD84: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x00BCBD88: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCBD8C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_56);
            X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_56);
            // 0x00BCBD90: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCBD94: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBD98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCBD9C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCBDA0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBDA4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCBDA8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCBDAC: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCBDB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBDB4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCBDB8: TBZ w9, #0, #0xbcbdcc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_46;
            // 0x00BCBDBC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCBDC0: CBNZ w9, #0xbcbdcc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_46;
            // 0x00BCBDC4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCBDC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_46:
            // 0x00BCBDCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCBDD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCBDD4: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCBDD8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_21 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCBDDC: MOV x22, x0                | X22 = val_21;//m1                       
            // 0x00BCBDE0: CBNZ x21, #0xbcbde8        | if ( != null) goto label_47;            
            if(null != null)
            {
                goto label_47;
            }
            // 0x00BCBDE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_47:
            // 0x00BCBDE8: CBZ x22, #0xbcbe0c         | if (val_21 == null) goto label_49;      
            if(val_21 == null)
            {
                goto label_49;
            }
            // 0x00BCBDEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCBDF0: MOV x0, x22                | X0 = val_21;//m1                        
            // 0x00BCBDF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCBDF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_21, ????);     
            // 0x00BCBDFC: CBNZ x0, #0xbcbe0c         | if (val_21 != null) goto label_49;      
            if(val_21 != null)
            {
                goto label_49;
            }
            // 0x00BCBE00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_21, ????);     
            // 0x00BCBE04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBE08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_49:
            // 0x00BCBE0C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCBE10: CBNZ w8, #0xbcbe20         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_50;
            // 0x00BCBE14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
            // 0x00BCBE18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBE1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_50:
            // 0x00BCBE20: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_21;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_21;
            // 0x00BCBE24: CBNZ x20, #0xbcbe2c        | if (val_1 != null) goto label_51;       
            if(val_1 != null)
            {
                goto label_51;
            }
            // 0x00BCBE28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_51:
            // 0x00BCBE2C: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00BCBE30: LDR x8, [x8, #0xe20]       | X8 = (string**)(1152921510060558112)("set_texHeight");
            // 0x00BCBE34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBE38: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBE3C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBE40: LDR x1, [x8]               | X1 = "set_texHeight";                   
            // 0x00BCBE44: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBE48: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBE4C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBE50: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_texHeight", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_22 = val_1.GetMethod(name:  "set_texHeight", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBE54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBE58: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x00BCBE5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBE60: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache8;
            val_57 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache8;
            // 0x00BCBE64: CBNZ x22, #0xbcbeb0        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache8 != null) goto label_52;
            if(val_57 != null)
            {
                goto label_52;
            }
            // 0x00BCBE68: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00BCBE6C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBE70: LDR x8, [x8, #0xb28]       | X8 = 1152921510060562304;               
            // 0x00BCBE74: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCBE78: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texHeight_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCBE7C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23 = null;
            // 0x00BCBE80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCBE84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBE88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBE8C: MOV x2, x22                | X2 = 1152921510060562304 (0x1000000145111780);//ML01
            // 0x00BCBE90: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_23;
            // 0x00BCBE94: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texHeight_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texHeight_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCBE98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBE9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBEA0: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155264
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache8 = val_52;
            // 0x00BCBEA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBEA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBEAC: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_57 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache8;
            label_52:
            // 0x00BCBEB0: CBNZ x19, #0xbcbeb8        | if (X1 != 0) goto label_53;             
            if(X1 != 0)
            {
                goto label_53;
            }
            // 0x00BCBEB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_texHeight_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_53:
            // 0x00BCBEB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBEBC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCBEC0: MOV x1, x21                | X1 = val_22;//m1                        
            // 0x00BCBEC4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCBEC8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_57);
            X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_57);
            // 0x00BCBECC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCBED0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBED4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCBED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBEDC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBEE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCBEE4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBEE8: CBNZ x20, #0xbcbef0        | if (val_1 != null) goto label_54;       
            if(val_1 != null)
            {
                goto label_54;
            }
            // 0x00BCBEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_54:
            // 0x00BCBEF0: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00BCBEF4: LDR x8, [x8, #0xd28]       | X8 = (string**)(1152921510060563328)("get_glyphCount");
            // 0x00BCBEF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBEFC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBF00: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBF04: LDR x1, [x8]               | X1 = "get_glyphCount";                  
            // 0x00BCBF08: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBF0C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBF10: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBF14: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_glyphCount", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_24 = val_1.GetMethod(name:  "get_glyphCount", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBF18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBF1C: MOV x21, x0                | X21 = val_24;//m1                       
            // 0x00BCBF20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBF24: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache9;
            val_58 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache9;
            // 0x00BCBF28: CBNZ x22, #0xbcbf74        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache9 != null) goto label_55;
            if(val_58 != null)
            {
                goto label_55;
            }
            // 0x00BCBF2C: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00BCBF30: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBF34: LDR x8, [x8, #0x560]       | X8 = 1152921510060567520;               
            // 0x00BCBF38: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCBF3C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphCount_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCBF40: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25 = null;
            // 0x00BCBF44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCBF48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBF4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBF50: MOV x2, x22                | X2 = 1152921510060567520 (0x1000000145112BE0);//ML01
            // 0x00BCBF54: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_25;
            // 0x00BCBF58: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphCount_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphCount_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCBF5C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBF60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBF64: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155272
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache9 = val_52;
            // 0x00BCBF68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBF6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBF70: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_58 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache9;
            label_55:
            // 0x00BCBF74: CBNZ x19, #0xbcbf7c        | if (X1 != 0) goto label_56;             
            if(X1 != 0)
            {
                goto label_56;
            }
            // 0x00BCBF78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphCount_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_56:
            // 0x00BCBF7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBF80: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCBF84: MOV x1, x21                | X1 = val_24;//m1                        
            // 0x00BCBF88: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCBF8C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_58);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_58);
            // 0x00BCBF90: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCBF94: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBF98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCBF9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCBFA0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBFA4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCBFA8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBFAC: CBNZ x20, #0xbcbfb4        | if (val_1 != null) goto label_57;       
            if(val_1 != null)
            {
                goto label_57;
            }
            // 0x00BCBFB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_57:
            // 0x00BCBFB4: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00BCBFB8: LDR x8, [x8, #0x148]       | X8 = (string**)(1152921510060568544)("get_spriteName");
            // 0x00BCBFBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCBFC0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCBFC4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCBFC8: LDR x1, [x8]               | X1 = "get_spriteName";                  
            // 0x00BCBFCC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCBFD0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCBFD4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCBFD8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_spriteName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_26 = val_1.GetMethod(name:  "get_spriteName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCBFDC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCBFE0: MOV x21, x0                | X21 = val_26;//m1                       
            // 0x00BCBFE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCBFE8: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheA;
            val_59 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheA;
            // 0x00BCBFEC: CBNZ x22, #0xbcc038        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheA != null) goto label_58;
            if(val_59 != null)
            {
                goto label_58;
            }
            // 0x00BCBFF0: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00BCBFF4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCBFF8: LDR x8, [x8, #0xcd0]       | X8 = 1152921510060572736;               
            // 0x00BCBFFC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC000: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_spriteName_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC004: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27 = null;
            // 0x00BCC008: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC00C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC010: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC014: MOV x2, x22                | X2 = 1152921510060572736 (0x1000000145114040);//ML01
            // 0x00BCC018: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_27;
            // 0x00BCC01C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_spriteName_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_spriteName_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC020: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC024: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC028: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155280
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheA = val_52;
            // 0x00BCC02C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC030: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC034: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_59 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheA;
            label_58:
            // 0x00BCC038: CBNZ x19, #0xbcc040        | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x00BCC03C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_spriteName_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_59:
            // 0x00BCC040: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC044: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC048: MOV x1, x21                | X1 = val_26;//m1                        
            // 0x00BCC04C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC050: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_59);
            X1.RegisterCLRMethodRedirection(mi:  val_26, func:  val_59);
            // 0x00BCC054: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC058: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC05C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC060: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCC064: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC068: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC06C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BCC070: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCC074: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BCC078: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC07C: LDR x22, [x9]              | X22 = typeof(System.String);            
            // 0x00BCC080: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCC084: TBZ w9, #0, #0xbcc098      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_61;
            // 0x00BCC088: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCC08C: CBNZ w9, #0xbcc098         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x00BCC090: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCC094: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_61:
            // 0x00BCC098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC09C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC0A0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BCC0A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC0A8: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x00BCC0AC: CBNZ x21, #0xbcc0b4        | if ( != null) goto label_62;            
            if(null != null)
            {
                goto label_62;
            }
            // 0x00BCC0B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_62:
            // 0x00BCC0B4: CBZ x22, #0xbcc0d8         | if (val_28 == null) goto label_64;      
            if(val_28 == null)
            {
                goto label_64;
            }
            // 0x00BCC0B8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC0BC: MOV x0, x22                | X0 = val_28;//m1                        
            // 0x00BCC0C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC0C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x00BCC0C8: CBNZ x0, #0xbcc0d8         | if (val_28 != null) goto label_64;      
            if(val_28 != null)
            {
                goto label_64;
            }
            // 0x00BCC0CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x00BCC0D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC0D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_64:
            // 0x00BCC0D8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC0DC: CBNZ w8, #0xbcc0ec         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_65;
            // 0x00BCC0E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x00BCC0E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC0E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_65:
            // 0x00BCC0EC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_28;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_28;
            // 0x00BCC0F0: CBNZ x20, #0xbcc0f8        | if (val_1 != null) goto label_66;       
            if(val_1 != null)
            {
                goto label_66;
            }
            // 0x00BCC0F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_66:
            // 0x00BCC0F8: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00BCC0FC: LDR x8, [x8, #0x650]       | X8 = (string**)(1152921510060577856)("set_spriteName");
            // 0x00BCC100: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC104: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC108: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCC10C: LDR x1, [x8]               | X1 = "set_spriteName";                  
            // 0x00BCC110: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC114: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC118: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCC11C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_spriteName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_29 = val_1.GetMethod(name:  "set_spriteName", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC120: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC124: MOV x21, x0                | X21 = val_29;//m1                       
            // 0x00BCC128: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC12C: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheB;
            val_60 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheB;
            // 0x00BCC130: CBNZ x22, #0xbcc17c        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheB != null) goto label_67;
            if(val_60 != null)
            {
                goto label_67;
            }
            // 0x00BCC134: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00BCC138: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC13C: LDR x8, [x8, #0x340]       | X8 = 1152921510060582048;               
            // 0x00BCC140: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC144: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_spriteName_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC148: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_30 = null;
            // 0x00BCC14C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC154: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC158: MOV x2, x22                | X2 = 1152921510060582048 (0x10000001451164A0);//ML01
            // 0x00BCC15C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_30;
            // 0x00BCC160: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_spriteName_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_30 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_spriteName_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC164: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC168: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC16C: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155288
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheB = val_52;
            // 0x00BCC170: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC174: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC178: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_60 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheB;
            label_67:
            // 0x00BCC17C: CBNZ x19, #0xbcc184        | if (X1 != 0) goto label_68;             
            if(X1 != 0)
            {
                goto label_68;
            }
            // 0x00BCC180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::set_spriteName_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_68:
            // 0x00BCC184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC188: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC18C: MOV x1, x21                | X1 = val_29;//m1                        
            // 0x00BCC190: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC194: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_29, func:  val_60);
            X1.RegisterCLRMethodRedirection(mi:  val_29, func:  val_60);
            // 0x00BCC198: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC19C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC1A0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC1A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC1A8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC1AC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC1B0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC1B4: CBNZ x20, #0xbcc1bc        | if (val_1 != null) goto label_69;       
            if(val_1 != null)
            {
                goto label_69;
            }
            // 0x00BCC1B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_69:
            // 0x00BCC1BC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BCC1C0: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921510060583072)("get_glyphs");
            // 0x00BCC1C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC1C8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC1CC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCC1D0: LDR x1, [x8]               | X1 = "get_glyphs";                      
            // 0x00BCC1D4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC1D8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC1DC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCC1E0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_glyphs", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_31 = val_1.GetMethod(name:  "get_glyphs", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC1E4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC1E8: MOV x21, x0                | X21 = val_31;//m1                       
            // 0x00BCC1EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC1F0: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheC;
            val_61 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheC;
            // 0x00BCC1F4: CBNZ x22, #0xbcc240        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheC != null) goto label_70;
            if(val_61 != null)
            {
                goto label_70;
            }
            // 0x00BCC1F8: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00BCC1FC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC200: LDR x8, [x8, #0x248]       | X8 = 1152921510060587264;               
            // 0x00BCC204: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC208: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphs_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC20C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_32 = null;
            // 0x00BCC210: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC214: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC218: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC21C: MOV x2, x22                | X2 = 1152921510060587264 (0x1000000145117900);//ML01
            // 0x00BCC220: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_32;
            // 0x00BCC224: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphs_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_32 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphs_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC228: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC22C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC230: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155296
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheC = val_52;
            // 0x00BCC234: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC238: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC23C: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_61 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheC;
            label_70:
            // 0x00BCC240: CBNZ x19, #0xbcc248        | if (X1 != 0) goto label_71;             
            if(X1 != 0)
            {
                goto label_71;
            }
            // 0x00BCC244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::get_glyphs_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_71:
            // 0x00BCC248: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC24C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC250: MOV x1, x21                | X1 = val_31;//m1                        
            // 0x00BCC254: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC258: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_31, func:  val_61);
            X1.RegisterCLRMethodRedirection(mi:  val_31, func:  val_61);
            // 0x00BCC25C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC260: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC264: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC268: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BCC26C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC270: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC274: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCC278: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCC27C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC280: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCC284: TBZ w9, #0, #0xbcc298      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_73;
            // 0x00BCC288: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCC28C: CBNZ w9, #0xbcc298         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
            // 0x00BCC290: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCC294: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_73:
            // 0x00BCC298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC29C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC2A0: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCC2A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_33 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC2A8: MOV x22, x0                | X22 = val_33;//m1                       
            // 0x00BCC2AC: CBNZ x21, #0xbcc2b4        | if ( != null) goto label_74;            
            if(null != null)
            {
                goto label_74;
            }
            // 0x00BCC2B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_74:
            // 0x00BCC2B4: CBZ x22, #0xbcc2d8         | if (val_33 == null) goto label_76;      
            if(val_33 == null)
            {
                goto label_76;
            }
            // 0x00BCC2B8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC2BC: MOV x0, x22                | X0 = val_33;//m1                        
            // 0x00BCC2C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC2C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_33, ????);     
            // 0x00BCC2C8: CBNZ x0, #0xbcc2d8         | if (val_33 != null) goto label_76;      
            if(val_33 != null)
            {
                goto label_76;
            }
            // 0x00BCC2CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_33, ????);     
            // 0x00BCC2D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC2D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            label_76:
            // 0x00BCC2D8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC2DC: CBNZ w8, #0xbcc2ec         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_77;
            // 0x00BCC2E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_33, ????);     
            // 0x00BCC2E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC2E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            label_77:
            // 0x00BCC2EC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_33;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_33;
            // 0x00BCC2F0: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BCC2F4: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x00BCC2F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC2FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC300: LDR x1, [x8]               | X1 = typeof(System.Boolean);            
            // 0x00BCC304: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_34 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC308: MOV x22, x0                | X22 = val_34;//m1                       
            // 0x00BCC30C: CBZ x22, #0xbcc330         | if (val_34 == null) goto label_79;      
            if(val_34 == null)
            {
                goto label_79;
            }
            // 0x00BCC310: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC314: MOV x0, x22                | X0 = val_34;//m1                        
            // 0x00BCC318: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC31C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_34, ????);     
            // 0x00BCC320: CBNZ x0, #0xbcc330         | if (val_34 != null) goto label_79;      
            if(val_34 != null)
            {
                goto label_79;
            }
            // 0x00BCC324: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_34, ????);     
            // 0x00BCC328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC32C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
            label_79:
            // 0x00BCC330: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC334: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BCC338: B.HI #0xbcc348             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_80;
            // 0x00BCC33C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_34, ????);     
            // 0x00BCC340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC344: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
            label_80:
            // 0x00BCC348: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_34;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_34;
            // 0x00BCC34C: CBNZ x20, #0xbcc354        | if (val_1 != null) goto label_81;       
            if(val_1 != null)
            {
                goto label_81;
            }
            // 0x00BCC350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_81:
            // 0x00BCC354: ADRP x28, #0x3670000       | X28 = 57081856 (0x3670000);             
            // 0x00BCC358: LDR x28, [x28, #0xe38]     | X28 = (string**)(1152921510060596480)("GetGlyph");
            // 0x00BCC35C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC360: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC364: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCC368: LDR x1, [x28]              | X1 = "GetGlyph";                        
            // 0x00BCC36C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC370: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC374: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCC378: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetGlyph", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_35 = val_1.GetMethod(name:  "GetGlyph", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC37C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC380: MOV x21, x0                | X21 = val_35;//m1                       
            // 0x00BCC384: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC388: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheD;
            val_62 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheD;
            // 0x00BCC38C: CBNZ x22, #0xbcc3d8        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheD != null) goto label_82;
            if(val_62 != null)
            {
                goto label_82;
            }
            // 0x00BCC390: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00BCC394: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC398: LDR x8, [x8, #0x330]       | X8 = 1152921510060600672;               
            // 0x00BCC39C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC3A0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC3A4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_36 = null;
            // 0x00BCC3A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC3AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC3B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC3B4: MOV x2, x22                | X2 = 1152921510060600672 (0x100000014511AD60);//ML01
            // 0x00BCC3B8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_36;
            // 0x00BCC3BC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_36 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC3C0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC3C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC3C8: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155304
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheD = val_52;
            // 0x00BCC3CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC3D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC3D4: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_62 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheD;
            label_82:
            // 0x00BCC3D8: CBNZ x19, #0xbcc3e0        | if (X1 != 0) goto label_83;             
            if(X1 != 0)
            {
                goto label_83;
            }
            // 0x00BCC3DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_83:
            // 0x00BCC3E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC3E4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC3E8: MOV x1, x21                | X1 = val_35;//m1                        
            // 0x00BCC3EC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC3F0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_35, func:  val_62);
            X1.RegisterCLRMethodRedirection(mi:  val_35, func:  val_62);
            // 0x00BCC3F4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC3F8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC3FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC400: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BCC404: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC408: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC40C: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCC410: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCC414: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC418: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCC41C: TBZ w9, #0, #0xbcc430      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_85;
            // 0x00BCC420: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCC424: CBNZ w9, #0xbcc430         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_85;
            // 0x00BCC428: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCC42C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_85:
            // 0x00BCC430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC434: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC438: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCC43C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_37 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC440: MOV x22, x0                | X22 = val_37;//m1                       
            // 0x00BCC444: CBNZ x21, #0xbcc44c        | if ( != null) goto label_86;            
            if(null != null)
            {
                goto label_86;
            }
            // 0x00BCC448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_86:
            // 0x00BCC44C: CBZ x22, #0xbcc470         | if (val_37 == null) goto label_88;      
            if(val_37 == null)
            {
                goto label_88;
            }
            // 0x00BCC450: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC454: MOV x0, x22                | X0 = val_37;//m1                        
            // 0x00BCC458: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC45C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_37, ????);     
            // 0x00BCC460: CBNZ x0, #0xbcc470         | if (val_37 != null) goto label_88;      
            if(val_37 != null)
            {
                goto label_88;
            }
            // 0x00BCC464: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_37, ????);     
            // 0x00BCC468: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC46C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
            label_88:
            // 0x00BCC470: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC474: CBNZ w8, #0xbcc484         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_89;
            // 0x00BCC478: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_37, ????);     
            // 0x00BCC47C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC480: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
            label_89:
            // 0x00BCC484: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_37;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_37;
            // 0x00BCC488: CBNZ x20, #0xbcc490        | if (val_1 != null) goto label_90;       
            if(val_1 != null)
            {
                goto label_90;
            }
            // 0x00BCC48C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_90:
            // 0x00BCC490: LDR x1, [x28]              | X1 = "GetGlyph";                        
            // 0x00BCC494: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC498: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC49C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCC4A0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC4A4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC4A8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCC4AC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetGlyph", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_38 = val_1.GetMethod(name:  "GetGlyph", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC4B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC4B4: MOV x21, x0                | X21 = val_38;//m1                       
            // 0x00BCC4B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC4BC: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheE;
            val_63 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheE;
            // 0x00BCC4C0: CBNZ x22, #0xbcc50c        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheE != null) goto label_91;
            if(val_63 != null)
            {
                goto label_91;
            }
            // 0x00BCC4C4: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00BCC4C8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC4CC: LDR x8, [x8, #0xe60]       | X8 = 1152921510060609888;               
            // 0x00BCC4D0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC4D4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC4D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_39 = null;
            // 0x00BCC4DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC4E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC4E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC4E8: MOV x2, x22                | X2 = 1152921510060609888 (0x100000014511D160);//ML01
            // 0x00BCC4EC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_39;
            // 0x00BCC4F0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_39 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC4F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC4F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC4FC: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155312
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheE = val_52;
            // 0x00BCC500: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC504: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC508: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_63 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheE;
            label_91:
            // 0x00BCC50C: CBNZ x19, #0xbcc514        | if (X1 != 0) goto label_92;             
            if(X1 != 0)
            {
                goto label_92;
            }
            // 0x00BCC510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::GetGlyph_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_92:
            // 0x00BCC514: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC518: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC51C: MOV x1, x21                | X1 = val_38;//m1                        
            // 0x00BCC520: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC524: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_38, func:  val_63);
            X1.RegisterCLRMethodRedirection(mi:  val_38, func:  val_63);
            // 0x00BCC528: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC52C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC530: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC538: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC53C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC540: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC544: CBNZ x20, #0xbcc54c        | if (val_1 != null) goto label_93;       
            if(val_1 != null)
            {
                goto label_93;
            }
            // 0x00BCC548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_93:
            // 0x00BCC54C: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BCC550: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921510043458688)("Clear");
            // 0x00BCC554: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC558: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC55C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCC560: LDR x1, [x8]               | X1 = "Clear";                           
            // 0x00BCC564: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC568: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC56C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCC570: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_40 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC574: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC578: MOV x21, x0                | X21 = val_40;//m1                       
            // 0x00BCC57C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC580: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheF;
            val_64 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheF;
            // 0x00BCC584: CBNZ x22, #0xbcc5d0        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheF != null) goto label_94;
            if(val_64 != null)
            {
                goto label_94;
            }
            // 0x00BCC588: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00BCC58C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC590: LDR x8, [x8, #0x5f0]       | X8 = 1152921510060615008;               
            // 0x00BCC594: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC598: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC59C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_41 = null;
            // 0x00BCC5A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC5A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC5A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC5AC: MOV x2, x22                | X2 = 1152921510060615008 (0x100000014511E560);//ML01
            // 0x00BCC5B0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_41;
            // 0x00BCC5B4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_41 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC5B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC5BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC5C0: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155320
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheF = val_52;
            // 0x00BCC5C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC5C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC5CC: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_64 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cacheF;
            label_94:
            // 0x00BCC5D0: CBNZ x19, #0xbcc5d8        | if (X1 != 0) goto label_95;             
            if(X1 != 0)
            {
                goto label_95;
            }
            // 0x00BCC5D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_95:
            // 0x00BCC5D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC5DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC5E0: MOV x1, x21                | X1 = val_40;//m1                        
            // 0x00BCC5E4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC5E8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_40, func:  val_64);
            X1.RegisterCLRMethodRedirection(mi:  val_40, func:  val_64);
            // 0x00BCC5EC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC5F0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC5F4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC5F8: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00BCC5FC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC600: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC604: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BCC608: LDR x22, [x27]             | X22 = typeof(System.Int32);             
            // 0x00BCC60C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC610: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCC614: TBZ w9, #0, #0xbcc628      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_97;
            // 0x00BCC618: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCC61C: CBNZ w9, #0xbcc628         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_97;
            // 0x00BCC620: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCC624: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_97:
            // 0x00BCC628: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC62C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC630: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BCC634: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_42 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC638: MOV x22, x0                | X22 = val_42;//m1                       
            // 0x00BCC63C: CBNZ x21, #0xbcc644        | if ( != null) goto label_98;            
            if(null != null)
            {
                goto label_98;
            }
            // 0x00BCC640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_98:
            // 0x00BCC644: CBZ x22, #0xbcc668         | if (val_42 == null) goto label_100;     
            if(val_42 == null)
            {
                goto label_100;
            }
            // 0x00BCC648: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC64C: MOV x0, x22                | X0 = val_42;//m1                        
            // 0x00BCC650: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC654: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_42, ????);     
            // 0x00BCC658: CBNZ x0, #0xbcc668         | if (val_42 != null) goto label_100;     
            if(val_42 != null)
            {
                goto label_100;
            }
            // 0x00BCC65C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_42, ????);     
            // 0x00BCC660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC664: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_100:
            // 0x00BCC668: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC66C: CBNZ w8, #0xbcc67c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_101;
            // 0x00BCC670: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00BCC674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_101:
            // 0x00BCC67C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_42;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_42;
            // 0x00BCC680: LDR x1, [x27]              | X1 = typeof(System.Int32);              
            // 0x00BCC684: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC688: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC68C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_43 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC690: MOV x22, x0                | X22 = val_43;//m1                       
            // 0x00BCC694: CBZ x22, #0xbcc6b8         | if (val_43 == null) goto label_103;     
            if(val_43 == null)
            {
                goto label_103;
            }
            // 0x00BCC698: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC69C: MOV x0, x22                | X0 = val_43;//m1                        
            // 0x00BCC6A0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC6A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_43, ????);     
            // 0x00BCC6A8: CBNZ x0, #0xbcc6b8         | if (val_43 != null) goto label_103;     
            if(val_43 != null)
            {
                goto label_103;
            }
            // 0x00BCC6AC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_43, ????);     
            // 0x00BCC6B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC6B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            label_103:
            // 0x00BCC6B8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC6BC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BCC6C0: B.HI #0xbcc6d0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_104;
            // 0x00BCC6C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_43, ????);     
            // 0x00BCC6C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC6CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            label_104:
            // 0x00BCC6D0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_43;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_43;
            // 0x00BCC6D4: LDR x1, [x27]              | X1 = typeof(System.Int32);              
            // 0x00BCC6D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC6DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC6E0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_44 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC6E4: MOV x22, x0                | X22 = val_44;//m1                       
            // 0x00BCC6E8: CBZ x22, #0xbcc70c         | if (val_44 == null) goto label_106;     
            if(val_44 == null)
            {
                goto label_106;
            }
            // 0x00BCC6EC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC6F0: MOV x0, x22                | X0 = val_44;//m1                        
            // 0x00BCC6F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC6F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_44, ????);     
            // 0x00BCC6FC: CBNZ x0, #0xbcc70c         | if (val_44 != null) goto label_106;     
            if(val_44 != null)
            {
                goto label_106;
            }
            // 0x00BCC700: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_44, ????);     
            // 0x00BCC704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC708: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_44, ????);     
            label_106:
            // 0x00BCC70C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC710: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BCC714: B.HI #0xbcc724             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_107;
            // 0x00BCC718: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_44, ????);     
            // 0x00BCC71C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC720: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_44, ????);     
            label_107:
            // 0x00BCC724: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_44;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_44;
            // 0x00BCC728: LDR x1, [x27]              | X1 = typeof(System.Int32);              
            // 0x00BCC72C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCC730: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC734: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_45 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCC738: MOV x22, x0                | X22 = val_45;//m1                       
            // 0x00BCC73C: CBZ x22, #0xbcc760         | if (val_45 == null) goto label_109;     
            if(val_45 == null)
            {
                goto label_109;
            }
            // 0x00BCC740: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BCC744: MOV x0, x22                | X0 = val_45;//m1                        
            // 0x00BCC748: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BCC74C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_45, ????);     
            // 0x00BCC750: CBNZ x0, #0xbcc760         | if (val_45 != null) goto label_109;     
            if(val_45 != null)
            {
                goto label_109;
            }
            // 0x00BCC754: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_45, ????);     
            // 0x00BCC758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC75C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_45, ????);     
            label_109:
            // 0x00BCC760: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCC764: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00BCC768: B.HI #0xbcc778             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_110;
            // 0x00BCC76C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_45, ????);     
            // 0x00BCC770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC774: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_45, ????);     
            label_110:
            // 0x00BCC778: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_45;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_45;
            // 0x00BCC77C: CBNZ x20, #0xbcc784        | if (val_1 != null) goto label_111;      
            if(val_1 != null)
            {
                goto label_111;
            }
            // 0x00BCC780: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
            label_111:
            // 0x00BCC784: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BCC788: LDR x8, [x8, #0x6c8]       | X8 = (string**)(1152921510060632416)("Trim");
            // 0x00BCC78C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC790: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC794: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCC798: LDR x1, [x8]               | X1 = "Trim";                            
            // 0x00BCC79C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC7A0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC7A4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCC7A8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Trim", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_46 = val_1.GetMethod(name:  "Trim", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC7AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC7B0: MOV x21, x0                | X21 = val_46;//m1                       
            // 0x00BCC7B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC7B8: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache10;
            val_65 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache10;
            // 0x00BCC7BC: CBNZ x22, #0xbcc808        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache10 != null) goto label_112;
            if(val_65 != null)
            {
                goto label_112;
            }
            // 0x00BCC7C0: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x00BCC7C4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC7C8: LDR x8, [x8, #0x870]       | X8 = 1152921510060636592;               
            // 0x00BCC7CC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC7D0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Trim_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC7D4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_47 = null;
            // 0x00BCC7D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC7DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC7E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC7E4: MOV x2, x22                | X2 = 1152921510060636592 (0x10000001451239B0);//ML01
            // 0x00BCC7E8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_52 = val_47;
            // 0x00BCC7EC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Trim_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_47 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Trim_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC7F0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC7F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC7F8: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155328
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache10 = val_52;
            // 0x00BCC7FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC800: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC804: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_65 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache10;
            label_112:
            // 0x00BCC808: CBNZ x19, #0xbcc810        | if (X1 != 0) goto label_113;            
            if(X1 != 0)
            {
                goto label_113;
            }
            // 0x00BCC80C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Trim_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_113:
            // 0x00BCC810: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC814: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC818: MOV x1, x21                | X1 = val_46;//m1                        
            // 0x00BCC81C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC820: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_46, func:  val_65);
            X1.RegisterCLRMethodRedirection(mi:  val_46, func:  val_65);
            // 0x00BCC824: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC828: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC82C: LDR x21, [x8, #0x90]       | X21 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache0;
            val_66 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache0;
            // 0x00BCC830: CBNZ x21, #0xbcc87c        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache0 != null) goto label_114;
            if(val_66 != null)
            {
                goto label_114;
            }
            // 0x00BCC834: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00BCC838: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BCC83C: LDR x8, [x8, #0xad0]       | X8 = 1152921510060637616;               
            // 0x00BCC840: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BCC844: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__0();
            // 0x00BCC848: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_48 = null;
            // 0x00BCC84C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BCC850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC854: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC858: MOV x2, x21                | X2 = 1152921510060637616 (0x1000000145123DB0);//ML01
            // 0x00BCC85C: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BCC860: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__0());
            val_48 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__0());
            // 0x00BCC864: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC868: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC86C: STR x22, [x8, #0x90]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504783155344
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache0 = val_48;
            // 0x00BCC870: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC874: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC878: LDR x21, [x8, #0x90]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_66 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache0;
            label_114:
            // 0x00BCC87C: CBNZ x19, #0xbcc884        | if (X1 != 0) goto label_115;            
            if(X1 != 0)
            {
                goto label_115;
            }
            // 0x00BCC880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__0()), ????);
            label_115:
            // 0x00BCC884: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC888: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC88C: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BCC890: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BCC894: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_66);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_66);
            // 0x00BCC898: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC89C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC8A0: LDR x21, [x8, #0x98]       | X21 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache1;
            val_67 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache1;
            // 0x00BCC8A4: CBNZ x21, #0xbcc8f0        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache1 != null) goto label_116;
            if(val_67 != null)
            {
                goto label_116;
            }
            // 0x00BCC8A8: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00BCC8AC: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BCC8B0: LDR x8, [x8, #0xd30]       | X8 = 1152921510060638640;               
            // 0x00BCC8B4: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BCC8B8: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__1(int s);
            // 0x00BCC8BC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_49 = null;
            // 0x00BCC8C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BCC8C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC8C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC8CC: MOV x2, x21                | X2 = 1152921510060638640 (0x10000001451241B0);//ML01
            // 0x00BCC8D0: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BCC8D4: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__1(int s));
            val_49 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__1(int s));
            // 0x00BCC8D8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC8DC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC8E0: STR x22, [x8, #0x98]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504783155352
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache1 = val_49;
            // 0x00BCC8E4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC8E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC8EC: LDR x21, [x8, #0x98]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_67 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__am$cache1;
            label_116:
            // 0x00BCC8F0: CBNZ x19, #0xbcc8f8        | if (X1 != 0) goto label_117;            
            if(X1 != 0)
            {
                goto label_117;
            }
            // 0x00BCC8F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMFont_Binding::<Register>m__1(int s)), ????);
            label_117:
            // 0x00BCC8F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC8FC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC900: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BCC904: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BCC908: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_67);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_67);
            // 0x00BCC90C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCC910: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC914: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCC918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC91C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC920: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCC924: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC928: CBNZ x20, #0xbcc930        | if (val_1 != null) goto label_118;      
            if(val_1 != null)
            {
                goto label_118;
            }
            // 0x00BCC92C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_118:
            // 0x00BCC930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCC934: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCC938: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BCC93C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCC940: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCC944: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCC948: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_50 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCC94C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC950: MOV x20, x0                | X20 = val_50;//m1                       
            // 0x00BCC954: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC958: LDR x21, [x8, #0x88]       | X21 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache11;
            val_68 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache11;
            // 0x00BCC95C: CBNZ x21, #0xbcc9a8        | if (ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache11 != null) goto label_119;
            if(val_68 != null)
            {
                goto label_119;
            }
            // 0x00BCC960: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00BCC964: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCC968: LDR x8, [x8, #0x720]       | X8 = 1152921510060643760;               
            // 0x00BCC96C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCC970: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCC974: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_51 = null;
            // 0x00BCC978: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCC97C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCC980: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC984: MOV x2, x21                | X2 = 1152921510060643760 (0x10000001451255B0);//ML01
            // 0x00BCC988: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC98C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_51 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCC990: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC994: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC998: STR x22, [x8, #0x88]       | ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783155336
            ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache11 = val_51;
            // 0x00BCC99C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMFont_Binding);
            // 0x00BCC9A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMFont_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCC9A4: LDR x21, [x8, #0x88]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_68 = ILRuntime.Runtime.Generated.BMFont_Binding.<>f__mg$cache11;
            label_119:
            // 0x00BCC9A8: CBNZ x19, #0xbcc9b0        | if (X1 != 0) goto label_120;            
            if(X1 != 0)
            {
                goto label_120;
            }
            // 0x00BCC9AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMFont_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_120:
            // 0x00BCC9B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCC9B4: MOV x1, x20                | X1 = val_50;//m1                        
            // 0x00BCC9B8: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCC9BC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCC9C0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCC9C4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCC9C8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCC9CC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BCC9D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCC9D4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BCC9D8: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_50, func:  val_68); return;
            X1.RegisterCLRMethodRedirection(mi:  val_50, func:  val_68);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCC9DC (12372444), len: 612  VirtAddr: 0x00BCC9DC RVA: 0x00BCC9DC token: 100663861 methodIndex: 29906 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isValid_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x00BCC9DC: STP x26, x25, [sp, #-0x50]! | stack[1152921510060928448] = ???;  stack[1152921510060928456] = ???;  //  dest_result_addr=1152921510060928448 |  dest_result_addr=1152921510060928456
            // 0x00BCC9E0: STP x24, x23, [sp, #0x10]  | stack[1152921510060928464] = ???;  stack[1152921510060928472] = ???;  //  dest_result_addr=1152921510060928464 |  dest_result_addr=1152921510060928472
            // 0x00BCC9E4: STP x22, x21, [sp, #0x20]  | stack[1152921510060928480] = ???;  stack[1152921510060928488] = ???;  //  dest_result_addr=1152921510060928480 |  dest_result_addr=1152921510060928488
            // 0x00BCC9E8: STP x20, x19, [sp, #0x30]  | stack[1152921510060928496] = ???;  stack[1152921510060928504] = ???;  //  dest_result_addr=1152921510060928496 |  dest_result_addr=1152921510060928504
            // 0x00BCC9EC: STP x29, x30, [sp, #0x40]  | stack[1152921510060928512] = ???;  stack[1152921510060928520] = ???;  //  dest_result_addr=1152921510060928512 |  dest_result_addr=1152921510060928520
            // 0x00BCC9F0: ADD x29, sp, #0x40         | X29 = (1152921510060928448 + 64) = 1152921510060928512 (0x100000014516AE00);
            // 0x00BCC9F4: SUB sp, sp, #0x10          | SP = (1152921510060928448 - 16) = 1152921510060928432 (0x100000014516ADB0);
            // 0x00BCC9F8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCC9FC: LDRB w8, [x19, #0xbbb]     | W8 = (bool)static_value_03733BBB;       
            // 0x00BCCA00: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCCA04: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCCA08: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCCA0C: TBNZ w8, #0, #0xbcca28     | if (static_value_03733BBB == true) goto label_0;
            // 0x00BCCA10: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00BCCA14: LDR x8, [x8, #0xec0]       | X8 = 0x2B8F70C;                         
            // 0x00BCCA18: LDR w0, [x8]               | W0 = 0x1487;                            
            // 0x00BCCA1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1487, ????);     
            // 0x00BCCA20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCCA24: STRB w8, [x19, #0xbbb]     | static_value_03733BBB = true;            //  dest_result_addr=57883579
            label_0:
            // 0x00BCCA28: CBNZ x20, #0xbcca30        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCCA2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1487, ????);     
            label_1:
            // 0x00BCCA30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCA34: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCCA38: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCCA3C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCCA40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCA44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCA48: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCCA4C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCCA50: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCA54: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCCA58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCA5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCA60: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCCA64: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCCA68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCA6C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCCA70: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCCA74: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCCA78: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCCA7C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCCA80: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCCA84: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCCA88: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCCA8C: TBZ w9, #0, #0xbccaa0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCCA90: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCA94: CBNZ w9, #0xbccaa0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCCA98: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCCA9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCCAA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCAA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCCAA8: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCCAAC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCCAB0: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCCAB4: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCCAB8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCCABC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCCAC0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCCAC4: TBZ w9, #0, #0xbccad8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCCAC8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCACC: CBNZ w9, #0xbccad8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCCAD0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCCAD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCCAD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCADC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCCAE0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCCAE4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCCAE8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCCAEC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCCAF0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCCAF4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCCAF8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCCAFC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCCB00: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCCB04: TBZ w9, #0, #0xbccb18      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCCB08: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCB0C: CBNZ w9, #0xbccb18         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCCB10: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCCB14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCCB18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCB1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCB20: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCCB24: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCCB28: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCCB2C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BCCB30: CBZ x0, #0xbccb94          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCCB34: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCCB38: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCCB3C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCCB40: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCCB44: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCCB48: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCCB4C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCCB50: B.LO #0xbccb6c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCCB54: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCCB58: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCCB5C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCCB60: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCCB64: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x00BCCB68: B.EQ #0xbccb94             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCCB6C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCCB70: ADD x8, sp, #8             | X8 = (1152921510060928432 + 8) = 1152921510060928440 (0x100000014516ADB8);
            // 0x00BCCB74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCCB78: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510060916528]
            // 0x00BCCB7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCCB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCB84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCCB88: ADD x0, sp, #8             | X0 = (1152921510060928432 + 8) = 1152921510060928440 (0x100000014516ADB8);
            // 0x00BCCB8C: BL #0x299a140              | 
            // 0x00BCCB90: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x00BCCB94: CBNZ x20, #0xbccb9c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCCB98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014516ADB8, ????);
            label_11:
            // 0x00BCCB9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCCBA0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCCBA4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCCBA8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCCBAC: CBNZ x22, #0xbccbb4        | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x00BCCBB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCCBB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCBB8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCBBC: BL #0xb9226c               | X0 = val_13.get_isValid();              
            bool val_9 = val_13.isValid;
            // 0x00BCCBC0: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x00BCCBC4: CBZ x19, #0xbccbd8         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCCBC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCCBCC: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BCCBD0: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x00BCCBD4: B #0xbccbec                |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x00BCCBD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00BCCBDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCCBE0: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BCCBE4: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x00BCCBE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x00BCCBEC: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x00BCCBF0: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCCBF4: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x00BCCBF8: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCCBFC: TBZ w9, #0, #0xbccc0c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00BCCC00: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCCC04: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCCC08: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x00BCCC0C: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x00BCCC10: SUB sp, x29, #0x40         | SP = (1152921510060928512 - 64) = 1152921510060928448 (0x100000014516ADC0);
            // 0x00BCCC14: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCCC18: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCCC1C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCCC20: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCCC24: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCCC28: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCCC2C: MOV x19, x0                | 
            // 0x00BCCC30: ADD x0, sp, #8             | 
            // 0x00BCCC34: BL #0x299a140              | 
            // 0x00BCCC38: MOV x0, x19                | 
            // 0x00BCCC3C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCCC40 (12373056), len: 584  VirtAddr: 0x00BCCC40 RVA: 0x00BCCC40 token: 100663862 methodIndex: 29907 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_charSize_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BCCC40: STP x26, x25, [sp, #-0x50]! | stack[1152921510061097792] = ???;  stack[1152921510061097800] = ???;  //  dest_result_addr=1152921510061097792 |  dest_result_addr=1152921510061097800
            // 0x00BCCC44: STP x24, x23, [sp, #0x10]  | stack[1152921510061097808] = ???;  stack[1152921510061097816] = ???;  //  dest_result_addr=1152921510061097808 |  dest_result_addr=1152921510061097816
            // 0x00BCCC48: STP x22, x21, [sp, #0x20]  | stack[1152921510061097824] = ???;  stack[1152921510061097832] = ???;  //  dest_result_addr=1152921510061097824 |  dest_result_addr=1152921510061097832
            // 0x00BCCC4C: STP x20, x19, [sp, #0x30]  | stack[1152921510061097840] = ???;  stack[1152921510061097848] = ???;  //  dest_result_addr=1152921510061097840 |  dest_result_addr=1152921510061097848
            // 0x00BCCC50: STP x29, x30, [sp, #0x40]  | stack[1152921510061097856] = ???;  stack[1152921510061097864] = ???;  //  dest_result_addr=1152921510061097856 |  dest_result_addr=1152921510061097864
            // 0x00BCCC54: ADD x29, sp, #0x40         | X29 = (1152921510061097792 + 64) = 1152921510061097856 (0x1000000145194380);
            // 0x00BCCC58: SUB sp, sp, #0x10          | SP = (1152921510061097792 - 16) = 1152921510061097776 (0x1000000145194330);
            // 0x00BCCC5C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCCC60: LDRB w8, [x19, #0xbbc]     | W8 = (bool)static_value_03733BBC;       
            // 0x00BCCC64: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCCC68: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCCC6C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCCC70: TBNZ w8, #0, #0xbccc8c     | if (static_value_03733BBC == true) goto label_0;
            // 0x00BCCC74: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x00BCCC78: LDR x8, [x8, #0x940]       | X8 = 0x2B8F700;                         
            // 0x00BCCC7C: LDR w0, [x8]               | W0 = 0x1484;                            
            // 0x00BCCC80: BL #0x2782188              | X0 = sub_2782188( ?? 0x1484, ????);     
            // 0x00BCCC84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCCC88: STRB w8, [x19, #0xbbc]     | static_value_03733BBC = true;            //  dest_result_addr=57883580
            label_0:
            // 0x00BCCC8C: CBNZ x20, #0xbccc94        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCCC90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1484, ????);     
            label_1:
            // 0x00BCCC94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCC98: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCCC9C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCCCA0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCCCA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCCA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCCAC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCCCB0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCCCB4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCCB8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCCCBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCCC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCCC4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCCCC8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCCCCC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCCD0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCCCD4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCCCD8: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCCCDC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCCCE0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCCCE4: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCCCE8: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCCCEC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCCCF0: TBZ w9, #0, #0xbccd04      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCCCF4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCCF8: CBNZ w9, #0xbccd04         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCCCFC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCCD00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCCD04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCD08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCCD0C: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCCD10: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCCD14: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCCD18: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCCD1C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCCD20: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCCD24: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCCD28: TBZ w9, #0, #0xbccd3c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCCD2C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCD30: CBNZ w9, #0xbccd3c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCCD34: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCCD38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCCD3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCD40: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCCD44: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCCD48: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCCD4C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCCD50: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCCD54: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCCD58: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCCD5C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCCD60: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCCD64: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCCD68: TBZ w9, #0, #0xbccd7c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCCD6C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCD70: CBNZ w9, #0xbccd7c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCCD74: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCCD78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCCD7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCD80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCD84: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCCD88: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCCD8C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCCD90: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCCD94: CBZ x0, #0xbccdf8          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCCD98: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCCD9C: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCCDA0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCCDA4: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCCDA8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCCDAC: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCCDB0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCCDB4: B.LO #0xbccdd0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCCDB8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCCDBC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCCDC0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCCDC4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCCDC8: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCCDCC: B.EQ #0xbccdf8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCCDD0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCCDD4: ADD x8, sp, #8             | X8 = (1152921510061097776 + 8) = 1152921510061097784 (0x1000000145194338);
            // 0x00BCCDD8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCCDDC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510061085872]
            // 0x00BCCDE0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCCDE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCDE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCCDEC: ADD x0, sp, #8             | X0 = (1152921510061097776 + 8) = 1152921510061097784 (0x1000000145194338);
            // 0x00BCCDF0: BL #0x299a140              | 
            // 0x00BCCDF4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCCDF8: CBNZ x20, #0xbcce00        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCCDFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145194338, ????);
            label_11:
            // 0x00BCCE00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCCE04: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCCE08: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCCE0C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCCE10: CBNZ x22, #0xbcce18        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCCE14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCCE18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCE1C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCE20: BL #0xb922d4               | X0 = val_11.get_charSize();             
            int val_9 = val_11.charSize;
            // 0x00BCCE24: CBZ x19, #0xbcce80         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCCE28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCCE2C: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BCCE30: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCCE34: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BCCE38: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCCE3C: TBZ w9, #0, #0xbcce4c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BCCE40: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCCE44: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCCE48: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BCCE4C: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BCCE50: SUB sp, x29, #0x40         | SP = (1152921510061097856 - 64) = 1152921510061097792 (0x1000000145194340);
            // 0x00BCCE54: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCCE58: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCCE5C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCCE60: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCCE64: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCCE68: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCCE6C: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BCCE70: ADD x0, sp, #8             | X0 = (1152921510061097872 + 8) = 1152921510061097880 (0x1000000145194398);
            // 0x00BCCE74: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000145194398); //ERROR_TYPE
            // 0x00BCCE78: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BCCE7C: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BCCE80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BCCE84: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCCE88 (12373640), len: 576  VirtAddr: 0x00BCCE88 RVA: 0x00BCCE88 token: 100663863 methodIndex: 29908 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_charSize_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00BCCE88: STP x26, x25, [sp, #-0x50]! | stack[1152921510061267136] = ???;  stack[1152921510061267144] = ???;  //  dest_result_addr=1152921510061267136 |  dest_result_addr=1152921510061267144
            // 0x00BCCE8C: STP x24, x23, [sp, #0x10]  | stack[1152921510061267152] = ???;  stack[1152921510061267160] = ???;  //  dest_result_addr=1152921510061267152 |  dest_result_addr=1152921510061267160
            // 0x00BCCE90: STP x22, x21, [sp, #0x20]  | stack[1152921510061267168] = ???;  stack[1152921510061267176] = ???;  //  dest_result_addr=1152921510061267168 |  dest_result_addr=1152921510061267176
            // 0x00BCCE94: STP x20, x19, [sp, #0x30]  | stack[1152921510061267184] = ???;  stack[1152921510061267192] = ???;  //  dest_result_addr=1152921510061267184 |  dest_result_addr=1152921510061267192
            // 0x00BCCE98: STP x29, x30, [sp, #0x40]  | stack[1152921510061267200] = ???;  stack[1152921510061267208] = ???;  //  dest_result_addr=1152921510061267200 |  dest_result_addr=1152921510061267208
            // 0x00BCCE9C: ADD x29, sp, #0x40         | X29 = (1152921510061267136 + 64) = 1152921510061267200 (0x10000001451BD900);
            // 0x00BCCEA0: SUB sp, sp, #0x10          | SP = (1152921510061267136 - 16) = 1152921510061267120 (0x10000001451BD8B0);
            // 0x00BCCEA4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCCEA8: LDRB w8, [x20, #0xbbd]     | W8 = (bool)static_value_03733BBD;       
            // 0x00BCCEAC: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BCCEB0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCCEB4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCCEB8: TBNZ w8, #0, #0xbcced4     | if (static_value_03733BBD == true) goto label_0;
            // 0x00BCCEBC: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x00BCCEC0: LDR x8, [x8, #0x1d0]       | X8 = 0x2B8F72C;                         
            // 0x00BCCEC4: LDR w0, [x8]               | W0 = 0x148F;                            
            // 0x00BCCEC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x148F, ????);     
            // 0x00BCCECC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCCED0: STRB w8, [x20, #0xbbd]     | static_value_03733BBD = true;            //  dest_result_addr=57883581
            label_0:
            // 0x00BCCED4: CBNZ x19, #0xbccedc        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCCED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x148F, ????);     
            label_1:
            // 0x00BCCEDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCCEE0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCCEE4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCCEE8: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCCEEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCEF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCEF4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCCEF8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCCEFC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCF00: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCCF04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCF08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCF0C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCCF10: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCCF14: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCF18: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCCF1C: CBNZ x21, #0xbccf24        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCCF20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCCF24: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BCCF28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCF2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCF30: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCCF34: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCCF38: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCCF3C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCCF40: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCCF44: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCCF48: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCCF4C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCCF50: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCCF54: LDR x25, [x9]              | X25 = typeof(BMFont);                   
            // 0x00BCCF58: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCCF5C: TBZ w9, #0, #0xbccf70      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BCCF60: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCF64: CBNZ w9, #0xbccf70         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BCCF68: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCCF6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BCCF70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCF74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCCF78: MOV x1, x25                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCCF7C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCCF80: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCCF84: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCCF88: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BCCF8C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCCF90: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCCF94: TBZ w9, #0, #0xbccfa8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BCCF98: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCF9C: CBNZ w9, #0xbccfa8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BCCFA0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCCFA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BCCFA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCFAC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCCFB0: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCCFB4: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCCFB8: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BCCFBC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCCFC0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCCFC4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCCFC8: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BCCFCC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCCFD0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCCFD4: TBZ w9, #0, #0xbccfe8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BCCFD8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCCFDC: CBNZ w9, #0xbccfe8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BCCFE0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCCFE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BCCFE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCCFEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCCFF0: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BCCFF4: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BCCFF8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BCCFFC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BCD000: CBZ x0, #0xbcd064          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BCD004: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCD008: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCD00C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCD010: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCD014: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD018: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD01C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCD020: B.LO #0xbcd03c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BCD024: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCD028: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCD02C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCD030: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCD034: MOV x23, x0                | X23 = val_7;//m1                        
            val_10 = val_7;
            // 0x00BCD038: B.EQ #0xbcd064             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BCD03C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCD040: ADD x8, sp, #8             | X8 = (1152921510061267120 + 8) = 1152921510061267128 (0x10000001451BD8B8);
            // 0x00BCD044: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCD048: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510061255216]
            // 0x00BCD04C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BCD050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BCD058: ADD x0, sp, #8             | X0 = (1152921510061267120 + 8) = 1152921510061267128 (0x10000001451BD8B8);
            // 0x00BCD05C: BL #0x299a140              | 
            // 0x00BCD060: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x00BCD064: CBNZ x19, #0xbcd06c        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BCD068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001451BD8B8, ????);
            label_12:
            // 0x00BCD06C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD070: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCD074: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCD078: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCD07C: CBNZ x23, #0xbcd084        | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x00BCD080: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BCD084: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD088: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD08C: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x00BCD090: BL #0xb922dc               | val_10.set_charSize(value:  val_3 + 4); 
            val_10.charSize = val_3 + 4;
            // 0x00BCD094: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCD098: SUB sp, x29, #0x40         | SP = (1152921510061267200 - 64) = 1152921510061267136 (0x10000001451BD8C0);
            // 0x00BCD09C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCD0A0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCD0A4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCD0A8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCD0AC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCD0B0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCD0B4: MOV x19, x0                | 
            // 0x00BCD0B8: ADD x0, sp, #8             | 
            // 0x00BCD0BC: BL #0x299a140              | 
            // 0x00BCD0C0: MOV x0, x19                | 
            // 0x00BCD0C4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCD0C8 (12374216), len: 584  VirtAddr: 0x00BCD0C8 RVA: 0x00BCD0C8 token: 100663864 methodIndex: 29909 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_baseOffset_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BCD0C8: STP x26, x25, [sp, #-0x50]! | stack[1152921510061436480] = ???;  stack[1152921510061436488] = ???;  //  dest_result_addr=1152921510061436480 |  dest_result_addr=1152921510061436488
            // 0x00BCD0CC: STP x24, x23, [sp, #0x10]  | stack[1152921510061436496] = ???;  stack[1152921510061436504] = ???;  //  dest_result_addr=1152921510061436496 |  dest_result_addr=1152921510061436504
            // 0x00BCD0D0: STP x22, x21, [sp, #0x20]  | stack[1152921510061436512] = ???;  stack[1152921510061436520] = ???;  //  dest_result_addr=1152921510061436512 |  dest_result_addr=1152921510061436520
            // 0x00BCD0D4: STP x20, x19, [sp, #0x30]  | stack[1152921510061436528] = ???;  stack[1152921510061436536] = ???;  //  dest_result_addr=1152921510061436528 |  dest_result_addr=1152921510061436536
            // 0x00BCD0D8: STP x29, x30, [sp, #0x40]  | stack[1152921510061436544] = ???;  stack[1152921510061436552] = ???;  //  dest_result_addr=1152921510061436544 |  dest_result_addr=1152921510061436552
            // 0x00BCD0DC: ADD x29, sp, #0x40         | X29 = (1152921510061436480 + 64) = 1152921510061436544 (0x10000001451E6E80);
            // 0x00BCD0E0: SUB sp, sp, #0x10          | SP = (1152921510061436480 - 16) = 1152921510061436464 (0x10000001451E6E30);
            // 0x00BCD0E4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCD0E8: LDRB w8, [x19, #0xbbe]     | W8 = (bool)static_value_03733BBE;       
            // 0x00BCD0EC: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCD0F0: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCD0F4: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCD0F8: TBNZ w8, #0, #0xbcd114     | if (static_value_03733BBE == true) goto label_0;
            // 0x00BCD0FC: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00BCD100: LDR x8, [x8, #0x2b8]       | X8 = 0x2B8F6FC;                         
            // 0x00BCD104: LDR w0, [x8]               | W0 = 0x1483;                            
            // 0x00BCD108: BL #0x2782188              | X0 = sub_2782188( ?? 0x1483, ????);     
            // 0x00BCD10C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCD110: STRB w8, [x19, #0xbbe]     | static_value_03733BBE = true;            //  dest_result_addr=57883582
            label_0:
            // 0x00BCD114: CBNZ x20, #0xbcd11c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCD118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1483, ????);     
            label_1:
            // 0x00BCD11C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD120: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCD124: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCD128: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCD12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD130: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD134: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCD138: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCD13C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD140: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCD144: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD148: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD14C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCD150: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCD154: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD158: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCD15C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCD160: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCD164: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCD168: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCD16C: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCD170: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCD174: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCD178: TBZ w9, #0, #0xbcd18c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCD17C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD180: CBNZ w9, #0xbcd18c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCD184: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCD188: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCD18C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD190: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD194: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCD198: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCD19C: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCD1A0: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCD1A4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCD1A8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCD1AC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCD1B0: TBZ w9, #0, #0xbcd1c4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCD1B4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD1B8: CBNZ w9, #0xbcd1c4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCD1BC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCD1C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCD1C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD1C8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCD1CC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCD1D0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCD1D4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCD1D8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCD1DC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCD1E0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCD1E4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCD1E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCD1EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCD1F0: TBZ w9, #0, #0xbcd204      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCD1F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD1F8: CBNZ w9, #0xbcd204         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCD1FC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCD200: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCD204: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD208: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD20C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCD210: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCD214: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCD218: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCD21C: CBZ x0, #0xbcd280          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCD220: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCD224: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCD228: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCD22C: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCD230: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD234: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD238: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCD23C: B.LO #0xbcd258             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCD240: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCD244: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCD248: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCD24C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCD250: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCD254: B.EQ #0xbcd280             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCD258: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCD25C: ADD x8, sp, #8             | X8 = (1152921510061436464 + 8) = 1152921510061436472 (0x10000001451E6E38);
            // 0x00BCD260: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCD264: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510061424560]
            // 0x00BCD268: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCD26C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD270: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCD274: ADD x0, sp, #8             | X0 = (1152921510061436464 + 8) = 1152921510061436472 (0x10000001451E6E38);
            // 0x00BCD278: BL #0x299a140              | 
            // 0x00BCD27C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCD280: CBNZ x20, #0xbcd288        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCD284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001451E6E38, ????);
            label_11:
            // 0x00BCD288: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD28C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCD290: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCD294: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCD298: CBNZ x22, #0xbcd2a0        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCD29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCD2A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD2A4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD2A8: BL #0xb922e4               | X0 = val_11.get_baseOffset();           
            int val_9 = val_11.baseOffset;
            // 0x00BCD2AC: CBZ x19, #0xbcd308         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCD2B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCD2B4: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BCD2B8: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCD2BC: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BCD2C0: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCD2C4: TBZ w9, #0, #0xbcd2d4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BCD2C8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCD2CC: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCD2D0: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BCD2D4: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BCD2D8: SUB sp, x29, #0x40         | SP = (1152921510061436544 - 64) = 1152921510061436480 (0x10000001451E6E40);
            // 0x00BCD2DC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCD2E0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCD2E4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCD2E8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCD2EC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCD2F0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCD2F4: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BCD2F8: ADD x0, sp, #8             | X0 = (1152921510061436560 + 8) = 1152921510061436568 (0x10000001451E6E98);
            // 0x00BCD2FC: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001451E6E98); //ERROR_TYPE
            // 0x00BCD300: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BCD304: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BCD308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BCD30C: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCD310 (12374800), len: 576  VirtAddr: 0x00BCD310 RVA: 0x00BCD310 token: 100663865 methodIndex: 29910 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_baseOffset_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00BCD310: STP x26, x25, [sp, #-0x50]! | stack[1152921510061605824] = ???;  stack[1152921510061605832] = ???;  //  dest_result_addr=1152921510061605824 |  dest_result_addr=1152921510061605832
            // 0x00BCD314: STP x24, x23, [sp, #0x10]  | stack[1152921510061605840] = ???;  stack[1152921510061605848] = ???;  //  dest_result_addr=1152921510061605840 |  dest_result_addr=1152921510061605848
            // 0x00BCD318: STP x22, x21, [sp, #0x20]  | stack[1152921510061605856] = ???;  stack[1152921510061605864] = ???;  //  dest_result_addr=1152921510061605856 |  dest_result_addr=1152921510061605864
            // 0x00BCD31C: STP x20, x19, [sp, #0x30]  | stack[1152921510061605872] = ???;  stack[1152921510061605880] = ???;  //  dest_result_addr=1152921510061605872 |  dest_result_addr=1152921510061605880
            // 0x00BCD320: STP x29, x30, [sp, #0x40]  | stack[1152921510061605888] = ???;  stack[1152921510061605896] = ???;  //  dest_result_addr=1152921510061605888 |  dest_result_addr=1152921510061605896
            // 0x00BCD324: ADD x29, sp, #0x40         | X29 = (1152921510061605824 + 64) = 1152921510061605888 (0x1000000145210400);
            // 0x00BCD328: SUB sp, sp, #0x10          | SP = (1152921510061605824 - 16) = 1152921510061605808 (0x10000001452103B0);
            // 0x00BCD32C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCD330: LDRB w8, [x20, #0xbbf]     | W8 = (bool)static_value_03733BBF;       
            // 0x00BCD334: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BCD338: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCD33C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCD340: TBNZ w8, #0, #0xbcd35c     | if (static_value_03733BBF == true) goto label_0;
            // 0x00BCD344: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00BCD348: LDR x8, [x8, #0xe10]       | X8 = 0x2B8F728;                         
            // 0x00BCD34C: LDR w0, [x8]               | W0 = 0x148E;                            
            // 0x00BCD350: BL #0x2782188              | X0 = sub_2782188( ?? 0x148E, ????);     
            // 0x00BCD354: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCD358: STRB w8, [x20, #0xbbf]     | static_value_03733BBF = true;            //  dest_result_addr=57883583
            label_0:
            // 0x00BCD35C: CBNZ x19, #0xbcd364        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCD360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x148E, ????);     
            label_1:
            // 0x00BCD364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD368: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCD36C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCD370: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCD374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD378: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD37C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCD380: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCD384: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD388: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCD38C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD390: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD394: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCD398: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCD39C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD3A0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCD3A4: CBNZ x21, #0xbcd3ac        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCD3A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCD3AC: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BCD3B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD3B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD3B8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCD3BC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCD3C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD3C4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCD3C8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCD3CC: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCD3D0: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCD3D4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCD3D8: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCD3DC: LDR x25, [x9]              | X25 = typeof(BMFont);                   
            // 0x00BCD3E0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCD3E4: TBZ w9, #0, #0xbcd3f8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BCD3E8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD3EC: CBNZ w9, #0xbcd3f8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BCD3F0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCD3F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BCD3F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD3FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD400: MOV x1, x25                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCD404: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCD408: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCD40C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCD410: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BCD414: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCD418: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCD41C: TBZ w9, #0, #0xbcd430      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BCD420: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD424: CBNZ w9, #0xbcd430         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BCD428: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCD42C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BCD430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD434: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCD438: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCD43C: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCD440: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BCD444: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCD448: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCD44C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCD450: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BCD454: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCD458: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCD45C: TBZ w9, #0, #0xbcd470      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BCD460: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD464: CBNZ w9, #0xbcd470         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BCD468: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCD46C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BCD470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD474: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD478: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BCD47C: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BCD480: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BCD484: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BCD488: CBZ x0, #0xbcd4ec          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BCD48C: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCD490: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCD494: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCD498: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCD49C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD4A0: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD4A4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCD4A8: B.LO #0xbcd4c4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BCD4AC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCD4B0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCD4B4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCD4B8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCD4BC: MOV x23, x0                | X23 = val_7;//m1                        
            val_10 = val_7;
            // 0x00BCD4C0: B.EQ #0xbcd4ec             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BCD4C4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCD4C8: ADD x8, sp, #8             | X8 = (1152921510061605808 + 8) = 1152921510061605816 (0x10000001452103B8);
            // 0x00BCD4CC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCD4D0: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510061593904]
            // 0x00BCD4D4: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BCD4D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD4DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BCD4E0: ADD x0, sp, #8             | X0 = (1152921510061605808 + 8) = 1152921510061605816 (0x10000001452103B8);
            // 0x00BCD4E4: BL #0x299a140              | 
            // 0x00BCD4E8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x00BCD4EC: CBNZ x19, #0xbcd4f4        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BCD4F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001452103B8, ????);
            label_12:
            // 0x00BCD4F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD4F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCD4FC: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCD500: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCD504: CBNZ x23, #0xbcd50c        | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x00BCD508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BCD50C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD510: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD514: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x00BCD518: BL #0xb922ec               | val_10.set_baseOffset(value:  val_3 + 4);
            val_10.baseOffset = val_3 + 4;
            // 0x00BCD51C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCD520: SUB sp, x29, #0x40         | SP = (1152921510061605888 - 64) = 1152921510061605824 (0x10000001452103C0);
            // 0x00BCD524: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCD528: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCD52C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCD530: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCD534: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCD538: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCD53C: MOV x19, x0                | 
            // 0x00BCD540: ADD x0, sp, #8             | 
            // 0x00BCD544: BL #0x299a140              | 
            // 0x00BCD548: MOV x0, x19                | 
            // 0x00BCD54C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCD550 (12375376), len: 584  VirtAddr: 0x00BCD550 RVA: 0x00BCD550 token: 100663866 methodIndex: 29911 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_texWidth_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BCD550: STP x26, x25, [sp, #-0x50]! | stack[1152921510061775168] = ???;  stack[1152921510061775176] = ???;  //  dest_result_addr=1152921510061775168 |  dest_result_addr=1152921510061775176
            // 0x00BCD554: STP x24, x23, [sp, #0x10]  | stack[1152921510061775184] = ???;  stack[1152921510061775192] = ???;  //  dest_result_addr=1152921510061775184 |  dest_result_addr=1152921510061775192
            // 0x00BCD558: STP x22, x21, [sp, #0x20]  | stack[1152921510061775200] = ???;  stack[1152921510061775208] = ???;  //  dest_result_addr=1152921510061775200 |  dest_result_addr=1152921510061775208
            // 0x00BCD55C: STP x20, x19, [sp, #0x30]  | stack[1152921510061775216] = ???;  stack[1152921510061775224] = ???;  //  dest_result_addr=1152921510061775216 |  dest_result_addr=1152921510061775224
            // 0x00BCD560: STP x29, x30, [sp, #0x40]  | stack[1152921510061775232] = ???;  stack[1152921510061775240] = ???;  //  dest_result_addr=1152921510061775232 |  dest_result_addr=1152921510061775240
            // 0x00BCD564: ADD x29, sp, #0x40         | X29 = (1152921510061775168 + 64) = 1152921510061775232 (0x1000000145239980);
            // 0x00BCD568: SUB sp, sp, #0x10          | SP = (1152921510061775168 - 16) = 1152921510061775152 (0x1000000145239930);
            // 0x00BCD56C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCD570: LDRB w8, [x19, #0xbc0]     | W8 = (bool)static_value_03733BC0;       
            // 0x00BCD574: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCD578: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCD57C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCD580: TBNZ w8, #0, #0xbcd59c     | if (static_value_03733BC0 == true) goto label_0;
            // 0x00BCD584: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00BCD588: LDR x8, [x8, #0xc58]       | X8 = 0x2B8F718;                         
            // 0x00BCD58C: LDR w0, [x8]               | W0 = 0x148A;                            
            // 0x00BCD590: BL #0x2782188              | X0 = sub_2782188( ?? 0x148A, ????);     
            // 0x00BCD594: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCD598: STRB w8, [x19, #0xbc0]     | static_value_03733BC0 = true;            //  dest_result_addr=57883584
            label_0:
            // 0x00BCD59C: CBNZ x20, #0xbcd5a4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCD5A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x148A, ????);     
            label_1:
            // 0x00BCD5A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD5A8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCD5AC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCD5B0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCD5B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD5B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD5BC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCD5C0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCD5C4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD5C8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCD5CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD5D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD5D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCD5D8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCD5DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD5E0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCD5E4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCD5E8: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCD5EC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCD5F0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCD5F4: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCD5F8: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCD5FC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCD600: TBZ w9, #0, #0xbcd614      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCD604: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD608: CBNZ w9, #0xbcd614         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCD60C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCD610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCD614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD61C: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCD620: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCD624: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCD628: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCD62C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCD630: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCD634: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCD638: TBZ w9, #0, #0xbcd64c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCD63C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD640: CBNZ w9, #0xbcd64c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCD644: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCD648: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCD64C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD650: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCD654: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCD658: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCD65C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCD660: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCD664: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCD668: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCD66C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCD670: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCD674: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCD678: TBZ w9, #0, #0xbcd68c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCD67C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD680: CBNZ w9, #0xbcd68c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCD684: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCD688: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCD68C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD690: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD694: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCD698: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCD69C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCD6A0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCD6A4: CBZ x0, #0xbcd708          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCD6A8: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCD6AC: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCD6B0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCD6B4: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCD6B8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD6BC: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD6C0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCD6C4: B.LO #0xbcd6e0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCD6C8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCD6CC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCD6D0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCD6D4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCD6D8: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCD6DC: B.EQ #0xbcd708             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCD6E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCD6E4: ADD x8, sp, #8             | X8 = (1152921510061775152 + 8) = 1152921510061775160 (0x1000000145239938);
            // 0x00BCD6E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCD6EC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510061763248]
            // 0x00BCD6F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCD6F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD6F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCD6FC: ADD x0, sp, #8             | X0 = (1152921510061775152 + 8) = 1152921510061775160 (0x1000000145239938);
            // 0x00BCD700: BL #0x299a140              | 
            // 0x00BCD704: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCD708: CBNZ x20, #0xbcd710        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCD70C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145239938, ????);
            label_11:
            // 0x00BCD710: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD714: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCD718: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCD71C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCD720: CBNZ x22, #0xbcd728        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCD724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCD728: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD72C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD730: BL #0xb922f4               | X0 = val_11.get_texWidth();             
            int val_9 = val_11.texWidth;
            // 0x00BCD734: CBZ x19, #0xbcd790         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCD738: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCD73C: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BCD740: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCD744: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BCD748: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCD74C: TBZ w9, #0, #0xbcd75c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BCD750: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCD754: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCD758: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BCD75C: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BCD760: SUB sp, x29, #0x40         | SP = (1152921510061775232 - 64) = 1152921510061775168 (0x1000000145239940);
            // 0x00BCD764: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCD768: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCD76C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCD770: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCD774: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCD778: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCD77C: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BCD780: ADD x0, sp, #8             | X0 = (1152921510061775248 + 8) = 1152921510061775256 (0x1000000145239998);
            // 0x00BCD784: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000145239998); //ERROR_TYPE
            // 0x00BCD788: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BCD78C: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BCD790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BCD794: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCD798 (12375960), len: 576  VirtAddr: 0x00BCD798 RVA: 0x00BCD798 token: 100663867 methodIndex: 29912 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_texWidth_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00BCD798: STP x26, x25, [sp, #-0x50]! | stack[1152921510061944512] = ???;  stack[1152921510061944520] = ???;  //  dest_result_addr=1152921510061944512 |  dest_result_addr=1152921510061944520
            // 0x00BCD79C: STP x24, x23, [sp, #0x10]  | stack[1152921510061944528] = ???;  stack[1152921510061944536] = ???;  //  dest_result_addr=1152921510061944528 |  dest_result_addr=1152921510061944536
            // 0x00BCD7A0: STP x22, x21, [sp, #0x20]  | stack[1152921510061944544] = ???;  stack[1152921510061944552] = ???;  //  dest_result_addr=1152921510061944544 |  dest_result_addr=1152921510061944552
            // 0x00BCD7A4: STP x20, x19, [sp, #0x30]  | stack[1152921510061944560] = ???;  stack[1152921510061944568] = ???;  //  dest_result_addr=1152921510061944560 |  dest_result_addr=1152921510061944568
            // 0x00BCD7A8: STP x29, x30, [sp, #0x40]  | stack[1152921510061944576] = ???;  stack[1152921510061944584] = ???;  //  dest_result_addr=1152921510061944576 |  dest_result_addr=1152921510061944584
            // 0x00BCD7AC: ADD x29, sp, #0x40         | X29 = (1152921510061944512 + 64) = 1152921510061944576 (0x1000000145262F00);
            // 0x00BCD7B0: SUB sp, sp, #0x10          | SP = (1152921510061944512 - 16) = 1152921510061944496 (0x1000000145262EB0);
            // 0x00BCD7B4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCD7B8: LDRB w8, [x20, #0xbc1]     | W8 = (bool)static_value_03733BC1;       
            // 0x00BCD7BC: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BCD7C0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCD7C4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCD7C8: TBNZ w8, #0, #0xbcd7e4     | if (static_value_03733BC1 == true) goto label_0;
            // 0x00BCD7CC: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00BCD7D0: LDR x8, [x8, #0xb28]       | X8 = 0x2B8F738;                         
            // 0x00BCD7D4: LDR w0, [x8]               | W0 = 0x1492;                            
            // 0x00BCD7D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1492, ????);     
            // 0x00BCD7DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCD7E0: STRB w8, [x20, #0xbc1]     | static_value_03733BC1 = true;            //  dest_result_addr=57883585
            label_0:
            // 0x00BCD7E4: CBNZ x19, #0xbcd7ec        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCD7E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1492, ????);     
            label_1:
            // 0x00BCD7EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD7F0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCD7F4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCD7F8: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCD7FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD800: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD804: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCD808: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCD80C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD810: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCD814: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD818: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD81C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCD820: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCD824: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD828: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCD82C: CBNZ x21, #0xbcd834        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCD830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCD834: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BCD838: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD83C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD840: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCD844: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCD848: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCD84C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCD850: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCD854: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCD858: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCD85C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCD860: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCD864: LDR x25, [x9]              | X25 = typeof(BMFont);                   
            // 0x00BCD868: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCD86C: TBZ w9, #0, #0xbcd880      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BCD870: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD874: CBNZ w9, #0xbcd880         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BCD878: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCD87C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BCD880: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD884: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD888: MOV x1, x25                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCD88C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCD890: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCD894: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCD898: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BCD89C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCD8A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCD8A4: TBZ w9, #0, #0xbcd8b8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BCD8A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD8AC: CBNZ w9, #0xbcd8b8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BCD8B0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCD8B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BCD8B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD8BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCD8C0: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCD8C4: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCD8C8: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BCD8CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCD8D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCD8D4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCD8D8: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BCD8DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCD8E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCD8E4: TBZ w9, #0, #0xbcd8f8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BCD8E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCD8EC: CBNZ w9, #0xbcd8f8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BCD8F0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCD8F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BCD8F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD8FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCD900: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BCD904: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BCD908: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BCD90C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BCD910: CBZ x0, #0xbcd974          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BCD914: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCD918: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCD91C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCD920: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCD924: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD928: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCD92C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCD930: B.LO #0xbcd94c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BCD934: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCD938: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCD93C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCD940: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCD944: MOV x23, x0                | X23 = val_7;//m1                        
            val_10 = val_7;
            // 0x00BCD948: B.EQ #0xbcd974             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BCD94C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCD950: ADD x8, sp, #8             | X8 = (1152921510061944496 + 8) = 1152921510061944504 (0x1000000145262EB8);
            // 0x00BCD954: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCD958: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510061932592]
            // 0x00BCD95C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BCD960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCD964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BCD968: ADD x0, sp, #8             | X0 = (1152921510061944496 + 8) = 1152921510061944504 (0x1000000145262EB8);
            // 0x00BCD96C: BL #0x299a140              | 
            // 0x00BCD970: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x00BCD974: CBNZ x19, #0xbcd97c        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BCD978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145262EB8, ????);
            label_12:
            // 0x00BCD97C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD980: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCD984: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCD988: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCD98C: CBNZ x23, #0xbcd994        | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x00BCD990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BCD994: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCD998: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCD99C: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x00BCD9A0: BL #0xb922fc               | val_10.set_texWidth(value:  val_3 + 4); 
            val_10.texWidth = val_3 + 4;
            // 0x00BCD9A4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCD9A8: SUB sp, x29, #0x40         | SP = (1152921510061944576 - 64) = 1152921510061944512 (0x1000000145262EC0);
            // 0x00BCD9AC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCD9B0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCD9B4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCD9B8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCD9BC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCD9C0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCD9C4: MOV x19, x0                | 
            // 0x00BCD9C8: ADD x0, sp, #8             | 
            // 0x00BCD9CC: BL #0x299a140              | 
            // 0x00BCD9D0: MOV x0, x19                | 
            // 0x00BCD9D4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCD9D8 (12376536), len: 584  VirtAddr: 0x00BCD9D8 RVA: 0x00BCD9D8 token: 100663868 methodIndex: 29913 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_texHeight_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BCD9D8: STP x26, x25, [sp, #-0x50]! | stack[1152921510062113856] = ???;  stack[1152921510062113864] = ???;  //  dest_result_addr=1152921510062113856 |  dest_result_addr=1152921510062113864
            // 0x00BCD9DC: STP x24, x23, [sp, #0x10]  | stack[1152921510062113872] = ???;  stack[1152921510062113880] = ???;  //  dest_result_addr=1152921510062113872 |  dest_result_addr=1152921510062113880
            // 0x00BCD9E0: STP x22, x21, [sp, #0x20]  | stack[1152921510062113888] = ???;  stack[1152921510062113896] = ???;  //  dest_result_addr=1152921510062113888 |  dest_result_addr=1152921510062113896
            // 0x00BCD9E4: STP x20, x19, [sp, #0x30]  | stack[1152921510062113904] = ???;  stack[1152921510062113912] = ???;  //  dest_result_addr=1152921510062113904 |  dest_result_addr=1152921510062113912
            // 0x00BCD9E8: STP x29, x30, [sp, #0x40]  | stack[1152921510062113920] = ???;  stack[1152921510062113928] = ???;  //  dest_result_addr=1152921510062113920 |  dest_result_addr=1152921510062113928
            // 0x00BCD9EC: ADD x29, sp, #0x40         | X29 = (1152921510062113856 + 64) = 1152921510062113920 (0x100000014528C480);
            // 0x00BCD9F0: SUB sp, sp, #0x10          | SP = (1152921510062113856 - 16) = 1152921510062113840 (0x100000014528C430);
            // 0x00BCD9F4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCD9F8: LDRB w8, [x19, #0xbc2]     | W8 = (bool)static_value_03733BC2;       
            // 0x00BCD9FC: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCDA00: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCDA04: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCDA08: TBNZ w8, #0, #0xbcda24     | if (static_value_03733BC2 == true) goto label_0;
            // 0x00BCDA0C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00BCDA10: LDR x8, [x8, #0x978]       | X8 = 0x2B8F714;                         
            // 0x00BCDA14: LDR w0, [x8]               | W0 = 0x1489;                            
            // 0x00BCDA18: BL #0x2782188              | X0 = sub_2782188( ?? 0x1489, ????);     
            // 0x00BCDA1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCDA20: STRB w8, [x19, #0xbc2]     | static_value_03733BC2 = true;            //  dest_result_addr=57883586
            label_0:
            // 0x00BCDA24: CBNZ x20, #0xbcda2c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCDA28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1489, ????);     
            label_1:
            // 0x00BCDA2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCDA30: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCDA34: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCDA38: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCDA3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDA40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDA44: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCDA48: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCDA4C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDA50: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCDA54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDA58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDA5C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCDA60: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCDA64: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDA68: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCDA6C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCDA70: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCDA74: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCDA78: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCDA7C: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCDA80: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCDA84: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCDA88: TBZ w9, #0, #0xbcda9c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCDA8C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDA90: CBNZ w9, #0xbcda9c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCDA94: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCDA98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCDA9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDAA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCDAA4: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCDAA8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCDAAC: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCDAB0: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCDAB4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCDAB8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCDABC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCDAC0: TBZ w9, #0, #0xbcdad4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCDAC4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDAC8: CBNZ w9, #0xbcdad4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCDACC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCDAD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCDAD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDAD8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCDADC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCDAE0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCDAE4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCDAE8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCDAEC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCDAF0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCDAF4: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCDAF8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCDAFC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCDB00: TBZ w9, #0, #0xbcdb14      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCDB04: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDB08: CBNZ w9, #0xbcdb14         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCDB0C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCDB10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCDB14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDB18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDB1C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCDB20: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCDB24: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCDB28: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCDB2C: CBZ x0, #0xbcdb90          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCDB30: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCDB34: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCDB38: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCDB3C: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCDB40: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCDB44: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCDB48: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCDB4C: B.LO #0xbcdb68             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCDB50: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCDB54: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCDB58: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCDB5C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCDB60: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCDB64: B.EQ #0xbcdb90             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCDB68: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCDB6C: ADD x8, sp, #8             | X8 = (1152921510062113840 + 8) = 1152921510062113848 (0x100000014528C438);
            // 0x00BCDB70: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCDB74: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510062101936]
            // 0x00BCDB78: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCDB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCDB80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCDB84: ADD x0, sp, #8             | X0 = (1152921510062113840 + 8) = 1152921510062113848 (0x100000014528C438);
            // 0x00BCDB88: BL #0x299a140              | 
            // 0x00BCDB8C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCDB90: CBNZ x20, #0xbcdb98        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCDB94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014528C438, ????);
            label_11:
            // 0x00BCDB98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCDB9C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCDBA0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCDBA4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCDBA8: CBNZ x22, #0xbcdbb0        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCDBAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCDBB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCDBB4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDBB8: BL #0xb92304               | X0 = val_11.get_texHeight();            
            int val_9 = val_11.texHeight;
            // 0x00BCDBBC: CBZ x19, #0xbcdc18         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCDBC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCDBC4: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BCDBC8: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCDBCC: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BCDBD0: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCDBD4: TBZ w9, #0, #0xbcdbe4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BCDBD8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCDBDC: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCDBE0: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BCDBE4: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BCDBE8: SUB sp, x29, #0x40         | SP = (1152921510062113920 - 64) = 1152921510062113856 (0x100000014528C440);
            // 0x00BCDBEC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCDBF0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCDBF4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCDBF8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCDBFC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCDC00: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCDC04: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BCDC08: ADD x0, sp, #8             | X0 = (1152921510062113936 + 8) = 1152921510062113944 (0x100000014528C498);
            // 0x00BCDC0C: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x100000014528C498); //ERROR_TYPE
            // 0x00BCDC10: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BCDC14: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BCDC18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BCDC1C: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCDC20 (12377120), len: 576  VirtAddr: 0x00BCDC20 RVA: 0x00BCDC20 token: 100663869 methodIndex: 29914 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_texHeight_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00BCDC20: STP x26, x25, [sp, #-0x50]! | stack[1152921510062283200] = ???;  stack[1152921510062283208] = ???;  //  dest_result_addr=1152921510062283200 |  dest_result_addr=1152921510062283208
            // 0x00BCDC24: STP x24, x23, [sp, #0x10]  | stack[1152921510062283216] = ???;  stack[1152921510062283224] = ???;  //  dest_result_addr=1152921510062283216 |  dest_result_addr=1152921510062283224
            // 0x00BCDC28: STP x22, x21, [sp, #0x20]  | stack[1152921510062283232] = ???;  stack[1152921510062283240] = ???;  //  dest_result_addr=1152921510062283232 |  dest_result_addr=1152921510062283240
            // 0x00BCDC2C: STP x20, x19, [sp, #0x30]  | stack[1152921510062283248] = ???;  stack[1152921510062283256] = ???;  //  dest_result_addr=1152921510062283248 |  dest_result_addr=1152921510062283256
            // 0x00BCDC30: STP x29, x30, [sp, #0x40]  | stack[1152921510062283264] = ???;  stack[1152921510062283272] = ???;  //  dest_result_addr=1152921510062283264 |  dest_result_addr=1152921510062283272
            // 0x00BCDC34: ADD x29, sp, #0x40         | X29 = (1152921510062283200 + 64) = 1152921510062283264 (0x10000001452B5A00);
            // 0x00BCDC38: SUB sp, sp, #0x10          | SP = (1152921510062283200 - 16) = 1152921510062283184 (0x10000001452B59B0);
            // 0x00BCDC3C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCDC40: LDRB w8, [x20, #0xbc3]     | W8 = (bool)static_value_03733BC3;       
            // 0x00BCDC44: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BCDC48: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCDC4C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCDC50: TBNZ w8, #0, #0xbcdc6c     | if (static_value_03733BC3 == true) goto label_0;
            // 0x00BCDC54: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00BCDC58: LDR x8, [x8, #0xcd0]       | X8 = 0x2B8F734;                         
            // 0x00BCDC5C: LDR w0, [x8]               | W0 = 0x1491;                            
            // 0x00BCDC60: BL #0x2782188              | X0 = sub_2782188( ?? 0x1491, ????);     
            // 0x00BCDC64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCDC68: STRB w8, [x20, #0xbc3]     | static_value_03733BC3 = true;            //  dest_result_addr=57883587
            label_0:
            // 0x00BCDC6C: CBNZ x19, #0xbcdc74        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCDC70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1491, ????);     
            label_1:
            // 0x00BCDC74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCDC78: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCDC7C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCDC80: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCDC84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDC88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDC8C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCDC90: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCDC94: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDC98: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCDC9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDCA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDCA4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCDCA8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCDCAC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDCB0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCDCB4: CBNZ x21, #0xbcdcbc        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCDCB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCDCBC: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BCDCC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDCC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDCC8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCDCCC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCDCD0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDCD4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCDCD8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCDCDC: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCDCE0: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCDCE4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCDCE8: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCDCEC: LDR x25, [x9]              | X25 = typeof(BMFont);                   
            // 0x00BCDCF0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCDCF4: TBZ w9, #0, #0xbcdd08      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BCDCF8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDCFC: CBNZ w9, #0xbcdd08         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BCDD00: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCDD04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BCDD08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDD0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCDD10: MOV x1, x25                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCDD14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCDD18: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCDD1C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCDD20: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BCDD24: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCDD28: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCDD2C: TBZ w9, #0, #0xbcdd40      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BCDD30: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDD34: CBNZ w9, #0xbcdd40         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BCDD38: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCDD3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BCDD40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDD44: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCDD48: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCDD4C: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCDD50: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BCDD54: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCDD58: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCDD5C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCDD60: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BCDD64: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCDD68: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCDD6C: TBZ w9, #0, #0xbcdd80      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BCDD70: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDD74: CBNZ w9, #0xbcdd80         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BCDD78: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCDD7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BCDD80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDD84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDD88: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BCDD8C: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BCDD90: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BCDD94: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BCDD98: CBZ x0, #0xbcddfc          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BCDD9C: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCDDA0: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCDDA4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCDDA8: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCDDAC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCDDB0: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCDDB4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCDDB8: B.LO #0xbcddd4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BCDDBC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCDDC0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCDDC4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCDDC8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCDDCC: MOV x23, x0                | X23 = val_7;//m1                        
            val_10 = val_7;
            // 0x00BCDDD0: B.EQ #0xbcddfc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BCDDD4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCDDD8: ADD x8, sp, #8             | X8 = (1152921510062283184 + 8) = 1152921510062283192 (0x10000001452B59B8);
            // 0x00BCDDDC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCDDE0: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510062271280]
            // 0x00BCDDE4: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BCDDE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCDDEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BCDDF0: ADD x0, sp, #8             | X0 = (1152921510062283184 + 8) = 1152921510062283192 (0x10000001452B59B8);
            // 0x00BCDDF4: BL #0x299a140              | 
            // 0x00BCDDF8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x00BCDDFC: CBNZ x19, #0xbcde04        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BCDE00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001452B59B8, ????);
            label_12:
            // 0x00BCDE04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCDE08: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCDE0C: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCDE10: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCDE14: CBNZ x23, #0xbcde1c        | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x00BCDE18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BCDE1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCDE20: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDE24: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x00BCDE28: BL #0xb9230c               | val_10.set_texHeight(value:  val_3 + 4);
            val_10.texHeight = val_3 + 4;
            // 0x00BCDE2C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCDE30: SUB sp, x29, #0x40         | SP = (1152921510062283264 - 64) = 1152921510062283200 (0x10000001452B59C0);
            // 0x00BCDE34: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCDE38: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCDE3C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCDE40: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCDE44: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCDE48: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCDE4C: MOV x19, x0                | 
            // 0x00BCDE50: ADD x0, sp, #8             | 
            // 0x00BCDE54: BL #0x299a140              | 
            // 0x00BCDE58: MOV x0, x19                | 
            // 0x00BCDE5C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCDE60 (12377696), len: 584  VirtAddr: 0x00BCDE60 RVA: 0x00BCDE60 token: 100663870 methodIndex: 29915 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_glyphCount_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BCDE60: STP x26, x25, [sp, #-0x50]! | stack[1152921510062452544] = ???;  stack[1152921510062452552] = ???;  //  dest_result_addr=1152921510062452544 |  dest_result_addr=1152921510062452552
            // 0x00BCDE64: STP x24, x23, [sp, #0x10]  | stack[1152921510062452560] = ???;  stack[1152921510062452568] = ???;  //  dest_result_addr=1152921510062452560 |  dest_result_addr=1152921510062452568
            // 0x00BCDE68: STP x22, x21, [sp, #0x20]  | stack[1152921510062452576] = ???;  stack[1152921510062452584] = ???;  //  dest_result_addr=1152921510062452576 |  dest_result_addr=1152921510062452584
            // 0x00BCDE6C: STP x20, x19, [sp, #0x30]  | stack[1152921510062452592] = ???;  stack[1152921510062452600] = ???;  //  dest_result_addr=1152921510062452592 |  dest_result_addr=1152921510062452600
            // 0x00BCDE70: STP x29, x30, [sp, #0x40]  | stack[1152921510062452608] = ???;  stack[1152921510062452616] = ???;  //  dest_result_addr=1152921510062452608 |  dest_result_addr=1152921510062452616
            // 0x00BCDE74: ADD x29, sp, #0x40         | X29 = (1152921510062452544 + 64) = 1152921510062452608 (0x10000001452DEF80);
            // 0x00BCDE78: SUB sp, sp, #0x10          | SP = (1152921510062452544 - 16) = 1152921510062452528 (0x10000001452DEF30);
            // 0x00BCDE7C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCDE80: LDRB w8, [x19, #0xbc4]     | W8 = (bool)static_value_03733BC4;       
            // 0x00BCDE84: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCDE88: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCDE8C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCDE90: TBNZ w8, #0, #0xbcdeac     | if (static_value_03733BC4 == true) goto label_0;
            // 0x00BCDE94: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x00BCDE98: LDR x8, [x8, #0x9b0]       | X8 = 0x2B8F704;                         
            // 0x00BCDE9C: LDR w0, [x8]               | W0 = 0x1485;                            
            // 0x00BCDEA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1485, ????);     
            // 0x00BCDEA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCDEA8: STRB w8, [x19, #0xbc4]     | static_value_03733BC4 = true;            //  dest_result_addr=57883588
            label_0:
            // 0x00BCDEAC: CBNZ x20, #0xbcdeb4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCDEB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1485, ????);     
            label_1:
            // 0x00BCDEB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCDEB8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCDEBC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCDEC0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCDEC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDEC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDECC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCDED0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCDED4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDED8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCDEDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDEE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDEE4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCDEE8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCDEEC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCDEF0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCDEF4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCDEF8: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCDEFC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCDF00: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCDF04: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCDF08: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCDF0C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCDF10: TBZ w9, #0, #0xbcdf24      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCDF14: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDF18: CBNZ w9, #0xbcdf24         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCDF1C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCDF20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCDF24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDF28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCDF2C: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCDF30: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCDF34: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCDF38: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCDF3C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCDF40: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCDF44: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCDF48: TBZ w9, #0, #0xbcdf5c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCDF4C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDF50: CBNZ w9, #0xbcdf5c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCDF54: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCDF58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCDF5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDF60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCDF64: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCDF68: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCDF6C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCDF70: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCDF74: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCDF78: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCDF7C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCDF80: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCDF84: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCDF88: TBZ w9, #0, #0xbcdf9c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCDF8C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCDF90: CBNZ w9, #0xbcdf9c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCDF94: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCDF98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCDF9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCDFA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCDFA4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCDFA8: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCDFAC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCDFB0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCDFB4: CBZ x0, #0xbce018          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCDFB8: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCDFBC: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCDFC0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCDFC4: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCDFC8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCDFCC: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCDFD0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCDFD4: B.LO #0xbcdff0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCDFD8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCDFDC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCDFE0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCDFE4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCDFE8: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCDFEC: B.EQ #0xbce018             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCDFF0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCDFF4: ADD x8, sp, #8             | X8 = (1152921510062452528 + 8) = 1152921510062452536 (0x10000001452DEF38);
            // 0x00BCDFF8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCDFFC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510062440624]
            // 0x00BCE000: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCE004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE008: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCE00C: ADD x0, sp, #8             | X0 = (1152921510062452528 + 8) = 1152921510062452536 (0x10000001452DEF38);
            // 0x00BCE010: BL #0x299a140              | 
            // 0x00BCE014: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCE018: CBNZ x20, #0xbce020        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCE01C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001452DEF38, ????);
            label_11:
            // 0x00BCE020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE024: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCE028: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCE02C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCE030: CBNZ x22, #0xbce038        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCE034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCE038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE03C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE040: BL #0xb92314               | X0 = val_11.get_glyphCount();           
            int val_9 = val_11.glyphCount;
            // 0x00BCE044: CBZ x19, #0xbce0a0         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCE048: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCE04C: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BCE050: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCE054: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BCE058: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCE05C: TBZ w9, #0, #0xbce06c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BCE060: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCE064: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCE068: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BCE06C: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BCE070: SUB sp, x29, #0x40         | SP = (1152921510062452608 - 64) = 1152921510062452544 (0x10000001452DEF40);
            // 0x00BCE074: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCE078: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCE07C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCE080: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCE084: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCE088: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCE08C: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BCE090: ADD x0, sp, #8             | X0 = (1152921510062452624 + 8) = 1152921510062452632 (0x10000001452DEF98);
            // 0x00BCE094: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001452DEF98); //ERROR_TYPE
            // 0x00BCE098: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BCE09C: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BCE0A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BCE0A4: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCE0A8 (12378280), len: 552  VirtAddr: 0x00BCE0A8 RVA: 0x00BCE0A8 token: 100663871 methodIndex: 29916 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_spriteName_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x00BCE0A8: STP x24, x23, [sp, #-0x40]! | stack[1152921510062626000] = ???;  stack[1152921510062626008] = ???;  //  dest_result_addr=1152921510062626000 |  dest_result_addr=1152921510062626008
            // 0x00BCE0AC: STP x22, x21, [sp, #0x10]  | stack[1152921510062626016] = ???;  stack[1152921510062626024] = ???;  //  dest_result_addr=1152921510062626016 |  dest_result_addr=1152921510062626024
            // 0x00BCE0B0: STP x20, x19, [sp, #0x20]  | stack[1152921510062626032] = ???;  stack[1152921510062626040] = ???;  //  dest_result_addr=1152921510062626032 |  dest_result_addr=1152921510062626040
            // 0x00BCE0B4: STP x29, x30, [sp, #0x30]  | stack[1152921510062626048] = ???;  stack[1152921510062626056] = ???;  //  dest_result_addr=1152921510062626048 |  dest_result_addr=1152921510062626056
            // 0x00BCE0B8: ADD x29, sp, #0x30         | X29 = (1152921510062626000 + 48) = 1152921510062626048 (0x1000000145309500);
            // 0x00BCE0BC: SUB sp, sp, #0x10          | SP = (1152921510062626000 - 16) = 1152921510062625984 (0x10000001453094C0);
            // 0x00BCE0C0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BCE0C4: LDRB w8, [x21, #0xbc5]     | W8 = (bool)static_value_03733BC5;       
            // 0x00BCE0C8: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BCE0CC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCE0D0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCE0D4: TBNZ w8, #0, #0xbce0f0     | if (static_value_03733BC5 == true) goto label_0;
            // 0x00BCE0D8: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BCE0DC: LDR x8, [x8, #0xa88]       | X8 = 0x2B8F710;                         
            // 0x00BCE0E0: LDR w0, [x8]               | W0 = 0x1488;                            
            // 0x00BCE0E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1488, ????);     
            // 0x00BCE0E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCE0EC: STRB w8, [x21, #0xbc5]     | static_value_03733BC5 = true;            //  dest_result_addr=57883589
            label_0:
            // 0x00BCE0F0: CBNZ x20, #0xbce0f8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCE0F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1488, ????);     
            label_1:
            // 0x00BCE0F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE0FC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCE100: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCE104: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCE108: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE10C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE110: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCE114: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE118: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE11C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BCE120: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE124: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE128: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCE12C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE130: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE134: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCE138: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCE13C: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCE140: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BCE144: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCE148: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCE14C: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCE150: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCE154: TBZ w9, #0, #0xbce168      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCE158: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE15C: CBNZ w9, #0xbce168         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCE160: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCE164: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCE168: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE16C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE170: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCE174: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCE178: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCE17C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCE180: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCE184: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCE188: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCE18C: TBZ w9, #0, #0xbce1a0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCE190: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE194: CBNZ w9, #0xbce1a0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCE198: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCE19C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCE1A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE1A4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCE1A8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BCE1AC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCE1B0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BCE1B4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCE1B8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCE1BC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCE1C0: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BCE1C4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCE1C8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCE1CC: TBZ w9, #0, #0xbce1e0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCE1D0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE1D4: CBNZ w9, #0xbce1e0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCE1D8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCE1DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCE1E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE1E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE1E8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCE1EC: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BCE1F0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCE1F4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCE1F8: CBZ x0, #0xbce25c          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCE1FC: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCE200: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCE204: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCE208: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCE20C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCE210: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCE214: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCE218: B.LO #0xbce234             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCE21C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCE220: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCE224: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCE228: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCE22C: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCE230: B.EQ #0xbce25c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCE234: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCE238: ADD x8, sp, #8             | X8 = (1152921510062625984 + 8) = 1152921510062625992 (0x10000001453094C8);
            // 0x00BCE23C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCE240: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510062614064]
            // 0x00BCE244: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCE248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE24C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCE250: ADD x0, sp, #8             | X0 = (1152921510062625984 + 8) = 1152921510062625992 (0x10000001453094C8);
            // 0x00BCE254: BL #0x299a140              | 
            // 0x00BCE258: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCE25C: CBNZ x20, #0xbce264        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCE260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001453094C8, ????);
            label_11:
            // 0x00BCE264: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE268: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCE26C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BCE270: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCE274: CBNZ x23, #0xbce27c        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCE278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCE27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE280: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE284: BL #0xb9238c               | X0 = val_11.get_spriteName();           
            string val_9 = val_11.spriteName;
            // 0x00BCE288: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x00BCE28C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE290: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCE294: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BCE298: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BCE29C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCE2A0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BCE2A4: SUB sp, x29, #0x30         | SP = (1152921510062626048 - 48) = 1152921510062626000 (0x10000001453094D0);
            // 0x00BCE2A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCE2AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCE2B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCE2B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BCE2B8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCE2BC: MOV x19, x0                | 
            // 0x00BCE2C0: ADD x0, sp, #8             | 
            // 0x00BCE2C4: BL #0x299a140              | 
            // 0x00BCE2C8: MOV x0, x19                | 
            // 0x00BCE2CC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCE2D0 (12378832), len: 748  VirtAddr: 0x00BCE2D0 RVA: 0x00BCE2D0 token: 100663872 methodIndex: 29917 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_spriteName_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_14;
            //  | 
            var val_15;
            // 0x00BCE2D0: STP x26, x25, [sp, #-0x50]! | stack[1152921510062811712] = ???;  stack[1152921510062811720] = ???;  //  dest_result_addr=1152921510062811712 |  dest_result_addr=1152921510062811720
            // 0x00BCE2D4: STP x24, x23, [sp, #0x10]  | stack[1152921510062811728] = ???;  stack[1152921510062811736] = ???;  //  dest_result_addr=1152921510062811728 |  dest_result_addr=1152921510062811736
            // 0x00BCE2D8: STP x22, x21, [sp, #0x20]  | stack[1152921510062811744] = ???;  stack[1152921510062811752] = ???;  //  dest_result_addr=1152921510062811744 |  dest_result_addr=1152921510062811752
            // 0x00BCE2DC: STP x20, x19, [sp, #0x30]  | stack[1152921510062811760] = ???;  stack[1152921510062811768] = ???;  //  dest_result_addr=1152921510062811760 |  dest_result_addr=1152921510062811768
            // 0x00BCE2E0: STP x29, x30, [sp, #0x40]  | stack[1152921510062811776] = ???;  stack[1152921510062811784] = ???;  //  dest_result_addr=1152921510062811776 |  dest_result_addr=1152921510062811784
            // 0x00BCE2E4: ADD x29, sp, #0x40         | X29 = (1152921510062811712 + 64) = 1152921510062811776 (0x1000000145336A80);
            // 0x00BCE2E8: SUB sp, sp, #0x10          | SP = (1152921510062811712 - 16) = 1152921510062811696 (0x1000000145336A30);
            // 0x00BCE2EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCE2F0: LDRB w8, [x20, #0xbc6]     | W8 = (bool)static_value_03733BC6;       
            // 0x00BCE2F4: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BCE2F8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCE2FC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCE300: TBNZ w8, #0, #0xbce31c     | if (static_value_03733BC6 == true) goto label_0;
            // 0x00BCE304: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BCE308: LDR x8, [x8, #0xcf8]       | X8 = 0x2B8F730;                         
            // 0x00BCE30C: LDR w0, [x8]               | W0 = 0x1490;                            
            // 0x00BCE310: BL #0x2782188              | X0 = sub_2782188( ?? 0x1490, ????);     
            // 0x00BCE314: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCE318: STRB w8, [x20, #0xbc6]     | static_value_03733BC6 = true;            //  dest_result_addr=57883590
            label_0:
            // 0x00BCE31C: CBNZ x19, #0xbce324        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCE320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1490, ????);     
            label_1:
            // 0x00BCE324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE328: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCE32C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCE330: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCE334: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE338: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE33C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCE340: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE344: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE348: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCE34C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE354: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCE358: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE35C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE360: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCE364: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCE368: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BCE36C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BCE370: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCE374: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BCE378: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BCE37C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCE380: TBZ w9, #0, #0xbce394      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCE384: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE388: CBNZ w9, #0xbce394         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCE38C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCE390: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCE394: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE39C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BCE3A0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCE3A4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCE3A8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCE3AC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCE3B0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCE3B4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCE3B8: TBZ w9, #0, #0xbce3cc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCE3BC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE3C0: CBNZ w9, #0xbce3cc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCE3C4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCE3C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCE3CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE3D0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCE3D4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BCE3D8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCE3DC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCE3E0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCE3E4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCE3E8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCE3EC: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BCE3F0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCE3F4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCE3F8: TBZ w9, #0, #0xbce40c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCE3FC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE400: CBNZ w9, #0xbce40c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCE404: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCE408: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCE40C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE410: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE414: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCE418: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BCE41C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCE420: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x00BCE424: CBZ x0, #0xbce46c          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BCE428: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BCE42C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BCE430: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BCE434: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCE438: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BCE43C: MOV x24, x0                | X24 = val_6;//m1                        
            val_14 = val_6;
            // 0x00BCE440: B.EQ #0xbce46c             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BCE444: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCE448: MOV x8, sp                 | X8 = 1152921510062811696 (0x1000000145336A30);//ML01
            // 0x00BCE44C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCE450: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510062799792]
            // 0x00BCE454: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BCE458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE45C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BCE460: MOV x0, sp                 | X0 = 1152921510062811696 (0x1000000145336A30);//ML01
            // 0x00BCE464: BL #0x299a140              | 
            // 0x00BCE468: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_9:
            // 0x00BCE46C: CBNZ x19, #0xbce474        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BCE470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145336A30, ????);
            label_10:
            // 0x00BCE474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE478: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCE47C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BCE480: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCE484: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE488: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE48C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCE490: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE494: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE498: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BCE49C: LDR x8, [x8, #0x778]       | X8 = 1152921504875909120;               
            // 0x00BCE4A0: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BCE4A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE4A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE4AC: LDR x1, [x8]               | X1 = typeof(BMFont);                    
            // 0x00BCE4B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCE4B4: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BCE4B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE4BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCE4C0: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BCE4C4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCE4C8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCE4CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCE4D0: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BCE4D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE4D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE4DC: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BCE4E0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BCE4E4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BCE4E8: CBZ x0, #0xbce54c          | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x00BCE4EC: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCE4F0: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCE4F4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCE4F8: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCE4FC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCE500: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCE504: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCE508: B.LO #0xbce524             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BCE50C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCE510: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCE514: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCE518: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCE51C: MOV x21, x0                | X21 = val_11;//m1                       
            val_15 = val_11;
            // 0x00BCE520: B.EQ #0xbce54c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BCE524: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCE528: ADD x8, sp, #8             | X8 = (1152921510062811696 + 8) = 1152921510062811704 (0x1000000145336A38);
            // 0x00BCE52C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCE530: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510062799792]
            // 0x00BCE534: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BCE538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE53C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BCE540: ADD x0, sp, #8             | X0 = (1152921510062811696 + 8) = 1152921510062811704 (0x1000000145336A38);
            // 0x00BCE544: BL #0x299a140              | 
            // 0x00BCE548: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_13:
            // 0x00BCE54C: CBNZ x19, #0xbce554        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BCE550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145336A38, ????);
            label_14:
            // 0x00BCE554: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE558: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCE55C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BCE560: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCE564: CBNZ x21, #0xbce56c        | if (0x0 != 0) goto label_15;            
            if(val_15 != 0)
            {
                goto label_15;
            }
            // 0x00BCE568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BCE56C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE570: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE574: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE578: BL #0xb92394               | val_15.set_spriteName(value:  val_14);  
            val_15.spriteName = val_14;
            // 0x00BCE57C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCE580: SUB sp, x29, #0x40         | SP = (1152921510062811776 - 64) = 1152921510062811712 (0x1000000145336A40);
            // 0x00BCE584: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCE588: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCE58C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCE590: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCE594: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCE598: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCE59C: MOV x19, x0                | 
            // 0x00BCE5A0: ADD x0, sp, #8             | 
            // 0x00BCE5A4: B #0xbce5b0                | 
            // 0x00BCE5A8: MOV x19, x0                | 
            // 0x00BCE5AC: MOV x0, sp                 | 
            label_16:
            // 0x00BCE5B0: BL #0x299a140              | 
            // 0x00BCE5B4: MOV x0, x19                | 
            // 0x00BCE5B8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCE5BC (12379580), len: 876  VirtAddr: 0x00BCE5BC RVA: 0x00BCE5BC token: 100663873 methodIndex: 29918 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_glyphs_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x00BCE5BC: STP x24, x23, [sp, #-0x40]! | stack[1152921510062997456] = ???;  stack[1152921510062997464] = ???;  //  dest_result_addr=1152921510062997456 |  dest_result_addr=1152921510062997464
            // 0x00BCE5C0: STP x22, x21, [sp, #0x10]  | stack[1152921510062997472] = ???;  stack[1152921510062997480] = ???;  //  dest_result_addr=1152921510062997472 |  dest_result_addr=1152921510062997480
            // 0x00BCE5C4: STP x20, x19, [sp, #0x20]  | stack[1152921510062997488] = ???;  stack[1152921510062997496] = ???;  //  dest_result_addr=1152921510062997488 |  dest_result_addr=1152921510062997496
            // 0x00BCE5C8: STP x29, x30, [sp, #0x30]  | stack[1152921510062997504] = ???;  stack[1152921510062997512] = ???;  //  dest_result_addr=1152921510062997504 |  dest_result_addr=1152921510062997512
            // 0x00BCE5CC: ADD x29, sp, #0x30         | X29 = (1152921510062997456 + 48) = 1152921510062997504 (0x1000000145364000);
            // 0x00BCE5D0: SUB sp, sp, #0x20          | SP = (1152921510062997456 - 32) = 1152921510062997424 (0x1000000145363FB0);
            // 0x00BCE5D4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCE5D8: LDRB w8, [x20, #0xbc7]     | W8 = (bool)static_value_03733BC7;       
            // 0x00BCE5DC: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BCE5E0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCE5E4: MOV x21, x1                | X21 = X1;//m1                           
            val_14 = X1;
            // 0x00BCE5E8: TBNZ w8, #0, #0xbce604     | if (static_value_03733BC7 == true) goto label_0;
            // 0x00BCE5EC: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00BCE5F0: LDR x8, [x8, #0x98]        | X8 = 0x2B8F708;                         
            // 0x00BCE5F4: LDR w0, [x8]               | W0 = 0x1486;                            
            // 0x00BCE5F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1486, ????);     
            // 0x00BCE5FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCE600: STRB w8, [x20, #0xbc7]     | static_value_03733BC7 = true;            //  dest_result_addr=57883591
            label_0:
            // 0x00BCE604: CBNZ x21, #0xbce60c        | if (X1 != 0) goto label_1;              
            if(val_14 != 0)
            {
                goto label_1;
            }
            // 0x00BCE608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1486, ????);     
            label_1:
            // 0x00BCE60C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE610: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCE614: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_14.AppDomain;
            // 0x00BCE618: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCE61C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE620: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE624: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCE628: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE62C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE630: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCE634: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE638: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE63C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCE640: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCE644: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE648: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCE64C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCE650: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCE654: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BCE658: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCE65C: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCE660: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCE664: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCE668: TBZ w9, #0, #0xbce67c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCE66C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE670: CBNZ w9, #0xbce67c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCE674: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCE678: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCE67C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE680: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE684: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCE688: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCE68C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCE690: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCE694: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCE698: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCE69C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCE6A0: TBZ w9, #0, #0xbce6b4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCE6A4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE6A8: CBNZ w9, #0xbce6b4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCE6AC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCE6B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCE6B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE6B8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCE6BC: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BCE6C0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCE6C4: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BCE6C8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BCE6CC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCE6D0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCE6D4: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BCE6D8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCE6DC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCE6E0: TBZ w9, #0, #0xbce6f4      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCE6E4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCE6E8: CBNZ w9, #0xbce6f4         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCE6EC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCE6F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCE6F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE6F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE6FC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCE700: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BCE704: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCE708: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BCE70C: CBZ x0, #0xbce770          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCE710: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCE714: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCE718: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCE71C: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCE720: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCE724: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCE728: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCE72C: B.LO #0xbce748             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCE730: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCE734: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCE738: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCE73C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCE740: MOV x23, x0                | X23 = val_6;//m1                        
            val_15 = val_6;
            // 0x00BCE744: B.EQ #0xbce770             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCE748: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCE74C: ADD x8, sp, #8             | X8 = (1152921510062997424 + 8) = 1152921510062997432 (0x1000000145363FB8);
            // 0x00BCE750: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCE754: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510062985520]
            // 0x00BCE758: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCE75C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE760: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCE764: ADD x0, sp, #8             | X0 = (1152921510062997424 + 8) = 1152921510062997432 (0x1000000145363FB8);
            // 0x00BCE768: BL #0x299a140              | 
            // 0x00BCE76C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x00BCE770: CBNZ x21, #0xbce778        | if (X1 != 0) goto label_11;             
            if(val_14 != 0)
            {
                goto label_11;
            }
            // 0x00BCE774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145363FB8, ????);
            label_11:
            // 0x00BCE778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCE77C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCE780: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BCE784: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_14.Free(esp:  null);
            // 0x00BCE788: CBNZ x23, #0xbce790        | if (0x0 != 0) goto label_12;            
            if(val_15 != 0)
            {
                goto label_12;
            }
            // 0x00BCE78C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCE790: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE794: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE798: BL #0xb9239c               | X0 = val_15.get_glyphs();               
            System.Collections.Generic.List<BMGlyph> val_9 = val_15.glyphs;
            // 0x00BCE79C: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x00BCE7A0: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_16 = 1152921504824418304;
            // 0x00BCE7A4: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BCE7A8: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_17 = null;
            // 0x00BCE7AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00BCE7B0: CBZ x0, #0xbce844          | if (val_9 == null) goto label_13;       
            if(val_9 == null)
            {
                goto label_13;
            }
            // 0x00BCE7B4: CBZ x22, #0xbce85c         | if (val_9 == null) goto label_14;       
            if(val_9 == null)
            {
                goto label_14;
            }
            // 0x00BCE7B8: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x00BCE7BC: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00BCE7C0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCE7C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00BCE7C8: CBNZ x0, #0xbce7fc         | if (val_9 != null) goto label_15;       
            if(val_9 != null)
            {
                goto label_15;
            }
            // 0x00BCE7CC: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.List<BMGlyph>);
            // 0x00BCE7D0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCE7D4: LDR x0, [x8, #0x30]        | X0 = System.Collections.Generic.List<T>.__il2cppRuntimeField_element_class;
            // 0x00BCE7D8: ADD x8, sp, #0x10          | X8 = (1152921510062997424 + 16) = 1152921510062997440 (0x1000000145363FC0);
            // 0x00BCE7DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.Generic.List<T>.__il2cppRuntimeField_element_class, ????);
            // 0x00BCE7E0: LDR x0, [sp, #0x10]        | X0 = val_10;                             //  find_add[1152921510062985520]
            // 0x00BCE7E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x00BCE7E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE7EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x00BCE7F0: ADD x0, sp, #0x10          | X0 = (1152921510062997424 + 16) = 1152921510062997440 (0x1000000145363FC0);
            // 0x00BCE7F4: BL #0x299a140              | 
            // 0x00BCE7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145363FC0, ????);
            label_15:
            // 0x00BCE7FC: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            // 0x00BCE800: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00BCE804: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x00BCE808: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00BCE80C: MOV x23, x0                | X23 = val_9;//m1                        
            val_16 = val_9;
            // 0x00BCE810: CBNZ x23, #0xbce868        | if (val_9 != null) goto label_16;       
            if(val_16 != null)
            {
                goto label_16;
            }
            // 0x00BCE814: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.List<BMGlyph>);
            // 0x00BCE818: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCE81C: LDR x0, [x8, #0x30]        | X0 = System.Collections.Generic.List<T>.__il2cppRuntimeField_element_class;
            // 0x00BCE820: ADD x8, sp, #0x18          | X8 = (1152921510062997424 + 24) = 1152921510062997448 (0x1000000145363FC8);
            // 0x00BCE824: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.Generic.List<T>.__il2cppRuntimeField_element_class, ????);
            // 0x00BCE828: LDR x0, [sp, #0x18]        | X0 = val_11;                             //  find_add[1152921510062985520]
            // 0x00BCE82C: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x00BCE830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x00BCE834: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x00BCE838: ADD x0, sp, #0x18          | X0 = (1152921510062997424 + 24) = 1152921510062997448 (0x1000000145363FC8);
            // 0x00BCE83C: BL #0x299a140              | 
            // 0x00BCE840: B #0xbce864                |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x00BCE844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE848: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCE84C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCE850: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BCE854: MOV x3, x22                | X3 = val_9;//m1                         
            // 0x00BCE858: B #0xbce8dc                |  goto label_18;                         
            goto label_18;
            label_14:
            // 0x00BCE85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00BCE860: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_14 = null;
            label_17:
            // 0x00BCE864: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_16:
            // 0x00BCE868: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x00BCE86C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x00BCE870: CBZ x9, #0xbce89c          | if (mem[282584257676929] == 0) goto label_19;
            if(mem[282584257676929] == 0)
            {
                goto label_19;
            }
            // 0x00BCE874: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_13 = mem[282584257676823];
            // 0x00BCE878: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x00BCE87C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_13 = val_13 + 8;
            label_21:
            // 0x00BCE880: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x00BCE884: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x00BCE888: B.EQ #0xbce8b0             | if ((mem[282584257676823] + 8) + -8 == val_14) goto label_20;
            if(((mem[282584257676823] + 8) + -8) == val_14)
            {
                goto label_20;
            }
            // 0x00BCE88C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x00BCE890: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_13 = val_13 + 16;
            // 0x00BCE894: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x00BCE898: B.LO #0xbce880             | if (0 < mem[282584257676929]) goto label_21;
            if(val_14 < mem[282584257676929])
            {
                goto label_21;
            }
            label_19:
            // 0x00BCE89C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BCE8A0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_18 = val_16;
            // 0x00BCE8A4: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_14;
            // 0x00BCE8A8: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x00BCE8AC: B #0xbce8bc                |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x00BCE8B0: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x00BCE8B4: ADD x8, x8, x9, lsl #4     | X8 = (val_16 + ((mem[282584257676823] + 8)) << 4);
            val_16 = val_16 + (((mem[282584257676823] + 8)) << 4);
            // 0x00BCE8B8: ADD x0, x8, #0x110         | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_18 = val_16 + 272;
            label_22:
            // 0x00BCE8BC: LDP x8, x1, [x0]           | X8 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x00BCE8C0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE8C4: BLR x8                     | X0 = ((val_16 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x00BCE8C8: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x00BCE8CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE8D0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCE8D4: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCE8D8: MOV x2, x19                | X2 = X3;//m1                            
            label_18:
            // 0x00BCE8DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCE8E0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x00BCE8E4: SUB sp, x29, #0x30         | SP = (1152921510062997504 - 48) = 1152921510062997456 (0x1000000145363FD0);
            // 0x00BCE8E8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCE8EC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCE8F0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCE8F4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BCE8F8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_12;
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCE8FC: MOV x19, x0                | 
            // 0x00BCE900: ADD x0, sp, #8             | 
            // 0x00BCE904: B #0xbce91c                | 
            // 0x00BCE908: MOV x19, x0                | 
            // 0x00BCE90C: ADD x0, sp, #0x10          | 
            // 0x00BCE910: B #0xbce91c                | 
            // 0x00BCE914: MOV x19, x0                | 
            // 0x00BCE918: ADD x0, sp, #0x18          | 
            label_24:
            // 0x00BCE91C: BL #0x299a140              | 
            // 0x00BCE920: MOV x0, x19                | 
            // 0x00BCE924: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCE928 (12380456), len: 952  VirtAddr: 0x00BCE928 RVA: 0x00BCE928 token: 100663874 methodIndex: 29919 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetGlyph_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            var val_13;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            // 0x00BCE928: STP x26, x25, [sp, #-0x50]! | stack[1152921510063174976] = ???;  stack[1152921510063174984] = ???;  //  dest_result_addr=1152921510063174976 |  dest_result_addr=1152921510063174984
            // 0x00BCE92C: STP x24, x23, [sp, #0x10]  | stack[1152921510063174992] = ???;  stack[1152921510063175000] = ???;  //  dest_result_addr=1152921510063174992 |  dest_result_addr=1152921510063175000
            // 0x00BCE930: STP x22, x21, [sp, #0x20]  | stack[1152921510063175008] = ???;  stack[1152921510063175016] = ???;  //  dest_result_addr=1152921510063175008 |  dest_result_addr=1152921510063175016
            // 0x00BCE934: STP x20, x19, [sp, #0x30]  | stack[1152921510063175024] = ???;  stack[1152921510063175032] = ???;  //  dest_result_addr=1152921510063175024 |  dest_result_addr=1152921510063175032
            // 0x00BCE938: STP x29, x30, [sp, #0x40]  | stack[1152921510063175040] = ???;  stack[1152921510063175048] = ???;  //  dest_result_addr=1152921510063175040 |  dest_result_addr=1152921510063175048
            // 0x00BCE93C: ADD x29, sp, #0x40         | X29 = (1152921510063174976 + 64) = 1152921510063175040 (0x100000014538F580);
            // 0x00BCE940: SUB sp, sp, #0x20          | SP = (1152921510063174976 - 32) = 1152921510063174944 (0x100000014538F520);
            // 0x00BCE944: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCE948: LDRB w8, [x20, #0xbc8]     | W8 = (bool)static_value_03733BC8;       
            // 0x00BCE94C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BCE950: MOV x23, x2                | X23 = X2;//m1                           
            // 0x00BCE954: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BCE958: TBNZ w8, #0, #0xbce974     | if (static_value_03733BC8 == true) goto label_0;
            // 0x00BCE95C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BCE960: LDR x8, [x8, #0x810]       | X8 = 0x2B8F71C;                         
            // 0x00BCE964: LDR w0, [x8]               | W0 = 0x148B;                            
            // 0x00BCE968: BL #0x2782188              | X0 = sub_2782188( ?? 0x148B, ????);     
            // 0x00BCE96C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCE970: STRB w8, [x20, #0xbc8]     | static_value_03733BC8 = true;            //  dest_result_addr=57883592
            label_0:
            // 0x00BCE974: CBNZ x21, #0xbce97c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCE978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x148B, ????);     
            label_1:
            // 0x00BCE97C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCE980: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCE984: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCE988: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCE98C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE990: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE994: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BCE998: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCE99C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE9A0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCE9A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE9A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE9AC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCE9B0: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCE9B4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE9B8: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BCE9BC: CBNZ x22, #0xbce9c4        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCE9C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCE9C4: LDR w26, [x22, #4]         | W26 = val_3 + 4;                        
            // 0x00BCE9C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE9CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE9D0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCE9D4: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCE9D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCE9DC: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCE9E0: CBNZ x22, #0xbce9e8        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BCE9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BCE9E8: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x00BCE9EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCE9F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCE9F4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BCE9F8: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCE9FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCEA00: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCEA04: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCEA08: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCEA0C: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BCEA10: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCEA14: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCEA18: LDR x25, [x9]              | X25 = typeof(BMFont);                   
            // 0x00BCEA1C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCEA20: TBZ w9, #0, #0xbcea34      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCEA24: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCEA28: CBNZ w9, #0xbcea34         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCEA2C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCEA30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00BCEA34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEA38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCEA3C: MOV x1, x25                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCEA40: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCEA44: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCEA48: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCEA4C: MOV x25, x0                | X25 = val_6;//m1                        
            // 0x00BCEA50: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCEA54: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCEA58: TBZ w9, #0, #0xbcea6c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCEA5C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCEA60: CBNZ w9, #0xbcea6c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCEA64: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCEA68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x00BCEA6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEA70: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCEA74: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x00BCEA78: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCEA7C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BCEA80: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BCEA84: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCEA88: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCEA8C: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x00BCEA90: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCEA94: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCEA98: TBZ w9, #0, #0xbceaac      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BCEA9C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCEAA0: CBNZ w9, #0xbceaac         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BCEAA4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCEAA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x00BCEAAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEAB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCEAB4: MOV x1, x25                | X1 = val_6;//m1                         
            // 0x00BCEAB8: MOV x2, x24                | X2 = val_7;//m1                         
            // 0x00BCEABC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x00BCEAC0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BCEAC4: CBZ x0, #0xbceb28          | if (val_8 == null) goto label_12;       
            if(val_8 == null)
            {
                goto label_12;
            }
            // 0x00BCEAC8: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCEACC: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCEAD0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCEAD4: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCEAD8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCEADC: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCEAE0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCEAE4: B.LO #0xbceb00             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x00BCEAE8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCEAEC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCEAF0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCEAF4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCEAF8: MOV x24, x0                | X24 = val_8;//m1                        
            val_17 = val_8;
            // 0x00BCEAFC: B.EQ #0xbceb28             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x00BCEB00: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCEB04: ADD x8, sp, #8             | X8 = (1152921510063174944 + 8) = 1152921510063174952 (0x100000014538F528);
            // 0x00BCEB08: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCEB0C: LDR x0, [sp, #8]           | X0 = val_10;                             //  find_add[1152921510063163056]
            // 0x00BCEB10: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x00BCEB14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCEB18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x00BCEB1C: ADD x0, sp, #8             | X0 = (1152921510063174944 + 8) = 1152921510063174952 (0x100000014538F528);
            // 0x00BCEB20: BL #0x299a140              | 
            // 0x00BCEB24: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_12:
            // 0x00BCEB28: CBNZ x21, #0xbceb30        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BCEB2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014538F528, ????);
            label_13:
            // 0x00BCEB30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCEB34: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCEB38: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x00BCEB3C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCEB40: CBNZ x24, #0xbceb48        | if (0x0 != 0) goto label_14;            
            if(val_17 != 0)
            {
                goto label_14;
            }
            // 0x00BCEB44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_14:
            // 0x00BCEB48: CMP w26, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x00BCEB4C: CSET w2, eq                | W2 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_11 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x00BCEB50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCEB54: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEB58: MOV w1, w22                | W1 = val_4 + 4;//m1                     
            // 0x00BCEB5C: BL #0xb923a4               | X0 = val_17.GetGlyph(index:  val_4 + 4, createIfMissing:  bool val_11 = ((val_3 + 4) == 1) ? 1 : 0);
            BMGlyph val_12 = val_17.GetGlyph(index:  val_4 + 4, createIfMissing:  val_11);
            // 0x00BCEB60: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x00BCEB64: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_18 = 1152921504824418304;
            // 0x00BCEB68: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x00BCEB6C: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x00BCEB70: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x00BCEB74: CBZ x0, #0xbcec20          | if (val_12 == null) goto label_15;      
            if(val_12 == null)
            {
                goto label_15;
            }
            // 0x00BCEB78: CBZ x21, #0xbcebbc         | if (val_12 == null) goto label_16;      
            if(val_12 == null)
            {
                goto label_16;
            }
            // 0x00BCEB7C: LDR x22, [x23]             | X22 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x00BCEB80: MOV x0, x21                | X0 = val_12;//m1                        
            // 0x00BCEB84: MOV x1, x22                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCEB88: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x00BCEB8C: CBNZ x0, #0xbcebc0         | if (val_12 != null) goto label_17;      
            if(val_12 != null)
            {
                goto label_17;
            }
            // 0x00BCEB90: LDR x8, [x21]              | X8 = typeof(BMGlyph);                   
            // 0x00BCEB94: MOV x1, x22                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCEB98: LDR x0, [x8, #0x30]        | X0 = BMGlyph.__il2cppRuntimeField_element_class;
            // 0x00BCEB9C: ADD x8, sp, #0x10          | X8 = (1152921510063174944 + 16) = 1152921510063174960 (0x100000014538F530);
            // 0x00BCEBA0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? BMGlyph.__il2cppRuntimeField_element_class, ????);
            // 0x00BCEBA4: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510063163056]
            // 0x00BCEBA8: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BCEBAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCEBB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BCEBB4: ADD x0, sp, #0x10          | X0 = (1152921510063174944 + 16) = 1152921510063174960 (0x100000014538F530);
            // 0x00BCEBB8: BL #0x299a140              | 
            label_16:
            // 0x00BCEBBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014538F530, ????);
            label_17:
            // 0x00BCEBC0: LDR x23, [x23]             | X23 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_18 = null;
            // 0x00BCEBC4: MOV x0, x21                | X0 = val_12;//m1                        
            // 0x00BCEBC8: MOV x1, x23                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_19 = val_18;
            // 0x00BCEBCC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x00BCEBD0: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x00BCEBD4: CBZ x22, #0xbcec94         | if (val_12 == null) goto label_18;      
            if(val_12 == null)
            {
                goto label_18;
            }
            // 0x00BCEBD8: LDR x8, [x22]              | X8 = typeof(BMGlyph);                   
            // 0x00BCEBDC: LDRH w9, [x8, #0x102]      | W9 = BMGlyph.__il2cppRuntimeField_interface_offsets_count;
            // 0x00BCEBE0: CBZ x9, #0xbcec0c          | if (BMGlyph.__il2cppRuntimeField_interface_offsets_count == 0) goto label_19;
            // 0x00BCEBE4: LDR x10, [x8, #0x98]       | X10 = BMGlyph.__il2cppRuntimeField_interfaceOffsets;
            // 0x00BCEBE8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_17 = 0;
            // 0x00BCEBEC: ADD x10, x10, #8           | X10 = (BMGlyph.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504875999240 (0x10000000100AF008);
            label_21:
            // 0x00BCEBF0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00BCEBF4: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x00BCEBF8: B.EQ #0xbcec38             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_18) goto label_20;
            // 0x00BCEBFC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_17 = val_17 + 1;
            // 0x00BCEC00: ADD x10, x10, #0x10        | X10 = (1152921504875999240 + 16) = 1152921504875999256 (0x10000000100AF018);
            // 0x00BCEC04: CMP x11, x9                | STATE = COMPARE((0 + 1), BMGlyph.__il2cppRuntimeField_interface_offsets_count)
            // 0x00BCEC08: B.LO #0xbcebf0             | if (0 < BMGlyph.__il2cppRuntimeField_interface_offsets_count) goto label_21;
            label_19:
            // 0x00BCEC0C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BCEC10: MOV x0, x22                | X0 = val_12;//m1                        
            val_20 = val_12;
            // 0x00BCEC14: MOV x1, x23                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_19 = val_18;
            // 0x00BCEC18: BL #0x2776c24              | X0 = sub_2776C24( ?? val_12, ????);     
            // 0x00BCEC1C: B #0xbcec44                |  goto label_22;                         
            goto label_22;
            label_15:
            // 0x00BCEC20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEC24: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCEC28: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCEC2C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BCEC30: MOV x3, x21                | X3 = val_12;//m1                        
            // 0x00BCEC34: B #0xbcec64                |  goto label_23;                         
            goto label_23;
            label_20:
            // 0x00BCEC38: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00BCEC3C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504875962368 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00BCEC40: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504875962368 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_22:
            // 0x00BCEC44: LDP x8, x1, [x0]           | X8 = typeof(BMGlyph);                    //  | 
            // 0x00BCEC48: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x00BCEC4C: BLR x8                     | X0 = sub_10000000100A6000( ?? val_12, ????);
            // 0x00BCEC50: MOV x3, x0                 | X3 = val_12;//m1                        
            // 0x00BCEC54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEC58: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCEC5C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCEC60: MOV x2, x19                | X2 = X3;//m1                            
            label_23:
            // 0x00BCEC64: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCEC68: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x00BCEC6C: SUB sp, x29, #0x40         | SP = (1152921510063175040 - 64) = 1152921510063174976 (0x100000014538F540);
            // 0x00BCEC70: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCEC74: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCEC78: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCEC7C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCEC80: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCEC84: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCEC88: MOV x19, x0                | X19 = val_15;//m1                       
            val_21 = val_15;
            // 0x00BCEC8C: ADD x0, sp, #8             | X0 = (1152921510063175056 + 8) = 1152921510063175064 (0x100000014538F598);
            // 0x00BCEC90: B #0xbcecc8                |  goto label_25;                         
            goto label_25;
            label_18:
            // 0x00BCEC94: LDR x8, [x21]              | X8 = typeof(BMGlyph);                   
            // 0x00BCEC98: MOV x1, x23                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCEC9C: LDR x0, [x8, #0x30]        | X0 = BMGlyph.__il2cppRuntimeField_element_class;
            // 0x00BCECA0: ADD x8, sp, #0x18          | X8 = (1152921510063174944 + 24) = 1152921510063174968 (0x100000014538F538);
            // 0x00BCECA4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? BMGlyph.__il2cppRuntimeField_element_class, ????);
            // 0x00BCECA8: LDR x0, [sp, #0x18]        | X0 = val_16;                             //  find_add[1152921510063163056]
            // 0x00BCECAC: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x00BCECB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCECB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x00BCECB8: ADD x0, sp, #0x18          | X0 = (1152921510063174944 + 24) = 1152921510063174968 (0x100000014538F538);
            // 0x00BCECBC: BL #0x299a140              | 
            // 0x00BCECC0: MOV x19, x0                | X19 = 1152921510063174968 (0x100000014538F538);//ML01
            val_21;
            // 0x00BCECC4: ADD x0, sp, #0x10          | X0 = (1152921510063174944 + 16) = 1152921510063174960 (0x100000014538F530);
            label_25:
            // 0x00BCECC8: BL #0x299a140              | 
            // 0x00BCECCC: MOV x0, x19                | X0 = 1152921510063174968 (0x100000014538F538);//ML01
            // 0x00BCECD0: BL #0x980800               | X0 = sub_980800( ?? 0x100000014538F538, ????);
            // 0x00BCECD4: MOV x19, x0                | X19 = 1152921510063174968 (0x100000014538F538);//ML01
            // 0x00BCECD8: ADD x0, sp, #0x18          | X0 = (1152921510063174944 + 24) = 1152921510063174968 (0x100000014538F538);
            // 0x00BCECDC: B #0xbcecc8                |  goto label_25;                         
            goto label_25;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCECE0 (12381408), len: 908  VirtAddr: 0x00BCECE0 RVA: 0x00BCECE0 token: 100663875 methodIndex: 29920 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetGlyph_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x00BCECE0: STP x26, x25, [sp, #-0x50]! | stack[1152921510063352512] = ???;  stack[1152921510063352520] = ???;  //  dest_result_addr=1152921510063352512 |  dest_result_addr=1152921510063352520
            // 0x00BCECE4: STP x24, x23, [sp, #0x10]  | stack[1152921510063352528] = ???;  stack[1152921510063352536] = ???;  //  dest_result_addr=1152921510063352528 |  dest_result_addr=1152921510063352536
            // 0x00BCECE8: STP x22, x21, [sp, #0x20]  | stack[1152921510063352544] = ???;  stack[1152921510063352552] = ???;  //  dest_result_addr=1152921510063352544 |  dest_result_addr=1152921510063352552
            // 0x00BCECEC: STP x20, x19, [sp, #0x30]  | stack[1152921510063352560] = ???;  stack[1152921510063352568] = ???;  //  dest_result_addr=1152921510063352560 |  dest_result_addr=1152921510063352568
            // 0x00BCECF0: STP x29, x30, [sp, #0x40]  | stack[1152921510063352576] = ???;  stack[1152921510063352584] = ???;  //  dest_result_addr=1152921510063352576 |  dest_result_addr=1152921510063352584
            // 0x00BCECF4: ADD x29, sp, #0x40         | X29 = (1152921510063352512 + 64) = 1152921510063352576 (0x10000001453BAB00);
            // 0x00BCECF8: SUB sp, sp, #0x20          | SP = (1152921510063352512 - 32) = 1152921510063352480 (0x10000001453BAAA0);
            // 0x00BCECFC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCED00: LDRB w8, [x20, #0xbc9]     | W8 = (bool)static_value_03733BC9;       
            // 0x00BCED04: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BCED08: MOV x23, x2                | X23 = X2;//m1                           
            // 0x00BCED0C: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BCED10: TBNZ w8, #0, #0xbced2c     | if (static_value_03733BC9 == true) goto label_0;
            // 0x00BCED14: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BCED18: LDR x8, [x8, #0x160]       | X8 = 0x2B8F720;                         
            // 0x00BCED1C: LDR w0, [x8]               | W0 = 0x148C;                            
            // 0x00BCED20: BL #0x2782188              | X0 = sub_2782188( ?? 0x148C, ????);     
            // 0x00BCED24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCED28: STRB w8, [x20, #0xbc9]     | static_value_03733BC9 = true;            //  dest_result_addr=57883593
            label_0:
            // 0x00BCED2C: CBNZ x21, #0xbced34        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCED30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x148C, ????);     
            label_1:
            // 0x00BCED34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCED38: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCED3C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCED40: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCED44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCED48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCED4C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCED50: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCED54: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCED58: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCED5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCED60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCED64: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCED68: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCED6C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCED70: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BCED74: CBNZ x22, #0xbced7c        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCED78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCED7C: LDR w22, [x22, #4]         | W22 = val_3 + 4;                        
            // 0x00BCED80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCED84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCED88: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCED8C: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BCED90: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCED94: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCED98: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCED9C: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCEDA0: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x00BCEDA4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCEDA8: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCEDAC: LDR x25, [x9]              | X25 = typeof(BMFont);                   
            // 0x00BCEDB0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCEDB4: TBZ w9, #0, #0xbcedc8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BCEDB8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCEDBC: CBNZ w9, #0xbcedc8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BCEDC0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCEDC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BCEDC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEDCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCEDD0: MOV x1, x25                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCEDD4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCEDD8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCEDDC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCEDE0: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BCEDE4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCEDE8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCEDEC: TBZ w9, #0, #0xbcee00      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BCEDF0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCEDF4: CBNZ w9, #0xbcee00         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BCEDF8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCEDFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BCEE00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEE04: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCEE08: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BCEE0C: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCEE10: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BCEE14: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BCEE18: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCEE1C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCEE20: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BCEE24: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCEE28: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCEE2C: TBZ w9, #0, #0xbcee40      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BCEE30: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCEE34: CBNZ w9, #0xbcee40         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BCEE38: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCEE3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BCEE40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEE44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCEE48: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BCEE4C: MOV x2, x24                | X2 = val_6;//m1                         
            // 0x00BCEE50: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BCEE54: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BCEE58: CBZ x0, #0xbceebc          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BCEE5C: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCEE60: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCEE64: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCEE68: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCEE6C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCEE70: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCEE74: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCEE78: B.LO #0xbcee94             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BCEE7C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCEE80: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCEE84: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCEE88: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCEE8C: MOV x24, x0                | X24 = val_7;//m1                        
            val_15 = val_7;
            // 0x00BCEE90: B.EQ #0xbceebc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BCEE94: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCEE98: ADD x8, sp, #8             | X8 = (1152921510063352480 + 8) = 1152921510063352488 (0x10000001453BAAA8);
            // 0x00BCEE9C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCEEA0: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510063340592]
            // 0x00BCEEA4: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BCEEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCEEAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BCEEB0: ADD x0, sp, #8             | X0 = (1152921510063352480 + 8) = 1152921510063352488 (0x10000001453BAAA8);
            // 0x00BCEEB4: BL #0x299a140              | 
            // 0x00BCEEB8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_11:
            // 0x00BCEEBC: CBNZ x21, #0xbceec4        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BCEEC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001453BAAA8, ????);
            label_12:
            // 0x00BCEEC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCEEC8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCEECC: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00BCEED0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCEED4: CBNZ x24, #0xbceedc        | if (0x0 != 0) goto label_13;            
            if(val_15 != 0)
            {
                goto label_13;
            }
            // 0x00BCEED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BCEEDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCEEE0: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEEE4: MOV w1, w22                | W1 = val_3 + 4;//m1                     
            // 0x00BCEEE8: BL #0xb9259c               | X0 = val_15.GetGlyph(index:  val_3 + 4);
            BMGlyph val_10 = val_15.GetGlyph(index:  val_3 + 4);
            // 0x00BCEEEC: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x00BCEEF0: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_16 = 1152921504824418304;
            // 0x00BCEEF4: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x00BCEEF8: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x00BCEEFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x00BCEF00: CBZ x0, #0xbcefac          | if (val_10 == null) goto label_14;      
            if(val_10 == null)
            {
                goto label_14;
            }
            // 0x00BCEF04: CBZ x21, #0xbcef48         | if (val_10 == null) goto label_15;      
            if(val_10 == null)
            {
                goto label_15;
            }
            // 0x00BCEF08: LDR x22, [x23]             | X22 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x00BCEF0C: MOV x0, x21                | X0 = val_10;//m1                        
            // 0x00BCEF10: MOV x1, x22                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCEF14: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x00BCEF18: CBNZ x0, #0xbcef4c         | if (val_10 != null) goto label_16;      
            if(val_10 != null)
            {
                goto label_16;
            }
            // 0x00BCEF1C: LDR x8, [x21]              | X8 = typeof(BMGlyph);                   
            // 0x00BCEF20: MOV x1, x22                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCEF24: LDR x0, [x8, #0x30]        | X0 = BMGlyph.__il2cppRuntimeField_element_class;
            // 0x00BCEF28: ADD x8, sp, #0x10          | X8 = (1152921510063352480 + 16) = 1152921510063352496 (0x10000001453BAAB0);
            // 0x00BCEF2C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? BMGlyph.__il2cppRuntimeField_element_class, ????);
            // 0x00BCEF30: LDR x0, [sp, #0x10]        | X0 = val_11;                             //  find_add[1152921510063340592]
            // 0x00BCEF34: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x00BCEF38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCEF3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x00BCEF40: ADD x0, sp, #0x10          | X0 = (1152921510063352480 + 16) = 1152921510063352496 (0x10000001453BAAB0);
            // 0x00BCEF44: BL #0x299a140              | 
            label_15:
            // 0x00BCEF48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001453BAAB0, ????);
            label_16:
            // 0x00BCEF4C: LDR x23, [x23]             | X23 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_16 = null;
            // 0x00BCEF50: MOV x0, x21                | X0 = val_10;//m1                        
            // 0x00BCEF54: MOV x1, x23                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_16;
            // 0x00BCEF58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x00BCEF5C: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00BCEF60: CBZ x22, #0xbcf020         | if (val_10 == null) goto label_17;      
            if(val_10 == null)
            {
                goto label_17;
            }
            // 0x00BCEF64: LDR x8, [x22]              | X8 = typeof(BMGlyph);                   
            // 0x00BCEF68: LDRH w9, [x8, #0x102]      | W9 = BMGlyph.__il2cppRuntimeField_interface_offsets_count;
            // 0x00BCEF6C: CBZ x9, #0xbcef98          | if (BMGlyph.__il2cppRuntimeField_interface_offsets_count == 0) goto label_18;
            // 0x00BCEF70: LDR x10, [x8, #0x98]       | X10 = BMGlyph.__il2cppRuntimeField_interfaceOffsets;
            // 0x00BCEF74: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x00BCEF78: ADD x10, x10, #8           | X10 = (BMGlyph.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504875999240 (0x10000000100AF008);
            label_20:
            // 0x00BCEF7C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00BCEF80: CMP x12, x23               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x00BCEF84: B.EQ #0xbcefc4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_16) goto label_19;
            // 0x00BCEF88: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x00BCEF8C: ADD x10, x10, #0x10        | X10 = (1152921504875999240 + 16) = 1152921504875999256 (0x10000000100AF018);
            // 0x00BCEF90: CMP x11, x9                | STATE = COMPARE((0 + 1), BMGlyph.__il2cppRuntimeField_interface_offsets_count)
            // 0x00BCEF94: B.LO #0xbcef7c             | if (0 < BMGlyph.__il2cppRuntimeField_interface_offsets_count) goto label_20;
            label_18:
            // 0x00BCEF98: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BCEF9C: MOV x0, x22                | X0 = val_10;//m1                        
            val_18 = val_10;
            // 0x00BCEFA0: MOV x1, x23                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_17 = val_16;
            // 0x00BCEFA4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_10, ????);     
            // 0x00BCEFA8: B #0xbcefd0                |  goto label_21;                         
            goto label_21;
            label_14:
            // 0x00BCEFAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEFB0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCEFB4: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCEFB8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BCEFBC: MOV x3, x21                | X3 = val_10;//m1                        
            // 0x00BCEFC0: B #0xbceff0                |  goto label_22;                         
            goto label_22;
            label_19:
            // 0x00BCEFC4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00BCEFC8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504875962368 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00BCEFCC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504875962368 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_21:
            // 0x00BCEFD0: LDP x8, x1, [x0]           | X8 = typeof(BMGlyph);                    //  | 
            // 0x00BCEFD4: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x00BCEFD8: BLR x8                     | X0 = sub_10000000100A6000( ?? val_10, ????);
            // 0x00BCEFDC: MOV x3, x0                 | X3 = val_10;//m1                        
            // 0x00BCEFE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCEFE4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCEFE8: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCEFEC: MOV x2, x19                | X2 = X3;//m1                            
            label_22:
            // 0x00BCEFF0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCEFF4: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x00BCEFF8: SUB sp, x29, #0x40         | SP = (1152921510063352576 - 64) = 1152921510063352512 (0x10000001453BAAC0);
            // 0x00BCEFFC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCF000: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCF004: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCF008: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCF00C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCF010: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_13;
            return val_13;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCF014: MOV x19, x0                | X19 = val_13;//m1                       
            val_19 = val_13;
            // 0x00BCF018: ADD x0, sp, #8             | X0 = (1152921510063352592 + 8) = 1152921510063352600 (0x10000001453BAB18);
            // 0x00BCF01C: B #0xbcf054                |  goto label_24;                         
            goto label_24;
            label_17:
            // 0x00BCF020: LDR x8, [x21]              | X8 = typeof(BMGlyph);                   
            // 0x00BCF024: MOV x1, x23                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x00BCF028: LDR x0, [x8, #0x30]        | X0 = BMGlyph.__il2cppRuntimeField_element_class;
            // 0x00BCF02C: ADD x8, sp, #0x18          | X8 = (1152921510063352480 + 24) = 1152921510063352504 (0x10000001453BAAB8);
            // 0x00BCF030: BL #0x27d96d4              | X0 = sub_27D96D4( ?? BMGlyph.__il2cppRuntimeField_element_class, ????);
            // 0x00BCF034: LDR x0, [sp, #0x18]        | X0 = val_14;                             //  find_add[1152921510063340592]
            // 0x00BCF038: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BCF03C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF040: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BCF044: ADD x0, sp, #0x18          | X0 = (1152921510063352480 + 24) = 1152921510063352504 (0x10000001453BAAB8);
            // 0x00BCF048: BL #0x299a140              | 
            // 0x00BCF04C: MOV x19, x0                | X19 = 1152921510063352504 (0x10000001453BAAB8);//ML01
            val_19;
            // 0x00BCF050: ADD x0, sp, #0x10          | X0 = (1152921510063352480 + 16) = 1152921510063352496 (0x10000001453BAAB0);
            label_24:
            // 0x00BCF054: BL #0x299a140              | 
            // 0x00BCF058: MOV x0, x19                | X0 = 1152921510063352504 (0x10000001453BAAB8);//ML01
            // 0x00BCF05C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001453BAAB8, ????);
            // 0x00BCF060: MOV x19, x0                | X19 = 1152921510063352504 (0x10000001453BAAB8);//ML01
            // 0x00BCF064: ADD x0, sp, #0x18          | X0 = (1152921510063352480 + 24) = 1152921510063352504 (0x10000001453BAAB8);
            // 0x00BCF068: B #0xbcf054                |  goto label_24;                         
            goto label_24;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCF06C (12382316), len: 528  VirtAddr: 0x00BCF06C RVA: 0x00BCF06C token: 100663876 methodIndex: 29921 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BCF06C: STP x24, x23, [sp, #-0x40]! | stack[1152921510063525968] = ???;  stack[1152921510063525976] = ???;  //  dest_result_addr=1152921510063525968 |  dest_result_addr=1152921510063525976
            // 0x00BCF070: STP x22, x21, [sp, #0x10]  | stack[1152921510063525984] = ???;  stack[1152921510063525992] = ???;  //  dest_result_addr=1152921510063525984 |  dest_result_addr=1152921510063525992
            // 0x00BCF074: STP x20, x19, [sp, #0x20]  | stack[1152921510063526000] = ???;  stack[1152921510063526008] = ???;  //  dest_result_addr=1152921510063526000 |  dest_result_addr=1152921510063526008
            // 0x00BCF078: STP x29, x30, [sp, #0x30]  | stack[1152921510063526016] = ???;  stack[1152921510063526024] = ???;  //  dest_result_addr=1152921510063526016 |  dest_result_addr=1152921510063526024
            // 0x00BCF07C: ADD x29, sp, #0x30         | X29 = (1152921510063525968 + 48) = 1152921510063526016 (0x10000001453E5080);
            // 0x00BCF080: SUB sp, sp, #0x10          | SP = (1152921510063525968 - 16) = 1152921510063525952 (0x10000001453E5040);
            // 0x00BCF084: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCF088: LDRB w8, [x20, #0xbca]     | W8 = (bool)static_value_03733BCA;       
            // 0x00BCF08C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCF090: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCF094: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCF098: TBNZ w8, #0, #0xbcf0b4     | if (static_value_03733BCA == true) goto label_0;
            // 0x00BCF09C: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BCF0A0: LDR x8, [x8, #0xc20]       | X8 = 0x2B8F6F4;                         
            // 0x00BCF0A4: LDR w0, [x8]               | W0 = 0x1481;                            
            // 0x00BCF0A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1481, ????);     
            // 0x00BCF0AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCF0B0: STRB w8, [x20, #0xbca]     | static_value_03733BCA = true;            //  dest_result_addr=57883594
            label_0:
            // 0x00BCF0B4: CBNZ x19, #0xbcf0bc        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCF0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1481, ????);     
            label_1:
            // 0x00BCF0BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF0C0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCF0C4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCF0C8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCF0CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF0D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF0D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCF0D8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCF0DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF0E0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCF0E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF0E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF0EC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCF0F0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCF0F4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF0F8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCF0FC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCF100: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCF104: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCF108: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCF10C: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCF110: LDR x24, [x9]              | X24 = typeof(BMFont);                   
            // 0x00BCF114: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCF118: TBZ w9, #0, #0xbcf12c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCF11C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF120: CBNZ w9, #0xbcf12c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCF124: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCF128: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCF12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF134: MOV x1, x24                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCF138: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCF13C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCF140: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCF144: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCF148: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCF14C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCF150: TBZ w9, #0, #0xbcf164      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCF154: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF158: CBNZ w9, #0xbcf164         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCF15C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCF160: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCF164: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF168: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCF16C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCF170: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCF174: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCF178: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCF17C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCF180: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCF184: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCF188: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCF18C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCF190: TBZ w9, #0, #0xbcf1a4      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCF194: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF198: CBNZ w9, #0xbcf1a4         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCF19C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCF1A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCF1A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF1A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF1AC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCF1B0: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCF1B4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCF1B8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BCF1BC: CBZ x0, #0xbcf220          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCF1C0: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCF1C4: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCF1C8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCF1CC: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCF1D0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCF1D4: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCF1D8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCF1DC: B.LO #0xbcf1f8             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCF1E0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCF1E4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCF1E8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCF1EC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCF1F0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BCF1F4: B.EQ #0xbcf220             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCF1F8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCF1FC: ADD x8, sp, #8             | X8 = (1152921510063525952 + 8) = 1152921510063525960 (0x10000001453E5048);
            // 0x00BCF200: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCF204: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510063514032]
            // 0x00BCF208: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCF20C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF210: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCF214: ADD x0, sp, #8             | X0 = (1152921510063525952 + 8) = 1152921510063525960 (0x10000001453E5048);
            // 0x00BCF218: BL #0x299a140              | 
            // 0x00BCF21C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BCF220: CBNZ x19, #0xbcf228        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCF224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001453E5048, ????);
            label_11:
            // 0x00BCF228: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF22C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCF230: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCF234: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCF238: CBNZ x22, #0xbcf240        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BCF23C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCF240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF244: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF248: BL #0xb925a4               | val_9.Clear();                          
            val_9.Clear();
            // 0x00BCF24C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCF250: SUB sp, x29, #0x30         | SP = (1152921510063526016 - 48) = 1152921510063525968 (0x10000001453E5050);
            // 0x00BCF254: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCF258: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCF25C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCF260: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BCF264: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCF268: MOV x19, x0                | 
            // 0x00BCF26C: ADD x0, sp, #8             | 
            // 0x00BCF270: BL #0x299a140              | 
            // 0x00BCF274: MOV x0, x19                | 
            // 0x00BCF278: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCF27C (12382844), len: 704  VirtAddr: 0x00BCF27C RVA: 0x00BCF27C token: 100663877 methodIndex: 29922 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Trim_16(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00BCF27C: STP x28, x27, [sp, #-0x60]! | stack[1152921510063695280] = ???;  stack[1152921510063695288] = ???;  //  dest_result_addr=1152921510063695280 |  dest_result_addr=1152921510063695288
            // 0x00BCF280: STP x26, x25, [sp, #0x10]  | stack[1152921510063695296] = ???;  stack[1152921510063695304] = ???;  //  dest_result_addr=1152921510063695296 |  dest_result_addr=1152921510063695304
            // 0x00BCF284: STP x24, x23, [sp, #0x20]  | stack[1152921510063695312] = ???;  stack[1152921510063695320] = ???;  //  dest_result_addr=1152921510063695312 |  dest_result_addr=1152921510063695320
            // 0x00BCF288: STP x22, x21, [sp, #0x30]  | stack[1152921510063695328] = ???;  stack[1152921510063695336] = ???;  //  dest_result_addr=1152921510063695328 |  dest_result_addr=1152921510063695336
            // 0x00BCF28C: STP x20, x19, [sp, #0x40]  | stack[1152921510063695344] = ???;  stack[1152921510063695352] = ???;  //  dest_result_addr=1152921510063695344 |  dest_result_addr=1152921510063695352
            // 0x00BCF290: STP x29, x30, [sp, #0x50]  | stack[1152921510063695360] = ???;  stack[1152921510063695368] = ???;  //  dest_result_addr=1152921510063695360 |  dest_result_addr=1152921510063695368
            // 0x00BCF294: ADD x29, sp, #0x50         | X29 = (1152921510063695280 + 80) = 1152921510063695360 (0x100000014540E600);
            // 0x00BCF298: SUB sp, sp, #0x10          | SP = (1152921510063695280 - 16) = 1152921510063695264 (0x100000014540E5A0);
            // 0x00BCF29C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCF2A0: LDRB w8, [x20, #0xbcb]     | W8 = (bool)static_value_03733BCB;       
            // 0x00BCF2A4: MOV x25, x3                | X25 = X3;//m1                           
            // 0x00BCF2A8: MOV x26, x2                | X26 = X2;//m1                           
            // 0x00BCF2AC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCF2B0: TBNZ w8, #0, #0xbcf2cc     | if (static_value_03733BCB == true) goto label_0;
            // 0x00BCF2B4: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x00BCF2B8: LDR x8, [x8, #0xec8]       | X8 = 0x2B8F73C;                         
            // 0x00BCF2BC: LDR w0, [x8]               | W0 = 0x1493;                            
            // 0x00BCF2C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1493, ????);     
            // 0x00BCF2C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCF2C8: STRB w8, [x20, #0xbcb]     | static_value_03733BCB = true;            //  dest_result_addr=57883595
            label_0:
            // 0x00BCF2CC: CBNZ x19, #0xbcf2d4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCF2D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1493, ????);     
            label_1:
            // 0x00BCF2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF2D8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCF2DC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCF2E0: MOV x27, x0                | X27 = val_1;//m1                        
            // 0x00BCF2E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF2E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF2EC: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BCF2F0: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BCF2F4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF2F8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCF2FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF300: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF304: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCF308: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BCF30C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF310: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCF314: CBNZ x21, #0xbcf31c        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCF318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCF31C: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BCF320: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF324: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF328: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCF32C: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BCF330: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF334: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCF338: CBNZ x22, #0xbcf340        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BCF33C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BCF340: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x00BCF344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF348: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF34C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BCF350: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BCF354: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF358: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BCF35C: CBNZ x23, #0xbcf364        | if (val_5 != 0) goto label_4;           
            if(val_5 != 0)
            {
                goto label_4;
            }
            // 0x00BCF360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x00BCF364: LDR w23, [x23, #4]         | W23 = val_5 + 4;                        
            // 0x00BCF368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF36C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF370: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BCF374: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BCF378: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_6 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF37C: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BCF380: CBNZ x24, #0xbcf388        | if (val_6 != 0) goto label_5;           
            if(val_6 != 0)
            {
                goto label_5;
            }
            // 0x00BCF384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_5:
            // 0x00BCF388: LDR w24, [x24, #4]         | W24 = val_6 + 4;                        
            // 0x00BCF38C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF390: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF394: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BCF398: MOV x1, x26                | X1 = X2;//m1                            
            // 0x00BCF39C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCF3A0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCF3A4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCF3A8: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BCF3AC: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x00BCF3B0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCF3B4: LDR x9, [x9, #0x778]       | X9 = 1152921504875909120;               
            // 0x00BCF3B8: LDR x28, [x9]              | X28 = typeof(BMFont);                   
            // 0x00BCF3BC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCF3C0: TBZ w9, #0, #0xbcf3d4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCF3C4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF3C8: CBNZ w9, #0xbcf3d4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCF3CC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCF3D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x00BCF3D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF3D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF3DC: MOV x1, x28                | X1 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCF3E0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCF3E4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCF3E8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCF3EC: MOV x28, x0                | X28 = val_8;//m1                        
            // 0x00BCF3F0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCF3F4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCF3F8: TBZ w9, #0, #0xbcf40c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BCF3FC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF400: CBNZ w9, #0xbcf40c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BCF404: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCF408: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x00BCF40C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF410: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCF414: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x00BCF418: MOV x2, x27                | X2 = val_1;//m1                         
            // 0x00BCF41C: MOV x3, x25                | X3 = X3;//m1                            
            // 0x00BCF420: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCF424: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCF428: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCF42C: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BCF430: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCF434: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCF438: TBZ w9, #0, #0xbcf44c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00BCF43C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCF440: CBNZ w9, #0xbcf44c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00BCF444: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCF448: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_11:
            // 0x00BCF44C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF450: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF454: MOV x1, x28                | X1 = val_8;//m1                         
            // 0x00BCF458: MOV x2, x25                | X2 = val_9;//m1                         
            // 0x00BCF45C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BCF460: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BCF464: CBZ x0, #0xbcf4c8          | if (val_10 == null) goto label_14;      
            if(val_10 == null)
            {
                goto label_14;
            }
            // 0x00BCF468: ADRP x9, #0x35c4000        | X9 = 56377344 (0x35C4000);              
            // 0x00BCF46C: LDR x9, [x9, #0xe28]       | X9 = 1152921504875909120;               
            // 0x00BCF470: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCF474: LDR x1, [x9]               | X1 = typeof(BMFont);                    
            // 0x00BCF478: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCF47C: LDRB w9, [x1, #0x104]      | W9 = BMFont.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCF480: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMFont.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCF484: B.LO #0xbcf4a0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMFont.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BCF488: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCF48C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyD
            // 0x00BCF490: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCF494: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMFont))
            // 0x00BCF498: MOV x25, x0                | X25 = val_10;//m1                       
            val_13 = val_10;
            // 0x00BCF49C: B.EQ #0xbcf4c8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMFont.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BCF4A0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCF4A4: ADD x8, sp, #8             | X8 = (1152921510063695264 + 8) = 1152921510063695272 (0x100000014540E5A8);
            // 0x00BCF4A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCF4AC: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510063683376]
            // 0x00BCF4B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BCF4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF4B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BCF4BC: ADD x0, sp, #8             | X0 = (1152921510063695264 + 8) = 1152921510063695272 (0x100000014540E5A8);
            // 0x00BCF4C0: BL #0x299a140              | 
            // 0x00BCF4C4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_14:
            // 0x00BCF4C8: CBNZ x19, #0xbcf4d0        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BCF4CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014540E5A8, ????);
            label_15:
            // 0x00BCF4D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCF4D4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCF4D8: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x00BCF4DC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCF4E0: CBNZ x25, #0xbcf4e8        | if (0x0 != 0) goto label_16;            
            if(val_13 != 0)
            {
                goto label_16;
            }
            // 0x00BCF4E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BCF4E8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCF4EC: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF4F0: MOV w1, w24                | W1 = val_6 + 4;//m1                     
            // 0x00BCF4F4: MOV w2, w23                | W2 = val_5 + 4;//m1                     
            // 0x00BCF4F8: MOV w3, w22                | W3 = val_4 + 4;//m1                     
            // 0x00BCF4FC: MOV w4, w21                | W4 = val_3 + 4;//m1                     
            // 0x00BCF500: BL #0xb92620               | val_13.Trim(xMin:  val_6 + 4, yMin:  val_5 + 4, xMax:  val_4 + 4, yMax:  val_3 + 4);
            val_13.Trim(xMin:  val_6 + 4, yMin:  val_5 + 4, xMax:  val_4 + 4, yMax:  val_3 + 4);
            // 0x00BCF504: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCF508: SUB sp, x29, #0x50         | SP = (1152921510063695360 - 80) = 1152921510063695280 (0x100000014540E5B0);
            // 0x00BCF50C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCF510: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCF514: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCF518: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCF51C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BCF520: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BCF524: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCF528: MOV x19, x0                | 
            // 0x00BCF52C: ADD x0, sp, #8             | 
            // 0x00BCF530: BL #0x299a140              | 
            // 0x00BCF534: MOV x0, x19                | 
            // 0x00BCF538: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCF53C (12383548), len: 180  VirtAddr: 0x00BCF53C RVA: 0x00BCF53C token: 100663878 methodIndex: 29923 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BCF53C: STP x22, x21, [sp, #-0x30]! | stack[1152921510063852384] = ???;  stack[1152921510063852392] = ???;  //  dest_result_addr=1152921510063852384 |  dest_result_addr=1152921510063852392
            // 0x00BCF540: STP x20, x19, [sp, #0x10]  | stack[1152921510063852400] = ???;  stack[1152921510063852408] = ???;  //  dest_result_addr=1152921510063852400 |  dest_result_addr=1152921510063852408
            // 0x00BCF544: STP x29, x30, [sp, #0x20]  | stack[1152921510063852416] = ???;  stack[1152921510063852424] = ???;  //  dest_result_addr=1152921510063852416 |  dest_result_addr=1152921510063852424
            // 0x00BCF548: ADD x29, sp, #0x20         | X29 = (1152921510063852384 + 32) = 1152921510063852416 (0x1000000145434B80);
            // 0x00BCF54C: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BCF550: LDRB w8, [x22, #0xbcc]     | W8 = (bool)static_value_03733BCC;       
            // 0x00BCF554: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BCF558: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BCF55C: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BCF560: TBNZ w8, #0, #0xbcf57c     | if (static_value_03733BCC == true) goto label_0;
            // 0x00BCF564: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00BCF568: LDR x8, [x8, #0xd78]       | X8 = 0x2B8F6F8;                         
            // 0x00BCF56C: LDR w0, [x8]               | W0 = 0x1482;                            
            // 0x00BCF570: BL #0x2782188              | X0 = sub_2782188( ?? 0x1482, ????);     
            // 0x00BCF574: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCF578: STRB w8, [x22, #0xbcc]     | static_value_03733BCC = true;            //  dest_result_addr=57883596
            label_0:
            // 0x00BCF57C: CBNZ x21, #0xbcf584        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCF580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1482, ????);     
            label_1:
            // 0x00BCF584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF588: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BCF58C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCF590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF594: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BCF598: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BCF59C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCF5A0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BCF5A4: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BCF5A8: LDR x8, [x8, #0xe28]       | X8 = 1152921504875909120;               
            // 0x00BCF5AC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCF5B0: LDR x8, [x8]               | X8 = typeof(BMFont);                    
            // 0x00BCF5B4: MOV x0, x8                 | X0 = 1152921504875909120 (0x1000000010099000);//ML01
            BMFont val_3 = null;
            // 0x00BCF5B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMFont), ????);
            // 0x00BCF5BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF5C0: MOV x21, x0                | X21 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCF5C4: BL #0xb921cc               | .ctor();                                
            val_3 = new BMFont();
            // 0x00BCF5C8: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BCF5CC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BCF5D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCF5D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCF5D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCF5DC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BCF5E0: MOV x3, x21                | X3 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCF5E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCF5E8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BCF5EC: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCF5F0 (12383728), len: 92  VirtAddr: 0x00BCF5F0 RVA: 0x00BCF5F0 token: 100663879 methodIndex: 29924 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BCF5F0: STP x20, x19, [sp, #-0x20]! | stack[1152921510063980784] = ???;  stack[1152921510063980792] = ???;  //  dest_result_addr=1152921510063980784 |  dest_result_addr=1152921510063980792
            // 0x00BCF5F4: STP x29, x30, [sp, #0x10]  | stack[1152921510063980800] = ???;  stack[1152921510063980808] = ???;  //  dest_result_addr=1152921510063980800 |  dest_result_addr=1152921510063980808
            // 0x00BCF5F8: ADD x29, sp, #0x10         | X29 = (1152921510063980784 + 16) = 1152921510063980800 (0x1000000145454100);
            // 0x00BCF5FC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCF600: LDRB w8, [x19, #0xbcd]     | W8 = (bool)static_value_03733BCD;       
            // 0x00BCF604: TBNZ w8, #0, #0xbcf620     | if (static_value_03733BCD == true) goto label_0;
            // 0x00BCF608: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BCF60C: LDR x8, [x8, #0x608]       | X8 = 0x2B8F740;                         
            // 0x00BCF610: LDR w0, [x8]               | W0 = 0x1494;                            
            // 0x00BCF614: BL #0x2782188              | X0 = sub_2782188( ?? 0x1494, ????);     
            // 0x00BCF618: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCF61C: STRB w8, [x19, #0xbcd]     | static_value_03733BCD = true;            //  dest_result_addr=57883597
            label_0:
            // 0x00BCF620: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BCF624: LDR x8, [x8, #0xe28]       | X8 = 1152921504875909120;               
            // 0x00BCF628: LDR x0, [x8]               | X0 = typeof(BMFont);                    
            BMFont val_1 = null;
            // 0x00BCF62C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMFont), ????);
            // 0x00BCF630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCF634: MOV x19, x0                | X19 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCF638: BL #0xb921cc               | .ctor();                                
            val_1 = new BMFont();
            // 0x00BCF63C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCF640: MOV x0, x19                | X0 = 1152921504875909120 (0x1000000010099000);//ML01
            // 0x00BCF644: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BCF648: RET                        |  return (System.Object)typeof(BMFont);  
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCF64C (12383820), len: 92  VirtAddr: 0x00BCF64C RVA: 0x00BCF64C token: 100663880 methodIndex: 29925 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BCF64C: STP x20, x19, [sp, #-0x20]! | stack[1152921510064096880] = ???;  stack[1152921510064096888] = ???;  //  dest_result_addr=1152921510064096880 |  dest_result_addr=1152921510064096888
            // 0x00BCF650: STP x29, x30, [sp, #0x10]  | stack[1152921510064096896] = ???;  stack[1152921510064096904] = ???;  //  dest_result_addr=1152921510064096896 |  dest_result_addr=1152921510064096904
            // 0x00BCF654: ADD x29, sp, #0x10         | X29 = (1152921510064096880 + 16) = 1152921510064096896 (0x1000000145470680);
            // 0x00BCF658: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCF65C: LDRB w8, [x20, #0xbce]     | W8 = (bool)static_value_03733BCE;       
            // 0x00BCF660: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BCF664: TBNZ w8, #0, #0xbcf680     | if (static_value_03733BCE == true) goto label_0;
            // 0x00BCF668: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BCF66C: LDR x8, [x8, #0x5e0]       | X8 = 0x2B8F744;                         
            // 0x00BCF670: LDR w0, [x8]               | W0 = 0x1495;                            
            // 0x00BCF674: BL #0x2782188              | X0 = sub_2782188( ?? 0x1495, ????);     
            // 0x00BCF678: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCF67C: STRB w8, [x20, #0xbce]     | static_value_03733BCE = true;            //  dest_result_addr=57883598
            label_0:
            // 0x00BCF680: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00BCF684: LDR x8, [x8, #0x420]       | X8 = 1152921510064080816;               
            // 0x00BCF688: LDR x20, [x8]              | X20 = typeof(BMFont[]);                 
            // 0x00BCF68C: MOV x0, x20                | X0 = 1152921510064080816 (0x100000014546C7B0);//ML01
            // 0x00BCF690: BL #0x277461c              | X0 = sub_277461C( ?? typeof(BMFont[]), ????);
            // 0x00BCF694: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCF698: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BCF69C: MOV x0, x20                | X0 = 1152921510064080816 (0x100000014546C7B0);//ML01
            // 0x00BCF6A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BCF6A4: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(BMFont[]), ????);
        
        }
    
    }

}
