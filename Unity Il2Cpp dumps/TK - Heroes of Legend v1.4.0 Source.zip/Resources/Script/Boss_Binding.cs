using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class Boss_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BD5614 (12408340), len: 8  VirtAddr: 0x00BD5614 RVA: 0x00BD5614 token: 100663927 methodIndex: 29972 delegateWrapperIndex: 0 methodInvoker: 0
        public Boss_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BD5614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5618: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD561C (12408348), len: 852  VirtAddr: 0x00BD561C RVA: 0x00BD561C token: 100663928 methodIndex: 29973 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_9;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_10;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_11;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_12;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13;
            // 0x00BD561C: STP x24, x23, [sp, #-0x40]! | stack[1152921510070909792] = ???;  stack[1152921510070909800] = ???;  //  dest_result_addr=1152921510070909792 |  dest_result_addr=1152921510070909800
            // 0x00BD5620: STP x22, x21, [sp, #0x10]  | stack[1152921510070909808] = ???;  stack[1152921510070909816] = ???;  //  dest_result_addr=1152921510070909808 |  dest_result_addr=1152921510070909816
            // 0x00BD5624: STP x20, x19, [sp, #0x20]  | stack[1152921510070909824] = ???;  stack[1152921510070909832] = ???;  //  dest_result_addr=1152921510070909824 |  dest_result_addr=1152921510070909832
            // 0x00BD5628: STP x29, x30, [sp, #0x30]  | stack[1152921510070909840] = ???;  stack[1152921510070909848] = ???;  //  dest_result_addr=1152921510070909840 |  dest_result_addr=1152921510070909848
            // 0x00BD562C: ADD x29, sp, #0x30         | X29 = (1152921510070909792 + 48) = 1152921510070909840 (0x1000000145AEFB90);
            // 0x00BD5630: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD5634: LDRB w8, [x20, #0xbfb]     | W8 = (bool)static_value_03733BFB;       
            // 0x00BD5638: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD563C: TBNZ w8, #0, #0xbd5658     | if (static_value_03733BFB == true) goto label_0;
            // 0x00BD5640: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD5644: LDR x8, [x8, #0xe28]       | X8 = 0x2B8F89C;                         
            // 0x00BD5648: LDR w0, [x8]               | W0 = 0x14EB;                            
            // 0x00BD564C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14EB, ????);     
            // 0x00BD5650: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5654: STRB w8, [x20, #0xbfb]     | static_value_03733BFB = true;            //  dest_result_addr=57883643
            label_0:
            // 0x00BD5658: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD565C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD5660: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BD5664: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00BD5668: LDR x8, [x8, #0xdd8]       | X8 = 1152921504893960192;               
            // 0x00BD566C: LDR x20, [x8]              | X20 = typeof(Boss);                     
            // 0x00BD5670: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD5674: TBZ w8, #0, #0xbd5684      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BD5678: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD567C: CBNZ w8, #0xbd5684         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BD5680: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BD5684: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD5688: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD568C: MOV x1, x20                | X1 = 1152921504893960192 (0x10000000111D0000);//ML01
            // 0x00BD5690: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD5694: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BD5698: CBNZ x20, #0xbd56a0        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BD569C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00BD56A0: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x00BD56A4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD56A8: LDR x9, [x9, #0xd98]       | X9 = (string**)(1152921510070888544)("IsShowHp");
            // 0x00BD56AC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD56B0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD56B4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD56B8: LDR x1, [x9]               | X1 = "IsShowHp";                        
            // 0x00BD56BC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD56C0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD56C4: ADRP x24, #0x3664000       | X24 = 57032704 (0x3664000);             
            // 0x00BD56C8: LDR x24, [x24, #0x3d0]     | X24 = 1152921504783310848;              
            // 0x00BD56CC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD56D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD56D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD56D8: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache0;
            val_8 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache0;
            // 0x00BD56DC: CBNZ x22, #0xbd5728        | if (ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_8 != null)
            {
                goto label_4;
            }
            // 0x00BD56E0: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BD56E4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD56E8: LDR x8, [x8, #0xd70]       | X8 = 1152921510070888640;               
            // 0x00BD56EC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD56F0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.Boss_Binding::get_IsShowHp_0(ref object o);
            // 0x00BD56F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x00BD56F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD56FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5700: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5704: MOV x2, x22                | X2 = 1152921510070888640 (0x1000000145AEA8C0);//ML01
            // 0x00BD5708: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_9 = val_2;
            // 0x00BD570C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::get_IsShowHp_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::get_IsShowHp_0(ref object o));
            // 0x00BD5710: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5714: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5718: STR x23, [x8]              | ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783314944
            ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache0 = val_9;
            // 0x00BD571C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5720: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5724: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_8 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BD5728: CBNZ x19, #0xbd5730        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BD572C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::get_IsShowHp_0(ref object o)), ????);
            label_5:
            // 0x00BD5730: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5734: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD5738: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD573C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD5740: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_8);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_8);
            // 0x00BD5744: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5748: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD574C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache1;
            val_10 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache1;
            // 0x00BD5750: CBNZ x22, #0xbd579c        | if (ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_10 != null)
            {
                goto label_6;
            }
            // 0x00BD5754: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BD5758: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD575C: LDR x8, [x8, #0x788]       | X8 = 1152921510070889664;               
            // 0x00BD5760: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD5764: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.Boss_Binding::set_IsShowHp_0(ref object o, object v);
            // 0x00BD5768: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x00BD576C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD5770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5774: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5778: MOV x2, x22                | X2 = 1152921510070889664 (0x1000000145AEACC0);//ML01
            // 0x00BD577C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_9 = val_3;
            // 0x00BD5780: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.Boss_Binding::set_IsShowHp_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.Boss_Binding::set_IsShowHp_0(ref object o, object v));
            // 0x00BD5784: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5788: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD578C: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783314952
            ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache1 = val_9;
            // 0x00BD5790: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5794: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5798: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_10 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache1;
            label_6:
            // 0x00BD579C: CBNZ x19, #0xbd57a4        | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x00BD57A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.Boss_Binding::set_IsShowHp_0(ref object o, object v)), ????);
            label_7:
            // 0x00BD57A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD57A8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD57AC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD57B0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD57B4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            // 0x00BD57B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD57BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD57C0: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache0;
            val_11 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache0;
            // 0x00BD57C4: CBNZ x21, #0xbd5810        | if (ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache0 != null) goto label_8;
            if(val_11 != null)
            {
                goto label_8;
            }
            // 0x00BD57C8: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00BD57CC: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BD57D0: LDR x8, [x8, #0x3f0]       | X8 = 1152921510070890688;               
            // 0x00BD57D4: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BD57D8: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__0();
            // 0x00BD57DC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_4 = null;
            // 0x00BD57E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BD57E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD57E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD57EC: MOV x2, x21                | X2 = 1152921510070890688 (0x1000000145AEB0C0);//ML01
            // 0x00BD57F0: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BD57F4: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__0());
            val_4 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__0());
            // 0x00BD57F8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD57FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5800: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504783314968
            ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache0 = val_4;
            // 0x00BD5804: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5808: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD580C: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_11 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache0;
            label_8:
            // 0x00BD5810: CBNZ x19, #0xbd5818        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00BD5814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__0()), ????);
            label_9:
            // 0x00BD5818: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD581C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD5820: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BD5824: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BD5828: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            // 0x00BD582C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5830: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5834: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache1;
            val_12 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache1;
            // 0x00BD5838: CBNZ x21, #0xbd5884        | if (ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache1 != null) goto label_10;
            if(val_12 != null)
            {
                goto label_10;
            }
            // 0x00BD583C: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BD5840: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BD5844: LDR x8, [x8, #0x800]       | X8 = 1152921510070891712;               
            // 0x00BD5848: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BD584C: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__1(int s);
            // 0x00BD5850: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_5 = null;
            // 0x00BD5854: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BD5858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD585C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5860: MOV x2, x21                | X2 = 1152921510070891712 (0x1000000145AEB4C0);//ML01
            // 0x00BD5864: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BD5868: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__1(int s));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__1(int s));
            // 0x00BD586C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5870: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5874: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504783314976
            ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache1 = val_5;
            // 0x00BD5878: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD587C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5880: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_12 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__am$cache1;
            label_10:
            // 0x00BD5884: CBNZ x19, #0xbd588c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD5888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Boss_Binding::<Register>m__1(int s)), ????);
            label_11:
            // 0x00BD588C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5890: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD5894: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BD5898: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BD589C: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            // 0x00BD58A0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BD58A4: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00BD58A8: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x00BD58AC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD58B0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD58B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD58B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD58BC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD58C0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD58C4: CBNZ x20, #0xbd58cc        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BD58C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x00BD58CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD58D0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD58D4: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BD58D8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD58DC: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD58E0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD58E4: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_6 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD58E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD58EC: MOV x20, x0                | X20 = val_6;//m1                        
            // 0x00BD58F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD58F4: LDR x21, [x8, #0x10]       | X21 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache2;
            val_13 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache2;
            // 0x00BD58F8: CBNZ x21, #0xbd5944        | if (ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache2 != null) goto label_13;
            if(val_13 != null)
            {
                goto label_13;
            }
            // 0x00BD58FC: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x00BD5900: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD5904: LDR x8, [x8, #0xdf0]       | X8 = 1152921510070896832;               
            // 0x00BD5908: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD590C: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Boss_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD5910: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BD5914: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD5918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD591C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5920: MOV x2, x21                | X2 = 1152921510070896832 (0x1000000145AEC8C0);//ML01
            // 0x00BD5924: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD5928: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Boss_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Boss_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD592C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD5930: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5934: STR x22, [x8, #0x10]       | ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783314960
            ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache2 = val_7;
            // 0x00BD5938: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Boss_Binding);
            // 0x00BD593C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Boss_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD5940: LDR x21, [x8, #0x10]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_13 = ILRuntime.Runtime.Generated.Boss_Binding.<>f__mg$cache2;
            label_13:
            // 0x00BD5944: CBNZ x19, #0xbd594c        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BD5948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Boss_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x00BD594C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD5950: MOV x1, x20                | X1 = val_6;//m1                         
            // 0x00BD5954: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD5958: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD595C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5960: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD5964: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5968: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BD596C: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_13); return;
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_13);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5970 (12409200), len: 312  VirtAddr: 0x00BD5970 RVA: 0x00BD5970 token: 100663929 methodIndex: 29974 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_IsShowHp_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD5970: STP x20, x19, [sp, #-0x20]! | stack[1152921510071042224] = ???;  stack[1152921510071042232] = ???;  //  dest_result_addr=1152921510071042224 |  dest_result_addr=1152921510071042232
            // 0x00BD5974: STP x29, x30, [sp, #0x10]  | stack[1152921510071042240] = ???;  stack[1152921510071042248] = ???;  //  dest_result_addr=1152921510071042240 |  dest_result_addr=1152921510071042248
            // 0x00BD5978: ADD x29, sp, #0x10         | X29 = (1152921510071042224 + 16) = 1152921510071042240 (0x1000000145B100C0);
            // 0x00BD597C: SUB sp, sp, #0x20          | SP = (1152921510071042224 - 32) = 1152921510071042192 (0x1000000145B10090);
            // 0x00BD5980: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD5984: LDRB w8, [x20, #0xbfc]     | W8 = (bool)static_value_03733BFC;       
            // 0x00BD5988: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD598C: TBNZ w8, #0, #0xbd59a8     | if (static_value_03733BFC == true) goto label_0;
            // 0x00BD5990: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00BD5994: LDR x8, [x8, #0xcd0]       | X8 = 0x2B8F898;                         
            // 0x00BD5998: LDR w0, [x8]               | W0 = 0x14EA;                            
            // 0x00BD599C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14EA, ????);     
            // 0x00BD59A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD59A4: STRB w8, [x20, #0xbfc]     | static_value_03733BFC = true;            //  dest_result_addr=57883644
            label_0:
            // 0x00BD59A8: ADRP x20, #0x3641000       | X20 = 56889344 (0x3641000);             
            // 0x00BD59AC: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD59B0: LDR x20, [x20, #0xe8]      | X20 = 1152921504893960192;              
            // 0x00BD59B4: CBZ x19, #0xbd5a08         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD59B8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD59BC: LDR x1, [x20]              | X1 = typeof(Boss);                      
            // 0x00BD59C0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD59C4: LDRB w9, [x1, #0x104]      | W9 = Boss.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD59C8: CMP w10, w9                | STATE = COMPARE(X1 + 260, Boss.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD59CC: B.LO #0xbd59e4             | if (X1 + 260 < Boss.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD59D0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD59D4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD59D8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD59DC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Boss))
            // 0x00BD59E0: B.EQ #0xbd5a0c             | if ((X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD59E4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD59E8: ADD x8, sp, #0x10          | X8 = (1152921510071042192 + 16) = 1152921510071042208 (0x1000000145B100A0);
            // 0x00BD59EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD59F0: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510071030256]
            // 0x00BD59F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD59F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD59FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD5A00: ADD x0, sp, #0x10          | X0 = (1152921510071042192 + 16) = 1152921510071042208 (0x1000000145B100A0);
            // 0x00BD5A04: BL #0x299a140              | 
            label_1:
            // 0x00BD5A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145B100A0, ????);
            label_3:
            // 0x00BD5A0C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD5A10: LDR x1, [x20]              | X1 = typeof(Boss);                      
            // 0x00BD5A14: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD5A18: LDRB w9, [x1, #0x104]      | W9 = Boss.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD5A1C: CMP w10, w9                | STATE = COMPARE(X1 + 260, Boss.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD5A20: B.LO #0xbd5a64             | if (X1 + 260 < Boss.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD5A24: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD5A28: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD5A2C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD5A30: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Boss))
            // 0x00BD5A34: B.NE #0xbd5a64             | if ((X1 + 176 + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD5A38: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x00BD5A3C: LDRB w8, [x19, #0x638]     | W8 = X1 + 1592;                         
            // 0x00BD5A40: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x00BD5A44: ADD x1, sp, #0xf           | X1 = (1152921510071042192 + 15) = 1152921510071042207 (0x1000000145B1009F);
            // 0x00BD5A48: STRB w8, [sp, #0xf]        | stack[1152921510071042207] = X1 + 1592;  //  dest_result_addr=1152921510071042207
            // 0x00BD5A4C: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x00BD5A50: BL #0x27bc028              | X0 = 1152921510071090272 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 1592);
            // 0x00BD5A54: SUB sp, x29, #0x10         | SP = (1152921510071042240 - 16) = 1152921510071042224 (0x1000000145B100B0);
            // 0x00BD5A58: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5A5C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5A60: RET                        |  return (System.Object)X1 + 1592;       
            return (object)X1 + 1592;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD5A64: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD5A68: ADD x8, sp, #0x18          | X8 = (1152921510071042192 + 24) = 1152921510071042216 (0x1000000145B100A8);
            // 0x00BD5A6C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD5A70: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510071030256]
            // 0x00BD5A74: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD5A78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5A7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD5A80: ADD x0, sp, #0x18          | X0 = (1152921510071042192 + 24) = 1152921510071042216 (0x1000000145B100A8);
            // 0x00BD5A84: BL #0x299a140              | 
            // 0x00BD5A88: MOV x19, x0                | X19 = 1152921510071042216 (0x1000000145B100A8);//ML01
            // 0x00BD5A8C: ADD x0, sp, #0x10          | X0 = (1152921510071042192 + 16) = 1152921510071042208 (0x1000000145B100A0);
            label_6:
            // 0x00BD5A90: BL #0x299a140              | 
            // 0x00BD5A94: MOV x0, x19                | X0 = 1152921510071042216 (0x1000000145B100A8);//ML01
            // 0x00BD5A98: BL #0x980800               | X0 = sub_980800( ?? 0x1000000145B100A8, ????);
            // 0x00BD5A9C: MOV x19, x0                | X19 = 1152921510071042216 (0x1000000145B100A8);//ML01
            // 0x00BD5AA0: ADD x0, sp, #0x18          | X0 = (1152921510071042192 + 24) = 1152921510071042216 (0x1000000145B100A8);
            // 0x00BD5AA4: B #0xbd5a90                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5AA8 (12409512), len: 412  VirtAddr: 0x00BD5AA8 RVA: 0x00BD5AA8 token: 100663930 methodIndex: 29975 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_IsShowHp_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD5AA8: STP x22, x21, [sp, #-0x30]! | stack[1152921510071170432] = ???;  stack[1152921510071170440] = ???;  //  dest_result_addr=1152921510071170432 |  dest_result_addr=1152921510071170440
            // 0x00BD5AAC: STP x20, x19, [sp, #0x10]  | stack[1152921510071170448] = ???;  stack[1152921510071170456] = ???;  //  dest_result_addr=1152921510071170448 |  dest_result_addr=1152921510071170456
            // 0x00BD5AB0: STP x29, x30, [sp, #0x20]  | stack[1152921510071170464] = ???;  stack[1152921510071170472] = ???;  //  dest_result_addr=1152921510071170464 |  dest_result_addr=1152921510071170472
            // 0x00BD5AB4: ADD x29, sp, #0x20         | X29 = (1152921510071170432 + 32) = 1152921510071170464 (0x1000000145B2F5A0);
            // 0x00BD5AB8: SUB sp, sp, #0x20          | SP = (1152921510071170432 - 32) = 1152921510071170400 (0x1000000145B2F560);
            // 0x00BD5ABC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD5AC0: LDRB w8, [x21, #0xbfd]     | W8 = (bool)static_value_03733BFD;       
            // 0x00BD5AC4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BD5AC8: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD5ACC: TBNZ w8, #0, #0xbd5ae8     | if (static_value_03733BFD == true) goto label_0;
            // 0x00BD5AD0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00BD5AD4: LDR x8, [x8, #0xe0]        | X8 = 0x2B8F8A0;                         
            // 0x00BD5AD8: LDR w0, [x8]               | W0 = 0x14EC;                            
            // 0x00BD5ADC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14EC, ????);     
            // 0x00BD5AE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5AE4: STRB w8, [x21, #0xbfd]     | static_value_03733BFD = true;            //  dest_result_addr=57883645
            label_0:
            // 0x00BD5AE8: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BD5AEC: CBZ x21, #0xbd5ba0         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD5AF0: ADRP x20, #0x3641000       | X20 = 56889344 (0x3641000);             
            // 0x00BD5AF4: LDR x20, [x20, #0xe8]      | X20 = 1152921504893960192;              
            // 0x00BD5AF8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD5AFC: LDR x1, [x20]              | X1 = typeof(Boss);                      
            // 0x00BD5B00: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD5B04: LDRB w9, [x1, #0x104]      | W9 = Boss.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD5B08: CMP w10, w9                | STATE = COMPARE(mem[null + 260], Boss.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD5B0C: B.LO #0xbd5b24             | if (mem[null + 260] < Boss.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD5B10: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD5B14: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD5B18: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD5B1C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Boss))
            // 0x00BD5B20: B.EQ #0xbd5b4c             | if ((mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD5B24: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD5B28: ADD x8, sp, #8             | X8 = (1152921510071170400 + 8) = 1152921510071170408 (0x1000000145B2F568);
            // 0x00BD5B2C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD5B30: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510071158480]
            // 0x00BD5B34: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD5B38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5B3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD5B40: ADD x0, sp, #8             | X0 = (1152921510071170400 + 8) = 1152921510071170408 (0x1000000145B2F568);
            // 0x00BD5B44: BL #0x299a140              | 
            // 0x00BD5B48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145B2F568, ????);
            label_3:
            // 0x00BD5B4C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD5B50: LDR x1, [x20]              | X1 = typeof(Boss);                      
            // 0x00BD5B54: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD5B58: LDRB w9, [x1, #0x104]      | W9 = Boss.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD5B5C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], Boss.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD5B60: B.LO #0xbd5b78             | if (mem[null + 260] < Boss.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD5B64: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD5B68: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD5B6C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD5B70: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Boss))
            // 0x00BD5B74: B.EQ #0xbd5ba8             | if ((mem[null + 176] + (Boss.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD5B78: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD5B7C: ADD x8, sp, #0x10          | X8 = (1152921510071170400 + 16) = 1152921510071170416 (0x1000000145B2F570);
            // 0x00BD5B80: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD5B84: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510071158480]
            // 0x00BD5B88: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD5B8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5B90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD5B94: ADD x0, sp, #0x10          | X0 = (1152921510071170400 + 16) = 1152921510071170416 (0x1000000145B2F570);
            // 0x00BD5B98: BL #0x299a140              | 
            // 0x00BD5B9C: B #0xbd5ba4                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD5BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14EC, ????);     
            label_6:
            // 0x00BD5BA4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BD5BA8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BD5BAC: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00BD5BB0: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x00BD5BB4: CBNZ x19, #0xbd5bbc        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BD5BB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14EC, ????);     
            label_7:
            // 0x00BD5BBC: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD5BC0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD5BC4: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00BD5BC8: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00BD5BCC: B.NE #0xbd5c14             | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BD5BD0: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BD5BD4: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BD5BD8: LDRB w8, [x0]              | W8 = X2;                                
            // 0x00BD5BDC: STRB w8, [x21, #0x638]     | static_value_00000638 = X2;              //  dest_result_addr=1592
            // 0x00BD5BE0: SUB sp, x29, #0x20         | SP = (1152921510071170464 - 32) = 1152921510071170432 (0x1000000145B2F580);
            // 0x00BD5BE4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5BE8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5BEC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD5BF0: RET                        |  return;                                
            return;
            // 0x00BD5BF4: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD5BF8: ADD x0, sp, #8             | X0 = (1152921510071170480 + 8) = 1152921510071170488 (0x1000000145B2F5B8);
            // 0x00BD5BFC: B #0xbd5c08                |  goto label_10;                         
            goto label_10;
            // 0x00BD5C00: MOV x19, x0                | X19 = 1152921510071170488 (0x1000000145B2F5B8);//ML01
            val_7;
            // 0x00BD5C04: ADD x0, sp, #0x10          | X0 = (1152921510071170480 + 16) = 1152921510071170496 (0x1000000145B2F5C0);
            label_10:
            // 0x00BD5C08: BL #0x299a140              | 
            // 0x00BD5C0C: MOV x0, x19                | X0 = 1152921510071170488 (0x1000000145B2F5B8);//ML01
            // 0x00BD5C10: BL #0x980800               | X0 = sub_980800( ?? 0x1000000145B2F5B8, ????);
            label_8:
            // 0x00BD5C14: ADD x8, sp, #0x18          | X8 = (1152921510071170480 + 24) = 1152921510071170504 (0x1000000145B2F5C8);
            // 0x00BD5C18: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BD5C1C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000145B2F5B8, ????);
            // 0x00BD5C20: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510071158480]
            // 0x00BD5C24: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD5C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5C2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD5C30: ADD x0, sp, #0x18          | X0 = (1152921510071170480 + 24) = 1152921510071170504 (0x1000000145B2F5C8);
            // 0x00BD5C34: BL #0x299a140              | 
            // 0x00BD5C38: MOV x19, x0                | X19 = 1152921510071170504 (0x1000000145B2F5C8);//ML01
            // 0x00BD5C3C: ADD x0, sp, #0x18          | X0 = (1152921510071170480 + 24) = 1152921510071170504 (0x1000000145B2F5C8);
            // 0x00BD5C40: B #0xbd5c08                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5C44 (12409924), len: 180  VirtAddr: 0x00BD5C44 RVA: 0x00BD5C44 token: 100663931 methodIndex: 29976 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BD5C44: STP x22, x21, [sp, #-0x30]! | stack[1152921510071306928] = ???;  stack[1152921510071306936] = ???;  //  dest_result_addr=1152921510071306928 |  dest_result_addr=1152921510071306936
            // 0x00BD5C48: STP x20, x19, [sp, #0x10]  | stack[1152921510071306944] = ???;  stack[1152921510071306952] = ???;  //  dest_result_addr=1152921510071306944 |  dest_result_addr=1152921510071306952
            // 0x00BD5C4C: STP x29, x30, [sp, #0x20]  | stack[1152921510071306960] = ???;  stack[1152921510071306968] = ???;  //  dest_result_addr=1152921510071306960 |  dest_result_addr=1152921510071306968
            // 0x00BD5C50: ADD x29, sp, #0x20         | X29 = (1152921510071306928 + 32) = 1152921510071306960 (0x1000000145B50AD0);
            // 0x00BD5C54: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BD5C58: LDRB w8, [x22, #0xbfe]     | W8 = (bool)static_value_03733BFE;       
            // 0x00BD5C5C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BD5C60: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BD5C64: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BD5C68: TBNZ w8, #0, #0xbd5c84     | if (static_value_03733BFE == true) goto label_0;
            // 0x00BD5C6C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00BD5C70: LDR x8, [x8, #0xbd0]       | X8 = 0x2B8F894;                         
            // 0x00BD5C74: LDR w0, [x8]               | W0 = 0x14E9;                            
            // 0x00BD5C78: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E9, ????);     
            // 0x00BD5C7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5C80: STRB w8, [x22, #0xbfe]     | static_value_03733BFE = true;            //  dest_result_addr=57883646
            label_0:
            // 0x00BD5C84: CBNZ x21, #0xbd5c8c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD5C88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14E9, ????);     
            label_1:
            // 0x00BD5C8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5C90: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BD5C94: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD5C98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD5C9C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BD5CA0: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BD5CA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD5CA8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BD5CAC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00BD5CB0: LDR x8, [x8, #0xe8]        | X8 = 1152921504893960192;               
            // 0x00BD5CB4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD5CB8: LDR x8, [x8]               | X8 = typeof(Boss);                      
            // 0x00BD5CBC: MOV x0, x8                 | X0 = 1152921504893960192 (0x10000000111D0000);//ML01
            Boss val_3 = null;
            // 0x00BD5CC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Boss), ????);
            // 0x00BD5CC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5CC8: MOV x21, x0                | X21 = 1152921504893960192 (0x10000000111D0000);//ML01
            // 0x00BD5CCC: BL #0xb93854               | .ctor();                                
            val_3 = new Boss();
            // 0x00BD5CD0: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BD5CD4: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BD5CD8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5CDC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5CE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD5CE4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BD5CE8: MOV x3, x21                | X3 = 1152921504893960192 (0x10000000111D0000);//ML01
            // 0x00BD5CEC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD5CF0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD5CF4: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5CF8 (12410104), len: 92  VirtAddr: 0x00BD5CF8 RVA: 0x00BD5CF8 token: 100663932 methodIndex: 29977 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BD5CF8: STP x20, x19, [sp, #-0x20]! | stack[1152921510071435328] = ???;  stack[1152921510071435336] = ???;  //  dest_result_addr=1152921510071435328 |  dest_result_addr=1152921510071435336
            // 0x00BD5CFC: STP x29, x30, [sp, #0x10]  | stack[1152921510071435344] = ???;  stack[1152921510071435352] = ???;  //  dest_result_addr=1152921510071435344 |  dest_result_addr=1152921510071435352
            // 0x00BD5D00: ADD x29, sp, #0x10         | X29 = (1152921510071435328 + 16) = 1152921510071435344 (0x1000000145B70050);
            // 0x00BD5D04: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD5D08: LDRB w8, [x19, #0xbff]     | W8 = (bool)static_value_03733BFF;       
            // 0x00BD5D0C: TBNZ w8, #0, #0xbd5d28     | if (static_value_03733BFF == true) goto label_0;
            // 0x00BD5D10: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BD5D14: LDR x8, [x8, #0x800]       | X8 = 0x2B8F8A4;                         
            // 0x00BD5D18: LDR w0, [x8]               | W0 = 0x14ED;                            
            // 0x00BD5D1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14ED, ????);     
            // 0x00BD5D20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5D24: STRB w8, [x19, #0xbff]     | static_value_03733BFF = true;            //  dest_result_addr=57883647
            label_0:
            // 0x00BD5D28: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00BD5D2C: LDR x8, [x8, #0xe8]        | X8 = 1152921504893960192;               
            // 0x00BD5D30: LDR x0, [x8]               | X0 = typeof(Boss);                      
            Boss val_1 = null;
            // 0x00BD5D34: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Boss), ????);
            // 0x00BD5D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5D3C: MOV x19, x0                | X19 = 1152921504893960192 (0x10000000111D0000);//ML01
            // 0x00BD5D40: BL #0xb93854               | .ctor();                                
            val_1 = new Boss();
            // 0x00BD5D44: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5D48: MOV x0, x19                | X0 = 1152921504893960192 (0x10000000111D0000);//ML01
            // 0x00BD5D4C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5D50: RET                        |  return (System.Object)typeof(Boss);    
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5D54 (12410196), len: 92  VirtAddr: 0x00BD5D54 RVA: 0x00BD5D54 token: 100663933 methodIndex: 29978 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BD5D54: STP x20, x19, [sp, #-0x20]! | stack[1152921510071551424] = ???;  stack[1152921510071551432] = ???;  //  dest_result_addr=1152921510071551424 |  dest_result_addr=1152921510071551432
            // 0x00BD5D58: STP x29, x30, [sp, #0x10]  | stack[1152921510071551440] = ???;  stack[1152921510071551448] = ???;  //  dest_result_addr=1152921510071551440 |  dest_result_addr=1152921510071551448
            // 0x00BD5D5C: ADD x29, sp, #0x10         | X29 = (1152921510071551424 + 16) = 1152921510071551440 (0x1000000145B8C5D0);
            // 0x00BD5D60: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD5D64: LDRB w8, [x20, #0xc00]     | W8 = (bool)static_value_03733C00;       
            // 0x00BD5D68: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BD5D6C: TBNZ w8, #0, #0xbd5d88     | if (static_value_03733C00 == true) goto label_0;
            // 0x00BD5D70: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00BD5D74: LDR x8, [x8, #0x630]       | X8 = 0x2B8F8A8;                         
            // 0x00BD5D78: LDR w0, [x8]               | W0 = 0x14EE;                            
            // 0x00BD5D7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14EE, ????);     
            // 0x00BD5D80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5D84: STRB w8, [x20, #0xc00]     | static_value_03733C00 = true;            //  dest_result_addr=57883648
            label_0:
            // 0x00BD5D88: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00BD5D8C: LDR x8, [x8, #0xd00]       | X8 = 1152921510071535360;               
            // 0x00BD5D90: LDR x20, [x8]              | X20 = typeof(Boss[]);                   
            // 0x00BD5D94: MOV x0, x20                | X0 = 1152921510071535360 (0x1000000145B88700);//ML01
            // 0x00BD5D98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Boss[]), ????);
            // 0x00BD5D9C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5DA0: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BD5DA4: MOV x0, x20                | X0 = 1152921510071535360 (0x1000000145B88700);//ML01
            // 0x00BD5DA8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5DAC: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(Boss[]), ????);
        
        }
    
    }

}
