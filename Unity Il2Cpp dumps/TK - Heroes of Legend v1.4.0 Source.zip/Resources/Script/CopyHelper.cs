using UnityEngine;
private class ZipEntry.CopyHelper
{
    // Fields
    private static System.Text.RegularExpressions.Regex re; // static_offset: 0x00000000
    private static int callCount; // static_offset: 0x00000008
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x01982B60 (26749792), len: 132  VirtAddr: 0x01982B60 RVA: 0x01982B60 token: 100663530 methodIndex: 21087 delegateWrapperIndex: 0 methodInvoker: 0
    private static ZipEntry.CopyHelper()
    {
        //
        // Disasemble & Code
        // 0x01982B60: STP x20, x19, [sp, #-0x20]! | stack[1152921509662235152] = ???;  stack[1152921509662235160] = ???;  //  dest_result_addr=1152921509662235152 |  dest_result_addr=1152921509662235160
        // 0x01982B64: STP x29, x30, [sp, #0x10]  | stack[1152921509662235168] = ???;  stack[1152921509662235176] = ???;  //  dest_result_addr=1152921509662235168 |  dest_result_addr=1152921509662235176
        // 0x01982B68: ADD x29, sp, #0x10         | X29 = (1152921509662235152 + 16) = 1152921509662235168 (0x100000012D531A20);
        // 0x01982B6C: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
        // 0x01982B70: LDRB w8, [x19, #0x44e]     | W8 = (bool)static_value_0373944E;       
        // 0x01982B74: TBNZ w8, #0, #0x1982b90    | if (static_value_0373944E == true) goto label_0;
        // 0x01982B78: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x01982B7C: LDR x8, [x8, #0x370]       | X8 = 0x2B92D24;                         
        // 0x01982B80: LDR w0, [x8]               | W0 = 0x220E;                            
        // 0x01982B84: BL #0x2782188              | X0 = sub_2782188( ?? 0x220E, ????);     
        // 0x01982B88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x01982B8C: STRB w8, [x19, #0x44e]     | static_value_0373944E = true;            //  dest_result_addr=57906254
        label_0:
        // 0x01982B90: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x01982B94: LDR x8, [x8, #0x3a0]       | X8 = 1152921504681553920;               
        // 0x01982B98: LDR x0, [x8]               | X0 = typeof(System.Text.RegularExpressions.Regex);
        System.Text.RegularExpressions.Regex val_1 = null;
        // 0x01982B9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.RegularExpressions.Regex), ????);
        // 0x01982BA0: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x01982BA4: LDR x8, [x8, #0x830]       | X8 = (string**)(1152921509662223072)(" \\(copy (\\d+)\\)$");
        // 0x01982BA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01982BAC: MOV x19, x0                | X19 = 1152921504681553920 (0x100000000473F000);//ML01
        // 0x01982BB0: LDR x1, [x8]               | X1 = " \\(copy (\\d+)\\)$";             
        // 0x01982BB4: BL #0x1ebe578              | .ctor(pattern:  " \\(copy (\\d+)\\)$"); 
        val_1 = new System.Text.RegularExpressions.Regex(pattern:  " \\(copy (\\d+)\\)$");
        // 0x01982BB8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x01982BBC: LDR x8, [x8, #0x120]       | X8 = 1152921504751521792;               
        // 0x01982BC0: LDR x9, [x8]               | X9 = typeof(ZipEntry.CopyHelper);       
        // 0x01982BC4: LDR x9, [x9, #0xa0]        | X9 = ZipEntry.CopyHelper.__il2cppRuntimeField_static_fields;
        // 0x01982BC8: STR x19, [x9]              | ZipEntry.CopyHelper.re = typeof(System.Text.RegularExpressions.Regex);  //  dest_result_addr=1152921504751525888
        ZipEntry.CopyHelper.re = val_1;
        // 0x01982BCC: LDR x8, [x8]               | X8 = typeof(ZipEntry.CopyHelper);       
        // 0x01982BD0: LDR x8, [x8, #0xa0]        | X8 = ZipEntry.CopyHelper.__il2cppRuntimeField_static_fields;
        // 0x01982BD4: STR wzr, [x8, #8]          | ZipEntry.CopyHelper.callCount = 0;       //  dest_result_addr=1152921504751525896
        ZipEntry.CopyHelper.callCount = 0;
        // 0x01982BD8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x01982BDC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x01982BE0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0197678C (26699660), len: 1392  VirtAddr: 0x0197678C RVA: 0x0197678C token: 100663531 methodIndex: 21088 delegateWrapperIndex: 0 methodInvoker: 0
    internal static string AppendCopyToFileName(string f)
    {
        //
        // Disasemble & Code
        //  | 
        string val_34;
        //  | 
        var val_35;
        //  | 
        var val_36;
        //  | 
        var val_37;
        //  | 
        var val_38;
        //  | 
        var val_39;
        //  | 
        string val_40;
        //  | 
        string val_41;
        //  | 
        string val_42;
        //  | 
        string val_43;
        // 0x0197678C: STP x22, x21, [sp, #-0x30]! | stack[1152921509662454896] = ???;  stack[1152921509662454904] = ???;  //  dest_result_addr=1152921509662454896 |  dest_result_addr=1152921509662454904
        // 0x01976790: STP x20, x19, [sp, #0x10]  | stack[1152921509662454912] = ???;  stack[1152921509662454920] = ???;  //  dest_result_addr=1152921509662454912 |  dest_result_addr=1152921509662454920
        // 0x01976794: STP x29, x30, [sp, #0x20]  | stack[1152921509662454928] = ???;  stack[1152921509662454936] = ???;  //  dest_result_addr=1152921509662454928 |  dest_result_addr=1152921509662454936
        // 0x01976798: ADD x29, sp, #0x20         | X29 = (1152921509662454896 + 32) = 1152921509662454928 (0x100000012D567490);
        // 0x0197679C: SUB sp, sp, #0x10          | SP = (1152921509662454896 - 16) = 1152921509662454880 (0x100000012D567460);
        // 0x019767A0: ADRP x20, #0x3739000       | X20 = 57905152 (0x3739000);             
        // 0x019767A4: LDRB w8, [x20, #0x44f]     | W8 = (bool)static_value_0373944F;       
        // 0x019767A8: MOV x19, x1                | X19 = X1;//m1                           
        // 0x019767AC: TBNZ w8, #0, #0x19767c8    | if (static_value_0373944F == true) goto label_0;
        // 0x019767B0: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x019767B4: LDR x8, [x8, #0x7a8]       | X8 = 0x2B92D28;                         
        // 0x019767B8: LDR w0, [x8]               | W0 = 0x220F;                            
        // 0x019767BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x220F, ????);     
        // 0x019767C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x019767C4: STRB w8, [x20, #0x44f]     | static_value_0373944F = true;            //  dest_result_addr=57906255
        label_0:
        // 0x019767C8: ADRP x21, #0x366c000       | X21 = 57065472 (0x366C000);             
        // 0x019767CC: LDR x21, [x21, #0x120]     | X21 = 1152921504751521792;              
        val_34 = 1152921504751521792;
        // 0x019767D0: LDR x0, [x21]              | X0 = typeof(ZipEntry.CopyHelper);       
        val_35 = null;
        // 0x019767D4: LDRB w8, [x0, #0x10a]      | W8 = ZipEntry.CopyHelper.__il2cppRuntimeField_10A;
        // 0x019767D8: TBZ w8, #0, #0x19767ec     | if (ZipEntry.CopyHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x019767DC: LDR w8, [x0, #0xbc]        | W8 = ZipEntry.CopyHelper.__il2cppRuntimeField_cctor_finished;
        // 0x019767E0: CBNZ w8, #0x19767ec        | if (ZipEntry.CopyHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x019767E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZipEntry.CopyHelper), ????);
        // 0x019767E8: LDR x0, [x21]              | X0 = typeof(ZipEntry.CopyHelper);       
        val_35 = null;
        label_2:
        // 0x019767EC: LDR x8, [x0, #0xa0]        | X8 = ZipEntry.CopyHelper.__il2cppRuntimeField_static_fields;
        // 0x019767F0: LDR w9, [x8, #8]           | W9 = ZipEntry.CopyHelper.callCount;     
        int val_34 = ZipEntry.CopyHelper.callCount;
        // 0x019767F4: ADD w9, w9, #1             | W9 = (ZipEntry.CopyHelper.callCount + 1);
        val_34 = val_34 + 1;
        // 0x019767F8: STR w9, [x8, #8]           | ZipEntry.CopyHelper.callCount = (ZipEntry.CopyHelper.callCount + 1);  //  dest_result_addr=1152921504751525896
        ZipEntry.CopyHelper.callCount = val_34;
        // 0x019767FC: LDR x8, [x21]              | X8 = typeof(ZipEntry.CopyHelper);       
        // 0x01976800: LDR x8, [x8, #0xa0]        | X8 = ZipEntry.CopyHelper.__il2cppRuntimeField_static_fields;
        // 0x01976804: LDR w8, [x8, #8]           | W8 = (ZipEntry.CopyHelper.callCount + 1);
        // 0x01976808: CMP w8, #0x1a              | STATE = COMPARE((ZipEntry.CopyHelper.callCount + 1), 0x1A)
        // 0x0197680C: B.GE #0x1976cbc            | if (ZipEntry.CopyHelper.callCount >= 26) goto label_3;
        if(ZipEntry.CopyHelper.callCount >= 26)
        {
            goto label_3;
        }
        // 0x01976810: CBNZ x19, #0x1976818       | if (X1 != 0) goto label_4;              
        if(X1 != 0)
        {
            goto label_4;
        }
        // 0x01976814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ZipEntry.CopyHelper), ????);
        label_4:
        // 0x01976818: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x0197681C: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
        // 0x01976820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976824: MOV x0, x19                | X0 = X1;//m1                            
        // 0x01976828: LDR x1, [x8]               | X1 = ".";                               
        // 0x0197682C: BL #0x18ad1e4              | X0 = X1.LastIndexOf(value:  ".");       
        int val_1 = X1.LastIndexOf(value:  ".");
        // 0x01976830: MOV w20, w0                | W20 = val_1;//m1                        
        // 0x01976834: LDR x0, [x21]              | X0 = typeof(ZipEntry.CopyHelper);       
        val_36 = null;
        // 0x01976838: CMN w20, #1                | STATE = COMPARE(val_1, 0x1)             
        // 0x0197683C: ADD x8, x0, #0x109         | X8 = (val_36 + 265) = 1152921504751522057 (0x10000000089F9109);
        // 0x01976840: LDRH w8, [x8]              | W8 = ZipEntry.CopyHelper.__il2cppRuntimeField_109;
        // 0x01976844: AND w8, w8, #0x100         | W8 = (ZipEntry.CopyHelper.__il2cppRuntimeField_109 & 256);
        // 0x01976848: AND w8, w8, #0xffff        | W8 = ((ZipEntry.CopyHelper.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x0197684C: B.EQ #0x19769bc            | if (val_1 == 1) goto label_5;           
        if(val_1 == 1)
        {
            goto label_5;
        }
        // 0x01976850: CBZ w8, #0x1976864         | if (((ZipEntry.CopyHelper.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_7;
        // 0x01976854: LDR w8, [x0, #0xbc]        | W8 = ZipEntry.CopyHelper.__il2cppRuntimeField_cctor_finished;
        // 0x01976858: CBNZ w8, #0x1976864        | if (ZipEntry.CopyHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0197685C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZipEntry.CopyHelper), ????);
        // 0x01976860: LDR x0, [x21]              | X0 = typeof(ZipEntry.CopyHelper);       
        val_37 = null;
        label_7:
        // 0x01976864: LDR x8, [x0, #0xa0]        | X8 = ZipEntry.CopyHelper.__il2cppRuntimeField_static_fields;
        // 0x01976868: LDR x21, [x8]              | X21 = ZipEntry.CopyHelper.re;           
        // 0x0197686C: CBNZ x19, #0x1976874       | if (X1 != 0) goto label_8;              
        if(X1 != 0)
        {
            goto label_8;
        }
        // 0x01976870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ZipEntry.CopyHelper), ????);
        label_8:
        // 0x01976874: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x01976878: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0197687C: MOV x0, x19                | X0 = X1;//m1                            
        // 0x01976880: MOV w2, w20                | W2 = val_1;//m1                         
        // 0x01976884: BL #0x18a920c              | X0 = X1.Substring(startIndex:  0, length:  val_1);
        string val_4 = X1.Substring(startIndex:  0, length:  val_1);
        // 0x01976888: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x0197688C: CBNZ x21, #0x1976894       | if (ZipEntry.CopyHelper.re != null) goto label_9;
        if(ZipEntry.CopyHelper.re != null)
        {
            goto label_9;
        }
        // 0x01976890: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x01976894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976898: MOV x0, x21                | X0 = ZipEntry.CopyHelper.re;//m1        
        // 0x0197689C: MOV x1, x22                | X1 = val_4;//m1                         
        // 0x019768A0: BL #0x1ec0180              | X0 = ZipEntry.CopyHelper.re.Match(input:  val_4);
        System.Text.RegularExpressions.Match val_5 = ZipEntry.CopyHelper.re.Match(input:  val_4);
        // 0x019768A4: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x019768A8: CBNZ x21, #0x19768b0       | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x019768AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x019768B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019768B4: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x019768B8: BL #0x1eb458c              | X0 = val_5.get_Success();               
        bool val_6 = val_5.Success;
        // 0x019768BC: TBZ w0, #0, #0x1976b1c     | if (val_6 == false) goto label_11;      
        if(val_6 == false)
        {
            goto label_11;
        }
        // 0x019768C0: CBNZ x21, #0x19768c8       | if (val_5 != null) goto label_12;       
        if(val_5 != null)
        {
            goto label_12;
        }
        // 0x019768C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x019768C8: LDR x8, [x21]              | X8 = typeof(System.Text.RegularExpressions.Match);
        // 0x019768CC: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x019768D0: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150; X1 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_158; //  | 
        // 0x019768D4: BLR x9                     | X0 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150();
        // 0x019768D8: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x019768DC: CBNZ x22, #0x19768e4       | if (val_5 != null) goto label_13;       
        if(val_5 != null)
        {
            goto label_13;
        }
        // 0x019768E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_13:
        // 0x019768E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x019768E8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x019768EC: MOV x0, x22                | X0 = val_5;//m1                         
        // 0x019768F0: BL #0x1eb45cc              | X0 = val_5.get_Item(i:  1);             
        System.Text.RegularExpressions.Group val_7 = val_5.Item[1];
        // 0x019768F4: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x019768F8: CBNZ x22, #0x1976900       | if (val_7 != null) goto label_14;       
        if(val_7 != null)
        {
            goto label_14;
        }
        // 0x019768FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_14:
        // 0x01976900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01976904: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x01976908: BL #0x1eb4ff4              | X0 = val_7.get_Value();                 
        string val_8 = val_7.Value;
        // 0x0197690C: MOV x1, x0                 | X1 = val_8;//m1                         
        // 0x01976910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976914: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976918: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_9 = System.Int32.Parse(s:  0);
        // 0x0197691C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x01976920: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x01976924: ADD w9, w0, #1             | W9 = (val_9 + 1);                       
        int val_10 = val_9 + 1;
        // 0x01976928: ADD x1, sp, #0xc           | X1 = (1152921509662454880 + 12) = 1152921509662454892 (0x100000012D56746C);
        // 0x0197692C: STR w9, [sp, #0xc]         | stack[1152921509662454892] = (val_9 + 1);  //  dest_result_addr=1152921509662454892
        // 0x01976930: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x01976934: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x01976938: BL #0x27bc028              | X0 = 1152921509662519424 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (val_9 + 1));
        // 0x0197693C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x01976940: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x01976944: MOV x22, x0                | X22 = 1152921509662519424 (0x100000012D577080);//ML01
        // 0x01976948: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x0197694C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x01976950: TBZ w9, #0, #0x1976964     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x01976954: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x01976958: CBNZ w9, #0x1976964        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x0197695C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x01976960: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_16:
        // 0x01976964: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x01976968: LDR x8, [x8, #0x328]       | X8 = (string**)(1152921509662359760)(" (copy {0})");
        // 0x0197696C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976970: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976974: MOV x2, x22                | X2 = 1152921509662519424 (0x100000012D577080);//ML01
        // 0x01976978: LDR x1, [x8]               | X1 = " (copy {0})";                     
        // 0x0197697C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  " (copy {0})");
        string val_11 = System.String.Format(format:  0, arg0:  " (copy {0})");
        // 0x01976980: MOV x22, x0                | X22 = val_11;//m1                       
        // 0x01976984: CBNZ x21, #0x197698c       | if (val_5 != null) goto label_17;       
        if(val_5 != null)
        {
            goto label_17;
        }
        // 0x01976988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_17:
        // 0x0197698C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01976990: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x01976994: BL #0x1eb4594              | X0 = val_5.get_Index();                 
        int val_12 = val_5.Index;
        // 0x01976998: MOV w21, w0                | W21 = val_12;//m1                       
        // 0x0197699C: CBZ x19, #0x1976c18        | if (X1 == 0) goto label_18;             
        if(X1 == 0)
        {
            goto label_18;
        }
        // 0x019769A0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x019769A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x019769A8: MOV x0, x19                | X0 = X1;//m1                            
        // 0x019769AC: MOV w2, w21                | W2 = val_12;//m1                        
        // 0x019769B0: BL #0x18a920c              | X0 = X1.Substring(startIndex:  0, length:  val_12);
        string val_13 = X1.Substring(startIndex:  0, length:  val_12);
        // 0x019769B4: MOV x21, x0                | X21 = val_13;//m1                       
        val_34 = val_13;
        // 0x019769B8: B #0x1976c38               |  goto label_19;                         
        goto label_19;
        label_5:
        // 0x019769BC: CBZ w8, #0x19769d0         | if (((ZipEntry.CopyHelper.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_21;
        // 0x019769C0: LDR w8, [x0, #0xbc]        | W8 = ZipEntry.CopyHelper.__il2cppRuntimeField_cctor_finished;
        // 0x019769C4: CBNZ w8, #0x19769d0        | if (ZipEntry.CopyHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x019769C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZipEntry.CopyHelper), ????);
        // 0x019769CC: LDR x0, [x21]              | X0 = typeof(ZipEntry.CopyHelper);       
        val_38 = null;
        label_21:
        // 0x019769D0: LDR x8, [x0, #0xa0]        | X8 = ZipEntry.CopyHelper.__il2cppRuntimeField_static_fields;
        // 0x019769D4: LDR x20, [x8]              | X20 = ZipEntry.CopyHelper.re;           
        // 0x019769D8: CBNZ x20, #0x19769e0       | if (ZipEntry.CopyHelper.re != null) goto label_22;
        if(ZipEntry.CopyHelper.re != null)
        {
            goto label_22;
        }
        // 0x019769DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ZipEntry.CopyHelper), ????);
        label_22:
        // 0x019769E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x019769E4: MOV x0, x20                | X0 = ZipEntry.CopyHelper.re;//m1        
        // 0x019769E8: MOV x1, x19                | X1 = X1;//m1                            
        // 0x019769EC: BL #0x1ec0180              | X0 = ZipEntry.CopyHelper.re.Match(input:  X1);
        System.Text.RegularExpressions.Match val_14 = ZipEntry.CopyHelper.re.Match(input:  X1);
        // 0x019769F0: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x019769F4: CBNZ x20, #0x19769fc       | if (val_14 != null) goto label_23;      
        if(val_14 != null)
        {
            goto label_23;
        }
        // 0x019769F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_23:
        // 0x019769FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01976A00: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x01976A04: BL #0x1eb458c              | X0 = val_14.get_Success();              
        bool val_15 = val_14.Success;
        // 0x01976A08: TBZ w0, #0, #0x1976ba0     | if (val_15 == false) goto label_24;     
        if(val_15 == false)
        {
            goto label_24;
        }
        // 0x01976A0C: CBNZ x20, #0x1976a14       | if (val_14 != null) goto label_25;      
        if(val_14 != null)
        {
            goto label_25;
        }
        // 0x01976A10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_25:
        // 0x01976A14: LDR x8, [x20]              | X8 = typeof(System.Text.RegularExpressions.Match);
        // 0x01976A18: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x01976A1C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150; X1 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_158; //  | 
        // 0x01976A20: BLR x9                     | X0 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150();
        // 0x01976A24: MOV x21, x0                | X21 = val_14;//m1                       
        // 0x01976A28: CBNZ x21, #0x1976a30       | if (val_14 != null) goto label_26;      
        if(val_14 != null)
        {
            goto label_26;
        }
        // 0x01976A2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_26:
        // 0x01976A30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976A34: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x01976A38: MOV x0, x21                | X0 = val_14;//m1                        
        // 0x01976A3C: BL #0x1eb45cc              | X0 = val_14.get_Item(i:  1);            
        System.Text.RegularExpressions.Group val_16 = val_14.Item[1];
        // 0x01976A40: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x01976A44: CBNZ x21, #0x1976a4c       | if (val_16 != null) goto label_27;      
        if(val_16 != null)
        {
            goto label_27;
        }
        // 0x01976A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_27:
        // 0x01976A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01976A50: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x01976A54: BL #0x1eb4ff4              | X0 = val_16.get_Value();                
        string val_17 = val_16.Value;
        // 0x01976A58: MOV x1, x0                 | X1 = val_17;//m1                        
        // 0x01976A5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976A60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976A64: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_18 = System.Int32.Parse(s:  0);
        // 0x01976A68: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x01976A6C: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x01976A70: ADD w9, w0, #1             | W9 = (val_18 + 1);                      
        int val_19 = val_18 + 1;
        // 0x01976A74: ADD x1, sp, #0xc           | X1 = (1152921509662454880 + 12) = 1152921509662454892 (0x100000012D56746C);
        // 0x01976A78: STR w9, [sp, #0xc]         | stack[1152921509662454892] = (val_18 + 1);  //  dest_result_addr=1152921509662454892
        // 0x01976A7C: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x01976A80: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x01976A84: BL #0x27bc028              | X0 = 1152921509662544000 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (val_18 + 1));
        // 0x01976A88: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x01976A8C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x01976A90: MOV x21, x0                | X21 = 1152921509662544000 (0x100000012D57D080);//ML01
        // 0x01976A94: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x01976A98: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x01976A9C: TBZ w9, #0, #0x1976ab0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_29;
        // 0x01976AA0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x01976AA4: CBNZ w9, #0x1976ab0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
        // 0x01976AA8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x01976AAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_29:
        // 0x01976AB0: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x01976AB4: LDR x8, [x8, #0x328]       | X8 = (string**)(1152921509662359760)(" (copy {0})");
        // 0x01976AB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976ABC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976AC0: MOV x2, x21                | X2 = 1152921509662544000 (0x100000012D57D080);//ML01
        // 0x01976AC4: LDR x1, [x8]               | X1 = " (copy {0})";                     
        // 0x01976AC8: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  " (copy {0})");
        string val_20 = System.String.Format(format:  0, arg0:  " (copy {0})");
        // 0x01976ACC: MOV x21, x0                | X21 = val_20;//m1                       
        val_34 = val_20;
        // 0x01976AD0: CBNZ x20, #0x1976ad8       | if (val_14 != null) goto label_30;      
        if(val_14 != null)
        {
            goto label_30;
        }
        // 0x01976AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_30:
        // 0x01976AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01976ADC: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x01976AE0: BL #0x1eb4594              | X0 = val_14.get_Index();                
        int val_21 = val_14.Index;
        // 0x01976AE4: MOV w20, w0                | W20 = val_21;//m1                       
        // 0x01976AE8: CBNZ x19, #0x1976af0       | if (X1 != 0) goto label_31;             
        if(X1 != 0)
        {
            goto label_31;
        }
        // 0x01976AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_31:
        // 0x01976AF0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x01976AF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976AF8: MOV x0, x19                | X0 = X1;//m1                            
        // 0x01976AFC: MOV w2, w20                | W2 = val_21;//m1                        
        // 0x01976B00: BL #0x18a920c              | X0 = X1.Substring(startIndex:  0, length:  val_21);
        string val_22 = X1.Substring(startIndex:  0, length:  val_21);
        // 0x01976B04: MOV x1, x0                 | X1 = val_22;//m1                        
        // 0x01976B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976B0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976B10: MOV x2, x21                | X2 = val_20;//m1                        
        // 0x01976B14: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_22);
        string val_23 = System.String.Concat(str0:  0, str1:  val_22);
        // 0x01976B18: B #0x1976ca8               |  goto label_39;                         
        goto label_39;
        label_11:
        // 0x01976B1C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x01976B20: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x01976B24: ADD x1, sp, #0xc           | X1 = (1152921509662454880 + 12) = 1152921509662454892 (0x100000012D56746C);
        // 0x01976B28: LDR x0, [x8]               | X0 = typeof(System.Int32);              
        // 0x01976B2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x01976B30: STR w8, [sp, #0xc]         | stack[1152921509662454892] = 0x1;        //  dest_result_addr=1152921509662454892
        // 0x01976B34: BL #0x27bc028              | X0 = 1152921509662560384 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
        // 0x01976B38: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x01976B3C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x01976B40: MOV x21, x0                | X21 = 1152921509662560384 (0x100000012D581080);//ML01
        // 0x01976B44: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x01976B48: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x01976B4C: TBZ w9, #0, #0x1976b60     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_34;
        // 0x01976B50: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x01976B54: CBNZ w9, #0x1976b60        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
        // 0x01976B58: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x01976B5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_34:
        // 0x01976B60: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x01976B64: LDR x8, [x8, #0x328]       | X8 = (string**)(1152921509662359760)(" (copy {0})");
        // 0x01976B68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976B6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976B70: MOV x2, x21                | X2 = 1152921509662560384 (0x100000012D581080);//ML01
        // 0x01976B74: LDR x1, [x8]               | X1 = " (copy {0})";                     
        // 0x01976B78: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  " (copy {0})");
        string val_24 = System.String.Format(format:  0, arg0:  " (copy {0})");
        // 0x01976B7C: MOV x21, x0                | X21 = val_24;//m1                       
        val_34 = val_24;
        // 0x01976B80: CBZ x19, #0x1976c60        | if (X1 == 0) goto label_35;             
        if(X1 == 0)
        {
            goto label_35;
        }
        // 0x01976B84: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x01976B88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976B8C: MOV x0, x19                | X0 = X1;//m1                            
        // 0x01976B90: MOV w2, w20                | W2 = val_1;//m1                         
        // 0x01976B94: BL #0x18a920c              | X0 = X1.Substring(startIndex:  0, length:  val_1);
        string val_25 = X1.Substring(startIndex:  0, length:  val_1);
        // 0x01976B98: MOV x22, x0                | X22 = val_25;//m1                       
        val_40 = val_25;
        // 0x01976B9C: B #0x1976c80               |  goto label_36;                         
        goto label_36;
        label_24:
        // 0x01976BA0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x01976BA4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x01976BA8: ADD x1, sp, #0xc           | X1 = (1152921509662454880 + 12) = 1152921509662454892 (0x100000012D56746C);
        // 0x01976BAC: LDR x0, [x8]               | X0 = typeof(System.Int32);              
        // 0x01976BB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x01976BB4: STR w8, [sp, #0xc]         | stack[1152921509662454892] = 0x1;        //  dest_result_addr=1152921509662454892
        // 0x01976BB8: BL #0x27bc028              | X0 = 1152921509662572672 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
        // 0x01976BBC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x01976BC0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x01976BC4: MOV x20, x0                | X20 = 1152921509662572672 (0x100000012D584080);//ML01
        // 0x01976BC8: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x01976BCC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x01976BD0: TBZ w9, #0, #0x1976be4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x01976BD4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x01976BD8: CBNZ w9, #0x1976be4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
        // 0x01976BDC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x01976BE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_38:
        // 0x01976BE4: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x01976BE8: LDR x8, [x8, #0x328]       | X8 = (string**)(1152921509662359760)(" (copy {0})");
        // 0x01976BEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976BF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976BF4: MOV x2, x20                | X2 = 1152921509662572672 (0x100000012D584080);//ML01
        // 0x01976BF8: LDR x1, [x8]               | X1 = " (copy {0})";                     
        // 0x01976BFC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  " (copy {0})");
        string val_26 = System.String.Format(format:  0, arg0:  " (copy {0})");
        // 0x01976C00: MOV x2, x0                 | X2 = val_26;//m1                        
        // 0x01976C04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976C08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976C0C: MOV x1, x19                | X1 = X1;//m1                            
        // 0x01976C10: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  X1);
        string val_27 = System.String.Concat(str0:  0, str1:  X1);
        // 0x01976C14: B #0x1976ca8               |  goto label_39;                         
        goto label_39;
        label_18:
        // 0x01976C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        // 0x01976C1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976C20: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x01976C24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976C28: MOV w2, w21                | W2 = val_12;//m1                        
        // 0x01976C2C: BL #0x18a920c              | X0 = 0.Substring(startIndex:  0, length:  val_12);
        string val_28 = 0.Substring(startIndex:  0, length:  val_12);
        // 0x01976C30: MOV x21, x0                | X21 = val_28;//m1                       
        val_34 = val_28;
        // 0x01976C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_19:
        // 0x01976C38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976C3C: MOV x0, x19                | X0 = X1;//m1                            
        // 0x01976C40: MOV w1, w20                | W1 = val_1;//m1                         
        // 0x01976C44: BL #0x18a5a40              | X0 = X1.Substring(startIndex:  val_1);  
        string val_29 = X1.Substring(startIndex:  val_1);
        // 0x01976C48: MOV x3, x0                 | X3 = val_29;//m1                        
        // 0x01976C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_41 = 0;
        // 0x01976C50: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x01976C54: MOV x1, x21                | X1 = val_28;//m1                        
        val_42 = val_34;
        // 0x01976C58: MOV x2, x22                | X2 = val_11;//m1                        
        val_43 = val_11;
        // 0x01976C5C: B #0x1976ca4               |  goto label_40;                         
        goto label_40;
        label_35:
        // 0x01976C60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        // 0x01976C64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01976C68: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x01976C6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01976C70: MOV w2, w20                | W2 = val_1;//m1                         
        // 0x01976C74: BL #0x18a920c              | X0 = 0.Substring(startIndex:  0, length:  val_1);
        string val_30 = 0.Substring(startIndex:  0, length:  val_1);
        // 0x01976C78: MOV x22, x0                | X22 = val_30;//m1                       
        val_40 = val_30;
        // 0x01976C7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_36:
        // 0x01976C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976C84: MOV x0, x19                | X0 = X1;//m1                            
        // 0x01976C88: MOV w1, w20                | W1 = val_1;//m1                         
        // 0x01976C8C: BL #0x18a5a40              | X0 = X1.Substring(startIndex:  val_1);  
        string val_31 = X1.Substring(startIndex:  val_1);
        // 0x01976C90: MOV x3, x0                 | X3 = val_31;//m1                        
        // 0x01976C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_41 = 0;
        // 0x01976C98: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x01976C9C: MOV x1, x22                | X1 = val_30;//m1                        
        val_42 = val_40;
        // 0x01976CA0: MOV x2, x21                | X2 = val_24;//m1                        
        val_43 = val_34;
        label_40:
        // 0x01976CA4: BL #0x18a311c              | X0 = System.String.Concat(str0:  val_41 = 0, str1:  val_42 = val_40, str2:  val_43 = val_34);
        string val_32 = System.String.Concat(str0:  val_41, str1:  val_42, str2:  val_43);
        label_39:
        // 0x01976CA8: SUB sp, x29, #0x20         | SP = (1152921509662454928 - 32) = 1152921509662454896 (0x100000012D567470);
        // 0x01976CAC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x01976CB0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x01976CB4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x01976CB8: RET                        |  return (System.String)val_32;          
        return val_32;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        label_3:
        // 0x01976CBC: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x01976CC0: LDR x8, [x8, #0x268]       | X8 = 1152921504655835136;               
        // 0x01976CC4: LDR x0, [x8]               | X0 = typeof(System.OverflowException);  
        System.OverflowException val_33 = null;
        // 0x01976CC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.OverflowException), ????);
        // 0x01976CCC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x01976CD0: LDR x8, [x8, #0x810]       | X8 = (string**)(1152921509662441776)("overflow while creating filename");
        // 0x01976CD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x01976CD8: MOV x19, x0                | X19 = 1152921504655835136 (0x1000000002EB8000);//ML01
        // 0x01976CDC: LDR x1, [x8]               | X1 = "overflow while creating filename";
        // 0x01976CE0: BL #0x16f8d88              | .ctor(message:  "overflow while creating filename");
        val_33 = new System.OverflowException(message:  "overflow while creating filename");
        // 0x01976CE4: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x01976CE8: LDR x8, [x8, #0x9e0]       | X8 = 1152921509662441920;               
        // 0x01976CEC: MOV x0, x19                | X0 = 1152921504655835136 (0x1000000002EB8000);//ML01
        // 0x01976CF0: LDR x1, [x8]               | X1 = static System.String ZipEntry.CopyHelper::AppendCopyToFileName(string f);
        // 0x01976CF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.OverflowException), ????);
        // 0x01976CF8: BL #0x196f408              | SlurpBlock(block:  static System.String ZipEntry.CopyHelper::AppendCopyToFileName(string f), offset:  0, count:  0);
        SlurpBlock(block:  static System.String ZipEntry.CopyHelper::AppendCopyToFileName(string f), offset:  0, count:  0);
    
    }

}
