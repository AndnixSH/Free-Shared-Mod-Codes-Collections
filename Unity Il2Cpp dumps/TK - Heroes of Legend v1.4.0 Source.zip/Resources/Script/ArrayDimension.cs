using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public struct ArrayDimension
    {
        // Fields
        private System.Nullable<int> lower_bound; //  0x00000000
        private System.Nullable<int> upper_bound; //  0x00000008
        
        // Properties
        public bool IsSized { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E53EC8 (15023816), len: 16  VirtAddr: 0x00E53EC8 RVA: 0x00E53EC8 token: 100663431 methodIndex: 19258 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsSized()
        {
            //
            // Disasemble & Code
            // 0x00E53EC8: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921509418066208 (0x100000011EC56120);
            // 0x00E53ECC: B #0xe53e54                | X0 = sub_E53E54( ?? (ILRuntime.Mono.Cecil.ArrayDimension)[1152921509418066192], ????);
            // 0x00E53ED0: STP x1, x2, [x0]           | mem[1152921509418066208] = ???;  .upper_bound = ;  //  dest_result_addr=1152921509418066208 |  dest_result_addr=1152921509418066216
            mem[1152921509418066208] = ???;
            .upper_bound = new System.Nullable<System.Int32>();
            // 0x00E53ED4: RET                        |  return (System.Boolean)(ILRuntime.Mono.Cecil.ArrayDimension)[1152921509418066192];
            return (bool)1152921509418066208;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E53ED8 (15023832), len: 268  VirtAddr: 0x00E53ED8 RVA: 0x00E53ED8 token: 100663432 methodIndex: 19259 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayDimension(System.Nullable<int> lowerBound, System.Nullable<int> upperBound)
        {
            //
            // Disasemble & Code
            // 0x00E53ED8: STP x1, x2, [x0, #0x10]    | mem[1152921509418178208] = lowerBound.HasValue;  mem[1152921509418178216] = upperBound.HasValue;  //  dest_result_addr=1152921509418178208 |  dest_result_addr=1152921509418178216
            mem[1152921509418178208] = lowerBound.HasValue;
            mem[1152921509418178216] = upperBound.HasValue;
            // 0x00E53EDC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E53FE4 (15024100), len: 8  VirtAddr: 0x00E53FE4 RVA: 0x00E53FE4 token: 100663433 methodIndex: 19260 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            // 0x00E53FE4: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921509418290208 (0x100000011EC8CC20);
            // 0x00E53FE8: B #0xe53ee0                | X0 = sub_E53EE0( ?? (ILRuntime.Mono.Cecil.ArrayDimension)[1152921509418290192], ????);
        
        }
    
    }

}
