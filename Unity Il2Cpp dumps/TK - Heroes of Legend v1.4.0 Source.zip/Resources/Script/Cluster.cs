using UnityEngine;
[Serializable]
public class FingerClusterManager.Cluster
{
    // Fields
    public int Id; //  0x00000010
    public float StartTime; //  0x00000014
    public FingerGestures.FingerList Fingers; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00ED5B1C (15555356), len: 100  VirtAddr: 0x00ED5B1C RVA: 0x00ED5B1C token: 100683959 methodIndex: 27611 delegateWrapperIndex: 0 methodInvoker: 0
    public FingerClusterManager.Cluster()
    {
        //
        // Disasemble & Code
        // 0x00ED5B1C: STP x20, x19, [sp, #-0x20]! | stack[1152921513573296688] = ???;  stack[1152921513573296696] = ???;  //  dest_result_addr=1152921513573296688 |  dest_result_addr=1152921513573296696
        // 0x00ED5B20: STP x29, x30, [sp, #0x10]  | stack[1152921513573296704] = ???;  stack[1152921513573296712] = ???;  //  dest_result_addr=1152921513573296704 |  dest_result_addr=1152921513573296712
        // 0x00ED5B24: ADD x29, sp, #0x10         | X29 = (1152921513573296688 + 16) = 1152921513573296704 (0x1000000216712A40);
        // 0x00ED5B28: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00ED5B2C: LDRB w8, [x20, #0xe64]     | W8 = (bool)static_value_03734E64;       
        // 0x00ED5B30: MOV x19, x0                | X19 = 1152921513573308720 (0x1000000216715930);//ML01
        // 0x00ED5B34: TBNZ w8, #0, #0xed5b50     | if (static_value_03734E64 == true) goto label_0;
        // 0x00ED5B38: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00ED5B3C: LDR x8, [x8, #0xc20]       | X8 = 0x2B90D78;                         
        // 0x00ED5B40: LDR w0, [x8]               | W0 = 0x1A22;                            
        // 0x00ED5B44: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A22, ????);     
        // 0x00ED5B48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00ED5B4C: STRB w8, [x20, #0xe64]     | static_value_03734E64 = true;            //  dest_result_addr=57888356
        label_0:
        // 0x00ED5B50: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00ED5B54: LDR x8, [x8, #0xb40]       | X8 = 1152921504854183936;               
        // 0x00ED5B58: LDR x0, [x8]               | X0 = typeof(FingerGestures.FingerList); 
        FingerGestures.FingerList val_1 = null;
        // 0x00ED5B5C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(FingerGestures.FingerList), ????);
        // 0x00ED5B60: MOV x20, x0                | X20 = 1152921504854183936 (0x100000000EBE1000);//ML01
        // 0x00ED5B64: BL #0xed4fe0               | .ctor();                                
        val_1 = new FingerGestures.FingerList();
        // 0x00ED5B68: STR x20, [x19, #0x18]      | this.Fingers = typeof(FingerGestures.FingerList);  //  dest_result_addr=1152921513573308744
        this.Fingers = val_1;
        // 0x00ED5B6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ED5B70: MOV x0, x19                | X0 = 1152921513573308720 (0x1000000216715930);//ML01
        // 0x00ED5B74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ED5B78: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ED5B7C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ED5B80 (15555456), len: 40  VirtAddr: 0x00ED5B80 RVA: 0x00ED5B80 token: 100683960 methodIndex: 27612 delegateWrapperIndex: 0 methodInvoker: 0
    public void Reset()
    {
        //
        // Disasemble & Code
        // 0x00ED5B80: STP x20, x19, [sp, #-0x20]! | stack[1152921513573412784] = ???;  stack[1152921513573412792] = ???;  //  dest_result_addr=1152921513573412784 |  dest_result_addr=1152921513573412792
        // 0x00ED5B84: STP x29, x30, [sp, #0x10]  | stack[1152921513573412800] = ???;  stack[1152921513573412808] = ???;  //  dest_result_addr=1152921513573412800 |  dest_result_addr=1152921513573412808
        // 0x00ED5B88: ADD x29, sp, #0x10         | X29 = (1152921513573412784 + 16) = 1152921513573412800 (0x100000021672EFC0);
        // 0x00ED5B8C: LDR x19, [x0, #0x18]       | X19 = this.Fingers; //P2                
        // 0x00ED5B90: CBNZ x19, #0xed5b98        | if (this.Fingers != null) goto label_0; 
        if(this.Fingers != null)
        {
            goto label_0;
        }
        // 0x00ED5B94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ED5B98: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ED5B9C: MOV x0, x19                | X0 = this.Fingers;//m1                  
        // 0x00ED5BA0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ED5BA4: B #0xed53b8                | this.Fingers.Clear(); return;           
        this.Fingers.Clear();
        return;
    
    }

}
