using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonProperty
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285EADC
        private Newtonsoft.Json.Bson.BsonString <Name>k__BackingField; //  0x00000010
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285EB18
        private Newtonsoft.Json.Bson.BsonToken <Value>k__BackingField; //  0x00000018
        
        // Properties
        public Newtonsoft.Json.Bson.BsonString Name { get; set; }
        public Newtonsoft.Json.Bson.BsonToken Value { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD1D3C (11345212), len: 8  VirtAddr: 0x00AD1D3C RVA: 0x00AD1D3C token: 100684790 methodIndex: 47379 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonProperty()
        {
            //
            // Disasemble & Code
            // 0x00AD1D3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1D40: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1830 (11343920), len: 8  VirtAddr: 0x00AD1830 RVA: 0x00AD1830 token: 100684791 methodIndex: 47380 delegateWrapperIndex: 0 methodInvoker: 0
        public Newtonsoft.Json.Bson.BsonString get_Name()
        {
            //
            // Disasemble & Code
            // 0x00AD1830: LDR x0, [x0, #0x10]        | X0 = this.<Name>k__BackingField; //P2   
            // 0x00AD1834: RET                        |  return (Newtonsoft.Json.Bson.BsonString)this.<Name>k__BackingField;
            return this.<Name>k__BackingField;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonString, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1D8C (11345292), len: 8  VirtAddr: 0x00AD1D8C RVA: 0x00AD1D8C token: 100684792 methodIndex: 47381 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Name(Newtonsoft.Json.Bson.BsonString value)
        {
            //
            // Disasemble & Code
            // 0x00AD1D8C: STR x1, [x0, #0x10]        | this.<Name>k__BackingField = value;      //  dest_result_addr=1152921513725538368
            this.<Name>k__BackingField = value;
            // 0x00AD1D90: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1828 (11343912), len: 8  VirtAddr: 0x00AD1828 RVA: 0x00AD1828 token: 100684793 methodIndex: 47382 delegateWrapperIndex: 0 methodInvoker: 0
        public Newtonsoft.Json.Bson.BsonToken get_Value()
        {
            //
            // Disasemble & Code
            // 0x00AD1828: LDR x0, [x0, #0x18]        | X0 = this.<Value>k__BackingField; //P2  
            // 0x00AD182C: RET                        |  return (Newtonsoft.Json.Bson.BsonToken)this.<Value>k__BackingField;
            return this.<Value>k__BackingField;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonToken, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1D94 (11345300), len: 8  VirtAddr: 0x00AD1D94 RVA: 0x00AD1D94 token: 100684794 methodIndex: 47383 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Value(Newtonsoft.Json.Bson.BsonToken value)
        {
            //
            // Disasemble & Code
            // 0x00AD1D94: STR x1, [x0, #0x18]        | this.<Value>k__BackingField = value;     //  dest_result_addr=1152921513725778760
            this.<Value>k__BackingField = value;
            // 0x00AD1D98: RET                        |  return;                                
            return;
        
        }
    
    }

}
