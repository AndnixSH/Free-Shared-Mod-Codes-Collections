using UnityEngine;

namespace ILRuntime.Runtime.Debugger.Protocol
{
    public enum AttachResults
    {
        // Fields
        OK = 0
        ,AlreadyAttached = 1
        
    
    }

}
