using UnityEngine;

namespace ILRuntime.Mono.Cecil.PE
{
    internal class BinaryStreamReader : BinaryReader
    {
        // Properties
        public int Position { get; set; }
        public int Length { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x011E05F0 (18744816), len: 64  VirtAddr: 0x011E05F0 RVA: 0x011E05F0 token: 100664525 methodIndex: 20284 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Position()
        {
            //
            // Disasemble & Code
            // 0x011E05F0: STP x20, x19, [sp, #-0x20]! | stack[1152921509560851168] = ???;  stack[1152921509560851176] = ???;  //  dest_result_addr=1152921509560851168 |  dest_result_addr=1152921509560851176
            // 0x011E05F4: STP x29, x30, [sp, #0x10]  | stack[1152921509560851184] = ???;  stack[1152921509560851192] = ???;  //  dest_result_addr=1152921509560851184 |  dest_result_addr=1152921509560851192
            // 0x011E05F8: ADD x29, sp, #0x10         | X29 = (1152921509560851168 + 16) = 1152921509560851184 (0x1000000127481AF0);
            // 0x011E05FC: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E0600: LDP x9, x1, [x8, #0x160]   | X9 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); X1 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); //  | 
            // 0x011E0604: BLR x9                     | X0 = this.get_BaseStream();             
            System.IO.Stream val_1 = this.BaseStream;
            // 0x011E0608: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x011E060C: CBNZ x19, #0x11e0614       | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x011E0610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x011E0614: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x011E0618: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x011E061C: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_1A0; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_1A8; //  | 
            // 0x011E0620: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_1A0();
            // 0x011E0624: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0628: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E062C: RET                        |  return (System.Int32)val_1;            
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0630 (18744880), len: 72  VirtAddr: 0x011E0630 RVA: 0x011E0630 token: 100664526 methodIndex: 20285 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Position(int value)
        {
            //
            // Disasemble & Code
            // 0x011E0630: STP x20, x19, [sp, #-0x20]! | stack[1152921509560971360] = ???;  stack[1152921509560971368] = ???;  //  dest_result_addr=1152921509560971360 |  dest_result_addr=1152921509560971368
            // 0x011E0634: STP x29, x30, [sp, #0x10]  | stack[1152921509560971376] = ???;  stack[1152921509560971384] = ???;  //  dest_result_addr=1152921509560971376 |  dest_result_addr=1152921509560971384
            // 0x011E0638: ADD x29, sp, #0x10         | X29 = (1152921509560971360 + 16) = 1152921509560971376 (0x100000012749F070);
            // 0x011E063C: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E0640: MOV w19, w1                | W19 = value;//m1                        
            // 0x011E0644: LDP x9, x8, [x8, #0x160]   | X9 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); X8 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); //  | 
            // 0x011E0648: MOV x1, x8                 | X1 = 31876840 (0x1E666E8);//ML01        
            // 0x011E064C: BLR x9                     | X0 = this.get_BaseStream();             
            System.IO.Stream val_1 = this.BaseStream;
            // 0x011E0650: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x011E0654: CBNZ x20, #0x11e065c       | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x011E0658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x011E065C: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x011E0660: SXTW x1, w19               | X1 = (long)(int)(value);                
            // 0x011E0664: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x011E0668: LDP x3, x2, [x8, #0x1b0]   | X3 = typeof(System.IO.Stream).__il2cppRuntimeField_1B0; X2 = typeof(System.IO.Stream).__il2cppRuntimeField_1B8; //  | 
            // 0x011E066C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0670: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E0674: BR x3                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_1B0;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_1B0;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0678 (18744952), len: 64  VirtAddr: 0x011E0678 RVA: 0x011E0678 token: 100664527 methodIndex: 20286 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Length()
        {
            //
            // Disasemble & Code
            // 0x011E0678: STP x20, x19, [sp, #-0x20]! | stack[1152921509561091552] = ???;  stack[1152921509561091560] = ???;  //  dest_result_addr=1152921509561091552 |  dest_result_addr=1152921509561091560
            // 0x011E067C: STP x29, x30, [sp, #0x10]  | stack[1152921509561091568] = ???;  stack[1152921509561091576] = ???;  //  dest_result_addr=1152921509561091568 |  dest_result_addr=1152921509561091576
            // 0x011E0680: ADD x29, sp, #0x10         | X29 = (1152921509561091552 + 16) = 1152921509561091568 (0x10000001274BC5F0);
            // 0x011E0684: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E0688: LDP x9, x1, [x8, #0x160]   | X9 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); X1 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); //  | 
            // 0x011E068C: BLR x9                     | X0 = this.get_BaseStream();             
            System.IO.Stream val_1 = this.BaseStream;
            // 0x011E0690: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x011E0694: CBNZ x19, #0x11e069c       | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x011E0698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x011E069C: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x011E06A0: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x011E06A4: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_190; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_198; //  | 
            // 0x011E06A8: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_190();
            // 0x011E06AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E06B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E06B4: RET                        |  return (System.Int32)val_1;            
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011E06B8 (18745016), len: 8  VirtAddr: 0x011E06B8 RVA: 0x011E06B8 token: 100664528 methodIndex: 20287 delegateWrapperIndex: 0 methodInvoker: 0
        public BinaryStreamReader(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            // 0x011E06B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011E06BC: B #0x1e664fc               | this..ctor(input:  stream); return;     
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E06C0 (18745024), len: 80  VirtAddr: 0x011E06C0 RVA: 0x011E06C0 token: 100664529 methodIndex: 20288 delegateWrapperIndex: 0 methodInvoker: 0
        public void Advance(int bytes)
        {
            //
            // Disasemble & Code
            // 0x011E06C0: STP x20, x19, [sp, #-0x20]! | stack[1152921509561331936] = ???;  stack[1152921509561331944] = ???;  //  dest_result_addr=1152921509561331936 |  dest_result_addr=1152921509561331944
            // 0x011E06C4: STP x29, x30, [sp, #0x10]  | stack[1152921509561331952] = ???;  stack[1152921509561331960] = ???;  //  dest_result_addr=1152921509561331952 |  dest_result_addr=1152921509561331960
            // 0x011E06C8: ADD x29, sp, #0x10         | X29 = (1152921509561331936 + 16) = 1152921509561331952 (0x10000001274F70F0);
            // 0x011E06CC: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E06D0: MOV w19, w1                | W19 = bytes;//m1                        
            // 0x011E06D4: LDP x9, x8, [x8, #0x160]   | X9 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); X8 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); //  | 
            // 0x011E06D8: MOV x1, x8                 | X1 = 31876840 (0x1E666E8);//ML01        
            // 0x011E06DC: BLR x9                     | X0 = this.get_BaseStream();             
            System.IO.Stream val_1 = this.BaseStream;
            // 0x011E06E0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x011E06E4: CBNZ x20, #0x11e06ec       | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x011E06E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x011E06EC: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x011E06F0: SXTW x1, w19               | X1 = (long)(int)(bytes);                
            // 0x011E06F4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x011E06F8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x011E06FC: LDR x4, [x8, #0x240]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_240;
            // 0x011E0700: LDR x3, [x8, #0x248]       | X3 = typeof(System.IO.Stream).__il2cppRuntimeField_248;
            // 0x011E0704: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0708: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E070C: BR x4                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0710 (18745104), len: 80  VirtAddr: 0x011E0710 RVA: 0x011E0710 token: 100664530 methodIndex: 20289 delegateWrapperIndex: 0 methodInvoker: 0
        public void MoveTo(uint position)
        {
            //
            // Disasemble & Code
            // 0x011E0710: STP x20, x19, [sp, #-0x20]! | stack[1152921509561452128] = ???;  stack[1152921509561452136] = ???;  //  dest_result_addr=1152921509561452128 |  dest_result_addr=1152921509561452136
            // 0x011E0714: STP x29, x30, [sp, #0x10]  | stack[1152921509561452144] = ???;  stack[1152921509561452152] = ???;  //  dest_result_addr=1152921509561452144 |  dest_result_addr=1152921509561452152
            // 0x011E0718: ADD x29, sp, #0x10         | X29 = (1152921509561452128 + 16) = 1152921509561452144 (0x1000000127514670);
            // 0x011E071C: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E0720: MOV w20, w1                | W20 = position;//m1                     
            // 0x011E0724: LDP x9, x8, [x8, #0x160]   | X9 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); X8 = public System.IO.Stream System.IO.BinaryReader::get_BaseStream(); //  | 
            // 0x011E0728: MOV x1, x8                 | X1 = 31876840 (0x1E666E8);//ML01        
            // 0x011E072C: BLR x9                     | X0 = this.get_BaseStream();             
            System.IO.Stream val_1 = this.BaseStream;
            // 0x011E0730: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x011E0734: CBNZ x19, #0x11e073c       | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x011E0738: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x011E073C: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x011E0740: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x011E0744: MOV w1, w20                | W1 = position;//m1                      
            // 0x011E0748: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x011E074C: LDR x4, [x8, #0x240]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_240;
            // 0x011E0750: LDR x3, [x8, #0x248]       | X3 = typeof(System.IO.Stream).__il2cppRuntimeField_248;
            // 0x011E0754: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0758: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E075C: BR x4                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E0760 (18745184), len: 60  VirtAddr: 0x011E0760 RVA: 0x011E0760 token: 100664531 methodIndex: 20290 delegateWrapperIndex: 0 methodInvoker: 0
        public void Align(int align)
        {
            //
            // Disasemble & Code
            // 0x011E0760: STP x20, x19, [sp, #-0x20]! | stack[1152921509561568224] = ???;  stack[1152921509561568232] = ???;  //  dest_result_addr=1152921509561568224 |  dest_result_addr=1152921509561568232
            // 0x011E0764: STP x29, x30, [sp, #0x10]  | stack[1152921509561568240] = ???;  stack[1152921509561568248] = ???;  //  dest_result_addr=1152921509561568240 |  dest_result_addr=1152921509561568248
            // 0x011E0768: ADD x29, sp, #0x10         | X29 = (1152921509561568224 + 16) = 1152921509561568240 (0x1000000127530BF0);
            // 0x011E076C: MOV w19, w1                | W19 = align;//m1                        
            // 0x011E0770: MOV x20, x0                | X20 = 1152921509561580256 (0x1000000127533AE0);//ML01
            // 0x011E0774: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_1 = this.Position;
            // 0x011E0778: ADD w8, w19, w0            | W8 = (align + val_1);                   
            int val_2 = align + val_1;
            // 0x011E077C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E0780: SUB w8, w8, #1             | W8 = ((align + val_1) - 1);             
            val_2 = val_2 - 1;
            // 0x011E0784: NEG w9, w19                | W9 = -(align);                          
            // 0x011E0788: AND w8, w8, w9             | W8 = (((align + val_1) - 1) & align);   
            val_2 = val_2 & (-align);
            // 0x011E078C: SUB w1, w8, w0             | W1 = ((((align + val_1) - 1) & align) - val_1);
            align = val_2 - val_1;
            // 0x011E0790: MOV x0, x20                | X0 = 1152921509561580256 (0x1000000127533AE0);//ML01
            // 0x011E0794: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E0798: B #0x11e06c0               | this.Advance(bytes:  align = val_2 - val_1); return;
            this.Advance(bytes:  align);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x011E079C (18745244), len: 80  VirtAddr: 0x011E079C RVA: 0x011E079C token: 100664532 methodIndex: 20291 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.PE.DataDirectory ReadDataDirectory()
        {
            //
            // Disasemble & Code
            // 0x011E079C: STP x20, x19, [sp, #-0x20]! | stack[1152921509561680224] = ???;  stack[1152921509561680232] = ???;  //  dest_result_addr=1152921509561680224 |  dest_result_addr=1152921509561680232
            // 0x011E07A0: STP x29, x30, [sp, #0x10]  | stack[1152921509561680240] = ???;  stack[1152921509561680248] = ???;  //  dest_result_addr=1152921509561680240 |  dest_result_addr=1152921509561680248
            // 0x011E07A4: ADD x29, sp, #0x10         | X29 = (1152921509561680224 + 16) = 1152921509561680240 (0x100000012754C170);
            // 0x011E07A8: MOV x19, x0                | X19 = 1152921509561692256 (0x100000012754F060);//ML01
            // 0x011E07AC: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E07B0: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x011E07B4: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x011E07B8: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_1 = this.ReadUInt32();
            // 0x011E07BC: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.PE.BinaryStreamReader);
            // 0x011E07C0: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x011E07C4: MOV x0, x19                | X0 = 1152921509561692256 (0x100000012754F060);//ML01
            // 0x011E07C8: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x011E07CC: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x011E07D0: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_2 = this.ReadUInt32();
            // 0x011E07D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011E07D8: MOV w8, w20                | W8 = val_1;//m1                         
            // 0x011E07DC: BFI x8, x0, #0x20, #0x20   | X8 = val_1 | val_2                      
            // 0x011E07E0: MOV x0, x8                 | X0 = val_1;//m1                         
            // 0x011E07E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011E07E8: RET                        |  return new ILRuntime.Mono.Cecil.PE.DataDirectory() {VirtualAddress = val_1, Size = val_2};
            return new ILRuntime.Mono.Cecil.PE.DataDirectory() {VirtualAddress = val_1, Size = val_2};
            //  |  // // {name=val_0.VirtualAddress, type=System.UInt32, size=4, nGRN=0 offset=0 }
            //  |  // // {name=val_0.Size, type=System.UInt32, size=4, nGRN=0 offset=4 }
        
        }
    
    }

}
