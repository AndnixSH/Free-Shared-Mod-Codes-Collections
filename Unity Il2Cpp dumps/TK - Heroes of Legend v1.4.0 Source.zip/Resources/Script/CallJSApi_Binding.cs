using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CallJSApi_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static System.Func<System.Reflection.MethodInfo, bool> <>f__am$cache0; // static_offset: 0x00000060
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0142BDD4 (21151188), len: 8  VirtAddr: 0x0142BDD4 RVA: 0x0142BDD4 token: 100664122 methodIndex: 30167 delegateWrapperIndex: 0 methodInvoker: 0
        public CallJSApi_Binding()
        {
            //
            // Disasemble & Code
            // 0x0142BDD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BDD8: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0142BDDC (21151196), len: 4548  VirtAddr: 0x0142BDDC RVA: 0x0142BDDC token: 100664123 methodIndex: 30168 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            var val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45;
            //  | 
            System.Type[] val_46;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_47;
            //  | 
            System.Type[] val_48;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_49;
            //  | 
            System.Type[] val_50;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_51;
            //  | 
            System.Type[] val_52;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_53;
            //  | 
            System.Type[] val_54;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_55;
            //  | 
            System.Type[] val_56;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_57;
            //  | 
            System.Type[] val_58;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_59;
            //  | 
            System.Type[] val_60;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_61;
            //  | 
            System.Type[] val_62;
            //  | 
            System.Type val_63;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_64;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_65;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_66;
            // 0x0142BDDC: STP x28, x27, [sp, #-0x60]! | stack[1152921510105439184] = ???;  stack[1152921510105439192] = ???;  //  dest_result_addr=1152921510105439184 |  dest_result_addr=1152921510105439192
            // 0x0142BDE0: STP x26, x25, [sp, #0x10]  | stack[1152921510105439200] = ???;  stack[1152921510105439208] = ???;  //  dest_result_addr=1152921510105439200 |  dest_result_addr=1152921510105439208
            // 0x0142BDE4: STP x24, x23, [sp, #0x20]  | stack[1152921510105439216] = ???;  stack[1152921510105439224] = ???;  //  dest_result_addr=1152921510105439216 |  dest_result_addr=1152921510105439224
            // 0x0142BDE8: STP x22, x21, [sp, #0x30]  | stack[1152921510105439232] = ???;  stack[1152921510105439240] = ???;  //  dest_result_addr=1152921510105439232 |  dest_result_addr=1152921510105439240
            // 0x0142BDEC: STP x20, x19, [sp, #0x40]  | stack[1152921510105439248] = ???;  stack[1152921510105439256] = ???;  //  dest_result_addr=1152921510105439248 |  dest_result_addr=1152921510105439256
            // 0x0142BDF0: STP x29, x30, [sp, #0x50]  | stack[1152921510105439264] = ???;  stack[1152921510105439272] = ???;  //  dest_result_addr=1152921510105439264 |  dest_result_addr=1152921510105439272
            // 0x0142BDF4: ADD x29, sp, #0x50         | X29 = (1152921510105439184 + 80) = 1152921510105439264 (0x1000000147BDDC20);
            // 0x0142BDF8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142BDFC: LDRB w8, [x20, #0x1b]      | W8 = (bool)static_value_0373701B;       
            // 0x0142BE00: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0142BE04: TBNZ w8, #0, #0x142be20    | if (static_value_0373701B == true) goto label_0;
            // 0x0142BE08: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x0142BE0C: LDR x8, [x8, #0x6f0]       | X8 = 0x2B900D4;                         
            // 0x0142BE10: LDR w0, [x8]               | W0 = 0x16F9;                            
            // 0x0142BE14: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F9, ????);     
            // 0x0142BE18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142BE1C: STRB w8, [x20, #0x1b]      | static_value_0373701B = true;            //  dest_result_addr=57896987
            label_0:
            // 0x0142BE20: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x0142BE24: LDR x8, [x8, #0x340]       | X8 = 1152921504783577088;               
            // 0x0142BE28: LDR x0, [x8]               | X0 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0);
            object val_1 = null;
            // 0x0142BE2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CallJSApi_Binding.<Register>c__AnonStorey0), ????);
            // 0x0142BE30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BE34: MOV x21, x0                | X21 = 1152921504783577088 (0x100000000A88B000);//ML01
            // 0x0142BE38: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x0142BE3C: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x0142BE40: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x0142BE44: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x0142BE48: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x0142BE4C: LDR x8, [x8, #0xfd8]       | X8 = 1152921504901255168;               
            // 0x0142BE50: LDR x20, [x8]              | X20 = typeof(CallJSApi);                
            // 0x0142BE54: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142BE58: TBZ w8, #0, #0x142be68     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0142BE5C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142BE60: CBNZ w8, #0x142be68        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0142BE64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0142BE68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BE6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BE70: MOV x1, x20                | X1 = 1152921504901255168 (0x10000000118C5000);//ML01
            // 0x0142BE74: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142BE78: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142BE7C: CBNZ x20, #0x142be84       | if (val_2 != null) goto label_3;        
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x0142BE80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x0142BE84: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0142BE88: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x0142BE8C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142BE90: LDR x9, [x8, #0x540]       | X9 = typeof(System.Type).__il2cppRuntimeField_540;
            // 0x0142BE94: LDR x2, [x8, #0x548]       | X2 = typeof(System.Type).__il2cppRuntimeField_548;
            // 0x0142BE98: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_540();
            // 0x0142BE9C: ADRP x25, #0x363e000       | X25 = 56877056 (0x363E000);             
            // 0x0142BEA0: LDR x25, [x25, #0x500]     | X25 = 1152921504783523840;              
            // 0x0142BEA4: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x0142BEA8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142BEAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142BEB0: LDR x9, [x8, #0x60]        | X9 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__am$cache0;
            // 0x0142BEB4: CBNZ x9, #0x142bf04        | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__am$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__am$cache0) != null)
            {
                goto label_4;
            }
            // 0x0142BEB8: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x0142BEBC: ADRP x9, #0x3645000        | X9 = 56905728 (0x3645000);              
            // 0x0142BEC0: LDR x8, [x8, #0x520]       | X8 = 1152921510105264496;               
            // 0x0142BEC4: LDR x9, [x9, #0x480]       | X9 = 1152921504688103424;               
            // 0x0142BEC8: LDR x23, [x8]              | X23 = static System.Boolean ILRuntime.Runtime.Generated.CallJSApi_Binding::<Register>m__0(System.Reflection.MethodInfo t);
            // 0x0142BECC: LDR x0, [x9]               | X0 = typeof(System.Func<T, TResult>);   
            System.Func<System.Reflection.MethodInfo, System.Boolean> val_3 = null;
            // 0x0142BED0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T, TResult>), ????);
            // 0x0142BED4: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x0142BED8: LDR x8, [x8, #0xb60]       | X8 = 1152921510105265520;               
            // 0x0142BEDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BEE0: MOV x2, x23                | X2 = 1152921510105264496 (0x1000000147BB3170);//ML01
            // 0x0142BEE4: MOV x24, x0                | X24 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x0142BEE8: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Reflection.MethodInfo, System.Boolean>::.ctor(object object, IntPtr method);
            // 0x0142BEEC: BL #0x21cb02c              | .ctor(object:  0, method:  static System.Boolean ILRuntime.Runtime.Generated.CallJSApi_Binding::<Register>m__0(System.Reflection.MethodInfo t));
            val_3 = new System.Func<System.Reflection.MethodInfo, System.Boolean>(object:  0, method:  static System.Boolean ILRuntime.Runtime.Generated.CallJSApi_Binding::<Register>m__0(System.Reflection.MethodInfo t));
            // 0x0142BEF0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142BEF4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142BEF8: STR x24, [x8, #0x60]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__am$cache0 = typeof(System.Func<T, TResult>);  //  dest_result_addr=1152921504783528032
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__am$cache0 = val_3;
            // 0x0142BEFC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142BF00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            label_4:
            // 0x0142BF04: ADRP x27, #0x3638000       | X27 = 56852480 (0x3638000);             
            // 0x0142BF08: LDR x2, [x8, #0x60]        | X2 = typeof(System.Func<T, TResult>);   
            // 0x0142BF0C: LDR x27, [x27, #0xe28]     | X27 = 1152921510105266544;              
            // 0x0142BF10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BF14: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x0142BF18: LDR x3, [x27]              | X3 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Reflection.MethodInfo>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate);
            // 0x0142BF1C: BL #0xb6ed64               | X0 = System.Linq.Enumerable.Where<System.Reflection.FieldInfo>(source:  0, predicate:  val_2);
            System.Collections.Generic.IEnumerable<TSource> val_4 = System.Linq.Enumerable.Where<System.Reflection.FieldInfo>(source:  0, predicate:  val_2);
            // 0x0142BF20: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x0142BF24: LDR x8, [x8, #0xf98]       | X8 = 1152921510105271664;               
            // 0x0142BF28: MOV x1, x0                 | X1 = val_4;//m1                         
            // 0x0142BF2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BF30: LDR x2, [x8]               | X2 = public static TSource[] System.Linq.Enumerable::ToArray<System.Reflection.MethodInfo>(System.Collections.Generic.IEnumerable<TSource> source);
            // 0x0142BF34: BL #0x23ddbdc              | X0 = System.Linq.Enumerable.ToArray<System.Type>(source:  0);
            TSource[] val_5 = System.Linq.Enumerable.ToArray<System.Type>(source:  0);
            // 0x0142BF38: ADRP x28, #0x35ef000       | X28 = 56553472 (0x35EF000);             
            // 0x0142BF3C: LDR x28, [x28, #0xff0]     | X28 = 1152921504987155056;              
            // 0x0142BF40: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x0142BF44: LDR x23, [x28]             | X23 = typeof(System.Type[]);            
            // 0x0142BF48: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142BF4C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142BF50: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142BF54: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142BF58: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142BF5C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142BF60: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142BF64: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142BF68: MOV x23, x0                | X23 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142BF6C: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0142BF70: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142BF74: TBZ w9, #0, #0x142bf88     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0142BF78: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142BF7C: CBNZ w9, #0x142bf88        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0142BF80: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142BF84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_6:
            // 0x0142BF88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BF8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BF90: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142BF94: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142BF98: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x0142BF9C: CBNZ x23, #0x142bfa4       | if ( != null) goto label_7;             
            if(null != null)
            {
                goto label_7;
            }
            // 0x0142BFA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_7:
            // 0x0142BFA4: CBZ x24, #0x142bfc8        | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142BFA8: LDR x8, [x23]              | X8 = ;                                  
            // 0x0142BFAC: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x0142BFB0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142BFB4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x0142BFB8: CBNZ x0, #0x142bfc8        | if (val_6 != null) goto label_9;        
            if(val_6 != null)
            {
                goto label_9;
            }
            // 0x0142BFBC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x0142BFC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BFC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_9:
            // 0x0142BFC8: LDR w8, [x23, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142BFCC: CBNZ w8, #0x142bfdc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_10;
            // 0x0142BFD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x0142BFD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142BFD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_10:
            // 0x0142BFDC: STR x24, [x23, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;
            // 0x0142BFE0: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x0142BFE4: LDR x8, [x8, #0x228]       | X8 = 1152921504954501264;               
            // 0x0142BFE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142BFEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142BFF0: LDR x1, [x8]               | X1 = typeof(System.Object[]);           
            // 0x0142BFF4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142BFF8: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x0142BFFC: CBZ x24, #0x142c020        | if (val_7 == null) goto label_12;       
            if(val_7 == null)
            {
                goto label_12;
            }
            // 0x0142C000: LDR x8, [x23]              | X8 = ;                                  
            // 0x0142C004: MOV x0, x24                | X0 = val_7;//m1                         
            // 0x0142C008: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C00C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x0142C010: CBNZ x0, #0x142c020        | if (val_7 != null) goto label_12;       
            if(val_7 != null)
            {
                goto label_12;
            }
            // 0x0142C014: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x0142C018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C01C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_12:
            // 0x0142C020: LDR w8, [x23, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C024: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142C028: B.HI #0x142c038            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_13;
            // 0x0142C02C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x0142C030: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C034: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_13:
            // 0x0142C038: STR x24, [x23, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;
            // 0x0142C03C: CBNZ x21, #0x142c044       | if ( != 0) goto label_14;               
            if(null != 0)
            {
                goto label_14;
            }
            // 0x0142C040: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_14:
            // 0x0142C044: STR x23, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = null;
            // 0x0142C048: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x0142C04C: ADRP x9, #0x3645000        | X9 = 56905728 (0x3645000);              
            // 0x0142C050: LDR x8, [x8, #0xbb0]       | X8 = 1152921510105317744;               
            // 0x0142C054: LDR x9, [x9, #0x480]       | X9 = 1152921504688103424;               
            // 0x0142C058: LDR x23, [x8]              | X23 = System.Boolean CallJSApi_Binding.<Register>c__AnonStorey0::<>m__0(System.Reflection.MethodInfo t);
            // 0x0142C05C: LDR x0, [x9]               | X0 = typeof(System.Func<T, TResult>);   
            System.Func<System.Reflection.MethodInfo, System.Boolean> val_8 = null;
            // 0x0142C060: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T, TResult>), ????);
            // 0x0142C064: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x0142C068: LDR x8, [x8, #0xb60]       | X8 = 1152921510105265520;               
            // 0x0142C06C: MOV x1, x21                | X1 = 1152921504783577088 (0x100000000A88B000);//ML01
            // 0x0142C070: MOV x2, x23                | X2 = 1152921510105317744 (0x1000000147BC0170);//ML01
            // 0x0142C074: MOV x24, x0                | X24 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x0142C078: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Reflection.MethodInfo, System.Boolean>::.ctor(object object, IntPtr method);
            // 0x0142C07C: BL #0x21cb02c              | .ctor(object:  val_1, method:  System.Boolean CallJSApi_Binding.<Register>c__AnonStorey0::<>m__0(System.Reflection.MethodInfo t));
            val_8 = new System.Func<System.Reflection.MethodInfo, System.Boolean>(object:  val_1, method:  System.Boolean CallJSApi_Binding.<Register>c__AnonStorey0::<>m__0(System.Reflection.MethodInfo t));
            // 0x0142C080: LDR x3, [x27]              | X3 = public static System.Collections.Generic.IEnumerable<TSource> System.Linq.Enumerable::Where<System.Reflection.MethodInfo>(System.Collections.Generic.IEnumerable<TSource> source, System.Func<TSource, bool> predicate);
            // 0x0142C084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C088: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x0142C08C: MOV x2, x24                | X2 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x0142C090: BL #0xb6ed64               | X0 = System.Linq.Enumerable.Where<System.Reflection.FieldInfo>(source:  0, predicate:  val_5);
            System.Collections.Generic.IEnumerable<TSource> val_9 = System.Linq.Enumerable.Where<System.Reflection.FieldInfo>(source:  0, predicate:  val_5);
            // 0x0142C094: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x0142C098: LDR x8, [x8, #0x820]       | X8 = 1152921510105322864;               
            // 0x0142C09C: MOV x1, x0                 | X1 = val_9;//m1                         
            // 0x0142C0A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C0A4: LDR x2, [x8]               | X2 = public static System.Reflection.MethodInfo System.Linq.Enumerable::Single<System.Reflection.MethodInfo>(System.Collections.Generic.IEnumerable<TSource> source);
            // 0x0142C0A8: BL #0x23dcd6c              | X0 = System.Linq.Enumerable.Single<System.Reflection.MethodInfo>(source:  0);
            System.Reflection.MethodInfo val_10 = System.Linq.Enumerable.Single<System.Reflection.MethodInfo>(source:  0);
            // 0x0142C0AC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C0B0: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x0142C0B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C0B8: LDR x23, [x8]              | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache0;
            val_45 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache0;
            // 0x0142C0BC: CBNZ x23, #0x142c108       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache0 != null) goto label_15;
            if(val_45 != null)
            {
                goto label_15;
            }
            // 0x0142C0C0: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x0142C0C4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C0C8: LDR x8, [x8, #0x100]       | X8 = 1152921510105327984;               
            // 0x0142C0CC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C0D0: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJsFun_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C0D4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x0142C0D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C0E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C0E4: MOV x2, x23                | X2 = 1152921510105327984 (0x1000000147BC2970);//ML01
            // 0x0142C0E8: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C0EC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJsFun_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJsFun_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C0F0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C0F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C0F8: STR x24, [x8]              | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527936
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache0 = val_11;
            // 0x0142C0FC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C100: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C104: LDR x23, [x8]              | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_45 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache0;
            label_15:
            // 0x0142C108: CBNZ x19, #0x142c110       | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x0142C10C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJsFun_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_16:
            // 0x0142C110: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C114: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C118: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x0142C11C: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C120: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_45);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_45);
            // 0x0142C124: CBZ x21, #0x142c14c        | if ( == 0) goto label_17;               
            if(null == 0)
            {
                goto label_17;
            }
            // 0x0142C128: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C12C: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C130: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C138: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C13C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C140: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_46 = null;
            // 0x0142C144: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_46;
            // 0x0142C148: B #0x142c174               |  goto label_18;                         
            goto label_18;
            label_17:
            // 0x0142C14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            // 0x0142C150: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C154: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C158: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C15C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C160: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C164: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C168: STR x0, [x21, #0x10]       | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = null;
            // 0x0142C16C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            // 0x0142C170: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_46 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_18:
            // 0x0142C174: CBNZ x20, #0x142c17c       | if (val_2 != null) goto label_19;       
            if(val_2 != null)
            {
                goto label_19;
            }
            // 0x0142C178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_19:
            // 0x0142C17C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x0142C180: LDR x8, [x8, #0x48]        | X8 = (string**)(1152921510105329008)("CallLoadJsObjToCs");
            // 0x0142C184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C188: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142C18C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142C190: LDR x1, [x8]               | X1 = "CallLoadJsObjToCs";               
            // 0x0142C194: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142C198: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C19C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142C1A0: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "CallLoadJsObjToCs", bindingAttr:  30, binder:  0, types:  val_46, modifiers:  0);
            System.Reflection.MethodInfo val_12 = val_2.GetMethod(name:  "CallLoadJsObjToCs", bindingAttr:  30, binder:  0, types:  val_46, modifiers:  0);
            // 0x0142C1A4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C1A8: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x0142C1AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C1B0: LDR x23, [x8, #8]          | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache1;
            val_47 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache1;
            // 0x0142C1B4: CBNZ x23, #0x142c200       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache1 != null) goto label_20;
            if(val_47 != null)
            {
                goto label_20;
            }
            // 0x0142C1B8: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x0142C1BC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C1C0: LDR x8, [x8, #0x8b8]       | X8 = 1152921510105333216;               
            // 0x0142C1C4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C1C8: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallLoadJsObjToCs_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C1CC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13 = null;
            // 0x0142C1D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C1D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C1D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C1DC: MOV x2, x23                | X2 = 1152921510105333216 (0x1000000147BC3DE0);//ML01
            // 0x0142C1E0: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C1E4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallLoadJsObjToCs_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallLoadJsObjToCs_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C1E8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C1EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C1F0: STR x24, [x8, #8]          | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527944
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache1 = val_13;
            // 0x0142C1F4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C1F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C1FC: LDR x23, [x8, #8]          | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_47 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache1;
            label_20:
            // 0x0142C200: CBNZ x19, #0x142c208       | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x0142C204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallLoadJsObjToCs_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_21:
            // 0x0142C208: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C20C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C210: MOV x1, x22                | X1 = val_12;//m1                        
            // 0x0142C214: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C218: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_47);
            X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_47);
            // 0x0142C21C: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C220: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C224: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C228: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0142C22C: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C230: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C234: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x0142C238: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142C23C: LDR x9, [x9, #0xcb8]       | X9 = 1152921504608604160;               
            // 0x0142C240: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_48 = null;
            // 0x0142C244: LDR x23, [x9]              | X23 = typeof(System.Boolean);           
            // 0x0142C248: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142C24C: TBZ w9, #0, #0x142c260     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x0142C250: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142C254: CBNZ w9, #0x142c260        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x0142C258: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142C25C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_23:
            // 0x0142C260: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C264: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C268: MOV x1, x23                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0142C26C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C270: MOV x23, x0                | X23 = val_14;//m1                       
            // 0x0142C274: CBNZ x22, #0x142c27c       | if ( != null) goto label_24;            
            if(null != null)
            {
                goto label_24;
            }
            // 0x0142C278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_24:
            // 0x0142C27C: CBZ x23, #0x142c2a0        | if (val_14 == null) goto label_26;      
            if(val_14 == null)
            {
                goto label_26;
            }
            // 0x0142C280: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C284: MOV x0, x23                | X0 = val_14;//m1                        
            // 0x0142C288: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C28C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142C290: CBNZ x0, #0x142c2a0        | if (val_14 != null) goto label_26;      
            if(val_14 != null)
            {
                goto label_26;
            }
            // 0x0142C294: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x0142C298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C29C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_26:
            // 0x0142C2A0: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C2A4: CBNZ w8, #0x142c2b4        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_27;
            // 0x0142C2A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x0142C2AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C2B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_27:
            // 0x0142C2B4: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_14;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_14;
            // 0x0142C2B8: CBZ x21, #0x142c2c4        | if ( == 0) goto label_28;               
            if(null == 0)
            {
                goto label_28;
            }
            // 0x0142C2BC: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_48;
            // 0x0142C2C0: B #0x142c2d4               |  goto label_29;                         
            goto label_29;
            label_28:
            // 0x0142C2C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x0142C2C8: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_48;
            // 0x0142C2CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x0142C2D0: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_48 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_29:
            // 0x0142C2D4: CBNZ x20, #0x142c2dc       | if (val_2 != null) goto label_30;       
            if(val_2 != null)
            {
                goto label_30;
            }
            // 0x0142C2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_30:
            // 0x0142C2DC: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x0142C2E0: LDR x8, [x8, #0x768]       | X8 = (string**)(1152921510105338336)("SetNeedNext");
            // 0x0142C2E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C2E8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142C2EC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142C2F0: LDR x1, [x8]               | X1 = "SetNeedNext";                     
            // 0x0142C2F4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142C2F8: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C2FC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142C300: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "SetNeedNext", bindingAttr:  30, binder:  0, types:  val_48, modifiers:  0);
            System.Reflection.MethodInfo val_15 = val_2.GetMethod(name:  "SetNeedNext", bindingAttr:  30, binder:  0, types:  val_48, modifiers:  0);
            // 0x0142C304: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C308: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x0142C30C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C310: LDR x23, [x8, #0x10]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache2;
            val_49 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache2;
            // 0x0142C314: CBNZ x23, #0x142c360       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache2 != null) goto label_31;
            if(val_49 != null)
            {
                goto label_31;
            }
            // 0x0142C318: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x0142C31C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C320: LDR x8, [x8, #0x5e0]       | X8 = 1152921510105342528;               
            // 0x0142C324: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C328: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::SetNeedNext_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C32C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_16 = null;
            // 0x0142C330: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C334: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C338: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C33C: MOV x2, x23                | X2 = 1152921510105342528 (0x1000000147BC6240);//ML01
            // 0x0142C340: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C344: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::SetNeedNext_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::SetNeedNext_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C348: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C34C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C350: STR x24, [x8, #0x10]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527952
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache2 = val_16;
            // 0x0142C354: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C358: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C35C: LDR x23, [x8, #0x10]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_49 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache2;
            label_31:
            // 0x0142C360: CBNZ x19, #0x142c368       | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x0142C364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::SetNeedNext_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_32:
            // 0x0142C368: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C36C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C370: MOV x1, x22                | X1 = val_15;//m1                        
            // 0x0142C374: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C378: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_15, func:  val_49);
            X1.RegisterCLRMethodRedirection(mi:  val_15, func:  val_49);
            // 0x0142C37C: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C380: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C384: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C388: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0142C38C: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C390: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C394: ADRP x27, #0x3616000       | X27 = 56713216 (0x3616000);             
            // 0x0142C398: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142C39C: LDR x27, [x27, #0x888]     | X27 = 1152921504996170800;              
            // 0x0142C3A0: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_50 = null;
            // 0x0142C3A4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142C3A8: LDR x23, [x27]             | X23 = typeof(System.Byte[]);            
            // 0x0142C3AC: TBZ w9, #0, #0x142c3c0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x0142C3B0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142C3B4: CBNZ w9, #0x142c3c0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x0142C3B8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142C3BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x0142C3C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C3C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C3C8: MOV x1, x23                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142C3CC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C3D0: MOV x23, x0                | X23 = val_17;//m1                       
            // 0x0142C3D4: CBNZ x22, #0x142c3dc       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x0142C3D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_35:
            // 0x0142C3DC: CBZ x23, #0x142c400        | if (val_17 == null) goto label_37;      
            if(val_17 == null)
            {
                goto label_37;
            }
            // 0x0142C3E0: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C3E4: MOV x0, x23                | X0 = val_17;//m1                        
            // 0x0142C3E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C3EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x0142C3F0: CBNZ x0, #0x142c400        | if (val_17 != null) goto label_37;      
            if(val_17 != null)
            {
                goto label_37;
            }
            // 0x0142C3F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x0142C3F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C3FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_37:
            // 0x0142C400: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C404: CBNZ w8, #0x142c414        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x0142C408: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x0142C40C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C410: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_38:
            // 0x0142C414: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;
            // 0x0142C418: CBZ x21, #0x142c424        | if ( == 0) goto label_39;               
            if(null == 0)
            {
                goto label_39;
            }
            // 0x0142C41C: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_50;
            // 0x0142C420: B #0x142c434               |  goto label_40;                         
            goto label_40;
            label_39:
            // 0x0142C424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            // 0x0142C428: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_50;
            // 0x0142C42C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            // 0x0142C430: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_50 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_40:
            // 0x0142C434: CBNZ x20, #0x142c43c       | if (val_2 != null) goto label_41;       
            if(val_2 != null)
            {
                goto label_41;
            }
            // 0x0142C438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_41:
            // 0x0142C43C: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x0142C440: LDR x8, [x8, #0x270]       | X8 = (string**)(1152921510105347648)("GetJSHash");
            // 0x0142C444: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C448: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142C44C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142C450: LDR x1, [x8]               | X1 = "GetJSHash";                       
            // 0x0142C454: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142C458: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C45C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142C460: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "GetJSHash", bindingAttr:  30, binder:  0, types:  val_50, modifiers:  0);
            System.Reflection.MethodInfo val_18 = val_2.GetMethod(name:  "GetJSHash", bindingAttr:  30, binder:  0, types:  val_50, modifiers:  0);
            // 0x0142C464: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C468: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x0142C46C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C470: LDR x23, [x8, #0x18]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache3;
            val_51 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache3;
            // 0x0142C474: CBNZ x23, #0x142c4c0       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache3 != null) goto label_42;
            if(val_51 != null)
            {
                goto label_42;
            }
            // 0x0142C478: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x0142C47C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C480: LDR x8, [x8, #0x388]       | X8 = 1152921510105351840;               
            // 0x0142C484: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C488: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJSHash_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C48C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_19 = null;
            // 0x0142C490: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C498: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C49C: MOV x2, x23                | X2 = 1152921510105351840 (0x1000000147BC86A0);//ML01
            // 0x0142C4A0: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C4A4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJSHash_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJSHash_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C4A8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C4AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C4B0: STR x24, [x8, #0x18]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527960
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache3 = val_19;
            // 0x0142C4B4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C4B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C4BC: LDR x23, [x8, #0x18]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_51 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache3;
            label_42:
            // 0x0142C4C0: CBNZ x19, #0x142c4c8       | if (X1 != 0) goto label_43;             
            if(X1 != 0)
            {
                goto label_43;
            }
            // 0x0142C4C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJSHash_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_43:
            // 0x0142C4C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C4CC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C4D0: MOV x1, x22                | X1 = val_18;//m1                        
            // 0x0142C4D4: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C4D8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_51);
            X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_51);
            // 0x0142C4DC: CBZ x21, #0x142c504        | if ( == 0) goto label_44;               
            if(null == 0)
            {
                goto label_44;
            }
            // 0x0142C4E0: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C4E4: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C4E8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C4EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C4F0: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C4F4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C4F8: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_52 = null;
            // 0x0142C4FC: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_52;
            // 0x0142C500: B #0x142c52c               |  goto label_45;                         
            goto label_45;
            label_44:
            // 0x0142C504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            // 0x0142C508: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C50C: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C510: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C514: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C518: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C51C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C520: STR x0, [x21, #0x10]       | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = null;
            // 0x0142C524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            // 0x0142C528: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_52 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_45:
            // 0x0142C52C: CBNZ x20, #0x142c534       | if (val_2 != null) goto label_46;       
            if(val_2 != null)
            {
                goto label_46;
            }
            // 0x0142C530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_46:
            // 0x0142C534: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x0142C538: LDR x8, [x8, #0x508]       | X8 = (string**)(1152921510105352864)("GetJsNum");
            // 0x0142C53C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C540: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142C544: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142C548: LDR x1, [x8]               | X1 = "GetJsNum";                        
            // 0x0142C54C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142C550: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C554: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142C558: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "GetJsNum", bindingAttr:  30, binder:  0, types:  val_52, modifiers:  0);
            System.Reflection.MethodInfo val_20 = val_2.GetMethod(name:  "GetJsNum", bindingAttr:  30, binder:  0, types:  val_52, modifiers:  0);
            // 0x0142C55C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C560: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x0142C564: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C568: LDR x23, [x8, #0x20]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache4;
            val_53 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache4;
            // 0x0142C56C: CBNZ x23, #0x142c5b8       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache4 != null) goto label_47;
            if(val_53 != null)
            {
                goto label_47;
            }
            // 0x0142C570: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0142C574: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C578: LDR x8, [x8, #0x928]       | X8 = 1152921510105357056;               
            // 0x0142C57C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C580: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJsNum_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C584: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_21 = null;
            // 0x0142C588: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C58C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C590: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C594: MOV x2, x23                | X2 = 1152921510105357056 (0x1000000147BC9B00);//ML01
            // 0x0142C598: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C59C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJsNum_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJsNum_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C5A0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C5A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C5A8: STR x24, [x8, #0x20]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527968
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache4 = val_21;
            // 0x0142C5AC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C5B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C5B4: LDR x23, [x8, #0x20]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_53 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache4;
            label_47:
            // 0x0142C5B8: CBNZ x19, #0x142c5c0       | if (X1 != 0) goto label_48;             
            if(X1 != 0)
            {
                goto label_48;
            }
            // 0x0142C5BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJsNum_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_48:
            // 0x0142C5C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C5C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C5C8: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x0142C5CC: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C5D0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_53);
            X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_53);
            // 0x0142C5D4: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C5D8: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C5DC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C5E0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142C5E4: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C5E8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C5EC: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142C5F0: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142C5F4: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142C5F8: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_54 = null;
            // 0x0142C5FC: LDR x23, [x9]              | X23 = typeof(System.String);            
            // 0x0142C600: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142C604: TBZ w9, #0, #0x142c618     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_50;
            // 0x0142C608: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142C60C: CBNZ w9, #0x142c618        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
            // 0x0142C610: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142C614: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_50:
            // 0x0142C618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C61C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C620: MOV x1, x23                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142C624: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_22 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C628: MOV x23, x0                | X23 = val_22;//m1                       
            // 0x0142C62C: CBNZ x22, #0x142c634       | if ( != null) goto label_51;            
            if(null != null)
            {
                goto label_51;
            }
            // 0x0142C630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_51:
            // 0x0142C634: CBZ x23, #0x142c658        | if (val_22 == null) goto label_53;      
            if(val_22 == null)
            {
                goto label_53;
            }
            // 0x0142C638: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C63C: MOV x0, x23                | X0 = val_22;//m1                        
            // 0x0142C640: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C644: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_22, ????);     
            // 0x0142C648: CBNZ x0, #0x142c658        | if (val_22 != null) goto label_53;      
            if(val_22 != null)
            {
                goto label_53;
            }
            // 0x0142C64C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_22, ????);     
            // 0x0142C650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C654: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_53:
            // 0x0142C658: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C65C: CBNZ w8, #0x142c66c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_54;
            // 0x0142C660: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_22, ????);     
            // 0x0142C664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C668: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_54:
            // 0x0142C66C: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_22;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_22;
            // 0x0142C670: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x0142C674: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x0142C678: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C67C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C680: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x0142C684: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_23 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C688: MOV x23, x0                | X23 = val_23;//m1                       
            // 0x0142C68C: CBZ x23, #0x142c6b0        | if (val_23 == null) goto label_56;      
            if(val_23 == null)
            {
                goto label_56;
            }
            // 0x0142C690: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C694: MOV x0, x23                | X0 = val_23;//m1                        
            // 0x0142C698: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C69C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_23, ????);     
            // 0x0142C6A0: CBNZ x0, #0x142c6b0        | if (val_23 != null) goto label_56;      
            if(val_23 != null)
            {
                goto label_56;
            }
            // 0x0142C6A4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_23, ????);     
            // 0x0142C6A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C6AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_56:
            // 0x0142C6B0: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C6B4: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142C6B8: B.HI #0x142c6c8            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_57;
            // 0x0142C6BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x0142C6C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C6C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_57:
            // 0x0142C6C8: STR x23, [x22, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_23;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_23;
            // 0x0142C6CC: CBZ x21, #0x142c6d8        | if ( == 0) goto label_58;               
            if(null == 0)
            {
                goto label_58;
            }
            // 0x0142C6D0: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_54;
            // 0x0142C6D4: B #0x142c6e8               |  goto label_59;                         
            goto label_59;
            label_58:
            // 0x0142C6D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            // 0x0142C6DC: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_54;
            // 0x0142C6E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            // 0x0142C6E4: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_54 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_59:
            // 0x0142C6E8: CBNZ x20, #0x142c6f0       | if (val_2 != null) goto label_60;       
            if(val_2 != null)
            {
                goto label_60;
            }
            // 0x0142C6EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_60:
            // 0x0142C6F0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0142C6F4: LDR x8, [x8, #0x610]       | X8 = (string**)(1152921510105366272)("LoadDataFromStreamPath");
            // 0x0142C6F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C6FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142C700: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142C704: LDR x1, [x8]               | X1 = "LoadDataFromStreamPath";          
            // 0x0142C708: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142C70C: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C710: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142C714: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "LoadDataFromStreamPath", bindingAttr:  30, binder:  0, types:  val_54, modifiers:  0);
            System.Reflection.MethodInfo val_24 = val_2.GetMethod(name:  "LoadDataFromStreamPath", bindingAttr:  30, binder:  0, types:  val_54, modifiers:  0);
            // 0x0142C718: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C71C: MOV x22, x0                | X22 = val_24;//m1                       
            // 0x0142C720: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C724: LDR x23, [x8, #0x28]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache5;
            val_55 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache5;
            // 0x0142C728: CBNZ x23, #0x142c774       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache5 != null) goto label_61;
            if(val_55 != null)
            {
                goto label_61;
            }
            // 0x0142C72C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0142C730: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C734: LDR x8, [x8, #0x700]       | X8 = 1152921510105370480;               
            // 0x0142C738: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C73C: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::LoadDataFromStreamPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C740: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25 = null;
            // 0x0142C744: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C74C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C750: MOV x2, x23                | X2 = 1152921510105370480 (0x1000000147BCCF70);//ML01
            // 0x0142C754: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C758: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::LoadDataFromStreamPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::LoadDataFromStreamPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C75C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C760: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C764: STR x24, [x8, #0x28]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527976
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache5 = val_25;
            // 0x0142C768: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C76C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C770: LDR x23, [x8, #0x28]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_55 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache5;
            label_61:
            // 0x0142C774: CBNZ x19, #0x142c77c       | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x0142C778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::LoadDataFromStreamPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_62:
            // 0x0142C77C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C780: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C784: MOV x1, x22                | X1 = val_24;//m1                        
            // 0x0142C788: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C78C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_55);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_55);
            // 0x0142C790: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C794: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C798: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C79C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142C7A0: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C7A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C7A8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142C7AC: LDR x23, [x27]             | X23 = typeof(System.Byte[]);            
            // 0x0142C7B0: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_56 = null;
            // 0x0142C7B4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142C7B8: TBZ w9, #0, #0x142c7cc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_64;
            // 0x0142C7BC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142C7C0: CBNZ w9, #0x142c7cc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_64;
            // 0x0142C7C4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142C7C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_64:
            // 0x0142C7CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C7D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C7D4: MOV x1, x23                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142C7D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_26 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C7DC: MOV x23, x0                | X23 = val_26;//m1                       
            // 0x0142C7E0: CBNZ x22, #0x142c7e8       | if ( != null) goto label_65;            
            if(null != null)
            {
                goto label_65;
            }
            // 0x0142C7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_65:
            // 0x0142C7E8: CBZ x23, #0x142c80c        | if (val_26 == null) goto label_67;      
            if(val_26 == null)
            {
                goto label_67;
            }
            // 0x0142C7EC: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C7F0: MOV x0, x23                | X0 = val_26;//m1                        
            // 0x0142C7F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C7F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_26, ????);     
            // 0x0142C7FC: CBNZ x0, #0x142c80c        | if (val_26 != null) goto label_67;      
            if(val_26 != null)
            {
                goto label_67;
            }
            // 0x0142C800: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_26, ????);     
            // 0x0142C804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C808: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_67:
            // 0x0142C80C: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C810: CBNZ w8, #0x142c820        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_68;
            // 0x0142C814: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_26, ????);     
            // 0x0142C818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C81C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_68:
            // 0x0142C820: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_26;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_26;
            // 0x0142C824: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0142C828: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0142C82C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C834: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142C838: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_27 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C83C: MOV x23, x0                | X23 = val_27;//m1                       
            // 0x0142C840: CBZ x23, #0x142c864        | if (val_27 == null) goto label_70;      
            if(val_27 == null)
            {
                goto label_70;
            }
            // 0x0142C844: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C848: MOV x0, x23                | X0 = val_27;//m1                        
            // 0x0142C84C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C850: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_27, ????);     
            // 0x0142C854: CBNZ x0, #0x142c864        | if (val_27 != null) goto label_70;      
            if(val_27 != null)
            {
                goto label_70;
            }
            // 0x0142C858: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_27, ????);     
            // 0x0142C85C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C860: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_70:
            // 0x0142C864: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C868: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142C86C: B.HI #0x142c87c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_71;
            // 0x0142C870: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_27, ????);     
            // 0x0142C874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C878: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_71:
            // 0x0142C87C: STR x23, [x22, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_27;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_27;
            // 0x0142C880: CBZ x21, #0x142c88c        | if ( == 0) goto label_72;               
            if(null == 0)
            {
                goto label_72;
            }
            // 0x0142C884: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_56;
            // 0x0142C888: B #0x142c89c               |  goto label_73;                         
            goto label_73;
            label_72:
            // 0x0142C88C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            // 0x0142C890: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_56;
            // 0x0142C894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            // 0x0142C898: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_56 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_73:
            // 0x0142C89C: CBNZ x20, #0x142c8a4       | if (val_2 != null) goto label_74;       
            if(val_2 != null)
            {
                goto label_74;
            }
            // 0x0142C8A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_74:
            // 0x0142C8A4: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x0142C8A8: LDR x8, [x8, #0x348]       | X8 = (string**)(1152921510105379696)("Bytes2String");
            // 0x0142C8AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C8B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142C8B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142C8B8: LDR x1, [x8]               | X1 = "Bytes2String";                    
            // 0x0142C8BC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142C8C0: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C8C4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142C8C8: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "Bytes2String", bindingAttr:  30, binder:  0, types:  val_56, modifiers:  0);
            System.Reflection.MethodInfo val_28 = val_2.GetMethod(name:  "Bytes2String", bindingAttr:  30, binder:  0, types:  val_56, modifiers:  0);
            // 0x0142C8CC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C8D0: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x0142C8D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C8D8: LDR x23, [x8, #0x30]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache6;
            val_57 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache6;
            // 0x0142C8DC: CBNZ x23, #0x142c928       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache6 != null) goto label_75;
            if(val_57 != null)
            {
                goto label_75;
            }
            // 0x0142C8E0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x0142C8E4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142C8E8: LDR x8, [x8, #0xc88]       | X8 = 1152921510105383888;               
            // 0x0142C8EC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142C8F0: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::Bytes2String_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142C8F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29 = null;
            // 0x0142C8F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142C8FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C900: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C904: MOV x2, x23                | X2 = 1152921510105383888 (0x1000000147BD03D0);//ML01
            // 0x0142C908: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C90C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::Bytes2String_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::Bytes2String_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142C910: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C914: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C918: STR x24, [x8, #0x30]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527984
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache6 = val_29;
            // 0x0142C91C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142C920: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142C924: LDR x23, [x8, #0x30]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_57 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache6;
            label_75:
            // 0x0142C928: CBNZ x19, #0x142c930       | if (X1 != 0) goto label_76;             
            if(X1 != 0)
            {
                goto label_76;
            }
            // 0x0142C92C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::Bytes2String_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_76:
            // 0x0142C930: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142C934: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142C938: MOV x1, x22                | X1 = val_28;//m1                        
            // 0x0142C93C: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142C940: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_28, func:  val_57);
            X1.RegisterCLRMethodRedirection(mi:  val_28, func:  val_57);
            // 0x0142C944: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142C948: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C94C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142C950: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142C954: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142C958: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142C95C: ADRP x9, #0x35cc000        | X9 = 56410112 (0x35CC000);              
            // 0x0142C960: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142C964: LDR x9, [x9, #0xbe0]       | X9 = 1152921504690233344;               
            // 0x0142C968: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_58 = null;
            // 0x0142C96C: LDR x23, [x9]              | X23 = typeof(UnityEngine.AndroidJavaClass);
            // 0x0142C970: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142C974: TBZ w9, #0, #0x142c988     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_78;
            // 0x0142C978: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142C97C: CBNZ w9, #0x142c988        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_78;
            // 0x0142C980: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142C984: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_78:
            // 0x0142C988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C98C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C990: MOV x1, x23                | X1 = 1152921504690233344 (0x1000000004F86000);//ML01
            // 0x0142C994: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_30 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C998: MOV x23, x0                | X23 = val_30;//m1                       
            // 0x0142C99C: CBNZ x22, #0x142c9a4       | if ( != null) goto label_79;            
            if(null != null)
            {
                goto label_79;
            }
            // 0x0142C9A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_79:
            // 0x0142C9A4: CBZ x23, #0x142c9c8        | if (val_30 == null) goto label_81;      
            if(val_30 == null)
            {
                goto label_81;
            }
            // 0x0142C9A8: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142C9AC: MOV x0, x23                | X0 = val_30;//m1                        
            // 0x0142C9B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142C9B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_30, ????);     
            // 0x0142C9B8: CBNZ x0, #0x142c9c8        | if (val_30 != null) goto label_81;      
            if(val_30 != null)
            {
                goto label_81;
            }
            // 0x0142C9BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_30, ????);     
            // 0x0142C9C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C9C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_30, ????);     
            label_81:
            // 0x0142C9C8: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142C9CC: CBNZ w8, #0x142c9dc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_82;
            // 0x0142C9D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_30, ????);     
            // 0x0142C9D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142C9D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_30, ????);     
            label_82:
            // 0x0142C9DC: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_30;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_30;
            // 0x0142C9E0: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0142C9E4: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0142C9E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142C9EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142C9F0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142C9F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_31 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142C9F8: MOV x23, x0                | X23 = val_31;//m1                       
            // 0x0142C9FC: CBZ x23, #0x142ca20        | if (val_31 == null) goto label_84;      
            if(val_31 == null)
            {
                goto label_84;
            }
            // 0x0142CA00: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142CA04: MOV x0, x23                | X0 = val_31;//m1                        
            // 0x0142CA08: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142CA0C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_31, ????);     
            // 0x0142CA10: CBNZ x0, #0x142ca20        | if (val_31 != null) goto label_84;      
            if(val_31 != null)
            {
                goto label_84;
            }
            // 0x0142CA14: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_31, ????);     
            // 0x0142CA18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CA1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            label_84:
            // 0x0142CA20: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142CA24: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142CA28: B.HI #0x142ca38            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_85;
            // 0x0142CA2C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_31, ????);     
            // 0x0142CA30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CA34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            label_85:
            // 0x0142CA38: STR x23, [x22, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_31;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_31;
            // 0x0142CA3C: CBZ x21, #0x142ca48        | if ( == 0) goto label_86;               
            if(null == 0)
            {
                goto label_86;
            }
            // 0x0142CA40: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_58;
            // 0x0142CA44: B #0x142ca58               |  goto label_87;                         
            goto label_87;
            label_86:
            // 0x0142CA48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            // 0x0142CA4C: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_58;
            // 0x0142CA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            // 0x0142CA54: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_58 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_87:
            // 0x0142CA58: CBNZ x20, #0x142ca60       | if (val_2 != null) goto label_88;       
            if(val_2 != null)
            {
                goto label_88;
            }
            // 0x0142CA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_88:
            // 0x0142CA60: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x0142CA64: LDR x8, [x8, #0x580]       | X8 = (string**)(1152921510105393104)("GetJavaStaticAJO");
            // 0x0142CA68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CA6C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142CA70: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142CA74: LDR x1, [x8]               | X1 = "GetJavaStaticAJO";                
            // 0x0142CA78: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142CA7C: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CA80: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142CA84: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "GetJavaStaticAJO", bindingAttr:  30, binder:  0, types:  val_58, modifiers:  0);
            System.Reflection.MethodInfo val_32 = val_2.GetMethod(name:  "GetJavaStaticAJO", bindingAttr:  30, binder:  0, types:  val_58, modifiers:  0);
            // 0x0142CA88: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CA8C: MOV x22, x0                | X22 = val_32;//m1                       
            // 0x0142CA90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CA94: LDR x23, [x8, #0x38]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache7;
            val_59 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache7;
            // 0x0142CA98: CBNZ x23, #0x142cae4       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache7 != null) goto label_89;
            if(val_59 != null)
            {
                goto label_89;
            }
            // 0x0142CA9C: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x0142CAA0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142CAA4: LDR x8, [x8, #0x798]       | X8 = 1152921510105397312;               
            // 0x0142CAA8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142CAAC: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaStaticAJO_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142CAB0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_33 = null;
            // 0x0142CAB4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142CAB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CABC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CAC0: MOV x2, x23                | X2 = 1152921510105397312 (0x1000000147BD3840);//ML01
            // 0x0142CAC4: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142CAC8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaStaticAJO_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaStaticAJO_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142CACC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CAD0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CAD4: STR x24, [x8, #0x38]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783527992
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache7 = val_33;
            // 0x0142CAD8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CADC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CAE0: LDR x23, [x8, #0x38]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_59 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache7;
            label_89:
            // 0x0142CAE4: CBNZ x19, #0x142caec       | if (X1 != 0) goto label_90;             
            if(X1 != 0)
            {
                goto label_90;
            }
            // 0x0142CAE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaStaticAJO_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_90:
            // 0x0142CAEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CAF0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142CAF4: MOV x1, x22                | X1 = val_32;//m1                        
            // 0x0142CAF8: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142CAFC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_32, func:  val_59);
            X1.RegisterCLRMethodRedirection(mi:  val_32, func:  val_59);
            // 0x0142CB00: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142CB04: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CB08: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142CB0C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142CB10: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CB14: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142CB18: ADRP x27, #0x35ce000       | X27 = 56418304 (0x35CE000);             
            // 0x0142CB1C: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142CB20: LDR x27, [x27, #0xd70]     | X27 = 1152921504690180096;              
            // 0x0142CB24: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_60 = null;
            // 0x0142CB28: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142CB2C: LDR x23, [x27]             | X23 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142CB30: TBZ w9, #0, #0x142cb44     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_92;
            // 0x0142CB34: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142CB38: CBNZ w9, #0x142cb44        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_92;
            // 0x0142CB3C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142CB40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_92:
            // 0x0142CB44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142CB48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142CB4C: MOV x1, x23                | X1 = 1152921504690180096 (0x1000000004F79000);//ML01
            // 0x0142CB50: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_34 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142CB54: MOV x23, x0                | X23 = val_34;//m1                       
            // 0x0142CB58: CBNZ x22, #0x142cb60       | if ( != null) goto label_93;            
            if(null != null)
            {
                goto label_93;
            }
            // 0x0142CB5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_93:
            // 0x0142CB60: CBZ x23, #0x142cb84        | if (val_34 == null) goto label_95;      
            if(val_34 == null)
            {
                goto label_95;
            }
            // 0x0142CB64: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142CB68: MOV x0, x23                | X0 = val_34;//m1                        
            // 0x0142CB6C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142CB70: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_34, ????);     
            // 0x0142CB74: CBNZ x0, #0x142cb84        | if (val_34 != null) goto label_95;      
            if(val_34 != null)
            {
                goto label_95;
            }
            // 0x0142CB78: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_34, ????);     
            // 0x0142CB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CB80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
            label_95:
            // 0x0142CB84: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142CB88: CBNZ w8, #0x142cb98        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_96;
            // 0x0142CB8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_34, ????);     
            // 0x0142CB90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CB94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
            label_96:
            // 0x0142CB98: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_34;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_34;
            // 0x0142CB9C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0142CBA0: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0142CBA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142CBA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142CBAC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142CBB0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_35 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142CBB4: MOV x23, x0                | X23 = val_35;//m1                       
            // 0x0142CBB8: CBZ x23, #0x142cbdc        | if (val_35 == null) goto label_98;      
            if(val_35 == null)
            {
                goto label_98;
            }
            // 0x0142CBBC: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142CBC0: MOV x0, x23                | X0 = val_35;//m1                        
            // 0x0142CBC4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142CBC8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_35, ????);     
            // 0x0142CBCC: CBNZ x0, #0x142cbdc        | if (val_35 != null) goto label_98;      
            if(val_35 != null)
            {
                goto label_98;
            }
            // 0x0142CBD0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_35, ????);     
            // 0x0142CBD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CBD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_98:
            // 0x0142CBDC: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142CBE0: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142CBE4: B.HI #0x142cbf4            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_99;
            // 0x0142CBE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_35, ????);     
            // 0x0142CBEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CBF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_99:
            // 0x0142CBF4: STR x23, [x22, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_35;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_35;
            // 0x0142CBF8: CBZ x21, #0x142cc04        | if ( == 0) goto label_100;              
            if(null == 0)
            {
                goto label_100;
            }
            // 0x0142CBFC: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_60;
            // 0x0142CC00: B #0x142cc14               |  goto label_101;                        
            goto label_101;
            label_100:
            // 0x0142CC04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            // 0x0142CC08: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_60;
            // 0x0142CC0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            // 0x0142CC10: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_60 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_101:
            // 0x0142CC14: CBNZ x20, #0x142cc1c       | if (val_2 != null) goto label_102;      
            if(val_2 != null)
            {
                goto label_102;
            }
            // 0x0142CC18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_102:
            // 0x0142CC1C: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x0142CC20: LDR x8, [x8, #0x4b0]       | X8 = (string**)(1152921510105406528)("GetJavaString");
            // 0x0142CC24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CC28: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142CC2C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142CC30: LDR x1, [x8]               | X1 = "GetJavaString";                   
            // 0x0142CC34: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142CC38: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CC3C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142CC40: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "GetJavaString", bindingAttr:  30, binder:  0, types:  val_60, modifiers:  0);
            System.Reflection.MethodInfo val_36 = val_2.GetMethod(name:  "GetJavaString", bindingAttr:  30, binder:  0, types:  val_60, modifiers:  0);
            // 0x0142CC44: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CC48: MOV x22, x0                | X22 = val_36;//m1                       
            // 0x0142CC4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CC50: LDR x23, [x8, #0x40]       | X23 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache8;
            val_61 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache8;
            // 0x0142CC54: CBNZ x23, #0x142cca0       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache8 != null) goto label_103;
            if(val_61 != null)
            {
                goto label_103;
            }
            // 0x0142CC58: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x0142CC5C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142CC60: LDR x8, [x8, #0x3f8]       | X8 = 1152921510105410720;               
            // 0x0142CC64: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142CC68: LDR x23, [x8]              | X23 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142CC6C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_37 = null;
            // 0x0142CC70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142CC74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CC78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CC7C: MOV x2, x23                | X2 = 1152921510105410720 (0x1000000147BD6CA0);//ML01
            // 0x0142CC80: MOV x24, x0                | X24 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142CC84: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_37 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142CC88: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CC8C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CC90: STR x24, [x8, #0x40]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783528000
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache8 = val_37;
            // 0x0142CC94: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CC98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CC9C: LDR x23, [x8, #0x40]       | X23 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_61 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache8;
            label_103:
            // 0x0142CCA0: CBNZ x19, #0x142cca8       | if (X1 != 0) goto label_104;            
            if(X1 != 0)
            {
                goto label_104;
            }
            // 0x0142CCA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::GetJavaString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_104:
            // 0x0142CCA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CCAC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142CCB0: MOV x1, x22                | X1 = val_36;//m1                        
            // 0x0142CCB4: MOV x2, x23                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142CCB8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_36, func:  val_61);
            X1.RegisterCLRMethodRedirection(mi:  val_36, func:  val_61);
            // 0x0142CCBC: LDR x22, [x28]             | X22 = typeof(System.Type[]);            
            // 0x0142CCC0: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CCC4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0142CCC8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0142CCCC: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CCD0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142CCD4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x0142CCD8: LDR x23, [x27]             | X23 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142CCDC: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_62 = null;
            // 0x0142CCE0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142CCE4: TBZ w9, #0, #0x142ccf8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_106;
            // 0x0142CCE8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142CCEC: CBNZ w9, #0x142ccf8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_106;
            // 0x0142CCF0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142CCF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_106:
            // 0x0142CCF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142CCFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142CD00: MOV x1, x23                | X1 = 1152921504690180096 (0x1000000004F79000);//ML01
            // 0x0142CD04: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_38 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142CD08: MOV x23, x0                | X23 = val_38;//m1                       
            // 0x0142CD0C: CBNZ x22, #0x142cd14       | if ( != null) goto label_107;           
            if(null != null)
            {
                goto label_107;
            }
            // 0x0142CD10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_107:
            // 0x0142CD14: CBZ x23, #0x142cd38        | if (val_38 == null) goto label_109;     
            if(val_38 == null)
            {
                goto label_109;
            }
            // 0x0142CD18: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142CD1C: MOV x0, x23                | X0 = val_38;//m1                        
            // 0x0142CD20: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142CD24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_38, ????);     
            // 0x0142CD28: CBNZ x0, #0x142cd38        | if (val_38 != null) goto label_109;     
            if(val_38 != null)
            {
                goto label_109;
            }
            // 0x0142CD2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_38, ????);     
            // 0x0142CD30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CD34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            label_109:
            // 0x0142CD38: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142CD3C: CBNZ w8, #0x142cd4c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_110;
            // 0x0142CD40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_38, ????);     
            // 0x0142CD44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CD48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            label_110:
            // 0x0142CD4C: STR x23, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_38;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_38;
            // 0x0142CD50: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0142CD54: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0142CD58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142CD5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142CD60: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142CD64: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_39 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142CD68: MOV x23, x0                | X23 = val_39;//m1                       
            val_63 = val_39;
            // 0x0142CD6C: CBZ x23, #0x142cd90        | if (val_39 == null) goto label_112;     
            if(val_63 == null)
            {
                goto label_112;
            }
            // 0x0142CD70: LDR x8, [x22]              | X8 = ;                                  
            // 0x0142CD74: MOV x0, x23                | X0 = val_39;//m1                        
            // 0x0142CD78: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142CD7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_39, ????);     
            // 0x0142CD80: CBNZ x0, #0x142cd90        | if (val_39 != null) goto label_112;     
            if(val_63 != null)
            {
                goto label_112;
            }
            // 0x0142CD84: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_39, ????);     
            // 0x0142CD88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CD8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            label_112:
            // 0x0142CD90: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0142CD94: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0142CD98: B.HI #0x142cda8            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_113;
            // 0x0142CD9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_39, ????);     
            // 0x0142CDA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CDA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_39, ????);     
            label_113:
            // 0x0142CDA8: STR x23, [x22, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_39;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_63;
            // 0x0142CDAC: CBZ x21, #0x142cdb8        | if ( == 0) goto label_114;              
            if(null == 0)
            {
                goto label_114;
            }
            // 0x0142CDB0: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_62;
            // 0x0142CDB4: B #0x142cdc8               |  goto label_115;                        
            goto label_115;
            label_114:
            // 0x0142CDB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            // 0x0142CDBC: STR x22, [x21, #0x10]      | typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = typeof(System.Type[]);  //  dest_result_addr=1152921504783577104
            typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10 = val_62;
            // 0x0142CDC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            // 0x0142CDC4: LDR x22, [x21, #0x10]      | X22 = typeof(System.Type[]);            
            val_62 = typeof(CallJSApi_Binding.<Register>c__AnonStorey0).__il2cppRuntimeField_10;
            label_115:
            // 0x0142CDC8: CBNZ x20, #0x142cdd0       | if (val_2 != null) goto label_116;      
            if(val_2 != null)
            {
                goto label_116;
            }
            // 0x0142CDCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_116:
            // 0x0142CDD0: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0142CDD4: LDR x8, [x8, #0xb58]       | X8 = (string**)(1152921510105419936)("CallJavaAJO");
            // 0x0142CDD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CDDC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142CDE0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142CDE4: LDR x1, [x8]               | X1 = "CallJavaAJO";                     
            // 0x0142CDE8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142CDEC: MOV x4, x22                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142CDF0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142CDF4: BL #0x1b6e2ac              | X0 = val_2.GetMethod(name:  "CallJavaAJO", bindingAttr:  30, binder:  0, types:  val_62, modifiers:  0);
            System.Reflection.MethodInfo val_40 = val_2.GetMethod(name:  "CallJavaAJO", bindingAttr:  30, binder:  0, types:  val_62, modifiers:  0);
            // 0x0142CDF8: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CDFC: MOV x21, x0                | X21 = val_40;//m1                       
            // 0x0142CE00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CE04: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache9;
            val_64 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache9;
            // 0x0142CE08: CBNZ x22, #0x142ce54       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache9 != null) goto label_117;
            if(val_64 != null)
            {
                goto label_117;
            }
            // 0x0142CE0C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x0142CE10: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142CE14: LDR x8, [x8, #0x618]       | X8 = 1152921510105424128;               
            // 0x0142CE18: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0142CE1C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJavaAJO_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142CE20: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_41 = null;
            // 0x0142CE24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0142CE28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CE2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CE30: MOV x2, x22                | X2 = 1152921510105424128 (0x1000000147BDA100);//ML01
            // 0x0142CE34: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_63 = val_41;
            // 0x0142CE38: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJavaAJO_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_41 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJavaAJO_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0142CE3C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CE40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CE44: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783528008
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache9 = val_63;
            // 0x0142CE48: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CE4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CE50: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_64 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cache9;
            label_117:
            // 0x0142CE54: CBNZ x19, #0x142ce5c       | if (X1 != 0) goto label_118;            
            if(X1 != 0)
            {
                goto label_118;
            }
            // 0x0142CE58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CallJSApi_Binding::CallJavaAJO_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_118:
            // 0x0142CE5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CE60: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142CE64: MOV x1, x21                | X1 = val_40;//m1                        
            // 0x0142CE68: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0142CE6C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_40, func:  val_64);
            X1.RegisterCLRMethodRedirection(mi:  val_40, func:  val_64);
            // 0x0142CE70: CBNZ x20, #0x142ce78       | if (val_2 != null) goto label_119;      
            if(val_2 != null)
            {
                goto label_119;
            }
            // 0x0142CE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_119:
            // 0x0142CE78: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x0142CE7C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0142CE80: LDR x9, [x9, #0x30]        | X9 = (string**)(1152921510105425152)("jsStr");
            // 0x0142CE84: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142CE88: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142CE8C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x0142CE90: LDR x1, [x9]               | X1 = "jsStr";                           
            // 0x0142CE94: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0142CE98: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0142CE9C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CEA0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142CEA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CEA8: LDR x21, [x8, #0x50]       | X21 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheA;
            val_65 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheA;
            // 0x0142CEAC: CBNZ x21, #0x142cef8       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheA != null) goto label_120;
            if(val_65 != null)
            {
                goto label_120;
            }
            // 0x0142CEB0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x0142CEB4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0142CEB8: LDR x8, [x8, #0x30]        | X8 = 1152921510105425232;               
            // 0x0142CEBC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0142CEC0: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CallJSApi_Binding::get_jsStr_0(ref object o);
            // 0x0142CEC4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_42 = null;
            // 0x0142CEC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0142CECC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CED0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CED4: MOV x2, x21                | X2 = 1152921510105425232 (0x1000000147BDA550);//ML01
            // 0x0142CED8: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0142CEDC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CallJSApi_Binding::get_jsStr_0(ref object o));
            val_42 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CallJSApi_Binding::get_jsStr_0(ref object o));
            // 0x0142CEE0: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CEE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CEE8: STR x22, [x8, #0x50]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783528016
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheA = val_42;
            // 0x0142CEEC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CEF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CEF4: LDR x21, [x8, #0x50]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_65 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheA;
            label_120:
            // 0x0142CEF8: CBNZ x19, #0x142cf00       | if (X1 != 0) goto label_121;            
            if(X1 != 0)
            {
                goto label_121;
            }
            // 0x0142CEFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CallJSApi_Binding::get_jsStr_0(ref object o)), ????);
            label_121:
            // 0x0142CF00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CF04: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142CF08: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142CF0C: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0142CF10: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_2, getter:  val_65);
            X1.RegisterCLRFieldGetter(f:  val_2, getter:  val_65);
            // 0x0142CF14: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CF18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CF1C: LDR x21, [x8, #0x58]       | X21 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheB;
            val_66 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheB;
            // 0x0142CF20: CBNZ x21, #0x142cf6c       | if (ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheB != null) goto label_122;
            if(val_66 != null)
            {
                goto label_122;
            }
            // 0x0142CF24: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x0142CF28: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x0142CF2C: LDR x8, [x8, #0x7b8]       | X8 = 1152921510105426256;               
            // 0x0142CF30: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x0142CF34: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.CallJSApi_Binding::set_jsStr_0(ref object o, object v);
            // 0x0142CF38: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_43 = null;
            // 0x0142CF3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x0142CF40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142CF44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CF48: MOV x2, x21                | X2 = 1152921510105426256 (0x1000000147BDA950);//ML01
            // 0x0142CF4C: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x0142CF50: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CallJSApi_Binding::set_jsStr_0(ref object o, object v));
            val_43 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CallJSApi_Binding::set_jsStr_0(ref object o, object v));
            // 0x0142CF54: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CF58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CF5C: STR x22, [x8, #0x58]       | ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783528024
            ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheB = val_43;
            // 0x0142CF60: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Generated.CallJSApi_Binding);
            // 0x0142CF64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CallJSApi_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142CF68: LDR x21, [x8, #0x58]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_66 = ILRuntime.Runtime.Generated.CallJSApi_Binding.<>f__mg$cacheB;
            label_122:
            // 0x0142CF6C: CBNZ x19, #0x142cf74       | if (X1 != 0) goto label_123;            
            if(X1 != 0)
            {
                goto label_123;
            }
            // 0x0142CF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CallJSApi_Binding::set_jsStr_0(ref object o, object v)), ????);
            label_123:
            // 0x0142CF74: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142CF78: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142CF7C: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x0142CF80: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0142CF84: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0142CF88: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0142CF8C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0142CF90: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0142CF94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142CF98: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0142CF9C: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_2, setter:  val_66); return;
            X1.RegisterCLRFieldSetter(f:  val_2, setter:  val_66);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0142CFA8 (21155752), len: 772  VirtAddr: 0x0142CFA8 RVA: 0x0142CFA8 token: 100664124 methodIndex: 30169 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* CallJsFun_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            System.Object[] val_14;
            // 0x0142CFA8: STP x28, x27, [sp, #-0x60]! | stack[1152921510105743696] = ???;  stack[1152921510105743704] = ???;  //  dest_result_addr=1152921510105743696 |  dest_result_addr=1152921510105743704
            // 0x0142CFAC: STP x26, x25, [sp, #0x10]  | stack[1152921510105743712] = ???;  stack[1152921510105743720] = ???;  //  dest_result_addr=1152921510105743712 |  dest_result_addr=1152921510105743720
            // 0x0142CFB0: STP x24, x23, [sp, #0x20]  | stack[1152921510105743728] = ???;  stack[1152921510105743736] = ???;  //  dest_result_addr=1152921510105743728 |  dest_result_addr=1152921510105743736
            // 0x0142CFB4: STP x22, x21, [sp, #0x30]  | stack[1152921510105743744] = ???;  stack[1152921510105743752] = ???;  //  dest_result_addr=1152921510105743744 |  dest_result_addr=1152921510105743752
            // 0x0142CFB8: STP x20, x19, [sp, #0x40]  | stack[1152921510105743760] = ???;  stack[1152921510105743768] = ???;  //  dest_result_addr=1152921510105743760 |  dest_result_addr=1152921510105743768
            // 0x0142CFBC: STP x29, x30, [sp, #0x50]  | stack[1152921510105743776] = ???;  stack[1152921510105743784] = ???;  //  dest_result_addr=1152921510105743776 |  dest_result_addr=1152921510105743784
            // 0x0142CFC0: ADD x29, sp, #0x50         | X29 = (1152921510105743696 + 80) = 1152921510105743776 (0x1000000147C281A0);
            // 0x0142CFC4: SUB sp, sp, #0x10          | SP = (1152921510105743696 - 16) = 1152921510105743680 (0x1000000147C28140);
            // 0x0142CFC8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142CFCC: LDRB w8, [x20, #0x1c]      | W8 = (bool)static_value_0373701C;       
            // 0x0142CFD0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x0142CFD4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142CFD8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0142CFDC: TBNZ w8, #0, #0x142cff8    | if (static_value_0373701C == true) goto label_0;
            // 0x0142CFE0: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x0142CFE4: LDR x8, [x8, #0xfa8]       | X8 = 0x2B900B4;                         
            // 0x0142CFE8: LDR w0, [x8]               | W0 = 0x16F1;                            
            // 0x0142CFEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F1, ????);     
            // 0x0142CFF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142CFF4: STRB w8, [x20, #0x1c]      | static_value_0373701C = true;            //  dest_result_addr=57896988
            label_0:
            // 0x0142CFF8: CBNZ x19, #0x142d000       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142CFFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F1, ????);     
            label_1:
            // 0x0142D000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D004: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142D008: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142D00C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142D010: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D014: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D018: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142D01C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142D020: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D024: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142D028: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D02C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D030: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142D034: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142D038: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D03C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142D040: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142D044: ADRP x9, #0x3640000        | X9 = 56885248 (0x3640000);              
            // 0x0142D048: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0142D04C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142D050: LDR x9, [x9, #0x228]       | X9 = 1152921504954501264;               
            // 0x0142D054: LDR x24, [x9]              | X24 = typeof(System.Object[]);          
            // 0x0142D058: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142D05C: TBZ w9, #0, #0x142d070     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142D060: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142D064: CBNZ w9, #0x142d070        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142D068: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142D06C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142D070: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D074: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D078: MOV x1, x24                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0142D07C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142D080: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142D084: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142D088: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142D08C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142D090: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142D094: TBZ w9, #0, #0x142d0a8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142D098: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142D09C: CBNZ w9, #0x142d0a8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142D0A0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142D0A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142D0A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D0AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142D0B0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142D0B4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142D0B8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0142D0BC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142D0C0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142D0C4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142D0C8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0142D0CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142D0D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142D0D4: TBZ w9, #0, #0x142d0e8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142D0D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142D0DC: CBNZ w9, #0x142d0e8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142D0E0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142D0E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142D0E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D0EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D0F0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142D0F4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0142D0F8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142D0FC: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x0142D100: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0142D104: CBZ x26, #0x142d158        | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142D108: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x0142D10C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x0142D110: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x0142D114: LDR x27, [x8]              | X27 = typeof(System.Object[]);          
            // 0x0142D118: MOV x1, x27                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0142D11C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x0142D120: MOV x24, x0                | X24 = val_6;//m1                        
            val_13 = val_6;
            // 0x0142D124: CBNZ x24, #0x142d158       | if (val_6 != null) goto label_9;        
            if(val_13 != null)
            {
                goto label_9;
            }
            // 0x0142D128: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x0142D12C: MOV x1, x27                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0142D130: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142D134: MOV x8, sp                 | X8 = 1152921510105743680 (0x1000000147C28140);//ML01
            // 0x0142D138: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142D13C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510105731792]
            // 0x0142D140: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142D144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D148: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142D14C: MOV x0, sp                 | X0 = 1152921510105743680 (0x1000000147C28140);//ML01
            // 0x0142D150: BL #0x299a140              | 
            // 0x0142D154: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_9:
            // 0x0142D158: CBNZ x19, #0x142d160       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0142D15C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147C28140, ????);
            label_10:
            // 0x0142D160: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D164: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142D168: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142D16C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142D170: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D174: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D178: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142D17C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142D180: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D184: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0142D188: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0142D18C: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142D190: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D194: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D198: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142D19C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142D1A0: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0142D1A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D1A8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142D1AC: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142D1B0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142D1B4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0142D1B8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142D1BC: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0142D1C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D1C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D1C8: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0142D1CC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0142D1D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x0142D1D4: CBZ x0, #0x142d21c         | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x0142D1D8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142D1DC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142D1E0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142D1E4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142D1E8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142D1EC: MOV x21, x0                | X21 = val_11;//m1                       
            val_14 = val_11;
            // 0x0142D1F0: B.EQ #0x142d21c            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x0142D1F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142D1F8: ADD x8, sp, #8             | X8 = (1152921510105743680 + 8) = 1152921510105743688 (0x1000000147C28148);
            // 0x0142D1FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142D200: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510105731792]
            // 0x0142D204: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0142D208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D20C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0142D210: ADD x0, sp, #8             | X0 = (1152921510105743680 + 8) = 1152921510105743688 (0x1000000147C28148);
            // 0x0142D214: BL #0x299a140              | 
            // 0x0142D218: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_12:
            // 0x0142D21C: CBNZ x19, #0x142d224       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0142D220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147C28148, ????);
            label_13:
            // 0x0142D224: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D228: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142D22C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142D230: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142D234: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142D238: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142D23C: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142D240: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142D244: TBZ w8, #0, #0x142d254     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x0142D248: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142D24C: CBNZ w8, #0x142d254        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x0142D250: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_15:
            // 0x0142D254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D258: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D25C: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x0142D260: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0142D264: BL #0xba5838               | CallJSApi.CallJsFun(funName:  0, args:  val_14);
            CallJSApi.CallJsFun(funName:  0, args:  val_14);
            // 0x0142D268: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142D26C: SUB sp, x29, #0x50         | SP = (1152921510105743776 - 80) = 1152921510105743696 (0x1000000147C28150);
            // 0x0142D270: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0142D274: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0142D278: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0142D27C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0142D280: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0142D284: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0142D288: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142D28C: MOV x19, x0                | 
            // 0x0142D290: ADD x0, sp, #8             | 
            // 0x0142D294: B #0x142d2a0               | 
            // 0x0142D298: MOV x19, x0                | 
            // 0x0142D29C: MOV x0, sp                 | 
            label_16:
            // 0x0142D2A0: BL #0x299a140              | 
            // 0x0142D2A4: MOV x0, x19                | 
            // 0x0142D2A8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142D2AC (21156524), len: 172  VirtAddr: 0x0142D2AC RVA: 0x0142D2AC token: 100664125 methodIndex: 30170 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* CallLoadJsObjToCs_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x0142D2AC: STP x22, x21, [sp, #-0x30]! | stack[1152921510105913088] = ???;  stack[1152921510105913096] = ???;  //  dest_result_addr=1152921510105913088 |  dest_result_addr=1152921510105913096
            // 0x0142D2B0: STP x20, x19, [sp, #0x10]  | stack[1152921510105913104] = ???;  stack[1152921510105913112] = ???;  //  dest_result_addr=1152921510105913104 |  dest_result_addr=1152921510105913112
            // 0x0142D2B4: STP x29, x30, [sp, #0x20]  | stack[1152921510105913120] = ???;  stack[1152921510105913128] = ???;  //  dest_result_addr=1152921510105913120 |  dest_result_addr=1152921510105913128
            // 0x0142D2B8: ADD x29, sp, #0x20         | X29 = (1152921510105913088 + 32) = 1152921510105913120 (0x1000000147C51720);
            // 0x0142D2BC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142D2C0: LDRB w8, [x21, #0x1d]      | W8 = (bool)static_value_0373701D;       
            // 0x0142D2C4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x0142D2C8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142D2CC: TBNZ w8, #0, #0x142d2e8    | if (static_value_0373701D == true) goto label_0;
            // 0x0142D2D0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142D2D4: LDR x8, [x8, #0x8b0]       | X8 = 0x2B900B8;                         
            // 0x0142D2D8: LDR w0, [x8]               | W0 = 0x16F2;                            
            // 0x0142D2DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F2, ????);     
            // 0x0142D2E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142D2E4: STRB w8, [x21, #0x1d]      | static_value_0373701D = true;            //  dest_result_addr=57896989
            label_0:
            // 0x0142D2E8: CBNZ x20, #0x142d2f0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142D2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F2, ????);     
            label_1:
            // 0x0142D2F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D2F4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142D2F8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142D2FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D300: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142D304: MOV x1, x19                | X1 = X2;//m1                            
            // 0x0142D308: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D30C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x0142D310: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142D314: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142D318: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x0142D31C: LDR x8, [x8]               | X8 = typeof(CallJSApi);                 
            // 0x0142D320: LDRB w9, [x8, #0x10a]      | W9 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142D324: TBZ w9, #0, #0x142d338     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142D328: LDR w9, [x8, #0xbc]        | W9 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142D32C: CBNZ w9, #0x142d338        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142D330: MOV x0, x8                 | X0 = 1152921504901255168 (0x10000000118C5000);//ML01
            // 0x0142D334: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_3:
            // 0x0142D338: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D33C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D340: BL #0xba58c4               | CallJSApi.CallLoadJsObjToCs();          
            CallJSApi.CallLoadJsObjToCs();
            // 0x0142D344: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x0142D348: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0142D34C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0142D350: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0142D354: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0142D358 (21156696), len: 580  VirtAddr: 0x0142D358 RVA: 0x0142D358 token: 100664126 methodIndex: 30171 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetNeedNext_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            // 0x0142D358: STP x26, x25, [sp, #-0x50]! | stack[1152921510106070112] = ???;  stack[1152921510106070120] = ???;  //  dest_result_addr=1152921510106070112 |  dest_result_addr=1152921510106070120
            // 0x0142D35C: STP x24, x23, [sp, #0x10]  | stack[1152921510106070128] = ???;  stack[1152921510106070136] = ???;  //  dest_result_addr=1152921510106070128 |  dest_result_addr=1152921510106070136
            // 0x0142D360: STP x22, x21, [sp, #0x20]  | stack[1152921510106070144] = ???;  stack[1152921510106070152] = ???;  //  dest_result_addr=1152921510106070144 |  dest_result_addr=1152921510106070152
            // 0x0142D364: STP x20, x19, [sp, #0x30]  | stack[1152921510106070160] = ???;  stack[1152921510106070168] = ???;  //  dest_result_addr=1152921510106070160 |  dest_result_addr=1152921510106070168
            // 0x0142D368: STP x29, x30, [sp, #0x40]  | stack[1152921510106070176] = ???;  stack[1152921510106070184] = ???;  //  dest_result_addr=1152921510106070176 |  dest_result_addr=1152921510106070184
            // 0x0142D36C: ADD x29, sp, #0x40         | X29 = (1152921510106070112 + 64) = 1152921510106070176 (0x1000000147C77CA0);
            // 0x0142D370: SUB sp, sp, #0x10          | SP = (1152921510106070112 - 16) = 1152921510106070096 (0x1000000147C77C50);
            // 0x0142D374: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142D378: LDRB w8, [x20, #0x1e]      | W8 = (bool)static_value_0373701E;       
            // 0x0142D37C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0142D380: MOV x21, x2                | X21 = X2;//m1                           
            // 0x0142D384: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0142D388: TBNZ w8, #0, #0x142d3a4    | if (static_value_0373701E == true) goto label_0;
            // 0x0142D38C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x0142D390: LDR x8, [x8, #0xa08]       | X8 = 0x2B900DC;                         
            // 0x0142D394: LDR w0, [x8]               | W0 = 0x16FB;                            
            // 0x0142D398: BL #0x2782188              | X0 = sub_2782188( ?? 0x16FB, ????);     
            // 0x0142D39C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142D3A0: STRB w8, [x20, #0x1e]      | static_value_0373701E = true;            //  dest_result_addr=57896990
            label_0:
            // 0x0142D3A4: CBNZ x19, #0x142d3ac       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142D3A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16FB, ????);     
            label_1:
            // 0x0142D3AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D3B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142D3B4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142D3B8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142D3BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D3C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D3C4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142D3C8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0142D3CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D3D0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142D3D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D3D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D3DC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142D3E0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0142D3E4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D3E8: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0142D3EC: CBNZ x24, #0x142d3f4       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x0142D3F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x0142D3F4: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x0142D3F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D3FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D400: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142D404: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0142D408: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D40C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142D410: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142D414: ADRP x9, #0x35b8000        | X9 = 56328192 (0x35B8000);              
            // 0x0142D418: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x0142D41C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142D420: LDR x9, [x9, #0xfd8]       | X9 = 1152921504901255168;               
            // 0x0142D424: LDR x24, [x9]              | X24 = typeof(CallJSApi);                
            // 0x0142D428: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142D42C: TBZ w9, #0, #0x142d440     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0142D430: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142D434: CBNZ w9, #0x142d440        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0142D438: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142D43C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x0142D440: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D444: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D448: MOV x1, x24                | X1 = 1152921504901255168 (0x10000000118C5000);//ML01
            // 0x0142D44C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142D450: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142D454: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142D458: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x0142D45C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142D460: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142D464: TBZ w9, #0, #0x142d478     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0142D468: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142D46C: CBNZ w9, #0x142d478        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0142D470: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142D474: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x0142D478: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D47C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142D480: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x0142D484: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142D488: MOV x3, x22                | X3 = X3;//m1                            
            // 0x0142D48C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142D490: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142D494: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142D498: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x0142D49C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142D4A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142D4A4: TBZ w9, #0, #0x142d4b8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0142D4A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142D4AC: CBNZ w9, #0x142d4b8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0142D4B0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142D4B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x0142D4B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D4BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D4C0: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x0142D4C4: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x0142D4C8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x0142D4CC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0142D4D0: CBZ x0, #0x142d534         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x0142D4D4: ADRP x9, #0x3604000        | X9 = 56639488 (0x3604000);              
            // 0x0142D4D8: LDR x9, [x9, #0xb68]       | X9 = 1152921504901255168;               
            // 0x0142D4DC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142D4E0: LDR x1, [x9]               | X1 = typeof(CallJSApi);                 
            // 0x0142D4E4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142D4E8: LDRB w9, [x1, #0x104]      | W9 = CallJSApi.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142D4EC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CallJSApi.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142D4F0: B.LO #0x142d50c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CallJSApi.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x0142D4F4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142D4F8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CallJSApi.__il2cppRuntimeField_typeHierarc
            // 0x0142D4FC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CallJSApi.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142D500: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CallJSApi.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CallJSApi))
            // 0x0142D504: MOV x22, x0                | X22 = val_7;//m1                        
            val_11 = val_7;
            // 0x0142D508: B.EQ #0x142d534            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CallJSApi.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x0142D50C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142D510: ADD x8, sp, #8             | X8 = (1152921510106070096 + 8) = 1152921510106070104 (0x1000000147C77C58);
            // 0x0142D514: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142D518: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510106058192]
            // 0x0142D51C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x0142D520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D524: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x0142D528: ADD x0, sp, #8             | X0 = (1152921510106070096 + 8) = 1152921510106070104 (0x1000000147C77C58);
            // 0x0142D52C: BL #0x299a140              | 
            // 0x0142D530: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_11:
            // 0x0142D534: CBNZ x19, #0x142d53c       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x0142D538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147C77C58, ????);
            label_12:
            // 0x0142D53C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D540: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142D544: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x0142D548: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142D54C: CBNZ x22, #0x142d554       | if (0x0 != 0) goto label_13;            
            if(val_11 != 0)
            {
                goto label_13;
            }
            // 0x0142D550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x0142D554: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x0142D558: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x0142D55C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D560: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x0142D564: BL #0xba5974               | val_11.SetNeedNext(isNext:  bool val_10 = ((val_3 + 4) == 1) ? 1 : 0);
            val_11.SetNeedNext(isNext:  val_10);
            // 0x0142D568: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142D56C: SUB sp, x29, #0x40         | SP = (1152921510106070176 - 64) = 1152921510106070112 (0x1000000147C77C60);
            // 0x0142D570: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142D574: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142D578: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142D57C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142D580: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142D584: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142D588: MOV x19, x0                | 
            // 0x0142D58C: ADD x0, sp, #8             | 
            // 0x0142D590: BL #0x299a140              | 
            // 0x0142D594: MOV x0, x19                | 
            // 0x0142D598: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142D59C (21157276), len: 576  VirtAddr: 0x0142D59C RVA: 0x0142D59C token: 100664127 methodIndex: 30172 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetJSHash_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_10;
            // 0x0142D59C: STP x26, x25, [sp, #-0x50]! | stack[1152921510106243552] = ???;  stack[1152921510106243560] = ???;  //  dest_result_addr=1152921510106243552 |  dest_result_addr=1152921510106243560
            // 0x0142D5A0: STP x24, x23, [sp, #0x10]  | stack[1152921510106243568] = ???;  stack[1152921510106243576] = ???;  //  dest_result_addr=1152921510106243568 |  dest_result_addr=1152921510106243576
            // 0x0142D5A4: STP x22, x21, [sp, #0x20]  | stack[1152921510106243584] = ???;  stack[1152921510106243592] = ???;  //  dest_result_addr=1152921510106243584 |  dest_result_addr=1152921510106243592
            // 0x0142D5A8: STP x20, x19, [sp, #0x30]  | stack[1152921510106243600] = ???;  stack[1152921510106243608] = ???;  //  dest_result_addr=1152921510106243600 |  dest_result_addr=1152921510106243608
            // 0x0142D5AC: STP x29, x30, [sp, #0x40]  | stack[1152921510106243616] = ???;  stack[1152921510106243624] = ???;  //  dest_result_addr=1152921510106243616 |  dest_result_addr=1152921510106243624
            // 0x0142D5B0: ADD x29, sp, #0x40         | X29 = (1152921510106243552 + 64) = 1152921510106243616 (0x1000000147CA2220);
            // 0x0142D5B4: SUB sp, sp, #0x10          | SP = (1152921510106243552 - 16) = 1152921510106243536 (0x1000000147CA21D0);
            // 0x0142D5B8: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142D5BC: LDRB w8, [x21, #0x1f]      | W8 = (bool)static_value_0373701F;       
            // 0x0142D5C0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142D5C4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142D5C8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142D5CC: TBNZ w8, #0, #0x142d5e8    | if (static_value_0373701F == true) goto label_0;
            // 0x0142D5D0: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x0142D5D4: LDR x8, [x8, #0x618]       | X8 = 0x2B900C8;                         
            // 0x0142D5D8: LDR w0, [x8]               | W0 = 0x16F6;                            
            // 0x0142D5DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F6, ????);     
            // 0x0142D5E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142D5E4: STRB w8, [x21, #0x1f]      | static_value_0373701F = true;            //  dest_result_addr=57896991
            label_0:
            // 0x0142D5E8: CBNZ x20, #0x142d5f0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142D5EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F6, ????);     
            label_1:
            // 0x0142D5F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D5F4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142D5F8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142D5FC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142D600: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D604: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D608: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142D60C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142D610: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D614: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142D618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D61C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D620: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142D624: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142D628: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D62C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142D630: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142D634: ADRP x9, #0x3616000        | X9 = 56713216 (0x3616000);              
            // 0x0142D638: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142D63C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142D640: LDR x9, [x9, #0x888]       | X9 = 1152921504996170800;               
            // 0x0142D644: LDR x24, [x9]              | X24 = typeof(System.Byte[]);            
            // 0x0142D648: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142D64C: TBZ w9, #0, #0x142d660     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142D650: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142D654: CBNZ w9, #0x142d660        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142D658: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142D65C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142D660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D664: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D668: MOV x1, x24                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142D66C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142D670: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142D674: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142D678: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142D67C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142D680: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142D684: TBZ w9, #0, #0x142d698     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142D688: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142D68C: CBNZ w9, #0x142d698        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142D690: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142D694: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142D698: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D69C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142D6A0: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142D6A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142D6A8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142D6AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142D6B0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142D6B4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142D6B8: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0142D6BC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142D6C0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142D6C4: TBZ w9, #0, #0x142d6d8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142D6C8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142D6CC: CBNZ w9, #0x142d6d8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142D6D0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142D6D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142D6D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D6DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D6E0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142D6E4: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x0142D6E8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142D6EC: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x0142D6F0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x0142D6F4: CBZ x24, #0x142d748        | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142D6F8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x0142D6FC: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x0142D700: MOV x0, x24                | X0 = val_6;//m1                         
            // 0x0142D704: LDR x25, [x8]              | X25 = typeof(System.Byte[]);            
            // 0x0142D708: MOV x1, x25                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142D70C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x0142D710: MOV x23, x0                | X23 = val_6;//m1                        
            val_10 = val_6;
            // 0x0142D714: CBNZ x23, #0x142d748       | if (val_6 != null) goto label_9;        
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x0142D718: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x0142D71C: MOV x1, x25                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142D720: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142D724: ADD x8, sp, #8             | X8 = (1152921510106243536 + 8) = 1152921510106243544 (0x1000000147CA21D8);
            // 0x0142D728: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142D72C: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510106231632]
            // 0x0142D730: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142D734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D738: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142D73C: ADD x0, sp, #8             | X0 = (1152921510106243536 + 8) = 1152921510106243544 (0x1000000147CA21D8);
            // 0x0142D740: BL #0x299a140              | 
            // 0x0142D744: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_9:
            // 0x0142D748: CBNZ x20, #0x142d750       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0142D74C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147CA21D8, ????);
            label_10:
            // 0x0142D750: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D754: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142D758: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0142D75C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142D760: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142D764: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142D768: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142D76C: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142D770: TBZ w8, #0, #0x142d780     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x0142D774: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142D778: CBNZ w8, #0x142d780        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x0142D77C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_12:
            // 0x0142D780: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D784: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D788: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142D78C: BL #0xba59e4               | X0 = CallJSApi.GetJSHash(bytes:  0);    
            string val_8 = CallJSApi.GetJSHash(bytes:  0);
            // 0x0142D790: MOV x3, x0                 | X3 = val_8;//m1                         
            // 0x0142D794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D798: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142D79C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142D7A0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142D7A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142D7A8: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142D7AC: SUB sp, x29, #0x40         | SP = (1152921510106243616 - 64) = 1152921510106243552 (0x1000000147CA21E0);
            // 0x0142D7B0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142D7B4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142D7B8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142D7BC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142D7C0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142D7C4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142D7C8: MOV x19, x0                | 
            // 0x0142D7CC: ADD x0, sp, #8             | 
            // 0x0142D7D0: BL #0x299a140              | 
            // 0x0142D7D4: MOV x0, x19                | 
            // 0x0142D7D8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142D7DC (21157852), len: 196  VirtAddr: 0x0142D7DC RVA: 0x0142D7DC token: 100664128 methodIndex: 30173 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetJsNum_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x0142D7DC: STP x22, x21, [sp, #-0x30]! | stack[1152921510106408832] = ???;  stack[1152921510106408840] = ???;  //  dest_result_addr=1152921510106408832 |  dest_result_addr=1152921510106408840
            // 0x0142D7E0: STP x20, x19, [sp, #0x10]  | stack[1152921510106408848] = ???;  stack[1152921510106408856] = ???;  //  dest_result_addr=1152921510106408848 |  dest_result_addr=1152921510106408856
            // 0x0142D7E4: STP x29, x30, [sp, #0x20]  | stack[1152921510106408864] = ???;  stack[1152921510106408872] = ???;  //  dest_result_addr=1152921510106408864 |  dest_result_addr=1152921510106408872
            // 0x0142D7E8: ADD x29, sp, #0x20         | X29 = (1152921510106408832 + 32) = 1152921510106408864 (0x1000000147CCA7A0);
            // 0x0142D7EC: ADRP x22, #0x3737000       | X22 = 57896960 (0x3737000);             
            // 0x0142D7F0: LDRB w8, [x22, #0x20]      | W8 = (bool)static_value_03737020;       
            // 0x0142D7F4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142D7F8: MOV x20, x2                | X20 = X2;//m1                           
            // 0x0142D7FC: MOV x21, x1                | X21 = X1;//m1                           
            // 0x0142D800: TBNZ w8, #0, #0x142d81c    | if (static_value_03737020 == true) goto label_0;
            // 0x0142D804: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x0142D808: LDR x8, [x8, #0xb80]       | X8 = 0x2B900CC;                         
            // 0x0142D80C: LDR w0, [x8]               | W0 = 0x16F7;                            
            // 0x0142D810: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F7, ????);     
            // 0x0142D814: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142D818: STRB w8, [x22, #0x20]      | static_value_03737020 = true;            //  dest_result_addr=57896992
            label_0:
            // 0x0142D81C: CBNZ x21, #0x142d824       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142D820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F7, ????);     
            label_1:
            // 0x0142D824: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D828: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142D82C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142D830: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D834: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142D838: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0142D83C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D840: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x0142D844: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142D848: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142D84C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142D850: LDR x8, [x8]               | X8 = typeof(CallJSApi);                 
            // 0x0142D854: LDRB w9, [x8, #0x10a]      | W9 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142D858: TBZ w9, #0, #0x142d86c     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142D85C: LDR w9, [x8, #0xbc]        | W9 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142D860: CBNZ w9, #0x142d86c        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142D864: MOV x0, x8                 | X0 = 1152921504901255168 (0x10000000118C5000);//ML01
            // 0x0142D868: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_3:
            // 0x0142D86C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D870: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D874: BL #0xba5b20               | X0 = CallJSApi.GetJsNum();              
            string val_3 = CallJSApi.GetJsNum();
            // 0x0142D878: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142D87C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142D880: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0142D884: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0142D888: MOV x3, x0                 | X3 = val_3;//m1                         
            // 0x0142D88C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D890: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142D894: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142D898: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0142D89C: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x0142D8A0 (21158048), len: 600  VirtAddr: 0x0142D8A0 RVA: 0x0142D8A0 token: 100664129 methodIndex: 30174 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* LoadDataFromStreamPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x0142D8A0: STP x26, x25, [sp, #-0x50]! | stack[1152921510106606816] = ???;  stack[1152921510106606824] = ???;  //  dest_result_addr=1152921510106606816 |  dest_result_addr=1152921510106606824
            // 0x0142D8A4: STP x24, x23, [sp, #0x10]  | stack[1152921510106606832] = ???;  stack[1152921510106606840] = ???;  //  dest_result_addr=1152921510106606832 |  dest_result_addr=1152921510106606840
            // 0x0142D8A8: STP x22, x21, [sp, #0x20]  | stack[1152921510106606848] = ???;  stack[1152921510106606856] = ???;  //  dest_result_addr=1152921510106606848 |  dest_result_addr=1152921510106606856
            // 0x0142D8AC: STP x20, x19, [sp, #0x30]  | stack[1152921510106606864] = ???;  stack[1152921510106606872] = ???;  //  dest_result_addr=1152921510106606864 |  dest_result_addr=1152921510106606872
            // 0x0142D8B0: STP x29, x30, [sp, #0x40]  | stack[1152921510106606880] = ???;  stack[1152921510106606888] = ???;  //  dest_result_addr=1152921510106606880 |  dest_result_addr=1152921510106606888
            // 0x0142D8B4: ADD x29, sp, #0x40         | X29 = (1152921510106606816 + 64) = 1152921510106606880 (0x1000000147CFAD20);
            // 0x0142D8B8: SUB sp, sp, #0x10          | SP = (1152921510106606816 - 16) = 1152921510106606800 (0x1000000147CFACD0);
            // 0x0142D8BC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142D8C0: LDRB w8, [x21, #0x21]      | W8 = (bool)static_value_03737021;       
            // 0x0142D8C4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142D8C8: MOV x23, x2                | X23 = X2;//m1                           
            // 0x0142D8CC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142D8D0: TBNZ w8, #0, #0x142d8ec    | if (static_value_03737021 == true) goto label_0;
            // 0x0142D8D4: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x0142D8D8: LDR x8, [x8, #0x6f8]       | X8 = 0x2B900D0;                         
            // 0x0142D8DC: LDR w0, [x8]               | W0 = 0x16F8;                            
            // 0x0142D8E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F8, ????);     
            // 0x0142D8E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142D8E8: STRB w8, [x21, #0x21]      | static_value_03737021 = true;            //  dest_result_addr=57896993
            label_0:
            // 0x0142D8EC: CBNZ x20, #0x142d8f4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142D8F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F8, ????);     
            label_1:
            // 0x0142D8F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142D8F8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142D8FC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142D900: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x0142D904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D908: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D90C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142D910: MOV x1, x23                | X1 = X2;//m1                            
            // 0x0142D914: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D918: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142D91C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D920: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D924: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142D928: MOV x1, x23                | X1 = X2;//m1                            
            // 0x0142D92C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D930: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0142D934: CBNZ x22, #0x142d93c       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x0142D938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x0142D93C: LDR w22, [x22, #4]         | W22 = val_3 + 4;                        
            // 0x0142D940: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D944: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142D948: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142D94C: MOV x1, x23                | X1 = X2;//m1                            
            // 0x0142D950: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142D954: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142D958: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142D95C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142D960: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x0142D964: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142D968: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142D96C: LDR x25, [x9]              | X25 = typeof(System.String);            
            // 0x0142D970: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142D974: TBZ w9, #0, #0x142d988     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0142D978: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142D97C: CBNZ w9, #0x142d988        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0142D980: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142D984: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x0142D988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D98C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142D990: MOV x1, x25                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142D994: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142D998: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142D99C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142D9A0: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x0142D9A4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142D9A8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142D9AC: TBZ w9, #0, #0x142d9c0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0142D9B0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142D9B4: CBNZ w9, #0x142d9c0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0142D9B8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142D9BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x0142D9C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142D9C4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142D9C8: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x0142D9CC: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x0142D9D0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142D9D4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142D9D8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142D9DC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142D9E0: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x0142D9E4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142D9E8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142D9EC: TBZ w9, #0, #0x142da00     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0142D9F0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142D9F4: CBNZ w9, #0x142da00        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0142D9F8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142D9FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x0142DA00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DA04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DA08: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x0142DA0C: MOV x2, x24                | X2 = val_6;//m1                         
            // 0x0142DA10: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x0142DA14: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0142DA18: CBZ x0, #0x142da60         | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x0142DA1C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142DA20: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142DA24: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142DA28: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142DA2C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142DA30: MOV x24, x0                | X24 = val_7;//m1                        
            val_11 = val_7;
            // 0x0142DA34: B.EQ #0x142da60            | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x0142DA38: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142DA3C: ADD x8, sp, #8             | X8 = (1152921510106606800 + 8) = 1152921510106606808 (0x1000000147CFACD8);
            // 0x0142DA40: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142DA44: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510106594896]
            // 0x0142DA48: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0142DA4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142DA50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0142DA54: ADD x0, sp, #8             | X0 = (1152921510106606800 + 8) = 1152921510106606808 (0x1000000147CFACD8);
            // 0x0142DA58: BL #0x299a140              | 
            // 0x0142DA5C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x0142DA60: CBNZ x20, #0x142da68       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0142DA64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147CFACD8, ????);
            label_11:
            // 0x0142DA68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DA6C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142DA70: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x0142DA74: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142DA78: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142DA7C: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142DA80: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142DA84: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142DA88: TBZ w8, #0, #0x142da98     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x0142DA8C: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142DA90: CBNZ w8, #0x142da98        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x0142DA94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_13:
            // 0x0142DA98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DA9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DAA0: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x0142DAA4: MOV w2, w22                | W2 = val_3 + 4;//m1                     
            // 0x0142DAA8: BL #0xba6264               | X0 = CallJSApi.LoadDataFromStreamPath(fileName:  0, max:  0);
            System.Byte[] val_9 = CallJSApi.LoadDataFromStreamPath(fileName:  0, max:  0);
            // 0x0142DAAC: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x0142DAB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DAB4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142DAB8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142DABC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142DAC0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142DAC4: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142DAC8: SUB sp, x29, #0x40         | SP = (1152921510106606880 - 64) = 1152921510106606816 (0x1000000147CFACE0);
            // 0x0142DACC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142DAD0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142DAD4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142DAD8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142DADC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142DAE0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142DAE4: MOV x19, x0                | 
            // 0x0142DAE8: ADD x0, sp, #8             | 
            // 0x0142DAEC: BL #0x299a140              | 
            // 0x0142DAF0: MOV x0, x19                | 
            // 0x0142DAF4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142DAF8 (21158648), len: 788  VirtAddr: 0x0142DAF8 RVA: 0x0142DAF8 token: 100664130 methodIndex: 30175 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Bytes2String_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_15;
            //  | 
            string val_16;
            // 0x0142DAF8: STP x26, x25, [sp, #-0x50]! | stack[1152921510106829408] = ???;  stack[1152921510106829416] = ???;  //  dest_result_addr=1152921510106829408 |  dest_result_addr=1152921510106829416
            // 0x0142DAFC: STP x24, x23, [sp, #0x10]  | stack[1152921510106829424] = ???;  stack[1152921510106829432] = ???;  //  dest_result_addr=1152921510106829424 |  dest_result_addr=1152921510106829432
            // 0x0142DB00: STP x22, x21, [sp, #0x20]  | stack[1152921510106829440] = ???;  stack[1152921510106829448] = ???;  //  dest_result_addr=1152921510106829440 |  dest_result_addr=1152921510106829448
            // 0x0142DB04: STP x20, x19, [sp, #0x30]  | stack[1152921510106829456] = ???;  stack[1152921510106829464] = ???;  //  dest_result_addr=1152921510106829456 |  dest_result_addr=1152921510106829464
            // 0x0142DB08: STP x29, x30, [sp, #0x40]  | stack[1152921510106829472] = ???;  stack[1152921510106829480] = ???;  //  dest_result_addr=1152921510106829472 |  dest_result_addr=1152921510106829480
            // 0x0142DB0C: ADD x29, sp, #0x40         | X29 = (1152921510106829408 + 64) = 1152921510106829472 (0x1000000147D312A0);
            // 0x0142DB10: SUB sp, sp, #0x10          | SP = (1152921510106829408 - 16) = 1152921510106829392 (0x1000000147D31250);
            // 0x0142DB14: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142DB18: LDRB w8, [x21, #0x22]      | W8 = (bool)static_value_03737022;       
            // 0x0142DB1C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142DB20: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142DB24: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142DB28: TBNZ w8, #0, #0x142db44    | if (static_value_03737022 == true) goto label_0;
            // 0x0142DB2C: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x0142DB30: LDR x8, [x8, #0x730]       | X8 = 0x2B900AC;                         
            // 0x0142DB34: LDR w0, [x8]               | W0 = 0x16EF;                            
            // 0x0142DB38: BL #0x2782188              | X0 = sub_2782188( ?? 0x16EF, ????);     
            // 0x0142DB3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142DB40: STRB w8, [x21, #0x22]      | static_value_03737022 = true;            //  dest_result_addr=57896994
            label_0:
            // 0x0142DB44: CBNZ x20, #0x142db4c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142DB48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16EF, ????);     
            label_1:
            // 0x0142DB4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142DB50: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142DB54: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142DB58: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142DB5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DB60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DB64: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142DB68: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142DB6C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142DB70: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142DB74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DB78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DB7C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142DB80: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142DB84: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142DB88: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142DB8C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142DB90: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142DB94: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0142DB98: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142DB9C: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142DBA0: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0142DBA4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142DBA8: TBZ w9, #0, #0x142dbbc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142DBAC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142DBB0: CBNZ w9, #0x142dbbc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142DBB4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142DBB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142DBBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DBC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DBC4: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142DBC8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142DBCC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142DBD0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142DBD4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142DBD8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142DBDC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142DBE0: TBZ w9, #0, #0x142dbf4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142DBE4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142DBE8: CBNZ w9, #0x142dbf4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142DBEC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142DBF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142DBF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DBF8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142DBFC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142DC00: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142DC04: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142DC08: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142DC0C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142DC10: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142DC14: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0142DC18: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142DC1C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142DC20: TBZ w9, #0, #0x142dc34     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142DC24: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142DC28: CBNZ w9, #0x142dc34        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142DC2C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142DC30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142DC34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DC38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DC3C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142DC40: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0142DC44: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142DC48: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x0142DC4C: CBZ x0, #0x142dc94         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142DC50: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142DC54: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142DC58: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142DC5C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142DC60: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142DC64: MOV x24, x0                | X24 = val_6;//m1                        
            val_15 = val_6;
            // 0x0142DC68: B.EQ #0x142dc94            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0142DC6C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142DC70: MOV x8, sp                 | X8 = 1152921510106829392 (0x1000000147D31250);//ML01
            // 0x0142DC74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142DC78: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510106817488]
            // 0x0142DC7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142DC80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142DC84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142DC88: MOV x0, sp                 | X0 = 1152921510106829392 (0x1000000147D31250);//ML01
            // 0x0142DC8C: BL #0x299a140              | 
            // 0x0142DC90: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_9:
            // 0x0142DC94: CBNZ x20, #0x142dc9c       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0142DC98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D31250, ????);
            label_10:
            // 0x0142DC9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DCA0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142DCA4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142DCA8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142DCAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DCB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DCB4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142DCB8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142DCBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142DCC0: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x0142DCC4: LDR x8, [x8, #0x888]       | X8 = 1152921504996170800;               
            // 0x0142DCC8: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142DCCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DCD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DCD4: LDR x1, [x8]               | X1 = typeof(System.Byte[]);             
            // 0x0142DCD8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142DCDC: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0142DCE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DCE4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142DCE8: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142DCEC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142DCF0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142DCF4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142DCF8: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0142DCFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DD00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DD04: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0142DD08: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0142DD0C: MOV x25, x0                | X25 = val_11;//m1                       
            // 0x0142DD10: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x0142DD14: CBZ x25, #0x142dd68        | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x0142DD18: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x0142DD1C: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x0142DD20: MOV x0, x25                | X0 = val_11;//m1                        
            // 0x0142DD24: LDR x26, [x8]              | X26 = typeof(System.Byte[]);            
            // 0x0142DD28: MOV x1, x26                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142DD2C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x0142DD30: MOV x23, x0                | X23 = val_11;//m1                       
            val_16 = val_11;
            // 0x0142DD34: CBNZ x23, #0x142dd68       | if (val_11 != null) goto label_12;      
            if(val_16 != null)
            {
                goto label_12;
            }
            // 0x0142DD38: LDR x8, [x25]              | X8 = typeof(System.Object);             
            // 0x0142DD3C: MOV x1, x26                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0142DD40: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142DD44: ADD x8, sp, #8             | X8 = (1152921510106829392 + 8) = 1152921510106829400 (0x1000000147D31258);
            // 0x0142DD48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142DD4C: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510106817488]
            // 0x0142DD50: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0142DD54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142DD58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0142DD5C: ADD x0, sp, #8             | X0 = (1152921510106829392 + 8) = 1152921510106829400 (0x1000000147D31258);
            // 0x0142DD60: BL #0x299a140              | 
            // 0x0142DD64: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_12:
            // 0x0142DD68: CBNZ x20, #0x142dd70       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0142DD6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D31258, ????);
            label_13:
            // 0x0142DD70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DD74: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142DD78: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142DD7C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142DD80: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142DD84: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142DD88: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142DD8C: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142DD90: TBZ w8, #0, #0x142dda0     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x0142DD94: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142DD98: CBNZ w8, #0x142dda0        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x0142DD9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_15:
            // 0x0142DDA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DDA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DDA8: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142DDAC: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0142DDB0: BL #0xba6888               | X0 = CallJSApi.Bytes2String(bytes:  0, arg:  val_16);
            string val_13 = CallJSApi.Bytes2String(bytes:  0, arg:  val_16);
            // 0x0142DDB4: MOV x3, x0                 | X3 = val_13;//m1                        
            // 0x0142DDB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DDBC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142DDC0: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142DDC4: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142DDC8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142DDCC: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142DDD0: SUB sp, x29, #0x40         | SP = (1152921510106829472 - 64) = 1152921510106829408 (0x1000000147D31260);
            // 0x0142DDD4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142DDD8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142DDDC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142DDE0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142DDE4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142DDE8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_14;
            return val_14;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142DDEC: MOV x19, x0                | 
            // 0x0142DDF0: MOV x0, sp                 | 
            // 0x0142DDF4: B #0x142de00               | 
            // 0x0142DDF8: MOV x19, x0                | 
            // 0x0142DDFC: ADD x0, sp, #8             | 
            label_16:
            // 0x0142DE00: BL #0x299a140              | 
            // 0x0142DE04: MOV x0, x19                | 
            // 0x0142DE08: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142DE0C (21159436), len: 1124  VirtAddr: 0x0142DE0C RVA: 0x0142DE0C token: 100664131 methodIndex: 30176 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetJavaStaticAJO_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            string val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            // 0x0142DE0C: STP x26, x25, [sp, #-0x50]! | stack[1152921510107031520] = ???;  stack[1152921510107031528] = ???;  //  dest_result_addr=1152921510107031520 |  dest_result_addr=1152921510107031528
            // 0x0142DE10: STP x24, x23, [sp, #0x10]  | stack[1152921510107031536] = ???;  stack[1152921510107031544] = ???;  //  dest_result_addr=1152921510107031536 |  dest_result_addr=1152921510107031544
            // 0x0142DE14: STP x22, x21, [sp, #0x20]  | stack[1152921510107031552] = ???;  stack[1152921510107031560] = ???;  //  dest_result_addr=1152921510107031552 |  dest_result_addr=1152921510107031560
            // 0x0142DE18: STP x20, x19, [sp, #0x30]  | stack[1152921510107031568] = ???;  stack[1152921510107031576] = ???;  //  dest_result_addr=1152921510107031568 |  dest_result_addr=1152921510107031576
            // 0x0142DE1C: STP x29, x30, [sp, #0x40]  | stack[1152921510107031584] = ???;  stack[1152921510107031592] = ???;  //  dest_result_addr=1152921510107031584 |  dest_result_addr=1152921510107031592
            // 0x0142DE20: ADD x29, sp, #0x40         | X29 = (1152921510107031520 + 64) = 1152921510107031584 (0x1000000147D62820);
            // 0x0142DE24: SUB sp, sp, #0x20          | SP = (1152921510107031520 - 32) = 1152921510107031488 (0x1000000147D627C0);
            // 0x0142DE28: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142DE2C: LDRB w8, [x20, #0x23]      | W8 = (bool)static_value_03737023;       
            // 0x0142DE30: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142DE34: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142DE38: MOV x21, x1                | X21 = X1;//m1                           
            val_19 = X1;
            // 0x0142DE3C: TBNZ w8, #0, #0x142de58    | if (static_value_03737023 == true) goto label_0;
            // 0x0142DE40: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x0142DE44: LDR x8, [x8, #0xf08]       | X8 = 0x2B900C0;                         
            // 0x0142DE48: LDR w0, [x8]               | W0 = 0x16F4;                            
            // 0x0142DE4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F4, ????);     
            // 0x0142DE50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142DE54: STRB w8, [x20, #0x23]      | static_value_03737023 = true;            //  dest_result_addr=57896995
            label_0:
            // 0x0142DE58: CBNZ x21, #0x142de60       | if (X1 != 0) goto label_1;              
            if(val_19 != 0)
            {
                goto label_1;
            }
            // 0x0142DE5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F4, ????);     
            label_1:
            // 0x0142DE60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142DE64: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142DE68: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_19.AppDomain;
            // 0x0142DE6C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142DE70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DE74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DE78: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142DE7C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142DE80: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142DE84: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142DE88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DE8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DE90: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142DE94: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142DE98: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142DE9C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142DEA0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142DEA4: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142DEA8: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0142DEAC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142DEB0: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142DEB4: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0142DEB8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142DEBC: TBZ w9, #0, #0x142ded0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142DEC0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142DEC4: CBNZ w9, #0x142ded0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142DEC8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142DECC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142DED0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DED8: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142DEDC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142DEE0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142DEE4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142DEE8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142DEEC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142DEF0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142DEF4: TBZ w9, #0, #0x142df08     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142DEF8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142DEFC: CBNZ w9, #0x142df08        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142DF00: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142DF04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142DF08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DF0C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142DF10: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142DF14: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142DF18: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142DF1C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142DF20: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142DF24: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142DF28: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0142DF2C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142DF30: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142DF34: TBZ w9, #0, #0x142df48     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142DF38: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142DF3C: CBNZ w9, #0x142df48        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142DF40: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142DF44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142DF48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DF4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DF50: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142DF54: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0142DF58: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142DF5C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x0142DF60: CBZ x0, #0x142dfa8         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142DF64: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142DF68: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142DF6C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142DF70: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142DF74: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142DF78: MOV x24, x0                | X24 = val_6;//m1                        
            val_20 = val_6;
            // 0x0142DF7C: B.EQ #0x142dfa8            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0142DF80: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142DF84: MOV x8, sp                 | X8 = 1152921510107031488 (0x1000000147D627C0);//ML01
            // 0x0142DF88: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142DF8C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510107019600]
            // 0x0142DF90: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142DF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142DF98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142DF9C: MOV x0, sp                 | X0 = 1152921510107031488 (0x1000000147D627C0);//ML01
            // 0x0142DFA0: BL #0x299a140              | 
            // 0x0142DFA4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_9:
            // 0x0142DFA8: CBNZ x21, #0x142dfb0       | if (X1 != 0) goto label_10;             
            if(val_19 != 0)
            {
                goto label_10;
            }
            // 0x0142DFAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D627C0, ????);
            label_10:
            // 0x0142DFB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DFB4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142DFB8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142DFBC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_19.Free(esp:  null);
            // 0x0142DFC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DFC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142DFC8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142DFCC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142DFD0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142DFD4: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0142DFD8: LDR x8, [x8, #0xbe0]       | X8 = 1152921504690233344;               
            // 0x0142DFDC: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142DFE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DFE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142DFE8: LDR x1, [x8]               | X1 = typeof(UnityEngine.AndroidJavaClass);
            // 0x0142DFEC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142DFF0: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0142DFF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142DFF8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142DFFC: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142E000: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142E004: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142E008: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142E00C: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0142E010: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E014: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E018: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0142E01C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0142E020: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x0142E024: CBZ x0, #0x142e088         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x0142E028: ADRP x9, #0x3641000        | X9 = 56889344 (0x3641000);              
            // 0x0142E02C: LDR x9, [x9, #0xa30]       | X9 = 1152921504690233344;               
            // 0x0142E030: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142E034: LDR x1, [x9]               | X1 = typeof(UnityEngine.AndroidJavaClass);
            // 0x0142E038: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142E03C: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.AndroidJavaClass.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142E040: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.AndroidJavaClass.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142E044: B.LO #0x142e060            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.AndroidJavaClass.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x0142E048: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142E04C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaClass.__il2cppRunti
            // 0x0142E050: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaClass.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142E054: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaClass.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.AndroidJavaClass))
            // 0x0142E058: MOV x23, x0                | X23 = val_11;//m1                       
            val_21 = val_11;
            // 0x0142E05C: B.EQ #0x142e088            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaClass.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x0142E060: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142E064: ADD x8, sp, #8             | X8 = (1152921510107031488 + 8) = 1152921510107031496 (0x1000000147D627C8);
            // 0x0142E068: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142E06C: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510107019600]
            // 0x0142E070: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x0142E074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E078: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x0142E07C: ADD x0, sp, #8             | X0 = (1152921510107031488 + 8) = 1152921510107031496 (0x1000000147D627C8);
            // 0x0142E080: BL #0x299a140              | 
            // 0x0142E084: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_13:
            // 0x0142E088: CBNZ x21, #0x142e090       | if (X1 != 0) goto label_14;             
            if(val_19 != 0)
            {
                goto label_14;
            }
            // 0x0142E08C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D627C8, ????);
            label_14:
            // 0x0142E090: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E094: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142E098: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142E09C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_19.Free(esp:  null);
            // 0x0142E0A0: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142E0A4: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142E0A8: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142E0AC: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142E0B0: TBZ w8, #0, #0x142e0c0     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x0142E0B4: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142E0B8: CBNZ w8, #0x142e0c0        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x0142E0BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_16:
            // 0x0142E0C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E0C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E0C8: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142E0CC: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0142E0D0: BL #0xba698c               | X0 = CallJSApi.GetJavaStaticAJO(_javaClass:  0, _name:  val_21);
            UnityEngine.AndroidJavaObject val_14 = CallJSApi.GetJavaStaticAJO(_javaClass:  0, _name:  val_21);
            // 0x0142E0D4: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x0142E0D8: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_22 = 1152921504824418304;
            // 0x0142E0DC: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x0142E0E0: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_23 = null;
            // 0x0142E0E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142E0E8: CBZ x0, #0x142e17c         | if (val_14 == null) goto label_17;      
            if(val_14 == null)
            {
                goto label_17;
            }
            // 0x0142E0EC: CBZ x22, #0x142e194        | if (val_14 == null) goto label_18;      
            if(val_14 == null)
            {
                goto label_18;
            }
            // 0x0142E0F0: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x0142E0F4: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x0142E0F8: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142E0FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142E100: CBNZ x0, #0x142e134        | if (val_14 != null) goto label_19;      
            if(val_14 != null)
            {
                goto label_19;
            }
            // 0x0142E104: LDR x8, [x22]              | X8 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E108: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142E10C: LDR x0, [x8, #0x30]        | X0 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class;
            // 0x0142E110: ADD x8, sp, #0x10          | X8 = (1152921510107031488 + 16) = 1152921510107031504 (0x1000000147D627D0);
            // 0x0142E114: BL #0x27d96d4              | X0 = sub_27D96D4( ?? UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class, ????);
            // 0x0142E118: LDR x0, [sp, #0x10]        | X0 = val_15;                             //  find_add[1152921510107019600]
            // 0x0142E11C: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x0142E120: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E124: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x0142E128: ADD x0, sp, #0x10          | X0 = (1152921510107031488 + 16) = 1152921510107031504 (0x1000000147D627D0);
            // 0x0142E12C: BL #0x299a140              | 
            // 0x0142E130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D627D0, ????);
            label_19:
            // 0x0142E134: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_19 = null;
            // 0x0142E138: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x0142E13C: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_23 = val_19;
            // 0x0142E140: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142E144: MOV x23, x0                | X23 = val_14;//m1                       
            val_22 = val_14;
            // 0x0142E148: CBNZ x23, #0x142e1a0       | if (val_14 != null) goto label_20;      
            if(val_22 != null)
            {
                goto label_20;
            }
            // 0x0142E14C: LDR x8, [x22]              | X8 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E150: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142E154: LDR x0, [x8, #0x30]        | X0 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class;
            // 0x0142E158: ADD x8, sp, #0x18          | X8 = (1152921510107031488 + 24) = 1152921510107031512 (0x1000000147D627D8);
            // 0x0142E15C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class, ????);
            // 0x0142E160: LDR x0, [sp, #0x18]        | X0 = val_16;                             //  find_add[1152921510107019600]
            // 0x0142E164: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x0142E168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_23 = 0;
            // 0x0142E16C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x0142E170: ADD x0, sp, #0x18          | X0 = (1152921510107031488 + 24) = 1152921510107031512 (0x1000000147D627D8);
            // 0x0142E174: BL #0x299a140              | 
            // 0x0142E178: B #0x142e19c               |  goto label_21;                         
            goto label_21;
            label_17:
            // 0x0142E17C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E180: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142E184: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142E188: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142E18C: MOV x3, x22                | X3 = val_14;//m1                        
            // 0x0142E190: B #0x142e214               |  goto label_22;                         
            goto label_22;
            label_18:
            // 0x0142E194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x0142E198: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_19 = null;
            label_21:
            // 0x0142E19C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_20:
            // 0x0142E1A0: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x0142E1A4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0142E1A8: CBZ x9, #0x142e1d4         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x0142E1AC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_18 = mem[282584257676823];
            // 0x0142E1B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_19 = 0;
            // 0x0142E1B4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_18 = val_18 + 8;
            label_25:
            // 0x0142E1B8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0142E1BC: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x0142E1C0: B.EQ #0x142e1e8            | if ((mem[282584257676823] + 8) + -8 == val_19) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == val_19)
            {
                goto label_24;
            }
            // 0x0142E1C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_19 = val_19 + 1;
            // 0x0142E1C8: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_18 = val_18 + 16;
            // 0x0142E1CC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0142E1D0: B.LO #0x142e1b8            | if (0 < mem[282584257676929]) goto label_25;
            if(val_19 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x0142E1D4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142E1D8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_24 = val_22;
            // 0x0142E1DC: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_23 = val_19;
            // 0x0142E1E0: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0142E1E4: B #0x142e1f4               |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x0142E1E8: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x0142E1EC: ADD x8, x8, x9, lsl #4     | X8 = (val_22 + ((mem[282584257676823] + 8)) << 4);
            val_22 = val_22 + (((mem[282584257676823] + 8)) << 4);
            // 0x0142E1F0: ADD x0, x8, #0x110         | X0 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_24 = val_22 + 272;
            label_26:
            // 0x0142E1F4: LDP x8, x1, [x0]           | X8 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0142E1F8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142E1FC: BLR x8                     | X0 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x0142E200: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x0142E204: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E208: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142E20C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142E210: MOV x2, x19                | X2 = X3;//m1                            
            label_22:
            // 0x0142E214: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142E218: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_17 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x0142E21C: SUB sp, x29, #0x40         | SP = (1152921510107031584 - 64) = 1152921510107031520 (0x1000000147D627E0);
            // 0x0142E220: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142E224: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142E228: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142E22C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142E230: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142E234: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_17;
            return val_17;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142E238: MOV x19, x0                | 
            // 0x0142E23C: ADD x0, sp, #8             | 
            // 0x0142E240: B #0x142e264               | 
            // 0x0142E244: MOV x19, x0                | 
            // 0x0142E248: MOV x0, sp                 | 
            // 0x0142E24C: B #0x142e264               | 
            // 0x0142E250: MOV x19, x0                | 
            // 0x0142E254: ADD x0, sp, #0x10          | 
            // 0x0142E258: B #0x142e264               | 
            // 0x0142E25C: MOV x19, x0                | 
            // 0x0142E260: ADD x0, sp, #0x18          | 
            label_29:
            // 0x0142E264: BL #0x299a140              | 
            // 0x0142E268: MOV x0, x19                | 
            // 0x0142E26C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142E270 (21160560), len: 800  VirtAddr: 0x0142E270 RVA: 0x0142E270 token: 100664132 methodIndex: 30177 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetJavaString_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            var val_16;
            //  | 
            string val_17;
            // 0x0142E270: STP x26, x25, [sp, #-0x50]! | stack[1152921510107233632] = ???;  stack[1152921510107233640] = ???;  //  dest_result_addr=1152921510107233632 |  dest_result_addr=1152921510107233640
            // 0x0142E274: STP x24, x23, [sp, #0x10]  | stack[1152921510107233648] = ???;  stack[1152921510107233656] = ???;  //  dest_result_addr=1152921510107233648 |  dest_result_addr=1152921510107233656
            // 0x0142E278: STP x22, x21, [sp, #0x20]  | stack[1152921510107233664] = ???;  stack[1152921510107233672] = ???;  //  dest_result_addr=1152921510107233664 |  dest_result_addr=1152921510107233672
            // 0x0142E27C: STP x20, x19, [sp, #0x30]  | stack[1152921510107233680] = ???;  stack[1152921510107233688] = ???;  //  dest_result_addr=1152921510107233680 |  dest_result_addr=1152921510107233688
            // 0x0142E280: STP x29, x30, [sp, #0x40]  | stack[1152921510107233696] = ???;  stack[1152921510107233704] = ???;  //  dest_result_addr=1152921510107233696 |  dest_result_addr=1152921510107233704
            // 0x0142E284: ADD x29, sp, #0x40         | X29 = (1152921510107233632 + 64) = 1152921510107233696 (0x1000000147D93DA0);
            // 0x0142E288: SUB sp, sp, #0x10          | SP = (1152921510107233632 - 16) = 1152921510107233616 (0x1000000147D93D50);
            // 0x0142E28C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142E290: LDRB w8, [x21, #0x24]      | W8 = (bool)static_value_03737024;       
            // 0x0142E294: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142E298: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142E29C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0142E2A0: TBNZ w8, #0, #0x142e2bc    | if (static_value_03737024 == true) goto label_0;
            // 0x0142E2A4: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x0142E2A8: LDR x8, [x8, #0x148]       | X8 = 0x2B900C4;                         
            // 0x0142E2AC: LDR w0, [x8]               | W0 = 0x16F5;                            
            // 0x0142E2B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F5, ????);     
            // 0x0142E2B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142E2B8: STRB w8, [x21, #0x24]      | static_value_03737024 = true;            //  dest_result_addr=57896996
            label_0:
            // 0x0142E2BC: CBNZ x20, #0x142e2c4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142E2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F5, ????);     
            label_1:
            // 0x0142E2C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E2C8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142E2CC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142E2D0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142E2D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E2D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E2DC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142E2E0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142E2E4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142E2E8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0142E2EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E2F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E2F4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142E2F8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142E2FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142E300: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142E304: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142E308: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142E30C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0142E310: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142E314: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142E318: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0142E31C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142E320: TBZ w9, #0, #0x142e334     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142E324: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142E328: CBNZ w9, #0x142e334        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142E32C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142E330: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142E334: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E338: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E33C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142E340: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142E344: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142E348: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142E34C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142E350: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142E354: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142E358: TBZ w9, #0, #0x142e36c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142E35C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142E360: CBNZ w9, #0x142e36c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142E364: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142E368: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142E36C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E370: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142E374: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142E378: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142E37C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142E380: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142E384: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142E388: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142E38C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0142E390: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142E394: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142E398: TBZ w9, #0, #0x142e3ac     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142E39C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142E3A0: CBNZ w9, #0x142e3ac        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142E3A4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142E3A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142E3AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E3B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E3B4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142E3B8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0142E3BC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142E3C0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x0142E3C4: CBZ x0, #0x142e40c         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142E3C8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142E3CC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142E3D0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142E3D4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142E3D8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142E3DC: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x0142E3E0: B.EQ #0x142e40c            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0142E3E4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142E3E8: MOV x8, sp                 | X8 = 1152921510107233616 (0x1000000147D93D50);//ML01
            // 0x0142E3EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142E3F0: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510107221712]
            // 0x0142E3F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142E3F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E3FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142E400: MOV x0, sp                 | X0 = 1152921510107233616 (0x1000000147D93D50);//ML01
            // 0x0142E404: BL #0x299a140              | 
            // 0x0142E408: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x0142E40C: CBNZ x20, #0x142e414       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0142E410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D93D50, ????);
            label_10:
            // 0x0142E414: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E418: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142E41C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142E420: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142E424: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E428: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E42C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142E430: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142E434: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142E438: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x0142E43C: LDR x8, [x8, #0xd70]       | X8 = 1152921504690180096;               
            // 0x0142E440: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142E444: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E448: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E44C: LDR x1, [x8]               | X1 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E450: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142E454: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0142E458: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E45C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142E460: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142E464: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142E468: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142E46C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142E470: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0142E474: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E478: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E47C: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0142E480: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0142E484: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x0142E488: CBZ x0, #0x142e4ec         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x0142E48C: ADRP x9, #0x35f0000        | X9 = 56557568 (0x35F0000);              
            // 0x0142E490: LDR x9, [x9, #0xff0]       | X9 = 1152921504690180096;               
            // 0x0142E494: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142E498: LDR x1, [x9]               | X1 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E49C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142E4A0: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142E4A4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142E4A8: B.LO #0x142e4c4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x0142E4AC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142E4B0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRunt
            // 0x0142E4B4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142E4B8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.AndroidJavaObject))
            // 0x0142E4BC: MOV x23, x0                | X23 = val_11;//m1                       
            val_17 = val_11;
            // 0x0142E4C0: B.EQ #0x142e4ec            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x0142E4C4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142E4C8: ADD x8, sp, #8             | X8 = (1152921510107233616 + 8) = 1152921510107233624 (0x1000000147D93D58);
            // 0x0142E4CC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142E4D0: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510107221712]
            // 0x0142E4D4: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x0142E4D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E4DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x0142E4E0: ADD x0, sp, #8             | X0 = (1152921510107233616 + 8) = 1152921510107233624 (0x1000000147D93D58);
            // 0x0142E4E4: BL #0x299a140              | 
            // 0x0142E4E8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x0142E4EC: CBNZ x20, #0x142e4f4       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x0142E4F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147D93D58, ????);
            label_14:
            // 0x0142E4F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E4F8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0142E4FC: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142E500: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142E504: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142E508: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142E50C: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142E510: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142E514: TBZ w8, #0, #0x142e524     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x0142E518: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142E51C: CBNZ w8, #0x142e524        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x0142E520: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_16:
            // 0x0142E524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E528: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E52C: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142E530: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0142E534: BL #0xba69f4               | X0 = CallJSApi.GetJavaString(_ajo:  0, _name:  val_17);
            string val_14 = CallJSApi.GetJavaString(_ajo:  0, _name:  val_17);
            // 0x0142E538: MOV x3, x0                 | X3 = val_14;//m1                        
            // 0x0142E53C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E540: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142E544: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0142E548: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142E54C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142E550: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0142E554: SUB sp, x29, #0x40         | SP = (1152921510107233696 - 64) = 1152921510107233632 (0x1000000147D93D60);
            // 0x0142E558: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142E55C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142E560: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142E564: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142E568: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142E56C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142E570: MOV x19, x0                | 
            // 0x0142E574: ADD x0, sp, #8             | 
            // 0x0142E578: B #0x142e584               | 
            // 0x0142E57C: MOV x19, x0                | 
            // 0x0142E580: MOV x0, sp                 | 
            label_17:
            // 0x0142E584: BL #0x299a140              | 
            // 0x0142E588: MOV x0, x19                | 
            // 0x0142E58C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142E590 (21161360), len: 1124  VirtAddr: 0x0142E590 RVA: 0x0142E590 token: 100664133 methodIndex: 30178 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* CallJavaAJO_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            string val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            // 0x0142E590: STP x26, x25, [sp, #-0x50]! | stack[1152921510107435744] = ???;  stack[1152921510107435752] = ???;  //  dest_result_addr=1152921510107435744 |  dest_result_addr=1152921510107435752
            // 0x0142E594: STP x24, x23, [sp, #0x10]  | stack[1152921510107435760] = ???;  stack[1152921510107435768] = ???;  //  dest_result_addr=1152921510107435760 |  dest_result_addr=1152921510107435768
            // 0x0142E598: STP x22, x21, [sp, #0x20]  | stack[1152921510107435776] = ???;  stack[1152921510107435784] = ???;  //  dest_result_addr=1152921510107435776 |  dest_result_addr=1152921510107435784
            // 0x0142E59C: STP x20, x19, [sp, #0x30]  | stack[1152921510107435792] = ???;  stack[1152921510107435800] = ???;  //  dest_result_addr=1152921510107435792 |  dest_result_addr=1152921510107435800
            // 0x0142E5A0: STP x29, x30, [sp, #0x40]  | stack[1152921510107435808] = ???;  stack[1152921510107435816] = ???;  //  dest_result_addr=1152921510107435808 |  dest_result_addr=1152921510107435816
            // 0x0142E5A4: ADD x29, sp, #0x40         | X29 = (1152921510107435744 + 64) = 1152921510107435808 (0x1000000147DC5320);
            // 0x0142E5A8: SUB sp, sp, #0x20          | SP = (1152921510107435744 - 32) = 1152921510107435712 (0x1000000147DC52C0);
            // 0x0142E5AC: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142E5B0: LDRB w8, [x20, #0x25]      | W8 = (bool)static_value_03737025;       
            // 0x0142E5B4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0142E5B8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0142E5BC: MOV x21, x1                | X21 = X1;//m1                           
            val_19 = X1;
            // 0x0142E5C0: TBNZ w8, #0, #0x142e5dc    | if (static_value_03737025 == true) goto label_0;
            // 0x0142E5C4: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x0142E5C8: LDR x8, [x8, #0x4f8]       | X8 = 0x2B900B0;                         
            // 0x0142E5CC: LDR w0, [x8]               | W0 = 0x16F0;                            
            // 0x0142E5D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F0, ????);     
            // 0x0142E5D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142E5D8: STRB w8, [x20, #0x25]      | static_value_03737025 = true;            //  dest_result_addr=57896997
            label_0:
            // 0x0142E5DC: CBNZ x21, #0x142e5e4       | if (X1 != 0) goto label_1;              
            if(val_19 != 0)
            {
                goto label_1;
            }
            // 0x0142E5E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16F0, ????);     
            label_1:
            // 0x0142E5E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E5E8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142E5EC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_19.AppDomain;
            // 0x0142E5F0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0142E5F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E5F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E5FC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142E600: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142E604: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142E608: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142E60C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E610: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E614: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0142E618: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142E61C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142E620: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0142E624: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0142E628: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0142E62C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0142E630: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0142E634: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x0142E638: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0142E63C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142E640: TBZ w9, #0, #0x142e654     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0142E644: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142E648: CBNZ w9, #0x142e654        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0142E64C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142E650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0142E654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E65C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0142E660: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142E664: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0142E668: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0142E66C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0142E670: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142E674: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0142E678: TBZ w9, #0, #0x142e68c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142E67C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142E680: CBNZ w9, #0x142e68c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0142E684: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0142E688: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142E68C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E690: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142E694: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142E698: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142E69C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142E6A0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142E6A4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0142E6A8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142E6AC: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0142E6B0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142E6B4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0142E6B8: TBZ w9, #0, #0x142e6cc     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142E6BC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0142E6C0: CBNZ w9, #0x142e6cc        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0142E6C4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0142E6C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142E6CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E6D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E6D4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0142E6D8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0142E6DC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142E6E0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x0142E6E4: CBZ x0, #0x142e72c         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0142E6E8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142E6EC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142E6F0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142E6F4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142E6F8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0142E6FC: MOV x24, x0                | X24 = val_6;//m1                        
            val_20 = val_6;
            // 0x0142E700: B.EQ #0x142e72c            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0142E704: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142E708: MOV x8, sp                 | X8 = 1152921510107435712 (0x1000000147DC52C0);//ML01
            // 0x0142E70C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142E710: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510107423824]
            // 0x0142E714: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0142E718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E71C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0142E720: MOV x0, sp                 | X0 = 1152921510107435712 (0x1000000147DC52C0);//ML01
            // 0x0142E724: BL #0x299a140              | 
            // 0x0142E728: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_9:
            // 0x0142E72C: CBNZ x21, #0x142e734       | if (X1 != 0) goto label_10;             
            if(val_19 != 0)
            {
                goto label_10;
            }
            // 0x0142E730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147DC52C0, ????);
            label_10:
            // 0x0142E734: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E738: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142E73C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0142E740: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_19.Free(esp:  null);
            // 0x0142E744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E74C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142E750: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0142E754: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142E758: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x0142E75C: LDR x8, [x8, #0xd70]       | X8 = 1152921504690180096;               
            // 0x0142E760: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0142E764: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E768: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E76C: LDR x1, [x8]               | X1 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E770: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142E774: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0142E778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E77C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142E780: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142E784: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142E788: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0142E78C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x0142E790: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0142E794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E798: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E79C: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0142E7A0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0142E7A4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x0142E7A8: CBZ x0, #0x142e80c         | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x0142E7AC: ADRP x9, #0x35f0000        | X9 = 56557568 (0x35F0000);              
            // 0x0142E7B0: LDR x9, [x9, #0xff0]       | X9 = 1152921504690180096;               
            // 0x0142E7B4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142E7B8: LDR x1, [x9]               | X1 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E7BC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142E7C0: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142E7C4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142E7C8: B.LO #0x142e7e4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x0142E7CC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142E7D0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRunt
            // 0x0142E7D4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142E7D8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.AndroidJavaObject))
            // 0x0142E7DC: MOV x23, x0                | X23 = val_11;//m1                       
            val_21 = val_11;
            // 0x0142E7E0: B.EQ #0x142e80c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UnityEngine.AndroidJavaObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x0142E7E4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0142E7E8: ADD x8, sp, #8             | X8 = (1152921510107435712 + 8) = 1152921510107435720 (0x1000000147DC52C8);
            // 0x0142E7EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0142E7F0: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510107423824]
            // 0x0142E7F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x0142E7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E7FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x0142E800: ADD x0, sp, #8             | X0 = (1152921510107435712 + 8) = 1152921510107435720 (0x1000000147DC52C8);
            // 0x0142E804: BL #0x299a140              | 
            // 0x0142E808: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_13:
            // 0x0142E80C: CBNZ x21, #0x142e814       | if (X1 != 0) goto label_14;             
            if(val_19 != 0)
            {
                goto label_14;
            }
            // 0x0142E810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147DC52C8, ????);
            label_14:
            // 0x0142E814: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142E818: MOV x0, x21                | X0 = X1;//m1                            
            // 0x0142E81C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0142E820: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_19.Free(esp:  null);
            // 0x0142E824: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x0142E828: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
            // 0x0142E82C: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
            // 0x0142E830: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142E834: TBZ w8, #0, #0x142e844     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x0142E838: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142E83C: CBNZ w8, #0x142e844        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x0142E840: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            label_16:
            // 0x0142E844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142E84C: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0142E850: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0142E854: BL #0xba6a5c               | X0 = CallJSApi.CallJavaAJO(_ajo:  0, _name:  val_21);
            UnityEngine.AndroidJavaObject val_14 = CallJSApi.CallJavaAJO(_ajo:  0, _name:  val_21);
            // 0x0142E858: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x0142E85C: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_22 = 1152921504824418304;
            // 0x0142E860: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x0142E864: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_23 = null;
            // 0x0142E868: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142E86C: CBZ x0, #0x142e900         | if (val_14 == null) goto label_17;      
            if(val_14 == null)
            {
                goto label_17;
            }
            // 0x0142E870: CBZ x22, #0x142e918        | if (val_14 == null) goto label_18;      
            if(val_14 == null)
            {
                goto label_18;
            }
            // 0x0142E874: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x0142E878: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x0142E87C: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142E880: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142E884: CBNZ x0, #0x142e8b8        | if (val_14 != null) goto label_19;      
            if(val_14 != null)
            {
                goto label_19;
            }
            // 0x0142E888: LDR x8, [x22]              | X8 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E88C: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142E890: LDR x0, [x8, #0x30]        | X0 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class;
            // 0x0142E894: ADD x8, sp, #0x10          | X8 = (1152921510107435712 + 16) = 1152921510107435728 (0x1000000147DC52D0);
            // 0x0142E898: BL #0x27d96d4              | X0 = sub_27D96D4( ?? UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class, ????);
            // 0x0142E89C: LDR x0, [sp, #0x10]        | X0 = val_15;                             //  find_add[1152921510107423824]
            // 0x0142E8A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x0142E8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142E8A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x0142E8AC: ADD x0, sp, #0x10          | X0 = (1152921510107435712 + 16) = 1152921510107435728 (0x1000000147DC52D0);
            // 0x0142E8B0: BL #0x299a140              | 
            // 0x0142E8B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147DC52D0, ????);
            label_19:
            // 0x0142E8B8: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_19 = null;
            // 0x0142E8BC: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x0142E8C0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_23 = val_19;
            // 0x0142E8C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0142E8C8: MOV x23, x0                | X23 = val_14;//m1                       
            val_22 = val_14;
            // 0x0142E8CC: CBNZ x23, #0x142e924       | if (val_14 != null) goto label_20;      
            if(val_22 != null)
            {
                goto label_20;
            }
            // 0x0142E8D0: LDR x8, [x22]              | X8 = typeof(UnityEngine.AndroidJavaObject);
            // 0x0142E8D4: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x0142E8D8: LDR x0, [x8, #0x30]        | X0 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class;
            // 0x0142E8DC: ADD x8, sp, #0x18          | X8 = (1152921510107435712 + 24) = 1152921510107435736 (0x1000000147DC52D8);
            // 0x0142E8E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? UnityEngine.AndroidJavaObject.__il2cppRuntimeField_element_class, ????);
            // 0x0142E8E4: LDR x0, [sp, #0x18]        | X0 = val_16;                             //  find_add[1152921510107423824]
            // 0x0142E8E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x0142E8EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_23 = 0;
            // 0x0142E8F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x0142E8F4: ADD x0, sp, #0x18          | X0 = (1152921510107435712 + 24) = 1152921510107435736 (0x1000000147DC52D8);
            // 0x0142E8F8: BL #0x299a140              | 
            // 0x0142E8FC: B #0x142e920               |  goto label_21;                         
            goto label_21;
            label_17:
            // 0x0142E900: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E904: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142E908: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142E90C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0142E910: MOV x3, x22                | X3 = val_14;//m1                        
            // 0x0142E914: B #0x142e998               |  goto label_22;                         
            goto label_22;
            label_18:
            // 0x0142E918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x0142E91C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_19 = null;
            label_21:
            // 0x0142E920: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_20:
            // 0x0142E924: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x0142E928: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x0142E92C: CBZ x9, #0x142e958         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x0142E930: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_18 = mem[282584257676823];
            // 0x0142E934: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_19 = 0;
            // 0x0142E938: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_18 = val_18 + 8;
            label_25:
            // 0x0142E93C: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x0142E940: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x0142E944: B.EQ #0x142e96c            | if ((mem[282584257676823] + 8) + -8 == val_19) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == val_19)
            {
                goto label_24;
            }
            // 0x0142E948: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_19 = val_19 + 1;
            // 0x0142E94C: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_18 = val_18 + 16;
            // 0x0142E950: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x0142E954: B.LO #0x142e93c            | if (0 < mem[282584257676929]) goto label_25;
            if(val_19 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x0142E958: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0142E95C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_24 = val_22;
            // 0x0142E960: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_23 = val_19;
            // 0x0142E964: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x0142E968: B #0x142e978               |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x0142E96C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x0142E970: ADD x8, x8, x9, lsl #4     | X8 = (val_22 + ((mem[282584257676823] + 8)) << 4);
            val_22 = val_22 + (((mem[282584257676823] + 8)) << 4);
            // 0x0142E974: ADD x0, x8, #0x110         | X0 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_24 = val_22 + 272;
            label_26:
            // 0x0142E978: LDP x8, x1, [x0]           | X8 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x0142E97C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0142E980: BLR x8                     | X0 = ((val_22 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x0142E984: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x0142E988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142E98C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0142E990: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x0142E994: MOV x2, x19                | X2 = X3;//m1                            
            label_22:
            // 0x0142E998: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0142E99C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_17 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x0142E9A0: SUB sp, x29, #0x40         | SP = (1152921510107435808 - 64) = 1152921510107435744 (0x1000000147DC52E0);
            // 0x0142E9A4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142E9A8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0142E9AC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142E9B0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142E9B4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142E9B8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_17;
            return val_17;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0142E9BC: MOV x19, x0                | 
            // 0x0142E9C0: ADD x0, sp, #8             | 
            // 0x0142E9C4: B #0x142e9e8               | 
            // 0x0142E9C8: MOV x19, x0                | 
            // 0x0142E9CC: MOV x0, sp                 | 
            // 0x0142E9D0: B #0x142e9e8               | 
            // 0x0142E9D4: MOV x19, x0                | 
            // 0x0142E9D8: ADD x0, sp, #0x10          | 
            // 0x0142E9DC: B #0x142e9e8               | 
            // 0x0142E9E0: MOV x19, x0                | 
            // 0x0142E9E4: ADD x0, sp, #0x18          | 
            label_29:
            // 0x0142E9E8: BL #0x299a140              | 
            // 0x0142E9EC: MOV x0, x19                | 
            // 0x0142E9F0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142E9F4 (21162484), len: 104  VirtAddr: 0x0142E9F4 RVA: 0x0142E9F4 token: 100664134 methodIndex: 30179 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_jsStr_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0142E9F4: STP x20, x19, [sp, #-0x20]! | stack[1152921510107596864] = ???;  stack[1152921510107596872] = ???;  //  dest_result_addr=1152921510107596864 |  dest_result_addr=1152921510107596872
            // 0x0142E9F8: STP x29, x30, [sp, #0x10]  | stack[1152921510107596880] = ???;  stack[1152921510107596888] = ???;  //  dest_result_addr=1152921510107596880 |  dest_result_addr=1152921510107596888
            // 0x0142E9FC: ADD x29, sp, #0x10         | X29 = (1152921510107596864 + 16) = 1152921510107596880 (0x1000000147DEC850);
            // 0x0142EA00: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0142EA04: LDRB w8, [x19, #0x26]      | W8 = (bool)static_value_03737026;       
            // 0x0142EA08: TBNZ w8, #0, #0x142ea24    | if (static_value_03737026 == true) goto label_0;
            // 0x0142EA0C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0142EA10: LDR x8, [x8, #0x708]       | X8 = 0x2B900BC;                         
            // 0x0142EA14: LDR w0, [x8]               | W0 = 0x16F3;                            
            // 0x0142EA18: BL #0x2782188              | X0 = sub_2782188( ?? 0x16F3, ????);     
            // 0x0142EA1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142EA20: STRB w8, [x19, #0x26]      | static_value_03737026 = true;            //  dest_result_addr=57896998
            label_0:
            // 0x0142EA24: ADRP x19, #0x3604000       | X19 = 56639488 (0x3604000);             
            // 0x0142EA28: LDR x19, [x19, #0xb68]     | X19 = 1152921504901255168;              
            // 0x0142EA2C: LDR x0, [x19]              | X0 = typeof(CallJSApi);                 
            val_1 = null;
            // 0x0142EA30: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142EA34: TBZ w8, #0, #0x142ea48     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0142EA38: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142EA3C: CBNZ w8, #0x142ea48        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0142EA40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            // 0x0142EA44: LDR x0, [x19]              | X0 = typeof(CallJSApi);                 
            val_1 = null;
            label_2:
            // 0x0142EA48: LDR x8, [x0, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
            // 0x0142EA4C: LDR x0, [x8, #8]           | X0 = CallJSApi.jsStr;                   
            // 0x0142EA50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0142EA54: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0142EA58: RET                        |  return (System.Object)CallJSApi.jsStr; 
            return (object)CallJSApi.jsStr;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0142EA5C (21162588), len: 204  VirtAddr: 0x0142EA5C RVA: 0x0142EA5C token: 100664135 methodIndex: 30180 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_jsStr_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            string val_2;
            //  | 
            var val_3;
            // 0x0142EA5C: STP x20, x19, [sp, #-0x20]! | stack[1152921510107720992] = ???;  stack[1152921510107721000] = ???;  //  dest_result_addr=1152921510107720992 |  dest_result_addr=1152921510107721000
            // 0x0142EA60: STP x29, x30, [sp, #0x10]  | stack[1152921510107721008] = ???;  stack[1152921510107721016] = ???;  //  dest_result_addr=1152921510107721008 |  dest_result_addr=1152921510107721016
            // 0x0142EA64: ADD x29, sp, #0x10         | X29 = (1152921510107720992 + 16) = 1152921510107721008 (0x1000000147E0AD30);
            // 0x0142EA68: SUB sp, sp, #0x10          | SP = (1152921510107720992 - 16) = 1152921510107720976 (0x1000000147E0AD10);
            // 0x0142EA6C: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0142EA70: LDRB w8, [x20, #0x27]      | W8 = (bool)static_value_03737027;       
            // 0x0142EA74: MOV x19, x2                | X19 = X2;//m1                           
            val_2 = X2;
            // 0x0142EA78: TBNZ w8, #0, #0x142ea94    | if (static_value_03737027 == true) goto label_0;
            // 0x0142EA7C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0142EA80: LDR x8, [x8, #0xe20]       | X8 = 0x2B900D8;                         
            // 0x0142EA84: LDR w0, [x8]               | W0 = 0x16FA;                            
            // 0x0142EA88: BL #0x2782188              | X0 = sub_2782188( ?? 0x16FA, ????);     
            // 0x0142EA8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142EA90: STRB w8, [x20, #0x27]      | static_value_03737027 = true;            //  dest_result_addr=57896999
            label_0:
            // 0x0142EA94: ADRP x20, #0x3604000       | X20 = 56639488 (0x3604000);             
            // 0x0142EA98: LDR x20, [x20, #0xb68]     | X20 = 1152921504901255168;              
            // 0x0142EA9C: LDR x0, [x20]              | X0 = typeof(CallJSApi);                 
            val_3 = null;
            // 0x0142EAA0: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
            // 0x0142EAA4: TBZ w8, #0, #0x142eab8     | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0142EAA8: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
            // 0x0142EAAC: CBNZ w8, #0x142eab8        | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0142EAB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
            // 0x0142EAB4: LDR x0, [x20]              | X0 = typeof(CallJSApi);                 
            val_3 = null;
            label_2:
            // 0x0142EAB8: LDR x20, [x0, #0xa0]       | X20 = CallJSApi.__il2cppRuntimeField_static_fields;
            // 0x0142EABC: CBZ x19, #0x142eafc        | if (X2 == 0) goto label_3;              
            if(val_2 == 0)
            {
                goto label_3;
            }
            // 0x0142EAC0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0142EAC4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142EAC8: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0142EACC: LDR x8, [x19]              | X8 = X2;                                
            // 0x0142EAD0: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x0142EAD4: B.EQ #0x142eb00            | if (val_2 == null) goto label_4;        
            if(val_2 == null)
            {
                goto label_4;
            }
            // 0x0142EAD8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x0142EADC: ADD x8, sp, #8             | X8 = (1152921510107720976 + 8) = 1152921510107720984 (0x1000000147E0AD18);
            // 0x0142EAE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x0142EAE4: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921510107709024]
            // 0x0142EAE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0142EAEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142EAF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0142EAF4: ADD x0, sp, #8             | X0 = (1152921510107720976 + 8) = 1152921510107720984 (0x1000000147E0AD18);
            // 0x0142EAF8: BL #0x299a140              | 
            label_3:
            // 0x0142EAFC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_2 = 0;
            label_4:
            // 0x0142EB00: STR x19, [x20, #8]         | CallJSApi.jsStr = null;                  //  dest_result_addr=1152921504901259272
            CallJSApi.jsStr = val_2;
            // 0x0142EB04: SUB sp, x29, #0x10         | SP = (1152921510107721008 - 16) = 1152921510107720992 (0x1000000147E0AD20);
            // 0x0142EB08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0142EB0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0142EB10: RET                        |  return;                                
            return;
            // 0x0142EB14: MOV x19, x0                | 
            // 0x0142EB18: ADD x0, sp, #8             | 
            // 0x0142EB1C: BL #0x299a140              | 
            // 0x0142EB20: MOV x0, x19                | 
            // 0x0142EB24: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0142EB28 (21162792), len: 64  VirtAddr: 0x0142EB28 RVA: 0x0142EB28 token: 100664136 methodIndex: 30181 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool <Register>m__0(System.Reflection.MethodInfo t)
        {
            //
            // Disasemble & Code
            // 0x0142EB28: STP x20, x19, [sp, #-0x20]! | stack[1152921510107845200] = ???;  stack[1152921510107845208] = ???;  //  dest_result_addr=1152921510107845200 |  dest_result_addr=1152921510107845208
            // 0x0142EB2C: STP x29, x30, [sp, #0x10]  | stack[1152921510107845216] = ???;  stack[1152921510107845224] = ???;  //  dest_result_addr=1152921510107845216 |  dest_result_addr=1152921510107845224
            // 0x0142EB30: ADD x29, sp, #0x10         | X29 = (1152921510107845200 + 16) = 1152921510107845216 (0x1000000147E29260);
            // 0x0142EB34: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0142EB38: CBNZ x19, #0x142eb40       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x0142EB3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? t, ????);          
            label_0:
            // 0x0142EB40: LDR x8, [x19]              | X8 = X1;                                
            // 0x0142EB44: MOV x0, x19                | X0 = X1;//m1                            
            var val_1 = X1;
            // 0x0142EB48: LDR x9, [x8, #0x360]       | X9 = X1 + 864;                          
            // 0x0142EB4C: LDR x1, [x8, #0x368]       | X1 = X1 + 872;                          
            // 0x0142EB50: BLR x9                     | X0 = X1 + 864();                        
            // 0x0142EB54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0142EB58: MVN w8, w0                 | W8 = ~(X1);                             
            // 0x0142EB5C: AND w0, w8, #1             | W0 = (~(X1) & 1);                       
            val_1 = (~val_1) & 1;
            // 0x0142EB60: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0142EB64: RET                        |  return (System.Boolean)(~(X1) & 1);    
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
