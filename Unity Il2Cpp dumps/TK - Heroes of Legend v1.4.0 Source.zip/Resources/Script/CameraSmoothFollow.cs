using UnityEngine;
public class CameraSmoothFollow : MonoBehaviour
{
    // Fields
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x286B860
    private bool <IsOpeningMoveUpdate>k__BackingField; //  0x00000018
    public const string RX_FIXED = "Camera_RX_FIXED";
    private float deltaTime; //  0x0000001C
    private UnityEngine.Transform lastTarget; //  0x00000020
    private System.Action onFinished; //  0x00000028
    private bool isPlayMove; //  0x00000030
    private bool isChangeTarget; //  0x00000031
    private float lastChangeTime; //  0x00000034
    [UnityEngine.SerializeField] // 0x286B89C
    private UnityEngine.Animator mAnimator; //  0x00000038
    public UnityEngine.Transform _target; //  0x00000040
    private UnityEngine.Vector3 lastTargetPos; //  0x00000048
    [UnityEngine.HideInInspector] // 0x286B8AC
    public bool isNeedRXEvent; //  0x00000054
    [UnityEngine.HideInInspector] // 0x286B8BC
    public float rxError; //  0x00000058
    [UnityEngine.HideInInspector] // 0x286B8CC
    public bool isLockTarget; //  0x0000005C
    [UnityEngine.HideInInspector] // 0x286B8DC
    public bool isDamping; //  0x0000005D
    public float distance; //  0x00000060
    private float lastDistance; //  0x00000064
    public float rx; //  0x00000068
    public float ry; //  0x0000006C
    public float rz; //  0x00000070
    public float posDamping; //  0x00000074
    private UnityEngine.Transform mTransform; //  0x00000078
    private UnityEngine.Quaternion currentRotation; //  0x00000080
    public UnityEngine.Quaternion lastRotation; //  0x00000090
    public UnityEngine.Vector3 lastPos; //  0x000000A0
    private UnityEngine.Vector3 targetPos; //  0x000000AC
    private CSCheckPointUnit chapter; //  0x000000B8
    private bool isStart; //  0x000000C0
    private float distance_out; //  0x000000C4
    private float distance_in; //  0x000000C8
    private float rx_out; //  0x000000CC
    private float rx_in; //  0x000000D0
    private float alternateTime; //  0x000000D4
    private float alternateTimer; //  0x000000D8
    private bool ifMoveOnStatrBattle; //  0x000000DC
    
    // Properties
    public bool IsOpeningMoveUpdate { get; set; }
    [UnityEngine.HideInInspector] // 0x286B91C
    public UnityEngine.Transform target { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D7F2A0 (14152352), len: 184  VirtAddr: 0x00D7F2A0 RVA: 0x00D7F2A0 token: 100690261 methodIndex: 25915 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraSmoothFollow()
    {
        //
        // Disasemble & Code
        // 0x00D7F2A0: STP x20, x19, [sp, #-0x20]! | stack[1152921514498166032] = ???;  stack[1152921514498166040] = ???;  //  dest_result_addr=1152921514498166032 |  dest_result_addr=1152921514498166040
        // 0x00D7F2A4: STP x29, x30, [sp, #0x10]  | stack[1152921514498166048] = ???;  stack[1152921514498166056] = ???;  //  dest_result_addr=1152921514498166048 |  dest_result_addr=1152921514498166056
        // 0x00D7F2A8: ADD x29, sp, #0x10         | X29 = (1152921514498166032 + 16) = 1152921514498166048 (0x100000024D918D20);
        // 0x00D7F2AC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7F2B0: LDRB w8, [x20, #0x412]     | W8 = (bool)static_value_03734412;       
        // 0x00D7F2B4: MOV x19, x0                | X19 = 1152921514498178064 (0x100000024D91BC10);//ML01
        // 0x00D7F2B8: TBNZ w8, #0, #0xd7f2d4     | if (static_value_03734412 == true) goto label_0;
        // 0x00D7F2BC: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00D7F2C0: LDR x8, [x8, #0x558]       | X8 = 0x2B903A0;                         
        // 0x00D7F2C4: LDR w0, [x8]               | W0 = 0x17AC;                            
        // 0x00D7F2C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x17AC, ????);     
        // 0x00D7F2CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F2D0: STRB w8, [x20, #0x412]     | static_value_03734412 = true;            //  dest_result_addr=57885714
        label_0:
        // 0x00D7F2D4: MOVZ w11, #0x3f4c, lsl #16 | W11 = 1061945344 (0x3F4C0000);//ML01    
        // 0x00D7F2D8: MOVZ w8, #0x4120, lsl #16  | W8 = 1092616192 (0x41200000);//ML01     
        // 0x00D7F2DC: MOVZ w9, #0x420c, lsl #16  | W9 = 1108082688 (0x420C0000);//ML01     
        // 0x00D7F2E0: MOVZ w10, #0xc330, lsl #16 | W10 = 3274702848 (0xC3300000);//ML01    
        // 0x00D7F2E4: MOVK w11, #0xcccd          | W11 = 1061997773 (0x3F4CCCCD);          
        // 0x00D7F2E8: STR w8, [x19, #0x60]       | this.distance = 10;                      //  dest_result_addr=1152921514498178160
        this.distance = 10f;
        // 0x00D7F2EC: STP w9, w10, [x19, #0x68]  | this.rx = 35;  this.ry = -176;           //  dest_result_addr=1152921514498178168 |  dest_result_addr=1152921514498178172
        this.rx = 35f;
        this.ry = -176f;
        // 0x00D7F2F0: STR w11, [x19, #0x74]      | this.posDamping = 0.8;                   //  dest_result_addr=1152921514498178180
        this.posDamping = 0.8f;
        // 0x00D7F2F4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D7F2F8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D7F2FC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D7F300: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D7F304: TBZ w8, #0, #0xd7f314      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7F308: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F30C: CBNZ w8, #0xd7f314         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7F310: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00D7F314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F31C: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.zero;
        // 0x00D7F320: ADRP x8, #0x2a97000        | X8 = 44658688 (0x2A97000);              
        // 0x00D7F324: STP s0, s1, [x19, #0xa0]   | this.lastPos = val_1;  mem[1152921514498178228] = val_1.y;  //  dest_result_addr=1152921514498178224 |  dest_result_addr=1152921514498178228
        this.lastPos = val_1;
        mem[1152921514498178228] = val_1.y;
        // 0x00D7F328: LDR q0, [x8, #0x210]       | Q0 = ;                                  
        // 0x00D7F32C: ORR x9, xzr, #0x3f8000003f800000 | X9 = 4575657222473777152(0x3F8000003F800000);
        // 0x00D7F330: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F334: STUR x9, [x19, #0xd4]      | this.alternateTime = 1; this.alternateTimer = 1;  //  dest_result_addr=1152921514498178276 dest_result_addr=1152921514498178280
        this.alternateTime = 1f;
        this.alternateTimer = 1f;
        // 0x00D7F338: STR s2, [x19, #0xa8]       | mem[1152921514498178232] = val_1.z;      //  dest_result_addr=1152921514498178232
        mem[1152921514498178232] = val_1.z;
        // 0x00D7F33C: STRB w8, [x19, #0xc0]      | this.isStart = true;                     //  dest_result_addr=1152921514498178256
        this.isStart = true;
        // 0x00D7F340: STUR q0, [x19, #0xc4]      | this.distance_out = ; this.distance_in = ; this.rx_out = 35; this.rx_in = 35;  //  dest_result_addr=1152921514498178260 dest_result_addr=1152921514498178264 dest_result_addr=1152921514498178268 dest_result_addr=1152921514498178272
        this.distance_out = ;
        this.distance_in = ;
        this.rx_out = 35f;
        this.rx_in = 35f;
        // 0x00D7F344: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7F348: MOV x0, x19                | X0 = 1152921514498178064 (0x100000024D91BC10);//ML01
        // 0x00D7F34C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F350: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D7F354: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F358 (14152536), len: 12  VirtAddr: 0x00D7F358 RVA: 0x00D7F358 token: 100690262 methodIndex: 25916 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_IsOpeningMoveUpdate(bool value)
    {
        //
        // Disasemble & Code
        // 0x00D7F358: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00D7F35C: STRB w8, [x0, #0x18]       | this.<IsOpeningMoveUpdate>k__BackingField = (value & 1);  //  dest_result_addr=1152921514498290088
        this.<IsOpeningMoveUpdate>k__BackingField = val_1;
        // 0x00D7F360: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F364 (14152548), len: 8  VirtAddr: 0x00D7F364 RVA: 0x00D7F364 token: 100690263 methodIndex: 25917 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_IsOpeningMoveUpdate()
    {
        //
        // Disasemble & Code
        // 0x00D7F364: LDRB w0, [x0, #0x18]       | W0 = this.<IsOpeningMoveUpdate>k__BackingField; //P2 
        // 0x00D7F368: RET                        |  return (System.Boolean)this.<IsOpeningMoveUpdate>k__BackingField;
        return this.<IsOpeningMoveUpdate>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F36C (14152556), len: 8  VirtAddr: 0x00D7F36C RVA: 0x00D7F36C token: 100690264 methodIndex: 25918 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Transform get_target()
    {
        //
        // Disasemble & Code
        // 0x00D7F36C: LDR x0, [x0, #0x40]        | X0 = this._target; //P2                 
        // 0x00D7F370: RET                        |  return (UnityEngine.Transform)this._target;
        return this._target;
        //  |  // // {name=val_0, type=UnityEngine.Transform, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F374 (14152564), len: 8  VirtAddr: 0x00D7F374 RVA: 0x00D7F374 token: 100690265 methodIndex: 25919 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_target(UnityEngine.Transform value)
    {
        //
        // Disasemble & Code
        // 0x00D7F374: STR x1, [x0, #0x40]        | this._target = value;                    //  dest_result_addr=1152921514498638416
        this._target = value;
        // 0x00D7F378: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F37C (14152572), len: 140  VirtAddr: 0x00D7F37C RVA: 0x00D7F37C token: 100690266 methodIndex: 25920 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x286B90C
    private System.Collections.IEnumerator DoConfigDataCamera(float timer)
    {
        //
        // Disasemble & Code
        // 0x00D7F37C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514498742400] = ???;  stack[1152921514498742408] = ???;  //  dest_result_addr=1152921514498742400 |  dest_result_addr=1152921514498742408
        // 0x00D7F380: STP x20, x19, [sp, #0x10]  | stack[1152921514498742416] = ???;  stack[1152921514498742424] = ???;  //  dest_result_addr=1152921514498742416 |  dest_result_addr=1152921514498742424
        // 0x00D7F384: STP x29, x30, [sp, #0x20]  | stack[1152921514498742432] = ???;  stack[1152921514498742440] = ???;  //  dest_result_addr=1152921514498742432 |  dest_result_addr=1152921514498742440
        // 0x00D7F388: ADD x29, sp, #0x20         | X29 = (1152921514498742400 + 32) = 1152921514498742432 (0x100000024D9A58A0);
        // 0x00D7F38C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7F390: LDRB w8, [x20, #0x413]     | W8 = (bool)static_value_03734413;       
        // 0x00D7F394: MOV v8.16b, v0.16b         | V8 = timer;//m1                         
        // 0x00D7F398: MOV x19, x0                | X19 = 1152921514498754448 (0x100000024D9A8790);//ML01
        // 0x00D7F39C: TBNZ w8, #0, #0xd7f3b8     | if (static_value_03734413 == true) goto label_0;
        // 0x00D7F3A0: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x00D7F3A4: LDR x8, [x8, #0x868]       | X8 = 0x2B903B4;                         
        // 0x00D7F3A8: LDR w0, [x8]               | W0 = 0x17B1;                            
        // 0x00D7F3AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17B1, ????);     
        // 0x00D7F3B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F3B4: STRB w8, [x20, #0x413]     | static_value_03734413 = true;            //  dest_result_addr=57885715
        label_0:
        // 0x00D7F3B8: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D7F3BC: LDR x8, [x8, #0x788]       | X8 = 1152921504888156160;               
        // 0x00D7F3C0: LDR x0, [x8]               | X0 = typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0);
        object val_1 = null;
        // 0x00D7F3C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0), ????);
        // 0x00D7F3C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F3CC: MOV x20, x0                | X20 = 1152921504888156160 (0x1000000010C47000);//ML01
        // 0x00D7F3D0: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D7F3D4: CBZ x20, #0xd7f3e0         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00D7F3D8: STR s8, [x20, #0x10]       | typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0).__il2cppRuntimeField_10 = timer;  //  dest_result_addr=1152921504888156176
        typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0).__il2cppRuntimeField_10 = timer;
        // 0x00D7F3DC: B #0xd7f3f0                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00D7F3E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00D7F3E4: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
        // 0x00D7F3E8: STR s8, [x8]               | mem[16] = timer;                         //  dest_result_addr=16
        mem[16] = timer;
        // 0x00D7F3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00D7F3F0: STR x19, [x20, #0x18]      | typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504888156184
        typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0).__il2cppRuntimeField_18 = this;
        // 0x00D7F3F4: MOV x0, x20                | X0 = 1152921504888156160 (0x1000000010C47000);//ML01
        // 0x00D7F3F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7F3FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7F400: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00D7F404: RET                        |  return (System.Collections.IEnumerator)typeof(CameraSmoothFollow.<DoConfigDataCamera>c__Iterator0);
        return (System.Collections.IEnumerator)val_1;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F410 (14152720), len: 1312  VirtAddr: 0x00D7F410 RVA: 0x00D7F410 token: 100690267 methodIndex: 25921 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        //  | 
        var val_12;
        //  | 
        checkpointCfg val_13;
        //  | 
        CSCheckPointUnit val_14;
        // 0x00D7F410: STP d11, d10, [sp, #-0x60]! | stack[1152921514498972336] = ???;  stack[1152921514498972344] = ???;  //  dest_result_addr=1152921514498972336 |  dest_result_addr=1152921514498972344
        // 0x00D7F414: STP d9, d8, [sp, #0x10]    | stack[1152921514498972352] = ???;  stack[1152921514498972360] = ???;  //  dest_result_addr=1152921514498972352 |  dest_result_addr=1152921514498972360
        // 0x00D7F418: STP x24, x23, [sp, #0x20]  | stack[1152921514498972368] = ???;  stack[1152921514498972376] = ???;  //  dest_result_addr=1152921514498972368 |  dest_result_addr=1152921514498972376
        // 0x00D7F41C: STP x22, x21, [sp, #0x30]  | stack[1152921514498972384] = ???;  stack[1152921514498972392] = ???;  //  dest_result_addr=1152921514498972384 |  dest_result_addr=1152921514498972392
        // 0x00D7F420: STP x20, x19, [sp, #0x40]  | stack[1152921514498972400] = ???;  stack[1152921514498972408] = ???;  //  dest_result_addr=1152921514498972400 |  dest_result_addr=1152921514498972408
        // 0x00D7F424: STP x29, x30, [sp, #0x50]  | stack[1152921514498972416] = ???;  stack[1152921514498972424] = ???;  //  dest_result_addr=1152921514498972416 |  dest_result_addr=1152921514498972424
        // 0x00D7F428: ADD x29, sp, #0x50         | X29 = (1152921514498972336 + 80) = 1152921514498972416 (0x100000024D9DDB00);
        // 0x00D7F42C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7F430: LDRB w8, [x20, #0x414]     | W8 = (bool)static_value_03734414;       
        // 0x00D7F434: MOV x19, x0                | X19 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F438: TBNZ w8, #0, #0xd7f454     | if (static_value_03734414 == true) goto label_0;
        // 0x00D7F43C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x00D7F440: LDR x8, [x8, #0x7d0]       | X8 = 0x2B903A8;                         
        // 0x00D7F444: LDR w0, [x8]               | W0 = 0x17AE;                            
        // 0x00D7F448: BL #0x2782188              | X0 = sub_2782188( ?? 0x17AE, ????);     
        // 0x00D7F44C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F450: STRB w8, [x20, #0x414]     | static_value_03734414 = true;            //  dest_result_addr=57885716
        label_0:
        // 0x00D7F454: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F458: STRB w8, [x19, #0x18]      | this.<IsOpeningMoveUpdate>k__BackingField = true;  //  dest_result_addr=1152921514498984456
        this.<IsOpeningMoveUpdate>k__BackingField = true;
        // 0x00D7F45C: ADRP x20, #0x35f6000       | X20 = 56582144 (0x35F6000);             
        // 0x00D7F460: LDR x20, [x20, #0x7e8]     | X20 = 1152921504909295616;              
        // 0x00D7F464: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_12 = null;
        // 0x00D7F468: LDRB w8, [x0, #0x10a]      | W8 = SceneMgr.__il2cppRuntimeField_10A; 
        // 0x00D7F46C: TBZ w8, #0, #0xd7f480      | if (SceneMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7F470: LDR w8, [x0, #0xbc]        | W8 = SceneMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F474: CBNZ w8, #0xd7f480         | if (SceneMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7F478: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SceneMgr), ????);
        // 0x00D7F47C: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_12 = null;
        label_2:
        // 0x00D7F480: ADRP x9, #0x35cc000        | X9 = 56410112 (0x35CC000);              
        // 0x00D7F484: ADRP x23, #0x3658000       | X23 = 56983552 (0x3658000);             
        // 0x00D7F488: LDR x8, [x0, #0xa0]        | X8 = SceneMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7F48C: LDR x9, [x9, #0x2e0]       | X9 = 1152921514498842448;               
        // 0x00D7F490: LDR x23, [x23, #0x980]     | X23 = 1152921504898113536;              
        // 0x00D7F494: LDR x20, [x8]              | X20 = SceneMgr.SCENE_LOAD_OK;           
        // 0x00D7F498: LDR x22, [x9]              | X22 = public System.Void CameraSmoothFollow::AddItween(CEvent.ZEvent ev);
        // 0x00D7F49C: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00D7F4A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7F4A4: ADRP x24, #0x367a000       | X24 = 57122816 (0x367A000);             
        // 0x00D7F4A8: LDR x24, [x24, #0xc38]     | X24 = 1152921512949758048;              
        // 0x00D7F4AC: MOV x1, x19                | X1 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F4B0: MOV x2, x22                | X2 = 1152921514498842448 (0x100000024D9BDF50);//ML01
        // 0x00D7F4B4: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        val_13 = val_1;
        // 0x00D7F4B8: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7F4BC: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CameraSmoothFollow::AddItween(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraSmoothFollow::AddItween(CEvent.ZEvent ev));
        // 0x00D7F4C0: ADRP x22, #0x35cc000       | X22 = 56410112 (0x35CC000);             
        // 0x00D7F4C4: LDR x22, [x22, #0xde0]     | X22 = 1152921504898379776;              
        // 0x00D7F4C8: LDR x0, [x22]              | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D7F4CC: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D7F4D0: TBZ w8, #0, #0xd7f4e0      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D7F4D4: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F4D8: CBNZ w8, #0xd7f4e0         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D7F4DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00D7F4E0: MOV x1, x20                | X1 = SceneMgr.SCENE_LOAD_OK;//m1        
        // 0x00D7F4E4: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7F4E8: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  SceneMgr.SCENE_LOAD_OK);
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  SceneMgr.SCENE_LOAD_OK);
        // 0x00D7F4EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F4F0: MOV x0, x19                | X0 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F4F4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_2 = this.transform;
        // 0x00D7F4F8: STR x0, [x19, #0x78]       | this.mTransform = val_2;                 //  dest_result_addr=1152921514498984552
        this.mTransform = val_2;
        // 0x00D7F4FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F504: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_3 = UnityEngine.Application.isPlaying;
        // 0x00D7F508: TBZ w0, #0, #0xd7f6b8      | if (val_3 == false) goto label_5;       
        if(val_3 == false)
        {
            goto label_5;
        }
        // 0x00D7F50C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7F510: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7F514: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D7F518: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7F51C: TBZ w8, #0, #0xd7f52c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00D7F520: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F524: CBNZ w8, #0xd7f52c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00D7F528: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_7:
        // 0x00D7F52C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F534: BL #0x26a84c0              | X0 = ZMG.get_CSGameDataMgr();           
        CSGameDataMgr val_4 = ZMG.CSGameDataMgr;
        // 0x00D7F538: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00D7F53C: CBNZ x20, #0xd7f544        | if (val_4 != null) goto label_8;        
        if(val_4 != null)
        {
            goto label_8;
        }
        // 0x00D7F540: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00D7F544: LDR x20, [x20, #0x10]      | X20 = val_4.levelData; //P2             
        // 0x00D7F548: CBNZ x20, #0xd7f550        | if (val_4.levelData != null) goto label_9;
        if(val_4.levelData != null)
        {
            goto label_9;
        }
        // 0x00D7F54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00D7F550: LDR x8, [x20, #0x10]       | X8 = val_4.levelData.checkpointUnit; //P2 
        val_14 = val_4.levelData.checkpointUnit;
        // 0x00D7F554: STR x8, [x19, #0xb8]       | this.chapter = val_4.levelData.checkpointUnit;  //  dest_result_addr=1152921514498984616
        this.chapter = val_14;
        // 0x00D7F558: CBZ x8, #0xd7f7c4          | if (val_4.levelData.checkpointUnit == null) goto label_10;
        if(val_14 == null)
        {
            goto label_10;
        }
        // 0x00D7F55C: LDR x20, [x8, #0x10]       | X20 = val_4.levelData.checkpointUnit.cfg; //P2 
        // 0x00D7F560: CBNZ x20, #0xd7f570        | if (val_4.levelData.checkpointUnit.cfg != null) goto label_11;
        if(val_4.levelData.checkpointUnit.cfg != null)
        {
            goto label_11;
        }
        // 0x00D7F564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        // 0x00D7F568: LDR x8, [x19, #0xb8]       | X8 = this.chapter; //P2                 
        val_14 = this.chapter;
        // 0x00D7F56C: CBZ x8, #0xd7f92c          | if (this.chapter == null) goto label_12;
        if(val_14 == null)
        {
            goto label_12;
        }
        label_11:
        // 0x00D7F570: LDR w20, [x20, #0x16c]     | W20 = val_4.levelData.checkpointUnit.cfg.camera_if_move; //P2 
        // 0x00D7F574: LDR x21, [x8, #0x10]       | X21 = this.chapter.cfg; //P2            
        val_13 = this.chapter.cfg;
        // 0x00D7F578: CBNZ x21, #0xd7f580        | if (this.chapter.cfg != null) goto label_13;
        if(val_13 != null)
        {
            goto label_13;
        }
        // 0x00D7F57C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x00D7F580: LDR w8, [x21, #0x168]      | W8 = this.chapter.cfg.Camera_distance; //P2 
        // 0x00D7F584: CMP w20, #1                | STATE = COMPARE(val_4.levelData.checkpointUnit.cfg.camera_if_move, 0x1)
        // 0x00D7F588: B.NE #0xd7f760             | if (val_4.levelData.checkpointUnit.cfg.camera_if_move != 1) goto label_14;
        if(val_4.levelData.checkpointUnit.cfg.camera_if_move != 1)
        {
            goto label_14;
        }
        // 0x00D7F58C: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F590: STR w8, [x19, #0xc8]       | this.distance_in = this.chapter.cfg.Camera_distance;  //  dest_result_addr=1152921514498984632
        this.distance_in = this.chapter.cfg.Camera_distance;
        // 0x00D7F594: CBNZ x20, #0xd7f59c        | if (this.chapter != null) goto label_15;
        if(this.chapter != null)
        {
            goto label_15;
        }
        // 0x00D7F598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_15:
        // 0x00D7F59C: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F5A0: CBNZ x20, #0xd7f5a8        | if (this.chapter.cfg != null) goto label_16;
        if(this.chapter.cfg != null)
        {
            goto label_16;
        }
        // 0x00D7F5A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_16:
        // 0x00D7F5A8: LDR w8, [x20, #0x174]      | W8 = this.chapter.cfg.Camera_distance_outattack; //P2 
        // 0x00D7F5AC: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F5B0: STR w8, [x19, #0xc4]       | this.distance_out = this.chapter.cfg.Camera_distance_outattack;  //  dest_result_addr=1152921514498984628
        this.distance_out = this.chapter.cfg.Camera_distance_outattack;
        // 0x00D7F5B4: CBNZ x20, #0xd7f5bc        | if (this.chapter != null) goto label_17;
        if(this.chapter != null)
        {
            goto label_17;
        }
        // 0x00D7F5B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_17:
        // 0x00D7F5BC: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F5C0: CBNZ x20, #0xd7f5c8        | if (this.chapter.cfg != null) goto label_18;
        if(this.chapter.cfg != null)
        {
            goto label_18;
        }
        // 0x00D7F5C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_18:
        // 0x00D7F5C8: LDR w8, [x20, #0x188]      | W8 = this.chapter.cfg.Camera_rx; //P2   
        // 0x00D7F5CC: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F5D0: STR w8, [x19, #0xd0]       | this.rx_in = this.chapter.cfg.Camera_rx;  //  dest_result_addr=1152921514498984640
        this.rx_in = this.chapter.cfg.Camera_rx;
        // 0x00D7F5D4: CBNZ x20, #0xd7f5dc        | if (this.chapter != null) goto label_19;
        if(this.chapter != null)
        {
            goto label_19;
        }
        // 0x00D7F5D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_19:
        // 0x00D7F5DC: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F5E0: CBNZ x20, #0xd7f5e8        | if (this.chapter.cfg != null) goto label_20;
        if(this.chapter.cfg != null)
        {
            goto label_20;
        }
        // 0x00D7F5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_20:
        // 0x00D7F5E8: LDR s0, [x20, #0x18c]      | S0 = this.chapter.cfg.Camera_rx__outattack; //P2 
        // 0x00D7F5EC: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F5F0: SCVTF s0, s0               | S0 = (float)(this.chapter.cfg.Camera_rx__outattack);
        // 0x00D7F5F4: STR s0, [x19, #0xcc]       | this.rx_out = this.chapter.cfg.Camera_rx__outattack;  //  dest_result_addr=1152921514498984636
        this.rx_out = (float)this.chapter.cfg.Camera_rx__outattack;
        // 0x00D7F5F8: CBNZ x20, #0xd7f600        | if (this.chapter != null) goto label_21;
        if(this.chapter != null)
        {
            goto label_21;
        }
        // 0x00D7F5FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_21:
        // 0x00D7F600: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F604: CBNZ x20, #0xd7f60c        | if (this.chapter.cfg != null) goto label_22;
        if(this.chapter.cfg != null)
        {
            goto label_22;
        }
        // 0x00D7F608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_22:
        // 0x00D7F60C: LDR w10, [x19, #0xcc]      | W10 = this.rx_out; //P2                 
        // 0x00D7F610: LDR w8, [x20, #0x178]      | W8 = this.chapter.cfg.Camera_alternate_time; //P2 
        // 0x00D7F614: LDR w9, [x19, #0xc4]       | W9 = this.distance_out; //P2            
        // 0x00D7F618: ADRP x11, #0x3670000       | X11 = 57081856 (0x3670000);             
        // 0x00D7F61C: LDR x11, [x11, #0x4c8]     | X11 = 1152921514498904912;              
        // 0x00D7F620: STR w10, [x19, #0x68]      | this.rx = this.rx_out;                   //  dest_result_addr=1152921514498984536
        this.rx = this.rx_out;
        // 0x00D7F624: STR w8, [x19, #0xd4]       | this.alternateTime = this.chapter.cfg.Camera_alternate_time;  //  dest_result_addr=1152921514498984644
        this.alternateTime = this.chapter.cfg.Camera_alternate_time;
        // 0x00D7F628: STR w9, [x19, #0x60]       | this.distance = this.distance_out;       //  dest_result_addr=1152921514498984528
        this.distance = this.distance_out;
        // 0x00D7F62C: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_5 = null;
        // 0x00D7F630: LDR x21, [x11]             | X21 = public System.Void CameraSmoothFollow::BattleStart(CEvent.ZEvent e);
        // 0x00D7F634: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7F638: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7F63C: MOV x1, x19                | X1 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F640: MOV x2, x21                | X2 = 1152921514498904912 (0x100000024D9CD350);//ML01
        // 0x00D7F644: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7F648: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CameraSmoothFollow::BattleStart(CEvent.ZEvent e));
        val_5 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraSmoothFollow::BattleStart(CEvent.ZEvent e));
        // 0x00D7F64C: LDR x0, [x22]              | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D7F650: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D7F654: TBZ w8, #0, #0xd7f664      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x00D7F658: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F65C: CBNZ w8, #0xd7f664         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x00D7F660: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_24:
        // 0x00D7F664: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00D7F668: LDR x8, [x8, #0x9c0]       | X8 = (string**)(1152921510361988960)("BATTLE_START");
        // 0x00D7F66C: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7F670: LDR x1, [x8]               | X1 = "BATTLE_START";                    
        // 0x00D7F674: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "BATTLE_START");
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "BATTLE_START");
        // 0x00D7F678: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00D7F67C: LDR x8, [x8, #0x6e8]       | X8 = 1152921514498905936;               
        // 0x00D7F680: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_6 = null;
        // 0x00D7F684: LDR x20, [x8]              | X20 = public System.Void CameraSmoothFollow::BattelEnd(CEvent.ZEvent e);
        // 0x00D7F688: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7F68C: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7F690: MOV x1, x19                | X1 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F694: MOV x2, x20                | X2 = 1152921514498905936 (0x100000024D9CD750);//ML01
        // 0x00D7F698: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        val_13 = val_6;
        // 0x00D7F69C: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CameraSmoothFollow::BattelEnd(CEvent.ZEvent e));
        val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraSmoothFollow::BattelEnd(CEvent.ZEvent e));
        // 0x00D7F6A0: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D7F6A4: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921510361990080)("BATTLE_ENDED");
        // 0x00D7F6A8: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7F6AC: LDR x1, [x8]               | X1 = "BATTLE_ENDED";                    
        // 0x00D7F6B0: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraSmoothFollow::BattelEnd(CEvent.ZEvent e)), fun:  "BATTLE_ENDED");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_6, fun:  "BATTLE_ENDED");
        // 0x00D7F6B4: B #0xd7f784                |  goto label_25;                         
        goto label_25;
        label_5:
        // 0x00D7F6B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F6BC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7F6C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F6C4: BL #0x1a625bc              | X0 = UnityEngine.GameObject.CreatePrimitive(type:  0);
        UnityEngine.GameObject val_7 = UnityEngine.GameObject.CreatePrimitive(type:  0);
        // 0x00D7F6C8: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00D7F6CC: CBZ x20, #0xd7f6fc         | if (val_7 == null) goto label_26;       
        if(val_7 == null)
        {
            goto label_26;
        }
        // 0x00D7F6D0: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00D7F6D4: LDR x8, [x8, #0x860]       | X8 = (string**)(1152921514498911056)("Viewpoint");
        // 0x00D7F6D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F6DC: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00D7F6E0: LDR x1, [x8]               | X1 = "Viewpoint";                       
        // 0x00D7F6E4: BL #0x1b78c7c              | val_7.set_name(value:  "Viewpoint");    
        val_7.name = "Viewpoint";
        // 0x00D7F6E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F6EC: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x00D7F6F0: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00D7F6F4: BL #0x1b77b04              | val_7.set_hideFlags(value:  52);        
        val_7.hideFlags = 52;
        // 0x00D7F6F8: B #0xd7f730                |  goto label_27;                         
        goto label_27;
        label_26:
        // 0x00D7F6FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        // 0x00D7F700: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00D7F704: LDR x8, [x8, #0x860]       | X8 = (string**)(1152921514498911056)("Viewpoint");
        // 0x00D7F708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F70C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F710: LDR x1, [x8]               | X1 = "Viewpoint";                       
        // 0x00D7F714: BL #0x1b78c7c              | 0.set_name(value:  "Viewpoint");        
        0.name = "Viewpoint";
        // 0x00D7F718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D7F71C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F720: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x00D7F724: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F728: BL #0x1b77b04              | 0.set_hideFlags(value:  52);            
        0.hideFlags = 52;
        // 0x00D7F72C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_27:
        // 0x00D7F730: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F734: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00D7F738: BL #0x1a62c1c              | X0 = val_7.get_transform();             
        UnityEngine.Transform val_8 = val_7.transform;
        // 0x00D7F73C: MOV x1, x0                 | X1 = val_8;//m1                         
        // 0x00D7F740: MOV x0, x19                | X0 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F744: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7F748: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7F74C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7F750: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D7F754: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00D7F758: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00D7F75C: B #0xd7f930                | this.ChangeTarget(_target:  val_8); return;
        this.ChangeTarget(_target:  val_8);
        return;
        label_14:
        // 0x00D7F760: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F764: STR w8, [x19, #0x60]       | this.distance = this.chapter.cfg.Camera_distance;  //  dest_result_addr=1152921514498984528
        this.distance = this.chapter.cfg.Camera_distance;
        // 0x00D7F768: CBNZ x20, #0xd7f770        | if (this.chapter != null) goto label_28;
        if(this.chapter != null)
        {
            goto label_28;
        }
        // 0x00D7F76C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_28:
        // 0x00D7F770: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F774: CBNZ x20, #0xd7f77c        | if (this.chapter.cfg != null) goto label_29;
        if(this.chapter.cfg != null)
        {
            goto label_29;
        }
        // 0x00D7F778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_29:
        // 0x00D7F77C: LDR w8, [x20, #0x188]      | W8 = this.chapter.cfg.Camera_rx; //P2   
        // 0x00D7F780: STR w8, [x19, #0x68]       | this.rx = this.chapter.cfg.Camera_rx;    //  dest_result_addr=1152921514498984536
        this.rx = this.chapter.cfg.Camera_rx;
        label_25:
        // 0x00D7F784: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F788: CBNZ x20, #0xd7f790        | if (this.chapter != null) goto label_30;
        if(this.chapter != null)
        {
            goto label_30;
        }
        // 0x00D7F78C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_30:
        // 0x00D7F790: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F794: CBNZ x20, #0xd7f79c        | if (this.chapter.cfg != null) goto label_31;
        if(this.chapter.cfg != null)
        {
            goto label_31;
        }
        // 0x00D7F798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_31:
        // 0x00D7F79C: LDR w8, [x20, #0x190]      | W8 = this.chapter.cfg.Camera_ry; //P2   
        // 0x00D7F7A0: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F7A4: STR w8, [x19, #0x6c]       | this.ry = this.chapter.cfg.Camera_ry;    //  dest_result_addr=1152921514498984540
        this.ry = this.chapter.cfg.Camera_ry;
        // 0x00D7F7A8: CBNZ x20, #0xd7f7b0        | if (this.chapter != null) goto label_32;
        if(this.chapter != null)
        {
            goto label_32;
        }
        // 0x00D7F7AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_32:
        // 0x00D7F7B0: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F7B4: CBNZ x20, #0xd7f7bc        | if (this.chapter.cfg != null) goto label_33;
        if(this.chapter.cfg != null)
        {
            goto label_33;
        }
        // 0x00D7F7B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_33:
        // 0x00D7F7BC: LDR w8, [x20, #0x194]      | W8 = this.chapter.cfg.Camera_posDamping; //P2 
        // 0x00D7F7C0: STR w8, [x19, #0x74]       | this.posDamping = this.chapter.cfg.Camera_posDamping;  //  dest_result_addr=1152921514498984548
        this.posDamping = this.chapter.cfg.Camera_posDamping;
        label_10:
        // 0x00D7F7C4: LDR w8, [x19, #0x60]       | W8 = this.distance; //P2                
        // 0x00D7F7C8: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00D7F7CC: STRB w9, [x19, #0x5d]      | this.isDamping = true;                   //  dest_result_addr=1152921514498984525
        this.isDamping = true;
        // 0x00D7F7D0: STR w8, [x19, #0x64]       | this.lastDistance = this.distance;       //  dest_result_addr=1152921514498984532
        this.lastDistance = this.distance;
        // 0x00D7F7D4: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D7F7D8: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00D7F7DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D7F7E0: LDP s10, s9, [x19, #0x68]  | S10 = this.rx; //P2  S9 = this.ry; //P2  //  | 
        // 0x00D7F7E4: LDR s8, [x19, #0x70]       | S8 = this.rz; //P2                      
        // 0x00D7F7E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D7F7EC: TBZ w8, #0, #0xd7f7fc      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_35;
        // 0x00D7F7F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F7F4: CBNZ w8, #0xd7f7fc         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
        // 0x00D7F7F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_35:
        // 0x00D7F7FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F800: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F804: MOV v0.16b, v10.16b        | V0 = this.rx;//m1                       
        // 0x00D7F808: MOV v1.16b, v9.16b         | V1 = this.ry;//m1                       
        // 0x00D7F80C: MOV v2.16b, v8.16b         | V2 = this.rz;//m1                       
        // 0x00D7F810: BL #0x1b7f530              | X0 = UnityEngine.Quaternion.Euler(x:  this.rx, y:  this.ry, z:  this.rz);
        UnityEngine.Quaternion val_9 = UnityEngine.Quaternion.Euler(x:  this.rx, y:  this.ry, z:  this.rz);
        // 0x00D7F814: STP s0, s1, [x19, #0x80]   | this.currentRotation = val_9;  mem[1152921514498984564] = val_9.y;  //  dest_result_addr=1152921514498984560 |  dest_result_addr=1152921514498984564
        this.currentRotation = val_9;
        mem[1152921514498984564] = val_9.y;
        // 0x00D7F818: STP s2, s3, [x19, #0x88]   | mem[1152921514498984568] = val_9.z;  mem[1152921514498984572] = val_9.w;  //  dest_result_addr=1152921514498984568 |  dest_result_addr=1152921514498984572
        mem[1152921514498984568] = val_9.z;
        mem[1152921514498984572] = val_9.w;
        // 0x00D7F81C: STP s0, s1, [x19, #0x90]   | this.lastRotation = val_9;  mem[1152921514498984580] = val_9.y;  //  dest_result_addr=1152921514498984576 |  dest_result_addr=1152921514498984580
        this.lastRotation = val_9;
        mem[1152921514498984580] = val_9.y;
        // 0x00D7F820: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F824: STP s2, s3, [x19, #0x98]   | mem[1152921514498984584] = val_9.z;  mem[1152921514498984588] = val_9.w;  //  dest_result_addr=1152921514498984584 |  dest_result_addr=1152921514498984588
        mem[1152921514498984584] = val_9.z;
        mem[1152921514498984588] = val_9.w;
        // 0x00D7F828: CBNZ x20, #0xd7f830        | if (this.chapter != null) goto label_36;
        if(this.chapter != null)
        {
            goto label_36;
        }
        // 0x00D7F82C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_36:
        // 0x00D7F830: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F834: CBNZ x20, #0xd7f83c        | if (this.chapter.cfg != null) goto label_37;
        if(this.chapter.cfg != null)
        {
            goto label_37;
        }
        // 0x00D7F838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_37:
        // 0x00D7F83C: LDRB w8, [x20, #0x1a0]     | W8 = this.chapter.cfg.Camera_disMove; //P2 
        // 0x00D7F840: CBZ w8, #0xd7f854          | if (this.chapter.cfg.Camera_disMove == false) goto label_38;
        if(this.chapter.cfg.Camera_disMove == false)
        {
            goto label_38;
        }
        // 0x00D7F844: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7F848: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F84C: MOV x0, x19                | X0 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F850: BL #0x20cb458              | this.set_enabled(value:  false);        
        this.enabled = false;
        label_38:
        // 0x00D7F854: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7F858: CBNZ x20, #0xd7f860        | if (this.chapter != null) goto label_39;
        if(this.chapter != null)
        {
            goto label_39;
        }
        // 0x00D7F85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_39:
        // 0x00D7F860: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7F864: CBNZ x20, #0xd7f86c        | if (this.chapter.cfg != null) goto label_40;
        if(this.chapter.cfg != null)
        {
            goto label_40;
        }
        // 0x00D7F868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_40:
        // 0x00D7F86C: LDR w8, [x20, #0x17c]      | W8 = this.chapter.cfg.Camera_time; //P2 
        // 0x00D7F870: CMP w8, #0                 | STATE = COMPARE(this.chapter.cfg.Camera_time, 0x0)
        // 0x00D7F874: B.LE #0xd7f898             | if (this.chapter.cfg.Camera_time <= 0) goto label_41;
        if(this.chapter.cfg.Camera_time <= 0)
        {
            goto label_41;
        }
        // 0x00D7F878: STRB wzr, [x19, #0xc0]     | this.isStart = false;                    //  dest_result_addr=1152921514498984624
        this.isStart = false;
        // 0x00D7F87C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7F880: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7F884: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7F888: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D7F88C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00D7F890: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00D7F894: RET                        |  return;                                
        return;
        label_41:
        // 0x00D7F898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F89C: MOV x0, x19                | X0 = 1152921514498984432 (0x100000024D9E09F0);//ML01
        // 0x00D7F8A0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_10 = this.transform;
        // 0x00D7F8A4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7F8A8: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00D7F8AC: MOV x19, x0                | X19 = val_10;//m1                       
        // 0x00D7F8B0: LDR x8, [x8]               | X8 = typeof(Util);                      
        // 0x00D7F8B4: LDRB w9, [x8, #0x10a]      | W9 = Util.__il2cppRuntimeField_10A;     
        // 0x00D7F8B8: TBZ w9, #0, #0xd7f8cc      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00D7F8BC: LDR w9, [x8, #0xbc]        | W9 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F8C0: CBNZ w9, #0xd7f8cc         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00D7F8C4: MOV x0, x8                 | X0 = 1152921504911745024 (0x10000000122C6000);//ML01
        // 0x00D7F8C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_43:
        // 0x00D7F8CC: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00D7F8D0: LDR x8, [x8, #0x418]       | X8 = (string**)(1152921514498960304)("48.41695,18.58528,44.16574");
        // 0x00D7F8D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F8D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F8DC: MOVZ w2, #0x2c             | W2 = 44 (0x2C);//ML01                   
        // 0x00D7F8E0: LDR x1, [x8]               | X1 = "48.41695,18.58528,44.16574";      
        // 0x00D7F8E4: BL #0xe17800               | X0 = Util.FormatVector3ByStr(str:  0, c:  'ꮰ');
        UnityEngine.Vector3 val_11 = Util.FormatVector3ByStr(str:  0, c:  'ꮰ');
        // 0x00D7F8E8: MOV v8.16b, v0.16b         | V8 = val_11.x;//m1                      
        // 0x00D7F8EC: MOV v9.16b, v1.16b         | V9 = val_11.y;//m1                      
        // 0x00D7F8F0: MOV v10.16b, v2.16b        | V10 = val_11.z;//m1                     
        // 0x00D7F8F4: CBNZ x19, #0xd7f8fc        | if (val_10 != null) goto label_44;      
        if(val_10 != null)
        {
            goto label_44;
        }
        // 0x00D7F8F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_44:
        // 0x00D7F8FC: MOV x0, x19                | X0 = val_10;//m1                        
        // 0x00D7F900: MOV v0.16b, v8.16b         | V0 = val_11.x;//m1                      
        // 0x00D7F904: MOV v1.16b, v9.16b         | V1 = val_11.y;//m1                      
        // 0x00D7F908: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7F90C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7F910: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7F914: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D7F918: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00D7F91C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F920: MOV v2.16b, v10.16b        | V2 = val_11.z;//m1                      
        // 0x00D7F924: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00D7F928: B #0x26935b8               | val_10.set_position(value:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}); return;
        val_10.position = new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z};
        return;
        label_12:
        // 0x00D7F92C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7FB20 (14154528), len: 40  VirtAddr: 0x00D7FB20 RVA: 0x00D7FB20 token: 100690268 methodIndex: 25922 delegateWrapperIndex: 0 methodInvoker: 0
    public void BattleStart(CEvent.ZEvent e)
    {
        //
        // Disasemble & Code
        // 0x00D7FB20: LDRB w8, [x0, #0x5d]       | W8 = this.isDamping; //P2               
        // 0x00D7FB24: CBZ w8, #0xd7fb44          | if (this.isDamping == false) goto label_0;
        if(this.isDamping == false)
        {
            goto label_0;
        }
        // 0x00D7FB28: LDP w9, w10, [x0, #0xd0]   | W9 = this.rx_in; //P2  W10 = this.alternateTime; //P2  //  | 
        // 0x00D7FB2C: LDR w11, [x0, #0xc8]       | W11 = this.distance_in; //P2            
        // 0x00D7FB30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7FB34: STRB w8, [x0, #0xdc]       | this.ifMoveOnStatrBattle = true;         //  dest_result_addr=1152921514499215436
        this.ifMoveOnStatrBattle = true;
        // 0x00D7FB38: STR w9, [x0, #0x68]        | this.rx = this.rx_in;                    //  dest_result_addr=1152921514499215320
        this.rx = this.rx_in;
        // 0x00D7FB3C: STR w10, [x0, #0xd8]       | this.alternateTimer = this.alternateTime;  //  dest_result_addr=1152921514499215432
        this.alternateTimer = this.alternateTime;
        // 0x00D7FB40: STR w11, [x0, #0x60]       | this.distance = this.distance_in;        //  dest_result_addr=1152921514499215312
        this.distance = this.distance_in;
        label_0:
        // 0x00D7FB44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7FB48 (14154568), len: 360  VirtAddr: 0x00D7FB48 RVA: 0x00D7FB48 token: 100690269 methodIndex: 25923 delegateWrapperIndex: 0 methodInvoker: 0
    public void BattelEnd(CEvent.ZEvent e)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_2;
        //  | 
        object val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        // 0x00D7FB48: STP x24, x23, [sp, #-0x40]! | stack[1152921514499335632] = ???;  stack[1152921514499335640] = ???;  //  dest_result_addr=1152921514499335632 |  dest_result_addr=1152921514499335640
        // 0x00D7FB4C: STP x22, x21, [sp, #0x10]  | stack[1152921514499335648] = ???;  stack[1152921514499335656] = ???;  //  dest_result_addr=1152921514499335648 |  dest_result_addr=1152921514499335656
        // 0x00D7FB50: STP x20, x19, [sp, #0x20]  | stack[1152921514499335664] = ???;  stack[1152921514499335672] = ???;  //  dest_result_addr=1152921514499335664 |  dest_result_addr=1152921514499335672
        // 0x00D7FB54: STP x29, x30, [sp, #0x30]  | stack[1152921514499335680] = ???;  stack[1152921514499335688] = ???;  //  dest_result_addr=1152921514499335680 |  dest_result_addr=1152921514499335688
        // 0x00D7FB58: ADD x29, sp, #0x30         | X29 = (1152921514499335632 + 48) = 1152921514499335680 (0x100000024DA36600);
        // 0x00D7FB5C: SUB sp, sp, #0x10          | SP = (1152921514499335632 - 16) = 1152921514499335616 (0x100000024DA365C0);
        // 0x00D7FB60: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7FB64: LDRB w8, [x21, #0x415]     | W8 = (bool)static_value_03734415;       
        // 0x00D7FB68: MOV x20, x1                | X20 = e;//m1                            
        val_4 = e;
        // 0x00D7FB6C: MOV x19, x0                | X19 = 1152921514499347696 (0x100000024DA394F0);//ML01
        // 0x00D7FB70: TBNZ w8, #0, #0xd7fb8c     | if (static_value_03734415 == true) goto label_0;
        // 0x00D7FB74: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D7FB78: LDR x8, [x8, #0x6e8]       | X8 = 0x2B903AC;                         
        // 0x00D7FB7C: LDR w0, [x8]               | W0 = 0x17AF;                            
        // 0x00D7FB80: BL #0x2782188              | X0 = sub_2782188( ?? 0x17AF, ????);     
        // 0x00D7FB84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7FB88: STRB w8, [x21, #0x415]     | static_value_03734415 = true;            //  dest_result_addr=57885717
        label_0:
        // 0x00D7FB8C: LDRB w8, [x19, #0x5d]      | W8 = this.isDamping; //P2               
        // 0x00D7FB90: CBZ w8, #0xd7fc30          | if (this.isDamping == false) goto label_8;
        if(this.isDamping == false)
        {
            goto label_8;
        }
        // 0x00D7FB94: CBNZ x20, #0xd7fb9c        | if (e != null) goto label_2;            
        if(val_4 != null)
        {
            goto label_2;
        }
        // 0x00D7FB98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17AF, ????);     
        label_2:
        // 0x00D7FB9C: LDR x0, [x20, #0x28]       | X0 = e.arg; //P2                        
        // 0x00D7FBA0: CBZ x0, #0xd7fc30          | if (e.arg == null) goto label_8;        
        if(e.arg == null)
        {
            goto label_8;
        }
        // 0x00D7FBA4: LDR x8, [x20, #0x30]       | X8 = e.arg1; //P2                       
        // 0x00D7FBA8: CBZ x8, #0xd7fc30          | if (e.arg1 == null) goto label_8;       
        if(e.arg1 == null)
        {
            goto label_8;
        }
        // 0x00D7FBAC: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
        // 0x00D7FBB0: LDR x23, [x23, #0x140]     | X23 = 1152921504607113216;              
        // 0x00D7FBB4: LDR x8, [x0]               | X8 = typeof(System.Object);             
        // 0x00D7FBB8: LDR x1, [x23]              | X1 = typeof(System.Int32);              
        // 0x00D7FBBC: LDR x9, [x8, #0x30]        | X9 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7FBC0: LDR x8, [x1, #0x30]        | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7FBC4: CMP x9, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7FBC8: B.NE #0xd7fc48             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_5;
        // 0x00D7FBCC: BL #0x27bc4e8              | e.arg.System.IDisposable.Dispose();     
        e.arg.System.IDisposable.Dispose();
        // 0x00D7FBD0: LDR w22, [x0]              | W22 = typeof(System.Object);            
        // 0x00D7FBD4: LDR x21, [x20, #0x30]      | X21 = e.arg1; //P2                      
        val_3 = e.arg1;
        // 0x00D7FBD8: LDR x20, [x23]             | X20 = typeof(System.Int32);             
        val_4 = null;
        // 0x00D7FBDC: CBNZ x21, #0xd7fbe4        | if (e.arg1 != null) goto label_6;       
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00D7FBE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? e.arg, ????);      
        label_6:
        // 0x00D7FBE4: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7FBE8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7FBEC: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7FBF0: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7FBF4: B.NE #0xd7fc6c             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7FBF8: MOV x0, x21                | X0 = e.arg1;//m1                        
        // 0x00D7FBFC: BL #0x27bc4e8              | e.arg1.System.IDisposable.Dispose();    
        val_3.System.IDisposable.Dispose();
        // 0x00D7FC00: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7FC04: SUB w8, w8, #1             | W8 = (1152921504606900224 - 1) = 1152921504606900223 (0x100000000000CFFF);
        // 0x00D7FC08: CMP w22, w8                | STATE = COMPARE(typeof(System.Object), 0x100000000000CFFF)
        // 0x00D7FC0C: B.EQ #0xd7fc30             | if (typeof(System.Object) == 1152921504606900223) goto label_8;
        if(null == 1152921504606900223)
        {
            goto label_8;
        }
        // 0x00D7FC10: LDR w9, [x19, #0xd4]       | W9 = this.alternateTime; //P2           
        // 0x00D7FC14: LDR w10, [x19, #0xcc]      | W10 = this.rx_out; //P2                 
        // 0x00D7FC18: LDR w11, [x19, #0xc4]      | W11 = this.distance_out; //P2           
        // 0x00D7FC1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7FC20: STRB w8, [x19, #0xdc]      | this.ifMoveOnStatrBattle = true;         //  dest_result_addr=1152921514499347916
        this.ifMoveOnStatrBattle = true;
        // 0x00D7FC24: STR w9, [x19, #0xd8]       | this.alternateTimer = this.alternateTime;  //  dest_result_addr=1152921514499347912
        this.alternateTimer = this.alternateTime;
        // 0x00D7FC28: STR w10, [x19, #0x68]      | this.rx = this.rx_out;                   //  dest_result_addr=1152921514499347800
        this.rx = this.rx_out;
        // 0x00D7FC2C: STR w11, [x19, #0x60]      | this.distance = this.distance_out;       //  dest_result_addr=1152921514499347792
        this.distance = this.distance_out;
        label_8:
        // 0x00D7FC30: SUB sp, x29, #0x30         | SP = (1152921514499335680 - 48) = 1152921514499335632 (0x100000024DA365D0);
        // 0x00D7FC34: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7FC38: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7FC3C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7FC40: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D7FC44: RET                        |  return;                                
        return;
        label_5:
        // 0x00D7FC48: ADD x8, sp, #8             | X8 = (1152921514499335616 + 8) = 1152921514499335624 (0x100000024DA365C8);
        // 0x00D7FC4C: MOV x0, x9                 | X0 = System.Object.__il2cppRuntimeField_element_class;//m1
        // 0x00D7FC50: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7FC54: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514499323696]
        // 0x00D7FC58: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
        // 0x00D7FC5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FC60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00D7FC64: ADD x0, sp, #8             | X0 = (1152921514499335616 + 8) = 1152921514499335624 (0x100000024DA365C8);
        // 0x00D7FC68: BL #0x299a140              | 
        label_7:
        // 0x00D7FC6C: MOV x8, sp                 | X8 = 1152921514499335616 (0x100000024DA365C0);//ML01
        // 0x00D7FC70: MOV x1, x20                | X1 = e;//m1                             
        // 0x00D7FC74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000024DA365C8, ????);
        // 0x00D7FC78: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921514499323696]
        // 0x00D7FC7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
        // 0x00D7FC80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FC84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        // 0x00D7FC88: MOV x0, sp                 | X0 = 1152921514499335616 (0x100000024DA365C0);//ML01
        // 0x00D7FC8C: BL #0x299a140              | 
        // 0x00D7FC90: MOV x19, x0                | X19 = 1152921514499335616 (0x100000024DA365C0);//ML01
        val_5 = ;
        // 0x00D7FC94: ADD x0, sp, #8             | X0 = (1152921514499335616 + 8) = 1152921514499335624 (0x100000024DA365C8);
        // 0x00D7FC98: B #0xd7fca4                |  goto label_9;                          
        goto label_9;
        // 0x00D7FC9C: MOV x19, x0                | X19 = 1152921514499335624 (0x100000024DA365C8);//ML01
        val_5;
        // 0x00D7FCA0: MOV x0, sp                 | X0 = 1152921514499335616 (0x100000024DA365C0);//ML01
        val_6;
        label_9:
        // 0x00D7FCA4: BL #0x299a140              | 
        // 0x00D7FCA8: MOV x0, x19                | X0 = 1152921514499335624 (0x100000024DA365C8);//ML01
        // 0x00D7FCAC: BL #0x980800               | X0 = sub_980800( ?? 0x100000024DA365C8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7FCB0 (14154928), len: 1588  VirtAddr: 0x00D7FCB0 RVA: 0x00D7FCB0 token: 100690270 methodIndex: 25924 delegateWrapperIndex: 0 methodInvoker: 0
    public void AddItween(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        object val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        // 0x00D7FCB0: STP d9, d8, [sp, #-0x60]!  | stack[1152921514499575600] = ???;  stack[1152921514499575608] = ???;  //  dest_result_addr=1152921514499575600 |  dest_result_addr=1152921514499575608
        // 0x00D7FCB4: STP x26, x25, [sp, #0x10]  | stack[1152921514499575616] = ???;  stack[1152921514499575624] = ???;  //  dest_result_addr=1152921514499575616 |  dest_result_addr=1152921514499575624
        // 0x00D7FCB8: STP x24, x23, [sp, #0x20]  | stack[1152921514499575632] = ???;  stack[1152921514499575640] = ???;  //  dest_result_addr=1152921514499575632 |  dest_result_addr=1152921514499575640
        // 0x00D7FCBC: STP x22, x21, [sp, #0x30]  | stack[1152921514499575648] = ???;  stack[1152921514499575656] = ???;  //  dest_result_addr=1152921514499575648 |  dest_result_addr=1152921514499575656
        // 0x00D7FCC0: STP x20, x19, [sp, #0x40]  | stack[1152921514499575664] = ???;  stack[1152921514499575672] = ???;  //  dest_result_addr=1152921514499575664 |  dest_result_addr=1152921514499575672
        // 0x00D7FCC4: STP x29, x30, [sp, #0x50]  | stack[1152921514499575680] = ???;  stack[1152921514499575688] = ???;  //  dest_result_addr=1152921514499575680 |  dest_result_addr=1152921514499575688
        // 0x00D7FCC8: ADD x29, sp, #0x50         | X29 = (1152921514499575600 + 80) = 1152921514499575680 (0x100000024DA70F80);
        // 0x00D7FCCC: SUB sp, sp, #0x50          | SP = (1152921514499575600 - 80) = 1152921514499575520 (0x100000024DA70EE0);
        // 0x00D7FCD0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7FCD4: LDRB w8, [x20, #0x416]     | W8 = (bool)static_value_03734416;       
        // 0x00D7FCD8: MOV x19, x0                | X19 = 1152921514499587696 (0x100000024DA73E70);//ML01
        val_12 = this;
        // 0x00D7FCDC: TBNZ w8, #0, #0xd7fcf8     | if (static_value_03734416 == true) goto label_0;
        // 0x00D7FCE0: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00D7FCE4: LDR x8, [x8, #0x588]       | X8 = 0x2B903A4;                         
        // 0x00D7FCE8: LDR w0, [x8]               | W0 = 0x17AD;                            
        // 0x00D7FCEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17AD, ????);     
        // 0x00D7FCF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7FCF4: STRB w8, [x20, #0x416]     | static_value_03734416 = true;            //  dest_result_addr=57885718
        label_0:
        // 0x00D7FCF8: ADRP x20, #0x35f6000       | X20 = 56582144 (0x35F6000);             
        // 0x00D7FCFC: LDR x20, [x20, #0x7e8]     | X20 = 1152921504909295616;              
        // 0x00D7FD00: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_13 = null;
        // 0x00D7FD04: STP xzr, xzr, [sp, #0x40]  | stack[1152921514499575584] = 0x0;  stack[1152921514499575592] = 0x0;  //  dest_result_addr=1152921514499575584 |  dest_result_addr=1152921514499575592
        // 0x00D7FD08: LDRB w8, [x0, #0x10a]      | W8 = SceneMgr.__il2cppRuntimeField_10A; 
        // 0x00D7FD0C: TBZ w8, #0, #0xd7fd20      | if (SceneMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7FD10: LDR w8, [x0, #0xbc]        | W8 = SceneMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00D7FD14: CBNZ w8, #0xd7fd20         | if (SceneMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7FD18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SceneMgr), ????);
        // 0x00D7FD1C: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_13 = null;
        label_2:
        // 0x00D7FD20: ADRP x9, #0x35cc000        | X9 = 56410112 (0x35CC000);              
        // 0x00D7FD24: ADRP x10, #0x3658000       | X10 = 56983552 (0x3658000);             
        // 0x00D7FD28: LDR x8, [x0, #0xa0]        | X8 = SceneMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7FD2C: LDR x9, [x9, #0x2e0]       | X9 = 1152921514498842448;               
        // 0x00D7FD30: LDR x10, [x10, #0x980]     | X10 = 1152921504898113536;              
        // 0x00D7FD34: LDR x20, [x8]              | X20 = SceneMgr.SCENE_LOAD_OK;           
        // 0x00D7FD38: LDR x22, [x9]              | X22 = public System.Void CameraSmoothFollow::AddItween(CEvent.ZEvent ev);
        // 0x00D7FD3C: LDR x0, [x10]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00D7FD40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7FD44: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D7FD48: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00D7FD4C: MOV x1, x19                | X1 = 1152921514499587696 (0x100000024DA73E70);//ML01
        // 0x00D7FD50: MOV x2, x22                | X2 = 1152921514498842448 (0x100000024D9BDF50);//ML01
        // 0x00D7FD54: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        val_14 = val_1;
        // 0x00D7FD58: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7FD5C: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CameraSmoothFollow::AddItween(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraSmoothFollow::AddItween(CEvent.ZEvent ev));
        // 0x00D7FD60: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D7FD64: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D7FD68: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D7FD6C: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D7FD70: TBZ w8, #0, #0xd7fd80      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D7FD74: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D7FD78: CBNZ w8, #0xd7fd80         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D7FD7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00D7FD80: MOV x1, x20                | X1 = SceneMgr.SCENE_LOAD_OK;//m1        
        // 0x00D7FD84: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7FD88: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  null, func:  SceneMgr.SCENE_LOAD_OK);
        CEvent.ZEventCenter.RemoveEventListener(eventType:  null, func:  SceneMgr.SCENE_LOAD_OK);
        // 0x00D7FD8C: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7FD90: CBNZ x20, #0xd7fd98        | if (this.chapter != null) goto label_5; 
        if(this.chapter != null)
        {
            goto label_5;
        }
        // 0x00D7FD94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CEvent.ZEventCenter), ????);
        label_5:
        // 0x00D7FD98: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7FD9C: CBNZ x20, #0xd7fda4        | if (this.chapter.cfg != null) goto label_6;
        if(this.chapter.cfg != null)
        {
            goto label_6;
        }
        // 0x00D7FDA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CEvent.ZEventCenter), ????);
        label_6:
        // 0x00D7FDA4: LDRB w8, [x20, #0x170]     | W8 = this.chapter.cfg.isCameraAnimation; //P2 
        // 0x00D7FDA8: CBZ w8, #0xd7fe08          | if (this.chapter.cfg.isCameraAnimation == false) goto label_7;
        if(this.chapter.cfg.isCameraAnimation == false)
        {
            goto label_7;
        }
        // 0x00D7FDAC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7FDB0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7FDB4: LDR x20, [x19, #0x38]      | X20 = this.mAnimator; //P2              
        // 0x00D7FDB8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7FDBC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7FDC0: TBZ w8, #0, #0xd7fdd0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00D7FDC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7FDC8: CBNZ w8, #0xd7fdd0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00D7FDCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_9:
        // 0x00D7FDD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7FDD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7FDD8: MOV x1, x20                | X1 = this.mAnimator;//m1                
        // 0x00D7FDDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7FDE0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        // 0x00D7FDE4: TBZ w0, #0, #0xd802c4      | if (val_2 == false) goto label_15;      
        if(val_2 == false)
        {
            goto label_15;
        }
        // 0x00D7FDE8: LDR x19, [x19, #0x38]      | X19 = this.mAnimator; //P2              
        val_12 = this.mAnimator;
        // 0x00D7FDEC: CBNZ x19, #0xd7fdf4        | if (this.mAnimator != null) goto label_11;
        if(val_12 != null)
        {
            goto label_11;
        }
        // 0x00D7FDF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_11:
        // 0x00D7FDF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7FDF8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D7FDFC: MOV x0, x19                | X0 = this.mAnimator;//m1                
        // 0x00D7FE00: BL #0x20cb458              | this.mAnimator.set_enabled(value:  true);
        val_12.enabled = true;
        // 0x00D7FE04: B #0xd802c4                |  goto label_15;                         
        goto label_15;
        label_7:
        // 0x00D7FE08: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D7FE0C: CBNZ x20, #0xd7fe14        | if (this.chapter != null) goto label_13;
        if(this.chapter != null)
        {
            goto label_13;
        }
        // 0x00D7FE10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CEvent.ZEventCenter), ????);
        label_13:
        // 0x00D7FE14: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D7FE18: CBNZ x20, #0xd7fe20        | if (this.chapter.cfg != null) goto label_14;
        if(this.chapter.cfg != null)
        {
            goto label_14;
        }
        // 0x00D7FE1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CEvent.ZEventCenter), ????);
        label_14:
        // 0x00D7FE20: LDR w8, [x20, #0x17c]      | W8 = this.chapter.cfg.Camera_time; //P2 
        // 0x00D7FE24: CMP w8, #1                 | STATE = COMPARE(this.chapter.cfg.Camera_time, 0x1)
        // 0x00D7FE28: B.LT #0xd802c4             | if (this.chapter.cfg.Camera_time < 1) goto label_15;
        if(this.chapter.cfg.Camera_time < 1)
        {
            goto label_15;
        }
        // 0x00D7FE2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FE30: MOV x0, x19                | X0 = 1152921514499587696 (0x100000024DA73E70);//ML01
        // 0x00D7FE34: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_3 = this.transform;
        // 0x00D7FE38: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00D7FE3C: CBNZ x20, #0xd7fe44        | if (val_3 != null) goto label_16;       
        if(val_3 != null)
        {
            goto label_16;
        }
        // 0x00D7FE40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_16:
        // 0x00D7FE44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FE48: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00D7FE4C: BL #0x26937d8              | X0 = val_3.get_rotation();              
        UnityEngine.Quaternion val_4 = val_3.rotation;
        // 0x00D7FE50: ADD x0, sp, #0x40          | X0 = (1152921514499575520 + 64) = 1152921514499575584 (0x100000024DA70F20);
        // 0x00D7FE54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FE58: STP s0, s1, [sp, #0x40]    | stack[1152921514499575584] = val_4.x;  stack[1152921514499575588] = val_4.y;  //  dest_result_addr=1152921514499575584 |  dest_result_addr=1152921514499575588
        // 0x00D7FE5C: STP s2, s3, [sp, #0x48]    | stack[1152921514499575592] = val_4.z;  stack[1152921514499575596] = val_4.w;  //  dest_result_addr=1152921514499575592 |  dest_result_addr=1152921514499575596
        // 0x00D7FE60: BL #0x1b7f1cc              | X0 = label_UnityEngine_Quaternion_INTERNAL_CALL_Inverse_GL01B7F1CC();
        // 0x00D7FE64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FE68: MOV x0, x19                | X0 = 1152921514499587696 (0x100000024DA73E70);//ML01
        // 0x00D7FE6C: MOV v8.16b, v2.16b         | V8 = val_4.z;//m1                       
        // 0x00D7FE70: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_5 = this.gameObject;
        // 0x00D7FE74: ADRP x26, #0x3630000       | X26 = 56819712 (0x3630000);             
        // 0x00D7FE78: LDR x26, [x26, #0x3d0]     | X26 = 1152921504954501264;              
        // 0x00D7FE7C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00D7FE80: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00D7FE84: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7FE88: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D7FE8C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00D7FE90: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7FE94: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D7FE98: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7FE9C: CBNZ x21, #0xd7fea4        | if ( != null) goto label_17;            
        if(null != null)
        {
            goto label_17;
        }
        // 0x00D7FEA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_17:
        // 0x00D7FEA4: ADRP x22, #0x3610000       | X22 = 56688640 (0x3610000);             
        // 0x00D7FEA8: LDR x22, [x22, #0x858]     | X22 = (string**)(1152921512527230304)("rotation");
        // 0x00D7FEAC: LDR x0, [x22]              | X0 = "rotation";                        
        // 0x00D7FEB0: CBZ x0, #0xd7fed0          | if ("rotation" == null) goto label_19;  
        // 0x00D7FEB4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D7FEB8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D7FEBC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "rotation", ????); 
        // 0x00D7FEC0: CBNZ x0, #0xd7fed0         | if ("rotation" != null) goto label_19;  
        if("rotation" != null)
        {
            goto label_19;
        }
        // 0x00D7FEC4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "rotation", ????); 
        // 0x00D7FEC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FECC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "rotation", ????); 
        label_19:
        // 0x00D7FED0: LDR x22, [x22]             | X22 = "rotation";                       
        // 0x00D7FED4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D7FED8: CBNZ w8, #0xd7fee8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_20;
        // 0x00D7FEDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "rotation", ????); 
        // 0x00D7FEE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FEE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "rotation", ????); 
        label_20:
        // 0x00D7FEE8: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "rotation";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "rotation";
        // 0x00D7FEEC: LDP s0, s1, [x19, #0x68]   | S0 = this.rx; //P2  S1 = this.ry; //P2   //  | 
        // 0x00D7FEF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FEF4: ADD x0, sp, #0x30          | X0 = (1152921514499575520 + 48) = 1152921514499575568 (0x100000024DA70F10);
        // 0x00D7FEF8: MOV v2.16b, v8.16b         | V2 = val_4.z;//m1                       
        // 0x00D7FEFC: STR wzr, [sp, #0x38]       | stack[1152921514499575576] = 0x0;        //  dest_result_addr=1152921514499575576
        // 0x00D7FF00: STR xzr, [sp, #0x30]       | stack[1152921514499575568] = 0x0;        //  dest_result_addr=1152921514499575568
        // 0x00D7FF04: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00D7FF08: ADRP x25, #0x3673000       | X25 = 57094144 (0x3673000);             
        // 0x00D7FF0C: LDR w8, [sp, #0x38]        | W8 = 0x0;                               
        // 0x00D7FF10: LDR x9, [sp, #0x30]        | X9 = 0x0;                               
        // 0x00D7FF14: LDR x25, [x25, #0x488]     | X25 = 1152921504695078912;              
        // 0x00D7FF18: ADD x1, sp, #0x20          | X1 = (1152921514499575520 + 32) = 1152921514499575552 (0x100000024DA70F00);
        // 0x00D7FF1C: STR w8, [sp, #0x28]        | stack[1152921514499575560] = 0x0;        //  dest_result_addr=1152921514499575560
        // 0x00D7FF20: LDR x0, [x25]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D7FF24: STR x9, [sp, #0x20]        | stack[1152921514499575552] = 0x0;        //  dest_result_addr=1152921514499575552
        // 0x00D7FF28: BL #0x27bc028              | X0 = 1152921514499656560 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), null);
        // 0x00D7FF2C: MOV x22, x0                | X22 = 1152921514499656560 (0x100000024DA84B70);//ML01
        // 0x00D7FF30: CBZ x22, #0xd7ff54         | if (null == 0) goto label_22;           
        if(0 == 0)
        {
            goto label_22;
        }
        // 0x00D7FF34: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D7FF38: MOV x0, x22                | X0 = 1152921514499656560 (0x100000024DA84B70);//ML01
        // 0x00D7FF3C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D7FF40: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? null, ????);       
        // 0x00D7FF44: CBNZ x0, #0xd7ff54         | if (null != 0) goto label_22;           
        if(0 != 0)
        {
            goto label_22;
        }
        // 0x00D7FF48: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? null, ????);       
        // 0x00D7FF4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FF50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null, ????);       
        label_22:
        // 0x00D7FF54: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D7FF58: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00D7FF5C: B.HI #0xd7ff6c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_23;
        // 0x00D7FF60: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null, ????);       
        // 0x00D7FF64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FF68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null, ????);       
        label_23:
        // 0x00D7FF6C: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = null;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = 0;
        // 0x00D7FF70: ADRP x23, #0x360c000       | X23 = 56672256 (0x360C000);             
        // 0x00D7FF74: LDR x23, [x23, #0x728]     | X23 = (string**)(1152921510122312064)("time");
        // 0x00D7FF78: LDR x0, [x23]              | X0 = "time";                            
        // 0x00D7FF7C: CBZ x0, #0xd7ff9c          | if ("time" == null) goto label_25;      
        // 0x00D7FF80: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D7FF84: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D7FF88: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00D7FF8C: CBNZ x0, #0xd7ff9c         | if ("time" != null) goto label_25;      
        if("time" != null)
        {
            goto label_25;
        }
        // 0x00D7FF90: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00D7FF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FF98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_25:
        // 0x00D7FF9C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D7FFA0: LDR x22, [x23]             | X22 = "time";                           
        // 0x00D7FFA4: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00D7FFA8: B.HI #0xd7ffb8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_26;
        // 0x00D7FFAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00D7FFB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FFB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_26:
        // 0x00D7FFB8: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00D7FFBC: LDR x22, [x19, #0xb8]      | X22 = this.chapter; //P2                
        // 0x00D7FFC0: CBNZ x22, #0xd7ffc8        | if (this.chapter != null) goto label_27;
        if(this.chapter != null)
        {
            goto label_27;
        }
        // 0x00D7FFC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_27:
        // 0x00D7FFC8: LDR x22, [x22, #0x10]      | X22 = this.chapter.cfg; //P2            
        // 0x00D7FFCC: CBNZ x22, #0xd7ffd4        | if (this.chapter.cfg != null) goto label_28;
        if(this.chapter.cfg != null)
        {
            goto label_28;
        }
        // 0x00D7FFD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_28:
        // 0x00D7FFD4: ADRP x24, #0x3652000       | X24 = 56958976 (0x3652000);             
        // 0x00D7FFD8: LDR w8, [x22, #0x17c]      | W8 = this.chapter.cfg.Camera_time; //P2 
        // 0x00D7FFDC: LDR x24, [x24, #0x140]     | X24 = 1152921504607113216;              
        // 0x00D7FFE0: ADD x1, sp, #0x1c          | X1 = (1152921514499575520 + 28) = 1152921514499575548 (0x100000024DA70EFC);
        // 0x00D7FFE4: STR w8, [sp, #0x1c]        | stack[1152921514499575548] = this.chapter.cfg.Camera_time;  //  dest_result_addr=1152921514499575548
        // 0x00D7FFE8: LDR x0, [x24]              | X0 = typeof(System.Int32);              
        // 0x00D7FFEC: BL #0x27bc028              | X0 = 1152921514499668848 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.chapter.cfg.Camera_time);
        // 0x00D7FFF0: MOV x22, x0                | X22 = 1152921514499668848 (0x100000024DA87B70);//ML01
        // 0x00D7FFF4: CBNZ x21, #0xd7fffc        | if ( != null) goto label_29;            
        if(null != null)
        {
            goto label_29;
        }
        // 0x00D7FFF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.chapter.cfg.Camera_time, ????);
        label_29:
        // 0x00D7FFFC: CBZ x22, #0xd80020         | if (this.chapter.cfg.Camera_time == 0) goto label_31;
        if(this.chapter.cfg.Camera_time == 0)
        {
            goto label_31;
        }
        // 0x00D80000: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D80004: MOV x0, x22                | X0 = 1152921514499668848 (0x100000024DA87B70);//ML01
        // 0x00D80008: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D8000C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.chapter.cfg.Camera_time, ????);
        // 0x00D80010: CBNZ x0, #0xd80020         | if (this.chapter.cfg.Camera_time != 0) goto label_31;
        if(this.chapter.cfg.Camera_time != 0)
        {
            goto label_31;
        }
        // 0x00D80014: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.chapter.cfg.Camera_time, ????);
        // 0x00D80018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8001C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.chapter.cfg.Camera_time, ????);
        label_31:
        // 0x00D80020: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D80024: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00D80028: B.HI #0xd80038             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_32;
        // 0x00D8002C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.chapter.cfg.Camera_time, ????);
        // 0x00D80030: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80034: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.chapter.cfg.Camera_time, ????);
        label_32:
        // 0x00D80038: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = this.chapter.cfg.Camera_time; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = this.chapter.cfg.Camera_time;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00D8003C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00D80040: LDR x8, [x8, #0x178]       | X8 = 1152921504856739840;               
        // 0x00D80044: LDR x0, [x8]               | X0 = typeof(iTween);                    
        // 0x00D80048: LDRB w8, [x0, #0x10a]      | W8 = iTween.__il2cppRuntimeField_10A;   
        // 0x00D8004C: TBZ w8, #0, #0xd8005c      | if (iTween.__il2cppRuntimeField_has_cctor == 0) goto label_34;
        // 0x00D80050: LDR w8, [x0, #0xbc]        | W8 = iTween.__il2cppRuntimeField_cctor_finished;
        // 0x00D80054: CBNZ w8, #0xd8005c         | if (iTween.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
        // 0x00D80058: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(iTween), ????);
        label_34:
        // 0x00D8005C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80060: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D80064: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D80068: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_6 = iTween.Hash(args:  0);
        // 0x00D8006C: MOV x2, x0                 | X2 = val_6;//m1                         
        // 0x00D80070: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80074: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D80078: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x00D8007C: BL #0x17c7120              | iTween.RotateTo(target:  0, args:  val_5);
        iTween.RotateTo(target:  0, args:  val_5);
        // 0x00D80080: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80084: MOV x0, x19                | X0 = 1152921514499587696 (0x100000024DA73E70);//ML01
        // 0x00D80088: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_7 = this.gameObject;
        // 0x00D8008C: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00D80090: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00D80094: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D80098: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D8009C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00D800A0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D800A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D800A8: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_14 = null;
        // 0x00D800AC: CBNZ x21, #0xd800b4        | if ( != null) goto label_35;            
        if(null != null)
        {
            goto label_35;
        }
        // 0x00D800B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_35:
        // 0x00D800B4: ADRP x22, #0x35b8000       | X22 = 56328192 (0x35B8000);             
        // 0x00D800B8: LDR x22, [x22, #0x3a0]     | X22 = (string**)(1152921511315277136)("position");
        // 0x00D800BC: LDR x0, [x22]              | X0 = "position";                        
        // 0x00D800C0: CBZ x0, #0xd800e0          | if ("position" == null) goto label_37;  
        // 0x00D800C4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D800C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D800CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "position", ????); 
        // 0x00D800D0: CBNZ x0, #0xd800e0         | if ("position" != null) goto label_37;  
        if("position" != null)
        {
            goto label_37;
        }
        // 0x00D800D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "position", ????); 
        // 0x00D800D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D800DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "position", ????); 
        label_37:
        // 0x00D800E0: LDR x22, [x22]             | X22 = "position";                       
        // 0x00D800E4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D800E8: CBNZ w8, #0xd800f8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_38;
        // 0x00D800EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "position", ????); 
        // 0x00D800F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D800F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "position", ????); 
        label_38:
        // 0x00D800F8: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "position";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "position";
        // 0x00D800FC: LDR x22, [x19, #0xb8]      | X22 = this.chapter; //P2                
        // 0x00D80100: CBNZ x22, #0xd80108        | if (this.chapter != null) goto label_39;
        if(this.chapter != null)
        {
            goto label_39;
        }
        // 0x00D80104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "position", ????); 
        label_39:
        // 0x00D80108: LDR x22, [x22, #0x10]      | X22 = this.chapter.cfg; //P2            
        // 0x00D8010C: CBNZ x22, #0xd80114        | if (this.chapter.cfg != null) goto label_40;
        if(this.chapter.cfg != null)
        {
            goto label_40;
        }
        // 0x00D80110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "position", ????); 
        label_40:
        // 0x00D80114: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D80118: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00D8011C: LDR x22, [x22, #0x180]     | X22 = this.chapter.cfg.Camera_end; //P2 
        // 0x00D80120: LDR x0, [x8]               | X0 = typeof(Util);                      
        // 0x00D80124: LDRB w8, [x0, #0x10a]      | W8 = Util.__il2cppRuntimeField_10A;     
        // 0x00D80128: TBZ w8, #0, #0xd80138      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_42;
        // 0x00D8012C: LDR w8, [x0, #0xbc]        | W8 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00D80130: CBNZ w8, #0xd80138         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
        // 0x00D80134: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_42:
        // 0x00D80138: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8013C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D80140: MOVZ w2, #0x2c             | W2 = 44 (0x2C);//ML01                   
        // 0x00D80144: MOV x1, x22                | X1 = this.chapter.cfg.Camera_end;//m1   
        // 0x00D80148: BL #0xe17800               | X0 = Util.FormatVector3ByStr(str:  0, c:  this.chapter.cfg.Camera_end);
        UnityEngine.Vector3 val_8 = Util.FormatVector3ByStr(str:  0, c:  this.chapter.cfg.Camera_end);
        // 0x00D8014C: LDR x0, [x25]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D80150: ADD x1, sp, #0x10          | X1 = (1152921514499575520 + 16) = 1152921514499575536 (0x100000024DA70EF0);
        // 0x00D80154: STP s0, s1, [sp, #0x10]    | stack[1152921514499575536] = val_8.x;  stack[1152921514499575540] = val_8.y;  //  dest_result_addr=1152921514499575536 |  dest_result_addr=1152921514499575540
        // 0x00D80158: STR s2, [sp, #0x18]        | stack[1152921514499575544] = val_8.z;    //  dest_result_addr=1152921514499575544
        // 0x00D8015C: BL #0x27bc028              | X0 = 1152921514499694448 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_8);
        // 0x00D80160: MOV x22, x0                | X22 = 1152921514499694448 (0x100000024DA8DF70);//ML01
        // 0x00D80164: CBNZ x21, #0xd8016c        | if ( != null) goto label_43;            
        if(null != null)
        {
            goto label_43;
        }
        // 0x00D80168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_43:
        // 0x00D8016C: CBZ x22, #0xd80190         | if (val_8 == 0) goto label_45;          
        if(val_8 == 0)
        {
            goto label_45;
        }
        // 0x00D80170: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D80174: MOV x0, x22                | X0 = 1152921514499694448 (0x100000024DA8DF70);//ML01
        // 0x00D80178: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D8017C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
        // 0x00D80180: CBNZ x0, #0xd80190         | if (val_8 != 0) goto label_45;          
        if(val_8 != 0)
        {
            goto label_45;
        }
        // 0x00D80184: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
        // 0x00D80188: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8018C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_45:
        // 0x00D80190: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D80194: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00D80198: B.HI #0xd801a8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_46;
        // 0x00D8019C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00D801A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D801A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_46:
        // 0x00D801A8: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_8;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_8;
        // 0x00D801AC: LDR x0, [x23]              | X0 = "time";                            
        // 0x00D801B0: CBZ x0, #0xd801d0          | if ("time" == null) goto label_48;      
        // 0x00D801B4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D801B8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D801BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00D801C0: CBNZ x0, #0xd801d0         | if ("time" != null) goto label_48;      
        if("time" != null)
        {
            goto label_48;
        }
        // 0x00D801C4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00D801C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D801CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_48:
        // 0x00D801D0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D801D4: LDR x22, [x23]             | X22 = "time";                           
        // 0x00D801D8: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00D801DC: B.HI #0xd801ec             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_49;
        // 0x00D801E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00D801E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D801E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_49:
        // 0x00D801EC: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00D801F0: LDR x22, [x19, #0xb8]      | X22 = this.chapter; //P2                
        // 0x00D801F4: CBNZ x22, #0xd801fc        | if (this.chapter != null) goto label_50;
        if(this.chapter != null)
        {
            goto label_50;
        }
        // 0x00D801F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_50:
        // 0x00D801FC: LDR x22, [x22, #0x10]      | X22 = this.chapter.cfg; //P2            
        // 0x00D80200: CBNZ x22, #0xd80208        | if (this.chapter.cfg != null) goto label_51;
        if(this.chapter.cfg != null)
        {
            goto label_51;
        }
        // 0x00D80204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_51:
        // 0x00D80208: LDR w8, [x22, #0x17c]      | W8 = this.chapter.cfg.Camera_time; //P2 
        // 0x00D8020C: LDR x0, [x24]              | X0 = typeof(System.Int32);              
        // 0x00D80210: ADD x1, sp, #0xc           | X1 = (1152921514499575520 + 12) = 1152921514499575532 (0x100000024DA70EEC);
        // 0x00D80214: STR w8, [sp, #0xc]         | stack[1152921514499575532] = this.chapter.cfg.Camera_time;  //  dest_result_addr=1152921514499575532
        // 0x00D80218: BL #0x27bc028              | X0 = 1152921514499706736 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.chapter.cfg.Camera_time);
        // 0x00D8021C: MOV x22, x0                | X22 = 1152921514499706736 (0x100000024DA90F70);//ML01
        // 0x00D80220: CBNZ x21, #0xd80228        | if ( != null) goto label_52;            
        if(null != null)
        {
            goto label_52;
        }
        // 0x00D80224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.chapter.cfg.Camera_time, ????);
        label_52:
        // 0x00D80228: CBZ x22, #0xd8024c         | if (this.chapter.cfg.Camera_time == 0) goto label_54;
        if(this.chapter.cfg.Camera_time == 0)
        {
            goto label_54;
        }
        // 0x00D8022C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00D80230: MOV x0, x22                | X0 = 1152921514499706736 (0x100000024DA90F70);//ML01
        // 0x00D80234: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D80238: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.chapter.cfg.Camera_time, ????);
        // 0x00D8023C: CBNZ x0, #0xd8024c         | if (this.chapter.cfg.Camera_time != 0) goto label_54;
        if(this.chapter.cfg.Camera_time != 0)
        {
            goto label_54;
        }
        // 0x00D80240: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.chapter.cfg.Camera_time, ????);
        // 0x00D80244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80248: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.chapter.cfg.Camera_time, ????);
        label_54:
        // 0x00D8024C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D80250: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00D80254: B.HI #0xd80264             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_55;
        // 0x00D80258: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.chapter.cfg.Camera_time, ????);
        // 0x00D8025C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80260: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.chapter.cfg.Camera_time, ????);
        label_55:
        // 0x00D80264: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80268: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8026C: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D80270: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = this.chapter.cfg.Camera_time; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = this.chapter.cfg.Camera_time;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00D80274: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_9 = iTween.Hash(args:  0);
        // 0x00D80278: MOV x2, x0                 | X2 = val_9;//m1                         
        // 0x00D8027C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80280: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D80284: MOV x1, x20                | X1 = val_7;//m1                         
        // 0x00D80288: BL #0x17c41b0              | iTween.MoveTo(target:  0, args:  val_7);
        iTween.MoveTo(target:  0, args:  val_7);
        // 0x00D8028C: LDR x20, [x19, #0xb8]      | X20 = this.chapter; //P2                
        // 0x00D80290: CBNZ x20, #0xd80298        | if (this.chapter != null) goto label_56;
        if(this.chapter != null)
        {
            goto label_56;
        }
        // 0x00D80294: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_56:
        // 0x00D80298: LDR x20, [x20, #0x10]      | X20 = this.chapter.cfg; //P2            
        // 0x00D8029C: CBNZ x20, #0xd802a4        | if (this.chapter.cfg != null) goto label_57;
        if(this.chapter.cfg != null)
        {
            goto label_57;
        }
        // 0x00D802A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_57:
        // 0x00D802A4: LDR s0, [x20, #0x17c]      | S0 = this.chapter.cfg.Camera_time; //P2 
        // 0x00D802A8: MOV x0, x19                | X0 = 1152921514499587696 (0x100000024DA73E70);//ML01
        // 0x00D802AC: SCVTF s0, s0               | S0 = (float)(this.chapter.cfg.Camera_time);
        // 0x00D802B0: BL #0xd7f37c               | X0 = this.DoConfigDataCamera(timer:  (float)this.chapter.cfg.Camera_time);
        System.Collections.IEnumerator val_10 = this.DoConfigDataCamera(timer:  (float)this.chapter.cfg.Camera_time);
        // 0x00D802B4: MOV x1, x0                 | X1 = val_10;//m1                        
        // 0x00D802B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D802BC: MOV x0, x19                | X0 = 1152921514499587696 (0x100000024DA73E70);//ML01
        // 0x00D802C0: BL #0x1b772bc              | X0 = this.StartCoroutine(routine:  val_10);
        UnityEngine.Coroutine val_11 = this.StartCoroutine(routine:  val_10);
        label_15:
        // 0x00D802C4: SUB sp, x29, #0x50         | SP = (1152921514499575680 - 80) = 1152921514499575600 (0x100000024DA70F30);
        // 0x00D802C8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D802CC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D802D0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D802D4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D802D8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D802DC: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00D802E0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D802E4 (14156516), len: 80  VirtAddr: 0x00D802E4 RVA: 0x00D802E4 token: 100690271 methodIndex: 25925 delegateWrapperIndex: 0 methodInvoker: 0
    public void ChangeTarget(UnityEngine.Transform _target, float time, System.Action _onFinished)
    {
        //
        // Disasemble & Code
        // 0x00D802E4: STP d9, d8, [sp, #-0x30]!  | stack[1152921514499811552] = ???;  stack[1152921514499811560] = ???;  //  dest_result_addr=1152921514499811552 |  dest_result_addr=1152921514499811560
        // 0x00D802E8: STP x20, x19, [sp, #0x10]  | stack[1152921514499811568] = ???;  stack[1152921514499811576] = ???;  //  dest_result_addr=1152921514499811568 |  dest_result_addr=1152921514499811576
        // 0x00D802EC: STP x29, x30, [sp, #0x20]  | stack[1152921514499811584] = ???;  stack[1152921514499811592] = ???;  //  dest_result_addr=1152921514499811584 |  dest_result_addr=1152921514499811592
        // 0x00D802F0: ADD x29, sp, #0x20         | X29 = (1152921514499811552 + 32) = 1152921514499811584 (0x100000024DAAA900);
        // 0x00D802F4: MOV x19, x0                | X19 = 1152921514499823600 (0x100000024DAAD7F0);//ML01
        // 0x00D802F8: LDRB w8, [x19, #0x31]      | W8 = this.isChangeTarget; //P2          
        // 0x00D802FC: MOV v8.16b, v0.16b         | V8 = time;//m1                          
        // 0x00D80300: CBNZ w8, #0xd8030c         | if (this.isChangeTarget == true) goto label_0;
        if(this.isChangeTarget == true)
        {
            goto label_0;
        }
        // 0x00D80304: LDR x8, [x19, #0x40]       | X8 = this._target; //P2                 
        // 0x00D80308: STR x8, [x19, #0x20]       | this.lastTarget = this._target;          //  dest_result_addr=1152921514499823632
        this.lastTarget = this._target;
        label_0:
        // 0x00D8030C: MOV x0, x19                | X0 = 1152921514499823600 (0x100000024DAAD7F0);//ML01
        // 0x00D80310: STR x2, [x19, #0x28]       | this.onFinished = _onFinished;           //  dest_result_addr=1152921514499823640
        this.onFinished = _onFinished;
        // 0x00D80314: BL #0xd7f930               | this.ChangeTarget(_target:  _target);   
        this.ChangeTarget(_target:  _target);
        // 0x00D80318: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D8031C: STR s8, [x19, #0x34]       | this.lastChangeTime = time;              //  dest_result_addr=1152921514499823652
        this.lastChangeTime = time;
        // 0x00D80320: STRB w8, [x19, #0x31]      | this.isChangeTarget = true;              //  dest_result_addr=1152921514499823649
        this.isChangeTarget = true;
        // 0x00D80324: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D80328: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D8032C: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00D80330: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F930 (14154032), len: 496  VirtAddr: 0x00D7F930 RVA: 0x00D7F930 token: 100690272 methodIndex: 25926 delegateWrapperIndex: 0 methodInvoker: 0
    public void ChangeTarget(UnityEngine.Transform _target)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Transform val_9;
        // 0x00D7F930: STP d15, d14, [sp, #-0x70]! | stack[1152921514499948064] = ???;  stack[1152921514499948072] = ???;  //  dest_result_addr=1152921514499948064 |  dest_result_addr=1152921514499948072
        // 0x00D7F934: STP d13, d12, [sp, #0x10]  | stack[1152921514499948080] = ???;  stack[1152921514499948088] = ???;  //  dest_result_addr=1152921514499948080 |  dest_result_addr=1152921514499948088
        // 0x00D7F938: STP d11, d10, [sp, #0x20]  | stack[1152921514499948096] = ???;  stack[1152921514499948104] = ???;  //  dest_result_addr=1152921514499948096 |  dest_result_addr=1152921514499948104
        // 0x00D7F93C: STP d9, d8, [sp, #0x30]    | stack[1152921514499948112] = ???;  stack[1152921514499948120] = ???;  //  dest_result_addr=1152921514499948112 |  dest_result_addr=1152921514499948120
        // 0x00D7F940: STP x22, x21, [sp, #0x40]  | stack[1152921514499948128] = ???;  stack[1152921514499948136] = ???;  //  dest_result_addr=1152921514499948128 |  dest_result_addr=1152921514499948136
        // 0x00D7F944: STP x20, x19, [sp, #0x50]  | stack[1152921514499948144] = ???;  stack[1152921514499948152] = ???;  //  dest_result_addr=1152921514499948144 |  dest_result_addr=1152921514499948152
        // 0x00D7F948: STP x29, x30, [sp, #0x60]  | stack[1152921514499948160] = ???;  stack[1152921514499948168] = ???;  //  dest_result_addr=1152921514499948160 |  dest_result_addr=1152921514499948168
        // 0x00D7F94C: ADD x29, sp, #0x60         | X29 = (1152921514499948064 + 96) = 1152921514499948160 (0x100000024DACBE80);
        // 0x00D7F950: SUB sp, sp, #0x10          | SP = (1152921514499948064 - 16) = 1152921514499948048 (0x100000024DACBE10);
        // 0x00D7F954: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7F958: LDRB w8, [x21, #0x417]     | W8 = (bool)static_value_03734417;       
        // 0x00D7F95C: MOV x19, x1                | X19 = _target;//m1                      
        // 0x00D7F960: MOV x20, x0                | X20 = 1152921514499960176 (0x100000024DACED70);//ML01
        // 0x00D7F964: TBNZ w8, #0, #0xd7f980     | if (static_value_03734417 == true) goto label_0;
        // 0x00D7F968: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00D7F96C: LDR x8, [x8, #0x4e8]       | X8 = 0x2B903B0;                         
        // 0x00D7F970: LDR w0, [x8]               | W0 = 0x17B0;                            
        // 0x00D7F974: BL #0x2782188              | X0 = sub_2782188( ?? 0x17B0, ????);     
        // 0x00D7F978: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F97C: STRB w8, [x21, #0x417]     | static_value_03734417 = true;            //  dest_result_addr=57885719
        label_0:
        // 0x00D7F980: LDRH w8, [x20, #0x30]      | W8 = this.isPlayMove; //P2              
        // 0x00D7F984: AND w9, w8, #0xff          | W9 = (this.isPlayMove & 255);           
        bool val_1 = this.isPlayMove & 255;
        // 0x00D7F988: CBNZ w9, #0xd7fafc         | if ((this.isPlayMove & 255) == true) goto label_3;
        if(val_1 == true)
        {
            goto label_3;
        }
        // 0x00D7F98C: CMP w8, #0xff              | STATE = COMPARE(this.isPlayMove, 0xFF)  
        // 0x00D7F990: B.HI #0xd7fafc             | if (this.isPlayMove > true) goto label_3;
        if(this.isPlayMove > true)
        {
            goto label_3;
        }
        // 0x00D7F994: LDRB w8, [x20, #0x5c]      | W8 = this.isLockTarget; //P2            
        // 0x00D7F998: CBNZ w8, #0xd7fafc         | if (this.isLockTarget == true) goto label_3;
        if(this.isLockTarget == true)
        {
            goto label_3;
        }
        // 0x00D7F99C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7F9A0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7F9A4: LDR x21, [x20, #0x40]      | X21 = this._target; //P2                
        val_9 = this._target;
        // 0x00D7F9A8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7F9AC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7F9B0: TBZ w8, #0, #0xd7f9c0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00D7F9B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7F9B8: CBNZ w8, #0xd7f9c0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00D7F9BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00D7F9C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7F9C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7F9C8: MOV x1, x21                | X1 = this._target;//m1                  
        // 0x00D7F9CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F9D0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_9);
        bool val_2 = UnityEngine.Object.op_Equality(x:  0, y:  val_9);
        // 0x00D7F9D4: TBZ w0, #0, #0xd7faf8      | if (val_2 == false) goto label_6;       
        if(val_2 == false)
        {
            goto label_6;
        }
        // 0x00D7F9D8: CBNZ x19, #0xd7f9e0        | if (_target != null) goto label_7;      
        if(_target != null)
        {
            goto label_7;
        }
        // 0x00D7F9DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00D7F9E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F9E4: MOV x0, x19                | X0 = _target;//m1                       
        // 0x00D7F9E8: BL #0x2693510              | X0 = _target.get_position();            
        UnityEngine.Vector3 val_3 = _target.position;
        // 0x00D7F9EC: LDR x21, [x20, #0x78]      | X21 = this.mTransform; //P2             
        val_9 = this.mTransform;
        // 0x00D7F9F0: STP s0, s1, [x20, #0x48]   | this.lastTargetPos = val_3;  mem[1152921514499960252] = val_3.y;  //  dest_result_addr=1152921514499960248 |  dest_result_addr=1152921514499960252
        this.lastTargetPos = val_3;
        mem[1152921514499960252] = val_3.y;
        // 0x00D7F9F4: STR s2, [x20, #0x50]       | mem[1152921514499960256] = val_3.z;      //  dest_result_addr=1152921514499960256
        mem[1152921514499960256] = val_3.z;
        // 0x00D7F9F8: CBNZ x19, #0xd7fa00        | if (_target != null) goto label_8;      
        if(_target != null)
        {
            goto label_8;
        }
        // 0x00D7F9FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? _target, ????);    
        label_8:
        // 0x00D7FA00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FA04: MOV x0, x19                | X0 = _target;//m1                       
        // 0x00D7FA08: BL #0x2693510              | X0 = _target.get_position();            
        UnityEngine.Vector3 val_4 = _target.position;
        // 0x00D7FA0C: STP s1, s0, [sp, #8]       | stack[1152921514499948056] = val_4.y;  stack[1152921514499948060] = val_4.x;  //  dest_result_addr=1152921514499948056 |  dest_result_addr=1152921514499948060
        // 0x00D7FA10: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D7FA14: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D7FA18: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x00D7FA1C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D7FA20: LDP s14, s13, [x20, #0x80] | S14 = this.currentRotation; //P2         //  | 
        // 0x00D7FA24: LDP s12, s11, [x20, #0x88] |                                          //  | 
        // 0x00D7FA28: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D7FA2C: TBZ w8, #0, #0xd7fa3c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00D7FA30: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D7FA34: CBNZ w8, #0xd7fa3c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00D7FA38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_10:
        // 0x00D7FA3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7FA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FA44: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.forward;
        // 0x00D7FA48: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D7FA4C: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00D7FA50: MOV v15.16b, v0.16b        | V15 = val_5.x;//m1                      
        // 0x00D7FA54: MOV v8.16b, v1.16b         | V8 = val_5.y;//m1                       
        // 0x00D7FA58: MOV v9.16b, v2.16b         | V9 = val_5.z;//m1                       
        // 0x00D7FA5C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D7FA60: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D7FA64: TBZ w8, #0, #0xd7fa74      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00D7FA68: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D7FA6C: CBNZ w8, #0xd7fa74         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00D7FA70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_12:
        // 0x00D7FA74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7FA78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FA7C: MOV v0.16b, v14.16b        | V0 = this.currentRotation;//m1          
        // 0x00D7FA80: MOV v1.16b, v13.16b        | V1 = V13.16B;//m1                       
        // 0x00D7FA84: MOV v2.16b, v12.16b        | V2 = V12.16B;//m1                       
        // 0x00D7FA88: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x00D7FA8C: MOV v4.16b, v15.16b        | V4 = val_5.x;//m1                       
        // 0x00D7FA90: MOV v5.16b, v8.16b         | V5 = val_5.y;//m1                       
        // 0x00D7FA94: MOV v6.16b, v9.16b         | V6 = val_5.z;//m1                       
        // 0x00D7FA98: BL #0x1b7fc00              | X0 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = this.currentRotation, y = V13.16B, z = V12.16B, w = V11.16B}, point:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
        UnityEngine.Vector3 val_6 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = this.currentRotation, y = V13.16B, z = V12.16B, w = V11.16B}, point:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
        // 0x00D7FA9C: LDR s3, [x20, #0x60]       | S3 = this.distance; //P2                
        // 0x00D7FAA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7FAA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FAA8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, d:  this.distance);
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, d:  this.distance);
        // 0x00D7FAAC: MOV v3.16b, v0.16b         | V3 = val_7.x;//m1                       
        // 0x00D7FAB0: MOV v4.16b, v1.16b         | V4 = val_7.y;//m1                       
        // 0x00D7FAB4: LDP s1, s0, [sp, #8]       | S1 = val_4.y; S0 = val_4.x;              //  | 
        // 0x00D7FAB8: MOV v5.16b, v2.16b         | V5 = val_7.z;//m1                       
        // 0x00D7FABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7FAC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FAC4: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x00D7FAC8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z});
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z});
        // 0x00D7FACC: MOV v8.16b, v0.16b         | V8 = val_8.x;//m1                       
        // 0x00D7FAD0: MOV v9.16b, v1.16b         | V9 = val_8.y;//m1                       
        // 0x00D7FAD4: MOV v10.16b, v2.16b        | V10 = val_8.z;//m1                      
        // 0x00D7FAD8: CBNZ x21, #0xd7fae0        | if (this.mTransform != null) goto label_13;
        if(val_9 != null)
        {
            goto label_13;
        }
        // 0x00D7FADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_13:
        // 0x00D7FAE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7FAE4: MOV x0, x21                | X0 = this.mTransform;//m1               
        // 0x00D7FAE8: MOV v0.16b, v8.16b         | V0 = val_8.x;//m1                       
        // 0x00D7FAEC: MOV v1.16b, v9.16b         | V1 = val_8.y;//m1                       
        // 0x00D7FAF0: MOV v2.16b, v10.16b        | V2 = val_8.z;//m1                       
        // 0x00D7FAF4: BL #0x26935b8              | this.mTransform.set_position(value:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        val_9.position = new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z};
        label_6:
        // 0x00D7FAF8: STR x19, [x20, #0x40]      | this._target = _target;                  //  dest_result_addr=1152921514499960240
        this._target = _target;
        label_3:
        // 0x00D7FAFC: SUB sp, x29, #0x60         | SP = (1152921514499948160 - 96) = 1152921514499948064 (0x100000024DACBE20);
        // 0x00D7FB00: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7FB04: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7FB08: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7FB0C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D7FB10: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D7FB14: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D7FB18: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00D7FB1C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D80334 (14156596), len: 56  VirtAddr: 0x00D80334 RVA: 0x00D80334 token: 100690273 methodIndex: 25927 delegateWrapperIndex: 0 methodInvoker: 0
    public void PlayMove(UnityEngine.Transform _target, System.Action _onFinished)
    {
        //
        // Disasemble & Code
        // 0x00D80334: STP x20, x19, [sp, #-0x20]! | stack[1152921514500084720] = ???;  stack[1152921514500084728] = ???;  //  dest_result_addr=1152921514500084720 |  dest_result_addr=1152921514500084728
        // 0x00D80338: STP x29, x30, [sp, #0x10]  | stack[1152921514500084736] = ???;  stack[1152921514500084744] = ???;  //  dest_result_addr=1152921514500084736 |  dest_result_addr=1152921514500084744
        // 0x00D8033C: ADD x29, sp, #0x10         | X29 = (1152921514500084720 + 16) = 1152921514500084736 (0x100000024DAED400);
        // 0x00D80340: MOV x19, x0                | X19 = 1152921514500096752 (0x100000024DAF02F0);//ML01
        // 0x00D80344: LDR x8, [x19, #0x40]       | X8 = this._target; //P2                 
        // 0x00D80348: MOV x20, x2                | X20 = _onFinished;//m1                  
        // 0x00D8034C: STR x8, [x19, #0x20]       | this.lastTarget = this._target;          //  dest_result_addr=1152921514500096784
        this.lastTarget = this._target;
        // 0x00D80350: BL #0xd7f930               | this.ChangeTarget(_target:  _target);   
        this.ChangeTarget(_target:  _target);
        // 0x00D80354: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D80358: STRB w8, [x19, #0x30]      | this.isPlayMove = true;                  //  dest_result_addr=1152921514500096800
        this.isPlayMove = true;
        // 0x00D8035C: STR x20, [x19, #0x28]      | this.onFinished = _onFinished;           //  dest_result_addr=1152921514500096792
        this.onFinished = _onFinished;
        // 0x00D80360: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D80364: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D80368: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D8036C (14156652), len: 2428  VirtAddr: 0x00D8036C RVA: 0x00D8036C token: 100690274 methodIndex: 25928 delegateWrapperIndex: 0 methodInvoker: 0
    public void LateUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        var val_45;
        //  | 
        UnityEngine.Quaternion val_46;
        //  | 
        float val_47;
        //  | 
        float val_48;
        //  | 
        float val_49;
        //  | 
        float val_50;
        //  | 
        float val_51;
        //  | 
        float val_52;
        //  | 
        float val_53;
        //  | 
        float val_54;
        //  | 
        UnityEngine.Transform val_55;
        //  | 
        UnityEngine.Quaternion val_56;
        //  | 
        float val_57;
        //  | 
        float val_58;
        //  | 
        var val_59;
        //  | 
        var val_60;
        //  | 
        var val_61;
        //  | 
        System.Action val_62;
        // 0x00D8036C: STP d15, d14, [sp, #-0x70]! | stack[1152921514500282656] = ???;  stack[1152921514500282664] = ???;  //  dest_result_addr=1152921514500282656 |  dest_result_addr=1152921514500282664
        // 0x00D80370: STP d13, d12, [sp, #0x10]  | stack[1152921514500282672] = ???;  stack[1152921514500282680] = ???;  //  dest_result_addr=1152921514500282672 |  dest_result_addr=1152921514500282680
        // 0x00D80374: STP d11, d10, [sp, #0x20]  | stack[1152921514500282688] = ???;  stack[1152921514500282696] = ???;  //  dest_result_addr=1152921514500282688 |  dest_result_addr=1152921514500282696
        // 0x00D80378: STP d9, d8, [sp, #0x30]    | stack[1152921514500282704] = ???;  stack[1152921514500282712] = ???;  //  dest_result_addr=1152921514500282704 |  dest_result_addr=1152921514500282712
        // 0x00D8037C: STP x22, x21, [sp, #0x40]  | stack[1152921514500282720] = ???;  stack[1152921514500282728] = ???;  //  dest_result_addr=1152921514500282720 |  dest_result_addr=1152921514500282728
        // 0x00D80380: STP x20, x19, [sp, #0x50]  | stack[1152921514500282736] = ???;  stack[1152921514500282744] = ???;  //  dest_result_addr=1152921514500282736 |  dest_result_addr=1152921514500282744
        // 0x00D80384: STP x29, x30, [sp, #0x60]  | stack[1152921514500282752] = ???;  stack[1152921514500282760] = ???;  //  dest_result_addr=1152921514500282752 |  dest_result_addr=1152921514500282760
        // 0x00D80388: ADD x29, sp, #0x60         | X29 = (1152921514500282656 + 96) = 1152921514500282752 (0x100000024DB1D980);
        // 0x00D8038C: SUB sp, sp, #0x10          | SP = (1152921514500282656 - 16) = 1152921514500282640 (0x100000024DB1D910);
        // 0x00D80390: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D80394: LDRB w8, [x20, #0x418]     | W8 = (bool)static_value_03734418;       
        // 0x00D80398: MOV x19, x0                | X19 = 1152921514500294768 (0x100000024DB20870);//ML01
        // 0x00D8039C: TBNZ w8, #0, #0xd803b8     | if (static_value_03734418 == true) goto label_0;
        // 0x00D803A0: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00D803A4: LDR x8, [x8, #0xe30]       | X8 = 0x2B903B8;                         
        // 0x00D803A8: LDR w0, [x8]               | W0 = 0x17B2;                            
        // 0x00D803AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17B2, ????);     
        // 0x00D803B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D803B4: STRB w8, [x20, #0x418]     | static_value_03734418 = true;            //  dest_result_addr=57885720
        label_0:
        // 0x00D803B8: LDRB w8, [x19, #0x18]      | W8 = this.<IsOpeningMoveUpdate>k__BackingField; //P2 
        // 0x00D803BC: CBZ w8, #0xd80c70          | if (this.<IsOpeningMoveUpdate>k__BackingField == false) goto label_65;
        if((this.<IsOpeningMoveUpdate>k__BackingField) == false)
        {
            goto label_65;
        }
        // 0x00D803C0: LDRB w8, [x19, #0xc0]      | W8 = this.isStart; //P2                 
        // 0x00D803C4: CBZ w8, #0xd80c70          | if (this.isStart == false) goto label_65;
        if(this.isStart == false)
        {
            goto label_65;
        }
        // 0x00D803C8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D803CC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D803D0: LDR x20, [x19, #0x40]      | X20 = this._target; //P2                
        // 0x00D803D4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D803D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D803DC: TBZ w8, #0, #0xd803ec      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D803E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D803E4: CBNZ w8, #0xd803ec         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D803E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x00D803EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D803F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D803F4: MOV x1, x20                | X1 = this._target;//m1                  
        // 0x00D803F8: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x00D803FC: TBZ w0, #0, #0xd80c70      | if (val_1 == false) goto label_65;      
        if(val_1 == false)
        {
            goto label_65;
        }
        // 0x00D80400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80408: BL #0xadcf6c               | X0 = ShakeCamera.get_isshake();         
        bool val_2 = ShakeCamera.isshake;
        // 0x00D8040C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00D80410: TBNZ w8, #0, #0xd80c70     | if ((val_2 & 1) == true) goto label_65; 
        if(val_3 == true)
        {
            goto label_65;
        }
        // 0x00D80414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8041C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_4 = UnityEngine.Time.deltaTime;
        // 0x00D80420: STR s0, [x19, #0x1c]       | this.deltaTime = val_4;                  //  dest_result_addr=1152921514500294796
        this.deltaTime = val_4;
        // 0x00D80424: ADRP x22, #0x3642000       | X22 = 56893440 (0x3642000);             
        // 0x00D80428: LDR x22, [x22, #0xd78]     | X22 = 1152921504695132160;              
        // 0x00D8042C: LDR x0, [x22]              | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D80430: LDP s10, s9, [x19, #0x68]  | S10 = this.rx; //P2  S9 = this.ry; //P2  //  | 
        // 0x00D80434: LDR s8, [x19, #0x70]       | S8 = this.rz; //P2                      
        // 0x00D80438: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D8043C: TBZ w8, #0, #0xd8044c      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00D80440: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D80444: CBNZ w8, #0xd8044c         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00D80448: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_8:
        // 0x00D8044C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80454: MOV v0.16b, v10.16b        | V0 = this.rx;//m1                       
        // 0x00D80458: MOV v1.16b, v9.16b         | V1 = this.ry;//m1                       
        // 0x00D8045C: MOV v2.16b, v8.16b         | V2 = this.rz;//m1                       
        // 0x00D80460: BL #0x1b7f530              | X0 = UnityEngine.Quaternion.Euler(x:  this.rx, y:  this.ry, z:  this.rz);
        UnityEngine.Quaternion val_5 = UnityEngine.Quaternion.Euler(x:  this.rx, y:  this.ry, z:  this.rz);
        // 0x00D80464: MOV v8.16b, v0.16b         | V8 = val_5.x;//m1                       
        // 0x00D80468: MOV v9.16b, v1.16b         | V9 = val_5.y;//m1                       
        // 0x00D8046C: STP s8, s9, [x19, #0x80]   | this.currentRotation = val_5;  mem[1152921514500294900] = val_5.y;  //  dest_result_addr=1152921514500294896 |  dest_result_addr=1152921514500294900
        this.currentRotation = val_5;
        mem[1152921514500294900] = val_5.y;
        // 0x00D80470: LDRB w8, [x19, #0x5d]      | W8 = this.isDamping; //P2               
        // 0x00D80474: MOV v10.16b, v2.16b        | V10 = val_5.z;//m1                      
        // 0x00D80478: MOV v11.16b, v3.16b        | V11 = val_5.w;//m1                      
        // 0x00D8047C: STP s10, s11, [x19, #0x88] | mem[1152921514500294904] = val_5.z;  mem[1152921514500294908] = val_5.w;  //  dest_result_addr=1152921514500294904 |  dest_result_addr=1152921514500294908
        mem[1152921514500294904] = val_5.z;
        mem[1152921514500294908] = val_5.w;
        // 0x00D80480: CBZ w8, #0xd805d0          | if (this.isDamping == false) goto label_9;
        if(this.isDamping == false)
        {
            goto label_9;
        }
        // 0x00D80484: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D80488: CBNZ x20, #0xd80490        | if (this.mTransform != null) goto label_10;
        if(this.mTransform != null)
        {
            goto label_10;
        }
        // 0x00D8048C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_10:
        // 0x00D80490: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80494: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80498: BL #0x2693654              | X0 = this.mTransform.get_localPosition();
        UnityEngine.Vector3 val_6 = this.mTransform.localPosition;
        // 0x00D8049C: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D804A0: LDR x21, [x19, #0x40]      | X21 = this._target; //P2                
        // 0x00D804A4: STP s0, s1, [x19, #0xa0]   | this.lastPos = val_6;  mem[1152921514500294932] = val_6.y;  //  dest_result_addr=1152921514500294928 |  dest_result_addr=1152921514500294932
        this.lastPos = val_6;
        mem[1152921514500294932] = val_6.y;
        // 0x00D804A8: STR s2, [x19, #0xa8]       | mem[1152921514500294936] = val_6.z;      //  dest_result_addr=1152921514500294936
        mem[1152921514500294936] = val_6.z;
        // 0x00D804AC: CBNZ x21, #0xd804b4        | if (this._target != null) goto label_11;
        if(this._target != null)
        {
            goto label_11;
        }
        // 0x00D804B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mTransform, ????);
        label_11:
        // 0x00D804B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D804B8: MOV x0, x21                | X0 = this._target;//m1                  
        // 0x00D804BC: BL #0x2693510              | X0 = this._target.get_position();       
        UnityEngine.Vector3 val_7 = this._target.position;
        // 0x00D804C0: STP s1, s0, [sp, #8]       | stack[1152921514500282648] = val_7.y;  stack[1152921514500282652] = val_7.x;  //  dest_result_addr=1152921514500282648 |  dest_result_addr=1152921514500282652
        // 0x00D804C4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D804C8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D804CC: MOV v10.16b, v2.16b        | V10 = val_7.z;//m1                      
        // 0x00D804D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D804D4: LDP s14, s13, [x19, #0x80] | S14 = this.currentRotation; //P2         //  | 
        val_46 = this.currentRotation;
        // 0x00D804D8: LDP s12, s11, [x19, #0x88] |                                          //  | 
        // 0x00D804DC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D804E0: TBZ w8, #0, #0xd804f0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00D804E4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D804E8: CBNZ w8, #0xd804f0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00D804EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_13:
        // 0x00D804F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D804F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D804F8: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.forward;
        // 0x00D804FC: LDR x0, [x22]              | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D80500: MOV v15.16b, v0.16b        | V15 = val_8.x;//m1                      
        // 0x00D80504: MOV v8.16b, v1.16b         | V8 = val_8.y;//m1                       
        // 0x00D80508: MOV v9.16b, v2.16b         | V9 = val_8.z;//m1                       
        // 0x00D8050C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D80510: TBZ w8, #0, #0xd80520      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00D80514: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D80518: CBNZ w8, #0xd80520         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00D8051C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_15:
        // 0x00D80520: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80528: MOV v0.16b, v14.16b        | V0 = this.currentRotation;//m1          
        // 0x00D8052C: MOV v1.16b, v13.16b        | V1 = V13.16B;//m1                       
        // 0x00D80530: MOV v2.16b, v12.16b        | V2 = V12.16B;//m1                       
        // 0x00D80534: MOV v3.16b, v11.16b        | V3 = val_5.w;//m1                       
        // 0x00D80538: MOV v4.16b, v15.16b        | V4 = val_8.x;//m1                       
        // 0x00D8053C: MOV v5.16b, v8.16b         | V5 = val_8.y;//m1                       
        // 0x00D80540: MOV v6.16b, v9.16b         | V6 = val_8.z;//m1                       
        // 0x00D80544: BL #0x1b7fc00              | X0 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_46, y = V13.16B, z = V12.16B, w = val_5.w}, point:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        UnityEngine.Vector3 val_9 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_46, y = V13.16B, z = V12.16B, w = val_5.w}, point:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z});
        // 0x00D80548: LDR s3, [x19, #0x60]       | S3 = this.distance; //P2                
        // 0x00D8054C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80554: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  this.distance);
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  this.distance);
        // 0x00D80558: MOV v3.16b, v0.16b         | V3 = val_10.x;//m1                      
        // 0x00D8055C: MOV v4.16b, v1.16b         | V4 = val_10.y;//m1                      
        // 0x00D80560: LDP s1, s0, [sp, #8]       | S1 = val_7.y; S0 = val_7.x;              //  | 
        // 0x00D80564: MOV v5.16b, v2.16b         | V5 = val_10.z;//m1                      
        // 0x00D80568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8056C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80570: MOV v2.16b, v10.16b        | V2 = val_7.z;//m1                       
        // 0x00D80574: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        // 0x00D80578: MOV v9.16b, v0.16b         | V9 = val_11.x;//m1                      
        val_49 = val_11.x;
        // 0x00D8057C: MOV v10.16b, v1.16b        | V10 = val_11.y;//m1                     
        val_50 = val_11.y;
        // 0x00D80580: MOV v8.16b, v2.16b         | V8 = val_11.z;//m1                      
        val_51 = val_11.z;
        // 0x00D80584: STP s9, s10, [x19, #0xac]  | this.targetPos = val_11;  mem[1152921514500294944] = val_11.y;  //  dest_result_addr=1152921514500294940 |  dest_result_addr=1152921514500294944
        this.targetPos = val_11;
        mem[1152921514500294944] = val_50;
        // 0x00D80588: STR s8, [x19, #0xb4]       | mem[1152921514500294948] = val_11.z;     //  dest_result_addr=1152921514500294948
        mem[1152921514500294948] = val_51;
        // 0x00D8058C: CBNZ x20, #0xd80594        | if (this.mTransform != null) goto label_16;
        if(this.mTransform != null)
        {
            goto label_16;
        }
        // 0x00D80590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_16:
        // 0x00D80594: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80598: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D8059C: MOV v0.16b, v9.16b         | V0 = val_11.x;//m1                      
        val_52 = val_49;
        // 0x00D805A0: MOV v1.16b, v10.16b        | V1 = val_11.y;//m1                      
        val_53 = val_50;
        // 0x00D805A4: MOV v2.16b, v8.16b         | V2 = val_11.z;//m1                      
        val_54 = val_51;
        // 0x00D805A8: BL #0x26936fc              | this.mTransform.set_localPosition(value:  new UnityEngine.Vector3() {x = val_52, y = val_53, z = val_54});
        this.mTransform.localPosition = new UnityEngine.Vector3() {x = val_52, y = val_53, z = val_54};
        // 0x00D805AC: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D805B0: LDR x21, [x19, #0x40]      | X21 = this._target; //P2                
        val_55 = this._target;
        // 0x00D805B4: CBNZ x20, #0xd805bc        | if (this.mTransform != null) goto label_17;
        if(this.mTransform != null)
        {
            goto label_17;
        }
        // 0x00D805B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mTransform, ????);
        label_17:
        // 0x00D805BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D805C0: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D805C4: MOV x1, x21                | X1 = this._target;//m1                  
        // 0x00D805C8: BL #0x26950d4              | this.mTransform.LookAt(target:  val_55);
        this.mTransform.LookAt(target:  val_55);
        // 0x00D805CC: B #0xd80998                |  goto label_18;                         
        goto label_18;
        label_9:
        // 0x00D805D0: LDP s0, s1, [x19, #0x90]   | S0 = this.lastRotation; //P2             //  | 
        val_56 = this.lastRotation;
        // 0x00D805D4: LDR x0, [x22]              | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D805D8: LDP s15, s14, [x19, #0x98] |                                          //  | 
        // 0x00D805DC: LDR s12, [x19, #0x74]      | S12 = this.posDamping; //P2             
        // 0x00D805E0: LDR s13, [x19, #0x1c]      | S13 = this.deltaTime; //P2              
        // 0x00D805E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D805E8: TBZ w8, #0, #0xd80600      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00D805EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D805F0: CBNZ w8, #0xd80600         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00D805F4: STP s1, s0, [sp, #8]       | stack[1152921514500282648] = val_5.y;  stack[1152921514500282652] = this.lastRotation;  //  dest_result_addr=1152921514500282648 |  dest_result_addr=1152921514500282652
        // 0x00D805F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        // 0x00D805FC: LDP s1, s0, [sp, #8]       | S1 = val_5.y; S0 = this.lastRotation;    //  | 
        val_57 = val_5.y;
        val_56 = val_56;
        label_20:
        // 0x00D80600: FMUL s2, s12, s13          | S2 = (this.posDamping * this.deltaTime);
        float val_12 = this.posDamping * this.deltaTime;
        // 0x00D80604: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80608: STR s2, [sp]               | stack[1152921514500282640] = (this.posDamping * this.deltaTime);  //  dest_result_addr=1152921514500282640
        // 0x00D8060C: MOV v2.16b, v15.16b        | V2 = V15.16B;//m1                       
        // 0x00D80610: MOV v3.16b, v14.16b        | V3 = V14.16B;//m1                       
        // 0x00D80614: MOV v4.16b, v8.16b         | V4 = val_5.x;//m1                       
        // 0x00D80618: MOV v5.16b, v9.16b         | V5 = val_5.y;//m1                       
        // 0x00D8061C: MOV v6.16b, v10.16b        | V6 = val_5.z;//m1                       
        // 0x00D80620: MOV v7.16b, v11.16b        | V7 = val_5.w;//m1                       
        // 0x00D80624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80628: BL #0x1b7ebf0              | X0 = UnityEngine.Quaternion.Lerp(a:  new UnityEngine.Quaternion() {x = val_56, y = val_57, z = V15.16B, w = V14.16B}, b:  new UnityEngine.Quaternion() {x = val_5.x, y = val_5.y, z = val_5.z, w = val_5.w}, t:  val_12);
        UnityEngine.Quaternion val_13 = UnityEngine.Quaternion.Lerp(a:  new UnityEngine.Quaternion() {x = val_56, y = val_57, z = V15.16B, w = V14.16B}, b:  new UnityEngine.Quaternion() {x = val_5.x, y = val_5.y, z = val_5.z, w = val_5.w}, t:  val_12);
        // 0x00D8062C: STP s0, s1, [x19, #0x80]   | this.currentRotation = val_13;  mem[1152921514500294900] = val_13.y;  //  dest_result_addr=1152921514500294896 |  dest_result_addr=1152921514500294900
        this.currentRotation = val_13;
        mem[1152921514500294900] = val_13.y;
        // 0x00D80630: LDR x20, [x19, #0x40]      | X20 = this._target; //P2                
        // 0x00D80634: STP s2, s3, [x19, #0x88]   | mem[1152921514500294904] = val_13.z;  mem[1152921514500294908] = val_13.w;  //  dest_result_addr=1152921514500294904 |  dest_result_addr=1152921514500294908
        mem[1152921514500294904] = val_13.z;
        mem[1152921514500294908] = val_13.w;
        // 0x00D80638: STP s0, s1, [x19, #0x90]   | this.lastRotation = val_13;  mem[1152921514500294916] = val_13.y;  //  dest_result_addr=1152921514500294912 |  dest_result_addr=1152921514500294916
        this.lastRotation = val_13;
        mem[1152921514500294916] = val_13.y;
        // 0x00D8063C: LDP s9, s8, [x19, #0x48]   | S9 = this.lastTargetPos; //P2            //  | 
        // 0x00D80640: LDR s10, [x19, #0x50]      | 
        // 0x00D80644: STP s2, s3, [x19, #0x98]   | mem[1152921514500294920] = val_13.z;  mem[1152921514500294924] = val_13.w;  //  dest_result_addr=1152921514500294920 |  dest_result_addr=1152921514500294924
        mem[1152921514500294920] = val_13.z;
        mem[1152921514500294924] = val_13.w;
        // 0x00D80648: CBNZ x20, #0xd80650        | if (this._target != null) goto label_21;
        if(this._target != null)
        {
            goto label_21;
        }
        // 0x00D8064C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_21:
        // 0x00D80650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80654: MOV x0, x20                | X0 = this._target;//m1                  
        // 0x00D80658: BL #0x2693510              | X0 = this._target.get_position();       
        UnityEngine.Vector3 val_14 = this._target.position;
        // 0x00D8065C: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00D80660: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        val_55 = 1152921504695078912;
        // 0x00D80664: LDR s14, [x19, #0x74]      | S14 = this.posDamping; //P2             
        // 0x00D80668: LDR s15, [x19, #0x1c]      | S15 = this.deltaTime; //P2              
        // 0x00D8066C: MOV v11.16b, v0.16b        | V11 = val_14.x;//m1                     
        // 0x00D80670: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D80674: MOV v12.16b, v1.16b        | V12 = val_14.y;//m1                     
        // 0x00D80678: MOV v13.16b, v2.16b        | V13 = val_14.z;//m1                     
        // 0x00D8067C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D80680: TBZ w8, #0, #0xd80690      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x00D80684: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D80688: CBNZ w8, #0xd80690         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x00D8068C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_23:
        // 0x00D80690: FMUL s6, s14, s15          | S6 = (this.posDamping * this.deltaTime);
        float val_15 = this.posDamping * this.deltaTime;
        // 0x00D80694: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8069C: MOV v0.16b, v9.16b         | V0 = this.lastTargetPos;//m1            
        // 0x00D806A0: MOV v1.16b, v8.16b         | V1 = val_5.x;//m1                       
        // 0x00D806A4: MOV v2.16b, v10.16b        | V2 = val_5.z;//m1                       
        // 0x00D806A8: MOV v3.16b, v11.16b        | V3 = val_14.x;//m1                      
        // 0x00D806AC: MOV v4.16b, v12.16b        | V4 = val_14.y;//m1                      
        // 0x00D806B0: MOV v5.16b, v13.16b        | V5 = val_14.z;//m1                      
        // 0x00D806B4: BL #0x2698e54              | X0 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = this.lastTargetPos, y = val_5.x, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, t:  float val_15 = this.posDamping * this.deltaTime);
        UnityEngine.Vector3 val_16 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = this.lastTargetPos, y = val_5.x, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z}, t:  val_15);
        // 0x00D806B8: STP s0, s1, [x19, #0x48]   | this.lastTargetPos = val_16;  mem[1152921514500294844] = val_16.y;  //  dest_result_addr=1152921514500294840 |  dest_result_addr=1152921514500294844
        this.lastTargetPos = val_16;
        mem[1152921514500294844] = val_16.y;
        // 0x00D806BC: STR s2, [x19, #0x50]       | mem[1152921514500294848] = val_16.z;     //  dest_result_addr=1152921514500294848
        mem[1152921514500294848] = val_16.z;
        // 0x00D806C0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D806C4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D806C8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D806CC: LDP s8, s9, [x19, #0x60]   | S8 = this.distance; //P2  S9 = this.lastDistance; //P2  //  | 
        // 0x00D806D0: LDR s10, [x19, #0x74]      | S10 = this.posDamping; //P2             
        // 0x00D806D4: LDR s11, [x19, #0x1c]      | S11 = this.deltaTime; //P2              
        // 0x00D806D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D806DC: TBZ w8, #0, #0xd806ec      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00D806E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D806E4: CBNZ w8, #0xd806ec         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00D806E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_25:
        // 0x00D806EC: FMUL s2, s10, s11          | S2 = (this.posDamping * this.deltaTime);
        float val_17 = this.posDamping * this.deltaTime;
        // 0x00D806F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D806F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D806F8: MOV v0.16b, v9.16b         | V0 = this.lastDistance;//m1             
        // 0x00D806FC: MOV v1.16b, v8.16b         | V1 = this.distance;//m1                 
        // 0x00D80700: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  this.lastDistance, b:  this.distance, t:  float val_17 = this.posDamping * this.deltaTime);
        float val_18 = UnityEngine.Mathf.Lerp(a:  this.lastDistance, b:  this.distance, t:  val_17);
        // 0x00D80704: LDP s8, s9, [x19, #0xa0]   | S8 = this.lastPos; //P2                  //  | 
        // 0x00D80708: LDR s10, [x19, #0xa8]      | 
        // 0x00D8070C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80714: STR s0, [x19, #0x64]       | this.lastDistance = val_18;              //  dest_result_addr=1152921514500294868
        this.lastDistance = val_18;
        // 0x00D80718: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.zero;
        // 0x00D8071C: MOV v3.16b, v0.16b         | V3 = val_19.x;//m1                      
        // 0x00D80720: MOV v4.16b, v1.16b         | V4 = val_19.y;//m1                      
        // 0x00D80724: MOV v5.16b, v2.16b         | V5 = val_19.z;//m1                      
        // 0x00D80728: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8072C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80730: MOV v0.16b, v8.16b         | V0 = this.lastPos;//m1                  
        // 0x00D80734: MOV v1.16b, v9.16b         | V1 = this.lastDistance;//m1             
        // 0x00D80738: MOV v2.16b, v10.16b        | V2 = this.posDamping;//m1               
        // 0x00D8073C: BL #0x269a824              | X0 = UnityEngine.Vector3.op_Equality(lhs:  new UnityEngine.Vector3() {x = this.lastPos, y = this.lastDistance, z = this.posDamping}, rhs:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        bool val_20 = UnityEngine.Vector3.op_Equality(lhs:  new UnityEngine.Vector3() {x = this.lastPos, y = this.lastDistance, z = this.posDamping}, rhs:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        // 0x00D80740: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D80744: TBZ w0, #0, #0xd8085c      | if (val_20 == false) goto label_26;     
        if(val_20 == false)
        {
            goto label_26;
        }
        // 0x00D80748: LDR s0, [x19, #0x48]       | S0 = this.lastTargetPos; //P2           
        // 0x00D8074C: STR s0, [sp, #0xc]         | stack[1152921514500282652] = this.lastTargetPos;  //  dest_result_addr=1152921514500282652
        // 0x00D80750: LDR s0, [x19, #0x4c]       | 
        // 0x00D80754: STR s0, [sp, #8]           | stack[1152921514500282648] = this.lastTargetPos;  //  dest_result_addr=1152921514500282648
        // 0x00D80758: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D8075C: LDR s10, [x19, #0x50]      | 
        // 0x00D80760: LDP s14, s13, [x19, #0x80] | S14 = this.currentRotation; //P2         //  | 
        val_46 = this.currentRotation;
        // 0x00D80764: LDP s12, s11, [x19, #0x88] |                                          //  | 
        // 0x00D80768: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D8076C: TBZ w8, #0, #0xd8077c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x00D80770: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D80774: CBNZ w8, #0xd8077c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x00D80778: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_28:
        // 0x00D8077C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80784: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_21 = UnityEngine.Vector3.forward;
        // 0x00D80788: LDR x0, [x22]              | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D8078C: MOV v15.16b, v0.16b        | V15 = val_21.x;//m1                     
        // 0x00D80790: MOV v8.16b, v1.16b         | V8 = val_21.y;//m1                      
        // 0x00D80794: MOV v9.16b, v2.16b         | V9 = val_21.z;//m1                      
        // 0x00D80798: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D8079C: TBZ w8, #0, #0xd807ac      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00D807A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D807A4: CBNZ w8, #0xd807ac         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00D807A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_30:
        // 0x00D807AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D807B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D807B4: MOV v0.16b, v14.16b        | V0 = this.currentRotation;//m1          
        // 0x00D807B8: MOV v1.16b, v13.16b        | V1 = val_14.z;//m1                      
        // 0x00D807BC: MOV v2.16b, v12.16b        | V2 = val_14.y;//m1                      
        // 0x00D807C0: MOV v3.16b, v11.16b        | V3 = this.deltaTime;//m1                
        // 0x00D807C4: MOV v4.16b, v15.16b        | V4 = val_21.x;//m1                      
        // 0x00D807C8: MOV v5.16b, v8.16b         | V5 = val_21.y;//m1                      
        // 0x00D807CC: MOV v6.16b, v9.16b         | V6 = val_21.z;//m1                      
        // 0x00D807D0: BL #0x1b7fc00              | X0 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_46, y = val_14.z, z = val_14.y, w = this.deltaTime}, point:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        UnityEngine.Vector3 val_22 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_46, y = val_14.z, z = val_14.y, w = this.deltaTime}, point:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        // 0x00D807D4: LDR s3, [x19, #0x64]       | S3 = this.lastDistance; //P2            
        // 0x00D807D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D807DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D807E0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, d:  this.lastDistance);
        UnityEngine.Vector3 val_23 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, d:  this.lastDistance);
        // 0x00D807E4: MOV v3.16b, v0.16b         | V3 = val_23.x;//m1                      
        // 0x00D807E8: MOV v4.16b, v1.16b         | V4 = val_23.y;//m1                      
        // 0x00D807EC: LDP s1, s0, [sp, #8]       | S1 = this.lastTargetPos; S0 = this.lastTargetPos; //  | 
        // 0x00D807F0: MOV v5.16b, v2.16b         | V5 = val_23.z;//m1                      
        // 0x00D807F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D807F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D807FC: MOV v2.16b, v10.16b        | V2 = this.posDamping;//m1               
        // 0x00D80800: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.lastTargetPos, y = this.lastTargetPos, z = this.posDamping}, b:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        UnityEngine.Vector3 val_24 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.lastTargetPos, y = this.lastTargetPos, z = this.posDamping}, b:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        // 0x00D80804: MOV v9.16b, v0.16b         | V9 = val_24.x;//m1                      
        val_58 = val_24.x;
        // 0x00D80808: MOV v10.16b, v1.16b        | V10 = val_24.y;//m1                     
        // 0x00D8080C: MOV v8.16b, v2.16b         | V8 = val_24.z;//m1                      
        // 0x00D80810: STP s9, s10, [x19, #0xac]  | this.targetPos = val_24;  mem[1152921514500294944] = val_24.y;  //  dest_result_addr=1152921514500294940 |  dest_result_addr=1152921514500294944
        this.targetPos = val_24;
        mem[1152921514500294944] = val_24.y;
        // 0x00D80814: STR s8, [x19, #0xb4]       | mem[1152921514500294948] = val_24.z;     //  dest_result_addr=1152921514500294948
        mem[1152921514500294948] = val_24.z;
        // 0x00D80818: CBNZ x20, #0xd80820        | if (this.mTransform != null) goto label_31;
        if(this.mTransform != null)
        {
            goto label_31;
        }
        // 0x00D8081C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_31:
        // 0x00D80820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80824: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80828: MOV v0.16b, v9.16b         | V0 = val_24.x;//m1                      
        // 0x00D8082C: MOV v1.16b, v10.16b        | V1 = val_24.y;//m1                      
        // 0x00D80830: MOV v2.16b, v8.16b         | V2 = val_24.z;//m1                      
        // 0x00D80834: BL #0x26936fc              | this.mTransform.set_localPosition(value:  new UnityEngine.Vector3() {x = val_58, y = val_24.y, z = val_24.z});
        this.mTransform.localPosition = new UnityEngine.Vector3() {x = val_58, y = val_24.y, z = val_24.z};
        // 0x00D80838: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D8083C: CBNZ x20, #0xd80844        | if (this.mTransform != null) goto label_32;
        if(this.mTransform != null)
        {
            goto label_32;
        }
        // 0x00D80840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mTransform, ????);
        label_32:
        // 0x00D80844: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80848: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D8084C: BL #0x2693654              | X0 = this.mTransform.get_localPosition();
        UnityEngine.Vector3 val_25 = this.mTransform.localPosition;
        // 0x00D80850: STP s0, s1, [x19, #0xa0]   | this.lastPos = val_25;  mem[1152921514500294932] = val_25.y;  //  dest_result_addr=1152921514500294928 |  dest_result_addr=1152921514500294932
        this.lastPos = val_25;
        mem[1152921514500294932] = val_25.y;
        // 0x00D80854: STR s2, [x19, #0xa8]       | mem[1152921514500294936] = val_25.z;     //  dest_result_addr=1152921514500294936
        mem[1152921514500294936] = val_25.z;
        // 0x00D80858: B #0xd8096c                |  goto label_33;                         
        goto label_33;
        label_26:
        // 0x00D8085C: CBNZ x20, #0xd80864        | if (this.mTransform != null) goto label_34;
        if(this.mTransform != null)
        {
            goto label_34;
        }
        // 0x00D80860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_34:
        // 0x00D80864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80868: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D8086C: BL #0x2693654              | X0 = this.mTransform.get_localPosition();
        UnityEngine.Vector3 val_26 = this.mTransform.localPosition;
        // 0x00D80870: STP s0, s1, [x19, #0xa0]   | this.lastPos = val_26;  mem[1152921514500294932] = val_26.y;  //  dest_result_addr=1152921514500294928 |  dest_result_addr=1152921514500294932
        this.lastPos = val_26;
        mem[1152921514500294932] = val_26.y;
        // 0x00D80874: LDR s0, [x19, #0x48]       | S0 = this.lastTargetPos; //P2           
        // 0x00D80878: STR s2, [x19, #0xa8]       | mem[1152921514500294936] = val_26.z;     //  dest_result_addr=1152921514500294936
        mem[1152921514500294936] = val_26.z;
        // 0x00D8087C: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D80880: STR s0, [sp, #0xc]         | stack[1152921514500282652] = this.lastTargetPos;  //  dest_result_addr=1152921514500282652
        // 0x00D80884: LDR s0, [x19, #0x4c]       | 
        // 0x00D80888: STR s0, [sp, #8]           | stack[1152921514500282648] = this.lastTargetPos;  //  dest_result_addr=1152921514500282648
        // 0x00D8088C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D80890: LDR s10, [x19, #0x50]      | 
        // 0x00D80894: LDP s14, s13, [x19, #0x80] | S14 = this.currentRotation; //P2         //  | 
        val_46 = this.currentRotation;
        // 0x00D80898: LDP s12, s11, [x19, #0x88] |                                          //  | 
        // 0x00D8089C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D808A0: TBZ w8, #0, #0xd808b0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_36;
        // 0x00D808A4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D808A8: CBNZ w8, #0xd808b0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
        // 0x00D808AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_36:
        // 0x00D808B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D808B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D808B8: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_27 = UnityEngine.Vector3.forward;
        // 0x00D808BC: LDR x0, [x22]              | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D808C0: MOV v15.16b, v0.16b        | V15 = val_27.x;//m1                     
        // 0x00D808C4: MOV v8.16b, v1.16b         | V8 = val_27.y;//m1                      
        // 0x00D808C8: MOV v9.16b, v2.16b         | V9 = val_27.z;//m1                      
        // 0x00D808CC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D808D0: TBZ w8, #0, #0xd808e0      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_38;
        // 0x00D808D4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D808D8: CBNZ w8, #0xd808e0         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
        // 0x00D808DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_38:
        // 0x00D808E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D808E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D808E8: MOV v0.16b, v14.16b        | V0 = this.currentRotation;//m1          
        // 0x00D808EC: MOV v1.16b, v13.16b        | V1 = val_14.z;//m1                      
        // 0x00D808F0: MOV v2.16b, v12.16b        | V2 = val_14.y;//m1                      
        // 0x00D808F4: MOV v3.16b, v11.16b        | V3 = this.deltaTime;//m1                
        // 0x00D808F8: MOV v4.16b, v15.16b        | V4 = val_27.x;//m1                      
        // 0x00D808FC: MOV v5.16b, v8.16b         | V5 = val_27.y;//m1                      
        // 0x00D80900: MOV v6.16b, v9.16b         | V6 = val_27.z;//m1                      
        // 0x00D80904: BL #0x1b7fc00              | X0 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_46, y = val_14.z, z = val_14.y, w = this.deltaTime}, point:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z});
        UnityEngine.Vector3 val_28 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = val_46, y = val_14.z, z = val_14.y, w = this.deltaTime}, point:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z});
        // 0x00D80908: LDR s3, [x19, #0x64]       | S3 = this.lastDistance; //P2            
        // 0x00D8090C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80914: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z}, d:  this.lastDistance);
        UnityEngine.Vector3 val_29 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z}, d:  this.lastDistance);
        // 0x00D80918: MOV v3.16b, v0.16b         | V3 = val_29.x;//m1                      
        // 0x00D8091C: MOV v4.16b, v1.16b         | V4 = val_29.y;//m1                      
        // 0x00D80920: LDP s1, s0, [sp, #8]       | S1 = this.lastTargetPos; S0 = this.lastTargetPos; //  | 
        // 0x00D80924: MOV v5.16b, v2.16b         | V5 = val_29.z;//m1                      
        // 0x00D80928: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8092C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80930: MOV v2.16b, v10.16b        | V2 = this.posDamping;//m1               
        // 0x00D80934: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.lastTargetPos, y = this.lastTargetPos, z = this.posDamping}, b:  new UnityEngine.Vector3() {x = val_29.x, y = val_29.y, z = val_29.z});
        UnityEngine.Vector3 val_30 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.lastTargetPos, y = this.lastTargetPos, z = this.posDamping}, b:  new UnityEngine.Vector3() {x = val_29.x, y = val_29.y, z = val_29.z});
        // 0x00D80938: MOV v9.16b, v0.16b         | V9 = val_30.x;//m1                      
        val_58 = val_30.x;
        // 0x00D8093C: MOV v10.16b, v1.16b        | V10 = val_30.y;//m1                     
        // 0x00D80940: MOV v8.16b, v2.16b         | V8 = val_30.z;//m1                      
        // 0x00D80944: STP s9, s10, [x19, #0xac]  | this.targetPos = val_30;  mem[1152921514500294944] = val_30.y;  //  dest_result_addr=1152921514500294940 |  dest_result_addr=1152921514500294944
        this.targetPos = val_30;
        mem[1152921514500294944] = val_30.y;
        // 0x00D80948: STR s8, [x19, #0xb4]       | mem[1152921514500294948] = val_30.z;     //  dest_result_addr=1152921514500294948
        mem[1152921514500294948] = val_30.z;
        // 0x00D8094C: CBNZ x20, #0xd80954        | if (this.mTransform != null) goto label_39;
        if(this.mTransform != null)
        {
            goto label_39;
        }
        // 0x00D80950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_39:
        // 0x00D80954: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80958: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D8095C: MOV v0.16b, v9.16b         | V0 = val_30.x;//m1                      
        // 0x00D80960: MOV v1.16b, v10.16b        | V1 = val_30.y;//m1                      
        // 0x00D80964: MOV v2.16b, v8.16b         | V2 = val_30.z;//m1                      
        // 0x00D80968: BL #0x26936fc              | this.mTransform.set_localPosition(value:  new UnityEngine.Vector3() {x = val_58, y = val_30.y, z = val_30.z});
        this.mTransform.localPosition = new UnityEngine.Vector3() {x = val_58, y = val_30.y, z = val_30.z};
        label_33:
        // 0x00D8096C: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D80970: LDP s8, s9, [x19, #0x48]   | S8 = this.lastTargetPos; //P2            //  | 
        val_51 = this.lastTargetPos;
        // 0x00D80974: LDR s10, [x19, #0x50]      | 
        // 0x00D80978: CBNZ x20, #0xd80980        | if (this.mTransform != null) goto label_40;
        if(this.mTransform != null)
        {
            goto label_40;
        }
        // 0x00D8097C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mTransform, ????);
        label_40:
        // 0x00D80980: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80984: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80988: MOV v0.16b, v8.16b         | V0 = this.lastTargetPos;//m1            
        val_52 = val_51;
        // 0x00D8098C: MOV v1.16b, v9.16b         | V1 = val_30.x;//m1                      
        val_53 = val_58;
        // 0x00D80990: MOV v2.16b, v10.16b        | V2 = val_30.y;//m1                      
        val_54 = val_30.y;
        // 0x00D80994: BL #0x26952ec              | this.mTransform.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_52, y = val_53, z = val_54});
        this.mTransform.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_52, y = val_53, z = val_54});
        label_18:
        // 0x00D80998: LDRB w8, [x19, #0x5d]      | W8 = this.isDamping; //P2               
        // 0x00D8099C: CBZ w8, #0xd80aec          | if (this.isDamping == false) goto label_48;
        if(this.isDamping == false)
        {
            goto label_48;
        }
        // 0x00D809A0: LDRB w21, [x19, #0xdc]     | W21 = this.ifMoveOnStatrBattle; //P2    
        val_55 = this.ifMoveOnStatrBattle;
        // 0x00D809A4: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D809A8: LDP s10, s9, [x19, #0xa0]  | S10 = this.lastPos; //P2                 //  | 
        // 0x00D809AC: LDR s8, [x19, #0xa8]       | 
        // 0x00D809B0: CBNZ x20, #0xd809b8        | if (this.mTransform != null) goto label_42;
        if(this.mTransform != null)
        {
            goto label_42;
        }
        // 0x00D809B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mTransform, ????);
        label_42:
        // 0x00D809B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D809BC: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D809C0: BL #0x2693654              | X0 = this.mTransform.get_localPosition();
        UnityEngine.Vector3 val_31 = this.mTransform.localPosition;
        // 0x00D809C4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D809C8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D809CC: MOV v13.16b, v0.16b        | V13 = val_31.x;//m1                     
        // 0x00D809D0: MOV v12.16b, v1.16b        | V12 = val_31.y;//m1                     
        val_48 = val_31.y;
        // 0x00D809D4: MOV v11.16b, v2.16b        | V11 = val_31.z;//m1                     
        val_47 = val_31.z;
        // 0x00D809D8: CBZ w21, #0xd80a78         | if (this.ifMoveOnStatrBattle == false) goto label_43;
        if(val_55 == false)
        {
            goto label_43;
        }
        // 0x00D809DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D809E0: LDR s14, [x19, #0xd4]      | S14 = this.alternateTime; //P2          
        val_46 = this.alternateTime;
        // 0x00D809E4: LDR s15, [x19, #0x1c]      | S15 = this.deltaTime; //P2              
        // 0x00D809E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D809EC: TBZ w8, #0, #0xd809fc      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_45;
        // 0x00D809F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D809F4: CBNZ w8, #0xd809fc         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
        // 0x00D809F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_45:
        // 0x00D809FC: FMUL s6, s14, s15          | S6 = (this.alternateTime * this.deltaTime);
        float val_32 = val_46 * this.deltaTime;
        // 0x00D80A00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80A08: MOV v0.16b, v10.16b        | V0 = this.lastPos;//m1                  
        // 0x00D80A0C: MOV v1.16b, v9.16b         | V1 = val_30.x;//m1                      
        // 0x00D80A10: MOV v2.16b, v8.16b         | V2 = this.lastTargetPos;//m1            
        // 0x00D80A14: MOV v3.16b, v13.16b        | V3 = val_31.x;//m1                      
        // 0x00D80A18: MOV v4.16b, v12.16b        | V4 = val_31.y;//m1                      
        // 0x00D80A1C: MOV v5.16b, v11.16b        | V5 = val_31.z;//m1                      
        // 0x00D80A20: BL #0x2698e54              | X0 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = this.lastPos, y = val_58, z = val_51}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_48, z = val_47}, t:  float val_32 = val_46 * this.deltaTime);
        UnityEngine.Vector3 val_33 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = this.lastPos, y = val_58, z = val_51}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_48, z = val_47}, t:  val_32);
        // 0x00D80A24: MOV v8.16b, v0.16b         | V8 = val_33.x;//m1                      
        // 0x00D80A28: MOV v9.16b, v1.16b         | V9 = val_33.y;//m1                      
        // 0x00D80A2C: MOV v10.16b, v2.16b        | V10 = val_33.z;//m1                     
        val_50 = val_33.z;
        // 0x00D80A30: CBNZ x20, #0xd80a38        | if (this.mTransform != null) goto label_46;
        if(this.mTransform != null)
        {
            goto label_46;
        }
        // 0x00D80A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_46:
        // 0x00D80A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80A3C: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80A40: MOV v0.16b, v8.16b         | V0 = val_33.x;//m1                      
        // 0x00D80A44: MOV v1.16b, v9.16b         | V1 = val_33.y;//m1                      
        val_53 = val_33.y;
        // 0x00D80A48: MOV v2.16b, v10.16b        | V2 = val_33.z;//m1                      
        val_54 = val_50;
        // 0x00D80A4C: BL #0x26936fc              | this.mTransform.set_localPosition(value:  new UnityEngine.Vector3() {x = val_33.x, y = val_53, z = val_54});
        this.mTransform.localPosition = new UnityEngine.Vector3() {x = val_33.x, y = val_53, z = val_54};
        // 0x00D80A50: LDR s8, [x19, #0xd8]       | S8 = this.alternateTimer; //P2          
        val_51 = this.alternateTimer;
        // 0x00D80A54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80A5C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_34 = UnityEngine.Time.deltaTime;
        // 0x00D80A60: FSUB s0, s8, s0            | S0 = (this.alternateTimer - val_34);    
        val_52 = val_51 - val_34;
        // 0x00D80A64: STR s0, [x19, #0xd8]       | this.alternateTimer = (this.alternateTimer - val_34);  //  dest_result_addr=1152921514500294984
        this.alternateTimer = val_52;
        // 0x00D80A68: FCMP s0, #0.0              | STATE = COMPARE((this.alternateTimer - val_34), 0)
        // 0x00D80A6C: B.HI #0xd80aec             | if (val_52 > 0) goto label_48;          
        if(val_52 > 0f)
        {
            goto label_48;
        }
        // 0x00D80A70: STRB wzr, [x19, #0xdc]     | this.ifMoveOnStatrBattle = false;        //  dest_result_addr=1152921514500294988
        this.ifMoveOnStatrBattle = false;
        // 0x00D80A74: B #0xd80aec                |  goto label_48;                         
        goto label_48;
        label_43:
        // 0x00D80A78: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D80A7C: LDR s14, [x19, #0x74]      | S14 = this.posDamping; //P2             
        val_46 = this.posDamping;
        // 0x00D80A80: LDR s15, [x19, #0x1c]      | S15 = this.deltaTime; //P2              
        // 0x00D80A84: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D80A88: TBZ w8, #0, #0xd80a98      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_50;
        // 0x00D80A8C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D80A90: CBNZ w8, #0xd80a98         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
        // 0x00D80A94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_50:
        // 0x00D80A98: FMUL s6, s14, s15          | S6 = (this.posDamping * this.deltaTime);
        float val_35 = val_46 * this.deltaTime;
        // 0x00D80A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80AA4: MOV v0.16b, v10.16b        | V0 = this.lastPos;//m1                  
        // 0x00D80AA8: MOV v1.16b, v9.16b         | V1 = val_30.x;//m1                      
        // 0x00D80AAC: MOV v2.16b, v8.16b         | V2 = this.lastTargetPos;//m1            
        // 0x00D80AB0: MOV v3.16b, v13.16b        | V3 = val_31.x;//m1                      
        // 0x00D80AB4: MOV v4.16b, v12.16b        | V4 = val_31.y;//m1                      
        // 0x00D80AB8: MOV v5.16b, v11.16b        | V5 = val_31.z;//m1                      
        // 0x00D80ABC: BL #0x2698e54              | X0 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = this.lastPos, y = val_58, z = val_51}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_48, z = val_47}, t:  float val_35 = val_46 * this.deltaTime);
        UnityEngine.Vector3 val_36 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = this.lastPos, y = val_58, z = val_51}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_48, z = val_47}, t:  val_35);
        // 0x00D80AC0: MOV v8.16b, v0.16b         | V8 = val_36.x;//m1                      
        val_51 = val_36.x;
        // 0x00D80AC4: MOV v9.16b, v1.16b         | V9 = val_36.y;//m1                      
        // 0x00D80AC8: MOV v10.16b, v2.16b        | V10 = val_36.z;//m1                     
        val_50 = val_36.z;
        // 0x00D80ACC: CBNZ x20, #0xd80ad4        | if (this.mTransform != null) goto label_51;
        if(this.mTransform != null)
        {
            goto label_51;
        }
        // 0x00D80AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_51:
        // 0x00D80AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80AD8: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80ADC: MOV v0.16b, v8.16b         | V0 = val_36.x;//m1                      
        val_52 = val_51;
        // 0x00D80AE0: MOV v1.16b, v9.16b         | V1 = val_36.y;//m1                      
        val_53 = val_36.y;
        // 0x00D80AE4: MOV v2.16b, v10.16b        | V2 = val_36.z;//m1                      
        val_54 = val_50;
        // 0x00D80AE8: BL #0x26936fc              | this.mTransform.set_localPosition(value:  new UnityEngine.Vector3() {x = val_52, y = val_53, z = val_54});
        this.mTransform.localPosition = new UnityEngine.Vector3() {x = val_52, y = val_53, z = val_54};
        label_48:
        // 0x00D80AEC: LDRB w8, [x19, #0x54]      | W8 = this.isNeedRXEvent; //P2           
        // 0x00D80AF0: CBZ w8, #0xd80b9c          | if (this.isNeedRXEvent == false) goto label_56;
        if(this.isNeedRXEvent == false)
        {
            goto label_56;
        }
        // 0x00D80AF4: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D80AF8: CBNZ x20, #0xd80b00        | if (this.mTransform != null) goto label_53;
        if(this.mTransform != null)
        {
            goto label_53;
        }
        // 0x00D80AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mTransform, ????);
        label_53:
        // 0x00D80B00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80B04: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80B08: BL #0x2693798              | X0 = this.mTransform.get_eulerAngles(); 
        UnityEngine.Vector3 val_37 = this.mTransform.eulerAngles;
        // 0x00D80B0C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00D80B10: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00D80B14: LDR s9, [x19, #0x68]       | S9 = this.rx; //P2                      
        // 0x00D80B18: MOV v8.16b, v0.16b         | V8 = val_37.x;//m1                      
        val_51 = val_37.x;
        // 0x00D80B1C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00D80B20: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00D80B24: TBZ w8, #0, #0xd80b34      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_55;
        // 0x00D80B28: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00D80B2C: CBNZ w8, #0xd80b34         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
        // 0x00D80B30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_55:
        // 0x00D80B34: LDR s0, [x19, #0x58]       | S0 = this.rxError; //P2                 
        val_52 = this.rxError;
        // 0x00D80B38: FSUB s1, s8, s9            | S1 = (val_37.x - this.rx);              
        float val_38 = val_51 - this.rx;
        // 0x00D80B3C: FABS s1, s1                | S1 = System.Math.Abs((val_37.x - this.rx));
        val_53 = System.Math.Abs(val_38);
        // 0x00D80B40: FCMP s1, s0                | STATE = COMPARE((val_37.x - this.rx), this.rxError)
        // 0x00D80B44: B.PL #0xd80b9c             | if (val_53 >= 0) goto label_56;         
        if(val_53 >= 0)
        {
            goto label_56;
        }
        // 0x00D80B48: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D80B4C: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00D80B50: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        object val_39 = null;
        // 0x00D80B54: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00D80B58: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00D80B5C: LDR x8, [x8, #0xd98]       | X8 = (string**)(1152921514490072480)("Camera_RX_FIXED");
        // 0x00D80B60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80B64: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00D80B68: LDR x21, [x8]              | X21 = "Camera_RX_FIXED";                
        val_55 = "Camera_RX_FIXED";
        // 0x00D80B6C: BL #0x16f59f0              | .ctor();                                
        val_39 = new System.Object();
        // 0x00D80B70: STR x21, [x20, #0x10]      | typeof(CEvent.ZEvent).__il2cppRuntimeField_10 = "Camera_RX_FIXED";  //  dest_result_addr=1152921504898326544
        typeof(CEvent.ZEvent).__il2cppRuntimeField_10 = val_55;
        // 0x00D80B74: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D80B78: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D80B7C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D80B80: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D80B84: TBZ w8, #0, #0xd80b94      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_58;
        // 0x00D80B88: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D80B8C: CBNZ w8, #0xd80b94         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_58;
        // 0x00D80B90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_58:
        // 0x00D80B94: MOV x1, x20                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00D80B98: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  null);
        CEvent.ZEventCenter.DispatchEvent(ev:  null);
        label_56:
        // 0x00D80B9C: LDR x8, [x19, #0x30]       | X8 = this.isPlayMove; //P2              
        bool val_45 = this.isPlayMove;
        // 0x00D80BA0: AND w9, w8, #0xff          | W9 = (this.isPlayMove & 255);           
        bool val_40 = val_45 & 255;
        // 0x00D80BA4: CBZ w9, #0xd80c44          | if ((this.isPlayMove & 255) == false) goto label_59;
        if(val_40 == false)
        {
            goto label_59;
        }
        // 0x00D80BA8: LDR x20, [x19, #0x78]      | X20 = this.mTransform; //P2             
        // 0x00D80BAC: CBNZ x20, #0xd80bb4        | if (this.mTransform != null) goto label_60;
        if(this.mTransform != null)
        {
            goto label_60;
        }
        // 0x00D80BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CEvent.ZEventCenter), ????);
        label_60:
        // 0x00D80BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80BB8: MOV x0, x20                | X0 = this.mTransform;//m1               
        // 0x00D80BBC: BL #0x2693654              | X0 = this.mTransform.get_localPosition();
        UnityEngine.Vector3 val_41 = this.mTransform.localPosition;
        // 0x00D80BC0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D80BC4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D80BC8: MOV v8.16b, v0.16b         | V8 = val_41.x;//m1                      
        val_51 = val_41.x;
        // 0x00D80BCC: MOV v9.16b, v1.16b         | V9 = val_41.y;//m1                      
        // 0x00D80BD0: MOV v13.16b, v2.16b        | V13 = val_41.z;//m1                     
        // 0x00D80BD4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D80BD8: LDP s12, s11, [x19, #0xac] | S12 = this.targetPos; //P2               //  | 
        val_48 = this.targetPos;
        // 0x00D80BDC: LDR s10, [x19, #0xb4]      | 
        // 0x00D80BE0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D80BE4: TBZ w8, #0, #0xd80bf4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_62;
        // 0x00D80BE8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D80BEC: CBNZ w8, #0xd80bf4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
        // 0x00D80BF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_62:
        // 0x00D80BF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80BFC: MOV v0.16b, v8.16b         | V0 = val_41.x;//m1                      
        // 0x00D80C00: MOV v1.16b, v9.16b         | V1 = val_41.y;//m1                      
        // 0x00D80C04: MOV v2.16b, v13.16b        | V2 = val_41.z;//m1                      
        // 0x00D80C08: MOV v3.16b, v12.16b        | V3 = this.targetPos;//m1                
        // 0x00D80C0C: MOV v4.16b, v11.16b        | V4 = val_31.z;//m1                      
        // 0x00D80C10: MOV v5.16b, v10.16b        | V5 = val_36.z;//m1                      
        // 0x00D80C14: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_51, y = val_41.y, z = val_41.z}, b:  new UnityEngine.Vector3() {x = val_48, y = val_47, z = val_50});
        float val_42 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_51, y = val_41.y, z = val_41.z}, b:  new UnityEngine.Vector3() {x = val_48, y = val_47, z = val_50});
        // 0x00D80C18: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00D80C1C: LDR s1, [x8, #0x7ac]       | S1 = 0.2;                               
        // 0x00D80C20: FCMP s0, s1                | STATE = COMPARE(val_42, 0.200000002980232)
        // 0x00D80C24: B.PL #0xd80c70             | if (val_42 >= 0) goto label_65;         
        if(val_42 >= 0)
        {
            goto label_65;
        }
        // 0x00D80C28: LDR x1, [x19, #0x20]       | X1 = this.lastTarget; //P2              
        // 0x00D80C2C: MOV x0, x19                | X0 = 1152921514500294768 (0x100000024DB20870);//ML01
        // 0x00D80C30: STRB wzr, [x19, #0x30]     | this.isPlayMove = false;                 //  dest_result_addr=1152921514500294816
        this.isPlayMove = false;
        // 0x00D80C34: BL #0xd7f930               | this.ChangeTarget(_target:  this.lastTarget);
        this.ChangeTarget(_target:  this.lastTarget);
        // 0x00D80C38: LDR x20, [x19, #0x28]      | X20 = this.onFinished; //P2             
        val_62 = this.onFinished;
        // 0x00D80C3C: STR xzr, [x19, #0x20]      | this.lastTarget = null;                  //  dest_result_addr=1152921514500294800
        this.lastTarget = 0;
        // 0x00D80C40: B #0xd80cb0                |  goto label_64;                         
        goto label_64;
        label_59:
        // 0x00D80C44: AND x9, x8, #0xff00        | X9 = (this.isPlayMove & 65280);         
        bool val_43 = val_45 & 65280;
        // 0x00D80C48: CBZ x9, #0xd80c70          | if ((this.isPlayMove & 65280) == false) goto label_65;
        if(val_43 == false)
        {
            goto label_65;
        }
        // 0x00D80C4C: LSR x8, x8, #0x20          | X8 = (this.isPlayMove >> 32);           
        val_45 = val_45 >> 32;
        // 0x00D80C50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80C54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80C58: FMOV s8, w8                | S8 = ((this.isPlayMove >> 32));         
        val_51 = val_45;
        // 0x00D80C5C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_44 = UnityEngine.Time.deltaTime;
        // 0x00D80C60: FSUB s0, s8, s0            | S0 = ((this.isPlayMove >> 32) - val_44);
        val_44 = val_51 - val_44;
        // 0x00D80C64: STR s0, [x19, #0x34]       | this.lastChangeTime = ((this.isPlayMove >> 32) - val_44);  //  dest_result_addr=1152921514500294820
        this.lastChangeTime = val_44;
        // 0x00D80C68: FCMP s0, #0.0              | STATE = COMPARE(((this.isPlayMove >> 32) - val_44), 0)
        // 0x00D80C6C: B.LS #0xd80c94             | if (val_44 <= 0) goto label_66;         
        if(val_44 <= 0f)
        {
            goto label_66;
        }
        label_65:
        // 0x00D80C70: SUB sp, x29, #0x60         | SP = (1152921514500282752 - 96) = 1152921514500282656 (0x100000024DB1D920);
        // 0x00D80C74: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00D80C78: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00D80C7C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00D80C80: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D80C84: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D80C88: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D80C8C: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00D80C90: RET                        |  return;                                
        return;
        label_66:
        // 0x00D80C94: LDR x1, [x19, #0x20]       | X1 = this.lastTarget; //P2              
        // 0x00D80C98: MOV x0, x19                | X0 = 1152921514500294768 (0x100000024DB20870);//ML01
        // 0x00D80C9C: STRB wzr, [x19, #0x31]     | this.isChangeTarget = false;             //  dest_result_addr=1152921514500294817
        this.isChangeTarget = false;
        // 0x00D80CA0: BL #0xd7f930               | this.ChangeTarget(_target:  this.lastTarget);
        this.ChangeTarget(_target:  this.lastTarget);
        // 0x00D80CA4: LDR x20, [x19, #0x28]      | X20 = this.onFinished; //P2             
        val_62 = this.onFinished;
        // 0x00D80CA8: STR xzr, [x19, #0x20]      | this.lastTarget = null;                  //  dest_result_addr=1152921514500294800
        this.lastTarget = 0;
        // 0x00D80CAC: STR wzr, [x19, #0x34]      | this.lastChangeTime = 0;                 //  dest_result_addr=1152921514500294820
        this.lastChangeTime = 0f;
        label_64:
        // 0x00D80CB0: STR xzr, [x19, #0x28]      | this.onFinished = null;                  //  dest_result_addr=1152921514500294808
        this.onFinished = 0;
        // 0x00D80CB4: CBNZ x20, #0xd80cbc        | if (this.onFinished != null) goto label_67;
        if(val_62 != null)
        {
            goto label_67;
        }
        // 0x00D80CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_67:
        // 0x00D80CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80CC0: MOV x0, x20                | X0 = this.onFinished;//m1               
        // 0x00D80CC4: SUB sp, x29, #0x60         | SP = (1152921514500282752 - 96) = 1152921514500282656 (0x100000024DB1D920);
        // 0x00D80CC8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00D80CCC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00D80CD0: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00D80CD4: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D80CD8: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D80CDC: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D80CE0: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00D80CE4: B #0x26e3100               | this.onFinished.Invoke(); return;       
        val_62.Invoke();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D80D14 (14159124), len: 388  VirtAddr: 0x00D80D14 RVA: 0x00D80D14 token: 100690275 methodIndex: 25929 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 OffsetPos()
    {
        //
        // Disasemble & Code
        // 0x00D80D14: STP d15, d14, [sp, #-0x60]! | stack[1152921514500476592] = ???;  stack[1152921514500476600] = ???;  //  dest_result_addr=1152921514500476592 |  dest_result_addr=1152921514500476600
        // 0x00D80D18: STP d13, d12, [sp, #0x10]  | stack[1152921514500476608] = ???;  stack[1152921514500476616] = ???;  //  dest_result_addr=1152921514500476608 |  dest_result_addr=1152921514500476616
        // 0x00D80D1C: STP d11, d10, [sp, #0x20]  | stack[1152921514500476624] = ???;  stack[1152921514500476632] = ???;  //  dest_result_addr=1152921514500476624 |  dest_result_addr=1152921514500476632
        // 0x00D80D20: STP d9, d8, [sp, #0x30]    | stack[1152921514500476640] = ???;  stack[1152921514500476648] = ???;  //  dest_result_addr=1152921514500476640 |  dest_result_addr=1152921514500476648
        // 0x00D80D24: STP x20, x19, [sp, #0x40]  | stack[1152921514500476656] = ???;  stack[1152921514500476664] = ???;  //  dest_result_addr=1152921514500476656 |  dest_result_addr=1152921514500476664
        // 0x00D80D28: STP x29, x30, [sp, #0x50]  | stack[1152921514500476672] = ???;  stack[1152921514500476680] = ???;  //  dest_result_addr=1152921514500476672 |  dest_result_addr=1152921514500476680
        // 0x00D80D2C: ADD x29, sp, #0x50         | X29 = (1152921514500476592 + 80) = 1152921514500476672 (0x100000024DB4CF00);
        // 0x00D80D30: SUB sp, sp, #0x10          | SP = (1152921514500476592 - 16) = 1152921514500476576 (0x100000024DB4CEA0);
        // 0x00D80D34: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D80D38: LDRB w8, [x20, #0x419]     | W8 = (bool)static_value_03734419;       
        // 0x00D80D3C: MOV x19, x0                | X19 = 1152921514500488688 (0x100000024DB4FDF0);//ML01
        // 0x00D80D40: TBNZ w8, #0, #0xd80d5c     | if (static_value_03734419 == true) goto label_0;
        // 0x00D80D44: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D80D48: LDR x8, [x8, #0x700]       | X8 = 0x2B903BC;                         
        // 0x00D80D4C: LDR w0, [x8]               | W0 = 0x17B3;                            
        // 0x00D80D50: BL #0x2782188              | X0 = sub_2782188( ?? 0x17B3, ????);     
        // 0x00D80D54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D80D58: STRB w8, [x20, #0x419]     | static_value_03734419 = true;            //  dest_result_addr=57885721
        label_0:
        // 0x00D80D5C: LDR x20, [x19, #0x40]      | X20 = this._target; //P2                
        // 0x00D80D60: CBNZ x20, #0xd80d68        | if (this._target != null) goto label_1; 
        if(this._target != null)
        {
            goto label_1;
        }
        // 0x00D80D64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17B3, ????);     
        label_1:
        // 0x00D80D68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80D6C: MOV x0, x20                | X0 = this._target;//m1                  
        // 0x00D80D70: BL #0x2693510              | X0 = this._target.get_position();       
        UnityEngine.Vector3 val_1 = this._target.position;
        // 0x00D80D74: STP s1, s0, [sp, #8]       | stack[1152921514500476584] = val_1.y;  stack[1152921514500476588] = val_1.x;  //  dest_result_addr=1152921514500476584 |  dest_result_addr=1152921514500476588
        // 0x00D80D78: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D80D7C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D80D80: MOV v10.16b, v2.16b        | V10 = val_1.z;//m1                      
        // 0x00D80D84: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D80D88: LDP s14, s13, [x19, #0x80] | S14 = this.currentRotation; //P2         //  | 
        // 0x00D80D8C: LDP s12, s11, [x19, #0x88] |                                          //  | 
        // 0x00D80D90: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00D80D94: TBZ w8, #0, #0xd80da4      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00D80D98: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00D80D9C: CBNZ w8, #0xd80da4         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00D80DA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_3:
        // 0x00D80DA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80DA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80DAC: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.forward;
        // 0x00D80DB0: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D80DB4: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00D80DB8: MOV v15.16b, v0.16b        | V15 = val_2.x;//m1                      
        // 0x00D80DBC: MOV v8.16b, v1.16b         | V8 = val_2.y;//m1                       
        // 0x00D80DC0: MOV v9.16b, v2.16b         | V9 = val_2.z;//m1                       
        // 0x00D80DC4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00D80DC8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00D80DCC: TBZ w8, #0, #0xd80ddc      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00D80DD0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00D80DD4: CBNZ w8, #0xd80ddc         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00D80DD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_5:
        // 0x00D80DDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80DE4: MOV v0.16b, v14.16b        | V0 = this.currentRotation;//m1          
        // 0x00D80DE8: MOV v1.16b, v13.16b        | V1 = V13.16B;//m1                       
        // 0x00D80DEC: MOV v2.16b, v12.16b        | V2 = V12.16B;//m1                       
        // 0x00D80DF0: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x00D80DF4: MOV v4.16b, v15.16b        | V4 = val_2.x;//m1                       
        // 0x00D80DF8: MOV v5.16b, v8.16b         | V5 = val_2.y;//m1                       
        // 0x00D80DFC: MOV v6.16b, v9.16b         | V6 = val_2.z;//m1                       
        // 0x00D80E00: BL #0x1b7fc00              | X0 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = this.currentRotation, y = V13.16B, z = V12.16B, w = V11.16B}, point:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
        UnityEngine.Vector3 val_3 = UnityEngine.Quaternion.op_Multiply(rotation:  new UnityEngine.Quaternion() {x = this.currentRotation, y = V13.16B, z = V12.16B, w = V11.16B}, point:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
        // 0x00D80E04: LDR s3, [x19, #0x60]       | S3 = this.distance; //P2                
        // 0x00D80E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80E0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80E10: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, d:  this.distance);
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, d:  this.distance);
        // 0x00D80E14: MOV v3.16b, v0.16b         | V3 = val_4.x;//m1                       
        // 0x00D80E18: MOV v4.16b, v1.16b         | V4 = val_4.y;//m1                       
        // 0x00D80E1C: LDP s1, s0, [sp, #8]       | S1 = val_1.y; S0 = val_1.x;              //  | 
        // 0x00D80E20: MOV v5.16b, v2.16b         | V5 = val_4.z;//m1                       
        // 0x00D80E24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80E28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80E2C: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        // 0x00D80E30: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, b:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, b:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        // 0x00D80E34: LDR x19, [x19, #0x40]      | X19 = this._target; //P2                
        // 0x00D80E38: MOV v8.16b, v0.16b         | V8 = val_5.x;//m1                       
        // 0x00D80E3C: MOV v9.16b, v1.16b         | V9 = val_5.y;//m1                       
        // 0x00D80E40: MOV v10.16b, v2.16b        | V10 = val_5.z;//m1                      
        // 0x00D80E44: CBNZ x19, #0xd80e4c        | if (this._target != null) goto label_6; 
        if(this._target != null)
        {
            goto label_6;
        }
        // 0x00D80E48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00D80E4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80E50: MOV x0, x19                | X0 = this._target;//m1                  
        // 0x00D80E54: BL #0x2693510              | X0 = this._target.get_position();       
        UnityEngine.Vector3 val_6 = this._target.position;
        // 0x00D80E58: MOV v3.16b, v0.16b         | V3 = val_6.x;//m1                       
        // 0x00D80E5C: MOV v4.16b, v1.16b         | V4 = val_6.y;//m1                       
        // 0x00D80E60: MOV v5.16b, v2.16b         | V5 = val_6.z;//m1                       
        // 0x00D80E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D80E68: MOV v0.16b, v8.16b         | V0 = val_5.x;//m1                       
        // 0x00D80E6C: MOV v1.16b, v9.16b         | V1 = val_5.y;//m1                       
        // 0x00D80E70: MOV v2.16b, v10.16b        | V2 = val_5.z;//m1                       
        // 0x00D80E74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80E78: SUB sp, x29, #0x50         | SP = (1152921514500476672 - 80) = 1152921514500476592 (0x100000024DB4CEB0);
        // 0x00D80E7C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D80E80: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D80E84: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D80E88: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D80E8C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D80E90: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
        // 0x00D80E94: B #0x26950c4               | return UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        return UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
    
    }
    //
    // Offset in libil2cpp.so: 0x00D80E98 (14159512), len: 76  VirtAddr: 0x00D80E98 RVA: 0x00D80E98 token: 100690276 methodIndex: 25930 delegateWrapperIndex: 0 methodInvoker: 0
    public void InitDamping()
    {
        //
        // Disasemble & Code
        // 0x00D80E98: STP x20, x19, [sp, #-0x20]! | stack[1152921514500600944] = ???;  stack[1152921514500600952] = ???;  //  dest_result_addr=1152921514500600944 |  dest_result_addr=1152921514500600952
        // 0x00D80E9C: STP x29, x30, [sp, #0x10]  | stack[1152921514500600960] = ???;  stack[1152921514500600968] = ???;  //  dest_result_addr=1152921514500600960 |  dest_result_addr=1152921514500600968
        // 0x00D80EA0: ADD x29, sp, #0x10         | X29 = (1152921514500600944 + 16) = 1152921514500600960 (0x100000024DB6B480);
        // 0x00D80EA4: MOV x19, x0                | X19 = 1152921514500612976 (0x100000024DB6E370);//ML01
        // 0x00D80EA8: LDR q0, [x19, #0x80]       | Q0 = this.currentRotation; //P2         
        // 0x00D80EAC: LDR x20, [x19, #0x40]      | X20 = this._target; //P2                
        // 0x00D80EB0: STR q0, [x19, #0x90]       | this.lastRotation = this.currentRotation;  //  dest_result_addr=1152921514500613120
        this.lastRotation = this.currentRotation;
        // 0x00D80EB4: CBNZ x20, #0xd80ebc        | if (this._target != null) goto label_0; 
        if(this._target != null)
        {
            goto label_0;
        }
        // 0x00D80EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00D80EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D80EC0: MOV x0, x20                | X0 = this._target;//m1                  
        // 0x00D80EC4: BL #0x2693510              | X0 = this._target.get_position();       
        UnityEngine.Vector3 val_1 = this._target.position;
        // 0x00D80EC8: LDR w8, [x19, #0x60]       | W8 = this.distance; //P2                
        // 0x00D80ECC: STP s0, s1, [x19, #0x48]   | this.lastTargetPos = val_1;  mem[1152921514500613052] = val_1.y;  //  dest_result_addr=1152921514500613048 |  dest_result_addr=1152921514500613052
        this.lastTargetPos = val_1;
        mem[1152921514500613052] = val_1.y;
        // 0x00D80ED0: STR s2, [x19, #0x50]       | mem[1152921514500613056] = val_1.z;      //  dest_result_addr=1152921514500613056
        mem[1152921514500613056] = val_1.z;
        // 0x00D80ED4: STR w8, [x19, #0x64]       | this.lastDistance = this.distance;       //  dest_result_addr=1152921514500613076
        this.lastDistance = this.distance;
        // 0x00D80ED8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D80EDC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D80EE0: RET                        |  return;                                
        return;
    
    }

}
