using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class ButtonClickState_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01426B64 (21130084), len: 8  VirtAddr: 0x01426B64 RVA: 0x01426B64 token: 100664088 methodIndex: 30133 delegateWrapperIndex: 0 methodInvoker: 0
        public ButtonClickState_Binding()
        {
            //
            // Disasemble & Code
            // 0x01426B64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426B68: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01426B6C (21130092), len: 4112  VirtAddr: 0x01426B6C RVA: 0x01426B6C token: 100664089 methodIndex: 30134 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_45;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_46;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_47;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_48;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_49;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_50;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_51;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_52;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_53;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_54;
            // 0x01426B6C: STP x28, x27, [sp, #-0x60]! | stack[1152921510100146144] = ???;  stack[1152921510100146152] = ???;  //  dest_result_addr=1152921510100146144 |  dest_result_addr=1152921510100146152
            // 0x01426B70: STP x26, x25, [sp, #0x10]  | stack[1152921510100146160] = ???;  stack[1152921510100146168] = ???;  //  dest_result_addr=1152921510100146160 |  dest_result_addr=1152921510100146168
            // 0x01426B74: STP x24, x23, [sp, #0x20]  | stack[1152921510100146176] = ???;  stack[1152921510100146184] = ???;  //  dest_result_addr=1152921510100146176 |  dest_result_addr=1152921510100146184
            // 0x01426B78: STP x22, x21, [sp, #0x30]  | stack[1152921510100146192] = ???;  stack[1152921510100146200] = ???;  //  dest_result_addr=1152921510100146192 |  dest_result_addr=1152921510100146200
            // 0x01426B7C: STP x20, x19, [sp, #0x40]  | stack[1152921510100146208] = ???;  stack[1152921510100146216] = ???;  //  dest_result_addr=1152921510100146208 |  dest_result_addr=1152921510100146216
            // 0x01426B80: STP x29, x30, [sp, #0x50]  | stack[1152921510100146224] = ???;  stack[1152921510100146232] = ???;  //  dest_result_addr=1152921510100146224 |  dest_result_addr=1152921510100146232
            // 0x01426B84: ADD x29, sp, #0x50         | X29 = (1152921510100146144 + 80) = 1152921510100146224 (0x10000001476D1830);
            // 0x01426B88: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x01426B8C: LDRB w8, [x20, #0xffb]     | W8 = (bool)static_value_03736FFB;       
            // 0x01426B90: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01426B94: TBNZ w8, #0, #0x1426bb0    | if (static_value_03736FFB == true) goto label_0;
            // 0x01426B98: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x01426B9C: LDR x8, [x8, #0xbd8]       | X8 = 0x2B8FEC4;                         
            // 0x01426BA0: LDR w0, [x8]               | W0 = 0x1675;                            
            // 0x01426BA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1675, ????);     
            // 0x01426BA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01426BAC: STRB w8, [x20, #0xffb]     | static_value_03736FFB = true;            //  dest_result_addr=57896955
            label_0:
            // 0x01426BB0: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x01426BB4: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x01426BB8: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01426BBC: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x01426BC0: LDR x8, [x8, #0x620]       | X8 = 1152921504925163520;               
            // 0x01426BC4: LDR x20, [x8]              | X20 = typeof(ButtonClickState);         
            // 0x01426BC8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01426BCC: TBZ w8, #0, #0x1426bdc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01426BD0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01426BD4: CBNZ w8, #0x1426bdc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01426BD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01426BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01426BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01426BE4: MOV x1, x20                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x01426BE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01426BEC: ADRP x26, #0x35ef000       | X26 = 56553472 (0x35EF000);             
            // 0x01426BF0: LDR x26, [x26, #0xff0]     | X26 = 1152921504987155056;              
            // 0x01426BF4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01426BF8: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01426BFC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426C00: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01426C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426C08: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426C0C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01426C10: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426C14: CBNZ x20, #0x1426c1c       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x01426C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x01426C1C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x01426C20: LDR x8, [x8, #0x430]       | X8 = (string**)(1152921510100062288)("get_value");
            // 0x01426C24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426C28: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01426C2C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01426C30: LDR x1, [x8]               | X1 = "get_value";                       
            // 0x01426C34: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01426C38: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426C3C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01426C40: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_value", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_value", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01426C44: ADRP x24, #0x35f0000       | X24 = 56557568 (0x35F0000);             
            // 0x01426C48: LDR x24, [x24, #0x500]     | X24 = 1152921504783417344;              
            // 0x01426C4C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01426C50: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426C54: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426C58: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0;
            // 0x01426C5C: CBNZ x22, #0x1426ca8       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0) != null)
            {
                goto label_4;
            }
            // 0x01426C60: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x01426C64: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01426C68: LDR x8, [x8, #0xd78]       | X8 = 1152921510100066480;               
            // 0x01426C6C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01426C70: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_value_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01426C74: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x01426C78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01426C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426C80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426C84: MOV x2, x22                | X2 = 1152921510100066480 (0x10000001476BE0B0);//ML01
            // 0x01426C88: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_3;
            // 0x01426C8C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_value_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_value_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01426C90: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426C94: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426C98: STR x23, [x8]              | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421440
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0 = val_35;
            // 0x01426C9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426CA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426CA4: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_4:
            // 0x01426CA8: CBNZ x19, #0x1426cb0       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x01426CAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_value_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x01426CB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426CB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01426CB8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01426CBC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01426CC0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache0);
            // 0x01426CC4: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01426CC8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426CCC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01426CD0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01426CD4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426CD8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01426CDC: ADRP x27, #0x365e000       | X27 = 57008128 (0x365E000);             
            // 0x01426CE0: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01426CE4: LDR x27, [x27, #0xcb8]     | X27 = 1152921504608604160;              
            // 0x01426CE8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426CEC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01426CF0: LDR x22, [x27]             | X22 = typeof(System.Boolean);           
            // 0x01426CF4: TBZ w9, #0, #0x1426d08     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01426CF8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01426CFC: CBNZ w9, #0x1426d08        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01426D00: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01426D04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x01426D08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01426D0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01426D10: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x01426D14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01426D18: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x01426D1C: CBNZ x21, #0x1426d24       | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x01426D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x01426D24: CBZ x22, #0x1426d48        | if (val_4 == null) goto label_10;       
            if(val_4 == null)
            {
                goto label_10;
            }
            // 0x01426D28: LDR x8, [x21]              | X8 = ;                                  
            // 0x01426D2C: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x01426D30: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01426D34: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x01426D38: CBNZ x0, #0x1426d48        | if (val_4 != null) goto label_10;       
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x01426D3C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x01426D40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426D44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_10:
            // 0x01426D48: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01426D4C: CBNZ w8, #0x1426d5c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_11;
            // 0x01426D50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x01426D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426D58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_11:
            // 0x01426D5C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;
            // 0x01426D60: CBNZ x20, #0x1426d68       | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x01426D64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x01426D68: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x01426D6C: LDR x8, [x8, #0x348]       | X8 = (string**)(1152921510100071600)("set_value");
            // 0x01426D70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426D74: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01426D78: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01426D7C: LDR x1, [x8]               | X1 = "set_value";                       
            // 0x01426D80: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01426D84: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426D88: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01426D8C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_value", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_5 = val_1.GetMethod(name:  "set_value", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01426D90: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426D94: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x01426D98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426D9C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1;
            // 0x01426DA0: CBNZ x22, #0x1426dec       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1 != null) goto label_13;
            if((ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1) != null)
            {
                goto label_13;
            }
            // 0x01426DA4: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x01426DA8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01426DAC: LDR x8, [x8, #0xd48]       | X8 = 1152921510100075792;               
            // 0x01426DB0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01426DB4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_value_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01426DB8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_6 = null;
            // 0x01426DBC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01426DC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426DC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426DC8: MOV x2, x22                | X2 = 1152921510100075792 (0x10000001476C0510);//ML01
            // 0x01426DCC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_6;
            // 0x01426DD0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_value_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_value_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01426DD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426DD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426DDC: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421448
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1 = val_35;
            // 0x01426DE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426DE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426DE8: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_13:
            // 0x01426DEC: CBNZ x19, #0x1426df4       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x01426DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_value_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x01426DF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426DF8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01426DFC: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x01426E00: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01426E04: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_5, func:  ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_5, func:  ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache1);
            // 0x01426E08: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01426E0C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426E10: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01426E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426E18: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426E1C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01426E20: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426E24: CBNZ x20, #0x1426e2c       | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x01426E28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_15:
            // 0x01426E2C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x01426E30: LDR x8, [x8, #0x1f8]       | X8 = (string**)(1152921510100076816)("OnClick");
            // 0x01426E34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426E38: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01426E3C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01426E40: LDR x1, [x8]               | X1 = "OnClick";                         
            // 0x01426E44: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01426E48: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426E4C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01426E50: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnClick", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_7 = val_1.GetMethod(name:  "OnClick", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01426E54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426E58: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x01426E5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426E60: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache2;
            val_36 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache2;
            // 0x01426E64: CBNZ x22, #0x1426eb0       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache2 != null) goto label_16;
            if(val_36 != null)
            {
                goto label_16;
            }
            // 0x01426E68: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x01426E6C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01426E70: LDR x8, [x8, #0x198]       | X8 = 1152921510100081008;               
            // 0x01426E74: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01426E78: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnClick_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01426E7C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = null;
            // 0x01426E80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01426E84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426E88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426E8C: MOV x2, x22                | X2 = 1152921510100081008 (0x10000001476C1970);//ML01
            // 0x01426E90: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_8;
            // 0x01426E94: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnClick_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnClick_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01426E98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426E9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426EA0: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421456
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache2 = val_35;
            // 0x01426EA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426EA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426EAC: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_36 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache2;
            label_16:
            // 0x01426EB0: CBNZ x19, #0x1426eb8       | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x01426EB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnClick_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_17:
            // 0x01426EB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426EBC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01426EC0: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x01426EC4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01426EC8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_7, func:  val_36);
            X1.RegisterCLRMethodRedirection(mi:  val_7, func:  val_36);
            // 0x01426ECC: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01426ED0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426ED4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01426ED8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01426EDC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426EE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01426EE4: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01426EE8: LDR x22, [x27]             | X22 = typeof(System.Boolean);           
            // 0x01426EEC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426EF0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01426EF4: TBZ w9, #0, #0x1426f08     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x01426EF8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01426EFC: CBNZ w9, #0x1426f08        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x01426F00: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01426F04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_19:
            // 0x01426F08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01426F0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01426F10: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x01426F14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01426F18: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x01426F1C: CBNZ x21, #0x1426f24       | if ( != null) goto label_20;            
            if(null != null)
            {
                goto label_20;
            }
            // 0x01426F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_20:
            // 0x01426F24: CBZ x22, #0x1426f48        | if (val_9 == null) goto label_22;       
            if(val_9 == null)
            {
                goto label_22;
            }
            // 0x01426F28: LDR x8, [x21]              | X8 = ;                                  
            // 0x01426F2C: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x01426F30: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01426F34: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x01426F38: CBNZ x0, #0x1426f48        | if (val_9 != null) goto label_22;       
            if(val_9 != null)
            {
                goto label_22;
            }
            // 0x01426F3C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x01426F40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426F44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_22:
            // 0x01426F48: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01426F4C: CBNZ w8, #0x1426f5c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_23;
            // 0x01426F50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x01426F54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426F58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_23:
            // 0x01426F5C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_9;
            // 0x01426F60: CBNZ x20, #0x1426f68       | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x01426F64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_24:
            // 0x01426F68: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x01426F6C: LDR x8, [x8, #0xd88]       | X8 = (string**)(1152921510100086128)("OnPress");
            // 0x01426F70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426F74: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01426F78: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01426F7C: LDR x1, [x8]               | X1 = "OnPress";                         
            // 0x01426F80: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01426F84: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01426F88: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01426F8C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnPress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "OnPress", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01426F90: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426F94: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x01426F98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426F9C: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache3;
            val_37 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache3;
            // 0x01426FA0: CBNZ x22, #0x1426fec       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache3 != null) goto label_25;
            if(val_37 != null)
            {
                goto label_25;
            }
            // 0x01426FA4: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x01426FA8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01426FAC: LDR x8, [x8, #0xf20]       | X8 = 1152921510100090320;               
            // 0x01426FB0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01426FB4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnPress_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01426FB8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x01426FBC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01426FC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01426FC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426FC8: MOV x2, x22                | X2 = 1152921510100090320 (0x10000001476C3DD0);//ML01
            // 0x01426FCC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_11;
            // 0x01426FD0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnPress_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnPress_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01426FD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426FD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426FDC: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421464
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache3 = val_35;
            // 0x01426FE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01426FE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01426FE8: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_37 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache3;
            label_25:
            // 0x01426FEC: CBNZ x19, #0x1426ff4       | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x01426FF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnPress_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_26:
            // 0x01426FF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01426FF8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01426FFC: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x01427000: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01427004: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_37);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_37);
            // 0x01427008: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142700C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01427010: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01427014: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01427018: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142701C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01427020: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01427024: LDR x22, [x27]             | X22 = typeof(System.Boolean);           
            // 0x01427028: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142702C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01427030: TBZ w9, #0, #0x1427044     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x01427034: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01427038: CBNZ w9, #0x1427044        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x0142703C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01427040: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x01427044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427048: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142704C: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x01427050: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01427054: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x01427058: CBNZ x21, #0x1427060       | if ( != null) goto label_29;            
            if(null != null)
            {
                goto label_29;
            }
            // 0x0142705C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_29:
            // 0x01427060: CBZ x22, #0x1427084        | if (val_12 == null) goto label_31;      
            if(val_12 == null)
            {
                goto label_31;
            }
            // 0x01427064: LDR x8, [x21]              | X8 = ;                                  
            // 0x01427068: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x0142706C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01427070: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x01427074: CBNZ x0, #0x1427084        | if (val_12 != null) goto label_31;      
            if(val_12 != null)
            {
                goto label_31;
            }
            // 0x01427078: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x0142707C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427080: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_31:
            // 0x01427084: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01427088: CBNZ w8, #0x1427098        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_32;
            // 0x0142708C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x01427090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427094: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_32:
            // 0x01427098: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_12;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_12;
            // 0x0142709C: CBNZ x20, #0x14270a4       | if (val_1 != null) goto label_33;       
            if(val_1 != null)
            {
                goto label_33;
            }
            // 0x014270A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_33:
            // 0x014270A4: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x014270A8: LDR x8, [x8, #0xe68]       | X8 = (string**)(1152921510100095440)("OnHover");
            // 0x014270AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014270B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014270B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014270B8: LDR x1, [x8]               | X1 = "OnHover";                         
            // 0x014270BC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014270C0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014270C4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x014270C8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnHover", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_13 = val_1.GetMethod(name:  "OnHover", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014270CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014270D0: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x014270D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014270D8: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache4;
            val_38 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache4;
            // 0x014270DC: CBNZ x22, #0x1427128       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache4 != null) goto label_34;
            if(val_38 != null)
            {
                goto label_34;
            }
            // 0x014270E0: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x014270E4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x014270E8: LDR x8, [x8, #0x5a8]       | X8 = 1152921510100099632;               
            // 0x014270EC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x014270F0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnHover_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x014270F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_14 = null;
            // 0x014270F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x014270FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427100: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427104: MOV x2, x22                | X2 = 1152921510100099632 (0x10000001476C6230);//ML01
            // 0x01427108: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_14;
            // 0x0142710C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnHover_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnHover_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01427110: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427114: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427118: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421472
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache4 = val_35;
            // 0x0142711C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427120: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427124: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_38 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache4;
            label_34:
            // 0x01427128: CBNZ x19, #0x1427130       | if (X1 != 0) goto label_35;             
            if(X1 != 0)
            {
                goto label_35;
            }
            // 0x0142712C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::OnHover_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_35:
            // 0x01427130: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427134: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427138: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x0142713C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01427140: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_13, func:  val_38);
            X1.RegisterCLRMethodRedirection(mi:  val_13, func:  val_38);
            // 0x01427144: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01427148: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142714C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01427150: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01427154: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01427158: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0142715C: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x01427160: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01427164: LDR x9, [x9, #0xa88]       | X9 = 1152921504606900224;               
            // 0x01427168: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142716C: LDR x22, [x9]              | X22 = typeof(System.Object);            
            // 0x01427170: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01427174: TBZ w9, #0, #0x1427188     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x01427178: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0142717C: CBNZ w9, #0x1427188        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x01427180: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01427184: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_37:
            // 0x01427188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142718C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01427190: MOV x1, x22                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x01427194: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01427198: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x0142719C: CBNZ x21, #0x14271a4       | if ( != null) goto label_38;            
            if(null != null)
            {
                goto label_38;
            }
            // 0x014271A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_38:
            // 0x014271A4: CBZ x22, #0x14271c8        | if (val_15 == null) goto label_40;      
            if(val_15 == null)
            {
                goto label_40;
            }
            // 0x014271A8: LDR x8, [x21]              | X8 = ;                                  
            // 0x014271AC: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x014271B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014271B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x014271B8: CBNZ x0, #0x14271c8        | if (val_15 != null) goto label_40;      
            if(val_15 != null)
            {
                goto label_40;
            }
            // 0x014271BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x014271C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014271C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_40:
            // 0x014271C8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014271CC: CBNZ w8, #0x14271dc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_41;
            // 0x014271D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x014271D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014271D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_41:
            // 0x014271DC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;
            // 0x014271E0: CBNZ x20, #0x14271e8       | if (val_1 != null) goto label_42;       
            if(val_1 != null)
            {
                goto label_42;
            }
            // 0x014271E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_42:
            // 0x014271E8: ADRP x28, #0x366b000       | X28 = 57061376 (0x366B000);             
            // 0x014271EC: LDR x28, [x28, #0x768]     | X28 = (string**)(1152921510100104752)("SetFunctionState");
            // 0x014271F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014271F4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014271F8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014271FC: LDR x1, [x28]              | X1 = "SetFunctionState";                
            // 0x01427200: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427204: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01427208: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0142720C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetFunctionState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_16 = val_1.GetMethod(name:  "SetFunctionState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01427210: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427214: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x01427218: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142721C: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache5;
            val_39 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache5;
            // 0x01427220: CBNZ x22, #0x142726c       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache5 != null) goto label_43;
            if(val_39 != null)
            {
                goto label_43;
            }
            // 0x01427224: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x01427228: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0142722C: LDR x8, [x8, #0x600]       | X8 = 1152921510100108960;               
            // 0x01427230: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01427234: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01427238: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_17 = null;
            // 0x0142723C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01427240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427248: MOV x2, x22                | X2 = 1152921510100108960 (0x10000001476C86A0);//ML01
            // 0x0142724C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_17;
            // 0x01427250: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01427254: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427258: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142725C: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421480
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache5 = val_35;
            // 0x01427260: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427264: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427268: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_39 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache5;
            label_43:
            // 0x0142726C: CBNZ x19, #0x1427274       | if (X1 != 0) goto label_44;             
            if(X1 != 0)
            {
                goto label_44;
            }
            // 0x01427270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_44:
            // 0x01427274: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427278: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142727C: MOV x1, x21                | X1 = val_16;//m1                        
            // 0x01427280: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01427284: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_16, func:  val_39);
            X1.RegisterCLRMethodRedirection(mi:  val_16, func:  val_39);
            // 0x01427288: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0142728C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01427290: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01427294: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01427298: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142729C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x014272A0: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x014272A4: LDR x22, [x27]             | X22 = typeof(System.Boolean);           
            // 0x014272A8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014272AC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014272B0: TBZ w9, #0, #0x14272c4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_46;
            // 0x014272B4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014272B8: CBNZ w9, #0x14272c4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_46;
            // 0x014272BC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014272C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_46:
            // 0x014272C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014272C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014272CC: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x014272D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_18 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014272D4: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x014272D8: CBNZ x21, #0x14272e0       | if ( != null) goto label_47;            
            if(null != null)
            {
                goto label_47;
            }
            // 0x014272DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_47:
            // 0x014272E0: CBZ x22, #0x1427304        | if (val_18 == null) goto label_49;      
            if(val_18 == null)
            {
                goto label_49;
            }
            // 0x014272E4: LDR x8, [x21]              | X8 = ;                                  
            // 0x014272E8: MOV x0, x22                | X0 = val_18;//m1                        
            // 0x014272EC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014272F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_18, ????);     
            // 0x014272F4: CBNZ x0, #0x1427304        | if (val_18 != null) goto label_49;      
            if(val_18 != null)
            {
                goto label_49;
            }
            // 0x014272F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_18, ????);     
            // 0x014272FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427300: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_49:
            // 0x01427304: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01427308: CBNZ w8, #0x1427318        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_50;
            // 0x0142730C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x01427310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427314: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_50:
            // 0x01427318: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;
            // 0x0142731C: CBNZ x20, #0x1427324       | if (val_1 != null) goto label_51;       
            if(val_1 != null)
            {
                goto label_51;
            }
            // 0x01427320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_51:
            // 0x01427324: LDR x1, [x28]              | X1 = "SetFunctionState";                
            // 0x01427328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142732C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01427330: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01427334: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427338: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0142733C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01427340: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetFunctionState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_1.GetMethod(name:  "SetFunctionState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01427344: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427348: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x0142734C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427350: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache6;
            val_40 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache6;
            // 0x01427354: CBNZ x22, #0x14273a0       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache6 != null) goto label_52;
            if(val_40 != null)
            {
                goto label_52;
            }
            // 0x01427358: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x0142735C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01427360: LDR x8, [x8, #0xd98]       | X8 = 1152921510100118176;               
            // 0x01427364: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01427368: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0142736C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_20 = null;
            // 0x01427370: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01427374: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427378: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142737C: MOV x2, x22                | X2 = 1152921510100118176 (0x10000001476CAAA0);//ML01
            // 0x01427380: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_35 = val_20;
            // 0x01427384: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01427388: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142738C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427390: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783421488
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache6 = val_35;
            // 0x01427394: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427398: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142739C: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_40 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache6;
            label_52:
            // 0x014273A0: CBNZ x19, #0x14273a8       | if (X1 != 0) goto label_53;             
            if(X1 != 0)
            {
                goto label_53;
            }
            // 0x014273A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ButtonClickState_Binding::SetFunctionState_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_53:
            // 0x014273A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014273AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014273B0: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x014273B4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x014273B8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_40);
            X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_40);
            // 0x014273BC: CBNZ x20, #0x14273c4       | if (val_1 != null) goto label_54;       
            if(val_1 != null)
            {
                goto label_54;
            }
            // 0x014273C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_54:
            // 0x014273C4: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x014273C8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014273CC: LDR x9, [x9, #0x730]       | X9 = (string**)(1152921510100119200)("strNormal");
            // 0x014273D0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014273D4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014273D8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014273DC: LDR x1, [x9]               | X1 = "strNormal";                       
            // 0x014273E0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014273E4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014273E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014273EC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014273F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014273F4: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache7;
            val_41 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache7;
            // 0x014273F8: CBNZ x22, #0x1427444       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache7 != null) goto label_55;
            if(val_41 != null)
            {
                goto label_55;
            }
            // 0x014273FC: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x01427400: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01427404: LDR x8, [x8, #0xc20]       | X8 = 1152921510100119296;               
            // 0x01427408: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0142740C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strNormal_0(ref object o);
            // 0x01427410: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_21 = null;
            // 0x01427414: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142741C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427420: MOV x2, x22                | X2 = 1152921510100119296 (0x10000001476CAF00);//ML01
            // 0x01427424: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_35 = val_21;
            // 0x01427428: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strNormal_0(ref object o));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strNormal_0(ref object o));
            // 0x0142742C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427430: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427434: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421496
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache7 = val_35;
            // 0x01427438: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142743C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427440: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_41 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache7;
            label_55:
            // 0x01427444: CBNZ x19, #0x142744c       | if (X1 != 0) goto label_56;             
            if(X1 != 0)
            {
                goto label_56;
            }
            // 0x01427448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strNormal_0(ref object o)), ????);
            label_56:
            // 0x0142744C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427450: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427454: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01427458: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0142745C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            // 0x01427460: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427464: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427468: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache8;
            val_42 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache8;
            // 0x0142746C: CBNZ x22, #0x14274b8       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache8 != null) goto label_57;
            if(val_42 != null)
            {
                goto label_57;
            }
            // 0x01427470: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x01427474: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01427478: LDR x8, [x8, #0xb48]       | X8 = 1152921510100120320;               
            // 0x0142747C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01427480: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strNormal_0(ref object o, object v);
            // 0x01427484: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_22 = null;
            // 0x01427488: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x0142748C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427490: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427494: MOV x2, x22                | X2 = 1152921510100120320 (0x10000001476CB300);//ML01
            // 0x01427498: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_35 = val_22;
            // 0x0142749C: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strNormal_0(ref object o, object v));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strNormal_0(ref object o, object v));
            // 0x014274A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014274A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014274A8: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421504
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache8 = val_35;
            // 0x014274AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014274B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014274B4: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_42 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache8;
            label_57:
            // 0x014274B8: CBNZ x19, #0x14274c0       | if (X1 != 0) goto label_58;             
            if(X1 != 0)
            {
                goto label_58;
            }
            // 0x014274BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strNormal_0(ref object o, object v)), ????);
            label_58:
            // 0x014274C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014274C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014274C8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014274CC: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014274D0: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_42);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_42);
            // 0x014274D4: CBNZ x20, #0x14274dc       | if (val_1 != null) goto label_59;       
            if(val_1 != null)
            {
                goto label_59;
            }
            // 0x014274D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_59:
            // 0x014274DC: ADRP x9, #0x367b000        | X9 = 57126912 (0x367B000);              
            // 0x014274E0: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014274E4: LDR x9, [x9, #0xf68]       | X9 = (string**)(1152921510100121344)("strPress");
            // 0x014274E8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014274EC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014274F0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014274F4: LDR x1, [x9]               | X1 = "strPress";                        
            // 0x014274F8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014274FC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01427500: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427504: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01427508: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142750C: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache9;
            val_43 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache9;
            // 0x01427510: CBNZ x22, #0x142755c       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache9 != null) goto label_60;
            if(val_43 != null)
            {
                goto label_60;
            }
            // 0x01427514: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x01427518: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0142751C: LDR x8, [x8, #0xd98]       | X8 = 1152921510100121440;               
            // 0x01427520: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01427524: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strPress_1(ref object o);
            // 0x01427528: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_23 = null;
            // 0x0142752C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427534: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427538: MOV x2, x22                | X2 = 1152921510100121440 (0x10000001476CB760);//ML01
            // 0x0142753C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_35 = val_23;
            // 0x01427540: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strPress_1(ref object o));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strPress_1(ref object o));
            // 0x01427544: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427548: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142754C: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421512
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache9 = val_35;
            // 0x01427550: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427554: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427558: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_43 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache9;
            label_60:
            // 0x0142755C: CBNZ x19, #0x1427564       | if (X1 != 0) goto label_61;             
            if(X1 != 0)
            {
                goto label_61;
            }
            // 0x01427560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_strPress_1(ref object o)), ????);
            label_61:
            // 0x01427564: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427568: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142756C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01427570: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01427574: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_43);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_43);
            // 0x01427578: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142757C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427580: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheA;
            val_44 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheA;
            // 0x01427584: CBNZ x22, #0x14275d0       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheA != null) goto label_62;
            if(val_44 != null)
            {
                goto label_62;
            }
            // 0x01427588: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x0142758C: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01427590: LDR x8, [x8, #0xa40]       | X8 = 1152921510100122464;               
            // 0x01427594: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01427598: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strPress_1(ref object o, object v);
            // 0x0142759C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_24 = null;
            // 0x014275A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x014275A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014275A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014275AC: MOV x2, x22                | X2 = 1152921510100122464 (0x10000001476CBB60);//ML01
            // 0x014275B0: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_35 = val_24;
            // 0x014275B4: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strPress_1(ref object o, object v));
            val_24 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strPress_1(ref object o, object v));
            // 0x014275B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014275BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014275C0: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421520
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheA = val_35;
            // 0x014275C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014275C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014275CC: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_44 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheA;
            label_62:
            // 0x014275D0: CBNZ x19, #0x14275d8       | if (X1 != 0) goto label_63;             
            if(X1 != 0)
            {
                goto label_63;
            }
            // 0x014275D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_strPress_1(ref object o, object v)), ????);
            label_63:
            // 0x014275D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014275DC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014275E0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014275E4: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014275E8: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_44);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_44);
            // 0x014275EC: CBNZ x20, #0x14275f4       | if (val_1 != null) goto label_64;       
            if(val_1 != null)
            {
                goto label_64;
            }
            // 0x014275F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_64:
            // 0x014275F4: ADRP x9, #0x35b8000        | X9 = 56328192 (0x35B8000);              
            // 0x014275F8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014275FC: LDR x9, [x9, #0xfc8]       | X9 = (string**)(1152921510100123488)("interval_max_time");
            // 0x01427600: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01427604: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427608: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x0142760C: LDR x1, [x9]               | X1 = "interval_max_time";               
            // 0x01427610: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01427614: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01427618: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142761C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01427620: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427624: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheB;
            val_45 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheB;
            // 0x01427628: CBNZ x22, #0x1427674       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheB != null) goto label_65;
            if(val_45 != null)
            {
                goto label_65;
            }
            // 0x0142762C: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x01427630: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01427634: LDR x8, [x8, #0xc50]       | X8 = 1152921510100123600;               
            // 0x01427638: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0142763C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_max_time_2(ref object o);
            // 0x01427640: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_25 = null;
            // 0x01427644: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142764C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427650: MOV x2, x22                | X2 = 1152921510100123600 (0x10000001476CBFD0);//ML01
            // 0x01427654: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_35 = val_25;
            // 0x01427658: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_max_time_2(ref object o));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_max_time_2(ref object o));
            // 0x0142765C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427660: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427664: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421528
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheB = val_35;
            // 0x01427668: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142766C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427670: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_45 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheB;
            label_65:
            // 0x01427674: CBNZ x19, #0x142767c       | if (X1 != 0) goto label_66;             
            if(X1 != 0)
            {
                goto label_66;
            }
            // 0x01427678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_max_time_2(ref object o)), ????);
            label_66:
            // 0x0142767C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427680: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427684: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01427688: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0142768C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_45);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_45);
            // 0x01427690: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427694: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427698: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheC;
            val_46 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheC;
            // 0x0142769C: CBNZ x22, #0x14276e8       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheC != null) goto label_67;
            if(val_46 != null)
            {
                goto label_67;
            }
            // 0x014276A0: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x014276A4: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x014276A8: LDR x8, [x8, #0x568]       | X8 = 1152921510100124624;               
            // 0x014276AC: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x014276B0: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_max_time_2(ref object o, object v);
            // 0x014276B4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_26 = null;
            // 0x014276B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x014276BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014276C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014276C4: MOV x2, x22                | X2 = 1152921510100124624 (0x10000001476CC3D0);//ML01
            // 0x014276C8: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_35 = val_26;
            // 0x014276CC: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_max_time_2(ref object o, object v));
            val_26 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_max_time_2(ref object o, object v));
            // 0x014276D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014276D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014276D8: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421536
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheC = val_35;
            // 0x014276DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014276E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014276E4: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_46 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheC;
            label_67:
            // 0x014276E8: CBNZ x19, #0x14276f0       | if (X1 != 0) goto label_68;             
            if(X1 != 0)
            {
                goto label_68;
            }
            // 0x014276EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_max_time_2(ref object o, object v)), ????);
            label_68:
            // 0x014276F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014276F4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014276F8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014276FC: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01427700: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_46);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_46);
            // 0x01427704: CBNZ x20, #0x142770c       | if (val_1 != null) goto label_69;       
            if(val_1 != null)
            {
                goto label_69;
            }
            // 0x01427708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_69:
            // 0x0142770C: ADRP x9, #0x35f8000        | X9 = 56590336 (0x35F8000);              
            // 0x01427710: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01427714: LDR x9, [x9, #0x208]       | X9 = (string**)(1152921510100125648)("interval_min_time");
            // 0x01427718: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142771C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427720: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01427724: LDR x1, [x9]               | X1 = "interval_min_time";               
            // 0x01427728: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0142772C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01427730: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427734: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01427738: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142773C: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheD;
            val_47 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheD;
            // 0x01427740: CBNZ x22, #0x142778c       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheD != null) goto label_70;
            if(val_47 != null)
            {
                goto label_70;
            }
            // 0x01427744: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x01427748: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0142774C: LDR x8, [x8, #0x598]       | X8 = 1152921510100125760;               
            // 0x01427750: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01427754: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_min_time_3(ref object o);
            // 0x01427758: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_27 = null;
            // 0x0142775C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427760: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427764: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427768: MOV x2, x22                | X2 = 1152921510100125760 (0x10000001476CC840);//ML01
            // 0x0142776C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_35 = val_27;
            // 0x01427770: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_min_time_3(ref object o));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_min_time_3(ref object o));
            // 0x01427774: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427778: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142777C: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421544
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheD = val_35;
            // 0x01427780: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427784: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427788: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_47 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheD;
            label_70:
            // 0x0142778C: CBNZ x19, #0x1427794       | if (X1 != 0) goto label_71;             
            if(X1 != 0)
            {
                goto label_71;
            }
            // 0x01427790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_interval_min_time_3(ref object o)), ????);
            label_71:
            // 0x01427794: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427798: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142779C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014277A0: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x014277A4: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_47);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_47);
            // 0x014277A8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014277AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014277B0: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheE;
            val_48 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheE;
            // 0x014277B4: CBNZ x22, #0x1427800       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheE != null) goto label_72;
            if(val_48 != null)
            {
                goto label_72;
            }
            // 0x014277B8: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x014277BC: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x014277C0: LDR x8, [x8, #0xb98]       | X8 = 1152921510100126784;               
            // 0x014277C4: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x014277C8: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_min_time_3(ref object o, object v);
            // 0x014277CC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_28 = null;
            // 0x014277D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x014277D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014277D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014277DC: MOV x2, x22                | X2 = 1152921510100126784 (0x10000001476CCC40);//ML01
            // 0x014277E0: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_35 = val_28;
            // 0x014277E4: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_min_time_3(ref object o, object v));
            val_28 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_min_time_3(ref object o, object v));
            // 0x014277E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014277EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014277F0: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421552
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheE = val_35;
            // 0x014277F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014277F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014277FC: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_48 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheE;
            label_72:
            // 0x01427800: CBNZ x19, #0x1427808       | if (X1 != 0) goto label_73;             
            if(X1 != 0)
            {
                goto label_73;
            }
            // 0x01427804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_interval_min_time_3(ref object o, object v)), ????);
            label_73:
            // 0x01427808: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142780C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427810: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01427814: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01427818: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_48);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_48);
            // 0x0142781C: CBNZ x20, #0x1427824       | if (val_1 != null) goto label_74;       
            if(val_1 != null)
            {
                goto label_74;
            }
            // 0x01427820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_74:
            // 0x01427824: ADRP x9, #0x35d0000        | X9 = 56426496 (0x35D0000);              
            // 0x01427828: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0142782C: LDR x9, [x9, #0x310]       | X9 = (string**)(1152921510100127808)("less_speed");
            // 0x01427830: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01427834: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427838: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x0142783C: LDR x1, [x9]               | X1 = "less_speed";                      
            // 0x01427840: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01427844: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01427848: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142784C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01427850: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427854: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheF;
            val_49 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheF;
            // 0x01427858: CBNZ x22, #0x14278a4       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheF != null) goto label_75;
            if(val_49 != null)
            {
                goto label_75;
            }
            // 0x0142785C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x01427860: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01427864: LDR x8, [x8, #0xfe8]       | X8 = 1152921510100127904;               
            // 0x01427868: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0142786C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_less_speed_4(ref object o);
            // 0x01427870: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_29 = null;
            // 0x01427874: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142787C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427880: MOV x2, x22                | X2 = 1152921510100127904 (0x10000001476CD0A0);//ML01
            // 0x01427884: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_35 = val_29;
            // 0x01427888: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_less_speed_4(ref object o));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_less_speed_4(ref object o));
            // 0x0142788C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427890: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427894: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421560
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheF = val_35;
            // 0x01427898: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x0142789C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014278A0: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_49 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cacheF;
            label_75:
            // 0x014278A4: CBNZ x19, #0x14278ac       | if (X1 != 0) goto label_76;             
            if(X1 != 0)
            {
                goto label_76;
            }
            // 0x014278A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_less_speed_4(ref object o)), ????);
            label_76:
            // 0x014278AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014278B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014278B4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014278B8: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x014278BC: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_49);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_49);
            // 0x014278C0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014278C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014278C8: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache10;
            val_50 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache10;
            // 0x014278CC: CBNZ x22, #0x1427918       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache10 != null) goto label_77;
            if(val_50 != null)
            {
                goto label_77;
            }
            // 0x014278D0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014278D4: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x014278D8: LDR x8, [x8, #0x3d0]       | X8 = 1152921510100128928;               
            // 0x014278DC: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x014278E0: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_less_speed_4(ref object o, object v);
            // 0x014278E4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_30 = null;
            // 0x014278E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x014278EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014278F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014278F4: MOV x2, x22                | X2 = 1152921510100128928 (0x10000001476CD4A0);//ML01
            // 0x014278F8: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_35 = val_30;
            // 0x014278FC: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_less_speed_4(ref object o, object v));
            val_30 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_less_speed_4(ref object o, object v));
            // 0x01427900: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427904: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427908: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421568
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache10 = val_35;
            // 0x0142790C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427910: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427914: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_50 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache10;
            label_77:
            // 0x01427918: CBNZ x19, #0x1427920       | if (X1 != 0) goto label_78;             
            if(X1 != 0)
            {
                goto label_78;
            }
            // 0x0142791C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_less_speed_4(ref object o, object v)), ????);
            label_78:
            // 0x01427920: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427924: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427928: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0142792C: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01427930: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_50);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_50);
            // 0x01427934: CBNZ x20, #0x142793c       | if (val_1 != null) goto label_79;       
            if(val_1 != null)
            {
                goto label_79;
            }
            // 0x01427938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_79:
            // 0x0142793C: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x01427940: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01427944: LDR x9, [x9, #0x648]       | X9 = (string**)(1152921510100129952)("UsingSumTime");
            // 0x01427948: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0142794C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427950: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01427954: LDR x1, [x9]               | X1 = "UsingSumTime";                    
            // 0x01427958: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0142795C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01427960: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427964: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01427968: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x0142796C: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache11;
            val_51 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache11;
            // 0x01427970: CBNZ x22, #0x14279bc       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache11 != null) goto label_80;
            if(val_51 != null)
            {
                goto label_80;
            }
            // 0x01427974: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01427978: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0142797C: LDR x8, [x8, #0x360]       | X8 = 1152921510100130048;               
            // 0x01427980: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01427984: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_UsingSumTime_5(ref object o);
            // 0x01427988: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_31 = null;
            // 0x0142798C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427998: MOV x2, x22                | X2 = 1152921510100130048 (0x10000001476CD900);//ML01
            // 0x0142799C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_35 = val_31;
            // 0x014279A0: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_UsingSumTime_5(ref object o));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_UsingSumTime_5(ref object o));
            // 0x014279A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014279A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014279AC: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421576
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache11 = val_35;
            // 0x014279B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014279B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014279B8: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_51 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache11;
            label_80:
            // 0x014279BC: CBNZ x19, #0x14279c4       | if (X1 != 0) goto label_81;             
            if(X1 != 0)
            {
                goto label_81;
            }
            // 0x014279C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_UsingSumTime_5(ref object o)), ????);
            label_81:
            // 0x014279C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014279C8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014279CC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014279D0: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x014279D4: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_51);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_51);
            // 0x014279D8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x014279DC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x014279E0: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache12;
            val_52 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache12;
            // 0x014279E4: CBNZ x22, #0x1427a30       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache12 != null) goto label_82;
            if(val_52 != null)
            {
                goto label_82;
            }
            // 0x014279E8: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x014279EC: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x014279F0: LDR x8, [x8, #0x160]       | X8 = 1152921510100131072;               
            // 0x014279F4: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x014279F8: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_UsingSumTime_5(ref object o, object v);
            // 0x014279FC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_32 = null;
            // 0x01427A00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01427A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427A08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427A0C: MOV x2, x22                | X2 = 1152921510100131072 (0x10000001476CDD00);//ML01
            // 0x01427A10: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_35 = val_32;
            // 0x01427A14: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_UsingSumTime_5(ref object o, object v));
            val_32 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_UsingSumTime_5(ref object o, object v));
            // 0x01427A18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427A1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427A20: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421584
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache12 = val_35;
            // 0x01427A24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427A28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427A2C: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_52 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache12;
            label_82:
            // 0x01427A30: CBNZ x19, #0x1427a38       | if (X1 != 0) goto label_83;             
            if(X1 != 0)
            {
                goto label_83;
            }
            // 0x01427A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_UsingSumTime_5(ref object o, object v)), ????);
            label_83:
            // 0x01427A38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427A3C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427A40: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01427A44: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01427A48: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_52);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_52);
            // 0x01427A4C: CBNZ x20, #0x1427a54       | if (val_1 != null) goto label_84;       
            if(val_1 != null)
            {
                goto label_84;
            }
            // 0x01427A50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_84:
            // 0x01427A54: ADRP x9, #0x363b000        | X9 = 56864768 (0x363B000);              
            // 0x01427A58: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01427A5C: LDR x9, [x9, #0x5f0]       | X9 = (string**)(1152921510100132096)("onClick");
            // 0x01427A60: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01427A64: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01427A68: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01427A6C: LDR x1, [x9]               | X1 = "onClick";                         
            // 0x01427A70: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01427A74: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01427A78: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427A7C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01427A80: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427A84: LDR x21, [x8, #0x98]       | X21 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache13;
            val_53 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache13;
            // 0x01427A88: CBNZ x21, #0x1427ad4       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache13 != null) goto label_85;
            if(val_53 != null)
            {
                goto label_85;
            }
            // 0x01427A8C: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x01427A90: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01427A94: LDR x8, [x8, #0x900]       | X8 = 1152921510100132192;               
            // 0x01427A98: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01427A9C: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_onClick_6(ref object o);
            // 0x01427AA0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33 = null;
            // 0x01427AA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01427AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427AAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427AB0: MOV x2, x21                | X2 = 1152921510100132192 (0x10000001476CE160);//ML01
            // 0x01427AB4: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01427AB8: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_onClick_6(ref object o));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_onClick_6(ref object o));
            // 0x01427ABC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427AC0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427AC4: STR x22, [x8, #0x98]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783421592
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache13 = val_33;
            // 0x01427AC8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427ACC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427AD0: LDR x21, [x8, #0x98]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_53 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache13;
            label_85:
            // 0x01427AD4: CBNZ x19, #0x1427adc       | if (X1 != 0) goto label_86;             
            if(X1 != 0)
            {
                goto label_86;
            }
            // 0x01427AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.ButtonClickState_Binding::get_onClick_6(ref object o)), ????);
            label_86:
            // 0x01427ADC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427AE0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427AE4: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01427AE8: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01427AEC: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_53);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_53);
            // 0x01427AF0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427AF4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427AF8: LDR x21, [x8, #0xa0]       | X21 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache14;
            val_54 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache14;
            // 0x01427AFC: CBNZ x21, #0x1427b48       | if (ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache14 != null) goto label_87;
            if(val_54 != null)
            {
                goto label_87;
            }
            // 0x01427B00: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x01427B04: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01427B08: LDR x8, [x8, #0x8c8]       | X8 = 1152921510100133216;               
            // 0x01427B0C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01427B10: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_onClick_6(ref object o, object v);
            // 0x01427B14: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_34 = null;
            // 0x01427B18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01427B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427B20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427B24: MOV x2, x21                | X2 = 1152921510100133216 (0x10000001476CE560);//ML01
            // 0x01427B28: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01427B2C: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_onClick_6(ref object o, object v));
            val_34 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_onClick_6(ref object o, object v));
            // 0x01427B30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427B34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427B38: STR x22, [x8, #0xa0]       | ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783421600
            ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache14 = val_34;
            // 0x01427B3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.ButtonClickState_Binding);
            // 0x01427B40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.__il2cppRuntimeField_static_fields;
            // 0x01427B44: LDR x21, [x8, #0xa0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_54 = ILRuntime.Runtime.Generated.ButtonClickState_Binding.<>f__mg$cache14;
            label_87:
            // 0x01427B48: CBNZ x19, #0x1427b50       | if (X1 != 0) goto label_88;             
            if(X1 != 0)
            {
                goto label_88;
            }
            // 0x01427B4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.ButtonClickState_Binding::set_onClick_6(ref object o, object v)), ????);
            label_88:
            // 0x01427B50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427B54: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01427B58: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01427B5C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01427B60: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01427B64: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01427B68: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01427B6C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01427B70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427B74: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01427B78: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_54); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_54);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01427B7C (21134204), len: 612  VirtAddr: 0x01427B7C RVA: 0x01427B7C token: 100664090 methodIndex: 30135 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_value_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x01427B7C: STP x26, x25, [sp, #-0x50]! | stack[1152921510100344176] = ???;  stack[1152921510100344184] = ???;  //  dest_result_addr=1152921510100344176 |  dest_result_addr=1152921510100344184
            // 0x01427B80: STP x24, x23, [sp, #0x10]  | stack[1152921510100344192] = ???;  stack[1152921510100344200] = ???;  //  dest_result_addr=1152921510100344192 |  dest_result_addr=1152921510100344200
            // 0x01427B84: STP x22, x21, [sp, #0x20]  | stack[1152921510100344208] = ???;  stack[1152921510100344216] = ???;  //  dest_result_addr=1152921510100344208 |  dest_result_addr=1152921510100344216
            // 0x01427B88: STP x20, x19, [sp, #0x30]  | stack[1152921510100344224] = ???;  stack[1152921510100344232] = ???;  //  dest_result_addr=1152921510100344224 |  dest_result_addr=1152921510100344232
            // 0x01427B8C: STP x29, x30, [sp, #0x40]  | stack[1152921510100344240] = ???;  stack[1152921510100344248] = ???;  //  dest_result_addr=1152921510100344240 |  dest_result_addr=1152921510100344248
            // 0x01427B90: ADD x29, sp, #0x40         | X29 = (1152921510100344176 + 64) = 1152921510100344240 (0x1000000147701DB0);
            // 0x01427B94: SUB sp, sp, #0x10          | SP = (1152921510100344176 - 16) = 1152921510100344160 (0x1000000147701D60);
            // 0x01427B98: ADRP x19, #0x3736000       | X19 = 57892864 (0x3736000);             
            // 0x01427B9C: LDRB w8, [x19, #0xffc]     | W8 = (bool)static_value_03736FFC;       
            // 0x01427BA0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01427BA4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01427BA8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01427BAC: TBNZ w8, #0, #0x1427bc8    | if (static_value_03736FFC == true) goto label_0;
            // 0x01427BB0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01427BB4: LDR x8, [x8, #0xc28]       | X8 = 0x2B8FEB4;                         
            // 0x01427BB8: LDR w0, [x8]               | W0 = 0x1671;                            
            // 0x01427BBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1671, ????);     
            // 0x01427BC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01427BC4: STRB w8, [x19, #0xffc]     | static_value_03736FFC = true;            //  dest_result_addr=57896956
            label_0:
            // 0x01427BC8: CBNZ x20, #0x1427bd0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01427BCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1671, ????);     
            label_1:
            // 0x01427BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427BD4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01427BD8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01427BDC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01427BE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427BE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427BE8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01427BEC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01427BF0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01427BF4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01427BF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427BFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427C00: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01427C04: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01427C08: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01427C0C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01427C10: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01427C14: ADRP x9, #0x35bf000        | X9 = 56356864 (0x35BF000);              
            // 0x01427C18: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x01427C1C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01427C20: LDR x9, [x9, #0x620]       | X9 = 1152921504925163520;               
            // 0x01427C24: LDR x24, [x9]              | X24 = typeof(ButtonClickState);         
            // 0x01427C28: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01427C2C: TBZ w9, #0, #0x1427c40     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01427C30: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01427C34: CBNZ w9, #0x1427c40        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01427C38: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01427C3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01427C40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427C44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01427C48: MOV x1, x24                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x01427C4C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01427C50: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x01427C54: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x01427C58: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01427C5C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01427C60: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01427C64: TBZ w9, #0, #0x1427c78     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01427C68: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01427C6C: CBNZ w9, #0x1427c78        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01427C70: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01427C74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01427C78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427C7C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01427C80: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01427C84: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01427C88: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01427C8C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01427C90: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01427C94: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01427C98: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01427C9C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01427CA0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01427CA4: TBZ w9, #0, #0x1427cb8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01427CA8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01427CAC: CBNZ w9, #0x1427cb8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01427CB0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01427CB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01427CB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427CBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427CC0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01427CC4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x01427CC8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01427CCC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x01427CD0: CBZ x0, #0x1427d34         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01427CD4: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x01427CD8: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x01427CDC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01427CE0: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x01427CE4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01427CE8: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01427CEC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01427CF0: B.LO #0x1427d0c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01427CF4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01427CF8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x01427CFC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01427D00: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01427D04: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x01427D08: B.EQ #0x1427d34            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x01427D0C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01427D10: ADD x8, sp, #8             | X8 = (1152921510100344160 + 8) = 1152921510100344168 (0x1000000147701D68);
            // 0x01427D14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01427D18: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510100332256]
            // 0x01427D1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01427D20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427D24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01427D28: ADD x0, sp, #8             | X0 = (1152921510100344160 + 8) = 1152921510100344168 (0x1000000147701D68);
            // 0x01427D2C: BL #0x299a140              | 
            // 0x01427D30: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x01427D34: CBNZ x20, #0x1427d3c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01427D38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147701D68, ????);
            label_11:
            // 0x01427D3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01427D40: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01427D44: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01427D48: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01427D4C: CBNZ x22, #0x1427d54       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x01427D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x01427D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427D58: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01427D5C: BL #0xba259c               | X0 = val_13.get_value();                
            bool val_9 = val_13.value;
            // 0x01427D60: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x01427D64: CBZ x19, #0x1427d78        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x01427D68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01427D6C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01427D70: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01427D74: B #0x1427d8c               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x01427D78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x01427D7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01427D80: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x01427D84: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x01427D88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x01427D8C: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x01427D90: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01427D94: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x01427D98: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x01427D9C: TBZ w9, #0, #0x1427dac     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x01427DA0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x01427DA4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x01427DA8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x01427DAC: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x01427DB0: SUB sp, x29, #0x40         | SP = (1152921510100344240 - 64) = 1152921510100344176 (0x1000000147701D70);
            // 0x01427DB4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01427DB8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01427DBC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01427DC0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01427DC4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01427DC8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01427DCC: MOV x19, x0                | 
            // 0x01427DD0: ADD x0, sp, #8             | 
            // 0x01427DD4: BL #0x299a140              | 
            // 0x01427DD8: MOV x0, x19                | 
            // 0x01427DDC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01427DE0 (21134816), len: 580  VirtAddr: 0x01427DE0 RVA: 0x01427DE0 token: 100664091 methodIndex: 30136 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_value_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            // 0x01427DE0: STP x26, x25, [sp, #-0x50]! | stack[1152921510100513520] = ???;  stack[1152921510100513528] = ???;  //  dest_result_addr=1152921510100513520 |  dest_result_addr=1152921510100513528
            // 0x01427DE4: STP x24, x23, [sp, #0x10]  | stack[1152921510100513536] = ???;  stack[1152921510100513544] = ???;  //  dest_result_addr=1152921510100513536 |  dest_result_addr=1152921510100513544
            // 0x01427DE8: STP x22, x21, [sp, #0x20]  | stack[1152921510100513552] = ???;  stack[1152921510100513560] = ???;  //  dest_result_addr=1152921510100513552 |  dest_result_addr=1152921510100513560
            // 0x01427DEC: STP x20, x19, [sp, #0x30]  | stack[1152921510100513568] = ???;  stack[1152921510100513576] = ???;  //  dest_result_addr=1152921510100513568 |  dest_result_addr=1152921510100513576
            // 0x01427DF0: STP x29, x30, [sp, #0x40]  | stack[1152921510100513584] = ???;  stack[1152921510100513592] = ???;  //  dest_result_addr=1152921510100513584 |  dest_result_addr=1152921510100513592
            // 0x01427DF4: ADD x29, sp, #0x40         | X29 = (1152921510100513520 + 64) = 1152921510100513584 (0x100000014772B330);
            // 0x01427DF8: SUB sp, sp, #0x10          | SP = (1152921510100513520 - 16) = 1152921510100513504 (0x100000014772B2E0);
            // 0x01427DFC: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x01427E00: LDRB w8, [x20, #0xffd]     | W8 = (bool)static_value_03736FFD;       
            // 0x01427E04: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01427E08: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01427E0C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01427E10: TBNZ w8, #0, #0x1427e2c    | if (static_value_03736FFD == true) goto label_0;
            // 0x01427E14: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x01427E18: LDR x8, [x8, #0x508]       | X8 = 0x2B8FEE4;                         
            // 0x01427E1C: LDR w0, [x8]               | W0 = 0x167D;                            
            // 0x01427E20: BL #0x2782188              | X0 = sub_2782188( ?? 0x167D, ????);     
            // 0x01427E24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01427E28: STRB w8, [x20, #0xffd]     | static_value_03736FFD = true;            //  dest_result_addr=57896957
            label_0:
            // 0x01427E2C: CBNZ x19, #0x1427e34       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01427E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167D, ????);     
            label_1:
            // 0x01427E34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427E38: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427E3C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01427E40: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01427E44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427E48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427E4C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01427E50: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01427E54: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01427E58: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01427E5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427E60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427E64: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01427E68: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01427E6C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01427E70: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x01427E74: CBNZ x24, #0x1427e7c       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01427E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01427E7C: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x01427E80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427E84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427E88: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01427E8C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01427E90: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01427E94: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01427E98: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01427E9C: ADRP x9, #0x35bf000        | X9 = 56356864 (0x35BF000);              
            // 0x01427EA0: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x01427EA4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01427EA8: LDR x9, [x9, #0x620]       | X9 = 1152921504925163520;               
            // 0x01427EAC: LDR x24, [x9]              | X24 = typeof(ButtonClickState);         
            // 0x01427EB0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01427EB4: TBZ w9, #0, #0x1427ec8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01427EB8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01427EBC: CBNZ w9, #0x1427ec8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01427EC0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01427EC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01427EC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427ECC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01427ED0: MOV x1, x24                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x01427ED4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01427ED8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01427EDC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01427EE0: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x01427EE4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01427EE8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01427EEC: TBZ w9, #0, #0x1427f00     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01427EF0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01427EF4: CBNZ w9, #0x1427f00        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01427EF8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01427EFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x01427F00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427F04: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01427F08: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01427F0C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01427F10: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01427F14: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01427F18: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01427F1C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01427F20: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x01427F24: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01427F28: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01427F2C: TBZ w9, #0, #0x1427f40     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01427F30: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01427F34: CBNZ w9, #0x1427f40        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01427F38: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01427F3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x01427F40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01427F44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01427F48: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x01427F4C: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x01427F50: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x01427F54: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x01427F58: CBZ x0, #0x1427fbc         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x01427F5C: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x01427F60: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x01427F64: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01427F68: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x01427F6C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01427F70: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01427F74: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01427F78: B.LO #0x1427f94            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x01427F7C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01427F80: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x01427F84: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01427F88: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01427F8C: MOV x22, x0                | X22 = val_7;//m1                        
            val_11 = val_7;
            // 0x01427F90: B.EQ #0x1427fbc            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x01427F94: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01427F98: ADD x8, sp, #8             | X8 = (1152921510100513504 + 8) = 1152921510100513512 (0x100000014772B2E8);
            // 0x01427F9C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01427FA0: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510100501600]
            // 0x01427FA4: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x01427FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01427FAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x01427FB0: ADD x0, sp, #8             | X0 = (1152921510100513504 + 8) = 1152921510100513512 (0x100000014772B2E8);
            // 0x01427FB4: BL #0x299a140              | 
            // 0x01427FB8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_11:
            // 0x01427FBC: CBNZ x19, #0x1427fc4       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01427FC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014772B2E8, ????);
            label_12:
            // 0x01427FC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01427FC8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01427FCC: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01427FD0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01427FD4: CBNZ x22, #0x1427fdc       | if (0x0 != 0) goto label_13;            
            if(val_11 != 0)
            {
                goto label_13;
            }
            // 0x01427FD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01427FDC: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x01427FE0: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x01427FE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01427FE8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01427FEC: BL #0xba25a4               | val_11.set_value(value:  bool val_10 = ((val_3 + 4) == 1) ? 1 : 0);
            val_11.value = val_10;
            // 0x01427FF0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01427FF4: SUB sp, x29, #0x40         | SP = (1152921510100513584 - 64) = 1152921510100513520 (0x100000014772B2F0);
            // 0x01427FF8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01427FFC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01428000: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01428004: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01428008: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142800C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01428010: MOV x19, x0                | 
            // 0x01428014: ADD x0, sp, #8             | 
            // 0x01428018: BL #0x299a140              | 
            // 0x0142801C: MOV x0, x19                | 
            // 0x01428020: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01428024 (21135396), len: 528  VirtAddr: 0x01428024 RVA: 0x01428024 token: 100664092 methodIndex: 30137 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnClick_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x01428024: STP x24, x23, [sp, #-0x40]! | stack[1152921510100682880] = ???;  stack[1152921510100682888] = ???;  //  dest_result_addr=1152921510100682880 |  dest_result_addr=1152921510100682888
            // 0x01428028: STP x22, x21, [sp, #0x10]  | stack[1152921510100682896] = ???;  stack[1152921510100682904] = ???;  //  dest_result_addr=1152921510100682896 |  dest_result_addr=1152921510100682904
            // 0x0142802C: STP x20, x19, [sp, #0x20]  | stack[1152921510100682912] = ???;  stack[1152921510100682920] = ???;  //  dest_result_addr=1152921510100682912 |  dest_result_addr=1152921510100682920
            // 0x01428030: STP x29, x30, [sp, #0x30]  | stack[1152921510100682928] = ???;  stack[1152921510100682936] = ???;  //  dest_result_addr=1152921510100682928 |  dest_result_addr=1152921510100682936
            // 0x01428034: ADD x29, sp, #0x30         | X29 = (1152921510100682880 + 48) = 1152921510100682928 (0x10000001477548B0);
            // 0x01428038: SUB sp, sp, #0x10          | SP = (1152921510100682880 - 16) = 1152921510100682864 (0x1000000147754870);
            // 0x0142803C: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x01428040: LDRB w8, [x20, #0xffe]     | W8 = (bool)static_value_03736FFE;       
            // 0x01428044: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01428048: MOV x21, x2                | X21 = X2;//m1                           
            // 0x0142804C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01428050: TBNZ w8, #0, #0x142806c    | if (static_value_03736FFE == true) goto label_0;
            // 0x01428054: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x01428058: LDR x8, [x8, #0x778]       | X8 = 0x2B8FEB8;                         
            // 0x0142805C: LDR w0, [x8]               | W0 = 0x1672;                            
            // 0x01428060: BL #0x2782188              | X0 = sub_2782188( ?? 0x1672, ????);     
            // 0x01428064: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01428068: STRB w8, [x20, #0xffe]     | static_value_03736FFE = true;            //  dest_result_addr=57896958
            label_0:
            // 0x0142806C: CBNZ x19, #0x1428074       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01428070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1672, ????);     
            label_1:
            // 0x01428074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428078: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0142807C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01428080: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01428084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428088: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142808C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01428090: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01428094: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01428098: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0142809C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014280A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014280A4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014280A8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014280AC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014280B0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x014280B4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014280B8: ADRP x9, #0x35bf000        | X9 = 56356864 (0x35BF000);              
            // 0x014280BC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x014280C0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014280C4: LDR x9, [x9, #0x620]       | X9 = 1152921504925163520;               
            // 0x014280C8: LDR x24, [x9]              | X24 = typeof(ButtonClickState);         
            // 0x014280CC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x014280D0: TBZ w9, #0, #0x14280e4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x014280D4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x014280D8: CBNZ w9, #0x14280e4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x014280DC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x014280E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x014280E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014280E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014280EC: MOV x1, x24                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x014280F0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014280F4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x014280F8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x014280FC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01428100: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01428104: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01428108: TBZ w9, #0, #0x142811c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0142810C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01428110: CBNZ w9, #0x142811c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01428114: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01428118: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0142811C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428120: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01428124: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x01428128: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0142812C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01428130: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01428134: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01428138: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0142813C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01428140: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01428144: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01428148: TBZ w9, #0, #0x142815c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0142814C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01428150: CBNZ w9, #0x142815c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01428154: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01428158: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0142815C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428160: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428164: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01428168: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x0142816C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01428170: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x01428174: CBZ x0, #0x14281d8         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x01428178: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x0142817C: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x01428180: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01428184: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x01428188: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142818C: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428190: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428194: B.LO #0x14281b0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x01428198: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0142819C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x014281A0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014281A4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014281A8: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x014281AC: B.EQ #0x14281d8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x014281B0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014281B4: ADD x8, sp, #8             | X8 = (1152921510100682864 + 8) = 1152921510100682872 (0x1000000147754878);
            // 0x014281B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014281BC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510100670944]
            // 0x014281C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x014281C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014281C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x014281CC: ADD x0, sp, #8             | X0 = (1152921510100682864 + 8) = 1152921510100682872 (0x1000000147754878);
            // 0x014281D0: BL #0x299a140              | 
            // 0x014281D4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x014281D8: CBNZ x19, #0x14281e0       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x014281DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147754878, ????);
            label_11:
            // 0x014281E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014281E4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014281E8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x014281EC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x014281F0: CBNZ x22, #0x14281f8       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x014281F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x014281F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014281FC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01428200: BL #0xba2738               | val_9.OnClick();                        
            val_9.OnClick();
            // 0x01428204: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01428208: SUB sp, x29, #0x30         | SP = (1152921510100682928 - 48) = 1152921510100682880 (0x1000000147754880);
            // 0x0142820C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01428210: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01428214: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01428218: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0142821C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01428220: MOV x19, x0                | 
            // 0x01428224: ADD x0, sp, #8             | 
            // 0x01428228: BL #0x299a140              | 
            // 0x0142822C: MOV x0, x19                | 
            // 0x01428230: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01428234 (21135924), len: 580  VirtAddr: 0x01428234 RVA: 0x01428234 token: 100664093 methodIndex: 30138 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnPress_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            // 0x01428234: STP x26, x25, [sp, #-0x50]! | stack[1152921510100852208] = ???;  stack[1152921510100852216] = ???;  //  dest_result_addr=1152921510100852208 |  dest_result_addr=1152921510100852216
            // 0x01428238: STP x24, x23, [sp, #0x10]  | stack[1152921510100852224] = ???;  stack[1152921510100852232] = ???;  //  dest_result_addr=1152921510100852224 |  dest_result_addr=1152921510100852232
            // 0x0142823C: STP x22, x21, [sp, #0x20]  | stack[1152921510100852240] = ???;  stack[1152921510100852248] = ???;  //  dest_result_addr=1152921510100852240 |  dest_result_addr=1152921510100852248
            // 0x01428240: STP x20, x19, [sp, #0x30]  | stack[1152921510100852256] = ???;  stack[1152921510100852264] = ???;  //  dest_result_addr=1152921510100852256 |  dest_result_addr=1152921510100852264
            // 0x01428244: STP x29, x30, [sp, #0x40]  | stack[1152921510100852272] = ???;  stack[1152921510100852280] = ???;  //  dest_result_addr=1152921510100852272 |  dest_result_addr=1152921510100852280
            // 0x01428248: ADD x29, sp, #0x40         | X29 = (1152921510100852208 + 64) = 1152921510100852272 (0x100000014777DE30);
            // 0x0142824C: SUB sp, sp, #0x10          | SP = (1152921510100852208 - 16) = 1152921510100852192 (0x100000014777DDE0);
            // 0x01428250: ADRP x20, #0x3736000       | X20 = 57892864 (0x3736000);             
            // 0x01428254: LDRB w8, [x20, #0xfff]     | W8 = (bool)static_value_03736FFF;       
            // 0x01428258: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0142825C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01428260: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01428264: TBNZ w8, #0, #0x1428280    | if (static_value_03736FFF == true) goto label_0;
            // 0x01428268: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x0142826C: LDR x8, [x8, #0x10]        | X8 = 0x2B8FEC0;                         
            // 0x01428270: LDR w0, [x8]               | W0 = 0x1674;                            
            // 0x01428274: BL #0x2782188              | X0 = sub_2782188( ?? 0x1674, ????);     
            // 0x01428278: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142827C: STRB w8, [x20, #0xfff]     | static_value_03736FFF = true;            //  dest_result_addr=57896959
            label_0:
            // 0x01428280: CBNZ x19, #0x1428288       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01428284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1674, ????);     
            label_1:
            // 0x01428288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142828C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428290: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01428294: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01428298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142829C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014282A0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014282A4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014282A8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014282AC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x014282B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014282B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014282B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014282BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014282C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014282C4: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x014282C8: CBNZ x24, #0x14282d0       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x014282CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x014282D0: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x014282D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014282D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014282DC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014282E0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014282E4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014282E8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x014282EC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x014282F0: ADRP x9, #0x35bf000        | X9 = 56356864 (0x35BF000);              
            // 0x014282F4: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x014282F8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x014282FC: LDR x9, [x9, #0x620]       | X9 = 1152921504925163520;               
            // 0x01428300: LDR x24, [x9]              | X24 = typeof(ButtonClickState);         
            // 0x01428304: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01428308: TBZ w9, #0, #0x142831c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0142830C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01428310: CBNZ w9, #0x142831c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01428314: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01428318: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x0142831C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428324: MOV x1, x24                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x01428328: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0142832C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01428330: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01428334: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x01428338: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0142833C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01428340: TBZ w9, #0, #0x1428354     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01428344: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01428348: CBNZ w9, #0x1428354        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0142834C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01428350: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x01428354: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428358: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0142835C: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01428360: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01428364: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01428368: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0142836C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01428370: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01428374: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x01428378: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0142837C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01428380: TBZ w9, #0, #0x1428394     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01428384: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01428388: CBNZ w9, #0x1428394        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0142838C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01428390: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x01428394: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428398: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0142839C: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x014283A0: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x014283A4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x014283A8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x014283AC: CBZ x0, #0x1428410         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x014283B0: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x014283B4: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x014283B8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x014283BC: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x014283C0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014283C4: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014283C8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014283CC: B.LO #0x14283e8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x014283D0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014283D4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x014283D8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014283DC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014283E0: MOV x22, x0                | X22 = val_7;//m1                        
            val_11 = val_7;
            // 0x014283E4: B.EQ #0x1428410            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x014283E8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014283EC: ADD x8, sp, #8             | X8 = (1152921510100852192 + 8) = 1152921510100852200 (0x100000014777DDE8);
            // 0x014283F0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014283F4: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510100840288]
            // 0x014283F8: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x014283FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428400: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x01428404: ADD x0, sp, #8             | X0 = (1152921510100852192 + 8) = 1152921510100852200 (0x100000014777DDE8);
            // 0x01428408: BL #0x299a140              | 
            // 0x0142840C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_11:
            // 0x01428410: CBNZ x19, #0x1428418       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01428414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014777DDE8, ????);
            label_12:
            // 0x01428418: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142841C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428420: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01428424: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01428428: CBNZ x22, #0x1428430       | if (0x0 != 0) goto label_13;            
            if(val_11 != 0)
            {
                goto label_13;
            }
            // 0x0142842C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01428430: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x01428434: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x01428438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142843C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01428440: BL #0xba2b58               | val_11.OnPress(ispress:  bool val_10 = ((val_3 + 4) == 1) ? 1 : 0);
            val_11.OnPress(ispress:  val_10);
            // 0x01428444: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01428448: SUB sp, x29, #0x40         | SP = (1152921510100852272 - 64) = 1152921510100852208 (0x100000014777DDF0);
            // 0x0142844C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01428450: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01428454: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01428458: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0142845C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01428460: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01428464: MOV x19, x0                | 
            // 0x01428468: ADD x0, sp, #8             | 
            // 0x0142846C: BL #0x299a140              | 
            // 0x01428470: MOV x0, x19                | 
            // 0x01428474: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01428478 (21136504), len: 580  VirtAddr: 0x01428478 RVA: 0x01428478 token: 100664094 methodIndex: 30139 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnHover_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            // 0x01428478: STP x26, x25, [sp, #-0x50]! | stack[1152921510101021552] = ???;  stack[1152921510101021560] = ???;  //  dest_result_addr=1152921510101021552 |  dest_result_addr=1152921510101021560
            // 0x0142847C: STP x24, x23, [sp, #0x10]  | stack[1152921510101021568] = ???;  stack[1152921510101021576] = ???;  //  dest_result_addr=1152921510101021568 |  dest_result_addr=1152921510101021576
            // 0x01428480: STP x22, x21, [sp, #0x20]  | stack[1152921510101021584] = ???;  stack[1152921510101021592] = ???;  //  dest_result_addr=1152921510101021584 |  dest_result_addr=1152921510101021592
            // 0x01428484: STP x20, x19, [sp, #0x30]  | stack[1152921510101021600] = ???;  stack[1152921510101021608] = ???;  //  dest_result_addr=1152921510101021600 |  dest_result_addr=1152921510101021608
            // 0x01428488: STP x29, x30, [sp, #0x40]  | stack[1152921510101021616] = ???;  stack[1152921510101021624] = ???;  //  dest_result_addr=1152921510101021616 |  dest_result_addr=1152921510101021624
            // 0x0142848C: ADD x29, sp, #0x40         | X29 = (1152921510101021552 + 64) = 1152921510101021616 (0x10000001477A73B0);
            // 0x01428490: SUB sp, sp, #0x10          | SP = (1152921510101021552 - 16) = 1152921510101021536 (0x10000001477A7360);
            // 0x01428494: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01428498: LDRB w8, [x20]             | W8 = (bool)static_value_03737000;       
            // 0x0142849C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x014284A0: MOV x21, x2                | X21 = X2;//m1                           
            // 0x014284A4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014284A8: TBNZ w8, #0, #0x14284c4    | if (static_value_03737000 == true) goto label_0;
            // 0x014284AC: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x014284B0: LDR x8, [x8, #0x5c0]       | X8 = 0x2B8FEBC;                         
            // 0x014284B4: LDR w0, [x8]               | W0 = 0x1673;                            
            // 0x014284B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1673, ????);     
            // 0x014284BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014284C0: STRB w8, [x20]             | static_value_03737000 = true;            //  dest_result_addr=57896960
            label_0:
            // 0x014284C4: CBNZ x19, #0x14284cc       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014284C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1673, ????);     
            label_1:
            // 0x014284CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014284D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014284D4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014284D8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014284DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014284E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014284E4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014284E8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014284EC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014284F0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x014284F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014284F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014284FC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01428500: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01428504: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01428508: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0142850C: CBNZ x24, #0x1428514       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x01428510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x01428514: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x01428518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142851C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428520: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01428524: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01428528: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142852C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01428530: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01428534: ADRP x9, #0x35bf000        | X9 = 56356864 (0x35BF000);              
            // 0x01428538: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x0142853C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01428540: LDR x9, [x9, #0x620]       | X9 = 1152921504925163520;               
            // 0x01428544: LDR x24, [x9]              | X24 = typeof(ButtonClickState);         
            // 0x01428548: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142854C: TBZ w9, #0, #0x1428560     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01428550: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01428554: CBNZ w9, #0x1428560        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01428558: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142855C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01428560: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428564: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428568: MOV x1, x24                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x0142856C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01428570: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01428574: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01428578: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x0142857C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01428580: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01428584: TBZ w9, #0, #0x1428598     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01428588: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0142858C: CBNZ w9, #0x1428598        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01428590: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01428594: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x01428598: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142859C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014285A0: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x014285A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014285A8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x014285AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014285B0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014285B4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014285B8: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x014285BC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014285C0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014285C4: TBZ w9, #0, #0x14285d8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x014285C8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014285CC: CBNZ w9, #0x14285d8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x014285D0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014285D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x014285D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014285DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014285E0: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x014285E4: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x014285E8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x014285EC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x014285F0: CBZ x0, #0x1428654         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x014285F4: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x014285F8: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x014285FC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01428600: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x01428604: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428608: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142860C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428610: B.LO #0x142862c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x01428614: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01428618: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x0142861C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428620: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428624: MOV x22, x0                | X22 = val_7;//m1                        
            val_11 = val_7;
            // 0x01428628: B.EQ #0x1428654            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x0142862C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01428630: ADD x8, sp, #8             | X8 = (1152921510101021536 + 8) = 1152921510101021544 (0x10000001477A7368);
            // 0x01428634: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01428638: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510101009632]
            // 0x0142863C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x01428640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428644: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x01428648: ADD x0, sp, #8             | X0 = (1152921510101021536 + 8) = 1152921510101021544 (0x10000001477A7368);
            // 0x0142864C: BL #0x299a140              | 
            // 0x01428650: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_11:
            // 0x01428654: CBNZ x19, #0x142865c       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01428658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001477A7368, ????);
            label_12:
            // 0x0142865C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428660: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428664: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01428668: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0142866C: CBNZ x22, #0x1428674       | if (0x0 != 0) goto label_13;            
            if(val_11 != 0)
            {
                goto label_13;
            }
            // 0x01428670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01428674: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x01428678: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x0142867C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428680: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01428684: BL #0xba2b6c               | val_11.OnHover(ishover:  bool val_10 = ((val_3 + 4) == 1) ? 1 : 0);
            val_11.OnHover(ishover:  val_10);
            // 0x01428688: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0142868C: SUB sp, x29, #0x40         | SP = (1152921510101021616 - 64) = 1152921510101021552 (0x10000001477A7370);
            // 0x01428690: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01428694: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01428698: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0142869C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x014286A0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x014286A4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x014286A8: MOV x19, x0                | 
            // 0x014286AC: ADD x0, sp, #8             | 
            // 0x014286B0: BL #0x299a140              | 
            // 0x014286B4: MOV x0, x19                | 
            // 0x014286B8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014286BC (21137084), len: 664  VirtAddr: 0x014286BC RVA: 0x014286BC token: 100664095 methodIndex: 30140 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetFunctionState_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x014286BC: STP x26, x25, [sp, #-0x50]! | stack[1152921510101203184] = ???;  stack[1152921510101203192] = ???;  //  dest_result_addr=1152921510101203184 |  dest_result_addr=1152921510101203192
            // 0x014286C0: STP x24, x23, [sp, #0x10]  | stack[1152921510101203200] = ???;  stack[1152921510101203208] = ???;  //  dest_result_addr=1152921510101203200 |  dest_result_addr=1152921510101203208
            // 0x014286C4: STP x22, x21, [sp, #0x20]  | stack[1152921510101203216] = ???;  stack[1152921510101203224] = ???;  //  dest_result_addr=1152921510101203216 |  dest_result_addr=1152921510101203224
            // 0x014286C8: STP x20, x19, [sp, #0x30]  | stack[1152921510101203232] = ???;  stack[1152921510101203240] = ???;  //  dest_result_addr=1152921510101203232 |  dest_result_addr=1152921510101203240
            // 0x014286CC: STP x29, x30, [sp, #0x40]  | stack[1152921510101203248] = ???;  stack[1152921510101203256] = ???;  //  dest_result_addr=1152921510101203248 |  dest_result_addr=1152921510101203256
            // 0x014286D0: ADD x29, sp, #0x40         | X29 = (1152921510101203184 + 64) = 1152921510101203248 (0x10000001477D3930);
            // 0x014286D4: SUB sp, sp, #0x10          | SP = (1152921510101203184 - 16) = 1152921510101203168 (0x10000001477D38E0);
            // 0x014286D8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014286DC: LDRB w8, [x20, #1]         | W8 = (bool)static_value_03737001;       
            // 0x014286E0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x014286E4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x014286E8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014286EC: TBNZ w8, #0, #0x1428708    | if (static_value_03737001 == true) goto label_0;
            // 0x014286F0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x014286F4: LDR x8, [x8, #0xb8]        | X8 = 0x2B8FEE8;                         
            // 0x014286F8: LDR w0, [x8]               | W0 = 0x167E;                            
            // 0x014286FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x167E, ????);     
            // 0x01428700: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01428704: STRB w8, [x20, #1]         | static_value_03737001 = true;            //  dest_result_addr=57896961
            label_0:
            // 0x01428708: CBNZ x19, #0x1428710       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0142870C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167E, ????);     
            label_1:
            // 0x01428710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428714: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428718: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0142871C: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x01428720: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428724: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428728: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0142872C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01428730: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01428734: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01428738: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142873C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428740: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01428744: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01428748: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142874C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01428750: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01428754: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x01428758: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0142875C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01428760: LDR x9, [x9, #0xa88]       | X9 = 1152921504606900224;               
            // 0x01428764: LDR x23, [x9]              | X23 = typeof(System.Object);            
            // 0x01428768: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0142876C: TBZ w9, #0, #0x1428780     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01428770: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01428774: CBNZ w9, #0x1428780        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01428778: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0142877C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01428780: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428784: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428788: MOV x1, x23                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x0142878C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01428790: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01428794: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01428798: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x0142879C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014287A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x014287A4: TBZ w9, #0, #0x14287b8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014287A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x014287AC: CBNZ w9, #0x14287b8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014287B0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014287B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x014287B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014287BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014287C0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x014287C4: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x014287C8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x014287CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014287D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014287D4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014287D8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x014287DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014287E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014287E4: TBZ w9, #0, #0x14287f8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014287E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014287EC: CBNZ w9, #0x14287f8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014287F0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014287F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014287F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014287FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428800: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x01428804: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01428808: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0142880C: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x01428810: CBNZ x19, #0x1428818       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x01428814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x01428818: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0142881C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428820: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01428824: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01428828: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142882C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428830: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01428834: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01428838: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0142883C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01428840: LDR x8, [x8, #0x620]       | X8 = 1152921504925163520;               
            // 0x01428844: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x01428848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142884C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428850: LDR x1, [x8]               | X1 = typeof(ButtonClickState);          
            // 0x01428854: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01428858: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x0142885C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428860: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01428864: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x01428868: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x0142886C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x01428870: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01428874: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x01428878: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0142887C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428880: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x01428884: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x01428888: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0142888C: CBZ x0, #0x14288f0         | if (val_10 == null) goto label_11;      
            if(val_10 == null)
            {
                goto label_11;
            }
            // 0x01428890: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x01428894: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x01428898: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0142889C: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x014288A0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014288A4: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014288A8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014288AC: B.LO #0x14288c8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x014288B0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x014288B4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x014288B8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014288BC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014288C0: MOV x21, x0                | X21 = val_10;//m1                       
            val_13 = val_10;
            // 0x014288C4: B.EQ #0x14288f0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x014288C8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x014288CC: ADD x8, sp, #8             | X8 = (1152921510101203168 + 8) = 1152921510101203176 (0x10000001477D38E8);
            // 0x014288D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x014288D4: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510101191264]
            // 0x014288D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x014288DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014288E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x014288E4: ADD x0, sp, #8             | X0 = (1152921510101203168 + 8) = 1152921510101203176 (0x10000001477D38E8);
            // 0x014288E8: BL #0x299a140              | 
            // 0x014288EC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_11:
            // 0x014288F0: CBNZ x19, #0x14288f8       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x014288F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001477D38E8, ????);
            label_12:
            // 0x014288F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014288FC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428900: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x01428904: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01428908: CBNZ x21, #0x1428910       | if (0x0 != 0) goto label_13;            
            if(val_13 != 0)
            {
                goto label_13;
            }
            // 0x0142890C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01428910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428914: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01428918: MOV x1, x23                | X1 = val_6;//m1                         
            // 0x0142891C: BL #0xba2cd8               | val_13.SetFunctionState(isactive:  val_6);
            val_13.SetFunctionState(isactive:  val_6);
            // 0x01428920: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01428924: SUB sp, x29, #0x40         | SP = (1152921510101203248 - 64) = 1152921510101203184 (0x10000001477D38F0);
            // 0x01428928: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0142892C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01428930: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01428934: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01428938: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0142893C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01428940: MOV x19, x0                | 
            // 0x01428944: ADD x0, sp, #8             | 
            // 0x01428948: BL #0x299a140              | 
            // 0x0142894C: MOV x0, x19                | 
            // 0x01428950: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01428954 (21137748), len: 580  VirtAddr: 0x01428954 RVA: 0x01428954 token: 100664096 methodIndex: 30141 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetFunctionState_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            // 0x01428954: STP x26, x25, [sp, #-0x50]! | stack[1152921510101384816] = ???;  stack[1152921510101384824] = ???;  //  dest_result_addr=1152921510101384816 |  dest_result_addr=1152921510101384824
            // 0x01428958: STP x24, x23, [sp, #0x10]  | stack[1152921510101384832] = ???;  stack[1152921510101384840] = ???;  //  dest_result_addr=1152921510101384832 |  dest_result_addr=1152921510101384840
            // 0x0142895C: STP x22, x21, [sp, #0x20]  | stack[1152921510101384848] = ???;  stack[1152921510101384856] = ???;  //  dest_result_addr=1152921510101384848 |  dest_result_addr=1152921510101384856
            // 0x01428960: STP x20, x19, [sp, #0x30]  | stack[1152921510101384864] = ???;  stack[1152921510101384872] = ???;  //  dest_result_addr=1152921510101384864 |  dest_result_addr=1152921510101384872
            // 0x01428964: STP x29, x30, [sp, #0x40]  | stack[1152921510101384880] = ???;  stack[1152921510101384888] = ???;  //  dest_result_addr=1152921510101384880 |  dest_result_addr=1152921510101384888
            // 0x01428968: ADD x29, sp, #0x40         | X29 = (1152921510101384816 + 64) = 1152921510101384880 (0x10000001477FFEB0);
            // 0x0142896C: SUB sp, sp, #0x10          | SP = (1152921510101384816 - 16) = 1152921510101384800 (0x10000001477FFE60);
            // 0x01428970: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01428974: LDRB w8, [x20, #2]         | W8 = (bool)static_value_03737002;       
            // 0x01428978: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0142897C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x01428980: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01428984: TBNZ w8, #0, #0x14289a0    | if (static_value_03737002 == true) goto label_0;
            // 0x01428988: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x0142898C: LDR x8, [x8, #0xf70]       | X8 = 0x2B8FEEC;                         
            // 0x01428990: LDR w0, [x8]               | W0 = 0x167F;                            
            // 0x01428994: BL #0x2782188              | X0 = sub_2782188( ?? 0x167F, ????);     
            // 0x01428998: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142899C: STRB w8, [x20, #2]         | static_value_03737002 = true;            //  dest_result_addr=57896962
            label_0:
            // 0x014289A0: CBNZ x19, #0x14289a8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014289A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167F, ????);     
            label_1:
            // 0x014289A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014289AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014289B0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x014289B4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x014289B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014289BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014289C0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x014289C4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014289C8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014289CC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x014289D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014289D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014289D8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x014289DC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x014289E0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x014289E4: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x014289E8: CBNZ x24, #0x14289f0       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x014289EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x014289F0: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x014289F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014289F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014289FC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01428A00: MOV x1, x21                | X1 = X2;//m1                            
            // 0x01428A04: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01428A08: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01428A0C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01428A10: ADRP x9, #0x35bf000        | X9 = 56356864 (0x35BF000);              
            // 0x01428A14: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x01428A18: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01428A1C: LDR x9, [x9, #0x620]       | X9 = 1152921504925163520;               
            // 0x01428A20: LDR x24, [x9]              | X24 = typeof(ButtonClickState);         
            // 0x01428A24: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01428A28: TBZ w9, #0, #0x1428a3c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01428A2C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01428A30: CBNZ w9, #0x1428a3c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01428A34: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01428A38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01428A3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428A40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428A44: MOV x1, x24                | X1 = 1152921504925163520 (0x1000000012F92000);//ML01
            // 0x01428A48: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01428A4C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01428A50: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01428A54: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x01428A58: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01428A5C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01428A60: TBZ w9, #0, #0x1428a74     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01428A64: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01428A68: CBNZ w9, #0x1428a74        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01428A6C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01428A70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x01428A74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428A78: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01428A7C: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01428A80: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01428A84: MOV x3, x22                | X3 = X3;//m1                            
            // 0x01428A88: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01428A8C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01428A90: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01428A94: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x01428A98: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01428A9C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01428AA0: TBZ w9, #0, #0x1428ab4     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01428AA4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01428AA8: CBNZ w9, #0x1428ab4        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01428AAC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01428AB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x01428AB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01428AB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01428ABC: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x01428AC0: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x01428AC4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x01428AC8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x01428ACC: CBZ x0, #0x1428b30         | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x01428AD0: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x01428AD4: LDR x9, [x9, #0xe8]        | X9 = 1152921504925163520;               
            // 0x01428AD8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01428ADC: LDR x1, [x9]               | X1 = typeof(ButtonClickState);          
            // 0x01428AE0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428AE4: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428AE8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428AEC: B.LO #0x1428b08            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x01428AF0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01428AF4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_type
            // 0x01428AF8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428AFC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428B00: MOV x22, x0                | X22 = val_7;//m1                        
            val_11 = val_7;
            // 0x01428B04: B.EQ #0x1428b30            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x01428B08: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01428B0C: ADD x8, sp, #8             | X8 = (1152921510101384800 + 8) = 1152921510101384808 (0x10000001477FFE68);
            // 0x01428B10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01428B14: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510101372896]
            // 0x01428B18: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x01428B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428B20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x01428B24: ADD x0, sp, #8             | X0 = (1152921510101384800 + 8) = 1152921510101384808 (0x10000001477FFE68);
            // 0x01428B28: BL #0x299a140              | 
            // 0x01428B2C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_11:
            // 0x01428B30: CBNZ x19, #0x1428b38       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01428B34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001477FFE68, ????);
            label_12:
            // 0x01428B38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428B3C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01428B40: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x01428B44: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01428B48: CBNZ x22, #0x1428b50       | if (0x0 != 0) goto label_13;            
            if(val_11 != 0)
            {
                goto label_13;
            }
            // 0x01428B4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x01428B50: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x01428B54: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x01428B58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01428B5C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01428B60: BL #0xba2d9c               | val_11.SetFunctionState(isactive:  bool val_10 = ((val_3 + 4) == 1) ? 1 : 0);
            val_11.SetFunctionState(isactive:  val_10);
            // 0x01428B64: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01428B68: SUB sp, x29, #0x40         | SP = (1152921510101384880 - 64) = 1152921510101384816 (0x10000001477FFE70);
            // 0x01428B6C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01428B70: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01428B74: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01428B78: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01428B7C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01428B80: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01428B84: MOV x19, x0                | 
            // 0x01428B88: ADD x0, sp, #8             | 
            // 0x01428B8C: BL #0x299a140              | 
            // 0x01428B90: MOV x0, x19                | 
            // 0x01428B94: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01428B98 (21138328), len: 288  VirtAddr: 0x01428B98 RVA: 0x01428B98 token: 100664097 methodIndex: 30142 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_strNormal_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01428B98: STP x20, x19, [sp, #-0x20]! | stack[1152921510101529552] = ???;  stack[1152921510101529560] = ???;  //  dest_result_addr=1152921510101529552 |  dest_result_addr=1152921510101529560
            // 0x01428B9C: STP x29, x30, [sp, #0x10]  | stack[1152921510101529568] = ???;  stack[1152921510101529576] = ???;  //  dest_result_addr=1152921510101529568 |  dest_result_addr=1152921510101529576
            // 0x01428BA0: ADD x29, sp, #0x10         | X29 = (1152921510101529552 + 16) = 1152921510101529568 (0x10000001478233E0);
            // 0x01428BA4: SUB sp, sp, #0x10          | SP = (1152921510101529552 - 16) = 1152921510101529536 (0x10000001478233C0);
            // 0x01428BA8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01428BAC: LDRB w8, [x20, #3]         | W8 = (bool)static_value_03737003;       
            // 0x01428BB0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01428BB4: TBNZ w8, #0, #0x1428bd0    | if (static_value_03737003 == true) goto label_0;
            // 0x01428BB8: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01428BBC: LDR x8, [x8, #0x7b8]       | X8 = 0x2B8FEA8;                         
            // 0x01428BC0: LDR w0, [x8]               | W0 = 0x166E;                            
            // 0x01428BC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x166E, ????);     
            // 0x01428BC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01428BCC: STRB w8, [x20, #3]         | static_value_03737003 = true;            //  dest_result_addr=57896963
            label_0:
            // 0x01428BD0: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01428BD4: LDR x19, [x19]             | X19 = X1;                               
            // 0x01428BD8: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01428BDC: CBZ x19, #0x1428c30        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01428BE0: LDR x8, [x19]              | X8 = X1;                                
            // 0x01428BE4: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01428BE8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01428BEC: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428BF0: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428BF4: B.LO #0x1428c0c            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01428BF8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01428BFC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428C00: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428C04: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428C08: B.EQ #0x1428c34            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01428C0C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01428C10: MOV x8, sp                 | X8 = 1152921510101529536 (0x10000001478233C0);//ML01
            // 0x01428C14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01428C18: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510101517584]
            // 0x01428C1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01428C20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428C24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01428C28: MOV x0, sp                 | X0 = 1152921510101529536 (0x10000001478233C0);//ML01
            // 0x01428C2C: BL #0x299a140              | 
            label_1:
            // 0x01428C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001478233C0, ????);
            label_3:
            // 0x01428C34: LDR x8, [x19]              | X8 = X1;                                
            // 0x01428C38: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01428C3C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01428C40: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428C44: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428C48: B.LO #0x1428c74            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01428C4C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01428C50: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428C54: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428C58: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428C5C: B.NE #0x1428c74            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01428C60: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x01428C64: SUB sp, x29, #0x10         | SP = (1152921510101529568 - 16) = 1152921510101529552 (0x10000001478233D0);
            // 0x01428C68: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01428C6C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01428C70: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01428C74: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01428C78: ADD x8, sp, #8             | X8 = (1152921510101529536 + 8) = 1152921510101529544 (0x10000001478233C8);
            // 0x01428C7C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01428C80: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510101517584]
            // 0x01428C84: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01428C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428C8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01428C90: ADD x0, sp, #8             | X0 = (1152921510101529536 + 8) = 1152921510101529544 (0x10000001478233C8);
            // 0x01428C94: BL #0x299a140              | 
            // 0x01428C98: MOV x19, x0                | X19 = 1152921510101529544 (0x10000001478233C8);//ML01
            // 0x01428C9C: MOV x0, sp                 | X0 = 1152921510101529536 (0x10000001478233C0);//ML01
            label_6:
            // 0x01428CA0: BL #0x299a140              | 
            // 0x01428CA4: MOV x0, x19                | X0 = 1152921510101529544 (0x10000001478233C8);//ML01
            // 0x01428CA8: BL #0x980800               | X0 = sub_980800( ?? 0x10000001478233C8, ????);
            // 0x01428CAC: MOV x19, x0                | X19 = 1152921510101529544 (0x10000001478233C8);//ML01
            // 0x01428CB0: ADD x0, sp, #8             | X0 = (1152921510101529536 + 8) = 1152921510101529544 (0x10000001478233C8);
            // 0x01428CB4: B #0x1428ca0               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01428CB8 (21138616), len: 392  VirtAddr: 0x01428CB8 RVA: 0x01428CB8 token: 100664098 methodIndex: 30143 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_strNormal_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01428CB8: STP x22, x21, [sp, #-0x30]! | stack[1152921510101653664] = ???;  stack[1152921510101653672] = ???;  //  dest_result_addr=1152921510101653664 |  dest_result_addr=1152921510101653672
            // 0x01428CBC: STP x20, x19, [sp, #0x10]  | stack[1152921510101653680] = ???;  stack[1152921510101653688] = ???;  //  dest_result_addr=1152921510101653680 |  dest_result_addr=1152921510101653688
            // 0x01428CC0: STP x29, x30, [sp, #0x20]  | stack[1152921510101653696] = ???;  stack[1152921510101653704] = ???;  //  dest_result_addr=1152921510101653696 |  dest_result_addr=1152921510101653704
            // 0x01428CC4: ADD x29, sp, #0x20         | X29 = (1152921510101653664 + 32) = 1152921510101653696 (0x10000001478418C0);
            // 0x01428CC8: SUB sp, sp, #0x20          | SP = (1152921510101653664 - 32) = 1152921510101653632 (0x1000000147841880);
            // 0x01428CCC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01428CD0: LDRB w8, [x21, #4]         | W8 = (bool)static_value_03737004;       
            // 0x01428CD4: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01428CD8: MOV x20, x1                | X20 = v;//m1                            
            // 0x01428CDC: TBNZ w8, #0, #0x1428cf8    | if (static_value_03737004 == true) goto label_0;
            // 0x01428CE0: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x01428CE4: LDR x8, [x8, #0xb78]       | X8 = 0x2B8FED8;                         
            // 0x01428CE8: LDR w0, [x8]               | W0 = 0x167A;                            
            // 0x01428CEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x167A, ????);     
            // 0x01428CF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01428CF4: STRB w8, [x21, #4]         | static_value_03737004 = true;            //  dest_result_addr=57896964
            label_0:
            // 0x01428CF8: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01428CFC: CBZ x20, #0x1428db0        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01428D00: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
            // 0x01428D04: LDR x21, [x21, #0xe8]      | X21 = 1152921504925163520;              
            val_6 = 1152921504925163520;
            // 0x01428D08: LDR x8, [x20]              | X8 = ;                                  
            // 0x01428D0C: LDR x1, [x21]              | X1 = typeof(ButtonClickState);          
            // 0x01428D10: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01428D14: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428D18: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428D1C: B.LO #0x1428d34            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01428D20: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01428D24: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428D28: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428D2C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428D30: B.EQ #0x1428d5c            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01428D34: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01428D38: ADD x8, sp, #8             | X8 = (1152921510101653632 + 8) = 1152921510101653640 (0x1000000147841888);
            // 0x01428D3C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01428D40: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510101641712]
            // 0x01428D44: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01428D48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428D4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01428D50: ADD x0, sp, #8             | X0 = (1152921510101653632 + 8) = 1152921510101653640 (0x1000000147841888);
            // 0x01428D54: BL #0x299a140              | 
            // 0x01428D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147841888, ????);
            label_3:
            // 0x01428D5C: LDR x8, [x20]              | X8 = ;                                  
            // 0x01428D60: LDR x1, [x21]              | X1 = typeof(ButtonClickState);          
            // 0x01428D64: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01428D68: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428D6C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428D70: B.LO #0x1428d88            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01428D74: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01428D78: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428D7C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428D80: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428D84: B.EQ #0x1428db8            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01428D88: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01428D8C: ADD x8, sp, #0x10          | X8 = (1152921510101653632 + 16) = 1152921510101653648 (0x1000000147841890);
            // 0x01428D90: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01428D94: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510101641712]
            // 0x01428D98: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01428D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428DA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01428DA4: ADD x0, sp, #0x10          | X0 = (1152921510101653632 + 16) = 1152921510101653648 (0x1000000147841890);
            // 0x01428DA8: BL #0x299a140              | 
            // 0x01428DAC: B #0x1428db4               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01428DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167A, ????);     
            label_6:
            // 0x01428DB4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01428DB8: CBZ x19, #0x1428df8        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01428DBC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01428DC0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01428DC4: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01428DC8: LDR x8, [x19]              | X8 = X2;                                
            // 0x01428DCC: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01428DD0: B.EQ #0x1428dfc            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01428DD4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01428DD8: ADD x8, sp, #0x18          | X8 = (1152921510101653632 + 24) = 1152921510101653656 (0x1000000147841898);
            // 0x01428DDC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01428DE0: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510101641712]
            // 0x01428DE4: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01428DE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428DEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01428DF0: ADD x0, sp, #0x18          | X0 = (1152921510101653632 + 24) = 1152921510101653656 (0x1000000147841898);
            // 0x01428DF4: BL #0x299a140              | 
            label_7:
            // 0x01428DF8: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01428DFC: STR x19, [x20, #0x18]      | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_7;
            // 0x01428E00: SUB sp, x29, #0x20         | SP = (1152921510101653696 - 32) = 1152921510101653664 (0x10000001478418A0);
            // 0x01428E04: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01428E08: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01428E0C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01428E10: RET                        |  return;                                
            return;
            // 0x01428E14: MOV x19, x0                | 
            // 0x01428E18: ADD x0, sp, #8             | 
            // 0x01428E1C: B #0x1428e34               | 
            // 0x01428E20: MOV x19, x0                | 
            // 0x01428E24: ADD x0, sp, #0x10          | 
            // 0x01428E28: B #0x1428e34               | 
            // 0x01428E2C: MOV x19, x0                | 
            // 0x01428E30: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01428E34: BL #0x299a140              | 
            // 0x01428E38: MOV x0, x19                | 
            // 0x01428E3C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01428E40 (21139008), len: 288  VirtAddr: 0x01428E40 RVA: 0x01428E40 token: 100664099 methodIndex: 30144 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_strPress_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01428E40: STP x20, x19, [sp, #-0x20]! | stack[1152921510101777808] = ???;  stack[1152921510101777816] = ???;  //  dest_result_addr=1152921510101777808 |  dest_result_addr=1152921510101777816
            // 0x01428E44: STP x29, x30, [sp, #0x10]  | stack[1152921510101777824] = ???;  stack[1152921510101777832] = ???;  //  dest_result_addr=1152921510101777824 |  dest_result_addr=1152921510101777832
            // 0x01428E48: ADD x29, sp, #0x10         | X29 = (1152921510101777808 + 16) = 1152921510101777824 (0x100000014785FDA0);
            // 0x01428E4C: SUB sp, sp, #0x10          | SP = (1152921510101777808 - 16) = 1152921510101777792 (0x100000014785FD80);
            // 0x01428E50: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01428E54: LDRB w8, [x20, #5]         | W8 = (bool)static_value_03737005;       
            // 0x01428E58: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01428E5C: TBNZ w8, #0, #0x1428e78    | if (static_value_03737005 == true) goto label_0;
            // 0x01428E60: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x01428E64: LDR x8, [x8, #0xbd0]       | X8 = 0x2B8FEAC;                         
            // 0x01428E68: LDR w0, [x8]               | W0 = 0x166F;                            
            // 0x01428E6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x166F, ????);     
            // 0x01428E70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01428E74: STRB w8, [x20, #5]         | static_value_03737005 = true;            //  dest_result_addr=57896965
            label_0:
            // 0x01428E78: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01428E7C: LDR x19, [x19]             | X19 = X1;                               
            // 0x01428E80: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01428E84: CBZ x19, #0x1428ed8        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01428E88: LDR x8, [x19]              | X8 = X1;                                
            // 0x01428E8C: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01428E90: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01428E94: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428E98: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428E9C: B.LO #0x1428eb4            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01428EA0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01428EA4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428EA8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428EAC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428EB0: B.EQ #0x1428edc            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01428EB4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01428EB8: MOV x8, sp                 | X8 = 1152921510101777792 (0x100000014785FD80);//ML01
            // 0x01428EBC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01428EC0: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510101765840]
            // 0x01428EC4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01428EC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428ECC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01428ED0: MOV x0, sp                 | X0 = 1152921510101777792 (0x100000014785FD80);//ML01
            // 0x01428ED4: BL #0x299a140              | 
            label_1:
            // 0x01428ED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014785FD80, ????);
            label_3:
            // 0x01428EDC: LDR x8, [x19]              | X8 = X1;                                
            // 0x01428EE0: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01428EE4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01428EE8: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428EEC: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428EF0: B.LO #0x1428f1c            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01428EF4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01428EF8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428EFC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428F00: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428F04: B.NE #0x1428f1c            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01428F08: LDR x0, [x19, #0x20]       | X0 = X1 + 32;                           
            // 0x01428F0C: SUB sp, x29, #0x10         | SP = (1152921510101777824 - 16) = 1152921510101777808 (0x100000014785FD90);
            // 0x01428F10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01428F14: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01428F18: RET                        |  return (System.Object)X1 + 32;         
            return (object)X1 + 32;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01428F1C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01428F20: ADD x8, sp, #8             | X8 = (1152921510101777792 + 8) = 1152921510101777800 (0x100000014785FD88);
            // 0x01428F24: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01428F28: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510101765840]
            // 0x01428F2C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01428F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428F34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01428F38: ADD x0, sp, #8             | X0 = (1152921510101777792 + 8) = 1152921510101777800 (0x100000014785FD88);
            // 0x01428F3C: BL #0x299a140              | 
            // 0x01428F40: MOV x19, x0                | X19 = 1152921510101777800 (0x100000014785FD88);//ML01
            // 0x01428F44: MOV x0, sp                 | X0 = 1152921510101777792 (0x100000014785FD80);//ML01
            label_6:
            // 0x01428F48: BL #0x299a140              | 
            // 0x01428F4C: MOV x0, x19                | X0 = 1152921510101777800 (0x100000014785FD88);//ML01
            // 0x01428F50: BL #0x980800               | X0 = sub_980800( ?? 0x100000014785FD88, ????);
            // 0x01428F54: MOV x19, x0                | X19 = 1152921510101777800 (0x100000014785FD88);//ML01
            // 0x01428F58: ADD x0, sp, #8             | X0 = (1152921510101777792 + 8) = 1152921510101777800 (0x100000014785FD88);
            // 0x01428F5C: B #0x1428f48               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01428F60 (21139296), len: 392  VirtAddr: 0x01428F60 RVA: 0x01428F60 token: 100664100 methodIndex: 30145 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_strPress_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01428F60: STP x22, x21, [sp, #-0x30]! | stack[1152921510101901920] = ???;  stack[1152921510101901928] = ???;  //  dest_result_addr=1152921510101901920 |  dest_result_addr=1152921510101901928
            // 0x01428F64: STP x20, x19, [sp, #0x10]  | stack[1152921510101901936] = ???;  stack[1152921510101901944] = ???;  //  dest_result_addr=1152921510101901936 |  dest_result_addr=1152921510101901944
            // 0x01428F68: STP x29, x30, [sp, #0x20]  | stack[1152921510101901952] = ???;  stack[1152921510101901960] = ???;  //  dest_result_addr=1152921510101901952 |  dest_result_addr=1152921510101901960
            // 0x01428F6C: ADD x29, sp, #0x20         | X29 = (1152921510101901920 + 32) = 1152921510101901952 (0x100000014787E280);
            // 0x01428F70: SUB sp, sp, #0x20          | SP = (1152921510101901920 - 32) = 1152921510101901888 (0x100000014787E240);
            // 0x01428F74: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01428F78: LDRB w8, [x21, #6]         | W8 = (bool)static_value_03737006;       
            // 0x01428F7C: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01428F80: MOV x20, x1                | X20 = v;//m1                            
            // 0x01428F84: TBNZ w8, #0, #0x1428fa0    | if (static_value_03737006 == true) goto label_0;
            // 0x01428F88: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x01428F8C: LDR x8, [x8, #0x500]       | X8 = 0x2B8FEDC;                         
            // 0x01428F90: LDR w0, [x8]               | W0 = 0x167B;                            
            // 0x01428F94: BL #0x2782188              | X0 = sub_2782188( ?? 0x167B, ????);     
            // 0x01428F98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01428F9C: STRB w8, [x21, #6]         | static_value_03737006 = true;            //  dest_result_addr=57896966
            label_0:
            // 0x01428FA0: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01428FA4: CBZ x20, #0x1429058        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01428FA8: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
            // 0x01428FAC: LDR x21, [x21, #0xe8]      | X21 = 1152921504925163520;              
            val_6 = 1152921504925163520;
            // 0x01428FB0: LDR x8, [x20]              | X8 = ;                                  
            // 0x01428FB4: LDR x1, [x21]              | X1 = typeof(ButtonClickState);          
            // 0x01428FB8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01428FBC: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01428FC0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01428FC4: B.LO #0x1428fdc            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01428FC8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01428FCC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01428FD0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01428FD4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01428FD8: B.EQ #0x1429004            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01428FDC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01428FE0: ADD x8, sp, #8             | X8 = (1152921510101901888 + 8) = 1152921510101901896 (0x100000014787E248);
            // 0x01428FE4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01428FE8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510101889968]
            // 0x01428FEC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01428FF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01428FF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01428FF8: ADD x0, sp, #8             | X0 = (1152921510101901888 + 8) = 1152921510101901896 (0x100000014787E248);
            // 0x01428FFC: BL #0x299a140              | 
            // 0x01429000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014787E248, ????);
            label_3:
            // 0x01429004: LDR x8, [x20]              | X8 = ;                                  
            // 0x01429008: LDR x1, [x21]              | X1 = typeof(ButtonClickState);          
            // 0x0142900C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429010: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429014: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429018: B.LO #0x1429030            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x0142901C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429020: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429024: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429028: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x0142902C: B.EQ #0x1429060            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01429030: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429034: ADD x8, sp, #0x10          | X8 = (1152921510101901888 + 16) = 1152921510101901904 (0x100000014787E250);
            // 0x01429038: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x0142903C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510101889968]
            // 0x01429040: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429044: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429048: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x0142904C: ADD x0, sp, #0x10          | X0 = (1152921510101901888 + 16) = 1152921510101901904 (0x100000014787E250);
            // 0x01429050: BL #0x299a140              | 
            // 0x01429054: B #0x142905c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01429058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167B, ????);     
            label_6:
            // 0x0142905C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01429060: CBZ x19, #0x14290a0        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01429064: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01429068: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0142906C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01429070: LDR x8, [x19]              | X8 = X2;                                
            // 0x01429074: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01429078: B.EQ #0x14290a4            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x0142907C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01429080: ADD x8, sp, #0x18          | X8 = (1152921510101901888 + 24) = 1152921510101901912 (0x100000014787E258);
            // 0x01429084: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01429088: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510101889968]
            // 0x0142908C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01429090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429094: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01429098: ADD x0, sp, #0x18          | X0 = (1152921510101901888 + 24) = 1152921510101901912 (0x100000014787E258);
            // 0x0142909C: BL #0x299a140              | 
            label_7:
            // 0x014290A0: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x014290A4: STR x19, [x20, #0x20]      | mem[32] = 0x0;                           //  dest_result_addr=32
            mem[32] = val_7;
            // 0x014290A8: SUB sp, x29, #0x20         | SP = (1152921510101901952 - 32) = 1152921510101901920 (0x100000014787E260);
            // 0x014290AC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x014290B0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x014290B4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x014290B8: RET                        |  return;                                
            return;
            // 0x014290BC: MOV x19, x0                | 
            // 0x014290C0: ADD x0, sp, #8             | 
            // 0x014290C4: B #0x14290dc               | 
            // 0x014290C8: MOV x19, x0                | 
            // 0x014290CC: ADD x0, sp, #0x10          | 
            // 0x014290D0: B #0x14290dc               | 
            // 0x014290D4: MOV x19, x0                | 
            // 0x014290D8: ADD x0, sp, #0x18          | 
            label_10:
            // 0x014290DC: BL #0x299a140              | 
            // 0x014290E0: MOV x0, x19                | 
            // 0x014290E4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014290E8 (21139688), len: 312  VirtAddr: 0x014290E8 RVA: 0x014290E8 token: 100664101 methodIndex: 30146 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_interval_max_time_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014290E8: STP x20, x19, [sp, #-0x20]! | stack[1152921510102030160] = ???;  stack[1152921510102030168] = ???;  //  dest_result_addr=1152921510102030160 |  dest_result_addr=1152921510102030168
            // 0x014290EC: STP x29, x30, [sp, #0x10]  | stack[1152921510102030176] = ???;  stack[1152921510102030184] = ???;  //  dest_result_addr=1152921510102030176 |  dest_result_addr=1152921510102030184
            // 0x014290F0: ADD x29, sp, #0x10         | X29 = (1152921510102030160 + 16) = 1152921510102030176 (0x100000014789D760);
            // 0x014290F4: SUB sp, sp, #0x20          | SP = (1152921510102030160 - 32) = 1152921510102030128 (0x100000014789D730);
            // 0x014290F8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014290FC: LDRB w8, [x20, #7]         | W8 = (bool)static_value_03737007;       
            // 0x01429100: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01429104: TBNZ w8, #0, #0x1429120    | if (static_value_03737007 == true) goto label_0;
            // 0x01429108: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x0142910C: LDR x8, [x8, #0x78]        | X8 = 0x2B8FE98;                         
            // 0x01429110: LDR w0, [x8]               | W0 = 0x166A;                            
            // 0x01429114: BL #0x2782188              | X0 = sub_2782188( ?? 0x166A, ????);     
            // 0x01429118: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142911C: STRB w8, [x20, #7]         | static_value_03737007 = true;            //  dest_result_addr=57896967
            label_0:
            // 0x01429120: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01429124: LDR x19, [x19]             | X19 = X1;                               
            // 0x01429128: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x0142912C: CBZ x19, #0x1429180        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01429130: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429134: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429138: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x0142913C: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429140: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429144: B.LO #0x142915c            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01429148: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x0142914C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429150: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429154: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429158: B.EQ #0x1429184            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x0142915C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429160: ADD x8, sp, #0x10          | X8 = (1152921510102030128 + 16) = 1152921510102030144 (0x100000014789D740);
            // 0x01429164: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01429168: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510102018192]
            // 0x0142916C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429174: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01429178: ADD x0, sp, #0x10          | X0 = (1152921510102030128 + 16) = 1152921510102030144 (0x100000014789D740);
            // 0x0142917C: BL #0x299a140              | 
            label_1:
            // 0x01429180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014789D740, ????);
            label_3:
            // 0x01429184: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429188: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x0142918C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429190: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429194: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429198: B.LO #0x14291dc            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x0142919C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x014291A0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014291A4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014291A8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014291AC: B.NE #0x14291dc            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x014291B0: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x014291B4: LDR w8, [x19, #0x28]       | W8 = X1 + 40;                           
            // 0x014291B8: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x014291BC: ADD x1, sp, #0xc           | X1 = (1152921510102030128 + 12) = 1152921510102030140 (0x100000014789D73C);
            // 0x014291C0: STR w8, [sp, #0xc]         | stack[1152921510102030140] = X1 + 40;    //  dest_result_addr=1152921510102030140
            // 0x014291C4: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x014291C8: BL #0x27bc028              | X0 = 1152921510102078208 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 40);
            // 0x014291CC: SUB sp, x29, #0x10         | SP = (1152921510102030176 - 16) = 1152921510102030160 (0x100000014789D750);
            // 0x014291D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014291D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014291D8: RET                        |  return (System.Object)X1 + 40;         
            return (object)X1 + 40;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x014291DC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014291E0: ADD x8, sp, #0x18          | X8 = (1152921510102030128 + 24) = 1152921510102030152 (0x100000014789D748);
            // 0x014291E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014291E8: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510102018192]
            // 0x014291EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014291F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014291F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014291F8: ADD x0, sp, #0x18          | X0 = (1152921510102030128 + 24) = 1152921510102030152 (0x100000014789D748);
            // 0x014291FC: BL #0x299a140              | 
            // 0x01429200: MOV x19, x0                | X19 = 1152921510102030152 (0x100000014789D748);//ML01
            // 0x01429204: ADD x0, sp, #0x10          | X0 = (1152921510102030128 + 16) = 1152921510102030144 (0x100000014789D740);
            label_6:
            // 0x01429208: BL #0x299a140              | 
            // 0x0142920C: MOV x0, x19                | X0 = 1152921510102030152 (0x100000014789D748);//ML01
            // 0x01429210: BL #0x980800               | X0 = sub_980800( ?? 0x100000014789D748, ????);
            // 0x01429214: MOV x19, x0                | X19 = 1152921510102030152 (0x100000014789D748);//ML01
            // 0x01429218: ADD x0, sp, #0x18          | X0 = (1152921510102030128 + 24) = 1152921510102030152 (0x100000014789D748);
            // 0x0142921C: B #0x1429208               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429220 (21140000), len: 412  VirtAddr: 0x01429220 RVA: 0x01429220 token: 100664102 methodIndex: 30147 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_interval_max_time_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01429220: STP x22, x21, [sp, #-0x30]! | stack[1152921510102158368] = ???;  stack[1152921510102158376] = ???;  //  dest_result_addr=1152921510102158368 |  dest_result_addr=1152921510102158376
            // 0x01429224: STP x20, x19, [sp, #0x10]  | stack[1152921510102158384] = ???;  stack[1152921510102158392] = ???;  //  dest_result_addr=1152921510102158384 |  dest_result_addr=1152921510102158392
            // 0x01429228: STP x29, x30, [sp, #0x20]  | stack[1152921510102158400] = ???;  stack[1152921510102158408] = ???;  //  dest_result_addr=1152921510102158400 |  dest_result_addr=1152921510102158408
            // 0x0142922C: ADD x29, sp, #0x20         | X29 = (1152921510102158368 + 32) = 1152921510102158400 (0x10000001478BCC40);
            // 0x01429230: SUB sp, sp, #0x20          | SP = (1152921510102158368 - 32) = 1152921510102158336 (0x10000001478BCC00);
            // 0x01429234: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01429238: LDRB w8, [x21, #8]         | W8 = (bool)static_value_03737008;       
            // 0x0142923C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01429240: MOV x20, x1                | X20 = v;//m1                            
            // 0x01429244: TBNZ w8, #0, #0x1429260    | if (static_value_03737008 == true) goto label_0;
            // 0x01429248: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x0142924C: LDR x8, [x8, #0xef8]       | X8 = 0x2B8FEC8;                         
            // 0x01429250: LDR w0, [x8]               | W0 = 0x1676;                            
            // 0x01429254: BL #0x2782188              | X0 = sub_2782188( ?? 0x1676, ????);     
            // 0x01429258: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0142925C: STRB w8, [x21, #8]         | static_value_03737008 = true;            //  dest_result_addr=57896968
            label_0:
            // 0x01429260: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01429264: CBZ x21, #0x1429318        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01429268: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x0142926C: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01429270: LDR x8, [x21]              | X8 = ;                                  
            // 0x01429274: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429278: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x0142927C: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429280: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429284: B.LO #0x142929c            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01429288: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x0142928C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429290: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429294: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429298: B.EQ #0x14292c4            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x0142929C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014292A0: ADD x8, sp, #8             | X8 = (1152921510102158336 + 8) = 1152921510102158344 (0x10000001478BCC08);
            // 0x014292A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014292A8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510102146416]
            // 0x014292AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x014292B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014292B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014292B8: ADD x0, sp, #8             | X0 = (1152921510102158336 + 8) = 1152921510102158344 (0x10000001478BCC08);
            // 0x014292BC: BL #0x299a140              | 
            // 0x014292C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001478BCC08, ????);
            label_3:
            // 0x014292C4: LDR x8, [x21]              | X8 = ;                                  
            // 0x014292C8: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x014292CC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x014292D0: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014292D4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014292D8: B.LO #0x14292f0            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x014292DC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x014292E0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014292E4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014292E8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014292EC: B.EQ #0x1429320            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x014292F0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014292F4: ADD x8, sp, #0x10          | X8 = (1152921510102158336 + 16) = 1152921510102158352 (0x10000001478BCC10);
            // 0x014292F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014292FC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510102146416]
            // 0x01429300: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429308: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x0142930C: ADD x0, sp, #0x10          | X0 = (1152921510102158336 + 16) = 1152921510102158352 (0x10000001478BCC10);
            // 0x01429310: BL #0x299a140              | 
            // 0x01429314: B #0x142931c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01429318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1676, ????);     
            label_6:
            // 0x0142931C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01429320: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01429324: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x01429328: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x0142932C: CBNZ x19, #0x1429334       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01429330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1676, ????);     
            label_7:
            // 0x01429334: LDR x8, [x19]              | X8 = X2;                                
            // 0x01429338: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x0142933C: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x01429340: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x01429344: B.NE #0x142938c            | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01429348: MOV x0, x19                | X0 = X2;//m1                            
            // 0x0142934C: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01429350: LDR w8, [x0]               | W8 = X2;                                
            // 0x01429354: STR w8, [x21, #0x28]       | mem[40] = X2;                            //  dest_result_addr=40
            mem[40] = X2;
            // 0x01429358: SUB sp, x29, #0x20         | SP = (1152921510102158400 - 32) = 1152921510102158368 (0x10000001478BCC20);
            // 0x0142935C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01429360: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01429364: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01429368: RET                        |  return;                                
            return;
            // 0x0142936C: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01429370: ADD x0, sp, #8             | X0 = (1152921510102158416 + 8) = 1152921510102158424 (0x10000001478BCC58);
            // 0x01429374: B #0x1429380               |  goto label_10;                         
            goto label_10;
            // 0x01429378: MOV x19, x0                | X19 = 1152921510102158424 (0x10000001478BCC58);//ML01
            val_7;
            // 0x0142937C: ADD x0, sp, #0x10          | X0 = (1152921510102158416 + 16) = 1152921510102158432 (0x10000001478BCC60);
            label_10:
            // 0x01429380: BL #0x299a140              | 
            // 0x01429384: MOV x0, x19                | X0 = 1152921510102158424 (0x10000001478BCC58);//ML01
            // 0x01429388: BL #0x980800               | X0 = sub_980800( ?? 0x10000001478BCC58, ????);
            label_8:
            // 0x0142938C: ADD x8, sp, #0x18          | X8 = (1152921510102158416 + 24) = 1152921510102158440 (0x10000001478BCC68);
            // 0x01429390: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01429394: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001478BCC58, ????);
            // 0x01429398: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510102146416]
            // 0x0142939C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x014293A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014293A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x014293A8: ADD x0, sp, #0x18          | X0 = (1152921510102158416 + 24) = 1152921510102158440 (0x10000001478BCC68);
            // 0x014293AC: BL #0x299a140              | 
            // 0x014293B0: MOV x19, x0                | X19 = 1152921510102158440 (0x10000001478BCC68);//ML01
            // 0x014293B4: ADD x0, sp, #0x18          | X0 = (1152921510102158416 + 24) = 1152921510102158440 (0x10000001478BCC68);
            // 0x014293B8: B #0x1429380               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x014293BC (21140412), len: 312  VirtAddr: 0x014293BC RVA: 0x014293BC token: 100664103 methodIndex: 30148 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_interval_min_time_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014293BC: STP x20, x19, [sp, #-0x20]! | stack[1152921510102286608] = ???;  stack[1152921510102286616] = ???;  //  dest_result_addr=1152921510102286608 |  dest_result_addr=1152921510102286616
            // 0x014293C0: STP x29, x30, [sp, #0x10]  | stack[1152921510102286624] = ???;  stack[1152921510102286632] = ???;  //  dest_result_addr=1152921510102286624 |  dest_result_addr=1152921510102286632
            // 0x014293C4: ADD x29, sp, #0x10         | X29 = (1152921510102286608 + 16) = 1152921510102286624 (0x10000001478DC120);
            // 0x014293C8: SUB sp, sp, #0x20          | SP = (1152921510102286608 - 32) = 1152921510102286576 (0x10000001478DC0F0);
            // 0x014293CC: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014293D0: LDRB w8, [x20, #9]         | W8 = (bool)static_value_03737009;       
            // 0x014293D4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014293D8: TBNZ w8, #0, #0x14293f4    | if (static_value_03737009 == true) goto label_0;
            // 0x014293DC: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x014293E0: LDR x8, [x8, #0x6f0]       | X8 = 0x2B8FE9C;                         
            // 0x014293E4: LDR w0, [x8]               | W0 = 0x166B;                            
            // 0x014293E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x166B, ????);     
            // 0x014293EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014293F0: STRB w8, [x20, #9]         | static_value_03737009 = true;            //  dest_result_addr=57896969
            label_0:
            // 0x014293F4: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x014293F8: LDR x19, [x19]             | X19 = X1;                               
            // 0x014293FC: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01429400: CBZ x19, #0x1429454        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01429404: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429408: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x0142940C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429410: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429414: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429418: B.LO #0x1429430            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x0142941C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01429420: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429424: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429428: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x0142942C: B.EQ #0x1429458            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429430: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429434: ADD x8, sp, #0x10          | X8 = (1152921510102286576 + 16) = 1152921510102286592 (0x10000001478DC100);
            // 0x01429438: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x0142943C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510102274640]
            // 0x01429440: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429444: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429448: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x0142944C: ADD x0, sp, #0x10          | X0 = (1152921510102286576 + 16) = 1152921510102286592 (0x10000001478DC100);
            // 0x01429450: BL #0x299a140              | 
            label_1:
            // 0x01429454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001478DC100, ????);
            label_3:
            // 0x01429458: LDR x8, [x19]              | X8 = X1;                                
            // 0x0142945C: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429460: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429464: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429468: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142946C: B.LO #0x14294b0            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01429470: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01429474: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429478: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142947C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429480: B.NE #0x14294b0            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01429484: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x01429488: LDR w8, [x19, #0x2c]       | W8 = X1 + 44;                           
            // 0x0142948C: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x01429490: ADD x1, sp, #0xc           | X1 = (1152921510102286576 + 12) = 1152921510102286588 (0x10000001478DC0FC);
            // 0x01429494: STR w8, [sp, #0xc]         | stack[1152921510102286588] = X1 + 44;    //  dest_result_addr=1152921510102286588
            // 0x01429498: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x0142949C: BL #0x27bc028              | X0 = 1152921510102334656 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 44);
            // 0x014294A0: SUB sp, x29, #0x10         | SP = (1152921510102286624 - 16) = 1152921510102286608 (0x10000001478DC110);
            // 0x014294A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014294A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014294AC: RET                        |  return (System.Object)X1 + 44;         
            return (object)X1 + 44;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x014294B0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014294B4: ADD x8, sp, #0x18          | X8 = (1152921510102286576 + 24) = 1152921510102286600 (0x10000001478DC108);
            // 0x014294B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014294BC: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510102274640]
            // 0x014294C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014294C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014294C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014294CC: ADD x0, sp, #0x18          | X0 = (1152921510102286576 + 24) = 1152921510102286600 (0x10000001478DC108);
            // 0x014294D0: BL #0x299a140              | 
            // 0x014294D4: MOV x19, x0                | X19 = 1152921510102286600 (0x10000001478DC108);//ML01
            // 0x014294D8: ADD x0, sp, #0x10          | X0 = (1152921510102286576 + 16) = 1152921510102286592 (0x10000001478DC100);
            label_6:
            // 0x014294DC: BL #0x299a140              | 
            // 0x014294E0: MOV x0, x19                | X0 = 1152921510102286600 (0x10000001478DC108);//ML01
            // 0x014294E4: BL #0x980800               | X0 = sub_980800( ?? 0x10000001478DC108, ????);
            // 0x014294E8: MOV x19, x0                | X19 = 1152921510102286600 (0x10000001478DC108);//ML01
            // 0x014294EC: ADD x0, sp, #0x18          | X0 = (1152921510102286576 + 24) = 1152921510102286600 (0x10000001478DC108);
            // 0x014294F0: B #0x14294dc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014294F4 (21140724), len: 412  VirtAddr: 0x014294F4 RVA: 0x014294F4 token: 100664104 methodIndex: 30149 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_interval_min_time_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x014294F4: STP x22, x21, [sp, #-0x30]! | stack[1152921510102414816] = ???;  stack[1152921510102414824] = ???;  //  dest_result_addr=1152921510102414816 |  dest_result_addr=1152921510102414824
            // 0x014294F8: STP x20, x19, [sp, #0x10]  | stack[1152921510102414832] = ???;  stack[1152921510102414840] = ???;  //  dest_result_addr=1152921510102414832 |  dest_result_addr=1152921510102414840
            // 0x014294FC: STP x29, x30, [sp, #0x20]  | stack[1152921510102414848] = ???;  stack[1152921510102414856] = ???;  //  dest_result_addr=1152921510102414848 |  dest_result_addr=1152921510102414856
            // 0x01429500: ADD x29, sp, #0x20         | X29 = (1152921510102414816 + 32) = 1152921510102414848 (0x10000001478FB600);
            // 0x01429504: SUB sp, sp, #0x20          | SP = (1152921510102414816 - 32) = 1152921510102414784 (0x10000001478FB5C0);
            // 0x01429508: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0142950C: LDRB w8, [x21, #0xa]       | W8 = (bool)static_value_0373700A;       
            // 0x01429510: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01429514: MOV x20, x1                | X20 = v;//m1                            
            // 0x01429518: TBNZ w8, #0, #0x1429534    | if (static_value_0373700A == true) goto label_0;
            // 0x0142951C: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x01429520: LDR x8, [x8, #0x290]       | X8 = 0x2B8FECC;                         
            // 0x01429524: LDR w0, [x8]               | W0 = 0x1677;                            
            // 0x01429528: BL #0x2782188              | X0 = sub_2782188( ?? 0x1677, ????);     
            // 0x0142952C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429530: STRB w8, [x21, #0xa]       | static_value_0373700A = true;            //  dest_result_addr=57896970
            label_0:
            // 0x01429534: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01429538: CBZ x21, #0x14295ec        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x0142953C: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01429540: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01429544: LDR x8, [x21]              | X8 = ;                                  
            // 0x01429548: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x0142954C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429550: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429554: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429558: B.LO #0x1429570            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x0142955C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429560: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429564: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429568: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x0142956C: B.EQ #0x1429598            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429570: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429574: ADD x8, sp, #8             | X8 = (1152921510102414784 + 8) = 1152921510102414792 (0x10000001478FB5C8);
            // 0x01429578: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x0142957C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510102402864]
            // 0x01429580: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429588: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x0142958C: ADD x0, sp, #8             | X0 = (1152921510102414784 + 8) = 1152921510102414792 (0x10000001478FB5C8);
            // 0x01429590: BL #0x299a140              | 
            // 0x01429594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001478FB5C8, ????);
            label_3:
            // 0x01429598: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142959C: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x014295A0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x014295A4: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014295A8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014295AC: B.LO #0x14295c4            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x014295B0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x014295B4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014295B8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014295BC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014295C0: B.EQ #0x14295f4            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x014295C4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014295C8: ADD x8, sp, #0x10          | X8 = (1152921510102414784 + 16) = 1152921510102414800 (0x10000001478FB5D0);
            // 0x014295CC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014295D0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510102402864]
            // 0x014295D4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014295D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014295DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014295E0: ADD x0, sp, #0x10          | X0 = (1152921510102414784 + 16) = 1152921510102414800 (0x10000001478FB5D0);
            // 0x014295E4: BL #0x299a140              | 
            // 0x014295E8: B #0x14295f0               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x014295EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1677, ????);     
            label_6:
            // 0x014295F0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x014295F4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x014295F8: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x014295FC: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x01429600: CBNZ x19, #0x1429608       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01429604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1677, ????);     
            label_7:
            // 0x01429608: LDR x8, [x19]              | X8 = X2;                                
            // 0x0142960C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01429610: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x01429614: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x01429618: B.NE #0x1429660            | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x0142961C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01429620: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01429624: LDR w8, [x0]               | W8 = X2;                                
            // 0x01429628: STR w8, [x21, #0x2c]       | mem[44] = X2;                            //  dest_result_addr=44
            mem[44] = X2;
            // 0x0142962C: SUB sp, x29, #0x20         | SP = (1152921510102414848 - 32) = 1152921510102414816 (0x10000001478FB5E0);
            // 0x01429630: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01429634: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01429638: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0142963C: RET                        |  return;                                
            return;
            // 0x01429640: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01429644: ADD x0, sp, #8             | X0 = (1152921510102414864 + 8) = 1152921510102414872 (0x10000001478FB618);
            // 0x01429648: B #0x1429654               |  goto label_10;                         
            goto label_10;
            // 0x0142964C: MOV x19, x0                | X19 = 1152921510102414872 (0x10000001478FB618);//ML01
            val_7;
            // 0x01429650: ADD x0, sp, #0x10          | X0 = (1152921510102414864 + 16) = 1152921510102414880 (0x10000001478FB620);
            label_10:
            // 0x01429654: BL #0x299a140              | 
            // 0x01429658: MOV x0, x19                | X0 = 1152921510102414872 (0x10000001478FB618);//ML01
            // 0x0142965C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001478FB618, ????);
            label_8:
            // 0x01429660: ADD x8, sp, #0x18          | X8 = (1152921510102414864 + 24) = 1152921510102414888 (0x10000001478FB628);
            // 0x01429664: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01429668: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001478FB618, ????);
            // 0x0142966C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510102402864]
            // 0x01429670: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01429674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x0142967C: ADD x0, sp, #0x18          | X0 = (1152921510102414864 + 24) = 1152921510102414888 (0x10000001478FB628);
            // 0x01429680: BL #0x299a140              | 
            // 0x01429684: MOV x19, x0                | X19 = 1152921510102414888 (0x10000001478FB628);//ML01
            // 0x01429688: ADD x0, sp, #0x18          | X0 = (1152921510102414864 + 24) = 1152921510102414888 (0x10000001478FB628);
            // 0x0142968C: B #0x1429654               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429690 (21141136), len: 312  VirtAddr: 0x01429690 RVA: 0x01429690 token: 100664105 methodIndex: 30150 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_less_speed_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01429690: STP x20, x19, [sp, #-0x20]! | stack[1152921510102543056] = ???;  stack[1152921510102543064] = ???;  //  dest_result_addr=1152921510102543056 |  dest_result_addr=1152921510102543064
            // 0x01429694: STP x29, x30, [sp, #0x10]  | stack[1152921510102543072] = ???;  stack[1152921510102543080] = ???;  //  dest_result_addr=1152921510102543072 |  dest_result_addr=1152921510102543080
            // 0x01429698: ADD x29, sp, #0x10         | X29 = (1152921510102543056 + 16) = 1152921510102543072 (0x100000014791AAE0);
            // 0x0142969C: SUB sp, sp, #0x20          | SP = (1152921510102543056 - 32) = 1152921510102543024 (0x100000014791AAB0);
            // 0x014296A0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014296A4: LDRB w8, [x20, #0xb]       | W8 = (bool)static_value_0373700B;       
            // 0x014296A8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014296AC: TBNZ w8, #0, #0x14296c8    | if (static_value_0373700B == true) goto label_0;
            // 0x014296B0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x014296B4: LDR x8, [x8, #0x4b0]       | X8 = 0x2B8FEA0;                         
            // 0x014296B8: LDR w0, [x8]               | W0 = 0x166C;                            
            // 0x014296BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x166C, ????);     
            // 0x014296C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014296C4: STRB w8, [x20, #0xb]       | static_value_0373700B = true;            //  dest_result_addr=57896971
            label_0:
            // 0x014296C8: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x014296CC: LDR x19, [x19]             | X19 = X1;                               
            // 0x014296D0: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x014296D4: CBZ x19, #0x1429728        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x014296D8: LDR x8, [x19]              | X8 = X1;                                
            // 0x014296DC: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x014296E0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x014296E4: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014296E8: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014296EC: B.LO #0x1429704            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x014296F0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x014296F4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014296F8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014296FC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429700: B.EQ #0x142972c            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429704: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429708: ADD x8, sp, #0x10          | X8 = (1152921510102543024 + 16) = 1152921510102543040 (0x100000014791AAC0);
            // 0x0142970C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01429710: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510102531088]
            // 0x01429714: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142971C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01429720: ADD x0, sp, #0x10          | X0 = (1152921510102543024 + 16) = 1152921510102543040 (0x100000014791AAC0);
            // 0x01429724: BL #0x299a140              | 
            label_1:
            // 0x01429728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014791AAC0, ????);
            label_3:
            // 0x0142972C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429730: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429734: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429738: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142973C: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429740: B.LO #0x1429784            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01429744: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01429748: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0142974C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429750: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429754: B.NE #0x1429784            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01429758: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x0142975C: LDR w8, [x19, #0x30]       | W8 = X1 + 48;                           
            // 0x01429760: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x01429764: ADD x1, sp, #0xc           | X1 = (1152921510102543024 + 12) = 1152921510102543036 (0x100000014791AABC);
            // 0x01429768: STR w8, [sp, #0xc]         | stack[1152921510102543036] = X1 + 48;    //  dest_result_addr=1152921510102543036
            // 0x0142976C: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x01429770: BL #0x27bc028              | X0 = 1152921510102591104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 48);
            // 0x01429774: SUB sp, x29, #0x10         | SP = (1152921510102543072 - 16) = 1152921510102543056 (0x100000014791AAD0);
            // 0x01429778: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0142977C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01429780: RET                        |  return (System.Object)X1 + 48;         
            return (object)X1 + 48;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01429784: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429788: ADD x8, sp, #0x18          | X8 = (1152921510102543024 + 24) = 1152921510102543048 (0x100000014791AAC8);
            // 0x0142978C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01429790: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510102531088]
            // 0x01429794: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142979C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014297A0: ADD x0, sp, #0x18          | X0 = (1152921510102543024 + 24) = 1152921510102543048 (0x100000014791AAC8);
            // 0x014297A4: BL #0x299a140              | 
            // 0x014297A8: MOV x19, x0                | X19 = 1152921510102543048 (0x100000014791AAC8);//ML01
            // 0x014297AC: ADD x0, sp, #0x10          | X0 = (1152921510102543024 + 16) = 1152921510102543040 (0x100000014791AAC0);
            label_6:
            // 0x014297B0: BL #0x299a140              | 
            // 0x014297B4: MOV x0, x19                | X0 = 1152921510102543048 (0x100000014791AAC8);//ML01
            // 0x014297B8: BL #0x980800               | X0 = sub_980800( ?? 0x100000014791AAC8, ????);
            // 0x014297BC: MOV x19, x0                | X19 = 1152921510102543048 (0x100000014791AAC8);//ML01
            // 0x014297C0: ADD x0, sp, #0x18          | X0 = (1152921510102543024 + 24) = 1152921510102543048 (0x100000014791AAC8);
            // 0x014297C4: B #0x14297b0               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014297C8 (21141448), len: 412  VirtAddr: 0x014297C8 RVA: 0x014297C8 token: 100664106 methodIndex: 30151 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_less_speed_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x014297C8: STP x22, x21, [sp, #-0x30]! | stack[1152921510102671264] = ???;  stack[1152921510102671272] = ???;  //  dest_result_addr=1152921510102671264 |  dest_result_addr=1152921510102671272
            // 0x014297CC: STP x20, x19, [sp, #0x10]  | stack[1152921510102671280] = ???;  stack[1152921510102671288] = ???;  //  dest_result_addr=1152921510102671280 |  dest_result_addr=1152921510102671288
            // 0x014297D0: STP x29, x30, [sp, #0x20]  | stack[1152921510102671296] = ???;  stack[1152921510102671304] = ???;  //  dest_result_addr=1152921510102671296 |  dest_result_addr=1152921510102671304
            // 0x014297D4: ADD x29, sp, #0x20         | X29 = (1152921510102671264 + 32) = 1152921510102671296 (0x1000000147939FC0);
            // 0x014297D8: SUB sp, sp, #0x20          | SP = (1152921510102671264 - 32) = 1152921510102671232 (0x1000000147939F80);
            // 0x014297DC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x014297E0: LDRB w8, [x21, #0xc]       | W8 = (bool)static_value_0373700C;       
            // 0x014297E4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x014297E8: MOV x20, x1                | X20 = v;//m1                            
            // 0x014297EC: TBNZ w8, #0, #0x1429808    | if (static_value_0373700C == true) goto label_0;
            // 0x014297F0: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x014297F4: LDR x8, [x8, #0xc0]        | X8 = 0x2B8FED0;                         
            // 0x014297F8: LDR w0, [x8]               | W0 = 0x1678;                            
            // 0x014297FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1678, ????);     
            // 0x01429800: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429804: STRB w8, [x21, #0xc]       | static_value_0373700C = true;            //  dest_result_addr=57896972
            label_0:
            // 0x01429808: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x0142980C: CBZ x21, #0x14298c0        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01429810: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01429814: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01429818: LDR x8, [x21]              | X8 = ;                                  
            // 0x0142981C: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429820: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429824: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429828: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0142982C: B.LO #0x1429844            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01429830: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429834: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429838: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0142983C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429840: B.EQ #0x142986c            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429844: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429848: ADD x8, sp, #8             | X8 = (1152921510102671232 + 8) = 1152921510102671240 (0x1000000147939F88);
            // 0x0142984C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01429850: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510102659312]
            // 0x01429854: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142985C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01429860: ADD x0, sp, #8             | X0 = (1152921510102671232 + 8) = 1152921510102671240 (0x1000000147939F88);
            // 0x01429864: BL #0x299a140              | 
            // 0x01429868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147939F88, ????);
            label_3:
            // 0x0142986C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01429870: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429874: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429878: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0142987C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429880: B.LO #0x1429898            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01429884: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429888: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0142988C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429890: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429894: B.EQ #0x14298c8            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01429898: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0142989C: ADD x8, sp, #0x10          | X8 = (1152921510102671232 + 16) = 1152921510102671248 (0x1000000147939F90);
            // 0x014298A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014298A4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510102659312]
            // 0x014298A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014298AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014298B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014298B4: ADD x0, sp, #0x10          | X0 = (1152921510102671232 + 16) = 1152921510102671248 (0x1000000147939F90);
            // 0x014298B8: BL #0x299a140              | 
            // 0x014298BC: B #0x14298c4               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x014298C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1678, ????);     
            label_6:
            // 0x014298C4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x014298C8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x014298CC: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x014298D0: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x014298D4: CBNZ x19, #0x14298dc       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x014298D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1678, ????);     
            label_7:
            // 0x014298DC: LDR x8, [x19]              | X8 = X2;                                
            // 0x014298E0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x014298E4: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x014298E8: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x014298EC: B.NE #0x1429934            | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x014298F0: MOV x0, x19                | X0 = X2;//m1                            
            // 0x014298F4: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x014298F8: LDR w8, [x0]               | W8 = X2;                                
            // 0x014298FC: STR w8, [x21, #0x30]       | mem[48] = X2;                            //  dest_result_addr=48
            mem[48] = X2;
            // 0x01429900: SUB sp, x29, #0x20         | SP = (1152921510102671296 - 32) = 1152921510102671264 (0x1000000147939FA0);
            // 0x01429904: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01429908: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0142990C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01429910: RET                        |  return;                                
            return;
            // 0x01429914: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01429918: ADD x0, sp, #8             | X0 = (1152921510102671312 + 8) = 1152921510102671320 (0x1000000147939FD8);
            // 0x0142991C: B #0x1429928               |  goto label_10;                         
            goto label_10;
            // 0x01429920: MOV x19, x0                | X19 = 1152921510102671320 (0x1000000147939FD8);//ML01
            val_7;
            // 0x01429924: ADD x0, sp, #0x10          | X0 = (1152921510102671312 + 16) = 1152921510102671328 (0x1000000147939FE0);
            label_10:
            // 0x01429928: BL #0x299a140              | 
            // 0x0142992C: MOV x0, x19                | X0 = 1152921510102671320 (0x1000000147939FD8);//ML01
            // 0x01429930: BL #0x980800               | X0 = sub_980800( ?? 0x1000000147939FD8, ????);
            label_8:
            // 0x01429934: ADD x8, sp, #0x18          | X8 = (1152921510102671312 + 24) = 1152921510102671336 (0x1000000147939FE8);
            // 0x01429938: MOV x1, x20                | X1 = X20;//m1                           
            // 0x0142993C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000147939FD8, ????);
            // 0x01429940: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510102659312]
            // 0x01429944: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01429948: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0142994C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01429950: ADD x0, sp, #0x18          | X0 = (1152921510102671312 + 24) = 1152921510102671336 (0x1000000147939FE8);
            // 0x01429954: BL #0x299a140              | 
            // 0x01429958: MOV x19, x0                | X19 = 1152921510102671336 (0x1000000147939FE8);//ML01
            // 0x0142995C: ADD x0, sp, #0x18          | X0 = (1152921510102671312 + 24) = 1152921510102671336 (0x1000000147939FE8);
            // 0x01429960: B #0x1429928               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429964 (21141860), len: 312  VirtAddr: 0x01429964 RVA: 0x01429964 token: 100664107 methodIndex: 30152 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_UsingSumTime_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01429964: STP x20, x19, [sp, #-0x20]! | stack[1152921510102799504] = ???;  stack[1152921510102799512] = ???;  //  dest_result_addr=1152921510102799504 |  dest_result_addr=1152921510102799512
            // 0x01429968: STP x29, x30, [sp, #0x10]  | stack[1152921510102799520] = ???;  stack[1152921510102799528] = ???;  //  dest_result_addr=1152921510102799520 |  dest_result_addr=1152921510102799528
            // 0x0142996C: ADD x29, sp, #0x10         | X29 = (1152921510102799504 + 16) = 1152921510102799520 (0x10000001479594A0);
            // 0x01429970: SUB sp, sp, #0x20          | SP = (1152921510102799504 - 32) = 1152921510102799472 (0x1000000147959470);
            // 0x01429974: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01429978: LDRB w8, [x20, #0xd]       | W8 = (bool)static_value_0373700D;       
            // 0x0142997C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01429980: TBNZ w8, #0, #0x142999c    | if (static_value_0373700D == true) goto label_0;
            // 0x01429984: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x01429988: LDR x8, [x8, #0x440]       | X8 = 0x2B8FEB0;                         
            // 0x0142998C: LDR w0, [x8]               | W0 = 0x1670;                            
            // 0x01429990: BL #0x2782188              | X0 = sub_2782188( ?? 0x1670, ????);     
            // 0x01429994: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429998: STRB w8, [x20, #0xd]       | static_value_0373700D = true;            //  dest_result_addr=57896973
            label_0:
            // 0x0142999C: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x014299A0: LDR x19, [x19]             | X19 = X1;                               
            // 0x014299A4: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x014299A8: CBZ x19, #0x14299fc        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x014299AC: LDR x8, [x19]              | X8 = X1;                                
            // 0x014299B0: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x014299B4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x014299B8: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014299BC: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014299C0: B.LO #0x14299d8            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x014299C4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x014299C8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014299CC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014299D0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x014299D4: B.EQ #0x1429a00            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x014299D8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014299DC: ADD x8, sp, #0x10          | X8 = (1152921510102799472 + 16) = 1152921510102799488 (0x1000000147959480);
            // 0x014299E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014299E4: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510102787536]
            // 0x014299E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x014299EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014299F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014299F4: ADD x0, sp, #0x10          | X0 = (1152921510102799472 + 16) = 1152921510102799488 (0x1000000147959480);
            // 0x014299F8: BL #0x299a140              | 
            label_1:
            // 0x014299FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147959480, ????);
            label_3:
            // 0x01429A00: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429A04: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429A08: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429A0C: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429A10: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429A14: B.LO #0x1429a58            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01429A18: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01429A1C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429A20: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429A24: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429A28: B.NE #0x1429a58            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01429A2C: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x01429A30: LDR w8, [x19, #0x34]       | W8 = X1 + 52;                           
            // 0x01429A34: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x01429A38: ADD x1, sp, #0xc           | X1 = (1152921510102799472 + 12) = 1152921510102799484 (0x100000014795947C);
            // 0x01429A3C: STR w8, [sp, #0xc]         | stack[1152921510102799484] = X1 + 52;    //  dest_result_addr=1152921510102799484
            // 0x01429A40: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x01429A44: BL #0x27bc028              | X0 = 1152921510102847552 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 52);
            // 0x01429A48: SUB sp, x29, #0x10         | SP = (1152921510102799520 - 16) = 1152921510102799504 (0x1000000147959490);
            // 0x01429A4C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01429A50: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01429A54: RET                        |  return (System.Object)X1 + 52;         
            return (object)X1 + 52;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01429A58: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429A5C: ADD x8, sp, #0x18          | X8 = (1152921510102799472 + 24) = 1152921510102799496 (0x1000000147959488);
            // 0x01429A60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01429A64: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510102787536]
            // 0x01429A68: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429A70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01429A74: ADD x0, sp, #0x18          | X0 = (1152921510102799472 + 24) = 1152921510102799496 (0x1000000147959488);
            // 0x01429A78: BL #0x299a140              | 
            // 0x01429A7C: MOV x19, x0                | X19 = 1152921510102799496 (0x1000000147959488);//ML01
            // 0x01429A80: ADD x0, sp, #0x10          | X0 = (1152921510102799472 + 16) = 1152921510102799488 (0x1000000147959480);
            label_6:
            // 0x01429A84: BL #0x299a140              | 
            // 0x01429A88: MOV x0, x19                | X0 = 1152921510102799496 (0x1000000147959488);//ML01
            // 0x01429A8C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000147959488, ????);
            // 0x01429A90: MOV x19, x0                | X19 = 1152921510102799496 (0x1000000147959488);//ML01
            // 0x01429A94: ADD x0, sp, #0x18          | X0 = (1152921510102799472 + 24) = 1152921510102799496 (0x1000000147959488);
            // 0x01429A98: B #0x1429a84               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429A9C (21142172), len: 412  VirtAddr: 0x01429A9C RVA: 0x01429A9C token: 100664108 methodIndex: 30153 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_UsingSumTime_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01429A9C: STP x22, x21, [sp, #-0x30]! | stack[1152921510102927712] = ???;  stack[1152921510102927720] = ???;  //  dest_result_addr=1152921510102927712 |  dest_result_addr=1152921510102927720
            // 0x01429AA0: STP x20, x19, [sp, #0x10]  | stack[1152921510102927728] = ???;  stack[1152921510102927736] = ???;  //  dest_result_addr=1152921510102927728 |  dest_result_addr=1152921510102927736
            // 0x01429AA4: STP x29, x30, [sp, #0x20]  | stack[1152921510102927744] = ???;  stack[1152921510102927752] = ???;  //  dest_result_addr=1152921510102927744 |  dest_result_addr=1152921510102927752
            // 0x01429AA8: ADD x29, sp, #0x20         | X29 = (1152921510102927712 + 32) = 1152921510102927744 (0x1000000147978980);
            // 0x01429AAC: SUB sp, sp, #0x20          | SP = (1152921510102927712 - 32) = 1152921510102927680 (0x1000000147978940);
            // 0x01429AB0: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01429AB4: LDRB w8, [x21, #0xe]       | W8 = (bool)static_value_0373700E;       
            // 0x01429AB8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01429ABC: MOV x20, x1                | X20 = v;//m1                            
            // 0x01429AC0: TBNZ w8, #0, #0x1429adc    | if (static_value_0373700E == true) goto label_0;
            // 0x01429AC4: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x01429AC8: LDR x8, [x8, #0x470]       | X8 = 0x2B8FEE0;                         
            // 0x01429ACC: LDR w0, [x8]               | W0 = 0x167C;                            
            // 0x01429AD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x167C, ????);     
            // 0x01429AD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429AD8: STRB w8, [x21, #0xe]       | static_value_0373700E = true;            //  dest_result_addr=57896974
            label_0:
            // 0x01429ADC: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01429AE0: CBZ x21, #0x1429b94        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01429AE4: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01429AE8: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01429AEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x01429AF0: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429AF4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429AF8: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429AFC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429B00: B.LO #0x1429b18            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01429B04: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429B08: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429B0C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429B10: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429B14: B.EQ #0x1429b40            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429B18: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429B1C: ADD x8, sp, #8             | X8 = (1152921510102927680 + 8) = 1152921510102927688 (0x1000000147978948);
            // 0x01429B20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01429B24: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510102915760]
            // 0x01429B28: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429B2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429B30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01429B34: ADD x0, sp, #8             | X0 = (1152921510102927680 + 8) = 1152921510102927688 (0x1000000147978948);
            // 0x01429B38: BL #0x299a140              | 
            // 0x01429B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147978948, ????);
            label_3:
            // 0x01429B40: LDR x8, [x21]              | X8 = ;                                  
            // 0x01429B44: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429B48: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429B4C: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429B50: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429B54: B.LO #0x1429b6c            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01429B58: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429B5C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429B60: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429B64: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429B68: B.EQ #0x1429b9c            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01429B6C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429B70: ADD x8, sp, #0x10          | X8 = (1152921510102927680 + 16) = 1152921510102927696 (0x1000000147978950);
            // 0x01429B74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01429B78: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510102915760]
            // 0x01429B7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429B84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01429B88: ADD x0, sp, #0x10          | X0 = (1152921510102927680 + 16) = 1152921510102927696 (0x1000000147978950);
            // 0x01429B8C: BL #0x299a140              | 
            // 0x01429B90: B #0x1429b98               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01429B94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167C, ????);     
            label_6:
            // 0x01429B98: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x01429B9C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01429BA0: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x01429BA4: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x01429BA8: CBNZ x19, #0x1429bb0       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x01429BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x167C, ????);     
            label_7:
            // 0x01429BB0: LDR x8, [x19]              | X8 = X2;                                
            // 0x01429BB4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01429BB8: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x01429BBC: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x01429BC0: B.NE #0x1429c08            | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x01429BC4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01429BC8: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x01429BCC: LDR w8, [x0]               | W8 = X2;                                
            // 0x01429BD0: STR w8, [x21, #0x34]       | mem[52] = X2;                            //  dest_result_addr=52
            mem[52] = X2;
            // 0x01429BD4: SUB sp, x29, #0x20         | SP = (1152921510102927744 - 32) = 1152921510102927712 (0x1000000147978960);
            // 0x01429BD8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01429BDC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01429BE0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01429BE4: RET                        |  return;                                
            return;
            // 0x01429BE8: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01429BEC: ADD x0, sp, #8             | X0 = (1152921510102927760 + 8) = 1152921510102927768 (0x1000000147978998);
            // 0x01429BF0: B #0x1429bfc               |  goto label_10;                         
            goto label_10;
            // 0x01429BF4: MOV x19, x0                | X19 = 1152921510102927768 (0x1000000147978998);//ML01
            val_7;
            // 0x01429BF8: ADD x0, sp, #0x10          | X0 = (1152921510102927760 + 16) = 1152921510102927776 (0x10000001479789A0);
            label_10:
            // 0x01429BFC: BL #0x299a140              | 
            // 0x01429C00: MOV x0, x19                | X0 = 1152921510102927768 (0x1000000147978998);//ML01
            // 0x01429C04: BL #0x980800               | X0 = sub_980800( ?? 0x1000000147978998, ????);
            label_8:
            // 0x01429C08: ADD x8, sp, #0x18          | X8 = (1152921510102927760 + 24) = 1152921510102927784 (0x10000001479789A8);
            // 0x01429C0C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x01429C10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000147978998, ????);
            // 0x01429C14: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510102915760]
            // 0x01429C18: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01429C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429C20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01429C24: ADD x0, sp, #0x18          | X0 = (1152921510102927760 + 24) = 1152921510102927784 (0x10000001479789A8);
            // 0x01429C28: BL #0x299a140              | 
            // 0x01429C2C: MOV x19, x0                | X19 = 1152921510102927784 (0x10000001479789A8);//ML01
            // 0x01429C30: ADD x0, sp, #0x18          | X0 = (1152921510102927760 + 24) = 1152921510102927784 (0x10000001479789A8);
            // 0x01429C34: B #0x1429bfc               |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429C38 (21142584), len: 288  VirtAddr: 0x01429C38 RVA: 0x01429C38 token: 100664109 methodIndex: 30154 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_onClick_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01429C38: STP x20, x19, [sp, #-0x20]! | stack[1152921510103051856] = ???;  stack[1152921510103051864] = ???;  //  dest_result_addr=1152921510103051856 |  dest_result_addr=1152921510103051864
            // 0x01429C3C: STP x29, x30, [sp, #0x10]  | stack[1152921510103051872] = ???;  stack[1152921510103051880] = ???;  //  dest_result_addr=1152921510103051872 |  dest_result_addr=1152921510103051880
            // 0x01429C40: ADD x29, sp, #0x10         | X29 = (1152921510103051856 + 16) = 1152921510103051872 (0x1000000147996E60);
            // 0x01429C44: SUB sp, sp, #0x10          | SP = (1152921510103051856 - 16) = 1152921510103051840 (0x1000000147996E40);
            // 0x01429C48: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01429C4C: LDRB w8, [x20, #0xf]       | W8 = (bool)static_value_0373700F;       
            // 0x01429C50: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01429C54: TBNZ w8, #0, #0x1429c70    | if (static_value_0373700F == true) goto label_0;
            // 0x01429C58: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x01429C5C: LDR x8, [x8, #0x2a8]       | X8 = 0x2B8FEA4;                         
            // 0x01429C60: LDR w0, [x8]               | W0 = 0x166D;                            
            // 0x01429C64: BL #0x2782188              | X0 = sub_2782188( ?? 0x166D, ????);     
            // 0x01429C68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429C6C: STRB w8, [x20, #0xf]       | static_value_0373700F = true;            //  dest_result_addr=57896975
            label_0:
            // 0x01429C70: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
            // 0x01429C74: LDR x19, [x19]             | X19 = X1;                               
            // 0x01429C78: LDR x20, [x20, #0xe8]      | X20 = 1152921504925163520;              
            // 0x01429C7C: CBZ x19, #0x1429cd0        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01429C80: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429C84: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429C88: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429C8C: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429C90: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429C94: B.LO #0x1429cac            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01429C98: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01429C9C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429CA0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429CA4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429CA8: B.EQ #0x1429cd4            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429CAC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429CB0: MOV x8, sp                 | X8 = 1152921510103051840 (0x1000000147996E40);//ML01
            // 0x01429CB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01429CB8: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510103039888]
            // 0x01429CBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429CC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429CC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01429CC8: MOV x0, sp                 | X0 = 1152921510103051840 (0x1000000147996E40);//ML01
            // 0x01429CCC: BL #0x299a140              | 
            label_1:
            // 0x01429CD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000147996E40, ????);
            label_3:
            // 0x01429CD4: LDR x8, [x19]              | X8 = X1;                                
            // 0x01429CD8: LDR x1, [x20]              | X1 = typeof(ButtonClickState);          
            // 0x01429CDC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01429CE0: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429CE4: CMP w10, w9                | STATE = COMPARE(X1 + 260, ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429CE8: B.LO #0x1429d14            | if (X1 + 260 < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01429CEC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01429CF0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429CF4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429CF8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429CFC: B.NE #0x1429d14            | if ((X1 + 176 + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01429D00: LDR x0, [x19, #0x50]       | X0 = X1 + 80;                           
            // 0x01429D04: SUB sp, x29, #0x10         | SP = (1152921510103051872 - 16) = 1152921510103051856 (0x1000000147996E50);
            // 0x01429D08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01429D0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01429D10: RET                        |  return (System.Object)X1 + 80;         
            return (object)X1 + 80;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01429D14: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01429D18: ADD x8, sp, #8             | X8 = (1152921510103051840 + 8) = 1152921510103051848 (0x1000000147996E48);
            // 0x01429D1C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01429D20: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510103039888]
            // 0x01429D24: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429D2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01429D30: ADD x0, sp, #8             | X0 = (1152921510103051840 + 8) = 1152921510103051848 (0x1000000147996E48);
            // 0x01429D34: BL #0x299a140              | 
            // 0x01429D38: MOV x19, x0                | X19 = 1152921510103051848 (0x1000000147996E48);//ML01
            // 0x01429D3C: MOV x0, sp                 | X0 = 1152921510103051840 (0x1000000147996E40);//ML01
            label_6:
            // 0x01429D40: BL #0x299a140              | 
            // 0x01429D44: MOV x0, x19                | X0 = 1152921510103051848 (0x1000000147996E48);//ML01
            // 0x01429D48: BL #0x980800               | X0 = sub_980800( ?? 0x1000000147996E48, ????);
            // 0x01429D4C: MOV x19, x0                | X19 = 1152921510103051848 (0x1000000147996E48);//ML01
            // 0x01429D50: ADD x0, sp, #8             | X0 = (1152921510103051840 + 8) = 1152921510103051848 (0x1000000147996E48);
            // 0x01429D54: B #0x1429d40               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01429D58 (21142872), len: 392  VirtAddr: 0x01429D58 RVA: 0x01429D58 token: 100664110 methodIndex: 30155 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_onClick_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01429D58: STP x22, x21, [sp, #-0x30]! | stack[1152921510103175968] = ???;  stack[1152921510103175976] = ???;  //  dest_result_addr=1152921510103175968 |  dest_result_addr=1152921510103175976
            // 0x01429D5C: STP x20, x19, [sp, #0x10]  | stack[1152921510103175984] = ???;  stack[1152921510103175992] = ???;  //  dest_result_addr=1152921510103175984 |  dest_result_addr=1152921510103175992
            // 0x01429D60: STP x29, x30, [sp, #0x20]  | stack[1152921510103176000] = ???;  stack[1152921510103176008] = ???;  //  dest_result_addr=1152921510103176000 |  dest_result_addr=1152921510103176008
            // 0x01429D64: ADD x29, sp, #0x20         | X29 = (1152921510103175968 + 32) = 1152921510103176000 (0x10000001479B5340);
            // 0x01429D68: SUB sp, sp, #0x20          | SP = (1152921510103175968 - 32) = 1152921510103175936 (0x10000001479B5300);
            // 0x01429D6C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01429D70: LDRB w8, [x21, #0x10]      | W8 = (bool)static_value_03737010;       
            // 0x01429D74: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x01429D78: MOV x20, x1                | X20 = v;//m1                            
            // 0x01429D7C: TBNZ w8, #0, #0x1429d98    | if (static_value_03737010 == true) goto label_0;
            // 0x01429D80: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x01429D84: LDR x8, [x8, #0x68]        | X8 = 0x2B8FED4;                         
            // 0x01429D88: LDR w0, [x8]               | W0 = 0x1679;                            
            // 0x01429D8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1679, ????);     
            // 0x01429D90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01429D94: STRB w8, [x21, #0x10]      | static_value_03737010 = true;            //  dest_result_addr=57896976
            label_0:
            // 0x01429D98: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01429D9C: CBZ x20, #0x1429e50        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01429DA0: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
            // 0x01429DA4: LDR x21, [x21, #0xe8]      | X21 = 1152921504925163520;              
            val_6 = 1152921504925163520;
            // 0x01429DA8: LDR x8, [x20]              | X8 = ;                                  
            // 0x01429DAC: LDR x1, [x21]              | X1 = typeof(ButtonClickState);          
            // 0x01429DB0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429DB4: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429DB8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429DBC: B.LO #0x1429dd4            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01429DC0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429DC4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429DC8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429DCC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429DD0: B.EQ #0x1429dfc            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01429DD4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429DD8: ADD x8, sp, #8             | X8 = (1152921510103175936 + 8) = 1152921510103175944 (0x10000001479B5308);
            // 0x01429DDC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01429DE0: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510103164016]
            // 0x01429DE4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01429DE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429DEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01429DF0: ADD x0, sp, #8             | X0 = (1152921510103175936 + 8) = 1152921510103175944 (0x10000001479B5308);
            // 0x01429DF4: BL #0x299a140              | 
            // 0x01429DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001479B5308, ????);
            label_3:
            // 0x01429DFC: LDR x8, [x20]              | X8 = ;                                  
            // 0x01429E00: LDR x1, [x21]              | X1 = typeof(ButtonClickState);          
            // 0x01429E04: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01429E08: LDRB w9, [x1, #0x104]      | W9 = ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01429E0C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01429E10: B.LO #0x1429e28            | if (mem[null + 260] < ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01429E14: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01429E18: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01429E1C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01429E20: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ButtonClickState))
            // 0x01429E24: B.EQ #0x1429e58            | if ((mem[null + 176] + (ButtonClickState.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x01429E28: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01429E2C: ADD x8, sp, #0x10          | X8 = (1152921510103175936 + 16) = 1152921510103175952 (0x10000001479B5310);
            // 0x01429E30: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01429E34: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510103164016]
            // 0x01429E38: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01429E3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429E40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01429E44: ADD x0, sp, #0x10          | X0 = (1152921510103175936 + 16) = 1152921510103175952 (0x10000001479B5310);
            // 0x01429E48: BL #0x299a140              | 
            // 0x01429E4C: B #0x1429e54               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x01429E50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1679, ????);     
            label_6:
            // 0x01429E54: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x01429E58: CBZ x19, #0x1429e98        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x01429E5C: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x01429E60: LDR x8, [x8, #0xba8]       | X8 = 1152921504925216768;               
            // 0x01429E64: LDR x1, [x8]               | X1 = typeof(ButtonClickState.VoidDelegate);
            // 0x01429E68: LDR x8, [x19]              | X8 = X2;                                
            // 0x01429E6C: CMP x8, x1                 | STATE = COMPARE(X2, typeof(ButtonClickState.VoidDelegate))
            // 0x01429E70: B.EQ #0x1429e9c            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x01429E74: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01429E78: ADD x8, sp, #0x18          | X8 = (1152921510103175936 + 24) = 1152921510103175960 (0x10000001479B5318);
            // 0x01429E7C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01429E80: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510103164016]
            // 0x01429E84: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x01429E88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01429E8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x01429E90: ADD x0, sp, #0x18          | X0 = (1152921510103175936 + 24) = 1152921510103175960 (0x10000001479B5318);
            // 0x01429E94: BL #0x299a140              | 
            label_7:
            // 0x01429E98: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x01429E9C: STR x19, [x20, #0x50]      | mem[80] = 0x0;                           //  dest_result_addr=80
            mem[80] = val_7;
            // 0x01429EA0: SUB sp, x29, #0x20         | SP = (1152921510103176000 - 32) = 1152921510103175968 (0x10000001479B5320);
            // 0x01429EA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01429EA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01429EAC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01429EB0: RET                        |  return;                                
            return;
            // 0x01429EB4: MOV x19, x0                | 
            // 0x01429EB8: ADD x0, sp, #8             | 
            // 0x01429EBC: B #0x1429ed4               | 
            // 0x01429EC0: MOV x19, x0                | 
            // 0x01429EC4: ADD x0, sp, #0x10          | 
            // 0x01429EC8: B #0x1429ed4               | 
            // 0x01429ECC: MOV x19, x0                | 
            // 0x01429ED0: ADD x0, sp, #0x18          | 
            label_10:
            // 0x01429ED4: BL #0x299a140              | 
            // 0x01429ED8: MOV x0, x19                | 
            // 0x01429EDC: BL #0x980800               | 
        
        }
    
    }

}
