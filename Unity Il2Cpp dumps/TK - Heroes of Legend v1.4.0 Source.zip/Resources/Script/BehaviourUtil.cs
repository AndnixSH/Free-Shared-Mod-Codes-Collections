using UnityEngine;
public class BehaviourUtil : MonoBehaviour
{
    // Fields
    private static UnityEngine.MonoBehaviour globalCoroutine; // static_offset: 0x00000000
    private static uint curID; // static_offset: 0x00000008
    private static System.Collections.Generic.Dictionary<uint, Mihua.Utils.WaitForSeconds> allWaitSecondDic; // static_offset: 0x00000010
    private static System.Collections.Generic.Dictionary<uint, System.Collections.IEnumerator> allCoroutineDic; // static_offset: 0x00000018
    private static System.Collections.Generic.List<Mihua.Utils.WaitForSeconds> allCoroutineList; // static_offset: 0x00000020
    
    // Properties
    public static UnityEngine.MonoBehaviour GlobalCoroutine { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8D638 (12113464), len: 8  VirtAddr: 0x00B8D638 RVA: 0x00B8D638 token: 100696535 methodIndex: 25091 delegateWrapperIndex: 0 methodInvoker: 0
    public BehaviourUtil()
    {
        //
        // Disasemble & Code
        // 0x00B8D638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D63C: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D640 (12113472), len: 248  VirtAddr: 0x00B8D640 RVA: 0x00B8D640 token: 100696536 methodIndex: 25092 delegateWrapperIndex: 0 methodInvoker: 0
    public void Update()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        int val_4;
        //  | 
        var val_5;
        // 0x00B8D640: STP x22, x21, [sp, #-0x30]! | stack[1152921515547321344] = ???;  stack[1152921515547321352] = ???;  //  dest_result_addr=1152921515547321344 |  dest_result_addr=1152921515547321352
        // 0x00B8D644: STP x20, x19, [sp, #0x10]  | stack[1152921515547321360] = ???;  stack[1152921515547321368] = ???;  //  dest_result_addr=1152921515547321360 |  dest_result_addr=1152921515547321368
        // 0x00B8D648: STP x29, x30, [sp, #0x20]  | stack[1152921515547321376] = ???;  stack[1152921515547321384] = ???;  //  dest_result_addr=1152921515547321376 |  dest_result_addr=1152921515547321384
        // 0x00B8D64C: ADD x29, sp, #0x20         | X29 = (1152921515547321344 + 32) = 1152921515547321376 (0x100000028C1A6420);
        // 0x00B8D650: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B8D654: LDRB w8, [x19, #0xa1a]     | W8 = (bool)static_value_03733A1A;       
        // 0x00B8D658: TBNZ w8, #0, #0xb8d674     | if (static_value_03733A1A == true) goto label_0;
        // 0x00B8D65C: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00B8D660: LDR x8, [x8, #0x4b8]       | X8 = 0x2B8F338;                         
        // 0x00B8D664: LDR w0, [x8]               | W0 = 0x1390;                            
        // 0x00B8D668: BL #0x2782188              | X0 = sub_2782188( ?? 0x1390, ????);     
        // 0x00B8D66C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D670: STRB w8, [x19, #0xa1a]     | static_value_03733A1A = true;            //  dest_result_addr=57883162
        label_0:
        // 0x00B8D674: ADRP x21, #0x365d000       | X21 = 57004032 (0x365D000);             
        // 0x00B8D678: LDR x21, [x21, #0x4b8]     | X21 = 1152921504922660864;              
        // 0x00B8D67C: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x00B8D680: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D684: TBZ w8, #0, #0xb8d698      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8D688: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D68C: CBNZ w8, #0xb8d698         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8D690: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D694: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x00B8D698: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D69C: LDR x19, [x8, #0x20]       | X19 = BehaviourUtil.allCoroutineList;   
        // 0x00B8D6A0: CBNZ x19, #0xb8d6a8        | if (BehaviourUtil.allCoroutineList != null) goto label_3;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_3;
        }
        // 0x00B8D6A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_3:
        // 0x00B8D6A8: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B8D6AC: LDR x8, [x8, #0x890]       | X8 = 1152921515547303248;               
        // 0x00B8D6B0: MOV x0, x19                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8D6B4: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::get_Count();
        // 0x00B8D6B8: BL #0x25ed72c              | X0 = BehaviourUtil.allCoroutineList.get_Count();
        int val_1 = BehaviourUtil.allCoroutineList.Count;
        // 0x00B8D6BC: SUB w19, w0, #1            | W19 = (val_1 - 1);                      
        val_4 = val_1 - 1;
        // 0x00B8D6C0: TBNZ w19, #0x1f, #0xb8d728 | if (((val_1 - 1) & 0x80000000) != 0) goto label_4;
        if((val_4 & 2147483648) != 0)
        {
            goto label_4;
        }
        // 0x00B8D6C4: ADRP x22, #0x35ff000       | X22 = 56619008 (0x35FF000);             
        // 0x00B8D6C8: LDR x22, [x22, #0x3d8]     | X22 = 1152921515547304272;              
        label_9:
        // 0x00B8D6CC: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_5 = null;
        // 0x00B8D6D0: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D6D4: TBZ w8, #0, #0xb8d6e8      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B8D6D8: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D6DC: CBNZ w8, #0xb8d6e8         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B8D6E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D6E4: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_5 = null;
        label_6:
        // 0x00B8D6E8: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D6EC: LDR x20, [x8, #0x20]       | X20 = BehaviourUtil.allCoroutineList;   
        // 0x00B8D6F0: CBNZ x20, #0xb8d6f8        | if (BehaviourUtil.allCoroutineList != null) goto label_7;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_7;
        }
        // 0x00B8D6F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_7:
        // 0x00B8D6F8: LDR x2, [x22]              | X2 = public Mihua.Utils.WaitForSeconds System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::get_Item(int index);
        // 0x00B8D6FC: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8D700: MOV w1, w19                | W1 = (val_1 - 1);//m1                   
        // 0x00B8D704: BL #0x25ed734              | X0 = BehaviourUtil.allCoroutineList.get_Item(index:  val_4);
        Mihua.Utils.WaitForSeconds val_2 = BehaviourUtil.allCoroutineList.Item[val_4];
        // 0x00B8D708: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B8D70C: CBNZ x20, #0xb8d714        | if (val_2 != null) goto label_8;        
        if(val_2 != null)
        {
            goto label_8;
        }
        // 0x00B8D710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B8D714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D718: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B8D71C: BL #0xac2bd0               | val_2.Update();                         
        val_2.Update();
        // 0x00B8D720: SUB w19, w19, #1           | W19 = ((val_1 - 1) - 1);                
        val_4 = val_4 - 1;
        // 0x00B8D724: TBZ w19, #0x1f, #0xb8d6cc  | if ((((val_1 - 1) - 1) & 0x80000000) == 0) goto label_9;
        if((val_4 & 2147483648) == 0)
        {
            goto label_9;
        }
        label_4:
        // 0x00B8D728: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D72C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D730: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D734: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D738 (12113720), len: 184  VirtAddr: 0x00B8D738 RVA: 0x00B8D738 token: 100696537 methodIndex: 25093 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.Coroutine StartCoroutine(System.Collections.IEnumerator routine, uint id)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00B8D738: STP x22, x21, [sp, #-0x30]! | stack[1152921515547446656] = ???;  stack[1152921515547446664] = ???;  //  dest_result_addr=1152921515547446656 |  dest_result_addr=1152921515547446664
        // 0x00B8D73C: STP x20, x19, [sp, #0x10]  | stack[1152921515547446672] = ???;  stack[1152921515547446680] = ???;  //  dest_result_addr=1152921515547446672 |  dest_result_addr=1152921515547446680
        // 0x00B8D740: STP x29, x30, [sp, #0x20]  | stack[1152921515547446688] = ???;  stack[1152921515547446696] = ???;  //  dest_result_addr=1152921515547446688 |  dest_result_addr=1152921515547446696
        // 0x00B8D744: ADD x29, sp, #0x20         | X29 = (1152921515547446656 + 32) = 1152921515547446688 (0x100000028C1C4DA0);
        // 0x00B8D748: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B8D74C: LDRB w8, [x21, #0xa1b]     | W8 = (bool)static_value_03733A1B;       
        // 0x00B8D750: MOV w20, w2                | W20 = W2;//m1                           
        // 0x00B8D754: MOV x19, x1                | X19 = id;//m1                           
        // 0x00B8D758: TBNZ w8, #0, #0xb8d774     | if (static_value_03733A1B == true) goto label_0;
        // 0x00B8D75C: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00B8D760: LDR x8, [x8, #0xb28]       | X8 = 0x2B8F324;                         
        // 0x00B8D764: LDR w0, [x8]               | W0 = 0x138B;                            
        // 0x00B8D768: BL #0x2782188              | X0 = sub_2782188( ?? 0x138B, ????);     
        // 0x00B8D76C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D770: STRB w8, [x21, #0xa1b]     | static_value_03733A1B = true;            //  dest_result_addr=57883163
        label_0:
        // 0x00B8D774: ADRP x21, #0x365d000       | X21 = 57004032 (0x365D000);             
        // 0x00B8D778: LDR x21, [x21, #0x4b8]     | X21 = 1152921504922660864;              
        // 0x00B8D77C: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_2 = null;
        // 0x00B8D780: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D784: TBZ w8, #0, #0xb8d798      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8D788: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D78C: CBNZ w8, #0xb8d798         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8D790: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D794: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_2 = null;
        label_2:
        // 0x00B8D798: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D79C: LDR x21, [x8, #0x18]       | X21 = BehaviourUtil.allCoroutineDic;    
        // 0x00B8D7A0: CBNZ x21, #0xb8d7a8        | if (BehaviourUtil.allCoroutineDic != null) goto label_3;
        if(BehaviourUtil.allCoroutineDic != null)
        {
            goto label_3;
        }
        // 0x00B8D7A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_3:
        // 0x00B8D7A8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x00B8D7AC: LDR x8, [x8, #8]           | X8 = 1152921515547429584;               
        // 0x00B8D7B0: MOV x0, x21                | X0 = BehaviourUtil.allCoroutineDic;//m1 
        // 0x00B8D7B4: MOV w1, w20                | W1 = W2;//m1                            
        // 0x00B8D7B8: MOV x2, x19                | X2 = id;//m1                            
        // 0x00B8D7BC: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>::Add(System.UInt32 key, System.Collections.IEnumerator value);
        // 0x00B8D7C0: BL #0x24a0774              | BehaviourUtil.allCoroutineDic.Add(key:  W2, value:  id);
        BehaviourUtil.allCoroutineDic.Add(key:  W2, value:  id);
        // 0x00B8D7C4: BL #0xb8d7f0               | X0 = BehaviourUtil.get_GlobalCoroutine();
        UnityEngine.MonoBehaviour val_1 = BehaviourUtil.GlobalCoroutine;
        // 0x00B8D7C8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8D7CC: CBNZ x20, #0xb8d7d4        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00B8D7D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B8D7D4: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B8D7D8: MOV x1, x19                | X1 = id;//m1                            
        // 0x00B8D7DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D7E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D7E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D7E8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D7EC: B #0x1b772bc               | return val_1.StartCoroutine(routine:  id);
        return val_1.StartCoroutine(routine:  id);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D914 (12114196), len: 120  VirtAddr: 0x00B8D914 RVA: 0x00B8D914 token: 100696538 methodIndex: 25094 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.Coroutine StartCoroutine(System.Collections.IEnumerator routine)
    {
        //
        // Disasemble & Code
        //  | 
        System.Collections.IEnumerator val_2;
        // 0x00B8D914: STP x20, x19, [sp, #-0x20]! | stack[1152921515547570960] = ???;  stack[1152921515547570968] = ???;  //  dest_result_addr=1152921515547570960 |  dest_result_addr=1152921515547570968
        // 0x00B8D918: STP x29, x30, [sp, #0x10]  | stack[1152921515547570976] = ???;  stack[1152921515547570984] = ???;  //  dest_result_addr=1152921515547570976 |  dest_result_addr=1152921515547570984
        // 0x00B8D91C: ADD x29, sp, #0x10         | X29 = (1152921515547570960 + 16) = 1152921515547570976 (0x100000028C1E3320);
        // 0x00B8D920: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8D924: LDRB w8, [x20, #0xa1c]     | W8 = (bool)static_value_03733A1C;       
        // 0x00B8D928: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B8D92C: TBNZ w8, #0, #0xb8d948     | if (static_value_03733A1C == true) goto label_0;
        // 0x00B8D930: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B8D934: LDR x8, [x8, #0x408]       | X8 = 0x2B8F320;                         
        // 0x00B8D938: LDR w0, [x8]               | W0 = 0x138A;                            
        // 0x00B8D93C: BL #0x2782188              | X0 = sub_2782188( ?? 0x138A, ????);     
        // 0x00B8D940: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D944: STRB w8, [x20, #0xa1c]     | static_value_03733A1C = true;            //  dest_result_addr=57883164
        label_0:
        // 0x00B8D948: ADRP x20, #0x365d000       | X20 = 57004032 (0x365D000);             
        // 0x00B8D94C: LDR x20, [x20, #0x4b8]     | X20 = 1152921504922660864;              
        // 0x00B8D950: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_2 = null;
        // 0x00B8D954: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D958: TBZ w8, #0, #0xb8d96c      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8D95C: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D960: CBNZ w8, #0xb8d96c         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8D964: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D968: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_2 = null;
        label_2:
        // 0x00B8D96C: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D970: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B8D974: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x00B8D978: ADD w2, w9, #1             | W2 = (BehaviourUtil.curID + 1);         
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x00B8D97C: STR w2, [x8, #8]           | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x00B8D980: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D984: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D988: B #0xb8d738                | return BehaviourUtil.StartCoroutine(routine:  val_2 = null, id:  X1);
        return BehaviourUtil.StartCoroutine(routine:  val_2, id:  X1);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D98C (12114316), len: 228  VirtAddr: 0x00B8D98C RVA: 0x00B8D98C token: 100696539 methodIndex: 25095 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.Coroutine StartCoroutine(Mihua.Utils.WaitForSeconds routine)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00B8D98C: STP x22, x21, [sp, #-0x30]! | stack[1152921515547697280] = ???;  stack[1152921515547697288] = ???;  //  dest_result_addr=1152921515547697280 |  dest_result_addr=1152921515547697288
        // 0x00B8D990: STP x20, x19, [sp, #0x10]  | stack[1152921515547697296] = ???;  stack[1152921515547697304] = ???;  //  dest_result_addr=1152921515547697296 |  dest_result_addr=1152921515547697304
        // 0x00B8D994: STP x29, x30, [sp, #0x20]  | stack[1152921515547697312] = ???;  stack[1152921515547697320] = ???;  //  dest_result_addr=1152921515547697312 |  dest_result_addr=1152921515547697320
        // 0x00B8D998: ADD x29, sp, #0x20         | X29 = (1152921515547697280 + 32) = 1152921515547697312 (0x100000028C2020A0);
        // 0x00B8D99C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8D9A0: LDRB w8, [x20, #0xa1d]     | W8 = (bool)static_value_03733A1D;       
        // 0x00B8D9A4: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B8D9A8: TBNZ w8, #0, #0xb8d9c4     | if (static_value_03733A1D == true) goto label_0;
        // 0x00B8D9AC: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00B8D9B0: LDR x8, [x8, #0x5d8]       | X8 = 0x2B8F328;                         
        // 0x00B8D9B4: LDR w0, [x8]               | W0 = 0x138C;                            
        // 0x00B8D9B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x138C, ????);     
        // 0x00B8D9BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D9C0: STRB w8, [x20, #0xa1d]     | static_value_03733A1D = true;            //  dest_result_addr=57883165
        label_0:
        // 0x00B8D9C4: ADRP x22, #0x365d000       | X22 = 57004032 (0x365D000);             
        // 0x00B8D9C8: LDR x22, [x22, #0x4b8]     | X22 = 1152921504922660864;              
        // 0x00B8D9CC: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_2 = null;
        // 0x00B8D9D0: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D9D4: TBZ w8, #0, #0xb8d9e8      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8D9D8: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D9DC: CBNZ w8, #0xb8d9e8         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8D9E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D9E4: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_2 = null;
        label_2:
        // 0x00B8D9E8: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D9EC: LDR x20, [x8, #0x10]       | X20 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8D9F0: LDR w21, [x8, #8]          | W21 = BehaviourUtil.curID;              
        // 0x00B8D9F4: CBNZ x20, #0xb8d9fc        | if (BehaviourUtil.allWaitSecondDic != null) goto label_3;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_3;
        }
        // 0x00B8D9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_3:
        // 0x00B8D9FC: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B8DA00: LDR x8, [x8, #0xaa8]       | X8 = 1152921515547679184;               
        // 0x00B8DA04: MOV x0, x20                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DA08: MOV w1, w21                | W1 = BehaviourUtil.curID;//m1           
        // 0x00B8DA0C: MOV x2, x19                | X2 = X1;//m1                            
        // 0x00B8DA10: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::Add(System.UInt32 key, Mihua.Utils.WaitForSeconds value);
        // 0x00B8DA14: BL #0x24a0774              | BehaviourUtil.allWaitSecondDic.Add(key:  BehaviourUtil.curID, value:  X1);
        BehaviourUtil.allWaitSecondDic.Add(key:  BehaviourUtil.curID, value:  X1);
        // 0x00B8DA18: LDR x8, [x22]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DA1C: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DA20: LDR x20, [x8, #0x20]       | X20 = BehaviourUtil.allCoroutineList;   
        // 0x00B8DA24: CBNZ x20, #0xb8da2c        | if (BehaviourUtil.allCoroutineList != null) goto label_4;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_4;
        }
        // 0x00B8DA28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BehaviourUtil.allWaitSecondDic, ????);
        label_4:
        // 0x00B8DA2C: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00B8DA30: LDR x8, [x8, #0x3f0]       | X8 = 1152921515547680208;               
        // 0x00B8DA34: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8DA38: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B8DA3C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::Add(Mihua.Utils.WaitForSeconds item);
        // 0x00B8DA40: BL #0x25ea480              | BehaviourUtil.allCoroutineList.Add(item:  X1);
        BehaviourUtil.allCoroutineList.Add(item:  X1);
        // 0x00B8DA44: BL #0xb8d7f0               | X0 = BehaviourUtil.get_GlobalCoroutine();
        UnityEngine.MonoBehaviour val_1 = BehaviourUtil.GlobalCoroutine;
        // 0x00B8DA48: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8DA4C: CBNZ x20, #0xb8da54        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00B8DA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B8DA54: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B8DA58: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B8DA5C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8DA60: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8DA64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8DA68: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8DA6C: B #0x1b772bc               | return val_1.StartCoroutine(routine:  X1);
        return val_1.StartCoroutine(routine:  X1);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8DA70 (12114544), len: 484  VirtAddr: 0x00B8DA70 RVA: 0x00B8DA70 token: 100696540 methodIndex: 25096 delegateWrapperIndex: 0 methodInvoker: 0
    public static void StopAllCoroutine()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        // 0x00B8DA70: STP x22, x21, [sp, #-0x30]! | stack[1152921515547829760] = ???;  stack[1152921515547829768] = ???;  //  dest_result_addr=1152921515547829760 |  dest_result_addr=1152921515547829768
        // 0x00B8DA74: STP x20, x19, [sp, #0x10]  | stack[1152921515547829776] = ???;  stack[1152921515547829784] = ???;  //  dest_result_addr=1152921515547829776 |  dest_result_addr=1152921515547829784
        // 0x00B8DA78: STP x29, x30, [sp, #0x20]  | stack[1152921515547829792] = ???;  stack[1152921515547829800] = ???;  //  dest_result_addr=1152921515547829792 |  dest_result_addr=1152921515547829800
        // 0x00B8DA7C: ADD x29, sp, #0x20         | X29 = (1152921515547829760 + 32) = 1152921515547829792 (0x100000028C222620);
        // 0x00B8DA80: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8DA84: LDRB w8, [x20, #0xa1e]     | W8 = (bool)static_value_03733A1E;       
        // 0x00B8DA88: TBZ w8, #0, #0xb8da94      | if (static_value_03733A1E == false) goto label_0;
        // 0x00B8DA8C: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x00B8DA90: B #0xb8dad0                |  goto label_2;                          
        goto label_2;
        label_0:
        // 0x00B8DA94: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
        // 0x00B8DA98: LDR x8, [x8, #0x5f8]       | X8 = 0x2B8F32C;                         
        // 0x00B8DA9C: LDR w0, [x8]               | W0 = 0x138D;                            
        // 0x00B8DAA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x138D, ????);     
        // 0x00B8DAA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8DAA8: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x00B8DAAC: STRB w8, [x20, #0xa1e]     | static_value_03733A1E = true;            //  dest_result_addr=57883166
        // 0x00B8DAB0: B #0xb8dad0                |  goto label_2;                          
        goto label_2;
        label_12:
        // 0x00B8DAB4: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B8DAB8: LDR x8, [x8, #0x920]       | X8 = 1152921515547805520;               
        // 0x00B8DABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8DAC0: MOV x1, x20                | X1 = 57880576 (0x3733000);//ML01        
        // 0x00B8DAC4: LDR x2, [x8]               | X2 = public static System.Void Mihua.Utils.ObjectPool<Mihua.Utils.WaitForSeconds>::Recycle(Mihua.Utils.WaitForSeconds obj);
        // 0x00B8DAC8: BL #0x19e5bbc              | Mihua.Utils.ObjectPool<BuffState>.Recycle(obj:  0);
        Mihua.Utils.ObjectPool<BuffState>.Recycle(obj:  0);
        // 0x00B8DACC: ADD w19, w19, #1           | W19 = (val_7 + 1) = val_7 (0x00000001); 
        val_7 = 1;
        label_2:
        // 0x00B8DAD0: ADRP x21, #0x365d000       | X21 = 57004032 (0x365D000);             
        // 0x00B8DAD4: LDR x21, [x21, #0x4b8]     | X21 = 1152921504922660864;              
        // 0x00B8DAD8: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_8 = null;
        // 0x00B8DADC: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DAE0: TBZ w8, #0, #0xb8daf4      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B8DAE4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DAE8: CBNZ w8, #0xb8daf4         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B8DAEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DAF0: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_8 = null;
        label_4:
        // 0x00B8DAF4: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DAF8: LDR x20, [x8, #0x20]       | X20 = BehaviourUtil.allCoroutineList;   
        // 0x00B8DAFC: CBNZ x20, #0xb8db04        | if (BehaviourUtil.allCoroutineList != null) goto label_5;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_5;
        }
        // 0x00B8DB00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_5:
        // 0x00B8DB04: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B8DB08: LDR x8, [x8, #0x890]       | X8 = 1152921515547303248;               
        // 0x00B8DB0C: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8DB10: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::get_Count();
        // 0x00B8DB14: BL #0x25ed72c              | X0 = BehaviourUtil.allCoroutineList.get_Count();
        int val_1 = BehaviourUtil.allCoroutineList.Count;
        // 0x00B8DB18: MOV w8, w0                 | W8 = val_1;//m1                         
        // 0x00B8DB1C: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_9 = null;
        // 0x00B8DB20: CMP w19, w8                | STATE = COMPARE(0x1, val_1)             
        // 0x00B8DB24: ADD x9, x0, #0x109         | X9 = (val_9 + 265) = 1152921504922661129 (0x1000000012D2F109);
        // 0x00B8DB28: LDRH w9, [x9]              | W9 = BehaviourUtil.__il2cppRuntimeField_109;
        // 0x00B8DB2C: AND w9, w9, #0x100         | W9 = (BehaviourUtil.__il2cppRuntimeField_109 & 256);
        // 0x00B8DB30: B.GE #0xb8dba0             | if (val_7 >= val_1) goto label_6;       
        if(val_7 >= val_1)
        {
            goto label_6;
        }
        // 0x00B8DB34: AND w8, w9, #0xffff        | W8 = ((BehaviourUtil.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00B8DB38: CBZ w8, #0xb8db4c          | if (((BehaviourUtil.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_8;
        // 0x00B8DB3C: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DB40: CBNZ w8, #0xb8db4c         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B8DB44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DB48: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_10 = null;
        label_8:
        // 0x00B8DB4C: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DB50: LDR x20, [x8, #0x20]       | X20 = BehaviourUtil.allCoroutineList;   
        // 0x00B8DB54: CBNZ x20, #0xb8db5c        | if (BehaviourUtil.allCoroutineList != null) goto label_9;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_9;
        }
        // 0x00B8DB58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_9:
        // 0x00B8DB5C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x00B8DB60: LDR x8, [x8, #0x3d8]       | X8 = 1152921515547304272;               
        // 0x00B8DB64: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8DB68: MOV w1, w19                | W1 = 1 (0x1);//ML01                     
        // 0x00B8DB6C: LDR x2, [x8]               | X2 = public Mihua.Utils.WaitForSeconds System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::get_Item(int index);
        // 0x00B8DB70: BL #0x25ed734              | X0 = BehaviourUtil.allCoroutineList.get_Item(index:  1);
        Mihua.Utils.WaitForSeconds val_4 = BehaviourUtil.allCoroutineList.Item[1];
        // 0x00B8DB74: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B8DB78: LDR x8, [x8, #0x478]       | X8 = 1152921504924311552;               
        // 0x00B8DB7C: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B8DB80: LDR x8, [x8]               | X8 = typeof(Mihua.Utils.ObjectPool<T>); 
        // 0x00B8DB84: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_10A;
        // 0x00B8DB88: TBZ w9, #0, #0xb8dab4      | if (Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B8DB8C: LDR w9, [x8, #0xbc]        | W9 = Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DB90: CBNZ w9, #0xb8dab4         | if (Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B8DB94: MOV x0, x8                 | X0 = 1152921504924311552 (0x1000000012EC2000);//ML01
        // 0x00B8DB98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Utils.ObjectPool<T>), ????);
        // 0x00B8DB9C: B #0xb8dab4                |  goto label_12;                         
        goto label_12;
        label_6:
        // 0x00B8DBA0: AND w8, w9, #0xffff        | W8 = ((BehaviourUtil.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00B8DBA4: CBZ w8, #0xb8dbb8          | if (((BehaviourUtil.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_14;
        // 0x00B8DBA8: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DBAC: CBNZ w8, #0xb8dbb8         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B8DBB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DBB4: LDR x0, [x21]              | X0 = typeof(BehaviourUtil);             
        val_11 = null;
        label_14:
        // 0x00B8DBB8: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DBBC: LDR x19, [x8, #0x10]       | X19 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DBC0: CBNZ x19, #0xb8dbc8        | if (BehaviourUtil.allWaitSecondDic != null) goto label_15;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_15;
        }
        // 0x00B8DBC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_15:
        // 0x00B8DBC8: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00B8DBCC: LDR x8, [x8, #0x450]       | X8 = 1152921515547810640;               
        // 0x00B8DBD0: MOV x0, x19                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DBD4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::Clear();
        // 0x00B8DBD8: BL #0x24a0c24              | BehaviourUtil.allWaitSecondDic.Clear(); 
        BehaviourUtil.allWaitSecondDic.Clear();
        // 0x00B8DBDC: LDR x8, [x21]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DBE0: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DBE4: LDR x19, [x8, #0x20]       | X19 = BehaviourUtil.allCoroutineList;   
        // 0x00B8DBE8: CBNZ x19, #0xb8dbf0        | if (BehaviourUtil.allCoroutineList != null) goto label_16;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_16;
        }
        // 0x00B8DBEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BehaviourUtil.allWaitSecondDic, ????);
        label_16:
        // 0x00B8DBF0: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x00B8DBF4: LDR x8, [x8, #0x6a0]       | X8 = 1152921515547811664;               
        // 0x00B8DBF8: MOV x0, x19                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8DBFC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::Clear();
        // 0x00B8DC00: BL #0x25ead28              | BehaviourUtil.allCoroutineList.Clear(); 
        BehaviourUtil.allCoroutineList.Clear();
        // 0x00B8DC04: LDR x8, [x21]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DC08: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DC0C: LDR x19, [x8, #0x18]       | X19 = BehaviourUtil.allCoroutineDic;    
        // 0x00B8DC10: CBNZ x19, #0xb8dc18        | if (BehaviourUtil.allCoroutineDic != null) goto label_17;
        if(BehaviourUtil.allCoroutineDic != null)
        {
            goto label_17;
        }
        // 0x00B8DC14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BehaviourUtil.allCoroutineList, ????);
        label_17:
        // 0x00B8DC18: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B8DC1C: LDR x8, [x8, #0x400]       | X8 = 1152921515547812688;               
        // 0x00B8DC20: MOV x0, x19                | X0 = BehaviourUtil.allCoroutineDic;//m1 
        // 0x00B8DC24: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>::Clear();
        // 0x00B8DC28: BL #0x24a0c24              | BehaviourUtil.allCoroutineDic.Clear();  
        BehaviourUtil.allCoroutineDic.Clear();
        // 0x00B8DC2C: BL #0xb8d7f0               | X0 = BehaviourUtil.get_GlobalCoroutine();
        UnityEngine.MonoBehaviour val_6 = BehaviourUtil.GlobalCoroutine;
        // 0x00B8DC30: MOV x19, x0                | X19 = val_6;//m1                        
        // 0x00B8DC34: CBNZ x19, #0xb8dc3c        | if (val_6 != null) goto label_18;       
        if(val_6 != null)
        {
            goto label_18;
        }
        // 0x00B8DC38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_18:
        // 0x00B8DC3C: MOV x0, x19                | X0 = val_6;//m1                         
        // 0x00B8DC40: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8DC44: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8DC48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8DC4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8DC50: B #0x1b77530               | val_6.StopAllCoroutines(); return;      
        val_6.StopAllCoroutines();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8DC54 (12115028), len: 664  VirtAddr: 0x00B8DC54 RVA: 0x00B8DC54 token: 100696541 methodIndex: 25097 delegateWrapperIndex: 0 methodInvoker: 0
    public static void StopCoroutine(uint id)
    {
        //
        // Disasemble & Code
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        // 0x00B8DC54: STP x24, x23, [sp, #-0x40]! | stack[1152921515547973488] = ???;  stack[1152921515547973496] = ???;  //  dest_result_addr=1152921515547973488 |  dest_result_addr=1152921515547973496
        // 0x00B8DC58: STP x22, x21, [sp, #0x10]  | stack[1152921515547973504] = ???;  stack[1152921515547973512] = ???;  //  dest_result_addr=1152921515547973504 |  dest_result_addr=1152921515547973512
        // 0x00B8DC5C: STP x20, x19, [sp, #0x20]  | stack[1152921515547973520] = ???;  stack[1152921515547973528] = ???;  //  dest_result_addr=1152921515547973520 |  dest_result_addr=1152921515547973528
        // 0x00B8DC60: STP x29, x30, [sp, #0x30]  | stack[1152921515547973536] = ???;  stack[1152921515547973544] = ???;  //  dest_result_addr=1152921515547973536 |  dest_result_addr=1152921515547973544
        // 0x00B8DC64: ADD x29, sp, #0x30         | X29 = (1152921515547973488 + 48) = 1152921515547973536 (0x100000028C2457A0);
        // 0x00B8DC68: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8DC6C: LDRB w8, [x20, #0xa1f]     | W8 = (bool)static_value_03733A1F;       
        // 0x00B8DC70: MOV w19, w1                | W19 = W1;//m1                           
        // 0x00B8DC74: TBNZ w8, #0, #0xb8dc90     | if (static_value_03733A1F == true) goto label_0;
        // 0x00B8DC78: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00B8DC7C: LDR x8, [x8, #0x188]       | X8 = 0x2B8F334;                         
        // 0x00B8DC80: LDR w0, [x8]               | W0 = 0x138F;                            
        // 0x00B8DC84: BL #0x2782188              | X0 = sub_2782188( ?? 0x138F, ????);     
        // 0x00B8DC88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8DC8C: STRB w8, [x20, #0xa1f]     | static_value_03733A1F = true;            //  dest_result_addr=57883167
        label_0:
        // 0x00B8DC90: ADRP x22, #0x365d000       | X22 = 57004032 (0x365D000);             
        // 0x00B8DC94: LDR x22, [x22, #0x4b8]     | X22 = 1152921504922660864;              
        // 0x00B8DC98: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_10 = null;
        // 0x00B8DC9C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DCA0: TBZ w8, #0, #0xb8dcb4      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8DCA4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DCA8: CBNZ w8, #0xb8dcb4         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8DCAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DCB0: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_10 = null;
        label_2:
        // 0x00B8DCB4: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DCB8: LDR x20, [x8, #0x18]       | X20 = BehaviourUtil.allCoroutineDic;    
        // 0x00B8DCBC: CBNZ x20, #0xb8dcc4        | if (BehaviourUtil.allCoroutineDic != null) goto label_3;
        if(BehaviourUtil.allCoroutineDic != null)
        {
            goto label_3;
        }
        // 0x00B8DCC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_3:
        // 0x00B8DCC4: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00B8DCC8: LDR x8, [x8, #0x8a0]       | X8 = 1152921515547938000;               
        // 0x00B8DCCC: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineDic;//m1 
        // 0x00B8DCD0: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DCD4: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>::ContainsKey(System.UInt32 key);
        // 0x00B8DCD8: BL #0x24a0ce8              | X0 = BehaviourUtil.allCoroutineDic.ContainsKey(key:  W1);
        bool val_1 = BehaviourUtil.allCoroutineDic.ContainsKey(key:  W1);
        // 0x00B8DCDC: TBZ w0, #0, #0xb8dd58      | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x00B8DCE0: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_11 = null;
        // 0x00B8DCE4: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DCE8: TBZ w8, #0, #0xb8dcfc      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B8DCEC: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DCF0: CBNZ w8, #0xb8dcfc         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B8DCF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DCF8: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_11 = null;
        label_6:
        // 0x00B8DCFC: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DD00: LDR x20, [x8, #0x18]       | X20 = BehaviourUtil.allCoroutineDic;    
        // 0x00B8DD04: CBNZ x20, #0xb8dd0c        | if (BehaviourUtil.allCoroutineDic != null) goto label_7;
        if(BehaviourUtil.allCoroutineDic != null)
        {
            goto label_7;
        }
        // 0x00B8DD08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_7:
        // 0x00B8DD0C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B8DD10: LDR x8, [x8, #0x908]       | X8 = 1152921515547939024;               
        // 0x00B8DD14: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineDic;//m1 
        // 0x00B8DD18: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DD1C: LDR x2, [x8]               | X2 = public System.Collections.IEnumerator System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>::get_Item(System.UInt32 key);
        // 0x00B8DD20: BL #0x249f5fc              | X0 = BehaviourUtil.allCoroutineDic.get_Item(key:  W1);
        System.Collections.IEnumerator val_2 = BehaviourUtil.allCoroutineDic.Item[W1];
        // 0x00B8DD24: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00B8DD28: BL #0xb8deec               | BehaviourUtil.StopCoroutine(routine:  System.Collections.IEnumerator val_2 = BehaviourUtil.allCoroutineDic.Item[W1]);
        BehaviourUtil.StopCoroutine(routine:  val_2);
        // 0x00B8DD2C: LDR x8, [x22]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DD30: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DD34: LDR x20, [x8, #0x18]       | X20 = BehaviourUtil.allCoroutineDic;    
        // 0x00B8DD38: CBNZ x20, #0xb8dd40        | if (BehaviourUtil.allCoroutineDic != null) goto label_8;
        if(BehaviourUtil.allCoroutineDic != null)
        {
            goto label_8;
        }
        // 0x00B8DD3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B8DD40: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00B8DD44: LDR x8, [x8, #0xb50]       | X8 = 1152921515547944144;               
        // 0x00B8DD48: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineDic;//m1 
        // 0x00B8DD4C: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DD50: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>::Remove(System.UInt32 key);
        // 0x00B8DD54: BL #0x24a1608              | X0 = BehaviourUtil.allCoroutineDic.Remove(key:  W1);
        bool val_3 = BehaviourUtil.allCoroutineDic.Remove(key:  W1);
        label_4:
        // 0x00B8DD58: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_12 = null;
        // 0x00B8DD5C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DD60: TBZ w8, #0, #0xb8dd74      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B8DD64: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DD68: CBNZ w8, #0xb8dd74         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B8DD6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DD70: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_12 = null;
        label_10:
        // 0x00B8DD74: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DD78: LDR x20, [x8, #0x10]       | X20 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DD7C: CBNZ x20, #0xb8dd84        | if (BehaviourUtil.allWaitSecondDic != null) goto label_11;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_11;
        }
        // 0x00B8DD80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_11:
        // 0x00B8DD84: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00B8DD88: LDR x8, [x8, #0x498]       | X8 = 1152921515547945168;               
        // 0x00B8DD8C: MOV x0, x20                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DD90: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DD94: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::ContainsKey(System.UInt32 key);
        // 0x00B8DD98: BL #0x24a0ce8              | X0 = BehaviourUtil.allWaitSecondDic.ContainsKey(key:  W1);
        bool val_4 = BehaviourUtil.allWaitSecondDic.ContainsKey(key:  W1);
        // 0x00B8DD9C: TBZ w0, #0, #0xb8ded8      | if (val_4 == false) goto label_12;      
        if(val_4 == false)
        {
            goto label_12;
        }
        // 0x00B8DDA0: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_13 = null;
        // 0x00B8DDA4: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DDA8: TBZ w8, #0, #0xb8ddbc      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B8DDAC: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DDB0: CBNZ w8, #0xb8ddbc         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B8DDB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DDB8: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_13 = null;
        label_14:
        // 0x00B8DDBC: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DDC0: LDR x20, [x8, #0x10]       | X20 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DDC4: CBNZ x20, #0xb8ddcc        | if (BehaviourUtil.allWaitSecondDic != null) goto label_15;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_15;
        }
        // 0x00B8DDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_15:
        // 0x00B8DDCC: ADRP x23, #0x367c000       | X23 = 57131008 (0x367C000);             
        // 0x00B8DDD0: LDR x23, [x23, #0xce0]     | X23 = 1152921515547946192;              
        // 0x00B8DDD4: MOV x0, x20                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DDD8: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DDDC: LDR x2, [x23]              | X2 = public Mihua.Utils.WaitForSeconds System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::get_Item(System.UInt32 key);
        // 0x00B8DDE0: BL #0x249f5fc              | X0 = BehaviourUtil.allWaitSecondDic.get_Item(key:  W1);
        Mihua.Utils.WaitForSeconds val_5 = BehaviourUtil.allWaitSecondDic.Item[W1];
        // 0x00B8DDE4: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00B8DDE8: BL #0xb8deec               | BehaviourUtil.StopCoroutine(routine:  Mihua.Utils.WaitForSeconds val_5 = BehaviourUtil.allWaitSecondDic.Item[W1]);
        BehaviourUtil.StopCoroutine(routine:  val_5);
        // 0x00B8DDEC: LDR x8, [x22]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DDF0: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DDF4: LDR x20, [x8, #0x10]       | X20 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DDF8: CBNZ x20, #0xb8de00        | if (BehaviourUtil.allWaitSecondDic != null) goto label_16;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_16;
        }
        // 0x00B8DDFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_16:
        // 0x00B8DE00: LDR x2, [x23]              | X2 = public Mihua.Utils.WaitForSeconds System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::get_Item(System.UInt32 key);
        // 0x00B8DE04: MOV x0, x20                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DE08: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DE0C: BL #0x249f5fc              | X0 = BehaviourUtil.allWaitSecondDic.get_Item(key:  W1);
        Mihua.Utils.WaitForSeconds val_6 = BehaviourUtil.allWaitSecondDic.Item[W1];
        // 0x00B8DE10: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B8DE14: LDR x8, [x8, #0x478]       | X8 = 1152921504924311552;               
        // 0x00B8DE18: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00B8DE1C: LDR x8, [x8]               | X8 = typeof(Mihua.Utils.ObjectPool<T>); 
        // 0x00B8DE20: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_10A;
        // 0x00B8DE24: TBZ w9, #0, #0xb8de38      | if (Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B8DE28: LDR w9, [x8, #0xbc]        | W9 = Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DE2C: CBNZ w9, #0xb8de38         | if (Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B8DE30: MOV x0, x8                 | X0 = 1152921504924311552 (0x1000000012EC2000);//ML01
        // 0x00B8DE34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Utils.ObjectPool<T>), ????);
        label_18:
        // 0x00B8DE38: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B8DE3C: LDR x8, [x8, #0x920]       | X8 = 1152921515547805520;               
        // 0x00B8DE40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8DE44: MOV x1, x20                | X1 = val_6;//m1                         
        // 0x00B8DE48: LDR x2, [x8]               | X2 = public static System.Void Mihua.Utils.ObjectPool<Mihua.Utils.WaitForSeconds>::Recycle(Mihua.Utils.WaitForSeconds obj);
        // 0x00B8DE4C: BL #0x19e5bbc              | Mihua.Utils.ObjectPool<BuffState>.Recycle(obj:  0);
        Mihua.Utils.ObjectPool<BuffState>.Recycle(obj:  0);
        // 0x00B8DE50: LDR x8, [x22]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DE54: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DE58: LDR x20, [x8, #0x20]       | X20 = BehaviourUtil.allCoroutineList;   
        // 0x00B8DE5C: LDR x21, [x8, #0x10]       | X21 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DE60: CBNZ x21, #0xb8de68        | if (BehaviourUtil.allWaitSecondDic != null) goto label_19;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_19;
        }
        // 0x00B8DE64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_19:
        // 0x00B8DE68: LDR x2, [x23]              | X2 = public Mihua.Utils.WaitForSeconds System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::get_Item(System.UInt32 key);
        // 0x00B8DE6C: MOV x0, x21                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DE70: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DE74: BL #0x249f5fc              | X0 = BehaviourUtil.allWaitSecondDic.get_Item(key:  W1);
        Mihua.Utils.WaitForSeconds val_7 = BehaviourUtil.allWaitSecondDic.Item[W1];
        // 0x00B8DE78: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00B8DE7C: CBNZ x20, #0xb8de84        | if (BehaviourUtil.allCoroutineList != null) goto label_20;
        if(BehaviourUtil.allCoroutineList != null)
        {
            goto label_20;
        }
        // 0x00B8DE80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_20:
        // 0x00B8DE84: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00B8DE88: LDR x8, [x8, #0xbe0]       | X8 = 1152921515547959504;               
        // 0x00B8DE8C: MOV x0, x20                | X0 = BehaviourUtil.allCoroutineList;//m1
        // 0x00B8DE90: MOV x1, x21                | X1 = val_7;//m1                         
        // 0x00B8DE94: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::Remove(Mihua.Utils.WaitForSeconds item);
        // 0x00B8DE98: BL #0x25ecd20              | X0 = BehaviourUtil.allCoroutineList.Remove(item:  val_7);
        bool val_8 = BehaviourUtil.allCoroutineList.Remove(item:  val_7);
        // 0x00B8DE9C: LDR x8, [x22]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8DEA0: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DEA4: LDR x20, [x8, #0x10]       | X20 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DEA8: CBNZ x20, #0xb8deb0        | if (BehaviourUtil.allWaitSecondDic != null) goto label_21;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_21;
        }
        // 0x00B8DEAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_21:
        // 0x00B8DEB0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B8DEB4: LDR x8, [x8, #0xf10]       | X8 = 1152921515547960528;               
        // 0x00B8DEB8: MOV x0, x20                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DEBC: MOV w1, w19                | W1 = W1;//m1                            
        // 0x00B8DEC0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::Remove(System.UInt32 key);
        // 0x00B8DEC4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8DEC8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8DECC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8DED0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B8DED4: B #0x24a1608               | X0 = BehaviourUtil.allWaitSecondDic.Remove(key:  W1); return;
        bool val_9 = BehaviourUtil.allWaitSecondDic.Remove(key:  W1);
        return;
        label_12:
        // 0x00B8DED8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8DEDC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8DEE0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8DEE4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B8DEE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8DF68 (12115816), len: 264  VirtAddr: 0x00B8DF68 RVA: 0x00B8DF68 token: 100696542 methodIndex: 25098 delegateWrapperIndex: 0 methodInvoker: 0
    public static void SetPause(uint id, bool isPause)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x00B8DF68: STP x22, x21, [sp, #-0x30]! | stack[1152921515548105984] = ???;  stack[1152921515548105992] = ???;  //  dest_result_addr=1152921515548105984 |  dest_result_addr=1152921515548105992
        // 0x00B8DF6C: STP x20, x19, [sp, #0x10]  | stack[1152921515548106000] = ???;  stack[1152921515548106008] = ???;  //  dest_result_addr=1152921515548106000 |  dest_result_addr=1152921515548106008
        // 0x00B8DF70: STP x29, x30, [sp, #0x20]  | stack[1152921515548106016] = ???;  stack[1152921515548106024] = ???;  //  dest_result_addr=1152921515548106016 |  dest_result_addr=1152921515548106024
        // 0x00B8DF74: ADD x29, sp, #0x20         | X29 = (1152921515548105984 + 32) = 1152921515548106016 (0x100000028C265D20);
        // 0x00B8DF78: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B8DF7C: LDRB w8, [x21, #0xa20]     | W8 = (bool)static_value_03733A20;       
        // 0x00B8DF80: MOV w19, w2                | W19 = W2;//m1                           
        // 0x00B8DF84: MOV w20, w1                | W20 = isPause;//m1                      
        // 0x00B8DF88: TBNZ w8, #0, #0xb8dfa4     | if (static_value_03733A20 == true) goto label_0;
        // 0x00B8DF8C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B8DF90: LDR x8, [x8, #0xcd0]       | X8 = 0x2B8F31C;                         
        // 0x00B8DF94: LDR w0, [x8]               | W0 = 0x1389;                            
        // 0x00B8DF98: BL #0x2782188              | X0 = sub_2782188( ?? 0x1389, ????);     
        // 0x00B8DF9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8DFA0: STRB w8, [x21, #0xa20]     | static_value_03733A20 = true;            //  dest_result_addr=57883168
        label_0:
        // 0x00B8DFA4: ADRP x22, #0x365d000       | X22 = 57004032 (0x365D000);             
        // 0x00B8DFA8: LDR x22, [x22, #0x4b8]     | X22 = 1152921504922660864;              
        // 0x00B8DFAC: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_4 = null;
        // 0x00B8DFB0: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DFB4: TBZ w8, #0, #0xb8dfc8      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8DFB8: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DFBC: CBNZ w8, #0xb8dfc8         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8DFC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8DFC4: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_4 = null;
        label_2:
        // 0x00B8DFC8: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8DFCC: LDR x21, [x8, #0x10]       | X21 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8DFD0: CBNZ x21, #0xb8dfd8        | if (BehaviourUtil.allWaitSecondDic != null) goto label_3;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_3;
        }
        // 0x00B8DFD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_3:
        // 0x00B8DFD8: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00B8DFDC: LDR x8, [x8, #0x498]       | X8 = 1152921515547945168;               
        // 0x00B8DFE0: MOV x0, x21                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8DFE4: MOV w1, w20                | W1 = isPause;//m1                       
        // 0x00B8DFE8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::ContainsKey(System.UInt32 key);
        // 0x00B8DFEC: BL #0x24a0ce8              | X0 = BehaviourUtil.allWaitSecondDic.ContainsKey(key:  isPause);
        bool val_1 = BehaviourUtil.allWaitSecondDic.ContainsKey(key:  isPause);
        // 0x00B8DFF0: TBZ w0, #0, #0xb8e060      | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x00B8DFF4: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_5 = null;
        // 0x00B8DFF8: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DFFC: TBZ w8, #0, #0xb8e010      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B8E000: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E004: CBNZ w8, #0xb8e010         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B8E008: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8E00C: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_5 = null;
        label_6:
        // 0x00B8E010: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E014: LDR x21, [x8, #0x10]       | X21 = BehaviourUtil.allWaitSecondDic;   
        // 0x00B8E018: CBNZ x21, #0xb8e020        | if (BehaviourUtil.allWaitSecondDic != null) goto label_7;
        if(BehaviourUtil.allWaitSecondDic != null)
        {
            goto label_7;
        }
        // 0x00B8E01C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BehaviourUtil), ????);
        label_7:
        // 0x00B8E020: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B8E024: LDR x8, [x8, #0xce0]       | X8 = 1152921515547946192;               
        // 0x00B8E028: MOV x0, x21                | X0 = BehaviourUtil.allWaitSecondDic;//m1
        // 0x00B8E02C: MOV w1, w20                | W1 = isPause;//m1                       
        // 0x00B8E030: LDR x2, [x8]               | X2 = public Mihua.Utils.WaitForSeconds System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::get_Item(System.UInt32 key);
        // 0x00B8E034: BL #0x249f5fc              | X0 = BehaviourUtil.allWaitSecondDic.get_Item(key:  isPause);
        Mihua.Utils.WaitForSeconds val_2 = BehaviourUtil.allWaitSecondDic.Item[isPause];
        // 0x00B8E038: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B8E03C: CBNZ x20, #0xb8e044        | if (val_2 != null) goto label_8;        
        if(val_2 != null)
        {
            goto label_8;
        }
        // 0x00B8E040: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B8E044: AND w1, w19, #1            | W1 = (W2 & 1);                          
        bool val_3 = W2 & 1;
        // 0x00B8E048: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B8E04C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E050: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E054: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8E058: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8E05C: B #0xac2bb4                | val_2.set_ispause(value:  bool val_3 = W2 & 1); return;
        val_2.ispause = val_3;
        return;
        label_4:
        // 0x00B8E060: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E064: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E068: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8E06C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8DEEC (12115692), len: 124  VirtAddr: 0x00B8DEEC RVA: 0x00B8DEEC token: 100696543 methodIndex: 25099 delegateWrapperIndex: 0 methodInvoker: 0
    private static void StopCoroutine(System.Collections.IEnumerator routine)
    {
        //
        // Disasemble & Code
        // 0x00B8DEEC: STP x20, x19, [sp, #-0x20]! | stack[1152921515548230288] = ???;  stack[1152921515548230296] = ???;  //  dest_result_addr=1152921515548230288 |  dest_result_addr=1152921515548230296
        // 0x00B8DEF0: STP x29, x30, [sp, #0x10]  | stack[1152921515548230304] = ???;  stack[1152921515548230312] = ???;  //  dest_result_addr=1152921515548230304 |  dest_result_addr=1152921515548230312
        // 0x00B8DEF4: ADD x29, sp, #0x10         | X29 = (1152921515548230288 + 16) = 1152921515548230304 (0x100000028C2842A0);
        // 0x00B8DEF8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8DEFC: LDRB w8, [x20, #0xa21]     | W8 = (bool)static_value_03733A21;       
        // 0x00B8DF00: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B8DF04: TBNZ w8, #0, #0xb8df20     | if (static_value_03733A21 == true) goto label_0;
        // 0x00B8DF08: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B8DF0C: LDR x8, [x8, #0x830]       | X8 = 0x2B8F330;                         
        // 0x00B8DF10: LDR w0, [x8]               | W0 = 0x138E;                            
        // 0x00B8DF14: BL #0x2782188              | X0 = sub_2782188( ?? 0x138E, ????);     
        // 0x00B8DF18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8DF1C: STRB w8, [x20, #0xa21]     | static_value_03733A21 = true;            //  dest_result_addr=57883169
        label_0:
        // 0x00B8DF20: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B8DF24: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00B8DF28: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00B8DF2C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8DF30: TBZ w8, #0, #0xb8df40      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8DF34: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8DF38: CBNZ w8, #0xb8df40         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8DF3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_2:
        // 0x00B8DF40: BL #0xb8d7f0               | X0 = BehaviourUtil.get_GlobalCoroutine();
        UnityEngine.MonoBehaviour val_1 = BehaviourUtil.GlobalCoroutine;
        // 0x00B8DF44: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8DF48: CBNZ x20, #0xb8df50        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B8DF4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B8DF50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8DF54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8DF58: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B8DF5C: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B8DF60: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8DF64: B #0x1b77438               | val_1.StopCoroutine(routine:  X1); return;
        val_1.StopCoroutine(routine:  X1);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E070 (12116080), len: 156  VirtAddr: 0x00B8E070 RVA: 0x00B8E070 token: 100696544 methodIndex: 25100 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint JSDelayCall(float delaytime, System.Action act)
    {
        //
        // Disasemble & Code
        //  | 
        System.Action val_4;
        // 0x00B8E070: STP d9, d8, [sp, #-0x30]!  | stack[1152921515548362752] = ???;  stack[1152921515548362760] = ???;  //  dest_result_addr=1152921515548362752 |  dest_result_addr=1152921515548362760
        // 0x00B8E074: STP x20, x19, [sp, #0x10]  | stack[1152921515548362768] = ???;  stack[1152921515548362776] = ???;  //  dest_result_addr=1152921515548362768 |  dest_result_addr=1152921515548362776
        // 0x00B8E078: STP x29, x30, [sp, #0x20]  | stack[1152921515548362784] = ???;  stack[1152921515548362792] = ???;  //  dest_result_addr=1152921515548362784 |  dest_result_addr=1152921515548362792
        // 0x00B8E07C: ADD x29, sp, #0x20         | X29 = (1152921515548362752 + 32) = 1152921515548362784 (0x100000028C2A4820);
        // 0x00B8E080: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8E084: LDRB w8, [x20, #0xa22]     | W8 = (bool)static_value_03733A22;       
        // 0x00B8E088: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B8E08C: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B8E090: TBNZ w8, #0, #0xb8e0ac     | if (static_value_03733A22 == true) goto label_0;
        // 0x00B8E094: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00B8E098: LDR x8, [x8, #0xa40]       | X8 = 0x2B8F2F8;                         
        // 0x00B8E09C: LDR w0, [x8]               | W0 = 0x1380;                            
        // 0x00B8E0A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1380, ????);     
        // 0x00B8E0A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E0A8: STRB w8, [x20, #0xa22]     | static_value_03733A22 = true;            //  dest_result_addr=57883170
        label_0:
        // 0x00B8E0AC: ADRP x20, #0x365d000       | X20 = 57004032 (0x365D000);             
        // 0x00B8E0B0: LDR x20, [x20, #0x4b8]     | X20 = 1152921504922660864;              
        // 0x00B8E0B4: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_4 = null;
        // 0x00B8E0B8: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8E0BC: TBZ w8, #0, #0xb8e0d0      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8E0C0: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E0C4: CBNZ w8, #0xb8e0d0         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8E0C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8E0CC: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_4 = null;
        label_2:
        // 0x00B8E0D0: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E0D4: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x00B8E0D8: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B8E0DC: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x00B8E0E0: ADD w20, w9, #1            | W20 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x00B8E0E4: STR w20, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x00B8E0E8: BL #0xb8e10c               | X0 = BehaviourUtil.DelayCallExec(delaytime:  delaytime, act:  val_4 = null);
        System.Collections.IEnumerator val_2 = BehaviourUtil.DelayCallExec(delaytime:  delaytime, act:  val_4);
        // 0x00B8E0EC: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00B8E0F0: MOV w2, w20                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x00B8E0F4: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  System.Collections.IEnumerator val_2 = BehaviourUtil.DelayCallExec(delaytime:  delaytime, act:  val_4), id:  val_2);
        UnityEngine.Coroutine val_3 = BehaviourUtil.StartCoroutine(routine:  val_2, id:  val_2);
        // 0x00B8E0F8: MOV w0, w20                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x00B8E0FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E100: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E104: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8E108: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CF50C VirtAddr: 0x010CF50C -RVA: 0x010CF50C 
    // -BehaviourUtil.JSDelayCall<object>
    // -BehaviourUtil.JSDelayCall<string>
    // -BehaviourUtil.JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance>
    //
    // file offset: 0x010CEF34 VirtAddr: 0x010CEF34 -RVA: 0x010CEF34 
    // -BehaviourUtil.JSDelayCall<HERO_ELEMENT>
    //
    // file offset: 0x010CEFFC VirtAddr: 0x010CEFFC -RVA: 0x010CEFFC 
    // -BehaviourUtil.JSDelayCall<bool>
    //
    // file offset: 0x010CF0C4 VirtAddr: 0x010CF0C4 -RVA: 0x010CF0C4 
    // -BehaviourUtil.JSDelayCall<int>
    //
    //
    // Offset in libil2cpp.so: 0x010CF50C (17626380), len: 200  VirtAddr: 0x010CF50C RVA: 0x010CF50C token: 100696545 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint JSDelayCall<T>(float delaytime, System.Action<T> act, T arg1)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CF50C: STP d9, d8, [sp, #-0x40]!  | stack[1152921515548499312] = ???;  stack[1152921515548499320] = ???;  //  dest_result_addr=1152921515548499312 |  dest_result_addr=1152921515548499320
        // 0x010CF510: STP x22, x21, [sp, #0x10]  | stack[1152921515548499328] = ???;  stack[1152921515548499336] = ???;  //  dest_result_addr=1152921515548499328 |  dest_result_addr=1152921515548499336
        // 0x010CF514: STP x20, x19, [sp, #0x20]  | stack[1152921515548499344] = ???;  stack[1152921515548499352] = ???;  //  dest_result_addr=1152921515548499344 |  dest_result_addr=1152921515548499352
        // 0x010CF518: STP x29, x30, [sp, #0x30]  | stack[1152921515548499360] = ???;  stack[1152921515548499368] = ???;  //  dest_result_addr=1152921515548499360 |  dest_result_addr=1152921515548499368
        // 0x010CF51C: ADD x29, sp, #0x30         | X29 = (1152921515548499312 + 48) = 1152921515548499360 (0x100000028C2C5DA0);
        // 0x010CF520: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
        // 0x010CF524: LDRB w8, [x22, #0x8f9]     | W8 = (bool)static_value_037358F9;       
        // 0x010CF528: MOV x21, x3                | X21 = X3;//m1                           
        // 0x010CF52C: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CF530: MOV x20, x1                | X20 = arg1;//m1                         
        // 0x010CF534: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CF538: TBNZ w8, #0, #0x10cf554    | if (static_value_037358F9 == true) goto label_0;
        // 0x010CF53C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x010CF540: LDR x8, [x8, #0x698]       | X8 = 0x2B8F308;                         
        // 0x010CF544: LDR w0, [x8]               | W0 = 0x1384;                            
        // 0x010CF548: BL #0x2782188              | X0 = sub_2782188( ?? 0x1384, ????);     
        // 0x010CF54C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CF550: STRB w8, [x22, #0x8f9]     | static_value_037358F9 = true;            //  dest_result_addr=57891065
        label_0:
        // 0x010CF554: ADRP x22, #0x365d000       | X22 = 57004032 (0x365D000);             
        // 0x010CF558: LDR x22, [x22, #0x4b8]     | X22 = 1152921504922660864;              
        // 0x010CF55C: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CF560: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CF564: TBZ w8, #0, #0x10cf578     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CF568: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CF56C: CBNZ w8, #0x10cf578        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CF570: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CF574: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CF578: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CF57C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF580: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CF584: MOV x1, x20                | X1 = arg1;//m1                          
        // 0x010CF588: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CF58C: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CF590: ADD w22, w9, #1            | W22 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CF594: STR w22, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CF598: LDR x8, [x21, #0x30]       | X8 = X3 + 48;                           
        // 0x010CF59C: LDR x3, [x8]               | X3 = X3 + 48;                           
        // 0x010CF5A0: LDR x8, [x3]               | X8 = X3 + 48;                           
        // 0x010CF5A4: BLR x8                     | X0 = X3 + 48();                         
        // 0x010CF5A8: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CF5AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF5B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CF5B4: MOV w2, w22                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF5B8: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CF5BC: MOV w0, w22                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF5C0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x010CF5C4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x010CF5C8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x010CF5CC: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x010CF5D0: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CF434 VirtAddr: 0x010CF434 -RVA: 0x010CF434 
    // -BehaviourUtil.JSDelayCall<object, object>
    //
    // file offset: 0x010CF18C VirtAddr: 0x010CF18C -RVA: 0x010CF18C 
    // -BehaviourUtil.JSDelayCall<ILRuntime.Runtime.Intepreter.ILTypeInstance, int>
    // -BehaviourUtil.JSDelayCall<object, int>
    //
    //
    // Offset in libil2cpp.so: 0x010CF434 (17626164), len: 216  VirtAddr: 0x010CF434 RVA: 0x010CF434 token: 100696546 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint JSDelayCall<T1, T2>(float delaytime, System.Action<T1, T2> act, T1 arg1, T2 arg2)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CF434: STP d9, d8, [sp, #-0x50]!  | stack[1152921515548639968] = ???;  stack[1152921515548639976] = ???;  //  dest_result_addr=1152921515548639968 |  dest_result_addr=1152921515548639976
        // 0x010CF438: STP x24, x23, [sp, #0x10]  | stack[1152921515548639984] = ???;  stack[1152921515548639992] = ???;  //  dest_result_addr=1152921515548639984 |  dest_result_addr=1152921515548639992
        // 0x010CF43C: STP x22, x21, [sp, #0x20]  | stack[1152921515548640000] = ???;  stack[1152921515548640008] = ???;  //  dest_result_addr=1152921515548640000 |  dest_result_addr=1152921515548640008
        // 0x010CF440: STP x20, x19, [sp, #0x30]  | stack[1152921515548640016] = ???;  stack[1152921515548640024] = ???;  //  dest_result_addr=1152921515548640016 |  dest_result_addr=1152921515548640024
        // 0x010CF444: STP x29, x30, [sp, #0x40]  | stack[1152921515548640032] = ???;  stack[1152921515548640040] = ???;  //  dest_result_addr=1152921515548640032 |  dest_result_addr=1152921515548640040
        // 0x010CF448: ADD x29, sp, #0x40         | X29 = (1152921515548639968 + 64) = 1152921515548640032 (0x100000028C2E8320);
        // 0x010CF44C: ADRP x23, #0x3735000       | X23 = 57888768 (0x3735000);             
        // 0x010CF450: LDRB w8, [x23, #0x8f8]     | W8 = (bool)static_value_037358F8;       
        // 0x010CF454: MOV x22, x4                | X22 = X4;//m1                           
        // 0x010CF458: MOV x19, x3                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CF45C: MOV x20, x2                | X20 = arg2;//m1                         
        // 0x010CF460: MOV x21, x1                | X21 = arg1;//m1                         
        // 0x010CF464: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CF468: TBNZ w8, #0, #0x10cf484    | if (static_value_037358F8 == true) goto label_0;
        // 0x010CF46C: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x010CF470: LDR x8, [x8, #0xe88]       | X8 = 0x2B8F310;                         
        // 0x010CF474: LDR w0, [x8]               | W0 = 0x1386;                            
        // 0x010CF478: BL #0x2782188              | X0 = sub_2782188( ?? 0x1386, ????);     
        // 0x010CF47C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CF480: STRB w8, [x23, #0x8f8]     | static_value_037358F8 = true;            //  dest_result_addr=57891064
        label_0:
        // 0x010CF484: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
        // 0x010CF488: LDR x23, [x23, #0x4b8]     | X23 = 1152921504922660864;              
        // 0x010CF48C: LDR x0, [x23]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CF490: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CF494: TBZ w8, #0, #0x10cf4a8     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CF498: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CF49C: CBNZ w8, #0x10cf4a8        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CF4A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CF4A4: LDR x0, [x23]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CF4A8: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CF4AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF4B0: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CF4B4: MOV x1, x21                | X1 = arg1;//m1                          
        // 0x010CF4B8: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CF4BC: MOV x2, x20                | X2 = arg2;//m1                          
        // 0x010CF4C0: MOV x3, x19                | X3 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CF4C4: ADD w23, w9, #1            | W23 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CF4C8: STR w23, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CF4CC: LDR x8, [x22, #0x30]       | X8 = X4 + 48;                           
        // 0x010CF4D0: LDR x4, [x8]               | X4 = X4 + 48;                           
        // 0x010CF4D4: LDR x8, [x4]               | X8 = X4 + 48;                           
        // 0x010CF4D8: BLR x8                     | X0 = X4 + 48();                         
        // 0x010CF4DC: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CF4E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF4E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CF4E8: MOV w2, w23                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF4EC: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CF4F0: MOV w0, w23                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF4F4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x010CF4F8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x010CF4FC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x010CF500: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x010CF504: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x010CF508: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CF354 VirtAddr: 0x010CF354 -RVA: 0x010CF354 
    // -BehaviourUtil.JSDelayCall<object, object, object>
    //
    //
    // Offset in libil2cpp.so: 0x010CF354 (17625940), len: 224  VirtAddr: 0x010CF354 RVA: 0x010CF354 token: 100696547 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint JSDelayCall<T1, T2, T3>(float delaytime, System.Action<T1, T2, T3> act, T1 arg1, T2 arg2, T3 arg3)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CF354: STP d9, d8, [sp, #-0x50]!  | stack[1152921515548788832] = ???;  stack[1152921515548788840] = ???;  //  dest_result_addr=1152921515548788832 |  dest_result_addr=1152921515548788840
        // 0x010CF358: STP x24, x23, [sp, #0x10]  | stack[1152921515548788848] = ???;  stack[1152921515548788856] = ???;  //  dest_result_addr=1152921515548788848 |  dest_result_addr=1152921515548788856
        // 0x010CF35C: STP x22, x21, [sp, #0x20]  | stack[1152921515548788864] = ???;  stack[1152921515548788872] = ???;  //  dest_result_addr=1152921515548788864 |  dest_result_addr=1152921515548788872
        // 0x010CF360: STP x20, x19, [sp, #0x30]  | stack[1152921515548788880] = ???;  stack[1152921515548788888] = ???;  //  dest_result_addr=1152921515548788880 |  dest_result_addr=1152921515548788888
        // 0x010CF364: STP x29, x30, [sp, #0x40]  | stack[1152921515548788896] = ???;  stack[1152921515548788904] = ???;  //  dest_result_addr=1152921515548788896 |  dest_result_addr=1152921515548788904
        // 0x010CF368: ADD x29, sp, #0x40         | X29 = (1152921515548788832 + 64) = 1152921515548788896 (0x100000028C30C8A0);
        // 0x010CF36C: ADRP x24, #0x3735000       | X24 = 57888768 (0x3735000);             
        // 0x010CF370: LDRB w8, [x24, #0x8f7]     | W8 = (bool)static_value_037358F7;       
        // 0x010CF374: MOV x22, x5                | X22 = X5;//m1                           
        // 0x010CF378: MOV x19, x4                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CF37C: MOV x20, x3                | X20 = arg3;//m1                         
        // 0x010CF380: MOV x21, x2                | X21 = arg2;//m1                         
        // 0x010CF384: MOV x23, x1                | X23 = arg1;//m1                         
        // 0x010CF388: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CF38C: TBNZ w8, #0, #0x10cf3a8    | if (static_value_037358F7 == true) goto label_0;
        // 0x010CF390: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x010CF394: LDR x8, [x8, #0x958]       | X8 = 0x2B8F314;                         
        // 0x010CF398: LDR w0, [x8]               | W0 = 0x1387;                            
        // 0x010CF39C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1387, ????);     
        // 0x010CF3A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CF3A4: STRB w8, [x24, #0x8f7]     | static_value_037358F7 = true;            //  dest_result_addr=57891063
        label_0:
        // 0x010CF3A8: ADRP x24, #0x365d000       | X24 = 57004032 (0x365D000);             
        // 0x010CF3AC: LDR x24, [x24, #0x4b8]     | X24 = 1152921504922660864;              
        // 0x010CF3B0: LDR x0, [x24]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CF3B4: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CF3B8: TBZ w8, #0, #0x10cf3cc     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CF3BC: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CF3C0: CBNZ w8, #0x10cf3cc        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CF3C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CF3C8: LDR x0, [x24]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CF3CC: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CF3D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF3D4: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CF3D8: MOV x1, x23                | X1 = arg1;//m1                          
        // 0x010CF3DC: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CF3E0: MOV x2, x21                | X2 = arg2;//m1                          
        // 0x010CF3E4: MOV x3, x20                | X3 = arg3;//m1                          
        // 0x010CF3E8: MOV x4, x19                | X4 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CF3EC: ADD w24, w9, #1            | W24 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CF3F0: STR w24, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CF3F4: LDR x8, [x22, #0x30]       | X8 = X5 + 48;                           
        // 0x010CF3F8: LDR x5, [x8]               | X5 = X5 + 48;                           
        // 0x010CF3FC: LDR x8, [x5]               | X8 = X5 + 48;                           
        // 0x010CF400: BLR x8                     | X0 = X5 + 48();                         
        // 0x010CF404: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CF408: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF40C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CF410: MOV w2, w24                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF414: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CF418: MOV w0, w24                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF41C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x010CF420: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x010CF424: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x010CF428: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x010CF42C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x010CF430: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CF264 VirtAddr: 0x010CF264 -RVA: 0x010CF264 
    // -BehaviourUtil.JSDelayCall<object, object, object, object>
    //
    //
    // Offset in libil2cpp.so: 0x010CF264 (17625700), len: 240  VirtAddr: 0x010CF264 RVA: 0x010CF264 token: 100696548 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint JSDelayCall<T1, T2, T3, T4>(float delaytime, System.Action<T1, T2, T3, T4> act, T1 arg1, T2 arg2, T3 arg3, T4 arg4)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CF264: STP d9, d8, [sp, #-0x60]!  | stack[1152921515548945872] = ???;  stack[1152921515548945880] = ???;  //  dest_result_addr=1152921515548945872 |  dest_result_addr=1152921515548945880
        // 0x010CF268: STP x26, x25, [sp, #0x10]  | stack[1152921515548945888] = ???;  stack[1152921515548945896] = ???;  //  dest_result_addr=1152921515548945888 |  dest_result_addr=1152921515548945896
        // 0x010CF26C: STP x24, x23, [sp, #0x20]  | stack[1152921515548945904] = ???;  stack[1152921515548945912] = ???;  //  dest_result_addr=1152921515548945904 |  dest_result_addr=1152921515548945912
        // 0x010CF270: STP x22, x21, [sp, #0x30]  | stack[1152921515548945920] = ???;  stack[1152921515548945928] = ???;  //  dest_result_addr=1152921515548945920 |  dest_result_addr=1152921515548945928
        // 0x010CF274: STP x20, x19, [sp, #0x40]  | stack[1152921515548945936] = ???;  stack[1152921515548945944] = ???;  //  dest_result_addr=1152921515548945936 |  dest_result_addr=1152921515548945944
        // 0x010CF278: STP x29, x30, [sp, #0x50]  | stack[1152921515548945952] = ???;  stack[1152921515548945960] = ???;  //  dest_result_addr=1152921515548945952 |  dest_result_addr=1152921515548945960
        // 0x010CF27C: ADD x29, sp, #0x50         | X29 = (1152921515548945872 + 80) = 1152921515548945952 (0x100000028C332E20);
        // 0x010CF280: ADRP x25, #0x3735000       | X25 = 57888768 (0x3735000);             
        // 0x010CF284: LDRB w8, [x25, #0x8f6]     | W8 = (bool)static_value_037358F6;       
        // 0x010CF288: MOV x22, x6                | X22 = X6;//m1                           
        // 0x010CF28C: MOV x19, x5                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CF290: MOV x20, x4                | X20 = arg4;//m1                         
        // 0x010CF294: MOV x21, x3                | X21 = arg3;//m1                         
        // 0x010CF298: MOV x23, x2                | X23 = arg2;//m1                         
        // 0x010CF29C: MOV x24, x1                | X24 = arg1;//m1                         
        // 0x010CF2A0: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CF2A4: TBNZ w8, #0, #0x10cf2c0    | if (static_value_037358F6 == true) goto label_0;
        // 0x010CF2A8: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x010CF2AC: LDR x8, [x8, #0x8a0]       | X8 = 0x2B8F318;                         
        // 0x010CF2B0: LDR w0, [x8]               | W0 = 0x1388;                            
        // 0x010CF2B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1388, ????);     
        // 0x010CF2B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CF2BC: STRB w8, [x25, #0x8f6]     | static_value_037358F6 = true;            //  dest_result_addr=57891062
        label_0:
        // 0x010CF2C0: ADRP x25, #0x365d000       | X25 = 57004032 (0x365D000);             
        // 0x010CF2C4: LDR x25, [x25, #0x4b8]     | X25 = 1152921504922660864;              
        // 0x010CF2C8: LDR x0, [x25]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CF2CC: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CF2D0: TBZ w8, #0, #0x10cf2e4     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CF2D4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CF2D8: CBNZ w8, #0x10cf2e4        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CF2DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CF2E0: LDR x0, [x25]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CF2E4: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CF2E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF2EC: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CF2F0: MOV x1, x24                | X1 = arg1;//m1                          
        // 0x010CF2F4: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CF2F8: MOV x2, x23                | X2 = arg2;//m1                          
        // 0x010CF2FC: MOV x3, x21                | X3 = arg3;//m1                          
        // 0x010CF300: MOV x4, x20                | X4 = arg4;//m1                          
        // 0x010CF304: ADD w25, w9, #1            | W25 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CF308: STR w25, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CF30C: LDR x8, [x22, #0x30]       | X8 = X6 + 48;                           
        // 0x010CF310: MOV x5, x19                | X5 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CF314: LDR x6, [x8]               | X6 = X6 + 48;                           
        // 0x010CF318: LDR x8, [x6]               | X8 = X6 + 48;                           
        // 0x010CF31C: BLR x8                     | X0 = X6 + 48();                         
        // 0x010CF320: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CF324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CF328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CF32C: MOV w2, w25                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF330: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CF334: MOV w0, w25                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CF338: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x010CF33C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x010CF340: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x010CF344: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x010CF348: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x010CF34C: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x010CF350: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E194 (12116372), len: 156  VirtAddr: 0x00B8E194 RVA: 0x00B8E194 token: 100696549 methodIndex: 25101 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint DelayCall(float delaytime, System.Action act)
    {
        //
        // Disasemble & Code
        //  | 
        System.Action val_4;
        // 0x00B8E194: STP d9, d8, [sp, #-0x30]!  | stack[1152921515549094784] = ???;  stack[1152921515549094792] = ???;  //  dest_result_addr=1152921515549094784 |  dest_result_addr=1152921515549094792
        // 0x00B8E198: STP x20, x19, [sp, #0x10]  | stack[1152921515549094800] = ???;  stack[1152921515549094808] = ???;  //  dest_result_addr=1152921515549094800 |  dest_result_addr=1152921515549094808
        // 0x00B8E19C: STP x29, x30, [sp, #0x20]  | stack[1152921515549094816] = ???;  stack[1152921515549094824] = ???;  //  dest_result_addr=1152921515549094816 |  dest_result_addr=1152921515549094824
        // 0x00B8E1A0: ADD x29, sp, #0x20         | X29 = (1152921515549094784 + 32) = 1152921515549094816 (0x100000028C3573A0);
        // 0x00B8E1A4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8E1A8: LDRB w8, [x20, #0xa23]     | W8 = (bool)static_value_03733A23;       
        // 0x00B8E1AC: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B8E1B0: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B8E1B4: TBNZ w8, #0, #0xb8e1d0     | if (static_value_03733A23 == true) goto label_0;
        // 0x00B8E1B8: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
        // 0x00B8E1BC: LDR x8, [x8, #0x488]       | X8 = 0x2B8F2A0;                         
        // 0x00B8E1C0: LDR w0, [x8]               | W0 = 0x136A;                            
        // 0x00B8E1C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x136A, ????);     
        // 0x00B8E1C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E1CC: STRB w8, [x20, #0xa23]     | static_value_03733A23 = true;            //  dest_result_addr=57883171
        label_0:
        // 0x00B8E1D0: ADRP x20, #0x365d000       | X20 = 57004032 (0x365D000);             
        // 0x00B8E1D4: LDR x20, [x20, #0x4b8]     | X20 = 1152921504922660864;              
        // 0x00B8E1D8: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_4 = null;
        // 0x00B8E1DC: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8E1E0: TBZ w8, #0, #0xb8e1f4      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8E1E4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E1E8: CBNZ w8, #0xb8e1f4         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8E1EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8E1F0: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_4 = null;
        label_2:
        // 0x00B8E1F4: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E1F8: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x00B8E1FC: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B8E200: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x00B8E204: ADD w20, w9, #1            | W20 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x00B8E208: STR w20, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x00B8E20C: BL #0xb8e10c               | X0 = BehaviourUtil.DelayCallExec(delaytime:  delaytime, act:  val_4 = null);
        System.Collections.IEnumerator val_2 = BehaviourUtil.DelayCallExec(delaytime:  delaytime, act:  val_4);
        // 0x00B8E210: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00B8E214: MOV w2, w20                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x00B8E218: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  System.Collections.IEnumerator val_2 = BehaviourUtil.DelayCallExec(delaytime:  delaytime, act:  val_4), id:  val_2);
        UnityEngine.Coroutine val_3 = BehaviourUtil.StartCoroutine(routine:  val_2, id:  val_2);
        // 0x00B8E21C: MOV w0, w20                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x00B8E220: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E224: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E228: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8E22C: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E10C (12116236), len: 136  VirtAddr: 0x00B8E10C RVA: 0x00B8E10C token: 100696550 methodIndex: 25102 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x287C270
    private static System.Collections.IEnumerator DelayCallExec(float delaytime, System.Action act)
    {
        //
        // Disasemble & Code
        // 0x00B8E10C: STP d9, d8, [sp, #-0x30]!  | stack[1152921515549223168] = ???;  stack[1152921515549223176] = ???;  //  dest_result_addr=1152921515549223168 |  dest_result_addr=1152921515549223176
        // 0x00B8E110: STP x20, x19, [sp, #0x10]  | stack[1152921515549223184] = ???;  stack[1152921515549223192] = ???;  //  dest_result_addr=1152921515549223184 |  dest_result_addr=1152921515549223192
        // 0x00B8E114: STP x29, x30, [sp, #0x20]  | stack[1152921515549223200] = ???;  stack[1152921515549223208] = ???;  //  dest_result_addr=1152921515549223200 |  dest_result_addr=1152921515549223208
        // 0x00B8E118: ADD x29, sp, #0x20         | X29 = (1152921515549223168 + 32) = 1152921515549223200 (0x100000028C376920);
        // 0x00B8E11C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8E120: LDRB w8, [x20, #0xa24]     | W8 = (bool)static_value_03733A24;       
        // 0x00B8E124: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B8E128: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B8E12C: TBNZ w8, #0, #0xb8e148     | if (static_value_03733A24 == true) goto label_0;
        // 0x00B8E130: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B8E134: LDR x8, [x8, #0xb48]       | X8 = 0x2B8F2EC;                         
        // 0x00B8E138: LDR w0, [x8]               | W0 = 0x137D;                            
        // 0x00B8E13C: BL #0x2782188              | X0 = sub_2782188( ?? 0x137D, ????);     
        // 0x00B8E140: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E144: STRB w8, [x20, #0xa24]     | static_value_03733A24 = true;            //  dest_result_addr=57883172
        label_0:
        // 0x00B8E148: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x00B8E14C: LDR x8, [x8, #0x40]        | X8 = 1152921504922714112;               
        // 0x00B8E150: LDR x0, [x8]               | X0 = typeof(BehaviourUtil.<DelayCallExec>c__Iterator0);
        object val_1 = null;
        // 0x00B8E154: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BehaviourUtil.<DelayCallExec>c__Iterator0), ????);
        // 0x00B8E158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E15C: MOV x20, x0                | X20 = 1152921504922714112 (0x1000000012D3C000);//ML01
        // 0x00B8E160: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00B8E164: CBZ x20, #0xb8e170         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00B8E168: STR s8, [x20, #0x14]       | typeof(BehaviourUtil.<DelayCallExec>c__Iterator0).__il2cppRuntimeField_14 = delaytime;  //  dest_result_addr=1152921504922714132
        typeof(BehaviourUtil.<DelayCallExec>c__Iterator0).__il2cppRuntimeField_14 = delaytime;
        // 0x00B8E16C: B #0xb8e17c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B8E170: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00B8E174: STR s8, [x20, #0x14]       | typeof(BehaviourUtil.<DelayCallExec>c__Iterator0).__il2cppRuntimeField_14 = delaytime;  //  dest_result_addr=1152921504922714132
        typeof(BehaviourUtil.<DelayCallExec>c__Iterator0).__il2cppRuntimeField_14 = delaytime;
        // 0x00B8E178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00B8E17C: STR x19, [x20, #0x18]      | typeof(BehaviourUtil.<DelayCallExec>c__Iterator0).__il2cppRuntimeField_18 = X1;  //  dest_result_addr=1152921504922714136
        typeof(BehaviourUtil.<DelayCallExec>c__Iterator0).__il2cppRuntimeField_18 = X1;
        // 0x00B8E180: MOV x0, x20                | X0 = 1152921504922714112 (0x1000000012D3C000);//ML01
        // 0x00B8E184: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E188: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E18C: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8E190: RET                        |  return (System.Collections.IEnumerator)typeof(BehaviourUtil.<DelayCallExec>c__Iterator0);
        return (System.Collections.IEnumerator)val_1;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CECB4 VirtAddr: 0x010CECB4 -RVA: 0x010CECB4 
    // -BehaviourUtil.DelayCall<object>
    // -BehaviourUtil.DelayCall<EffectPara>
    // -BehaviourUtil.DelayCall<string>
    // -BehaviourUtil.DelayCall<CEvent.ZEvent>
    //
    // file offset: 0x010CE4DC VirtAddr: 0x010CE4DC -RVA: 0x010CE4DC 
    // -BehaviourUtil.DelayCall<int>
    //
    // file offset: 0x010CE054 VirtAddr: 0x010CE054 -RVA: 0x010CE054 
    // -BehaviourUtil.DelayCall<bool>
    //
    //
    // Offset in libil2cpp.so: 0x010CECB4 (17624244), len: 200  VirtAddr: 0x010CECB4 RVA: 0x010CECB4 token: 100696551 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint DelayCall<T1>(float delaytime, System.Action<T1> act, T1 arg1)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CECB4: STP d9, d8, [sp, #-0x40]!  | stack[1152921515549351536] = ???;  stack[1152921515549351544] = ???;  //  dest_result_addr=1152921515549351536 |  dest_result_addr=1152921515549351544
        // 0x010CECB8: STP x22, x21, [sp, #0x10]  | stack[1152921515549351552] = ???;  stack[1152921515549351560] = ???;  //  dest_result_addr=1152921515549351552 |  dest_result_addr=1152921515549351560
        // 0x010CECBC: STP x20, x19, [sp, #0x20]  | stack[1152921515549351568] = ???;  stack[1152921515549351576] = ???;  //  dest_result_addr=1152921515549351568 |  dest_result_addr=1152921515549351576
        // 0x010CECC0: STP x29, x30, [sp, #0x30]  | stack[1152921515549351584] = ???;  stack[1152921515549351592] = ???;  //  dest_result_addr=1152921515549351584 |  dest_result_addr=1152921515549351592
        // 0x010CECC4: ADD x29, sp, #0x30         | X29 = (1152921515549351536 + 48) = 1152921515549351584 (0x100000028C395EA0);
        // 0x010CECC8: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
        // 0x010CECCC: LDRB w8, [x22, #0x8ef]     | W8 = (bool)static_value_037358EF;       
        // 0x010CECD0: MOV x21, x3                | X21 = X3;//m1                           
        // 0x010CECD4: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CECD8: MOV x20, x1                | X20 = arg1;//m1                         
        // 0x010CECDC: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CECE0: TBNZ w8, #0, #0x10cecfc    | if (static_value_037358EF == true) goto label_0;
        // 0x010CECE4: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x010CECE8: LDR x8, [x8, #0x790]       | X8 = 0x2B8F2C0;                         
        // 0x010CECEC: LDR w0, [x8]               | W0 = 0x1372;                            
        // 0x010CECF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1372, ????);     
        // 0x010CECF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CECF8: STRB w8, [x22, #0x8ef]     | static_value_037358EF = true;            //  dest_result_addr=57891055
        label_0:
        // 0x010CECFC: ADRP x22, #0x365d000       | X22 = 57004032 (0x365D000);             
        // 0x010CED00: LDR x22, [x22, #0x4b8]     | X22 = 1152921504922660864;              
        // 0x010CED04: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CED08: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CED0C: TBZ w8, #0, #0x10ced20     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CED10: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CED14: CBNZ w8, #0x10ced20        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CED18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CED1C: LDR x0, [x22]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CED20: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CED24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CED28: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CED2C: MOV x1, x20                | X1 = arg1;//m1                          
        // 0x010CED30: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CED34: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CED38: ADD w22, w9, #1            | W22 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CED3C: STR w22, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CED40: LDR x8, [x21, #0x30]       | X8 = X3 + 48;                           
        // 0x010CED44: LDR x3, [x8]               | X3 = X3 + 48;                           
        // 0x010CED48: LDR x8, [x3]               | X8 = X3 + 48;                           
        // 0x010CED4C: BLR x8                     | X0 = X3 + 48();                         
        // 0x010CED50: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CED54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CED58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CED5C: MOV w2, w22                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CED60: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CED64: MOV w0, w22                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CED68: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x010CED6C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x010CED70: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x010CED74: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x010CED78: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x00B7C43C VirtAddr: 0x00B7C43C -RVA: 0x00B7C43C 
    // -BehaviourUtil.DelayCallExec<object>
    //
    // file offset: 0x00B7B7B8 VirtAddr: 0x00B7B7B8 -RVA: 0x00B7B7B8 
    // -BehaviourUtil.DelayCallExec<HERO_ELEMENT>
    //
    // file offset: 0x00B7B918 VirtAddr: 0x00B7B918 -RVA: 0x00B7B918 
    // -BehaviourUtil.DelayCallExec<bool>
    //
    // file offset: 0x00B7BD00 VirtAddr: 0x00B7BD00 -RVA: 0x00B7BD00 
    // -BehaviourUtil.DelayCallExec<int>
    //
    //
    // Offset in libil2cpp.so: 0x00B7C43C (12043324), len: 148  VirtAddr: 0x00B7C43C RVA: 0x00B7C43C token: 100696552 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x287C280
    private static System.Collections.IEnumerator DelayCallExec<T1>(float delaytime, System.Action<T1> act, T1 arg1)
    {
        //
        // Disasemble & Code
        // 0x00B7C43C: STP d9, d8, [sp, #-0x40]!  | stack[1152921515549484016] = ???;  stack[1152921515549484024] = ???;  //  dest_result_addr=1152921515549484016 |  dest_result_addr=1152921515549484024
        // 0x00B7C440: STP x22, x21, [sp, #0x10]  | stack[1152921515549484032] = ???;  stack[1152921515549484040] = ???;  //  dest_result_addr=1152921515549484032 |  dest_result_addr=1152921515549484040
        // 0x00B7C444: STP x20, x19, [sp, #0x20]  | stack[1152921515549484048] = ???;  stack[1152921515549484056] = ???;  //  dest_result_addr=1152921515549484048 |  dest_result_addr=1152921515549484056
        // 0x00B7C448: STP x29, x30, [sp, #0x30]  | stack[1152921515549484064] = ???;  stack[1152921515549484072] = ???;  //  dest_result_addr=1152921515549484064 |  dest_result_addr=1152921515549484072
        // 0x00B7C44C: ADD x29, sp, #0x30         | X29 = (1152921515549484016 + 48) = 1152921515549484064 (0x100000028C3B6420);
        // 0x00B7C450: MOV x21, x3                | X21 = X3;//m1                           
        // 0x00B7C454: LDR x8, [x21, #0x30]       | X8 = X3 + 48;                           
        // 0x00B7C458: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x00B7C45C: MOV x20, x1                | X20 = arg1;//m1                         
        // 0x00B7C460: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B7C464: LDR x22, [x8]              | X22 = X3 + 48;                          
        // 0x00B7C468: MOV x0, x22                | X0 = X3 + 48;//m1                       
        // 0x00B7C46C: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48, ????);    
        // 0x00B7C470: MOV x0, x22                | X0 = X3 + 48;//m1                       
        // 0x00B7C474: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X3 + 48, ????);
        // 0x00B7C478: LDR x8, [x21, #0x30]       | X8 = X3 + 48;                           
        // 0x00B7C47C: MOV x21, x0                | X21 = X3 + 48;//m1                      
        // 0x00B7C480: LDR x1, [x8, #8]           | X1 = X3 + 48 + 8;                       
        // 0x00B7C484: LDR x8, [x1]               | X8 = X3 + 48 + 8;                       
        // 0x00B7C488: BLR x8                     | X0 = X3 + 48 + 8();                     
        // 0x00B7C48C: CBZ x21, #0xb7c49c         | if (X3 + 48 == 0) goto label_0;         
        if((X3 + 48) == 0)
        {
            goto label_0;
        }
        // 0x00B7C490: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C494: STR x20, [x21, #0x18]      | mem2[0] = arg1;                          //  dest_result_addr=0
        mem2[0] = arg1;
        // 0x00B7C498: B #0xb7c4b4                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00B7C49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48, ????);    
        // 0x00B7C4A0: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C4A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48, ????);    
        // 0x00B7C4A8: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00B7C4AC: STR x20, [x8]              | mem[24] = arg1;                          //  dest_result_addr=24
        mem[24] = arg1;
        // 0x00B7C4B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3 + 48, ????);    
        label_1:
        // 0x00B7C4B4: STR x19, [x21, #0x20]      | mem2[0] = __RuntimeMethodHiddenParam;    //  dest_result_addr=0
        mem2[0] = __RuntimeMethodHiddenParam;
        // 0x00B7C4B8: MOV x0, x21                | X0 = X3 + 48;//m1                       
        // 0x00B7C4BC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B7C4C0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B7C4C4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B7C4C8: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B7C4CC: RET                        |  return (System.Collections.IEnumerator)X3 + 48;
        return (System.Collections.IEnumerator)X3 + 48;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CEA14 VirtAddr: 0x010CEA14 -RVA: 0x010CEA14 
    // -BehaviourUtil.DelayCall<object, object>
    //
    // file offset: 0x010CEAEC VirtAddr: 0x010CEAEC -RVA: 0x010CEAEC 
    // -BehaviourUtil.DelayCall<string, float>
    // -BehaviourUtil.DelayCall<object, float>
    //
    // file offset: 0x010CE11C VirtAddr: 0x010CE11C -RVA: 0x010CE11C 
    // -BehaviourUtil.DelayCall<int, int>
    //
    // file offset: 0x010CE5A4 VirtAddr: 0x010CE5A4 -RVA: 0x010CE5A4 
    // -BehaviourUtil.DelayCall<CombatEntity, bool>
    // -BehaviourUtil.DelayCall<object, bool>
    //
    // file offset: 0x010CEE5C VirtAddr: 0x010CEE5C -RVA: 0x010CEE5C 
    // -BehaviourUtil.DelayCall<float, float>
    //
    //
    // Offset in libil2cpp.so: 0x010CEA14 (17623572), len: 216  VirtAddr: 0x010CEA14 RVA: 0x010CEA14 token: 100696553 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint DelayCall<T1, T2>(float delaytime, System.Action<T1, T2> act, T1 arg1, T2 arg2)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CEA14: STP d9, d8, [sp, #-0x50]!  | stack[1152921515549620576] = ???;  stack[1152921515549620584] = ???;  //  dest_result_addr=1152921515549620576 |  dest_result_addr=1152921515549620584
        // 0x010CEA18: STP x24, x23, [sp, #0x10]  | stack[1152921515549620592] = ???;  stack[1152921515549620600] = ???;  //  dest_result_addr=1152921515549620592 |  dest_result_addr=1152921515549620600
        // 0x010CEA1C: STP x22, x21, [sp, #0x20]  | stack[1152921515549620608] = ???;  stack[1152921515549620616] = ???;  //  dest_result_addr=1152921515549620608 |  dest_result_addr=1152921515549620616
        // 0x010CEA20: STP x20, x19, [sp, #0x30]  | stack[1152921515549620624] = ???;  stack[1152921515549620632] = ???;  //  dest_result_addr=1152921515549620624 |  dest_result_addr=1152921515549620632
        // 0x010CEA24: STP x29, x30, [sp, #0x40]  | stack[1152921515549620640] = ???;  stack[1152921515549620648] = ???;  //  dest_result_addr=1152921515549620640 |  dest_result_addr=1152921515549620648
        // 0x010CEA28: ADD x29, sp, #0x40         | X29 = (1152921515549620576 + 64) = 1152921515549620640 (0x100000028C3D79A0);
        // 0x010CEA2C: ADRP x23, #0x3735000       | X23 = 57888768 (0x3735000);             
        // 0x010CEA30: LDRB w8, [x23, #0x8ec]     | W8 = (bool)static_value_037358EC;       
        // 0x010CEA34: MOV x22, x4                | X22 = X4;//m1                           
        // 0x010CEA38: MOV x19, x3                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CEA3C: MOV x20, x2                | X20 = arg2;//m1                         
        // 0x010CEA40: MOV x21, x1                | X21 = arg1;//m1                         
        // 0x010CEA44: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CEA48: TBNZ w8, #0, #0x10cea64    | if (static_value_037358EC == true) goto label_0;
        // 0x010CEA4C: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x010CEA50: LDR x8, [x8, #0xc00]       | X8 = 0x2B8F2D0;                         
        // 0x010CEA54: LDR w0, [x8]               | W0 = 0x1376;                            
        // 0x010CEA58: BL #0x2782188              | X0 = sub_2782188( ?? 0x1376, ????);     
        // 0x010CEA5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CEA60: STRB w8, [x23, #0x8ec]     | static_value_037358EC = true;            //  dest_result_addr=57891052
        label_0:
        // 0x010CEA64: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
        // 0x010CEA68: LDR x23, [x23, #0x4b8]     | X23 = 1152921504922660864;              
        // 0x010CEA6C: LDR x0, [x23]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CEA70: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CEA74: TBZ w8, #0, #0x10cea88     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CEA78: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CEA7C: CBNZ w8, #0x10cea88        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CEA80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CEA84: LDR x0, [x23]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CEA88: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CEA8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CEA90: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CEA94: MOV x1, x21                | X1 = arg1;//m1                          
        // 0x010CEA98: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CEA9C: MOV x2, x20                | X2 = arg2;//m1                          
        // 0x010CEAA0: MOV x3, x19                | X3 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CEAA4: ADD w23, w9, #1            | W23 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CEAA8: STR w23, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CEAAC: LDR x8, [x22, #0x30]       | X8 = X4 + 48;                           
        // 0x010CEAB0: LDR x4, [x8]               | X4 = X4 + 48;                           
        // 0x010CEAB4: LDR x8, [x4]               | X8 = X4 + 48;                           
        // 0x010CEAB8: BLR x8                     | X0 = X4 + 48();                         
        // 0x010CEABC: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CEAC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CEAC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CEAC8: MOV w2, w23                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CEACC: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CEAD0: MOV w0, w23                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CEAD4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x010CEAD8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x010CEADC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x010CEAE0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x010CEAE4: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x010CEAE8: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x00B7C21C VirtAddr: 0x00B7C21C -RVA: 0x00B7C21C 
    // -BehaviourUtil.DelayCallExec<object, object>
    //
    // file offset: 0x00B7B9B0 VirtAddr: 0x00B7B9B0 -RVA: 0x00B7B9B0 
    // -BehaviourUtil.DelayCallExec<int, int>
    //
    // file offset: 0x00B7BD94 VirtAddr: 0x00B7BD94 -RVA: 0x00B7BD94 
    // -BehaviourUtil.DelayCallExec<object, bool>
    //
    // file offset: 0x00B7BFD8 VirtAddr: 0x00B7BFD8 -RVA: 0x00B7BFD8 
    // -BehaviourUtil.DelayCallExec<object, int>
    //
    // file offset: 0x00B7C2C8 VirtAddr: 0x00B7C2C8 -RVA: 0x00B7C2C8 
    // -BehaviourUtil.DelayCallExec<object, float>
    //
    // file offset: 0x00B7C58C VirtAddr: 0x00B7C58C -RVA: 0x00B7C58C 
    // -BehaviourUtil.DelayCallExec<float, float>
    //
    //
    // Offset in libil2cpp.so: 0x00B7C21C (12042780), len: 172  VirtAddr: 0x00B7C21C RVA: 0x00B7C21C token: 100696554 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x287C290
    private static System.Collections.IEnumerator DelayCallExec<T1, T2>(float delaytime, System.Action<T1, T2> act, T1 arg1, T2 arg2)
    {
        //
        // Disasemble & Code
        // 0x00B7C21C: STP d9, d8, [sp, #-0x50]!  | stack[1152921515549761248] = ???;  stack[1152921515549761256] = ???;  //  dest_result_addr=1152921515549761248 |  dest_result_addr=1152921515549761256
        // 0x00B7C220: STP x24, x23, [sp, #0x10]  | stack[1152921515549761264] = ???;  stack[1152921515549761272] = ???;  //  dest_result_addr=1152921515549761264 |  dest_result_addr=1152921515549761272
        // 0x00B7C224: STP x22, x21, [sp, #0x20]  | stack[1152921515549761280] = ???;  stack[1152921515549761288] = ???;  //  dest_result_addr=1152921515549761280 |  dest_result_addr=1152921515549761288
        // 0x00B7C228: STP x20, x19, [sp, #0x30]  | stack[1152921515549761296] = ???;  stack[1152921515549761304] = ???;  //  dest_result_addr=1152921515549761296 |  dest_result_addr=1152921515549761304
        // 0x00B7C22C: STP x29, x30, [sp, #0x40]  | stack[1152921515549761312] = ???;  stack[1152921515549761320] = ???;  //  dest_result_addr=1152921515549761312 |  dest_result_addr=1152921515549761320
        // 0x00B7C230: ADD x29, sp, #0x40         | X29 = (1152921515549761248 + 64) = 1152921515549761312 (0x100000028C3F9F20);
        // 0x00B7C234: MOV x21, x4                | X21 = X4;//m1                           
        // 0x00B7C238: LDR x8, [x21, #0x30]       | X8 = X4 + 48;                           
        // 0x00B7C23C: MOV x19, x3                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x00B7C240: MOV x20, x2                | X20 = arg2;//m1                         
        // 0x00B7C244: MOV x22, x1                | X22 = arg1;//m1                         
        // 0x00B7C248: LDR x23, [x8]              | X23 = X4 + 48;                          
        // 0x00B7C24C: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B7C250: MOV x0, x23                | X0 = X4 + 48;//m1                       
        // 0x00B7C254: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48, ????);    
        // 0x00B7C258: MOV x0, x23                | X0 = X4 + 48;//m1                       
        // 0x00B7C25C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48, ????);
        // 0x00B7C260: LDR x8, [x21, #0x30]       | X8 = X4 + 48;                           
        // 0x00B7C264: MOV x21, x0                | X21 = X4 + 48;//m1                      
        // 0x00B7C268: LDR x1, [x8, #8]           | X1 = X4 + 48 + 8;                       
        // 0x00B7C26C: LDR x8, [x1]               | X8 = X4 + 48 + 8;                       
        // 0x00B7C270: BLR x8                     | X0 = X4 + 48 + 8();                     
        // 0x00B7C274: CBZ x21, #0xb7c284         | if (X4 + 48 == 0) goto label_0;         
        if((X4 + 48) == 0)
        {
            goto label_0;
        }
        // 0x00B7C278: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C27C: STP x22, x20, [x21, #0x18] | mem2[0] = arg1;  mem2[0] = arg2;         //  dest_result_addr=0 |  dest_result_addr=0
        mem2[0] = arg1;
        mem2[0] = arg2;
        // 0x00B7C280: B #0xb7c2a8                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00B7C284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
        // 0x00B7C288: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C28C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
        // 0x00B7C290: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00B7C294: STR x22, [x8]              | mem[24] = arg1;                          //  dest_result_addr=24
        mem[24] = arg1;
        // 0x00B7C298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
        // 0x00B7C29C: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00B7C2A0: STR x20, [x8]              | mem[32] = arg2;                          //  dest_result_addr=32
        mem[32] = arg2;
        // 0x00B7C2A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
        label_1:
        // 0x00B7C2A8: STR x19, [x21, #0x28]      | mem2[0] = __RuntimeMethodHiddenParam;    //  dest_result_addr=0
        mem2[0] = __RuntimeMethodHiddenParam;
        // 0x00B7C2AC: MOV x0, x21                | X0 = X4 + 48;//m1                       
        // 0x00B7C2B0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B7C2B4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B7C2B8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B7C2BC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B7C2C0: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B7C2C4: RET                        |  return (System.Collections.IEnumerator)X4 + 48;
        return (System.Collections.IEnumerator)X4 + 48;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CE934 VirtAddr: 0x010CE934 -RVA: 0x010CE934 
    // -BehaviourUtil.DelayCall<object, object, object>
    //
    // file offset: 0x010CDF74 VirtAddr: 0x010CDF74 -RVA: 0x010CDF74 
    // -BehaviourUtil.DelayCall<bool, CombatEntity, int>
    // -BehaviourUtil.DelayCall<bool, object, int>
    //
    // file offset: 0x010CEBBC VirtAddr: 0x010CEBBC -RVA: 0x010CEBBC 
    // -BehaviourUtil.DelayCall<Skill, UnityEngine.Vector3, int[]>
    // -BehaviourUtil.DelayCall<object, UnityEngine.Vector3, object>
    //
    // file offset: 0x010CE3E4 VirtAddr: 0x010CE3E4 -RVA: 0x010CE3E4 
    // -BehaviourUtil.DelayCall<int, Skill, UnityEngine.Vector3>
    // -BehaviourUtil.DelayCall<int, object, UnityEngine.Vector3>
    //
    // file offset: 0x010CED7C VirtAddr: 0x010CED7C -RVA: 0x010CED7C 
    // -BehaviourUtil.DelayCall<float, float, float>
    //
    // file offset: 0x010CE67C VirtAddr: 0x010CE67C -RVA: 0x010CE67C 
    // -BehaviourUtil.DelayCall<CombatEntity, int, int>
    // -BehaviourUtil.DelayCall<object, int, int>
    //
    //
    // Offset in libil2cpp.so: 0x010CE934 (17623348), len: 224  VirtAddr: 0x010CE934 RVA: 0x010CE934 token: 100696555 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint DelayCall<T1, T2, T3>(float delaytime, System.Action<T1, T2, T3> act, T1 arg1, T2 arg2, T3 arg3)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CE934: STP d9, d8, [sp, #-0x50]!  | stack[1152921515549906016] = ???;  stack[1152921515549906024] = ???;  //  dest_result_addr=1152921515549906016 |  dest_result_addr=1152921515549906024
        // 0x010CE938: STP x24, x23, [sp, #0x10]  | stack[1152921515549906032] = ???;  stack[1152921515549906040] = ???;  //  dest_result_addr=1152921515549906032 |  dest_result_addr=1152921515549906040
        // 0x010CE93C: STP x22, x21, [sp, #0x20]  | stack[1152921515549906048] = ???;  stack[1152921515549906056] = ???;  //  dest_result_addr=1152921515549906048 |  dest_result_addr=1152921515549906056
        // 0x010CE940: STP x20, x19, [sp, #0x30]  | stack[1152921515549906064] = ???;  stack[1152921515549906072] = ???;  //  dest_result_addr=1152921515549906064 |  dest_result_addr=1152921515549906072
        // 0x010CE944: STP x29, x30, [sp, #0x40]  | stack[1152921515549906080] = ???;  stack[1152921515549906088] = ???;  //  dest_result_addr=1152921515549906080 |  dest_result_addr=1152921515549906088
        // 0x010CE948: ADD x29, sp, #0x40         | X29 = (1152921515549906016 + 64) = 1152921515549906080 (0x100000028C41D4A0);
        // 0x010CE94C: ADRP x24, #0x3735000       | X24 = 57888768 (0x3735000);             
        // 0x010CE950: LDRB w8, [x24, #0x8eb]     | W8 = (bool)static_value_037358EB;       
        // 0x010CE954: MOV x22, x5                | X22 = X5;//m1                           
        // 0x010CE958: MOV x19, x4                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CE95C: MOV x20, x3                | X20 = arg3;//m1                         
        // 0x010CE960: MOV x21, x2                | X21 = arg2;//m1                         
        // 0x010CE964: MOV x23, x1                | X23 = arg1;//m1                         
        // 0x010CE968: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CE96C: TBNZ w8, #0, #0x10ce988    | if (static_value_037358EB == true) goto label_0;
        // 0x010CE970: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x010CE974: LDR x8, [x8, #0x400]       | X8 = 0x2B8F2D4;                         
        // 0x010CE978: LDR w0, [x8]               | W0 = 0x1377;                            
        // 0x010CE97C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1377, ????);     
        // 0x010CE980: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CE984: STRB w8, [x24, #0x8eb]     | static_value_037358EB = true;            //  dest_result_addr=57891051
        label_0:
        // 0x010CE988: ADRP x24, #0x365d000       | X24 = 57004032 (0x365D000);             
        // 0x010CE98C: LDR x24, [x24, #0x4b8]     | X24 = 1152921504922660864;              
        // 0x010CE990: LDR x0, [x24]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CE994: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CE998: TBZ w8, #0, #0x10ce9ac     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CE99C: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CE9A0: CBNZ w8, #0x10ce9ac        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CE9A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CE9A8: LDR x0, [x24]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CE9AC: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CE9B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CE9B4: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CE9B8: MOV x1, x23                | X1 = arg1;//m1                          
        // 0x010CE9BC: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CE9C0: MOV x2, x21                | X2 = arg2;//m1                          
        // 0x010CE9C4: MOV x3, x20                | X3 = arg3;//m1                          
        // 0x010CE9C8: MOV x4, x19                | X4 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CE9CC: ADD w24, w9, #1            | W24 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CE9D0: STR w24, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CE9D4: LDR x8, [x22, #0x30]       | X8 = X5 + 48;                           
        // 0x010CE9D8: LDR x5, [x8]               | X5 = X5 + 48;                           
        // 0x010CE9DC: LDR x8, [x5]               | X8 = X5 + 48;                           
        // 0x010CE9E0: BLR x8                     | X0 = X5 + 48();                         
        // 0x010CE9E4: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CE9E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CE9EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CE9F0: MOV w2, w24                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CE9F4: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CE9F8: MOV w0, w24                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CE9FC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x010CEA00: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x010CEA04: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x010CEA08: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x010CEA0C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x010CEA10: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x00B7C15C VirtAddr: 0x00B7C15C -RVA: 0x00B7C15C 
    // -BehaviourUtil.DelayCallExec<object, object, object>
    //
    // file offset: 0x00B7B84C VirtAddr: 0x00B7B84C -RVA: 0x00B7B84C 
    // -BehaviourUtil.DelayCallExec<bool, object, int>
    //
    // file offset: 0x00B7BC28 VirtAddr: 0x00B7BC28 -RVA: 0x00B7BC28 
    // -BehaviourUtil.DelayCallExec<int, object, UnityEngine.Vector3>
    //
    // file offset: 0x00B7BE44 VirtAddr: 0x00B7BE44 -RVA: 0x00B7BE44 
    // -BehaviourUtil.DelayCallExec<object, int, int>
    //
    // file offset: 0x00B7C36C VirtAddr: 0x00B7C36C -RVA: 0x00B7C36C 
    // -BehaviourUtil.DelayCallExec<object, UnityEngine.Vector3, object>
    //
    // file offset: 0x00B7C4D0 VirtAddr: 0x00B7C4D0 -RVA: 0x00B7C4D0 
    // -BehaviourUtil.DelayCallExec<float, float, float>
    //
    //
    // Offset in libil2cpp.so: 0x00B7C15C (12042588), len: 192  VirtAddr: 0x00B7C15C RVA: 0x00B7C15C token: 100696556 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x287C2A0
    private static System.Collections.IEnumerator DelayCallExec<T1, T2, T3>(float delaytime, System.Action<T1, T2, T3> act, T1 arg1, T2 arg2, T3 arg3)
    {
        //
        // Disasemble & Code
        // 0x00B7C15C: STP d9, d8, [sp, #-0x50]!  | stack[1152921515550054880] = ???;  stack[1152921515550054888] = ???;  //  dest_result_addr=1152921515550054880 |  dest_result_addr=1152921515550054888
        // 0x00B7C160: STP x24, x23, [sp, #0x10]  | stack[1152921515550054896] = ???;  stack[1152921515550054904] = ???;  //  dest_result_addr=1152921515550054896 |  dest_result_addr=1152921515550054904
        // 0x00B7C164: STP x22, x21, [sp, #0x20]  | stack[1152921515550054912] = ???;  stack[1152921515550054920] = ???;  //  dest_result_addr=1152921515550054912 |  dest_result_addr=1152921515550054920
        // 0x00B7C168: STP x20, x19, [sp, #0x30]  | stack[1152921515550054928] = ???;  stack[1152921515550054936] = ???;  //  dest_result_addr=1152921515550054928 |  dest_result_addr=1152921515550054936
        // 0x00B7C16C: STP x29, x30, [sp, #0x40]  | stack[1152921515550054944] = ???;  stack[1152921515550054952] = ???;  //  dest_result_addr=1152921515550054944 |  dest_result_addr=1152921515550054952
        // 0x00B7C170: ADD x29, sp, #0x40         | X29 = (1152921515550054880 + 64) = 1152921515550054944 (0x100000028C441A20);
        // 0x00B7C174: MOV x21, x5                | X21 = X5;//m1                           
        // 0x00B7C178: LDR x8, [x21, #0x30]       | X8 = X5 + 48;                           
        // 0x00B7C17C: MOV x19, x4                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x00B7C180: MOV x20, x3                | X20 = arg3;//m1                         
        // 0x00B7C184: MOV x22, x2                | X22 = arg2;//m1                         
        // 0x00B7C188: LDR x24, [x8]              | X24 = X5 + 48;                          
        // 0x00B7C18C: MOV x23, x1                | X23 = arg1;//m1                         
        // 0x00B7C190: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B7C194: MOV x0, x24                | X0 = X5 + 48;//m1                       
        // 0x00B7C198: BL #0x277461c              | X0 = sub_277461C( ?? X5 + 48, ????);    
        // 0x00B7C19C: MOV x0, x24                | X0 = X5 + 48;//m1                       
        // 0x00B7C1A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X5 + 48, ????);
        // 0x00B7C1A4: LDR x8, [x21, #0x30]       | X8 = X5 + 48;                           
        // 0x00B7C1A8: MOV x21, x0                | X21 = X5 + 48;//m1                      
        // 0x00B7C1AC: LDR x1, [x8, #8]           | X1 = X5 + 48 + 8;                       
        // 0x00B7C1B0: LDR x8, [x1]               | X8 = X5 + 48 + 8;                       
        // 0x00B7C1B4: BLR x8                     | X0 = X5 + 48 + 8();                     
        // 0x00B7C1B8: CBZ x21, #0xb7c1cc         | if (X5 + 48 == 0) goto label_0;         
        if((X5 + 48) == 0)
        {
            goto label_0;
        }
        // 0x00B7C1BC: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C1C0: STP x23, x22, [x21, #0x18] | mem2[0] = arg1;  mem2[0] = arg2;         //  dest_result_addr=0 |  dest_result_addr=0
        mem2[0] = arg1;
        mem2[0] = arg2;
        // 0x00B7C1C4: STR x20, [x21, #0x28]      | mem2[0] = arg3;                          //  dest_result_addr=0
        mem2[0] = arg3;
        // 0x00B7C1C8: B #0xb7c1fc                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00B7C1CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X5 + 48, ????);    
        // 0x00B7C1D0: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C1D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X5 + 48, ????);    
        // 0x00B7C1D8: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00B7C1DC: STR x23, [x8]              | mem[24] = arg1;                          //  dest_result_addr=24
        mem[24] = arg1;
        // 0x00B7C1E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X5 + 48, ????);    
        // 0x00B7C1E4: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00B7C1E8: STR x22, [x8]              | mem[32] = arg2;                          //  dest_result_addr=32
        mem[32] = arg2;
        // 0x00B7C1EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X5 + 48, ????);    
        // 0x00B7C1F0: MOVZ w8, #0x28             | W8 = 40 (0x28);//ML01                   
        // 0x00B7C1F4: STR x20, [x8]              | mem[40] = arg3;                          //  dest_result_addr=40
        mem[40] = arg3;
        // 0x00B7C1F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X5 + 48, ????);    
        label_1:
        // 0x00B7C1FC: STR x19, [x21, #0x30]      | mem2[0] = __RuntimeMethodHiddenParam;    //  dest_result_addr=0
        mem2[0] = __RuntimeMethodHiddenParam;
        // 0x00B7C200: MOV x0, x21                | X0 = X5 + 48;//m1                       
        // 0x00B7C204: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B7C208: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B7C20C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B7C210: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B7C214: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B7C218: RET                        |  return (System.Collections.IEnumerator)X5 + 48;
        return (System.Collections.IEnumerator)X5 + 48;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x010CE844 VirtAddr: 0x010CE844 -RVA: 0x010CE844 
    // -BehaviourUtil.DelayCall<object, object, object, object>
    //
    // file offset: 0x010CE1F4 VirtAddr: 0x010CE1F4 -RVA: 0x010CE1F4 
    // -BehaviourUtil.DelayCall<int, CombatEntity, FightEnum.EDamageType, int>
    // -BehaviourUtil.DelayCall<int, object, FightEnum.EDamageType, int>
    //
    // file offset: 0x010CE2E4 VirtAddr: 0x010CE2E4 -RVA: 0x010CE2E4 
    // -BehaviourUtil.DelayCall<int, Skill, UnityEngine.Vector3, CombatEntity>
    // -BehaviourUtil.DelayCall<int, object, UnityEngine.Vector3, object>
    //
    // file offset: 0x010CE75C VirtAddr: 0x010CE75C -RVA: 0x010CE75C 
    // -BehaviourUtil.DelayCall<UnityEngine.Transform, int, string, float>
    // -BehaviourUtil.DelayCall<object, int, object, float>
    //
    //
    // Offset in libil2cpp.so: 0x010CE844 (17623108), len: 240  VirtAddr: 0x010CE844 RVA: 0x010CE844 token: 100696557 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static uint DelayCall<T1, T2, T3, T4>(float delaytime, System.Action<T1, T2, T3, T4> act, T1 arg1, T2 arg2, T3 arg3, T4 arg4)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x010CE844: STP d9, d8, [sp, #-0x60]!  | stack[1152921515550207824] = ???;  stack[1152921515550207832] = ???;  //  dest_result_addr=1152921515550207824 |  dest_result_addr=1152921515550207832
        // 0x010CE848: STP x26, x25, [sp, #0x10]  | stack[1152921515550207840] = ???;  stack[1152921515550207848] = ???;  //  dest_result_addr=1152921515550207840 |  dest_result_addr=1152921515550207848
        // 0x010CE84C: STP x24, x23, [sp, #0x20]  | stack[1152921515550207856] = ???;  stack[1152921515550207864] = ???;  //  dest_result_addr=1152921515550207856 |  dest_result_addr=1152921515550207864
        // 0x010CE850: STP x22, x21, [sp, #0x30]  | stack[1152921515550207872] = ???;  stack[1152921515550207880] = ???;  //  dest_result_addr=1152921515550207872 |  dest_result_addr=1152921515550207880
        // 0x010CE854: STP x20, x19, [sp, #0x40]  | stack[1152921515550207888] = ???;  stack[1152921515550207896] = ???;  //  dest_result_addr=1152921515550207888 |  dest_result_addr=1152921515550207896
        // 0x010CE858: STP x29, x30, [sp, #0x50]  | stack[1152921515550207904] = ???;  stack[1152921515550207912] = ???;  //  dest_result_addr=1152921515550207904 |  dest_result_addr=1152921515550207912
        // 0x010CE85C: ADD x29, sp, #0x50         | X29 = (1152921515550207824 + 80) = 1152921515550207904 (0x100000028C466FA0);
        // 0x010CE860: ADRP x25, #0x3735000       | X25 = 57888768 (0x3735000);             
        // 0x010CE864: LDRB w8, [x25, #0x8ea]     | W8 = (bool)static_value_037358EA;       
        // 0x010CE868: MOV x22, x6                | X22 = X6;//m1                           
        // 0x010CE86C: MOV x19, x5                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x010CE870: MOV x20, x4                | X20 = arg4;//m1                         
        // 0x010CE874: MOV x21, x3                | X21 = arg3;//m1                         
        // 0x010CE878: MOV x23, x2                | X23 = arg2;//m1                         
        // 0x010CE87C: MOV x24, x1                | X24 = arg1;//m1                         
        // 0x010CE880: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x010CE884: TBNZ w8, #0, #0x10ce8a0    | if (static_value_037358EA == true) goto label_0;
        // 0x010CE888: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x010CE88C: LDR x8, [x8, #0x420]       | X8 = 0x2B8F2D8;                         
        // 0x010CE890: LDR w0, [x8]               | W0 = 0x1378;                            
        // 0x010CE894: BL #0x2782188              | X0 = sub_2782188( ?? 0x1378, ????);     
        // 0x010CE898: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x010CE89C: STRB w8, [x25, #0x8ea]     | static_value_037358EA = true;            //  dest_result_addr=57891050
        label_0:
        // 0x010CE8A0: ADRP x25, #0x365d000       | X25 = 57004032 (0x365D000);             
        // 0x010CE8A4: LDR x25, [x25, #0x4b8]     | X25 = 1152921504922660864;              
        // 0x010CE8A8: LDR x0, [x25]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x010CE8AC: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x010CE8B0: TBZ w8, #0, #0x10ce8c4     | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x010CE8B4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x010CE8B8: CBNZ w8, #0x10ce8c4        | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x010CE8BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x010CE8C0: LDR x0, [x25]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x010CE8C4: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x010CE8C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CE8CC: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x010CE8D0: MOV x1, x24                | X1 = arg1;//m1                          
        // 0x010CE8D4: LDR w9, [x8, #8]           | W9 = BehaviourUtil.curID;               
        // 0x010CE8D8: MOV x2, x23                | X2 = arg2;//m1                          
        // 0x010CE8DC: MOV x3, x21                | X3 = arg3;//m1                          
        // 0x010CE8E0: MOV x4, x20                | X4 = arg4;//m1                          
        // 0x010CE8E4: ADD w25, w9, #1            | W25 = (BehaviourUtil.curID + 1);        
        uint val_1 = BehaviourUtil.curID + 1;
        // 0x010CE8E8: STR w25, [x8, #8]          | BehaviourUtil.curID = (BehaviourUtil.curID + 1);  //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = val_1;
        // 0x010CE8EC: LDR x8, [x22, #0x30]       | X8 = X6 + 48;                           
        // 0x010CE8F0: MOV x5, x19                | X5 = __RuntimeMethodHiddenParam;//m1    
        // 0x010CE8F4: LDR x6, [x8]               | X6 = X6 + 48;                           
        // 0x010CE8F8: LDR x8, [x6]               | X8 = X6 + 48;                           
        // 0x010CE8FC: BLR x8                     | X0 = X6 + 48();                         
        // 0x010CE900: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
        // 0x010CE904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x010CE908: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x010CE90C: MOV w2, w25                | W2 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CE910: BL #0xb8d738               | X0 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        UnityEngine.Coroutine val_2 = BehaviourUtil.StartCoroutine(routine:  0, id:  0);
        // 0x010CE914: MOV w0, w25                | W0 = (BehaviourUtil.curID + 1);//m1     
        // 0x010CE918: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x010CE91C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x010CE920: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x010CE924: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x010CE928: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x010CE92C: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x010CE930: RET                        |  return (System.UInt32)(BehaviourUtil.curID + 1);
        return (uint)val_1;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x00B7C084 VirtAddr: 0x00B7C084 -RVA: 0x00B7C084 
    // -BehaviourUtil.DelayCallExec<object, object, object, object>
    //
    // file offset: 0x00B7BA60 VirtAddr: 0x00B7BA60 -RVA: 0x00B7BA60 
    // -BehaviourUtil.DelayCallExec<int, object, FightEnum.EDamageType, int>
    //
    // file offset: 0x00B7BB40 VirtAddr: 0x00B7BB40 -RVA: 0x00B7BB40 
    // -BehaviourUtil.DelayCallExec<int, object, UnityEngine.Vector3, object>
    //
    // file offset: 0x00B7BF04 VirtAddr: 0x00B7BF04 -RVA: 0x00B7BF04 
    // -BehaviourUtil.DelayCallExec<object, int, object, float>
    //
    //
    // Offset in libil2cpp.so: 0x00B7C084 (12042372), len: 216  VirtAddr: 0x00B7C084 RVA: 0x00B7C084 token: 100696558 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x287C2B0
    private static System.Collections.IEnumerator DelayCallExec<T1, T2, T3, T4>(float delaytime, System.Action<T1, T2, T3, T4> act, T1 arg1, T2 arg2, T3 arg3, T4 arg4)
    {
        //
        // Disasemble & Code
        // 0x00B7C084: STP d9, d8, [sp, #-0x60]!  | stack[1152921515550364880] = ???;  stack[1152921515550364888] = ???;  //  dest_result_addr=1152921515550364880 |  dest_result_addr=1152921515550364888
        // 0x00B7C088: STP x26, x25, [sp, #0x10]  | stack[1152921515550364896] = ???;  stack[1152921515550364904] = ???;  //  dest_result_addr=1152921515550364896 |  dest_result_addr=1152921515550364904
        // 0x00B7C08C: STP x24, x23, [sp, #0x20]  | stack[1152921515550364912] = ???;  stack[1152921515550364920] = ???;  //  dest_result_addr=1152921515550364912 |  dest_result_addr=1152921515550364920
        // 0x00B7C090: STP x22, x21, [sp, #0x30]  | stack[1152921515550364928] = ???;  stack[1152921515550364936] = ???;  //  dest_result_addr=1152921515550364928 |  dest_result_addr=1152921515550364936
        // 0x00B7C094: STP x20, x19, [sp, #0x40]  | stack[1152921515550364944] = ???;  stack[1152921515550364952] = ???;  //  dest_result_addr=1152921515550364944 |  dest_result_addr=1152921515550364952
        // 0x00B7C098: STP x29, x30, [sp, #0x50]  | stack[1152921515550364960] = ???;  stack[1152921515550364968] = ???;  //  dest_result_addr=1152921515550364960 |  dest_result_addr=1152921515550364968
        // 0x00B7C09C: ADD x29, sp, #0x50         | X29 = (1152921515550364880 + 80) = 1152921515550364960 (0x100000028C48D520);
        // 0x00B7C0A0: MOV x21, x6                | X21 = X6;//m1                           
        // 0x00B7C0A4: LDR x8, [x21, #0x30]       | X8 = X6 + 48;                           
        // 0x00B7C0A8: MOV x19, x5                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x00B7C0AC: MOV x20, x4                | X20 = arg4;//m1                         
        // 0x00B7C0B0: MOV x22, x3                | X22 = arg3;//m1                         
        // 0x00B7C0B4: LDR x25, [x8]              | X25 = X6 + 48;                          
        // 0x00B7C0B8: MOV x23, x2                | X23 = arg2;//m1                         
        // 0x00B7C0BC: MOV x24, x1                | X24 = arg1;//m1                         
        // 0x00B7C0C0: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B7C0C4: MOV x0, x25                | X0 = X6 + 48;//m1                       
        // 0x00B7C0C8: BL #0x277461c              | X0 = sub_277461C( ?? X6 + 48, ????);    
        // 0x00B7C0CC: MOV x0, x25                | X0 = X6 + 48;//m1                       
        // 0x00B7C0D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X6 + 48, ????);
        // 0x00B7C0D4: LDR x8, [x21, #0x30]       | X8 = X6 + 48;                           
        // 0x00B7C0D8: MOV x21, x0                | X21 = X6 + 48;//m1                      
        // 0x00B7C0DC: LDR x1, [x8, #8]           | X1 = X6 + 48 + 8;                       
        // 0x00B7C0E0: LDR x8, [x1]               | X8 = X6 + 48 + 8;                       
        // 0x00B7C0E4: BLR x8                     | X0 = X6 + 48 + 8();                     
        // 0x00B7C0E8: CBZ x21, #0xb7c0fc         | if (X6 + 48 == 0) goto label_0;         
        if((X6 + 48) == 0)
        {
            goto label_0;
        }
        // 0x00B7C0EC: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C0F0: STP x24, x23, [x21, #0x18] | mem2[0] = arg1;  mem2[0] = arg2;         //  dest_result_addr=0 |  dest_result_addr=0
        mem2[0] = arg1;
        mem2[0] = arg2;
        // 0x00B7C0F4: STP x22, x20, [x21, #0x28] | mem2[0] = arg3;  mem2[0] = arg4;         //  dest_result_addr=0 |  dest_result_addr=0
        mem2[0] = arg3;
        mem2[0] = arg4;
        // 0x00B7C0F8: B #0xb7c138                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00B7C0FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X6 + 48, ????);    
        // 0x00B7C100: STR s8, [x21, #0x14]       | mem2[0] = delaytime;                     //  dest_result_addr=0
        mem2[0] = delaytime;
        // 0x00B7C104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X6 + 48, ????);    
        // 0x00B7C108: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00B7C10C: STR x24, [x8]              | mem[24] = arg1;                          //  dest_result_addr=24
        mem[24] = arg1;
        // 0x00B7C110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X6 + 48, ????);    
        // 0x00B7C114: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00B7C118: STR x23, [x8]              | mem[32] = arg2;                          //  dest_result_addr=32
        mem[32] = arg2;
        // 0x00B7C11C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X6 + 48, ????);    
        // 0x00B7C120: MOVZ w8, #0x28             | W8 = 40 (0x28);//ML01                   
        // 0x00B7C124: STR x22, [x8]              | mem[40] = arg3;                          //  dest_result_addr=40
        mem[40] = arg3;
        // 0x00B7C128: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X6 + 48, ????);    
        // 0x00B7C12C: ORR w8, wzr, #0x30         | W8 = 48(0x30);                          
        // 0x00B7C130: STR x20, [x8]              | mem[48] = arg4;                          //  dest_result_addr=48
        mem[48] = arg4;
        // 0x00B7C134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X6 + 48, ????);    
        label_1:
        // 0x00B7C138: STR x19, [x21, #0x38]      | mem2[0] = __RuntimeMethodHiddenParam;    //  dest_result_addr=0
        mem2[0] = __RuntimeMethodHiddenParam;
        // 0x00B7C13C: MOV x0, x21                | X0 = X6 + 48;//m1                       
        // 0x00B7C140: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B7C144: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B7C148: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B7C14C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B7C150: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B7C154: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00B7C158: RET                        |  return (System.Collections.IEnumerator)X6 + 48;
        return (System.Collections.IEnumerator)X6 + 48;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E238 (12116536), len: 156  VirtAddr: 0x00B8E238 RVA: 0x00B8E238 token: 100696559 methodIndex: 25103 delegateWrapperIndex: 0 methodInvoker: 0
    private static Mihua.Utils.WaitForSeconds GetWaitSeconds(float delaytime)
    {
        //
        // Disasemble & Code
        // 0x00B8E238: STP d9, d8, [sp, #-0x30]!  | stack[1152921515550502528] = ???;  stack[1152921515550502536] = ???;  //  dest_result_addr=1152921515550502528 |  dest_result_addr=1152921515550502536
        // 0x00B8E23C: STP x20, x19, [sp, #0x10]  | stack[1152921515550502544] = ???;  stack[1152921515550502552] = ???;  //  dest_result_addr=1152921515550502544 |  dest_result_addr=1152921515550502552
        // 0x00B8E240: STP x29, x30, [sp, #0x20]  | stack[1152921515550502560] = ???;  stack[1152921515550502568] = ???;  //  dest_result_addr=1152921515550502560 |  dest_result_addr=1152921515550502568
        // 0x00B8E244: ADD x29, sp, #0x20         | X29 = (1152921515550502528 + 32) = 1152921515550502560 (0x100000028C4AEEA0);
        // 0x00B8E248: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B8E24C: LDRB w8, [x19, #0xa25]     | W8 = (bool)static_value_03733A25;       
        // 0x00B8E250: MOV v8.16b, v0.16b         | V8 = delaytime;//m1                     
        // 0x00B8E254: TBNZ w8, #0, #0xb8e270     | if (static_value_03733A25 == true) goto label_0;
        // 0x00B8E258: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B8E25C: LDR x8, [x8, #0x620]       | X8 = 0x2B8F2F4;                         
        // 0x00B8E260: LDR w0, [x8]               | W0 = 0x137F;                            
        // 0x00B8E264: BL #0x2782188              | X0 = sub_2782188( ?? 0x137F, ????);     
        // 0x00B8E268: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E26C: STRB w8, [x19, #0xa25]     | static_value_03733A25 = true;            //  dest_result_addr=57883173
        label_0:
        // 0x00B8E270: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B8E274: LDR x8, [x8, #0x478]       | X8 = 1152921504924311552;               
        // 0x00B8E278: LDR x0, [x8]               | X0 = typeof(Mihua.Utils.ObjectPool<T>); 
        // 0x00B8E27C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_10A;
        // 0x00B8E280: TBZ w8, #0, #0xb8e290      | if (Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8E284: LDR w8, [x0, #0xbc]        | W8 = Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E288: CBNZ w8, #0xb8e290         | if (Mihua.Utils.ObjectPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8E28C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Utils.ObjectPool<T>), ????);
        label_2:
        // 0x00B8E290: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
        // 0x00B8E294: LDR x8, [x8, #0x888]       | X8 = 1152921515550485456;               
        // 0x00B8E298: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E29C: LDR x1, [x8]               | X1 = public static Mihua.Utils.WaitForSeconds Mihua.Utils.ObjectPool<Mihua.Utils.WaitForSeconds>::GetObj();
        // 0x00B8E2A0: BL #0x19e6190              | X0 = Mihua.Utils.ObjectPool<BuffState>.GetObj();
        BuffState val_1 = Mihua.Utils.ObjectPool<BuffState>.GetObj();
        // 0x00B8E2A4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B8E2A8: CBNZ x19, #0xb8e2b0        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B8E2AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B8E2B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E2B4: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B8E2B8: MOV v0.16b, v8.16b         | V0 = delaytime;//m1                     
        // 0x00B8E2BC: BL #0xac2b74               | val_1.set_lastSeconds(value:  delaytime);
        val_1.lastSeconds = delaytime;
        // 0x00B8E2C0: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B8E2C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E2C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E2CC: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8E2D0: RET                        |  return (Mihua.Utils.WaitForSeconds)val_1;
        return (Mihua.Utils.WaitForSeconds)val_1;
        //  |  // // {name=val_0, type=Mihua.Utils.WaitForSeconds, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E2D4 (12116692), len: 4  VirtAddr: 0x00B8E2D4 RVA: 0x00B8E2D4 token: 100696560 methodIndex: 25104 delegateWrapperIndex: 0 methodInvoker: 0
    public static void DelayPause(float time)
    {
        //
        // Disasemble & Code
        // 0x00B8E2D4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D7F0 (12113904), len: 292  VirtAddr: 0x00B8D7F0 RVA: 0x00B8D7F0 token: 100696561 methodIndex: 25105 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.MonoBehaviour get_GlobalCoroutine()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        UnityEngine.MonoBehaviour val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        // 0x00B8D7F0: STP x20, x19, [sp, #-0x20]! | stack[1152921515550735760] = ???;  stack[1152921515550735768] = ???;  //  dest_result_addr=1152921515550735760 |  dest_result_addr=1152921515550735768
        // 0x00B8D7F4: STP x29, x30, [sp, #0x10]  | stack[1152921515550735776] = ???;  stack[1152921515550735784] = ???;  //  dest_result_addr=1152921515550735776 |  dest_result_addr=1152921515550735784
        // 0x00B8D7F8: ADD x29, sp, #0x10         | X29 = (1152921515550735760 + 16) = 1152921515550735776 (0x100000028C4E7DA0);
        // 0x00B8D7FC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B8D800: LDRB w8, [x19, #0xa26]     | W8 = (bool)static_value_03733A26;       
        // 0x00B8D804: TBNZ w8, #0, #0xb8d820     | if (static_value_03733A26 == true) goto label_0;
        // 0x00B8D808: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B8D80C: LDR x8, [x8, #0xd0]        | X8 = 0x2B8F2F0;                         
        // 0x00B8D810: LDR w0, [x8]               | W0 = 0x137E;                            
        // 0x00B8D814: BL #0x2782188              | X0 = sub_2782188( ?? 0x137E, ????);     
        // 0x00B8D818: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D81C: STRB w8, [x19, #0xa26]     | static_value_03733A26 = true;            //  dest_result_addr=57883174
        label_0:
        // 0x00B8D820: ADRP x20, #0x365d000       | X20 = 57004032 (0x365D000);             
        // 0x00B8D824: LDR x20, [x20, #0x4b8]     | X20 = 1152921504922660864;              
        // 0x00B8D828: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        // 0x00B8D82C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D830: TBZ w8, #0, #0xb8d844      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8D834: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D838: CBNZ w8, #0xb8d844         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8D83C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D840: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_3 = null;
        label_2:
        // 0x00B8D844: ADRP x9, #0x35fe000        | X9 = 56614912 (0x35FE000);              
        // 0x00B8D848: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D84C: LDR x9, [x9, #0x810]       | X9 = 1152921504697475072;               
        // 0x00B8D850: LDR x19, [x8]              | X19 = BehaviourUtil.globalCoroutine;    
        val_4 = BehaviourUtil.globalCoroutine;
        // 0x00B8D854: LDR x0, [x9]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B8D858: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B8D85C: TBZ w8, #0, #0xb8d86c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B8D860: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D864: CBNZ w8, #0xb8d86c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B8D868: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x00B8D86C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D870: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D874: MOV x1, x19                | X1 = BehaviourUtil.globalCoroutine;//m1 
        // 0x00B8D878: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8D87C: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_4);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  val_4);
        // 0x00B8D880: TBZ w0, #0, #0xb8d8e4      | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x00B8D884: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00B8D888: LDR x8, [x8, #0xf58]       | X8 = 1152921504923992064;               
        // 0x00B8D88C: LDR x0, [x8]               | X0 = typeof(GlobalObject);              
        // 0x00B8D890: LDRB w8, [x0, #0x10a]      | W8 = GlobalObject.__il2cppRuntimeField_10A;
        // 0x00B8D894: TBZ w8, #0, #0xb8d8a4      | if (GlobalObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B8D898: LDR w8, [x0, #0xbc]        | W8 = GlobalObject.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D89C: CBNZ w8, #0xb8d8a4         | if (GlobalObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B8D8A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(GlobalObject), ????);
        label_7:
        // 0x00B8D8A4: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00B8D8A8: LDR x8, [x8, #0xd88]       | X8 = 1152921515550718672;               
        // 0x00B8D8AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D8B0: LDR x1, [x8]               | X1 = public static BehaviourUtil GlobalObject::AddComponent<BehaviourUtil>();
        // 0x00B8D8B4: BL #0xfd7a98               | X0 = GlobalObject.AddComponent<ZMG>();  
        ZMG val_2 = GlobalObject.AddComponent<ZMG>();
        // 0x00B8D8B8: LDR x8, [x20]              | X8 = typeof(BehaviourUtil);             
        val_5 = null;
        // 0x00B8D8BC: MOV x19, x0                | X19 = val_2;//m1                        
        val_4 = val_2;
        // 0x00B8D8C0: LDRB w9, [x8, #0x10a]      | W9 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D8C4: TBZ w9, #0, #0xb8d8dc      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B8D8C8: LDR w9, [x8, #0xbc]        | W9 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D8CC: CBNZ w9, #0xb8d8dc         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B8D8D0: MOV x0, x8                 | X0 = 1152921504922660864 (0x1000000012D2F000);//ML01
        // 0x00B8D8D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D8D8: LDR x8, [x20]              | X8 = typeof(BehaviourUtil);             
        val_5 = null;
        label_9:
        // 0x00B8D8DC: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D8E0: STR x19, [x8]              | BehaviourUtil.globalCoroutine = val_2;   //  dest_result_addr=1152921504922664960
        BehaviourUtil.globalCoroutine = val_4;
        label_5:
        // 0x00B8D8E4: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_6 = null;
        // 0x00B8D8E8: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B8D8EC: TBZ w8, #0, #0xb8d900      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B8D8F0: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D8F4: CBNZ w8, #0xb8d900         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B8D8F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B8D8FC: LDR x0, [x20]              | X0 = typeof(BehaviourUtil);             
        val_6 = null;
        label_11:
        // 0x00B8D900: LDR x8, [x0, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8D904: LDR x0, [x8]               | X0 = val_2;                             
        // 0x00B8D908: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D90C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D910: RET                        |  return (UnityEngine.MonoBehaviour)val_2;
        return (UnityEngine.MonoBehaviour)BehaviourUtil.globalCoroutine;
        //  |  // // {name=val_0, type=UnityEngine.MonoBehaviour, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E2D8 (12116696), len: 224  VirtAddr: 0x00B8E2D8 RVA: 0x00B8E2D8 token: 100696562 methodIndex: 25106 delegateWrapperIndex: 0 methodInvoker: 0
    private static BehaviourUtil()
    {
        //
        // Disasemble & Code
        // 0x00B8E2D8: STP x20, x19, [sp, #-0x20]! | stack[1152921515550854928] = ???;  stack[1152921515550854936] = ???;  //  dest_result_addr=1152921515550854928 |  dest_result_addr=1152921515550854936
        // 0x00B8E2DC: STP x29, x30, [sp, #0x10]  | stack[1152921515550854944] = ???;  stack[1152921515550854952] = ???;  //  dest_result_addr=1152921515550854944 |  dest_result_addr=1152921515550854952
        // 0x00B8E2E0: ADD x29, sp, #0x10         | X29 = (1152921515550854928 + 16) = 1152921515550854944 (0x100000028C504F20);
        // 0x00B8E2E4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B8E2E8: LDRB w8, [x19, #0xa27]     | W8 = (bool)static_value_03733A27;       
        // 0x00B8E2EC: TBNZ w8, #0, #0xb8e308     | if (static_value_03733A27 == true) goto label_0;
        // 0x00B8E2F0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00B8E2F4: LDR x8, [x8, #0x878]       | X8 = 0x2B8F250;                         
        // 0x00B8E2F8: LDR w0, [x8]               | W0 = 0x1356;                            
        // 0x00B8E2FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1356, ????);     
        // 0x00B8E300: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E304: STRB w8, [x19, #0xa27]     | static_value_03733A27 = true;            //  dest_result_addr=57883175
        label_0:
        // 0x00B8E308: ADRP x20, #0x365d000       | X20 = 57004032 (0x365D000);             
        // 0x00B8E30C: LDR x20, [x20, #0x4b8]     | X20 = 1152921504922660864;              
        // 0x00B8E310: LDR x8, [x20]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8E314: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E318: STR wzr, [x8, #8]          | BehaviourUtil.curID = null;              //  dest_result_addr=1152921504922664968
        BehaviourUtil.curID = 0;
        // 0x00B8E31C: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x00B8E320: LDR x8, [x8, #0x210]       | X8 = 1152921504615792640;               
        // 0x00B8E324: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds> val_1 = null;
        // 0x00B8E328: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B8E32C: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00B8E330: LDR x8, [x8, #0xa90]       | X8 = 1152921515550839888;               
        // 0x00B8E334: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B8E338: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>::.ctor();
        // 0x00B8E33C: BL #0x249e42c              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.UInt32, Mihua.Utils.WaitForSeconds>();
        // 0x00B8E340: LDR x8, [x20]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8E344: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E348: STR x19, [x8, #0x10]       | BehaviourUtil.allWaitSecondDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504922664976
        BehaviourUtil.allWaitSecondDic = val_1;
        // 0x00B8E34C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8E350: LDR x8, [x8, #0xac8]       | X8 = 1152921504615792640;               
        // 0x00B8E354: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator> val_2 = null;
        // 0x00B8E358: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B8E35C: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00B8E360: LDR x8, [x8, #0xf0]        | X8 = 1152921515550840912;               
        // 0x00B8E364: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B8E368: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>::.ctor();
        // 0x00B8E36C: BL #0x249e42c              | .ctor();                                
        val_2 = new System.Collections.Generic.Dictionary<System.UInt32, System.Collections.IEnumerator>();
        // 0x00B8E370: LDR x8, [x20]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8E374: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E378: STR x19, [x8, #0x18]       | BehaviourUtil.allCoroutineDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504922664984
        BehaviourUtil.allCoroutineDic = val_2;
        // 0x00B8E37C: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00B8E380: LDR x8, [x8, #0x920]       | X8 = 1152921504616644608;               
        // 0x00B8E384: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<Mihua.Utils.WaitForSeconds> val_3 = null;
        // 0x00B8E388: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B8E38C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B8E390: LDR x8, [x8, #0xca8]       | X8 = 1152921515550841936;               
        // 0x00B8E394: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B8E398: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>::.ctor();
        // 0x00B8E39C: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<Mihua.Utils.WaitForSeconds>();
        // 0x00B8E3A0: LDR x8, [x20]              | X8 = typeof(BehaviourUtil);             
        // 0x00B8E3A4: LDR x8, [x8, #0xa0]        | X8 = BehaviourUtil.__il2cppRuntimeField_static_fields;
        // 0x00B8E3A8: STR x19, [x8, #0x20]       | BehaviourUtil.allCoroutineList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504922664992
        BehaviourUtil.allCoroutineList = val_3;
        // 0x00B8E3AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E3B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E3B4: RET                        |  return;                                
        return;
    
    }

}
