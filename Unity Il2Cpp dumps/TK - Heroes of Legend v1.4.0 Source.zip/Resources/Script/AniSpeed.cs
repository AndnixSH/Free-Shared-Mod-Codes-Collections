using UnityEngine;
public class AniSpeed : MonoBehaviour
{
    // Fields
    public float speed; //  0x00000018
    public UnityEngine.Animation ani; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B299B0 (11704752), len: 16  VirtAddr: 0x00B299B0 RVA: 0x00B299B0 token: 100696528 methodIndex: 24848 delegateWrapperIndex: 0 methodInvoker: 0
    public AniSpeed()
    {
        //
        // Disasemble & Code
        // 0x00B299B0: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00B299B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B299B8: STR w8, [x0, #0x18]        | this.speed = 1;                          //  dest_result_addr=1152921515546221352
        this.speed = 1f;
        // 0x00B299BC: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B299C0 (11704768), len: 320  VirtAddr: 0x00B299C0 RVA: 0x00B299C0 token: 100696529 methodIndex: 24849 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Animation val_7;
        // 0x00B299C0: STP d9, d8, [sp, #-0x40]!  | stack[1152921515546345840] = ???;  stack[1152921515546345848] = ???;  //  dest_result_addr=1152921515546345840 |  dest_result_addr=1152921515546345848
        // 0x00B299C4: STP x22, x21, [sp, #0x10]  | stack[1152921515546345856] = ???;  stack[1152921515546345864] = ???;  //  dest_result_addr=1152921515546345856 |  dest_result_addr=1152921515546345864
        // 0x00B299C8: STP x20, x19, [sp, #0x20]  | stack[1152921515546345872] = ???;  stack[1152921515546345880] = ???;  //  dest_result_addr=1152921515546345872 |  dest_result_addr=1152921515546345880
        // 0x00B299CC: STP x29, x30, [sp, #0x30]  | stack[1152921515546345888] = ???;  stack[1152921515546345896] = ???;  //  dest_result_addr=1152921515546345888 |  dest_result_addr=1152921515546345896
        // 0x00B299D0: ADD x29, sp, #0x30         | X29 = (1152921515546345840 + 48) = 1152921515546345888 (0x100000028C0B81A0);
        // 0x00B299D4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B299D8: LDRB w8, [x20, #0x75b]     | W8 = (bool)static_value_0373375B;       
        // 0x00B299DC: MOV x19, x0                | X19 = 1152921515546357904 (0x100000028C0BB090);//ML01
        // 0x00B299E0: TBNZ w8, #0, #0xb299fc     | if (static_value_0373375B == true) goto label_0;
        // 0x00B299E4: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00B299E8: LDR x8, [x8, #0x208]       | X8 = 0x2B8AF38;                         
        // 0x00B299EC: LDR w0, [x8]               | W0 = 0x28C;                             
        // 0x00B299F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x28C, ????);      
        // 0x00B299F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B299F8: STRB w8, [x20, #0x75b]     | static_value_0373375B = true;            //  dest_result_addr=57882459
        label_0:
        // 0x00B299FC: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x00B29A00: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        // 0x00B29A04: LDR x20, [x19, #0x20]      | X20 = this.ani; //P2                    
        // 0x00B29A08: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B29A0C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B29A10: TBZ w8, #0, #0xb29a20      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B29A14: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B29A18: CBNZ w8, #0xb29a20         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B29A1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B29A20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B29A24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29A28: MOV x1, x20                | X1 = this.ani;//m1                      
        // 0x00B29A2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B29A30: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.ani);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.ani);
        // 0x00B29A34: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B29A38: TBZ w8, #0, #0xb29a5c      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B29A3C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B29A40: LDR x8, [x8, #0x668]       | X8 = 1152921511735556432;               
        // 0x00B29A44: MOV x0, x19                | X0 = 1152921515546357904 (0x100000028C0BB090);//ML01
        // 0x00B29A48: LDR x1, [x8]               | X1 = public UnityEngine.Animation UnityEngine.Component::GetComponent<UnityEngine.Animation>();
        // 0x00B29A4C: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Animation>();
        UnityEngine.Animation val_3 = this.GetComponent<UnityEngine.Animation>();
        // 0x00B29A50: MOV x20, x0                | X20 = val_3;//m1                        
        val_7 = val_3;
        // 0x00B29A54: STR x20, [x19, #0x20]      | this.ani = val_3;                        //  dest_result_addr=1152921515546357936
        this.ani = val_7;
        // 0x00B29A58: B #0xb29a60                |  goto label_4;                          
        goto label_4;
        label_3:
        // 0x00B29A5C: LDR x20, [x19, #0x20]      | X20 = this.ani; //P2                    
        val_7 = this.ani;
        label_4:
        // 0x00B29A60: CBNZ x20, #0xb29a68        | if (this.ani != null) goto label_5;     
        if(val_7 != null)
        {
            goto label_5;
        }
        // 0x00B29A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B29A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29A6C: MOV x0, x20                | X0 = this.ani;//m1                      
        // 0x00B29A70: BL #0x270becc              | X0 = this.ani.get_clip();               
        UnityEngine.AnimationClip val_4 = val_7.clip;
        // 0x00B29A74: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00B29A78: CBNZ x21, #0xb29a80        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B29A7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00B29A80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29A84: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B29A88: BL #0x1b759fc              | X0 = val_4.get_name();                  
        string val_5 = val_4.name;
        // 0x00B29A8C: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B29A90: CBNZ x20, #0xb29a98        | if (this.ani != null) goto label_7;     
        if(val_7 != null)
        {
            goto label_7;
        }
        // 0x00B29A94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00B29A98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29A9C: MOV x0, x20                | X0 = this.ani;//m1                      
        // 0x00B29AA0: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B29AA4: BL #0x270c494              | X0 = this.ani.get_Item(name:  val_5);   
        UnityEngine.AnimationState val_6 = val_7.Item[val_5];
        // 0x00B29AA8: LDR s8, [x19, #0x18]       | S8 = this.speed; //P2                   
        // 0x00B29AAC: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00B29AB0: CBNZ x20, #0xb29ab8        | if (val_6 != null) goto label_8;        
        if(val_6 != null)
        {
            goto label_8;
        }
        // 0x00B29AB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00B29AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29ABC: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00B29AC0: MOV v0.16b, v8.16b         | V0 = this.speed;//m1                    
        // 0x00B29AC4: BL #0x270ea00              | val_6.set_speed(value:  this.speed);    
        val_6.speed = this.speed;
        // 0x00B29AC8: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B29ACC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B29AD0: TBZ w8, #0, #0xb29ae0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B29AD4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B29AD8: CBNZ w8, #0xb29ae0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B29ADC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_10:
        // 0x00B29AE0: MOV x1, x19                | X1 = 1152921515546357904 (0x100000028C0BB090);//ML01
        // 0x00B29AE4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29AE8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29AEC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B29AF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B29AF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29AF8: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B29AFC: B #0x1b78acc               | UnityEngine.Object.Destroy(obj:  0); return;
        UnityEngine.Object.Destroy(obj:  0);
        return;
    
    }

}
