using UnityEngine;

namespace SevenZip.Compression.RangeCoder
{
    internal struct BitTreeDecoder
    {
        // Fields
        private SevenZip.Compression.RangeCoder.BitDecoder[] Models; //  0x00000000
        private int NumBitLevels; //  0x00000008
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD7A8C (11369100), len: 152  VirtAddr: 0x00AD7A8C RVA: 0x00AD7A8C token: 100681682 methodIndex: 54717 delegateWrapperIndex: 0 methodInvoker: 0
        public BitTreeDecoder(int numBitLevels)
        {
            //
            // Disasemble & Code
            // 0x00AD7A8C: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513110561056 (0x10000001FADC6120);
            // 0x00AD7A90: B #0xad7a0c                | goto label_SevenZip_Compression_RangeCoder_BitEncoder_GetPrice1_GL00AD7A0C;
            label_SevenZip_Compression_RangeCoder_BitTreeDecoder__ctor_GL00AD7A94:
            // 0x00AD7A94: STP x24, x23, [sp, #-0x40]! | stack[1152921513110548976] = ???;  stack[1152921513110548984] = ???;  //  dest_result_addr=1152921513110548976 |  dest_result_addr=1152921513110548984
            // 0x00AD7A98: STP x22, x21, [sp, #0x10]  | stack[1152921513110548992] = ???;  stack[1152921513110549000] = ???;  //  dest_result_addr=1152921513110548992 |  dest_result_addr=1152921513110549000
            // 0x00AD7A9C: STP x20, x19, [sp, #0x20]  | stack[1152921513110549008] = ???;  stack[1152921513110549016] = ???;  //  dest_result_addr=1152921513110549008 |  dest_result_addr=1152921513110549016
            // 0x00AD7AA0: STP x29, x30, [sp, #0x30]  | stack[1152921513110549024] = ???;  stack[1152921513110549032] = ???;  //  dest_result_addr=1152921513110549024 |  dest_result_addr=1152921513110549032
            // 0x00AD7AA4: ADD x29, sp, #0x30         | X29 = (1152921513110548976 + 48) = 1152921513110549024 (0x10000001FADC3220);
            // 0x00AD7AA8: MOV x19, x0                | X19 = 1152921513110561056 (0x10000001FADC6120);//ML01
            // 0x00AD7AAC: LDR w8, [x19, #8]          |  //  find_add[1152921513110561040]
            // 0x00AD7AB0: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            // 0x00AD7AB4: AND x8, x8, #0x1f          | X8 = (X8 & 31);                         
            var val_1 = X8 & 31;
            // 0x00AD7AB8: LSL w8, w20, w8            | W8 = (1 << (X8 & 31));                  
            val_1 = 1 << val_1;
            // 0x00AD7ABC: CMP w8, #2                 | STATE = COMPARE((1 << (X8 & 31)), 0x2)  
            // 0x00AD7AC0: B.LT #0xad7b10             | if (val_1 < 0x2) goto label_0;          
            if(val_1 < 2)
            {
                goto label_0;
            }
            // 0x00AD7AC4: ORR w21, wzr, #0x400       | W21 = 1024(0x400);                      
            // 0x00AD7AC8: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            var val_2 = 1;
            label_3:
            // 0x00AD7ACC: LDR x23, [x19]             | X23 = typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder);
            // 0x00AD7AD0: CBNZ x23, #0xad7ad8        | if (typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder) != 0) goto label_1;
            if(new SevenZip.Compression.RangeCoder.BitTreeDecoder() != 0)
            {
                goto label_1;
            }
            // 0x00AD7AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110561040], ????);
            label_1:
            // 0x00AD7AD8: LDR w8, [x23, #0x18]       | W8 = SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze;
            // 0x00AD7ADC: CMP w22, w8                | STATE = COMPARE(0x1, SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze)
            // 0x00AD7AE0: B.LO #0xad7af0             | if (1 < SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze) goto label_2;
            // 0x00AD7AE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110561040], ????);
            // 0x00AD7AE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD7AEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110561040], ????);
            label_2:
            // 0x00AD7AF0: ADD x8, x23, x22, lsl #2   |  //  not_find_field:typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder).4
            // 0x00AD7AF4: STR w21, [x8, #0x20]       | SevenZip.Compression.RangeCoder.__il2cppRuntimeField_20 = 0x400;  //  dest_result_addr=1152921507406452224
            SevenZip.Compression.RangeCoder.__il2cppRuntimeField_20 = 1024;
            // 0x00AD7AF8: LDR w8, [x19, #8]          |  //  find_add[1152921513110561040]
            // 0x00AD7AFC: ADD w22, w22, #1           | W22 = (1 + 1);                          
            val_2 = val_2 + 1;
            // 0x00AD7B00: AND x8, x8, #0x1f          | X8 = (SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze & 31) = 0 (0x00000000);
            // 0x00AD7B04: LSL w8, w20, w8            | W8 = (1 << 0) = 0 (0x00000000);         
            // 0x00AD7B08: CMP x22, w8, sxtw          | STATE = COMPARE((1 + 1), (0) << )       
            // 0x00AD7B0C: B.LT #0xad7acc             | if (1 < 0 << ) goto label_3;            
            if(val_2 < (0 << ))
            {
                goto label_3;
            }
            label_0:
            // 0x00AD7B10: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7B14: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7B18: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7B1C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AD7B20: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7B24 (11369252), len: 184  VirtAddr: 0x00AD7B24 RVA: 0x00AD7B24 token: 100681683 methodIndex: 54718 delegateWrapperIndex: 0 methodInvoker: 0
        public void Init()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x00AD7B24: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513110673056 (0x10000001FADE16A0);
            // 0x00AD7B28: B #0xad7a94                | goto label_SevenZip_Compression_RangeCoder_BitTreeDecoder__ctor_GL00AD7A94;
            label_SevenZip_Compression_RangeCoder_BitTreeDecoder_Init_GL00AD7B2C:
            // 0x00AD7B2C: STP x26, x25, [sp, #-0x50]! | stack[1152921513110660960] = ???;  stack[1152921513110660968] = ???;  //  dest_result_addr=1152921513110660960 |  dest_result_addr=1152921513110660968
            // 0x00AD7B30: STP x24, x23, [sp, #0x10]  | stack[1152921513110660976] = ???;  stack[1152921513110660984] = ???;  //  dest_result_addr=1152921513110660976 |  dest_result_addr=1152921513110660984
            // 0x00AD7B34: STP x22, x21, [sp, #0x20]  | stack[1152921513110660992] = ???;  stack[1152921513110661000] = ???;  //  dest_result_addr=1152921513110660992 |  dest_result_addr=1152921513110661000
            // 0x00AD7B38: STP x20, x19, [sp, #0x30]  | stack[1152921513110661008] = ???;  stack[1152921513110661016] = ???;  //  dest_result_addr=1152921513110661008 |  dest_result_addr=1152921513110661016
            // 0x00AD7B3C: STP x29, x30, [sp, #0x40]  | stack[1152921513110661024] = ???;  stack[1152921513110661032] = ???;  //  dest_result_addr=1152921513110661024 |  dest_result_addr=1152921513110661032
            // 0x00AD7B40: ADD x29, sp, #0x40         | X29 = (1152921513110660960 + 64) = 1152921513110661024 (0x10000001FADDE7A0);
            // 0x00AD7B44: MOV x19, x0                | X19 = 1152921513110673056 (0x10000001FADE16A0);//ML01
            // 0x00AD7B48: LDR w8, [x19, #8]          |  //  find_add[1152921513110673040]
            // 0x00AD7B4C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00AD7B50: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            // 0x00AD7B54: CMP w8, #1                 | STATE = COMPARE(W8, 0x1)                
            // 0x00AD7B58: B.LT #0xad7bb4             | if (W8 < 0x1) goto label_0;             
            if(W8 < 1)
            {
                goto label_0;
            }
            // 0x00AD7B5C: ADD w23, w8, #1            | W23 = (W8 + 1);                         
            var val_1 = W8 + 1;
            // 0x00AD7B60: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            label_3:
            // 0x00AD7B64: LDR x24, [x19]             | X24 = typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder);
            // 0x00AD7B68: CBNZ x24, #0xad7b70        | if (typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder) != 0) goto label_1;
            if(new SevenZip.Compression.RangeCoder.BitTreeDecoder() != 0)
            {
                goto label_1;
            }
            // 0x00AD7B6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110673040], ????);
            label_1:
            // 0x00AD7B70: LDR w8, [x24, #0x18]       | W8 = SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze;
            // 0x00AD7B74: MOV w25, w22               | W25 = 1 (0x1);//ML01                    
            // 0x00AD7B78: CMP w22, w8                | STATE = COMPARE(0x1, SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze)
            // 0x00AD7B7C: B.LO #0xad7b8c             | if (1 < SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze) goto label_2;
            // 0x00AD7B80: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110673040], ????);
            // 0x00AD7B84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD7B88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110673040], ????);
            label_2:
            // 0x00AD7B8C: ADD x8, x24, x25, lsl #2   |  //  not_find_field:typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder).4
            // 0x00AD7B90: ADD x0, x8, #0x20          | X0 = (SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze + 32) = 1152921507406452224 (0x10000000A6DE9600);
            // 0x00AD7B94: MOV x1, x20                | X1 = X1;//m1                            
            // 0x00AD7B98: BL #0xad7464               | X0 = label_SevenZip_Compression_RangeCoder_BitDecoder_Init_GL00AD7464();
            // 0x00AD7B9C: ADD w22, w0, w22, lsl #1   | W22 = (1152921507406452224 + 2) = val_5 (0x10000000A6DE9602);
            val_5 = 1152921507406452226;
            // 0x00AD7BA0: SUB w23, w23, #1           | W23 = ((W8 + 1) - 1);                   
            val_1 = val_1 - 1;
            // 0x00AD7BA4: CMP w23, #1                | STATE = COMPARE(((W8 + 1) - 1), 0x1)    
            // 0x00AD7BA8: B.GT #0xad7b64             | if (val_1 > 0x1) goto label_3;          
            if(val_1 > 1)
            {
                goto label_3;
            }
            // 0x00AD7BAC: LDR w8, [x19, #8]          |  //  find_add[1152921513110673040]
            // 0x00AD7BB0: B #0xad7bb8                |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x00AD7BB4: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_5 = 1;
            label_4:
            // 0x00AD7BB8: AND w8, w8, #0x1f          | W8 = (W8 & 31);                         
            var val_2 = W8 & 31;
            // 0x00AD7BBC: LSL w8, w21, w8            | W8 = (1 << (W8 & 31));                  
            val_2 = 1 << val_2;
            // 0x00AD7BC0: SUB w0, w22, w8            | W0 = (val_5 - (1 << (W8 & 31)));        
            var val_3 = val_5 - val_2;
            // 0x00AD7BC4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7BC8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7BCC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7BD0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD7BD4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD7BD8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7BDC (11369436), len: 188  VirtAddr: 0x00AD7BDC RVA: 0x00AD7BDC token: 100681684 methodIndex: 54719 delegateWrapperIndex: 0 methodInvoker: 0
        public uint Decode(SevenZip.Compression.RangeCoder.Decoder rangeDecoder)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AD7BDC: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513110789152 (0x10000001FADFDC20);
            // 0x00AD7BE0: B #0xad7b2c                | goto label_SevenZip_Compression_RangeCoder_BitTreeDecoder_Init_GL00AD7B2C;
            label_SevenZip_Compression_RangeCoder_BitTreeDecoder_Decode_GL00AD7BE4:
            // 0x00AD7BE4: STP x26, x25, [sp, #-0x50]! | stack[1152921513110777056] = ???;  stack[1152921513110777064] = ???;  //  dest_result_addr=1152921513110777056 |  dest_result_addr=1152921513110777064
            // 0x00AD7BE8: STP x24, x23, [sp, #0x10]  | stack[1152921513110777072] = ???;  stack[1152921513110777080] = ???;  //  dest_result_addr=1152921513110777072 |  dest_result_addr=1152921513110777080
            // 0x00AD7BEC: STP x22, x21, [sp, #0x20]  | stack[1152921513110777088] = ???;  stack[1152921513110777096] = ???;  //  dest_result_addr=1152921513110777088 |  dest_result_addr=1152921513110777096
            // 0x00AD7BF0: STP x20, x19, [sp, #0x30]  | stack[1152921513110777104] = ???;  stack[1152921513110777112] = ???;  //  dest_result_addr=1152921513110777104 |  dest_result_addr=1152921513110777112
            // 0x00AD7BF4: STP x29, x30, [sp, #0x40]  | stack[1152921513110777120] = ???;  stack[1152921513110777128] = ???;  //  dest_result_addr=1152921513110777120 |  dest_result_addr=1152921513110777128
            // 0x00AD7BF8: ADD x29, sp, #0x40         | X29 = (1152921513110777056 + 64) = 1152921513110777120 (0x10000001FADFAD20);
            // 0x00AD7BFC: MOV x19, x0                | X19 = 1152921513110789152 (0x10000001FADFDC20);//ML01
            // 0x00AD7C00: LDR w8, [x19, #8]          |  //  find_add[1152921513110789136]
            // 0x00AD7C04: MOV x20, x1                | X20 = rangeDecoder;//m1                 
            // 0x00AD7C08: CMP w8, #1                 | STATE = COMPARE(W8, 0x1)                
            // 0x00AD7C0C: B.LT #0xad7c78             | if (W8 < 0x1) goto label_0;             
            if(W8 < 1)
            {
                goto label_0;
            }
            // 0x00AD7C10: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            // 0x00AD7C14: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x00AD7C18: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            label_3:
            // 0x00AD7C1C: LDR x24, [x19]             | X24 = typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder);
            // 0x00AD7C20: CBNZ x24, #0xad7c28        | if (typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder) != 0) goto label_1;
            if(new SevenZip.Compression.RangeCoder.BitTreeDecoder() != 0)
            {
                goto label_1;
            }
            // 0x00AD7C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110789136], ????);
            label_1:
            // 0x00AD7C28: LDR w8, [x24, #0x18]       | W8 = SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze;
            // 0x00AD7C2C: MOV w25, w23               | W25 = 1 (0x1);//ML01                    
            // 0x00AD7C30: CMP w23, w8                | STATE = COMPARE(0x1, SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze)
            // 0x00AD7C34: B.LO #0xad7c44             | if (1 < SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze) goto label_2;
            // 0x00AD7C38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110789136], ????);
            // 0x00AD7C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD7C40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (SevenZip.Compression.RangeCoder.BitTreeDecoder)[1152921513110789136], ????);
            label_2:
            // 0x00AD7C44: ADD x8, x24, x25, lsl #2   |  //  not_find_field:typeof(SevenZip.Compression.RangeCoder.BitTreeDecoder).4
            // 0x00AD7C48: ADD x0, x8, #0x20          | X0 = (SevenZip.Compression.RangeCoder.BitTreeDecoder.__il2cppRuntimeField_namespaze + 32) = 1152921507406452224 (0x10000000A6DE9600);
            // 0x00AD7C4C: MOV x1, x20                | X1 = rangeDecoder;//m1                  
            // 0x00AD7C50: BL #0xad7464               | X0 = label_SevenZip_Compression_RangeCoder_BitDecoder_Init_GL00AD7464();
            // 0x00AD7C54: LDR w9, [x19, #8]          |  //  find_add[1152921513110789136]
            // 0x00AD7C58: AND w8, w22, #0x1f         | W8 = (0 & 31);                          
            var val_1 = val_2 & 31;
            // 0x00AD7C5C: LSL w8, w0, w8             | W8 = (1152921507406452224 << (0 & 31)); 
            val_1 = 1152921507406452224 << val_1;
            // 0x00AD7C60: ADD w23, w0, w23, lsl #1   | W23 = (1152921507406452224 + 2) = 1152921507406452226 (0x10000000A6DE9602);
            // 0x00AD7C64: ORR w21, w8, w21           | W21 = ((1152921507406452224 << (0 & 31)) | 0);
            val_1 = val_1 | 0;
            // 0x00AD7C68: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x00AD7C6C: CMP w22, w9                | STATE = COMPARE((0 + 1), W9)            
            // 0x00AD7C70: B.LT #0xad7c1c             | if (0 < W9) goto label_3;               
            if(val_2 < W9)
            {
                goto label_3;
            }
            // 0x00AD7C74: B #0xad7c7c                |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x00AD7C78: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_1 = 0;
            label_4:
            // 0x00AD7C7C: MOV w0, w21                | W0 = 0 (0x0);//ML01                     
            // 0x00AD7C80: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7C84: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7C88: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7C8C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD7C90: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD7C94: RET                        |  return (System.UInt32)null;            
            return (uint)val_1;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7C98 (11369624), len: 8  VirtAddr: 0x00AD7C98 RVA: 0x00AD7C98 token: 100681685 methodIndex: 54720 delegateWrapperIndex: 0 methodInvoker: 0
        public uint ReverseDecode(SevenZip.Compression.RangeCoder.Decoder rangeDecoder)
        {
            //
            // Disasemble & Code
            // 0x00AD7C98: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513110909344 (0x10000001FAE1B1A0);
            // 0x00AD7C9C: B #0xad7be4                | goto label_SevenZip_Compression_RangeCoder_BitTreeDecoder_Decode_GL00AD7BE4;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7CA0 (11369632), len: 588  VirtAddr: 0x00AD7CA0 RVA: 0x00AD7CA0 token: 100681686 methodIndex: 54721 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint ReverseDecode(SevenZip.Compression.RangeCoder.BitDecoder[] Models, uint startIndex, SevenZip.Compression.RangeCoder.Decoder rangeDecoder, int NumBitLevels)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            // 0x00AD7CA0: STP x26, x25, [sp, #-0x50]! | stack[1152921513111054304] = ???;  stack[1152921513111054312] = ???;  //  dest_result_addr=1152921513111054304 |  dest_result_addr=1152921513111054312
            // 0x00AD7CA4: STP x24, x23, [sp, #0x10]  | stack[1152921513111054320] = ???;  stack[1152921513111054328] = ???;  //  dest_result_addr=1152921513111054320 |  dest_result_addr=1152921513111054328
            // 0x00AD7CA8: STP x22, x21, [sp, #0x20]  | stack[1152921513111054336] = ???;  stack[1152921513111054344] = ???;  //  dest_result_addr=1152921513111054336 |  dest_result_addr=1152921513111054344
            // 0x00AD7CAC: STP x20, x19, [sp, #0x30]  | stack[1152921513111054352] = ???;  stack[1152921513111054360] = ???;  //  dest_result_addr=1152921513111054352 |  dest_result_addr=1152921513111054360
            // 0x00AD7CB0: STP x29, x30, [sp, #0x40]  | stack[1152921513111054368] = ???;  stack[1152921513111054376] = ???;  //  dest_result_addr=1152921513111054368 |  dest_result_addr=1152921513111054376
            // 0x00AD7CB4: ADD x29, sp, #0x40         | X29 = (1152921513111054304 + 64) = 1152921513111054368 (0x10000001FAE3E820);
            // 0x00AD7CB8: MOV w19, w4                | W19 = W4;//m1                           
            // 0x00AD7CBC: MOV x20, x3                | X20 = NumBitLevels;//m1                 
            // 0x00AD7CC0: MOV w21, w2                | W21 = rangeDecoder;//m1                 
            // 0x00AD7CC4: MOV x22, x1                | X22 = startIndex;//m1                   
            // 0x00AD7CC8: CMP w19, #1                | STATE = COMPARE(W4, 0x1)                
            // 0x00AD7CCC: B.LT #0xad7d34             | if (W4 < 0x1) goto label_0;             
            if(W4 < 1)
            {
                goto label_0;
            }
            // 0x00AD7CD0: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x00AD7CD4: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x00AD7CD8: ORR w25, wzr, #1           | W25 = 1(0x1);                           
            label_3:
            // 0x00AD7CDC: CBNZ x22, #0xad7ce4        | if (startIndex != 0) goto label_1;      
            if(startIndex != 0)
            {
                goto label_1;
            }
            // 0x00AD7CE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Models, ????);     
            label_1:
            // 0x00AD7CE4: LDR w8, [x22, #0x18]       | W8 = startIndex + 24;                   
            // 0x00AD7CE8: ADD w9, w25, w21           | W9 = (1 + rangeDecoder);                
            SevenZip.Compression.RangeCoder.Decoder val_1 = 1 + rangeDecoder;
            // 0x00AD7CEC: SXTW x26, w9               | X26 = (long)(int)((1 + rangeDecoder));  
            // 0x00AD7CF0: CMP w9, w8                 | STATE = COMPARE((1 + rangeDecoder), startIndex + 24)
            // 0x00AD7CF4: B.LO #0xad7d04             | if (val_1 < startIndex + 24) goto label_2;
            if(val_1 < (startIndex + 24))
            {
                goto label_2;
            }
            // 0x00AD7CF8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? Models, ????);     
            // 0x00AD7CFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD7D00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? Models, ????);     
            label_2:
            // 0x00AD7D04: ADD x8, x22, x26, lsl #2   | X8 = (startIndex + ((long)(int)((1 + rangeDecoder))) << 2);
            uint val_2 = startIndex + (((long)(int)((1 + rangeDecoder))) << 2);
            // 0x00AD7D08: ADD x0, x8, #0x20          | X0 = ((startIndex + ((long)(int)((1 + rangeDecoder))) << 2) + 32);
            uint val_3 = val_2 + 32;
            // 0x00AD7D0C: MOV x1, x20                | X1 = NumBitLevels;//m1                  
            // 0x00AD7D10: BL #0xad7464               | X0 = label_SevenZip_Compression_RangeCoder_BitDecoder_Init_GL00AD7464();
            // 0x00AD7D14: AND w8, w24, #0x1f         | W8 = (0 & 31);                          
            var val_4 = val_6 & 31;
            // 0x00AD7D18: LSL w8, w0, w8             | W8 = (((startIndex + ((long)(int)((1 + rangeDecoder))) << 2) + 32) << (0 & 31));
            val_4 = val_3 << val_4;
            // 0x00AD7D1C: ADD w25, w0, w25, lsl #1   | W25 = (((startIndex + ((long)(int)((1 + rangeDecoder))) << 2) + 32) + 2);
            uint val_5 = val_3 + 2;
            // 0x00AD7D20: ADD w24, w24, #1           | W24 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x00AD7D24: ORR w23, w8, w23           | W23 = ((((startIndex + ((long)(int)((1 + rangeDecoder))) << 2) + 32) << (0 & 31)) | 0);
            val_5 = val_4 | 0;
            // 0x00AD7D28: CMP w19, w24               | STATE = COMPARE(W4, (0 + 1))            
            // 0x00AD7D2C: B.NE #0xad7cdc             | if (W4 != 0) goto label_3;              
            if(W4 != val_6)
            {
                goto label_3;
            }
            // 0x00AD7D30: B #0xad7d38                |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x00AD7D34: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_4:
            // 0x00AD7D38: MOV w0, w23                | W0 = 0 (0x0);//ML01                     
            // 0x00AD7D3C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7D40: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7D44: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7D48: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD7D4C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD7D50: RET                        |  return (System.UInt32)null;            
            return (uint)val_5;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
    
    }

}
