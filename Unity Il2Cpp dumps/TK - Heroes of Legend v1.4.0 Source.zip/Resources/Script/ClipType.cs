using UnityEngine;

namespace Pathfinding.ClipperLib
{
    public enum ClipType
    {
        // Fields
        ctIntersection = 0
        ,ctUnion = 1
        ,ctDifference = 2
        ,ctXor = 3
        
    
    }

}
