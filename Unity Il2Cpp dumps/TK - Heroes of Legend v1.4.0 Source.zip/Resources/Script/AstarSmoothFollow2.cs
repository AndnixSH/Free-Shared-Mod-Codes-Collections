using UnityEngine;
public class AstarSmoothFollow2 : MonoBehaviour
{
    // Fields
    public UnityEngine.Transform target; //  0x00000018
    public float distance; //  0x00000020
    public float height; //  0x00000024
    public float damping; //  0x00000028
    public bool smoothRotation; //  0x0000002C
    public bool followBehind; //  0x0000002D
    public float rotationDamping; //  0x00000030
    public bool staticOffset; //  0x00000034
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8C6A8 (12109480), len: 44  VirtAddr: 0x00B8C6A8 RVA: 0x00B8C6A8 token: 100682738 methodIndex: 25069 delegateWrapperIndex: 0 methodInvoker: 0
    public AstarSmoothFollow2()
    {
        //
        // Disasemble & Code
        // 0x00B8C6A8: MOVZ w8, #0x4040, lsl #16  | W8 = 1077936128 (0x40400000);//ML01     
        // 0x00B8C6AC: MOVZ w9, #0x40a0, lsl #16  | W9 = 1084227584 (0x40A00000);//ML01     
        // 0x00B8C6B0: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x00B8C6B4: MOVZ w11, #0x4120, lsl #16 | W11 = 1092616192 (0x41200000);//ML01    
        // 0x00B8C6B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C6BC: STP w8, w8, [x0, #0x20]    | this.distance = 3;  this.height = 3;     //  dest_result_addr=1152921513310919360 |  dest_result_addr=1152921513310919364
        this.distance = 3f;
        this.height = 3f;
        // 0x00B8C6C0: STR w9, [x0, #0x28]        | this.damping = 5;                        //  dest_result_addr=1152921513310919368
        this.damping = 5f;
        // 0x00B8C6C4: STRB w10, [x0, #0x2c]      | this.smoothRotation = true;              //  dest_result_addr=1152921513310919372
        this.smoothRotation = true;
        // 0x00B8C6C8: STRB w10, [x0, #0x2d]      | this.followBehind = true;                //  dest_result_addr=1152921513310919373
        this.followBehind = true;
        // 0x00B8C6CC: STR w11, [x0, #0x30]       | this.rotationDamping = 10;               //  dest_result_addr=1152921513310919376
        this.rotationDamping = 10f;
        // 0x00B8C6D0: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8C6D4 (12109524), len: 1104  VirtAddr: 0x00B8C6D4 RVA: 0x00B8C6D4 token: 100682739 methodIndex: 25070 delegateWrapperIndex: 0 methodInvoker: 0
    private void LateUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Transform val_23;
        //  | 
        float val_24;
        //  | 
        float val_25;
        //  | 
        float val_26;
        //  | 
        float val_27;
        //  | 
        var val_28;
        //  | 
        float val_29;
        //  | 
        float val_30;
        //  | 
        float val_31;
        // 0x00B8C6D4: STP d15, d14, [sp, #-0x70]! | stack[1152921513311064272] = ???;  stack[1152921513311064280] = ???;  //  dest_result_addr=1152921513311064272 |  dest_result_addr=1152921513311064280
        // 0x00B8C6D8: STP d13, d12, [sp, #0x10]  | stack[1152921513311064288] = ???;  stack[1152921513311064296] = ???;  //  dest_result_addr=1152921513311064288 |  dest_result_addr=1152921513311064296
        // 0x00B8C6DC: STP d11, d10, [sp, #0x20]  | stack[1152921513311064304] = ???;  stack[1152921513311064312] = ???;  //  dest_result_addr=1152921513311064304 |  dest_result_addr=1152921513311064312
        // 0x00B8C6E0: STP d9, d8, [sp, #0x30]    | stack[1152921513311064320] = ???;  stack[1152921513311064328] = ???;  //  dest_result_addr=1152921513311064320 |  dest_result_addr=1152921513311064328
        // 0x00B8C6E4: STP x22, x21, [sp, #0x40]  | stack[1152921513311064336] = ???;  stack[1152921513311064344] = ???;  //  dest_result_addr=1152921513311064336 |  dest_result_addr=1152921513311064344
        // 0x00B8C6E8: STP x20, x19, [sp, #0x50]  | stack[1152921513311064352] = ???;  stack[1152921513311064360] = ???;  //  dest_result_addr=1152921513311064352 |  dest_result_addr=1152921513311064360
        // 0x00B8C6EC: STP x29, x30, [sp, #0x60]  | stack[1152921513311064368] = ???;  stack[1152921513311064376] = ???;  //  dest_result_addr=1152921513311064368 |  dest_result_addr=1152921513311064376
        // 0x00B8C6F0: ADD x29, sp, #0x60         | X29 = (1152921513311064272 + 96) = 1152921513311064368 (0x1000000206CFD130);
        // 0x00B8C6F4: SUB sp, sp, #0x20          | SP = (1152921513311064272 - 32) = 1152921513311064240 (0x1000000206CFD0B0);
        // 0x00B8C6F8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8C6FC: LDRB w8, [x20, #0xa12]     | W8 = (bool)static_value_03733A12;       
        // 0x00B8C700: MOV x19, x0                | X19 = 1152921513311076384 (0x1000000206D00020);//ML01
        val_23 = this;
        // 0x00B8C704: TBNZ w8, #0, #0xb8c720     | if (static_value_03733A12 == true) goto label_0;
        // 0x00B8C708: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00B8C70C: LDR x8, [x8, #0xdb0]       | X8 = 0x2B8EE14;                         
        // 0x00B8C710: LDR w0, [x8]               | W0 = 0x1245;                            
        // 0x00B8C714: BL #0x2782188              | X0 = sub_2782188( ?? 0x1245, ????);     
        // 0x00B8C718: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8C71C: STRB w8, [x20, #0xa12]     | static_value_03733A12 = true;            //  dest_result_addr=57883154
        label_0:
        // 0x00B8C720: LDRB w8, [x19, #0x34]      | W8 = this.staticOffset; //P2            
        // 0x00B8C724: CBZ w8, #0xb8c7b0          | if (this.staticOffset == false) goto label_1;
        if(this.staticOffset == false)
        {
            goto label_1;
        }
        // 0x00B8C728: LDR x20, [x19, #0x18]      | X20 = this.target; //P2                 
        // 0x00B8C72C: CBNZ x20, #0xb8c734        | if (this.target != null) goto label_2;  
        if(this.target != null)
        {
            goto label_2;
        }
        // 0x00B8C730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1245, ????);     
        label_2:
        // 0x00B8C734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C738: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B8C73C: BL #0x2693510              | X0 = this.target.get_position();        
        UnityEngine.Vector3 val_1 = this.target.position;
        // 0x00B8C740: MOV v9.16b, v1.16b         | V9 = val_1.y;//m1                       
        // 0x00B8C744: LDP s3, s1, [x19, #0x20]   | S3 = this.distance; //P2  S1 = this.height; //P2  //  | 
        // 0x00B8C748: MOV v8.16b, v0.16b         | V8 = val_1.x;//m1                       
        // 0x00B8C74C: MOV v10.16b, v2.16b        | V10 = val_1.z;//m1                      
        // 0x00B8C750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C754: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B8C758: ADD x0, sp, #0x10          | X0 = (1152921513311064240 + 16) = 1152921513311064256 (0x1000000206CFD0C0);
        // 0x00B8C75C: MOV v2.16b, v3.16b         | V2 = this.distance;//m1                 
        // 0x00B8C760: STR wzr, [sp, #0x18]       | stack[1152921513311064264] = 0x0;        //  dest_result_addr=1152921513311064264
        // 0x00B8C764: STR xzr, [sp, #0x10]       | stack[1152921513311064256] = 0x0;        //  dest_result_addr=1152921513311064256
        // 0x00B8C768: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B8C76C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8C770: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B8C774: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8C778: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8C77C: TBZ w8, #0, #0xb8c78c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B8C780: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8C784: CBNZ w8, #0xb8c78c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B8C788: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_4:
        // 0x00B8C78C: LDP s3, s4, [sp, #0x10]    | S3 = 0; S4 = 0;                          //  | 
        // 0x00B8C790: LDR s5, [sp, #0x18]        | S5 = 0;                                 
        // 0x00B8C794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8C798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C79C: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
        val_24 = val_1.x;
        // 0x00B8C7A0: MOV v1.16b, v9.16b         | V1 = val_1.y;//m1                       
        val_25 = val_1.y;
        // 0x00B8C7A4: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        val_26 = val_1.z;
        // 0x00B8C7A8: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_24, y = val_25, z = val_26}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_24, y = val_25, z = val_26}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B8C7AC: B #0xb8c7f8                |  goto label_5;                          
        goto label_5;
        label_1:
        // 0x00B8C7B0: LDRB w21, [x19, #0x2d]     | W21 = this.followBehind; //P2           
        // 0x00B8C7B4: LDR x20, [x19, #0x18]      | X20 = this.target; //P2                 
        // 0x00B8C7B8: LDP s9, s8, [x19, #0x20]   | S9 = this.distance; //P2  S8 = this.height; //P2  //  | 
        // 0x00B8C7BC: CBNZ x20, #0xb8c7c4        | if (this.target != null) goto label_6;  
        if(this.target != null)
        {
            goto label_6;
        }
        // 0x00B8C7C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1245, ????);     
        label_6:
        // 0x00B8C7C4: CBZ w21, #0xb8c7e0         | if (this.followBehind == false) goto label_7;
        if(this.followBehind == false)
        {
            goto label_7;
        }
        // 0x00B8C7C8: FNEG s2, s9                | S2 = -(this.distance);                  
        val_26 = -this.distance;
        // 0x00B8C7CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C7D0: FMOV s0, wzr               | S0 = 0f;                                
        val_24 = 0f;
        // 0x00B8C7D4: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B8C7D8: MOV v1.16b, v8.16b         | V1 = this.height;//m1                   
        val_25 = this.height;
        // 0x00B8C7DC: B #0xb8c7f4                |  goto label_8;                          
        goto label_8;
        label_7:
        // 0x00B8C7E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C7E4: FMOV s0, wzr               | S0 = 0f;                                
        val_24 = 0f;
        // 0x00B8C7E8: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B8C7EC: MOV v1.16b, v8.16b         | V1 = this.height;//m1                   
        val_25 = this.height;
        // 0x00B8C7F0: MOV v2.16b, v9.16b         | V2 = this.distance;//m1                 
        val_26 = this.distance;
        label_8:
        // 0x00B8C7F4: BL #0x2695710              | X0 = this.target.TransformPoint(x:  val_24 = 0f, y:  val_25 = this.height, z:  val_26 = this.distance);
        UnityEngine.Vector3 val_3 = this.target.TransformPoint(x:  val_24, y:  val_25, z:  val_26);
        label_5:
        // 0x00B8C7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C7FC: MOV x0, x19                | X0 = 1152921513311076384 (0x1000000206D00020);//ML01
        // 0x00B8C800: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00B8C804: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00B8C808: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x00B8C80C: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_4 = this.transform;
        // 0x00B8C810: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B8C814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C818: MOV x0, x19                | X0 = 1152921513311076384 (0x1000000206D00020);//ML01
        // 0x00B8C81C: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_5 = this.transform;
        // 0x00B8C820: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B8C824: CBNZ x21, #0xb8c82c        | if (val_5 != null) goto label_9;        
        if(val_5 != null)
        {
            goto label_9;
        }
        // 0x00B8C828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B8C82C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C830: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B8C834: BL #0x2693510              | X0 = val_5.get_position();              
        UnityEngine.Vector3 val_6 = val_5.position;
        // 0x00B8C838: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8C83C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C840: MOV v11.16b, v0.16b        | V11 = val_6.x;//m1                      
        // 0x00B8C844: MOV v12.16b, v1.16b        | V12 = val_6.y;//m1                      
        val_27 = val_6.y;
        // 0x00B8C848: MOV v13.16b, v2.16b        | V13 = val_6.z;//m1                      
        // 0x00B8C84C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_7 = UnityEngine.Time.deltaTime;
        // 0x00B8C850: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00B8C854: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        val_28 = 1152921504695078912;
        // 0x00B8C858: LDR s15, [x19, #0x28]      | S15 = this.damping; //P2                
        // 0x00B8C85C: MOV v14.16b, v0.16b        | V14 = val_7;//m1                        
        val_29 = val_7;
        // 0x00B8C860: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8C864: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8C868: TBZ w8, #0, #0xb8c878      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B8C86C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8C870: CBNZ w8, #0xb8c878         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B8C874: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_11:
        // 0x00B8C878: FMUL s6, s14, s15          | S6 = (val_7 * this.damping);            
        float val_8 = val_29 * this.damping;
        // 0x00B8C87C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8C880: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C884: MOV v0.16b, v11.16b        | V0 = val_6.x;//m1                       
        // 0x00B8C888: MOV v1.16b, v12.16b        | V1 = val_6.y;//m1                       
        // 0x00B8C88C: MOV v2.16b, v13.16b        | V2 = val_6.z;//m1                       
        // 0x00B8C890: MOV v3.16b, v8.16b         | V3 = val_3.x;//m1                       
        // 0x00B8C894: MOV v4.16b, v9.16b         | V4 = val_3.y;//m1                       
        // 0x00B8C898: MOV v5.16b, v10.16b        | V5 = val_3.z;//m1                       
        // 0x00B8C89C: BL #0x2698e54              | X0 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_27, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, t:  float val_8 = val_29 * this.damping);
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.Lerp(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_27, z = val_6.z}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, t:  val_8);
        // 0x00B8C8A0: MOV v8.16b, v0.16b         | V8 = val_9.x;//m1                       
        // 0x00B8C8A4: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        // 0x00B8C8A8: MOV v10.16b, v2.16b        | V10 = val_9.z;//m1                      
        // 0x00B8C8AC: CBNZ x20, #0xb8c8b4        | if (val_4 != null) goto label_12;       
        if(val_4 != null)
        {
            goto label_12;
        }
        // 0x00B8C8B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_12:
        // 0x00B8C8B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C8B8: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B8C8BC: MOV v0.16b, v8.16b         | V0 = val_9.x;//m1                       
        // 0x00B8C8C0: MOV v1.16b, v9.16b         | V1 = val_9.y;//m1                       
        // 0x00B8C8C4: MOV v2.16b, v10.16b        | V2 = val_9.z;//m1                       
        // 0x00B8C8C8: BL #0x26935b8              | val_4.set_position(value:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        val_4.position = new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z};
        // 0x00B8C8CC: LDRB w8, [x19, #0x2c]      | W8 = this.smoothRotation; //P2          
        // 0x00B8C8D0: CBZ w8, #0xb8caa8          | if (this.smoothRotation == false) goto label_13;
        if(this.smoothRotation == false)
        {
            goto label_13;
        }
        // 0x00B8C8D4: LDR x20, [x19, #0x18]      | X20 = this.target; //P2                 
        // 0x00B8C8D8: CBNZ x20, #0xb8c8e0        | if (this.target != null) goto label_14; 
        if(this.target != null)
        {
            goto label_14;
        }
        // 0x00B8C8DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_14:
        // 0x00B8C8E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C8E4: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B8C8E8: BL #0x2693510              | X0 = this.target.get_position();        
        UnityEngine.Vector3 val_10 = this.target.position;
        // 0x00B8C8EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C8F0: MOV x0, x19                | X0 = 1152921513311076384 (0x1000000206D00020);//ML01
        // 0x00B8C8F4: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
        // 0x00B8C8F8: MOV v9.16b, v1.16b         | V9 = val_10.y;//m1                      
        // 0x00B8C8FC: MOV v10.16b, v2.16b        | V10 = val_10.z;//m1                     
        // 0x00B8C900: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_11 = this.transform;
        // 0x00B8C904: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00B8C908: CBNZ x20, #0xb8c910        | if (val_11 != null) goto label_15;      
        if(val_11 != null)
        {
            goto label_15;
        }
        // 0x00B8C90C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_15:
        // 0x00B8C910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C914: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x00B8C918: BL #0x2693510              | X0 = val_11.get_position();             
        UnityEngine.Vector3 val_12 = val_11.position;
        // 0x00B8C91C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8C920: MOV v11.16b, v0.16b        | V11 = val_12.x;//m1                     
        // 0x00B8C924: MOV v12.16b, v1.16b        | V12 = val_12.y;//m1                     
        // 0x00B8C928: MOV v13.16b, v2.16b        | V13 = val_12.z;//m1                     
        // 0x00B8C92C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8C930: TBZ w8, #0, #0xb8c940      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B8C934: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8C938: CBNZ w8, #0xb8c940         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B8C93C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_17:
        // 0x00B8C940: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8C944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C948: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
        // 0x00B8C94C: MOV v1.16b, v9.16b         | V1 = val_10.y;//m1                      
        // 0x00B8C950: MOV v2.16b, v10.16b        | V2 = val_10.z;//m1                      
        // 0x00B8C954: MOV v3.16b, v11.16b        | V3 = val_12.x;//m1                      
        // 0x00B8C958: MOV v4.16b, v12.16b        | V4 = val_12.y;//m1                      
        // 0x00B8C95C: MOV v5.16b, v13.16b        | V5 = val_12.z;//m1                      
        // 0x00B8C960: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z});
        UnityEngine.Vector3 val_13 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z});
        // 0x00B8C964: LDR x20, [x19, #0x18]      | X20 = this.target; //P2                 
        // 0x00B8C968: MOV v8.16b, v0.16b         | V8 = val_13.x;//m1                      
        // 0x00B8C96C: MOV v9.16b, v1.16b         | V9 = val_13.y;//m1                      
        // 0x00B8C970: MOV v10.16b, v2.16b        | V10 = val_13.z;//m1                     
        // 0x00B8C974: CBNZ x20, #0xb8c97c        | if (this.target != null) goto label_18; 
        if(this.target != null)
        {
            goto label_18;
        }
        // 0x00B8C978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_18:
        // 0x00B8C97C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C980: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B8C984: BL #0x2693c68              | X0 = this.target.get_up();              
        UnityEngine.Vector3 val_14 = this.target.up;
        // 0x00B8C988: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B8C98C: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B8C990: MOV v11.16b, v0.16b        | V11 = val_14.x;//m1                     
        // 0x00B8C994: MOV v12.16b, v1.16b        | V12 = val_14.y;//m1                     
        // 0x00B8C998: MOV v13.16b, v2.16b        | V13 = val_14.z;//m1                     
        // 0x00B8C99C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00B8C9A0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B8C9A4: TBZ w8, #0, #0xb8c9b4      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B8C9A8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B8C9AC: CBNZ w8, #0xb8c9b4         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B8C9B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_20:
        // 0x00B8C9B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8C9B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C9BC: MOV v0.16b, v8.16b         | V0 = val_13.x;//m1                      
        // 0x00B8C9C0: MOV v1.16b, v9.16b         | V1 = val_13.y;//m1                      
        // 0x00B8C9C4: MOV v2.16b, v10.16b        | V2 = val_13.z;//m1                      
        // 0x00B8C9C8: MOV v3.16b, v11.16b        | V3 = val_14.x;//m1                      
        // 0x00B8C9CC: MOV v4.16b, v12.16b        | V4 = val_14.y;//m1                      
        // 0x00B8C9D0: MOV v5.16b, v13.16b        | V5 = val_14.z;//m1                      
        // 0x00B8C9D4: BL #0x1b7e7b4              | X0 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, upwards:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        UnityEngine.Quaternion val_15 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, upwards:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        // 0x00B8C9D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C9DC: MOV x0, x19                | X0 = 1152921513311076384 (0x1000000206D00020);//ML01
        // 0x00B8C9E0: MOV v8.16b, v0.16b         | V8 = val_15.x;//m1                      
        // 0x00B8C9E4: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
        // 0x00B8C9E8: MOV v10.16b, v2.16b        | V10 = val_15.z;//m1                     
        // 0x00B8C9EC: MOV v11.16b, v3.16b        | V11 = val_15.w;//m1                     
        // 0x00B8C9F0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_16 = this.transform;
        // 0x00B8C9F4: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x00B8C9F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8C9FC: MOV x0, x19                | X0 = 1152921513311076384 (0x1000000206D00020);//ML01
        // 0x00B8CA00: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_17 = this.transform;
        // 0x00B8CA04: MOV x21, x0                | X21 = val_17;//m1                       
        val_28 = val_17;
        // 0x00B8CA08: CBNZ x21, #0xb8ca10        | if (val_17 != null) goto label_21;      
        if(val_28 != null)
        {
            goto label_21;
        }
        // 0x00B8CA0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_21:
        // 0x00B8CA10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CA14: MOV x0, x21                | X0 = val_17;//m1                        
        // 0x00B8CA18: BL #0x26937d8              | X0 = val_17.get_rotation();             
        UnityEngine.Quaternion val_18 = val_28.rotation;
        // 0x00B8CA1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CA20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CA24: MOV v12.16b, v0.16b        | V12 = val_18.x;//m1                     
        val_27 = val_18.x;
        // 0x00B8CA28: MOV v13.16b, v1.16b        | V13 = val_18.y;//m1                     
        // 0x00B8CA2C: MOV v14.16b, v2.16b        | V14 = val_18.z;//m1                     
        val_29 = val_18.z;
        // 0x00B8CA30: MOV v15.16b, v3.16b        | V15 = val_18.w;//m1                     
        // 0x00B8CA34: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_19 = UnityEngine.Time.deltaTime;
        // 0x00B8CA38: LDR s1, [x19, #0x30]       | S1 = this.rotationDamping; //P2         
        // 0x00B8CA3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CA40: MOV v2.16b, v14.16b        | V2 = val_18.z;//m1                      
        // 0x00B8CA44: MOV v3.16b, v15.16b        | V3 = val_18.w;//m1                      
        // 0x00B8CA48: FMUL s0, s0, s1            | S0 = (val_19 * this.rotationDamping);   
        val_19 = val_19 * this.rotationDamping;
        // 0x00B8CA4C: STR s0, [sp]               | stack[1152921513311064240] = (val_19 * this.rotationDamping);  //  dest_result_addr=1152921513311064240
        // 0x00B8CA50: MOV v0.16b, v12.16b        | V0 = val_18.x;//m1                      
        // 0x00B8CA54: MOV v1.16b, v13.16b        | V1 = val_18.y;//m1                      
        // 0x00B8CA58: MOV v4.16b, v8.16b         | V4 = val_15.x;//m1                      
        // 0x00B8CA5C: MOV v5.16b, v9.16b         | V5 = val_15.y;//m1                      
        // 0x00B8CA60: MOV v6.16b, v10.16b        | V6 = val_15.z;//m1                      
        // 0x00B8CA64: MOV v7.16b, v11.16b        | V7 = val_15.w;//m1                      
        // 0x00B8CA68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CA6C: BL #0x1b7e988              | X0 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_27, y = val_18.y, z = val_29, w = val_18.w}, b:  new UnityEngine.Quaternion() {x = val_15.x, y = val_15.y, z = val_15.z, w = val_15.w}, t:  val_19);
        UnityEngine.Quaternion val_20 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_27, y = val_18.y, z = val_29, w = val_18.w}, b:  new UnityEngine.Quaternion() {x = val_15.x, y = val_15.y, z = val_15.z, w = val_15.w}, t:  val_19);
        // 0x00B8CA70: MOV v8.16b, v0.16b         | V8 = val_20.x;//m1                      
        val_30 = val_20.x;
        // 0x00B8CA74: MOV v9.16b, v1.16b         | V9 = val_20.y;//m1                      
        // 0x00B8CA78: MOV v10.16b, v2.16b        | V10 = val_20.z;//m1                     
        val_31 = val_20.z;
        // 0x00B8CA7C: MOV v11.16b, v3.16b        | V11 = val_20.w;//m1                     
        // 0x00B8CA80: CBNZ x20, #0xb8ca88        | if (val_16 != null) goto label_22;      
        if(val_16 != null)
        {
            goto label_22;
        }
        // 0x00B8CA84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_22:
        // 0x00B8CA88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CA8C: MOV x0, x20                | X0 = val_16;//m1                        
        // 0x00B8CA90: MOV v0.16b, v8.16b         | V0 = val_20.x;//m1                      
        // 0x00B8CA94: MOV v1.16b, v9.16b         | V1 = val_20.y;//m1                      
        // 0x00B8CA98: MOV v2.16b, v10.16b        | V2 = val_20.z;//m1                      
        // 0x00B8CA9C: MOV v3.16b, v11.16b        | V3 = val_20.w;//m1                      
        // 0x00B8CAA0: BL #0x26938b0              | val_16.set_rotation(value:  new UnityEngine.Quaternion() {x = val_30, y = val_20.y, z = val_31, w = val_20.w});
        val_16.rotation = new UnityEngine.Quaternion() {x = val_30, y = val_20.y, z = val_31, w = val_20.w};
        // 0x00B8CAA4: B #0xb8cb00                |  goto label_23;                         
        goto label_23;
        label_13:
        // 0x00B8CAA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CAAC: MOV x0, x19                | X0 = 1152921513311076384 (0x1000000206D00020);//ML01
        // 0x00B8CAB0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_21 = this.transform;
        // 0x00B8CAB4: LDR x19, [x19, #0x18]      | X19 = this.target; //P2                 
        val_23 = this.target;
        // 0x00B8CAB8: MOV x20, x0                | X20 = val_21;//m1                       
        // 0x00B8CABC: CBNZ x19, #0xb8cac4        | if (this.target != null) goto label_24; 
        if(val_23 != null)
        {
            goto label_24;
        }
        // 0x00B8CAC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_24:
        // 0x00B8CAC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CAC8: MOV x0, x19                | X0 = this.target;//m1                   
        // 0x00B8CACC: BL #0x2693c68              | X0 = this.target.get_up();              
        UnityEngine.Vector3 val_22 = val_23.up;
        // 0x00B8CAD0: MOV v8.16b, v0.16b         | V8 = val_22.x;//m1                      
        val_30 = val_22.x;
        // 0x00B8CAD4: MOV v9.16b, v1.16b         | V9 = val_22.y;//m1                      
        // 0x00B8CAD8: MOV v10.16b, v2.16b        | V10 = val_22.z;//m1                     
        val_31 = val_22.z;
        // 0x00B8CADC: CBNZ x20, #0xb8cae4        | if (val_21 != null) goto label_25;      
        if(val_21 != null)
        {
            goto label_25;
        }
        // 0x00B8CAE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.target, ????);
        label_25:
        // 0x00B8CAE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CAE8: MOV x0, x20                | X0 = val_21;//m1                        
        // 0x00B8CAEC: MOV x1, x19                | X1 = this.target;//m1                   
        // 0x00B8CAF0: MOV v0.16b, v8.16b         | V0 = val_22.x;//m1                      
        // 0x00B8CAF4: MOV v1.16b, v9.16b         | V1 = val_22.y;//m1                      
        // 0x00B8CAF8: MOV v2.16b, v10.16b        | V2 = val_22.z;//m1                      
        // 0x00B8CAFC: BL #0x269514c              | val_21.LookAt(target:  val_23, worldUp:  new UnityEngine.Vector3() {x = val_30, y = val_22.y, z = val_31});
        val_21.LookAt(target:  val_23, worldUp:  new UnityEngine.Vector3() {x = val_30, y = val_22.y, z = val_31});
        label_23:
        // 0x00B8CB00: SUB sp, x29, #0x60         | SP = (1152921513311064368 - 96) = 1152921513311064272 (0x1000000206CFD0D0);
        // 0x00B8CB04: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8CB08: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8CB0C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8CB10: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B8CB14: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B8CB18: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B8CB1C: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00B8CB20: RET                        |  return;                                
        return;
    
    }

}
