using UnityEngine;

namespace ILRuntime.Mono.Cecil.Cil
{
    public sealed class AsyncMethodBodyDebugInformation : CustomDebugInformation
    {
        // Fields
        internal ILRuntime.Mono.Cecil.Cil.InstructionOffset catch_handler; //  0x00000030
        internal ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> yields; //  0x00000040
        internal ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> resumes; //  0x00000048
        internal ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.MethodDefinition> resume_methods; //  0x00000050
        public static System.Guid KindIdentifier; // static_offset: 0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E58E60 (15044192), len: 196  VirtAddr: 0x00E58E60 RVA: 0x00E58E60 token: 100664768 methodIndex: 19359 delegateWrapperIndex: 0 methodInvoker: 0
        internal AsyncMethodBodyDebugInformation(int catchHandler)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00E58E60: STP x22, x21, [sp, #-0x30]! | stack[1152921509594983968] = ???;  stack[1152921509594983976] = ???;  //  dest_result_addr=1152921509594983968 |  dest_result_addr=1152921509594983976
            // 0x00E58E64: STP x20, x19, [sp, #0x10]  | stack[1152921509594983984] = ???;  stack[1152921509594983992] = ???;  //  dest_result_addr=1152921509594983984 |  dest_result_addr=1152921509594983992
            // 0x00E58E68: STP x29, x30, [sp, #0x20]  | stack[1152921509594984000] = ???;  stack[1152921509594984008] = ???;  //  dest_result_addr=1152921509594984000 |  dest_result_addr=1152921509594984008
            // 0x00E58E6C: ADD x29, sp, #0x20         | X29 = (1152921509594983968 + 32) = 1152921509594984000 (0x100000012950EE40);
            // 0x00E58E70: SUB sp, sp, #0x10          | SP = (1152921509594983968 - 16) = 1152921509594983952 (0x100000012950EE10);
            // 0x00E58E74: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E58E78: LDRB w8, [x21, #0xad9]     | W8 = (bool)static_value_03734AD9;       
            // 0x00E58E7C: MOV w20, w1                | W20 = catchHandler;//m1                 
            // 0x00E58E80: MOV x19, x0                | X19 = 1152921509594996016 (0x1000000129511D30);//ML01
            // 0x00E58E84: TBNZ w8, #0, #0xe58ea0     | if (static_value_03734AD9 == true) goto label_0;
            // 0x00E58E88: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00E58E8C: LDR x8, [x8, #0xff8]       | X8 = 0x2B8EE30;                         
            // 0x00E58E90: LDR w0, [x8]               | W0 = 0x124D;                            
            // 0x00E58E94: BL #0x2782188              | X0 = sub_2782188( ?? 0x124D, ????);     
            // 0x00E58E98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58E9C: STRB w8, [x21, #0xad9]     | static_value_03734AD9 = true;            //  dest_result_addr=57887449
            label_0:
            // 0x00E58EA0: ADRP x21, #0x366b000       | X21 = 57061376 (0x366B000);             
            // 0x00E58EA4: LDR x21, [x21, #0x290]     | X21 = 1152921504748060672;              
            // 0x00E58EA8: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation);
            val_3 = null;
            // 0x00E58EAC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.__il2cppRuntimeField_10A;
            // 0x00E58EB0: TBZ w8, #0, #0xe58ec4      | if (ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E58EB4: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.__il2cppRuntimeField_cctor_finished;
            // 0x00E58EB8: CBNZ w8, #0xe58ec4         | if (ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E58EBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation), ????);
            // 0x00E58EC0: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation);
            val_3 = null;
            label_2:
            // 0x00E58EC4: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.__il2cppRuntimeField_static_fields;
            // 0x00E58EC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58ECC: MOV x0, x19                | X0 = 1152921509594996016 (0x1000000129511D30);//ML01
            object val_1 = this;
            // 0x00E58ED0: LDP x21, x22, [x8]         | X21 = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier; X22 = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier.__il2cppRuntimeField_8; //  | 
            // 0x00E58ED4: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00E58ED8: MOV x0, sp                 | X0 = 1152921509594983952 (0x100000012950EE10);//ML01
            ProtoBuf.SubItemToken val_2;
            // 0x00E58EDC: MOVZ w1, #0x3700, lsl #16  | W1 = 922746880 (0x37000000);//ML01      
            // 0x00E58EE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58EE4: STP x21, x22, [x19, #0x20] | mem[1152921509594996048] = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier;  mem[1152921509594996056] = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier.__il2cppRuntimeField_8;  //  dest_result_addr=1152921509594996048 |  dest_result_addr=1152921509594996056
            mem[1152921509594996048] = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier;
            mem[1152921509594996056] = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier.__il2cppRuntimeField_8;
            // 0x00E58EE8: STR wzr, [sp]              | stack[1152921509594983952] = 0x0;        //  dest_result_addr=1152921509594983952
            // 0x00E58EEC: BL #0x11d58e4              | null..ctor(value:  0);                  
            val_2 = new ProtoBuf.SubItemToken(value:  0);
            // 0x00E58EF0: LDR w8, [sp]               | W8 = val_2.value;                       
            // 0x00E58EF4: MOV x0, sp                 | X0 = 1152921509594983952 (0x100000012950EE10);//ML01
            // 0x00E58EF8: MOV w1, w20                | W1 = catchHandler;//m1                  
            // 0x00E58EFC: STR w8, [x19, #0x10]       | mem[1152921509594996032] = val_2.value;  //  dest_result_addr=1152921509594996032
            mem[1152921509594996032] = val_2.value;
            // 0x00E58F00: STP xzr, xzr, [sp]         | stack[1152921509594983952] = 0x0;  stack[1152921509594983960] = 0x0;  //  dest_result_addr=1152921509594983952 |  dest_result_addr=1152921509594983960
            // 0x00E58F04: BL #0xe58f80               | X0 = label_ILRuntime_Mono_Cecil_Cil_CustomDebugInformation__ctor_GL00E58F80();
            // 0x00E58F08: LDP x8, x9, [sp]           | X8 = 0x0; X9 = 0x0;                      //  | 
            // 0x00E58F0C: STP x8, x9, [x19, #0x30]   | this.catch_handler = new ILRuntime.Mono.Cecil.Cil.InstructionOffset();  mem[1152921509594996072] = 0x0;  //  dest_result_addr=1152921509594996064 |  dest_result_addr=1152921509594996072
            this.catch_handler = 0;
            mem[1152921509594996072] = 0;
            // 0x00E58F10: SUB sp, x29, #0x20         | SP = (1152921509594984000 - 32) = 1152921509594983968 (0x100000012950EE20);
            // 0x00E58F14: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58F18: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E58F1C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E58F20: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58FFC (15044604), len: 120  VirtAddr: 0x00E58FFC RVA: 0x00E58FFC token: 100664769 methodIndex: 19360 delegateWrapperIndex: 0 methodInvoker: 0
        private static AsyncMethodBodyDebugInformation()
        {
            //
            // Disasemble & Code
            // 0x00E58FFC: STP x20, x19, [sp, #-0x20]! | stack[1152921509595096128] = ???;  stack[1152921509595096136] = ???;  //  dest_result_addr=1152921509595096128 |  dest_result_addr=1152921509595096136
            // 0x00E59000: STP x29, x30, [sp, #0x10]  | stack[1152921509595096144] = ???;  stack[1152921509595096152] = ???;  //  dest_result_addr=1152921509595096144 |  dest_result_addr=1152921509595096152
            // 0x00E59004: ADD x29, sp, #0x10         | X29 = (1152921509595096128 + 16) = 1152921509595096144 (0x100000012952A450);
            // 0x00E59008: SUB sp, sp, #0x10          | SP = (1152921509595096128 - 16) = 1152921509595096112 (0x100000012952A430);
            // 0x00E5900C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E59010: LDRB w8, [x19, #0xada]     | W8 = (bool)static_value_03734ADA;       
            // 0x00E59014: TBNZ w8, #0, #0xe59030     | if (static_value_03734ADA == true) goto label_0;
            // 0x00E59018: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00E5901C: LDR x8, [x8, #0x4f0]       | X8 = 0x2B8EE2C;                         
            // 0x00E59020: LDR w0, [x8]               | W0 = 0x124C;                            
            // 0x00E59024: BL #0x2782188              | X0 = sub_2782188( ?? 0x124C, ????);     
            // 0x00E59028: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5902C: STRB w8, [x19, #0xada]     | static_value_03734ADA = true;            //  dest_result_addr=57887450
            label_0:
            // 0x00E59030: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00E59034: LDR x8, [x8, #0x690]       | X8 = (string**)(1152921509595084016)("{54FD2AC5-E925-401A-9C2A-F94F171072F8}");
            // 0x00E59038: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5903C: MOV x0, sp                 | X0 = 1152921509595096112 (0x100000012952A430);//ML01
            // 0x00E59040: LDR x1, [x8]               | X1 = "{54FD2AC5-E925-401A-9C2A-F94F171072F8}";
            // 0x00E59044: STP xzr, xzr, [sp]         | stack[1152921509595096112] = 0x0;  stack[1152921509595096120] = 0x0;  //  dest_result_addr=1152921509595096112 |  dest_result_addr=1152921509595096120
            // 0x00E59048: BL #0x1c488c0              | X0 = label_System_Guid__ctor_GL01C488C0();
            // 0x00E5904C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00E59050: LDR x8, [x8, #0x290]       | X8 = 1152921504748060672;               
            // 0x00E59054: LDR x8, [x8]               | X8 = typeof(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation);
            // 0x00E59058: LDP x9, x10, [sp]          | X9 = 0x0; X10 = 0x0;                     //  | 
            // 0x00E5905C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.__il2cppRuntimeField_static_fields;
            // 0x00E59060: STP x9, x10, [x8]          | ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier = new System.Guid();  ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier.__il2cppRuntimeField_8 = 0x0;  //  dest_result_addr=1152921504748064768 |  dest_result_addr=1152921504748064776
            ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier = 0;
            ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation.KindIdentifier.__il2cppRuntimeField_8 = 0;
            // 0x00E59064: SUB sp, x29, #0x10         | SP = (1152921509595096144 - 16) = 1152921509595096128 (0x100000012952A440);
            // 0x00E59068: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5906C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E59070: RET                        |  return;                                
            return;
        
        }
    
    }

}
