using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class BMSymbol_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000078
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BD2E14 (12398100), len: 8  VirtAddr: 0x00BD2E14 RVA: 0x00BD2E14 token: 100663909 methodIndex: 29954 delegateWrapperIndex: 0 methodInvoker: 0
        public BMSymbol_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BD2E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2E18: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD2E1C (12398108), len: 3032  VirtAddr: 0x00BD2E1C RVA: 0x00BD2E1C token: 100663910 methodIndex: 29955 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45;
            // 0x00BD2E1C: STP x26, x25, [sp, #-0x50]! | stack[1152921510068186736] = ???;  stack[1152921510068186744] = ???;  //  dest_result_addr=1152921510068186736 |  dest_result_addr=1152921510068186744
            // 0x00BD2E20: STP x24, x23, [sp, #0x10]  | stack[1152921510068186752] = ???;  stack[1152921510068186760] = ???;  //  dest_result_addr=1152921510068186752 |  dest_result_addr=1152921510068186760
            // 0x00BD2E24: STP x22, x21, [sp, #0x20]  | stack[1152921510068186768] = ???;  stack[1152921510068186776] = ???;  //  dest_result_addr=1152921510068186768 |  dest_result_addr=1152921510068186776
            // 0x00BD2E28: STP x20, x19, [sp, #0x30]  | stack[1152921510068186784] = ???;  stack[1152921510068186792] = ???;  //  dest_result_addr=1152921510068186784 |  dest_result_addr=1152921510068186792
            // 0x00BD2E2C: STP x29, x30, [sp, #0x40]  | stack[1152921510068186800] = ???;  stack[1152921510068186808] = ???;  //  dest_result_addr=1152921510068186800 |  dest_result_addr=1152921510068186808
            // 0x00BD2E30: ADD x29, sp, #0x40         | X29 = (1152921510068186736 + 64) = 1152921510068186800 (0x1000000145856EB0);
            // 0x00BD2E34: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD2E38: LDRB w8, [x20, #0xbea]     | W8 = (bool)static_value_03733BEA;       
            // 0x00BD2E3C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD2E40: TBNZ w8, #0, #0xbd2e5c     | if (static_value_03733BEA == true) goto label_0;
            // 0x00BD2E44: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00BD2E48: LDR x8, [x8, #0xd18]       | X8 = 0x2B8F7FC;                         
            // 0x00BD2E4C: LDR w0, [x8]               | W0 = 0x14C3;                            
            // 0x00BD2E50: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C3, ????);     
            // 0x00BD2E54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD2E58: STRB w8, [x20, #0xbea]     | static_value_03733BEA = true;            //  dest_result_addr=57883626
            label_0:
            // 0x00BD2E5C: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00BD2E60: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x00BD2E64: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BD2E68: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00BD2E6C: LDR x8, [x8, #0x648]       | X8 = 1152921504876015616;               
            // 0x00BD2E70: LDR x20, [x8]              | X20 = typeof(BMSymbol);                 
            // 0x00BD2E74: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD2E78: TBZ w8, #0, #0xbd2e88      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BD2E7C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD2E80: CBNZ w8, #0xbd2e88         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BD2E84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BD2E88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD2E8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD2E90: MOV x1, x20                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD2E94: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD2E98: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x00BD2E9C: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x00BD2EA0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BD2EA4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD2EA8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2EAC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD2EB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2EB4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2EB8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD2EBC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2EC0: CBNZ x20, #0xbd2ec8        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BD2EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x00BD2EC8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00BD2ECC: LDR x8, [x8, #0x6f0]       | X8 = (string**)(1152921510068112320)("get_length");
            // 0x00BD2ED0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD2ED4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD2ED8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD2EDC: LDR x1, [x8]               | X1 = "get_length";                      
            // 0x00BD2EE0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD2EE4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2EE8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD2EEC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_length", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_length", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD2EF0: ADRP x24, #0x364f000       | X24 = 56946688 (0x364F000);             
            // 0x00BD2EF4: LDR x24, [x24, #0xfd0]     | X24 = 1152921504783257600;              
            // 0x00BD2EF8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BD2EFC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD2F00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD2F04: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache0;
            val_29 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache0;
            // 0x00BD2F08: CBNZ x22, #0xbd2f54        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_29 != null)
            {
                goto label_4;
            }
            // 0x00BD2F0C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00BD2F10: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD2F14: LDR x8, [x8, #0xa10]       | X8 = 1152921510068116512;               
            // 0x00BD2F18: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD2F1C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_length_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD2F20: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x00BD2F24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD2F28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2F2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD2F30: MOV x2, x22                | X2 = 1152921510068116512 (0x1000000145845C20);//ML01
            // 0x00BD2F34: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_3;
            // 0x00BD2F38: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_length_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_length_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD2F3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD2F40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD2F44: STR x23, [x8]              | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261696
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache0 = val_30;
            // 0x00BD2F48: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD2F4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD2F50: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_29 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BD2F54: CBNZ x19, #0xbd2f5c        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BD2F58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_length_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x00BD2F5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD2F60: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD2F64: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BD2F68: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD2F6C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_29);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_29);
            // 0x00BD2F70: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD2F74: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2F78: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD2F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2F80: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2F84: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD2F88: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2F8C: CBNZ x20, #0xbd2f94        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00BD2F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x00BD2F94: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BD2F98: LDR x8, [x8, #0x368]       | X8 = (string**)(1152921510068117536)("get_offsetX");
            // 0x00BD2F9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD2FA0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD2FA4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD2FA8: LDR x1, [x8]               | X1 = "get_offsetX";                     
            // 0x00BD2FAC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD2FB0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD2FB4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD2FB8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_offsetX", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "get_offsetX", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD2FBC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD2FC0: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00BD2FC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD2FC8: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache1;
            val_31 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache1;
            // 0x00BD2FCC: CBNZ x22, #0xbd3018        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache1 != null) goto label_7;
            if(val_31 != null)
            {
                goto label_7;
            }
            // 0x00BD2FD0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00BD2FD4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD2FD8: LDR x8, [x8, #0x7f0]       | X8 = 1152921510068121728;               
            // 0x00BD2FDC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD2FE0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetX_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD2FE4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x00BD2FE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD2FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD2FF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD2FF4: MOV x2, x22                | X2 = 1152921510068121728 (0x1000000145847080);//ML01
            // 0x00BD2FF8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_5;
            // 0x00BD2FFC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetX_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetX_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD3000: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3004: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3008: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261704
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache1 = val_30;
            // 0x00BD300C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3010: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3014: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_31 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache1;
            label_7:
            // 0x00BD3018: CBNZ x19, #0xbd3020        | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x00BD301C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetX_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_8:
            // 0x00BD3020: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3024: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD3028: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00BD302C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD3030: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_31);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_31);
            // 0x00BD3034: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD3038: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD303C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD3040: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3044: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3048: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD304C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3050: CBNZ x20, #0xbd3058        | if (val_1 != null) goto label_9;        
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x00BD3054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_9:
            // 0x00BD3058: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00BD305C: LDR x8, [x8, #0x858]       | X8 = (string**)(1152921510068122752)("get_offsetY");
            // 0x00BD3060: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3064: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD3068: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD306C: LDR x1, [x8]               | X1 = "get_offsetY";                     
            // 0x00BD3070: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD3074: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3078: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD307C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_offsetY", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_1.GetMethod(name:  "get_offsetY", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3080: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3084: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00BD3088: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD308C: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache2;
            val_32 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache2;
            // 0x00BD3090: CBNZ x22, #0xbd30dc        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache2 != null) goto label_10;
            if(val_32 != null)
            {
                goto label_10;
            }
            // 0x00BD3094: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00BD3098: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD309C: LDR x8, [x8, #0xa18]       | X8 = 1152921510068126944;               
            // 0x00BD30A0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD30A4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetY_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD30A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BD30AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD30B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD30B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD30B8: MOV x2, x22                | X2 = 1152921510068126944 (0x10000001458484E0);//ML01
            // 0x00BD30BC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_7;
            // 0x00BD30C0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetY_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetY_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD30C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD30C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD30CC: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261712
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache2 = val_30;
            // 0x00BD30D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD30D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD30D8: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_32 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache2;
            label_10:
            // 0x00BD30DC: CBNZ x19, #0xbd30e4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD30E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_offsetY_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_11:
            // 0x00BD30E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD30E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD30EC: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x00BD30F0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD30F4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_32);
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_32);
            // 0x00BD30F8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD30FC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3100: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD3104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3108: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD310C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD3110: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3114: CBNZ x20, #0xbd311c        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BD3118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x00BD311C: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00BD3120: LDR x8, [x8, #0xae0]       | X8 = (string**)(1152921510068127968)("get_width");
            // 0x00BD3124: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3128: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD312C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD3130: LDR x1, [x8]               | X1 = "get_width";                       
            // 0x00BD3134: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD3138: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD313C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD3140: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_width", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_8 = val_1.GetMethod(name:  "get_width", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3144: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3148: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x00BD314C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3150: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache3;
            val_33 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache3;
            // 0x00BD3154: CBNZ x22, #0xbd31a0        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache3 != null) goto label_13;
            if(val_33 != null)
            {
                goto label_13;
            }
            // 0x00BD3158: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x00BD315C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD3160: LDR x8, [x8, #0x8b8]       | X8 = 1152921510068132160;               
            // 0x00BD3164: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD3168: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_width_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD316C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_9 = null;
            // 0x00BD3170: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD3174: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3178: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD317C: MOV x2, x22                | X2 = 1152921510068132160 (0x1000000145849940);//ML01
            // 0x00BD3180: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_9;
            // 0x00BD3184: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_width_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_width_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD3188: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD318C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3190: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261720
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache3 = val_30;
            // 0x00BD3194: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3198: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD319C: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_33 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache3;
            label_13:
            // 0x00BD31A0: CBNZ x19, #0xbd31a8        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BD31A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_width_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x00BD31A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD31AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD31B0: MOV x1, x21                | X1 = val_8;//m1                         
            // 0x00BD31B4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD31B8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_8, func:  val_33);
            X1.RegisterCLRMethodRedirection(mi:  val_8, func:  val_33);
            // 0x00BD31BC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD31C0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD31C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD31C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD31CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD31D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD31D4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD31D8: CBNZ x20, #0xbd31e0        | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x00BD31DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_15:
            // 0x00BD31E0: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00BD31E4: LDR x8, [x8, #0x50]        | X8 = (string**)(1152921510068133184)("get_height");
            // 0x00BD31E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD31EC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD31F0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD31F4: LDR x1, [x8]               | X1 = "get_height";                      
            // 0x00BD31F8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD31FC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3200: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD3204: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_height", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "get_height", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3208: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD320C: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x00BD3210: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3214: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache4;
            val_34 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache4;
            // 0x00BD3218: CBNZ x22, #0xbd3264        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache4 != null) goto label_16;
            if(val_34 != null)
            {
                goto label_16;
            }
            // 0x00BD321C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00BD3220: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD3224: LDR x8, [x8, #0x658]       | X8 = 1152921510068137376;               
            // 0x00BD3228: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD322C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_height_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD3230: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x00BD3234: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD3238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD323C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3240: MOV x2, x22                | X2 = 1152921510068137376 (0x100000014584ADA0);//ML01
            // 0x00BD3244: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_11;
            // 0x00BD3248: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_height_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_height_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD324C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3250: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3254: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261728
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache4 = val_30;
            // 0x00BD3258: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD325C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3260: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_34 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache4;
            label_16:
            // 0x00BD3264: CBNZ x19, #0xbd326c        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BD3268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_height_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_17:
            // 0x00BD326C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3270: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD3274: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x00BD3278: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD327C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_34);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_34);
            // 0x00BD3280: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD3284: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3288: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD328C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3290: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3294: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD3298: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD329C: CBNZ x20, #0xbd32a4        | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x00BD32A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_18:
            // 0x00BD32A4: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00BD32A8: LDR x8, [x8, #0x838]       | X8 = (string**)(1152921510068138400)("get_advance");
            // 0x00BD32AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD32B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD32B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD32B8: LDR x1, [x8]               | X1 = "get_advance";                     
            // 0x00BD32BC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD32C0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD32C4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD32C8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_advance", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_12 = val_1.GetMethod(name:  "get_advance", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD32CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD32D0: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x00BD32D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD32D8: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache5;
            val_35 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache5;
            // 0x00BD32DC: CBNZ x22, #0xbd3328        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache5 != null) goto label_19;
            if(val_35 != null)
            {
                goto label_19;
            }
            // 0x00BD32E0: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00BD32E4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD32E8: LDR x8, [x8, #0x6b8]       | X8 = 1152921510068142592;               
            // 0x00BD32EC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD32F0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_advance_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD32F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13 = null;
            // 0x00BD32F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD32FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3300: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3304: MOV x2, x22                | X2 = 1152921510068142592 (0x100000014584C200);//ML01
            // 0x00BD3308: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_13;
            // 0x00BD330C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_advance_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_advance_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD3310: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3314: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3318: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261736
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache5 = val_30;
            // 0x00BD331C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3320: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3324: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_35 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache5;
            label_19:
            // 0x00BD3328: CBNZ x19, #0xbd3330        | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x00BD332C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_advance_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_20:
            // 0x00BD3330: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3334: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD3338: MOV x1, x21                | X1 = val_12;//m1                        
            // 0x00BD333C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD3340: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_35);
            X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_35);
            // 0x00BD3344: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD3348: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD334C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD3350: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3354: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3358: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD335C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3360: CBNZ x20, #0xbd3368        | if (val_1 != null) goto label_21;       
            if(val_1 != null)
            {
                goto label_21;
            }
            // 0x00BD3364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_21:
            // 0x00BD3368: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x00BD336C: LDR x8, [x8, #0xf00]       | X8 = (string**)(1152921510068143616)("get_uvRect");
            // 0x00BD3370: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3374: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD3378: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD337C: LDR x1, [x8]               | X1 = "get_uvRect";                      
            // 0x00BD3380: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD3384: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3388: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD338C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_uvRect", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "get_uvRect", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3390: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3394: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00BD3398: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD339C: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache6;
            val_36 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache6;
            // 0x00BD33A0: CBNZ x22, #0xbd33ec        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache6 != null) goto label_22;
            if(val_36 != null)
            {
                goto label_22;
            }
            // 0x00BD33A4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00BD33A8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD33AC: LDR x8, [x8, #0xda8]       | X8 = 1152921510068147808;               
            // 0x00BD33B0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD33B4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_uvRect_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD33B8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x00BD33BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD33C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD33C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD33C8: MOV x2, x22                | X2 = 1152921510068147808 (0x100000014584D660);//ML01
            // 0x00BD33CC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_15;
            // 0x00BD33D0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_uvRect_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_uvRect_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD33D4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD33D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD33DC: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261744
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache6 = val_30;
            // 0x00BD33E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD33E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD33E8: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_36 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache6;
            label_22:
            // 0x00BD33EC: CBNZ x19, #0xbd33f4        | if (X1 != 0) goto label_23;             
            if(X1 != 0)
            {
                goto label_23;
            }
            // 0x00BD33F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::get_uvRect_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_23:
            // 0x00BD33F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD33F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD33FC: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x00BD3400: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD3404: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_36);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_36);
            // 0x00BD3408: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD340C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3410: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD3414: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3418: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD341C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD3420: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3424: CBNZ x20, #0xbd342c        | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x00BD3428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_24:
            // 0x00BD342C: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00BD3430: LDR x8, [x8, #0x6d8]       | X8 = (string**)(1152921510068148832)("MarkAsChanged");
            // 0x00BD3434: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3438: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD343C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD3440: LDR x1, [x8]               | X1 = "MarkAsChanged";                   
            // 0x00BD3444: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD3448: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD344C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD3450: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "MarkAsChanged", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_16 = val_1.GetMethod(name:  "MarkAsChanged", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3454: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3458: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x00BD345C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3460: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache7;
            val_37 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache7;
            // 0x00BD3464: CBNZ x22, #0xbd34b0        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache7 != null) goto label_25;
            if(val_37 != null)
            {
                goto label_25;
            }
            // 0x00BD3468: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00BD346C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD3470: LDR x8, [x8, #0x4a8]       | X8 = 1152921510068153024;               
            // 0x00BD3474: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD3478: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::MarkAsChanged_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD347C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_17 = null;
            // 0x00BD3480: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD3484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3488: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD348C: MOV x2, x22                | X2 = 1152921510068153024 (0x100000014584EAC0);//ML01
            // 0x00BD3490: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_17;
            // 0x00BD3494: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::MarkAsChanged_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::MarkAsChanged_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD3498: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD349C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD34A0: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261752
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache7 = val_30;
            // 0x00BD34A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD34A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD34AC: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_37 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache7;
            label_25:
            // 0x00BD34B0: CBNZ x19, #0xbd34b8        | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x00BD34B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::MarkAsChanged_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_26:
            // 0x00BD34B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD34BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD34C0: MOV x1, x21                | X1 = val_16;//m1                        
            // 0x00BD34C4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD34C8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_16, func:  val_37);
            X1.RegisterCLRMethodRedirection(mi:  val_16, func:  val_37);
            // 0x00BD34CC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD34D0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD34D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD34D8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BD34DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD34E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD34E4: ADRP x9, #0x363d000        | X9 = 56872960 (0x363D000);              
            // 0x00BD34E8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BD34EC: LDR x9, [x9, #0x2e8]       | X9 = 1152921504879104000;               
            // 0x00BD34F0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD34F4: LDR x22, [x9]              | X22 = typeof(UIAtlas);                  
            // 0x00BD34F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD34FC: TBZ w9, #0, #0xbd3510      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x00BD3500: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3504: CBNZ w9, #0xbd3510         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x00BD3508: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD350C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x00BD3510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3518: MOV x1, x22                | X1 = 1152921504879104000 (0x10000000103A5000);//ML01
            // 0x00BD351C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_18 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD3520: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x00BD3524: CBNZ x21, #0xbd352c        | if ( != null) goto label_29;            
            if(null != null)
            {
                goto label_29;
            }
            // 0x00BD3528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_29:
            // 0x00BD352C: CBZ x22, #0xbd3550         | if (val_18 == null) goto label_31;      
            if(val_18 == null)
            {
                goto label_31;
            }
            // 0x00BD3530: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BD3534: MOV x0, x22                | X0 = val_18;//m1                        
            // 0x00BD3538: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD353C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_18, ????);     
            // 0x00BD3540: CBNZ x0, #0xbd3550         | if (val_18 != null) goto label_31;      
            if(val_18 != null)
            {
                goto label_31;
            }
            // 0x00BD3544: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_18, ????);     
            // 0x00BD3548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD354C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_31:
            // 0x00BD3550: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BD3554: CBNZ w8, #0xbd3564         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_32;
            // 0x00BD3558: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x00BD355C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3560: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_32:
            // 0x00BD3564: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;
            // 0x00BD3568: CBNZ x20, #0xbd3570        | if (val_1 != null) goto label_33;       
            if(val_1 != null)
            {
                goto label_33;
            }
            // 0x00BD356C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_33:
            // 0x00BD3570: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x00BD3574: LDR x8, [x8, #0xf38]       | X8 = (string**)(1152921510068158144)("Validate");
            // 0x00BD3578: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD357C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD3580: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD3584: LDR x1, [x8]               | X1 = "Validate";                        
            // 0x00BD3588: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD358C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3590: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BD3594: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Validate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_1.GetMethod(name:  "Validate", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3598: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD359C: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x00BD35A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD35A4: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache8;
            val_38 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache8;
            // 0x00BD35A8: CBNZ x22, #0xbd35f4        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache8 != null) goto label_34;
            if(val_38 != null)
            {
                goto label_34;
            }
            // 0x00BD35AC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00BD35B0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD35B4: LDR x8, [x8, #0xe00]       | X8 = 1152921510068162336;               
            // 0x00BD35B8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD35BC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Validate_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD35C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_20 = null;
            // 0x00BD35C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD35C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD35CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD35D0: MOV x2, x22                | X2 = 1152921510068162336 (0x1000000145850F20);//ML01
            // 0x00BD35D4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_30 = val_20;
            // 0x00BD35D8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Validate_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Validate_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD35DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD35E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD35E4: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261760
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache8 = val_30;
            // 0x00BD35E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD35EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD35F0: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_38 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache8;
            label_34:
            // 0x00BD35F4: CBNZ x19, #0xbd35fc        | if (X1 != 0) goto label_35;             
            if(X1 != 0)
            {
                goto label_35;
            }
            // 0x00BD35F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Validate_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_35:
            // 0x00BD35FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3600: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD3604: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x00BD3608: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD360C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_38);
            X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_38);
            // 0x00BD3610: CBNZ x20, #0xbd3618        | if (val_1 != null) goto label_36;       
            if(val_1 != null)
            {
                goto label_36;
            }
            // 0x00BD3614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_36:
            // 0x00BD3618: ADRP x9, #0x3647000        | X9 = 56913920 (0x3647000);              
            // 0x00BD361C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD3620: LDR x9, [x9, #0xdd8]       | X9 = (string**)(1152921510068163360)("sequence");
            // 0x00BD3624: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD3628: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD362C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD3630: LDR x1, [x9]               | X1 = "sequence";                        
            // 0x00BD3634: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD3638: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD363C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3640: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD3644: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3648: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache9;
            val_39 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache9;
            // 0x00BD364C: CBNZ x22, #0xbd3698        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache9 != null) goto label_37;
            if(val_39 != null)
            {
                goto label_37;
            }
            // 0x00BD3650: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00BD3654: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD3658: LDR x8, [x8, #0x810]       | X8 = 1152921510068163456;               
            // 0x00BD365C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD3660: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_sequence_0(ref object o);
            // 0x00BD3664: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_21 = null;
            // 0x00BD3668: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD366C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3670: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3674: MOV x2, x22                | X2 = 1152921510068163456 (0x1000000145851380);//ML01
            // 0x00BD3678: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_30 = val_21;
            // 0x00BD367C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_sequence_0(ref object o));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_sequence_0(ref object o));
            // 0x00BD3680: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3684: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3688: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783261768
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache9 = val_30;
            // 0x00BD368C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3690: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3694: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_39 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cache9;
            label_37:
            // 0x00BD3698: CBNZ x19, #0xbd36a0        | if (X1 != 0) goto label_38;             
            if(X1 != 0)
            {
                goto label_38;
            }
            // 0x00BD369C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_sequence_0(ref object o)), ????);
            label_38:
            // 0x00BD36A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD36A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD36A8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD36AC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD36B0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            // 0x00BD36B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD36B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD36BC: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheA;
            val_40 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheA;
            // 0x00BD36C0: CBNZ x22, #0xbd370c        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheA != null) goto label_39;
            if(val_40 != null)
            {
                goto label_39;
            }
            // 0x00BD36C4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00BD36C8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD36CC: LDR x8, [x8, #0xd10]       | X8 = 1152921510068164480;               
            // 0x00BD36D0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD36D4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_sequence_0(ref object o, object v);
            // 0x00BD36D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_22 = null;
            // 0x00BD36DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD36E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD36E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD36E8: MOV x2, x22                | X2 = 1152921510068164480 (0x1000000145851780);//ML01
            // 0x00BD36EC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_30 = val_22;
            // 0x00BD36F0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_sequence_0(ref object o, object v));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_sequence_0(ref object o, object v));
            // 0x00BD36F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD36F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD36FC: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783261776
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheA = val_30;
            // 0x00BD3700: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3704: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3708: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_40 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheA;
            label_39:
            // 0x00BD370C: CBNZ x19, #0xbd3714        | if (X1 != 0) goto label_40;             
            if(X1 != 0)
            {
                goto label_40;
            }
            // 0x00BD3710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_sequence_0(ref object o, object v)), ????);
            label_40:
            // 0x00BD3714: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3718: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD371C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD3720: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD3724: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_40);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_40);
            // 0x00BD3728: CBNZ x20, #0xbd3730        | if (val_1 != null) goto label_41;       
            if(val_1 != null)
            {
                goto label_41;
            }
            // 0x00BD372C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_41:
            // 0x00BD3730: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD3734: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BD3738: LDR x9, [x9, #0xe28]       | X9 = (string**)(1152921510068165504)("spriteName");
            // 0x00BD373C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BD3740: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD3744: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BD3748: LDR x1, [x9]               | X1 = "spriteName";                      
            // 0x00BD374C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BD3750: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BD3754: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3758: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BD375C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3760: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheB;
            val_41 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheB;
            // 0x00BD3764: CBNZ x22, #0xbd37b0        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheB != null) goto label_42;
            if(val_41 != null)
            {
                goto label_42;
            }
            // 0x00BD3768: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BD376C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BD3770: LDR x8, [x8, #0x588]       | X8 = 1152921510068165600;               
            // 0x00BD3774: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BD3778: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_spriteName_1(ref object o);
            // 0x00BD377C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_23 = null;
            // 0x00BD3780: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BD3784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD378C: MOV x2, x22                | X2 = 1152921510068165600 (0x1000000145851BE0);//ML01
            // 0x00BD3790: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_30 = val_23;
            // 0x00BD3794: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_spriteName_1(ref object o));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_spriteName_1(ref object o));
            // 0x00BD3798: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD379C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD37A0: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783261784
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheB = val_30;
            // 0x00BD37A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD37A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD37AC: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_41 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheB;
            label_42:
            // 0x00BD37B0: CBNZ x19, #0xbd37b8        | if (X1 != 0) goto label_43;             
            if(X1 != 0)
            {
                goto label_43;
            }
            // 0x00BD37B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::get_spriteName_1(ref object o)), ????);
            label_43:
            // 0x00BD37B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD37BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD37C0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD37C4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BD37C8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            // 0x00BD37CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD37D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD37D4: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheC;
            val_42 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheC;
            // 0x00BD37D8: CBNZ x22, #0xbd3824        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheC != null) goto label_44;
            if(val_42 != null)
            {
                goto label_44;
            }
            // 0x00BD37DC: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BD37E0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BD37E4: LDR x8, [x8, #0x2a8]       | X8 = 1152921510068166624;               
            // 0x00BD37E8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BD37EC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_spriteName_1(ref object o, object v);
            // 0x00BD37F0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_24 = null;
            // 0x00BD37F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BD37F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD37FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3800: MOV x2, x22                | X2 = 1152921510068166624 (0x1000000145851FE0);//ML01
            // 0x00BD3804: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_30 = val_24;
            // 0x00BD3808: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_spriteName_1(ref object o, object v));
            val_24 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_spriteName_1(ref object o, object v));
            // 0x00BD380C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3810: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3814: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783261792
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheC = val_30;
            // 0x00BD3818: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD381C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3820: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_42 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheC;
            label_44:
            // 0x00BD3824: CBNZ x19, #0xbd382c        | if (X1 != 0) goto label_45;             
            if(X1 != 0)
            {
                goto label_45;
            }
            // 0x00BD3828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.BMSymbol_Binding::set_spriteName_1(ref object o, object v)), ????);
            label_45:
            // 0x00BD382C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3830: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD3834: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BD3838: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BD383C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_42);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_42);
            // 0x00BD3840: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3844: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3848: LDR x21, [x8, #0x70]       | X21 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache0;
            val_43 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache0;
            // 0x00BD384C: CBNZ x21, #0xbd3898        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache0 != null) goto label_46;
            if(val_43 != null)
            {
                goto label_46;
            }
            // 0x00BD3850: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00BD3854: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BD3858: LDR x8, [x8, #0x298]       | X8 = 1152921510068167648;               
            // 0x00BD385C: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BD3860: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__0();
            // 0x00BD3864: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_25 = null;
            // 0x00BD3868: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BD386C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3870: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3874: MOV x2, x21                | X2 = 1152921510068167648 (0x10000001458523E0);//ML01
            // 0x00BD3878: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BD387C: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__0());
            val_25 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__0());
            // 0x00BD3880: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3884: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3888: STR x22, [x8, #0x70]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504783261808
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache0 = val_25;
            // 0x00BD388C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3890: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3894: LDR x21, [x8, #0x70]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_43 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache0;
            label_46:
            // 0x00BD3898: CBNZ x19, #0xbd38a0        | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x00BD389C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__0()), ????);
            label_47:
            // 0x00BD38A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD38A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD38A8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BD38AC: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BD38B0: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_43);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_43);
            // 0x00BD38B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD38B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD38BC: LDR x21, [x8, #0x78]       | X21 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache1;
            val_44 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache1;
            // 0x00BD38C0: CBNZ x21, #0xbd390c        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache1 != null) goto label_48;
            if(val_44 != null)
            {
                goto label_48;
            }
            // 0x00BD38C4: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00BD38C8: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BD38CC: LDR x8, [x8, #0x400]       | X8 = 1152921510068168672;               
            // 0x00BD38D0: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BD38D4: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__1(int s);
            // 0x00BD38D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_26 = null;
            // 0x00BD38DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BD38E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD38E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD38E8: MOV x2, x21                | X2 = 1152921510068168672 (0x10000001458527E0);//ML01
            // 0x00BD38EC: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BD38F0: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__1(int s));
            val_26 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__1(int s));
            // 0x00BD38F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD38F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD38FC: STR x22, [x8, #0x78]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504783261816
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache1 = val_26;
            // 0x00BD3900: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD3904: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3908: LDR x21, [x8, #0x78]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_44 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__am$cache1;
            label_48:
            // 0x00BD390C: CBNZ x19, #0xbd3914        | if (X1 != 0) goto label_49;             
            if(X1 != 0)
            {
                goto label_49;
            }
            // 0x00BD3910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.BMSymbol_Binding::<Register>m__1(int s)), ????);
            label_49:
            // 0x00BD3914: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3918: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD391C: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BD3920: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BD3924: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_44);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_44);
            // 0x00BD3928: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BD392C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3930: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BD3934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3938: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD393C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BD3940: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3944: CBNZ x20, #0xbd394c        | if (val_1 != null) goto label_50;       
            if(val_1 != null)
            {
                goto label_50;
            }
            // 0x00BD3948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_50:
            // 0x00BD394C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3950: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD3954: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BD3958: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BD395C: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BD3960: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD3964: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_27 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BD3968: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD396C: MOV x20, x0                | X20 = val_27;//m1                       
            // 0x00BD3970: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD3974: LDR x21, [x8, #0x68]       | X21 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheD;
            val_45 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheD;
            // 0x00BD3978: CBNZ x21, #0xbd39c4        | if (ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheD != null) goto label_51;
            if(val_45 != null)
            {
                goto label_51;
            }
            // 0x00BD397C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00BD3980: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BD3984: LDR x8, [x8, #0x1c8]       | X8 = 1152921510068173792;               
            // 0x00BD3988: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BD398C: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BD3990: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_28 = null;
            // 0x00BD3994: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BD3998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD399C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD39A0: MOV x2, x21                | X2 = 1152921510068173792 (0x1000000145853BE0);//ML01
            // 0x00BD39A4: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD39A8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_28 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BD39AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD39B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD39B4: STR x22, [x8, #0x68]       | ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783261800
            ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheD = val_28;
            // 0x00BD39B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.BMSymbol_Binding);
            // 0x00BD39BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.BMSymbol_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BD39C0: LDR x21, [x8, #0x68]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_45 = ILRuntime.Runtime.Generated.BMSymbol_Binding.<>f__mg$cacheD;
            label_51:
            // 0x00BD39C4: CBNZ x19, #0xbd39cc        | if (X1 != 0) goto label_52;             
            if(X1 != 0)
            {
                goto label_52;
            }
            // 0x00BD39C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.BMSymbol_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_52:
            // 0x00BD39CC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD39D0: MOV x1, x20                | X1 = val_27;//m1                        
            // 0x00BD39D4: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BD39D8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD39DC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD39E0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD39E4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD39E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD39EC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD39F0: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_27, func:  val_45); return;
            X1.RegisterCLRMethodRedirection(mi:  val_27, func:  val_45);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD39F4 (12401140), len: 584  VirtAddr: 0x00BD39F4 RVA: 0x00BD39F4 token: 100663911 methodIndex: 29956 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_length_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BD39F4: STP x26, x25, [sp, #-0x50]! | stack[1152921510068380656] = ???;  stack[1152921510068380664] = ???;  //  dest_result_addr=1152921510068380656 |  dest_result_addr=1152921510068380664
            // 0x00BD39F8: STP x24, x23, [sp, #0x10]  | stack[1152921510068380672] = ???;  stack[1152921510068380680] = ???;  //  dest_result_addr=1152921510068380672 |  dest_result_addr=1152921510068380680
            // 0x00BD39FC: STP x22, x21, [sp, #0x20]  | stack[1152921510068380688] = ???;  stack[1152921510068380696] = ???;  //  dest_result_addr=1152921510068380688 |  dest_result_addr=1152921510068380696
            // 0x00BD3A00: STP x20, x19, [sp, #0x30]  | stack[1152921510068380704] = ???;  stack[1152921510068380712] = ???;  //  dest_result_addr=1152921510068380704 |  dest_result_addr=1152921510068380712
            // 0x00BD3A04: STP x29, x30, [sp, #0x40]  | stack[1152921510068380720] = ???;  stack[1152921510068380728] = ???;  //  dest_result_addr=1152921510068380720 |  dest_result_addr=1152921510068380728
            // 0x00BD3A08: ADD x29, sp, #0x40         | X29 = (1152921510068380656 + 64) = 1152921510068380720 (0x1000000145886430);
            // 0x00BD3A0C: SUB sp, sp, #0x10          | SP = (1152921510068380656 - 16) = 1152921510068380640 (0x10000001458863E0);
            // 0x00BD3A10: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD3A14: LDRB w8, [x19, #0xbeb]     | W8 = (bool)static_value_03733BEB;       
            // 0x00BD3A18: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD3A1C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD3A20: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD3A24: TBNZ w8, #0, #0xbd3a40     | if (static_value_03733BEB == true) goto label_0;
            // 0x00BD3A28: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BD3A2C: LDR x8, [x8, #0x118]       | X8 = 0x2B8F7DC;                         
            // 0x00BD3A30: LDR w0, [x8]               | W0 = 0x14BB;                            
            // 0x00BD3A34: BL #0x2782188              | X0 = sub_2782188( ?? 0x14BB, ????);     
            // 0x00BD3A38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD3A3C: STRB w8, [x19, #0xbeb]     | static_value_03733BEB = true;            //  dest_result_addr=57883627
            label_0:
            // 0x00BD3A40: CBNZ x20, #0xbd3a48        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD3A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14BB, ????);     
            label_1:
            // 0x00BD3A48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3A4C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD3A50: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD3A54: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD3A58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3A5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3A60: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD3A64: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD3A68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD3A6C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD3A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3A74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3A78: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD3A7C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD3A80: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD3A84: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD3A88: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD3A8C: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD3A90: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD3A94: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD3A98: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD3A9C: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD3AA0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD3AA4: TBZ w9, #0, #0xbd3ab8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD3AA8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3AAC: CBNZ w9, #0xbd3ab8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD3AB0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD3AB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD3AB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3ABC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3AC0: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD3AC4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD3AC8: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BD3ACC: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BD3AD0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD3AD4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD3AD8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD3ADC: TBZ w9, #0, #0xbd3af0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD3AE0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3AE4: CBNZ w9, #0xbd3af0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD3AE8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD3AEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD3AF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3AF4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD3AF8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD3AFC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD3B00: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD3B04: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD3B08: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD3B0C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD3B10: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD3B14: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD3B18: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD3B1C: TBZ w9, #0, #0xbd3b30      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD3B20: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3B24: CBNZ w9, #0xbd3b30         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD3B28: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD3B2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD3B30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3B34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3B38: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD3B3C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD3B40: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD3B44: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD3B48: CBZ x0, #0xbd3bac          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD3B4C: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD3B50: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD3B54: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD3B58: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD3B5C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD3B60: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD3B64: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD3B68: B.LO #0xbd3b84             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD3B6C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD3B70: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD3B74: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD3B78: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD3B7C: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD3B80: B.EQ #0xbd3bac             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD3B84: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD3B88: ADD x8, sp, #8             | X8 = (1152921510068380640 + 8) = 1152921510068380648 (0x10000001458863E8);
            // 0x00BD3B8C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD3B90: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510068368736]
            // 0x00BD3B94: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD3B98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3B9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD3BA0: ADD x0, sp, #8             | X0 = (1152921510068380640 + 8) = 1152921510068380648 (0x10000001458863E8);
            // 0x00BD3BA4: BL #0x299a140              | 
            // 0x00BD3BA8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD3BAC: CBNZ x20, #0xbd3bb4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD3BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001458863E8, ????);
            label_11:
            // 0x00BD3BB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3BB8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD3BBC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD3BC0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD3BC4: CBNZ x22, #0xbd3bcc        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD3BC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD3BCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3BD0: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3BD4: BL #0xb929f0               | X0 = val_11.get_length();               
            int val_9 = val_11.length;
            // 0x00BD3BD8: CBZ x19, #0xbd3c34         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BD3BDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD3BE0: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BD3BE4: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD3BE8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BD3BEC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD3BF0: TBZ w9, #0, #0xbd3c00      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BD3BF4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD3BF8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD3BFC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BD3C00: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BD3C04: SUB sp, x29, #0x40         | SP = (1152921510068380720 - 64) = 1152921510068380656 (0x10000001458863F0);
            // 0x00BD3C08: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD3C0C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD3C10: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD3C14: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD3C18: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD3C1C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD3C20: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BD3C24: ADD x0, sp, #8             | X0 = (1152921510068380736 + 8) = 1152921510068380744 (0x1000000145886448);
            // 0x00BD3C28: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000145886448); //ERROR_TYPE
            // 0x00BD3C2C: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BD3C30: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BD3C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BD3C38: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD3C3C (12401724), len: 584  VirtAddr: 0x00BD3C3C RVA: 0x00BD3C3C token: 100663912 methodIndex: 29957 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_offsetX_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BD3C3C: STP x26, x25, [sp, #-0x50]! | stack[1152921510068550000] = ???;  stack[1152921510068550008] = ???;  //  dest_result_addr=1152921510068550000 |  dest_result_addr=1152921510068550008
            // 0x00BD3C40: STP x24, x23, [sp, #0x10]  | stack[1152921510068550016] = ???;  stack[1152921510068550024] = ???;  //  dest_result_addr=1152921510068550016 |  dest_result_addr=1152921510068550024
            // 0x00BD3C44: STP x22, x21, [sp, #0x20]  | stack[1152921510068550032] = ???;  stack[1152921510068550040] = ???;  //  dest_result_addr=1152921510068550032 |  dest_result_addr=1152921510068550040
            // 0x00BD3C48: STP x20, x19, [sp, #0x30]  | stack[1152921510068550048] = ???;  stack[1152921510068550056] = ???;  //  dest_result_addr=1152921510068550048 |  dest_result_addr=1152921510068550056
            // 0x00BD3C4C: STP x29, x30, [sp, #0x40]  | stack[1152921510068550064] = ???;  stack[1152921510068550072] = ???;  //  dest_result_addr=1152921510068550064 |  dest_result_addr=1152921510068550072
            // 0x00BD3C50: ADD x29, sp, #0x40         | X29 = (1152921510068550000 + 64) = 1152921510068550064 (0x10000001458AF9B0);
            // 0x00BD3C54: SUB sp, sp, #0x10          | SP = (1152921510068550000 - 16) = 1152921510068549984 (0x10000001458AF960);
            // 0x00BD3C58: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD3C5C: LDRB w8, [x19, #0xbec]     | W8 = (bool)static_value_03733BEC;       
            // 0x00BD3C60: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD3C64: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD3C68: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD3C6C: TBNZ w8, #0, #0xbd3c88     | if (static_value_03733BEC == true) goto label_0;
            // 0x00BD3C70: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00BD3C74: LDR x8, [x8, #0x790]       | X8 = 0x2B8F7E0;                         
            // 0x00BD3C78: LDR w0, [x8]               | W0 = 0x14BC;                            
            // 0x00BD3C7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14BC, ????);     
            // 0x00BD3C80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD3C84: STRB w8, [x19, #0xbec]     | static_value_03733BEC = true;            //  dest_result_addr=57883628
            label_0:
            // 0x00BD3C88: CBNZ x20, #0xbd3c90        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD3C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14BC, ????);     
            label_1:
            // 0x00BD3C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3C94: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD3C98: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD3C9C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD3CA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3CA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3CA8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD3CAC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD3CB0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD3CB4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD3CB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3CBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3CC0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD3CC4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD3CC8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD3CCC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD3CD0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD3CD4: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD3CD8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD3CDC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD3CE0: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD3CE4: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD3CE8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD3CEC: TBZ w9, #0, #0xbd3d00      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD3CF0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3CF4: CBNZ w9, #0xbd3d00         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD3CF8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD3CFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD3D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3D08: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD3D0C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD3D10: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BD3D14: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BD3D18: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD3D1C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD3D20: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD3D24: TBZ w9, #0, #0xbd3d38      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD3D28: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3D2C: CBNZ w9, #0xbd3d38         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD3D30: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD3D34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD3D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3D3C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD3D40: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD3D44: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD3D48: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD3D4C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD3D50: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD3D54: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD3D58: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD3D5C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD3D60: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD3D64: TBZ w9, #0, #0xbd3d78      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD3D68: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3D6C: CBNZ w9, #0xbd3d78         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD3D70: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD3D74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD3D78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3D7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3D80: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD3D84: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD3D88: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD3D8C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD3D90: CBZ x0, #0xbd3df4          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD3D94: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD3D98: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD3D9C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD3DA0: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD3DA4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD3DA8: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD3DAC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD3DB0: B.LO #0xbd3dcc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD3DB4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD3DB8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD3DBC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD3DC0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD3DC4: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD3DC8: B.EQ #0xbd3df4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD3DCC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD3DD0: ADD x8, sp, #8             | X8 = (1152921510068549984 + 8) = 1152921510068549992 (0x10000001458AF968);
            // 0x00BD3DD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD3DD8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510068538080]
            // 0x00BD3DDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD3DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3DE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD3DE8: ADD x0, sp, #8             | X0 = (1152921510068549984 + 8) = 1152921510068549992 (0x10000001458AF968);
            // 0x00BD3DEC: BL #0x299a140              | 
            // 0x00BD3DF0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD3DF4: CBNZ x20, #0xbd3dfc        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD3DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001458AF968, ????);
            label_11:
            // 0x00BD3DFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3E00: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD3E04: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD3E08: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD3E0C: CBNZ x22, #0xbd3e14        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD3E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD3E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3E18: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3E1C: BL #0xb92a30               | X0 = val_11.get_offsetX();              
            int val_9 = val_11.offsetX;
            // 0x00BD3E20: CBZ x19, #0xbd3e7c         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BD3E24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD3E28: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BD3E2C: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD3E30: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BD3E34: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD3E38: TBZ w9, #0, #0xbd3e48      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BD3E3C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD3E40: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD3E44: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BD3E48: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BD3E4C: SUB sp, x29, #0x40         | SP = (1152921510068550064 - 64) = 1152921510068550000 (0x10000001458AF970);
            // 0x00BD3E50: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD3E54: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD3E58: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD3E5C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD3E60: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD3E64: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD3E68: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BD3E6C: ADD x0, sp, #8             | X0 = (1152921510068550080 + 8) = 1152921510068550088 (0x10000001458AF9C8);
            // 0x00BD3E70: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001458AF9C8); //ERROR_TYPE
            // 0x00BD3E74: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BD3E78: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BD3E7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BD3E80: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD3E84 (12402308), len: 584  VirtAddr: 0x00BD3E84 RVA: 0x00BD3E84 token: 100663913 methodIndex: 29958 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_offsetY_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BD3E84: STP x26, x25, [sp, #-0x50]! | stack[1152921510068719344] = ???;  stack[1152921510068719352] = ???;  //  dest_result_addr=1152921510068719344 |  dest_result_addr=1152921510068719352
            // 0x00BD3E88: STP x24, x23, [sp, #0x10]  | stack[1152921510068719360] = ???;  stack[1152921510068719368] = ???;  //  dest_result_addr=1152921510068719360 |  dest_result_addr=1152921510068719368
            // 0x00BD3E8C: STP x22, x21, [sp, #0x20]  | stack[1152921510068719376] = ???;  stack[1152921510068719384] = ???;  //  dest_result_addr=1152921510068719376 |  dest_result_addr=1152921510068719384
            // 0x00BD3E90: STP x20, x19, [sp, #0x30]  | stack[1152921510068719392] = ???;  stack[1152921510068719400] = ???;  //  dest_result_addr=1152921510068719392 |  dest_result_addr=1152921510068719400
            // 0x00BD3E94: STP x29, x30, [sp, #0x40]  | stack[1152921510068719408] = ???;  stack[1152921510068719416] = ???;  //  dest_result_addr=1152921510068719408 |  dest_result_addr=1152921510068719416
            // 0x00BD3E98: ADD x29, sp, #0x40         | X29 = (1152921510068719344 + 64) = 1152921510068719408 (0x10000001458D8F30);
            // 0x00BD3E9C: SUB sp, sp, #0x10          | SP = (1152921510068719344 - 16) = 1152921510068719328 (0x10000001458D8EE0);
            // 0x00BD3EA0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD3EA4: LDRB w8, [x19, #0xbed]     | W8 = (bool)static_value_03733BED;       
            // 0x00BD3EA8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD3EAC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD3EB0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD3EB4: TBNZ w8, #0, #0xbd3ed0     | if (static_value_03733BED == true) goto label_0;
            // 0x00BD3EB8: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x00BD3EBC: LDR x8, [x8, #0x3b0]       | X8 = 0x2B8F7E4;                         
            // 0x00BD3EC0: LDR w0, [x8]               | W0 = 0x14BD;                            
            // 0x00BD3EC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14BD, ????);     
            // 0x00BD3EC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD3ECC: STRB w8, [x19, #0xbed]     | static_value_03733BED = true;            //  dest_result_addr=57883629
            label_0:
            // 0x00BD3ED0: CBNZ x20, #0xbd3ed8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD3ED4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14BD, ????);     
            label_1:
            // 0x00BD3ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD3EDC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD3EE0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD3EE4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD3EE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3EEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3EF0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD3EF4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD3EF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD3EFC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD3F00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3F04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3F08: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD3F0C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD3F10: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD3F14: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD3F18: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD3F1C: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD3F20: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD3F24: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD3F28: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD3F2C: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD3F30: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD3F34: TBZ w9, #0, #0xbd3f48      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD3F38: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3F3C: CBNZ w9, #0xbd3f48         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD3F40: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD3F44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD3F48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3F4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD3F50: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD3F54: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD3F58: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BD3F5C: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BD3F60: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD3F64: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD3F68: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD3F6C: TBZ w9, #0, #0xbd3f80      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD3F70: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3F74: CBNZ w9, #0xbd3f80         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD3F78: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD3F7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD3F80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3F84: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD3F88: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD3F8C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD3F90: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD3F94: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD3F98: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD3F9C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD3FA0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD3FA4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD3FA8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD3FAC: TBZ w9, #0, #0xbd3fc0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD3FB0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD3FB4: CBNZ w9, #0xbd3fc0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD3FB8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD3FBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD3FC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD3FC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD3FC8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD3FCC: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD3FD0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD3FD4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD3FD8: CBZ x0, #0xbd403c          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD3FDC: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD3FE0: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD3FE4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD3FE8: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD3FEC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD3FF0: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD3FF4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD3FF8: B.LO #0xbd4014             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD3FFC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD4000: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD4004: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4008: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD400C: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD4010: B.EQ #0xbd403c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD4014: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD4018: ADD x8, sp, #8             | X8 = (1152921510068719328 + 8) = 1152921510068719336 (0x10000001458D8EE8);
            // 0x00BD401C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD4020: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510068707424]
            // 0x00BD4024: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD4028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD402C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD4030: ADD x0, sp, #8             | X0 = (1152921510068719328 + 8) = 1152921510068719336 (0x10000001458D8EE8);
            // 0x00BD4034: BL #0x299a140              | 
            // 0x00BD4038: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD403C: CBNZ x20, #0xbd4044        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD4040: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001458D8EE8, ????);
            label_11:
            // 0x00BD4044: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4048: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD404C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD4050: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD4054: CBNZ x22, #0xbd405c        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD4058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD405C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4060: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4064: BL #0xb92a38               | X0 = val_11.get_offsetY();              
            int val_9 = val_11.offsetY;
            // 0x00BD4068: CBZ x19, #0xbd40c4         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BD406C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4070: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BD4074: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4078: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BD407C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD4080: TBZ w9, #0, #0xbd4090      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BD4084: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD4088: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD408C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BD4090: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BD4094: SUB sp, x29, #0x40         | SP = (1152921510068719408 - 64) = 1152921510068719344 (0x10000001458D8EF0);
            // 0x00BD4098: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD409C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD40A0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD40A4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD40A8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD40AC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD40B0: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BD40B4: ADD x0, sp, #8             | X0 = (1152921510068719424 + 8) = 1152921510068719432 (0x10000001458D8F48);
            // 0x00BD40B8: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001458D8F48); //ERROR_TYPE
            // 0x00BD40BC: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BD40C0: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BD40C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BD40C8: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD40CC (12402892), len: 584  VirtAddr: 0x00BD40CC RVA: 0x00BD40CC token: 100663914 methodIndex: 29959 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_width_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BD40CC: STP x26, x25, [sp, #-0x50]! | stack[1152921510068888688] = ???;  stack[1152921510068888696] = ???;  //  dest_result_addr=1152921510068888688 |  dest_result_addr=1152921510068888696
            // 0x00BD40D0: STP x24, x23, [sp, #0x10]  | stack[1152921510068888704] = ???;  stack[1152921510068888712] = ???;  //  dest_result_addr=1152921510068888704 |  dest_result_addr=1152921510068888712
            // 0x00BD40D4: STP x22, x21, [sp, #0x20]  | stack[1152921510068888720] = ???;  stack[1152921510068888728] = ???;  //  dest_result_addr=1152921510068888720 |  dest_result_addr=1152921510068888728
            // 0x00BD40D8: STP x20, x19, [sp, #0x30]  | stack[1152921510068888736] = ???;  stack[1152921510068888744] = ???;  //  dest_result_addr=1152921510068888736 |  dest_result_addr=1152921510068888744
            // 0x00BD40DC: STP x29, x30, [sp, #0x40]  | stack[1152921510068888752] = ???;  stack[1152921510068888760] = ???;  //  dest_result_addr=1152921510068888752 |  dest_result_addr=1152921510068888760
            // 0x00BD40E0: ADD x29, sp, #0x40         | X29 = (1152921510068888688 + 64) = 1152921510068888752 (0x10000001459024B0);
            // 0x00BD40E4: SUB sp, sp, #0x10          | SP = (1152921510068888688 - 16) = 1152921510068888672 (0x1000000145902460);
            // 0x00BD40E8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD40EC: LDRB w8, [x19, #0xbee]     | W8 = (bool)static_value_03733BEE;       
            // 0x00BD40F0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD40F4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD40F8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD40FC: TBNZ w8, #0, #0xbd4118     | if (static_value_03733BEE == true) goto label_0;
            // 0x00BD4100: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BD4104: LDR x8, [x8, #0x438]       | X8 = 0x2B8F7F4;                         
            // 0x00BD4108: LDR w0, [x8]               | W0 = 0x14C1;                            
            // 0x00BD410C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C1, ????);     
            // 0x00BD4110: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4114: STRB w8, [x19, #0xbee]     | static_value_03733BEE = true;            //  dest_result_addr=57883630
            label_0:
            // 0x00BD4118: CBNZ x20, #0xbd4120        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD411C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14C1, ????);     
            label_1:
            // 0x00BD4120: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4124: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4128: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD412C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD4130: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4134: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4138: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD413C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD4140: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4144: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD4148: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD414C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4150: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4154: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD4158: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD415C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD4160: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD4164: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD4168: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD416C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD4170: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD4174: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD4178: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD417C: TBZ w9, #0, #0xbd4190      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD4180: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4184: CBNZ w9, #0xbd4190         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD4188: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD418C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD4190: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4194: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4198: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD419C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD41A0: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BD41A4: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BD41A8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD41AC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD41B0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD41B4: TBZ w9, #0, #0xbd41c8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD41B8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD41BC: CBNZ w9, #0xbd41c8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD41C0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD41C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD41C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD41CC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD41D0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD41D4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD41D8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD41DC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD41E0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD41E4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD41E8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD41EC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD41F0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD41F4: TBZ w9, #0, #0xbd4208      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD41F8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD41FC: CBNZ w9, #0xbd4208         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD4200: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD4204: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD4208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD420C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4210: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD4214: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD4218: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD421C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD4220: CBZ x0, #0xbd4284          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD4224: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD4228: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD422C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD4230: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD4234: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4238: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD423C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4240: B.LO #0xbd425c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD4244: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD4248: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD424C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4250: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD4254: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD4258: B.EQ #0xbd4284             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD425C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD4260: ADD x8, sp, #8             | X8 = (1152921510068888672 + 8) = 1152921510068888680 (0x1000000145902468);
            // 0x00BD4264: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD4268: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510068876768]
            // 0x00BD426C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD4270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4274: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD4278: ADD x0, sp, #8             | X0 = (1152921510068888672 + 8) = 1152921510068888680 (0x1000000145902468);
            // 0x00BD427C: BL #0x299a140              | 
            // 0x00BD4280: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD4284: CBNZ x20, #0xbd428c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD4288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145902468, ????);
            label_11:
            // 0x00BD428C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4290: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4294: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD4298: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD429C: CBNZ x22, #0xbd42a4        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD42A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD42A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD42A8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD42AC: BL #0xb92a40               | X0 = val_11.get_width();                
            int val_9 = val_11.width;
            // 0x00BD42B0: CBZ x19, #0xbd430c         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BD42B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD42B8: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BD42BC: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD42C0: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BD42C4: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD42C8: TBZ w9, #0, #0xbd42d8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BD42CC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD42D0: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD42D4: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BD42D8: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BD42DC: SUB sp, x29, #0x40         | SP = (1152921510068888752 - 64) = 1152921510068888688 (0x1000000145902470);
            // 0x00BD42E0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD42E4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD42E8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD42EC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD42F0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD42F4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD42F8: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BD42FC: ADD x0, sp, #8             | X0 = (1152921510068888768 + 8) = 1152921510068888776 (0x10000001459024C8);
            // 0x00BD4300: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001459024C8); //ERROR_TYPE
            // 0x00BD4304: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BD4308: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BD430C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BD4310: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD4314 (12403476), len: 584  VirtAddr: 0x00BD4314 RVA: 0x00BD4314 token: 100663915 methodIndex: 29960 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_height_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BD4314: STP x26, x25, [sp, #-0x50]! | stack[1152921510069058032] = ???;  stack[1152921510069058040] = ???;  //  dest_result_addr=1152921510069058032 |  dest_result_addr=1152921510069058040
            // 0x00BD4318: STP x24, x23, [sp, #0x10]  | stack[1152921510069058048] = ???;  stack[1152921510069058056] = ???;  //  dest_result_addr=1152921510069058048 |  dest_result_addr=1152921510069058056
            // 0x00BD431C: STP x22, x21, [sp, #0x20]  | stack[1152921510069058064] = ???;  stack[1152921510069058072] = ???;  //  dest_result_addr=1152921510069058064 |  dest_result_addr=1152921510069058072
            // 0x00BD4320: STP x20, x19, [sp, #0x30]  | stack[1152921510069058080] = ???;  stack[1152921510069058088] = ???;  //  dest_result_addr=1152921510069058080 |  dest_result_addr=1152921510069058088
            // 0x00BD4324: STP x29, x30, [sp, #0x40]  | stack[1152921510069058096] = ???;  stack[1152921510069058104] = ???;  //  dest_result_addr=1152921510069058096 |  dest_result_addr=1152921510069058104
            // 0x00BD4328: ADD x29, sp, #0x40         | X29 = (1152921510069058032 + 64) = 1152921510069058096 (0x100000014592BA30);
            // 0x00BD432C: SUB sp, sp, #0x10          | SP = (1152921510069058032 - 16) = 1152921510069058016 (0x100000014592B9E0);
            // 0x00BD4330: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD4334: LDRB w8, [x19, #0xbef]     | W8 = (bool)static_value_03733BEF;       
            // 0x00BD4338: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD433C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD4340: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD4344: TBNZ w8, #0, #0xbd4360     | if (static_value_03733BEF == true) goto label_0;
            // 0x00BD4348: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00BD434C: LDR x8, [x8, #0x200]       | X8 = 0x2B8F7D8;                         
            // 0x00BD4350: LDR w0, [x8]               | W0 = 0x14BA;                            
            // 0x00BD4354: BL #0x2782188              | X0 = sub_2782188( ?? 0x14BA, ????);     
            // 0x00BD4358: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD435C: STRB w8, [x19, #0xbef]     | static_value_03733BEF = true;            //  dest_result_addr=57883631
            label_0:
            // 0x00BD4360: CBNZ x20, #0xbd4368        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD4364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14BA, ????);     
            label_1:
            // 0x00BD4368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD436C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4370: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD4374: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD4378: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD437C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4380: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4384: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD4388: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD438C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD4390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4394: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4398: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD439C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD43A0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD43A4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD43A8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD43AC: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD43B0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD43B4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD43B8: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD43BC: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD43C0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD43C4: TBZ w9, #0, #0xbd43d8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD43C8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD43CC: CBNZ w9, #0xbd43d8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD43D0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD43D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD43D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD43DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD43E0: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD43E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD43E8: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BD43EC: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BD43F0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD43F4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD43F8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD43FC: TBZ w9, #0, #0xbd4410      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD4400: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4404: CBNZ w9, #0xbd4410         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD4408: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD440C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD4410: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4414: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD4418: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD441C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD4420: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD4424: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD4428: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD442C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD4430: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD4434: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD4438: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD443C: TBZ w9, #0, #0xbd4450      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD4440: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4444: CBNZ w9, #0xbd4450         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD4448: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD444C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD4450: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4454: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4458: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD445C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD4460: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD4464: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD4468: CBZ x0, #0xbd44cc          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD446C: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD4470: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD4474: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD4478: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD447C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4480: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4484: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4488: B.LO #0xbd44a4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD448C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD4490: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD4494: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4498: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD449C: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD44A0: B.EQ #0xbd44cc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD44A4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD44A8: ADD x8, sp, #8             | X8 = (1152921510069058016 + 8) = 1152921510069058024 (0x100000014592B9E8);
            // 0x00BD44AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD44B0: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510069046112]
            // 0x00BD44B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD44B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD44BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD44C0: ADD x0, sp, #8             | X0 = (1152921510069058016 + 8) = 1152921510069058024 (0x100000014592B9E8);
            // 0x00BD44C4: BL #0x299a140              | 
            // 0x00BD44C8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD44CC: CBNZ x20, #0xbd44d4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD44D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014592B9E8, ????);
            label_11:
            // 0x00BD44D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD44D8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD44DC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD44E0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD44E4: CBNZ x22, #0xbd44ec        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD44E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD44EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD44F0: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD44F4: BL #0xb92a48               | X0 = val_11.get_height();               
            int val_9 = val_11.height;
            // 0x00BD44F8: CBZ x19, #0xbd4554         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BD44FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4500: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BD4504: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4508: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BD450C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD4510: TBZ w9, #0, #0xbd4520      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BD4514: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD4518: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD451C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BD4520: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BD4524: SUB sp, x29, #0x40         | SP = (1152921510069058096 - 64) = 1152921510069058032 (0x100000014592B9F0);
            // 0x00BD4528: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD452C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD4530: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD4534: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD4538: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD453C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD4540: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BD4544: ADD x0, sp, #8             | X0 = (1152921510069058112 + 8) = 1152921510069058120 (0x100000014592BA48);
            // 0x00BD4548: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x100000014592BA48); //ERROR_TYPE
            // 0x00BD454C: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BD4550: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BD4554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BD4558: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD455C (12404060), len: 584  VirtAddr: 0x00BD455C RVA: 0x00BD455C token: 100663916 methodIndex: 29961 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_advance_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BD455C: STP x26, x25, [sp, #-0x50]! | stack[1152921510069227376] = ???;  stack[1152921510069227384] = ???;  //  dest_result_addr=1152921510069227376 |  dest_result_addr=1152921510069227384
            // 0x00BD4560: STP x24, x23, [sp, #0x10]  | stack[1152921510069227392] = ???;  stack[1152921510069227400] = ???;  //  dest_result_addr=1152921510069227392 |  dest_result_addr=1152921510069227400
            // 0x00BD4564: STP x22, x21, [sp, #0x20]  | stack[1152921510069227408] = ???;  stack[1152921510069227416] = ???;  //  dest_result_addr=1152921510069227408 |  dest_result_addr=1152921510069227416
            // 0x00BD4568: STP x20, x19, [sp, #0x30]  | stack[1152921510069227424] = ???;  stack[1152921510069227432] = ???;  //  dest_result_addr=1152921510069227424 |  dest_result_addr=1152921510069227432
            // 0x00BD456C: STP x29, x30, [sp, #0x40]  | stack[1152921510069227440] = ???;  stack[1152921510069227448] = ???;  //  dest_result_addr=1152921510069227440 |  dest_result_addr=1152921510069227448
            // 0x00BD4570: ADD x29, sp, #0x40         | X29 = (1152921510069227376 + 64) = 1152921510069227440 (0x1000000145954FB0);
            // 0x00BD4574: SUB sp, sp, #0x10          | SP = (1152921510069227376 - 16) = 1152921510069227360 (0x1000000145954F60);
            // 0x00BD4578: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD457C: LDRB w8, [x19, #0xbf0]     | W8 = (bool)static_value_03733BF0;       
            // 0x00BD4580: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD4584: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD4588: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD458C: TBNZ w8, #0, #0xbd45a8     | if (static_value_03733BF0 == true) goto label_0;
            // 0x00BD4590: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00BD4594: LDR x8, [x8, #0xc8]        | X8 = 0x2B8F7D4;                         
            // 0x00BD4598: LDR w0, [x8]               | W0 = 0x14B9;                            
            // 0x00BD459C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B9, ????);     
            // 0x00BD45A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD45A4: STRB w8, [x19, #0xbf0]     | static_value_03733BF0 = true;            //  dest_result_addr=57883632
            label_0:
            // 0x00BD45A8: CBNZ x20, #0xbd45b0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD45AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B9, ????);     
            label_1:
            // 0x00BD45B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD45B4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD45B8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD45BC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD45C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD45C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD45C8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD45CC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD45D0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD45D4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD45D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD45DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD45E0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD45E4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD45E8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD45EC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD45F0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD45F4: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD45F8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD45FC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD4600: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD4604: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD4608: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD460C: TBZ w9, #0, #0xbd4620      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD4610: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4614: CBNZ w9, #0xbd4620         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD4618: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD461C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD4620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4624: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4628: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD462C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD4630: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BD4634: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BD4638: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD463C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4640: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD4644: TBZ w9, #0, #0xbd4658      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD4648: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD464C: CBNZ w9, #0xbd4658         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD4650: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD4654: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD4658: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD465C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD4660: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD4664: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD4668: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD466C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD4670: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD4674: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD4678: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD467C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD4680: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD4684: TBZ w9, #0, #0xbd4698      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD4688: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD468C: CBNZ w9, #0xbd4698         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD4690: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD4694: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD4698: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD469C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD46A0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD46A4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD46A8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD46AC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD46B0: CBZ x0, #0xbd4714          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD46B4: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD46B8: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD46BC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD46C0: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD46C4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD46C8: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD46CC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD46D0: B.LO #0xbd46ec             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD46D4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD46D8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD46DC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD46E0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD46E4: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD46E8: B.EQ #0xbd4714             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD46EC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD46F0: ADD x8, sp, #8             | X8 = (1152921510069227360 + 8) = 1152921510069227368 (0x1000000145954F68);
            // 0x00BD46F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD46F8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510069215456]
            // 0x00BD46FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD4700: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4704: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD4708: ADD x0, sp, #8             | X0 = (1152921510069227360 + 8) = 1152921510069227368 (0x1000000145954F68);
            // 0x00BD470C: BL #0x299a140              | 
            // 0x00BD4710: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD4714: CBNZ x20, #0xbd471c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD4718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145954F68, ????);
            label_11:
            // 0x00BD471C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4720: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4724: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD4728: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD472C: CBNZ x22, #0xbd4734        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD4730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD4734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4738: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD473C: BL #0xb92a50               | X0 = val_11.get_advance();              
            int val_9 = val_11.advance;
            // 0x00BD4740: CBZ x19, #0xbd479c         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BD4744: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4748: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_9;         //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_9;
            // 0x00BD474C: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4750: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BD4754: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD4758: TBZ w9, #0, #0xbd4768      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BD475C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD4760: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD4764: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BD4768: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BD476C: SUB sp, x29, #0x40         | SP = (1152921510069227440 - 64) = 1152921510069227376 (0x1000000145954F70);
            // 0x00BD4770: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD4774: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD4778: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD477C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD4780: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BD4784: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD4788: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BD478C: ADD x0, sp, #8             | X0 = (1152921510069227456 + 8) = 1152921510069227464 (0x1000000145954FC8);
            // 0x00BD4790: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000145954FC8); //ERROR_TYPE
            // 0x00BD4794: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BD4798: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BD479C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BD47A0: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD47A4 (12404644), len: 584  VirtAddr: 0x00BD47A4 RVA: 0x00BD47A4 token: 100663917 methodIndex: 29962 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_uvRect_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            float val_8;
            //  | 
            var val_11;
            // 0x00BD47A4: STP x24, x23, [sp, #-0x40]! | stack[1152921510069401856] = ???;  stack[1152921510069401864] = ???;  //  dest_result_addr=1152921510069401856 |  dest_result_addr=1152921510069401864
            // 0x00BD47A8: STP x22, x21, [sp, #0x10]  | stack[1152921510069401872] = ???;  stack[1152921510069401880] = ???;  //  dest_result_addr=1152921510069401872 |  dest_result_addr=1152921510069401880
            // 0x00BD47AC: STP x20, x19, [sp, #0x20]  | stack[1152921510069401888] = ???;  stack[1152921510069401896] = ???;  //  dest_result_addr=1152921510069401888 |  dest_result_addr=1152921510069401896
            // 0x00BD47B0: STP x29, x30, [sp, #0x30]  | stack[1152921510069401904] = ???;  stack[1152921510069401912] = ???;  //  dest_result_addr=1152921510069401904 |  dest_result_addr=1152921510069401912
            // 0x00BD47B4: ADD x29, sp, #0x30         | X29 = (1152921510069401856 + 48) = 1152921510069401904 (0x100000014597F930);
            // 0x00BD47B8: SUB sp, sp, #0x10          | SP = (1152921510069401856 - 16) = 1152921510069401840 (0x100000014597F8F0);
            // 0x00BD47BC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD47C0: LDRB w8, [x20, #0xbf1]     | W8 = (bool)static_value_03733BF1;       
            // 0x00BD47C4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BD47C8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BD47CC: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BD47D0: TBNZ w8, #0, #0xbd47ec     | if (static_value_03733BF1 == true) goto label_0;
            // 0x00BD47D4: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00BD47D8: LDR x8, [x8, #0xd70]       | X8 = 0x2B8F7F0;                         
            // 0x00BD47DC: LDR w0, [x8]               | W0 = 0x14C0;                            
            // 0x00BD47E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C0, ????);     
            // 0x00BD47E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD47E8: STRB w8, [x20, #0xbf1]     | static_value_03733BF1 = true;            //  dest_result_addr=57883633
            label_0:
            // 0x00BD47EC: CBNZ x21, #0xbd47f4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD47F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14C0, ????);     
            label_1:
            // 0x00BD47F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD47F8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BD47FC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD4800: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD4804: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4808: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD480C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4810: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD4814: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4818: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD481C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4820: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4824: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4828: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD482C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4830: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD4834: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD4838: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD483C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BD4840: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD4844: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD4848: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD484C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD4850: TBZ w9, #0, #0xbd4864      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD4854: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4858: CBNZ w9, #0xbd4864         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD485C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD4860: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD4864: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4868: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD486C: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD4870: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD4874: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BD4878: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BD487C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD4880: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4884: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD4888: TBZ w9, #0, #0xbd489c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD488C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4890: CBNZ w9, #0xbd489c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD4894: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD4898: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD489C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD48A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD48A4: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BD48A8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD48AC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BD48B0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD48B4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD48B8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD48BC: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BD48C0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD48C4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD48C8: TBZ w9, #0, #0xbd48dc      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD48CC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD48D0: CBNZ w9, #0xbd48dc         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD48D4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD48D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD48DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD48E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD48E4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD48E8: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BD48EC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD48F0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BD48F4: CBZ x0, #0xbd4958          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD48F8: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD48FC: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD4900: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD4904: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD4908: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD490C: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4910: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4914: B.LO #0xbd4930             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD4918: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD491C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD4920: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4924: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD4928: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BD492C: B.EQ #0xbd4958             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD4930: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD4934: MOV x8, sp                 | X8 = 1152921510069401840 (0x100000014597F8F0);//ML01
            // 0x00BD4938: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD493C: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510069389920]
            // 0x00BD4940: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD4944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4948: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD494C: MOV x0, sp                 | X0 = 1152921510069401840 (0x100000014597F8F0);//ML01
            // 0x00BD4950: BL #0x299a140              | 
            // 0x00BD4954: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BD4958: CBNZ x21, #0xbd4960        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD495C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014597F8F0, ????);
            label_11:
            // 0x00BD4960: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4964: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BD4968: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BD496C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD4970: CBNZ x23, #0xbd4978        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BD4974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD4978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD497C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4980: BL #0xb92a58               | X0 = val_11.get_uvRect();               
            UnityEngine.Rect val_9 = val_11.uvRect;
            // 0x00BD4984: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00BD4988: STR s0, [sp]               | val_8 = val_9.m_XMin;                    //  dest_result_addr=1152921510069401840
            val_8 = val_9.m_XMin;
            // 0x00BD498C: LDR x8, [x8, #0xe48]       | X8 = 1152921504706473984;               
            // 0x00BD4990: MOV x1, sp                 | X1 = 1152921510069401840 (0x100000014597F8F0);//ML01
            // 0x00BD4994: LDR x0, [x8]               | X0 = typeof(UnityEngine.Rect);          
            // 0x00BD4998: STP s1, s2, [sp, #4]       | stack[1152921510069401844] = val_9.m_YMin;  stack[1152921510069401848] = val_9.m_Width;  //  dest_result_addr=1152921510069401844 |  dest_result_addr=1152921510069401848
            // 0x00BD499C: STR s3, [sp, #0xc]         | stack[1152921510069401852] = val_9.m_Height;  //  dest_result_addr=1152921510069401852
            // 0x00BD49A0: BL #0x27bc028              | X0 = 1152921510069475616 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Rect), val_9);
            // 0x00BD49A4: MOV x3, x0                 | X3 = 1152921510069475616 (0x1000000145991920);//ML01
            // 0x00BD49A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD49AC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BD49B0: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BD49B4: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BD49B8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD49BC: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  val_8 = val_9.m_XMin, mStack:  val_9.m_Width, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  val_8, mStack:  val_9.m_Width, obj:  ???, isBox:  ???);
            // 0x00BD49C0: SUB sp, x29, #0x30         | SP = (1152921510069401904 - 48) = 1152921510069401856 (0x100000014597F900);
            // 0x00BD49C4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD49C8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD49CC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD49D0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BD49D4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD49D8: MOV x19, x0                | 
            // 0x00BD49DC: MOV x0, sp                 | 
            // 0x00BD49E0: BL #0x299a140              | 
            // 0x00BD49E4: MOV x0, x19                | 
            // 0x00BD49E8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD49EC (12405228), len: 528  VirtAddr: 0x00BD49EC RVA: 0x00BD49EC token: 100663918 methodIndex: 29963 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* MarkAsChanged_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BD49EC: STP x24, x23, [sp, #-0x40]! | stack[1152921510069576320] = ???;  stack[1152921510069576328] = ???;  //  dest_result_addr=1152921510069576320 |  dest_result_addr=1152921510069576328
            // 0x00BD49F0: STP x22, x21, [sp, #0x10]  | stack[1152921510069576336] = ???;  stack[1152921510069576344] = ???;  //  dest_result_addr=1152921510069576336 |  dest_result_addr=1152921510069576344
            // 0x00BD49F4: STP x20, x19, [sp, #0x20]  | stack[1152921510069576352] = ???;  stack[1152921510069576360] = ???;  //  dest_result_addr=1152921510069576352 |  dest_result_addr=1152921510069576360
            // 0x00BD49F8: STP x29, x30, [sp, #0x30]  | stack[1152921510069576368] = ???;  stack[1152921510069576376] = ???;  //  dest_result_addr=1152921510069576368 |  dest_result_addr=1152921510069576376
            // 0x00BD49FC: ADD x29, sp, #0x30         | X29 = (1152921510069576320 + 48) = 1152921510069576368 (0x10000001459AA2B0);
            // 0x00BD4A00: SUB sp, sp, #0x10          | SP = (1152921510069576320 - 16) = 1152921510069576304 (0x10000001459AA270);
            // 0x00BD4A04: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD4A08: LDRB w8, [x20, #0xbf2]     | W8 = (bool)static_value_03733BF2;       
            // 0x00BD4A0C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BD4A10: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BD4A14: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD4A18: TBNZ w8, #0, #0xbd4a34     | if (static_value_03733BF2 == true) goto label_0;
            // 0x00BD4A1C: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00BD4A20: LDR x8, [x8, #0x9e0]       | X8 = 0x2B8F7F8;                         
            // 0x00BD4A24: LDR w0, [x8]               | W0 = 0x14C2;                            
            // 0x00BD4A28: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C2, ????);     
            // 0x00BD4A2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4A30: STRB w8, [x20, #0xbf2]     | static_value_03733BF2 = true;            //  dest_result_addr=57883634
            label_0:
            // 0x00BD4A34: CBNZ x19, #0xbd4a3c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD4A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14C2, ????);     
            label_1:
            // 0x00BD4A3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4A40: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD4A44: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD4A48: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD4A4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4A50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4A54: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4A58: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD4A5C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4A60: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD4A64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4A68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4A6C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4A70: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BD4A74: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4A78: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD4A7C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD4A80: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BD4A84: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BD4A88: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD4A8C: LDR x9, [x9, #0x648]       | X9 = 1152921504876015616;               
            // 0x00BD4A90: LDR x24, [x9]              | X24 = typeof(BMSymbol);                 
            // 0x00BD4A94: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD4A98: TBZ w9, #0, #0xbd4aac      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD4A9C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4AA0: CBNZ w9, #0xbd4aac         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD4AA4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD4AA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD4AAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4AB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4AB4: MOV x1, x24                | X1 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD4AB8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD4ABC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BD4AC0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BD4AC4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BD4AC8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4ACC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD4AD0: TBZ w9, #0, #0xbd4ae4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD4AD4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4AD8: CBNZ w9, #0xbd4ae4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD4ADC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD4AE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD4AE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4AE8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD4AEC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD4AF0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD4AF4: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BD4AF8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD4AFC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD4B00: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD4B04: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BD4B08: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD4B0C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD4B10: TBZ w9, #0, #0xbd4b24      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD4B14: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4B18: CBNZ w9, #0xbd4b24         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD4B1C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD4B20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD4B24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4B28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4B2C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BD4B30: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BD4B34: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD4B38: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BD4B3C: CBZ x0, #0xbd4ba0          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD4B40: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD4B44: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD4B48: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD4B4C: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD4B50: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4B54: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4B58: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4B5C: B.LO #0xbd4b78             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD4B60: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD4B64: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD4B68: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4B6C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD4B70: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BD4B74: B.EQ #0xbd4ba0             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD4B78: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD4B7C: ADD x8, sp, #8             | X8 = (1152921510069576304 + 8) = 1152921510069576312 (0x10000001459AA278);
            // 0x00BD4B80: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD4B84: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510069564384]
            // 0x00BD4B88: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD4B8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4B90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD4B94: ADD x0, sp, #8             | X0 = (1152921510069576304 + 8) = 1152921510069576312 (0x10000001459AA278);
            // 0x00BD4B98: BL #0x299a140              | 
            // 0x00BD4B9C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BD4BA0: CBNZ x19, #0xbd4ba8        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD4BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001459AA278, ????);
            label_11:
            // 0x00BD4BA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4BAC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BD4BB0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BD4BB4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD4BB8: CBNZ x22, #0xbd4bc0        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BD4BBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BD4BC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4BC4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4BC8: BL #0xb92a64               | val_9.MarkAsChanged();                  
            val_9.MarkAsChanged();
            // 0x00BD4BCC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BD4BD0: SUB sp, x29, #0x30         | SP = (1152921510069576368 - 48) = 1152921510069576320 (0x10000001459AA280);
            // 0x00BD4BD4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD4BD8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD4BDC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD4BE0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BD4BE4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD4BE8: MOV x19, x0                | 
            // 0x00BD4BEC: ADD x0, sp, #8             | 
            // 0x00BD4BF0: BL #0x299a140              | 
            // 0x00BD4BF4: MOV x0, x19                | 
            // 0x00BD4BF8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD4BFC (12405756), len: 860  VirtAddr: 0x00BD4BFC RVA: 0x00BD4BFC token: 100663919 methodIndex: 29964 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Validate_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            UIAtlas val_19;
            //  | 
            var val_20;
            //  | 
            bool val_21;
            //  | 
            var val_22;
            // 0x00BD4BFC: STP x28, x27, [sp, #-0x60]! | stack[1152921510069757920] = ???;  stack[1152921510069757928] = ???;  //  dest_result_addr=1152921510069757920 |  dest_result_addr=1152921510069757928
            // 0x00BD4C00: STP x26, x25, [sp, #0x10]  | stack[1152921510069757936] = ???;  stack[1152921510069757944] = ???;  //  dest_result_addr=1152921510069757936 |  dest_result_addr=1152921510069757944
            // 0x00BD4C04: STP x24, x23, [sp, #0x20]  | stack[1152921510069757952] = ???;  stack[1152921510069757960] = ???;  //  dest_result_addr=1152921510069757952 |  dest_result_addr=1152921510069757960
            // 0x00BD4C08: STP x22, x21, [sp, #0x30]  | stack[1152921510069757968] = ???;  stack[1152921510069757976] = ???;  //  dest_result_addr=1152921510069757968 |  dest_result_addr=1152921510069757976
            // 0x00BD4C0C: STP x20, x19, [sp, #0x40]  | stack[1152921510069757984] = ???;  stack[1152921510069757992] = ???;  //  dest_result_addr=1152921510069757984 |  dest_result_addr=1152921510069757992
            // 0x00BD4C10: STP x29, x30, [sp, #0x50]  | stack[1152921510069758000] = ???;  stack[1152921510069758008] = ???;  //  dest_result_addr=1152921510069758000 |  dest_result_addr=1152921510069758008
            // 0x00BD4C14: ADD x29, sp, #0x50         | X29 = (1152921510069757920 + 80) = 1152921510069758000 (0x10000001459D6830);
            // 0x00BD4C18: SUB sp, sp, #0x10          | SP = (1152921510069757920 - 16) = 1152921510069757904 (0x10000001459D67D0);
            // 0x00BD4C1C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD4C20: LDRB w8, [x19, #0xbf3]     | W8 = (bool)static_value_03733BF3;       
            // 0x00BD4C24: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BD4C28: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BD4C2C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BD4C30: TBNZ w8, #0, #0xbd4c4c     | if (static_value_03733BF3 == true) goto label_0;
            // 0x00BD4C34: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00BD4C38: LDR x8, [x8, #0xaf0]       | X8 = 0x2B8F810;                         
            // 0x00BD4C3C: LDR w0, [x8]               | W0 = 0x14C8;                            
            // 0x00BD4C40: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C8, ????);     
            // 0x00BD4C44: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4C48: STRB w8, [x19, #0xbf3]     | static_value_03733BF3 = true;            //  dest_result_addr=57883635
            label_0:
            // 0x00BD4C4C: CBNZ x20, #0xbd4c54        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD4C50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14C8, ????);     
            label_1:
            // 0x00BD4C54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4C58: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4C5C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD4C60: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BD4C64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4C68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4C6C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BD4C70: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD4C74: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4C78: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BD4C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4C80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4C84: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BD4C88: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD4C8C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4C90: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BD4C94: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BD4C98: ADRP x9, #0x363d000        | X9 = 56872960 (0x363D000);              
            // 0x00BD4C9C: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BD4CA0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BD4CA4: LDR x9, [x9, #0x2e8]       | X9 = 1152921504879104000;               
            // 0x00BD4CA8: LDR x25, [x9]              | X25 = typeof(UIAtlas);                  
            // 0x00BD4CAC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BD4CB0: TBZ w9, #0, #0xbd4cc4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BD4CB4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4CB8: CBNZ w9, #0xbd4cc4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BD4CBC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BD4CC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BD4CC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4CC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4CCC: MOV x1, x25                | X1 = 1152921504879104000 (0x10000000103A5000);//ML01
            // 0x00BD4CD0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD4CD4: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BD4CD8: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BD4CDC: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BD4CE0: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4CE4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BD4CE8: TBZ w9, #0, #0xbd4cfc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BD4CEC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4CF0: CBNZ w9, #0xbd4cfc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BD4CF4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BD4CF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BD4CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4D00: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD4D04: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BD4D08: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD4D0C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BD4D10: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD4D14: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BD4D18: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BD4D1C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BD4D20: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BD4D24: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BD4D28: TBZ w9, #0, #0xbd4d3c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BD4D2C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BD4D30: CBNZ w9, #0xbd4d3c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BD4D34: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BD4D38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BD4D3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4D40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4D44: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BD4D48: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BD4D4C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BD4D50: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x00BD4D54: CBZ x0, #0xbd4db8          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BD4D58: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BD4D5C: LDR x9, [x9, #0xf18]       | X9 = 1152921504879104000;               
            // 0x00BD4D60: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD4D64: LDR x1, [x9]               | X1 = typeof(UIAtlas);                   
            // 0x00BD4D68: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4D6C: LDRB w9, [x1, #0x104]      | W9 = UIAtlas.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4D70: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, UIAtlas.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4D74: B.LO #0xbd4d90             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < UIAtlas.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BD4D78: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD4D7C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UIAtlas.__il2cppRuntimeField_typeHierarchy
            // 0x00BD4D80: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (UIAtlas.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4D84: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (UIAtlas.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UIAtlas))
            // 0x00BD4D88: MOV x25, x0                | X25 = val_6;//m1                        
            val_19 = val_6;
            // 0x00BD4D8C: B.EQ #0xbd4db8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (UIAtlas.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BD4D90: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD4D94: MOV x8, sp                 | X8 = 1152921510069757904 (0x10000001459D67D0);//ML01
            // 0x00BD4D98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD4D9C: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510069746016]
            // 0x00BD4DA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BD4DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4DA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BD4DAC: MOV x0, sp                 | X0 = 1152921510069757904 (0x10000001459D67D0);//ML01
            // 0x00BD4DB0: BL #0x299a140              | 
            // 0x00BD4DB4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_10:
            // 0x00BD4DB8: CBNZ x20, #0xbd4dc0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BD4DBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001459D67D0, ????);
            label_11:
            // 0x00BD4DC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4DC4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4DC8: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BD4DCC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD4DD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4DD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4DD8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BD4DDC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BD4DE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BD4DE4: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BD4DE8: LDR x8, [x8, #0x648]       | X8 = 1152921504876015616;               
            // 0x00BD4DEC: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BD4DF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4DF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4DF8: LDR x1, [x8]               | X1 = typeof(BMSymbol);                  
            // 0x00BD4DFC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BD4E00: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x00BD4E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4E08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BD4E0C: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BD4E10: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BD4E14: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BD4E18: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BD4E1C: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BD4E20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4E24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD4E28: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x00BD4E2C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BD4E30: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x00BD4E34: CBZ x0, #0xbd4e98          | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x00BD4E38: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00BD4E3C: LDR x9, [x9, #0x610]       | X9 = 1152921504876015616;               
            // 0x00BD4E40: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BD4E44: LDR x1, [x9]               | X1 = typeof(BMSymbol);                  
            // 0x00BD4E48: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4E4C: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4E50: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4E54: B.LO #0xbd4e70             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BD4E58: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BD4E5C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarch
            // 0x00BD4E60: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4E64: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD4E68: MOV x21, x0                | X21 = val_12;//m1                       
            val_20 = val_12;
            // 0x00BD4E6C: B.EQ #0xbd4e98             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BD4E70: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BD4E74: ADD x8, sp, #8             | X8 = (1152921510069757904 + 8) = 1152921510069757912 (0x10000001459D67D8);
            // 0x00BD4E78: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BD4E7C: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510069746016]
            // 0x00BD4E80: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BD4E84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4E88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BD4E8C: ADD x0, sp, #8             | X0 = (1152921510069757904 + 8) = 1152921510069757912 (0x10000001459D67D8);
            // 0x00BD4E90: BL #0x299a140              | 
            // 0x00BD4E94: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_14:
            // 0x00BD4E98: CBNZ x20, #0xbd4ea0        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BD4E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001459D67D8, ????);
            label_15:
            // 0x00BD4EA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4EA4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BD4EA8: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BD4EAC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BD4EB0: CBNZ x21, #0xbd4eb8        | if (0x0 != 0) goto label_16;            
            if(val_20 != 0)
            {
                goto label_16;
            }
            // 0x00BD4EB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BD4EB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BD4EBC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BD4EC0: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4EC4: BL #0xb92a6c               | X0 = val_20.Validate(atlas:  val_19);   
            bool val_15 = val_20.Validate(atlas:  val_19);
            // 0x00BD4EC8: MOV w20, w0                | W20 = val_15;//m1                       
            // 0x00BD4ECC: CBZ x19, #0xbd4ee0         | if (val_2 == 0) goto label_17;          
            if(val_2 == 0)
            {
                goto label_17;
            }
            // 0x00BD4ED0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4ED4: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BD4ED8: AND w20, w20, #1           | W20 = (val_15 & 1);                     
            val_21 = val_15;
            // 0x00BD4EDC: B #0xbd4ef4                |  goto label_18;                         
            goto label_18;
            label_17:
            // 0x00BD4EE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            // 0x00BD4EE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4EE8: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BD4EEC: AND w20, w20, #1           | W20 = (val_15 & 1);                     
            val_21 = val_15;
            // 0x00BD4EF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_18:
            // 0x00BD4EF4: STR w20, [x19, #4]         | mem2[0] = (val_15 & 1);                  //  dest_result_addr=0
            mem2[0] = val_21;
            // 0x00BD4EF8: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BD4EFC: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_22 = 8;
            // 0x00BD4F00: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BD4F04: TBZ w9, #0, #0xbd4f14      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_19;
            // 0x00BD4F08: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BD4F0C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BD4F10: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_22 = 219381744;
            label_19:
            // 0x00BD4F14: ADD x0, x8, x19            | X0 = (val_22 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_16 = val_22 + val_2;
            // 0x00BD4F18: SUB sp, x29, #0x50         | SP = (1152921510069758000 - 80) = 1152921510069757920 (0x10000001459D67E0);
            // 0x00BD4F1C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD4F20: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD4F24: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BD4F28: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BD4F2C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BD4F30: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BD4F34: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_22 + val_2);
            return val_16;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BD4F38: MOV x19, x0                | 
            // 0x00BD4F3C: MOV x0, sp                 | 
            // 0x00BD4F40: B #0xbd4f4c                | 
            // 0x00BD4F44: MOV x19, x0                | 
            // 0x00BD4F48: ADD x0, sp, #8             | 
            label_20:
            // 0x00BD4F4C: BL #0x299a140              | 
            // 0x00BD4F50: MOV x0, x19                | 
            // 0x00BD4F54: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD4F58 (12406616), len: 288  VirtAddr: 0x00BD4F58 RVA: 0x00BD4F58 token: 100663920 methodIndex: 29965 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_sequence_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD4F58: STP x20, x19, [sp, #-0x20]! | stack[1152921510069914960] = ???;  stack[1152921510069914968] = ???;  //  dest_result_addr=1152921510069914960 |  dest_result_addr=1152921510069914968
            // 0x00BD4F5C: STP x29, x30, [sp, #0x10]  | stack[1152921510069914976] = ???;  stack[1152921510069914984] = ???;  //  dest_result_addr=1152921510069914976 |  dest_result_addr=1152921510069914984
            // 0x00BD4F60: ADD x29, sp, #0x10         | X29 = (1152921510069914960 + 16) = 1152921510069914976 (0x10000001459FCD60);
            // 0x00BD4F64: SUB sp, sp, #0x10          | SP = (1152921510069914960 - 16) = 1152921510069914944 (0x10000001459FCD40);
            // 0x00BD4F68: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD4F6C: LDRB w8, [x20, #0xbf4]     | W8 = (bool)static_value_03733BF4;       
            // 0x00BD4F70: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD4F74: TBNZ w8, #0, #0xbd4f90     | if (static_value_03733BF4 == true) goto label_0;
            // 0x00BD4F78: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00BD4F7C: LDR x8, [x8, #0xd88]       | X8 = 0x2B8F7E8;                         
            // 0x00BD4F80: LDR w0, [x8]               | W0 = 0x14BE;                            
            // 0x00BD4F84: BL #0x2782188              | X0 = sub_2782188( ?? 0x14BE, ????);     
            // 0x00BD4F88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD4F8C: STRB w8, [x20, #0xbf4]     | static_value_03733BF4 = true;            //  dest_result_addr=57883636
            label_0:
            // 0x00BD4F90: ADRP x20, #0x35c0000       | X20 = 56360960 (0x35C0000);             
            // 0x00BD4F94: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD4F98: LDR x20, [x20, #0x610]     | X20 = 1152921504876015616;              
            // 0x00BD4F9C: CBZ x19, #0xbd4ff0         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD4FA0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD4FA4: LDR x1, [x20]              | X1 = typeof(BMSymbol);                  
            // 0x00BD4FA8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD4FAC: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD4FB0: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD4FB4: B.LO #0xbd4fcc             | if (X1 + 260 < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD4FB8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD4FBC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD4FC0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD4FC4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD4FC8: B.EQ #0xbd4ff4             | if ((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD4FCC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD4FD0: MOV x8, sp                 | X8 = 1152921510069914944 (0x10000001459FCD40);//ML01
            // 0x00BD4FD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD4FD8: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510069902992]
            // 0x00BD4FDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD4FE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD4FE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD4FE8: MOV x0, sp                 | X0 = 1152921510069914944 (0x10000001459FCD40);//ML01
            // 0x00BD4FEC: BL #0x299a140              | 
            label_1:
            // 0x00BD4FF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001459FCD40, ????);
            label_3:
            // 0x00BD4FF4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD4FF8: LDR x1, [x20]              | X1 = typeof(BMSymbol);                  
            // 0x00BD4FFC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD5000: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD5004: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD5008: B.LO #0xbd5034             | if (X1 + 260 < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD500C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD5010: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD5014: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD5018: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD501C: B.NE #0xbd5034             | if ((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD5020: LDR x0, [x19, #0x10]       | X0 = X1 + 16;                           
            // 0x00BD5024: SUB sp, x29, #0x10         | SP = (1152921510069914976 - 16) = 1152921510069914960 (0x10000001459FCD50);
            // 0x00BD5028: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD502C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5030: RET                        |  return (System.Object)X1 + 16;         
            return (object)X1 + 16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD5034: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD5038: ADD x8, sp, #8             | X8 = (1152921510069914944 + 8) = 1152921510069914952 (0x10000001459FCD48);
            // 0x00BD503C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD5040: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510069902992]
            // 0x00BD5044: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD5048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD504C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD5050: ADD x0, sp, #8             | X0 = (1152921510069914944 + 8) = 1152921510069914952 (0x10000001459FCD48);
            // 0x00BD5054: BL #0x299a140              | 
            // 0x00BD5058: MOV x19, x0                | X19 = 1152921510069914952 (0x10000001459FCD48);//ML01
            // 0x00BD505C: MOV x0, sp                 | X0 = 1152921510069914944 (0x10000001459FCD40);//ML01
            label_6:
            // 0x00BD5060: BL #0x299a140              | 
            // 0x00BD5064: MOV x0, x19                | X0 = 1152921510069914952 (0x10000001459FCD48);//ML01
            // 0x00BD5068: BL #0x980800               | X0 = sub_980800( ?? 0x10000001459FCD48, ????);
            // 0x00BD506C: MOV x19, x0                | X19 = 1152921510069914952 (0x10000001459FCD48);//ML01
            // 0x00BD5070: ADD x0, sp, #8             | X0 = (1152921510069914944 + 8) = 1152921510069914952 (0x10000001459FCD48);
            // 0x00BD5074: B #0xbd5060                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5078 (12406904), len: 392  VirtAddr: 0x00BD5078 RVA: 0x00BD5078 token: 100663921 methodIndex: 29966 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_sequence_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD5078: STP x22, x21, [sp, #-0x30]! | stack[1152921510070039072] = ???;  stack[1152921510070039080] = ???;  //  dest_result_addr=1152921510070039072 |  dest_result_addr=1152921510070039080
            // 0x00BD507C: STP x20, x19, [sp, #0x10]  | stack[1152921510070039088] = ???;  stack[1152921510070039096] = ???;  //  dest_result_addr=1152921510070039088 |  dest_result_addr=1152921510070039096
            // 0x00BD5080: STP x29, x30, [sp, #0x20]  | stack[1152921510070039104] = ???;  stack[1152921510070039112] = ???;  //  dest_result_addr=1152921510070039104 |  dest_result_addr=1152921510070039112
            // 0x00BD5084: ADD x29, sp, #0x20         | X29 = (1152921510070039072 + 32) = 1152921510070039104 (0x1000000145A1B240);
            // 0x00BD5088: SUB sp, sp, #0x20          | SP = (1152921510070039072 - 32) = 1152921510070039040 (0x1000000145A1B200);
            // 0x00BD508C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD5090: LDRB w8, [x21, #0xbf5]     | W8 = (bool)static_value_03733BF5;       
            // 0x00BD5094: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD5098: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD509C: TBNZ w8, #0, #0xbd50b8     | if (static_value_03733BF5 == true) goto label_0;
            // 0x00BD50A0: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00BD50A4: LDR x8, [x8, #0x878]       | X8 = 0x2B8F800;                         
            // 0x00BD50A8: LDR w0, [x8]               | W0 = 0x14C4;                            
            // 0x00BD50AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C4, ????);     
            // 0x00BD50B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD50B4: STRB w8, [x21, #0xbf5]     | static_value_03733BF5 = true;            //  dest_result_addr=57883637
            label_0:
            // 0x00BD50B8: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BD50BC: CBZ x20, #0xbd5170         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD50C0: ADRP x21, #0x35c0000       | X21 = 56360960 (0x35C0000);             
            // 0x00BD50C4: LDR x21, [x21, #0x610]     | X21 = 1152921504876015616;              
            val_6 = 1152921504876015616;
            // 0x00BD50C8: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BD50CC: LDR x1, [x21]              | X1 = typeof(BMSymbol);                  
            // 0x00BD50D0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD50D4: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD50D8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD50DC: B.LO #0xbd50f4             | if (mem[null + 260] < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD50E0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD50E4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD50E8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD50EC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD50F0: B.EQ #0xbd511c             | if ((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD50F4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD50F8: ADD x8, sp, #8             | X8 = (1152921510070039040 + 8) = 1152921510070039048 (0x1000000145A1B208);
            // 0x00BD50FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD5100: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510070027120]
            // 0x00BD5104: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD5108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD510C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD5110: ADD x0, sp, #8             | X0 = (1152921510070039040 + 8) = 1152921510070039048 (0x1000000145A1B208);
            // 0x00BD5114: BL #0x299a140              | 
            // 0x00BD5118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145A1B208, ????);
            label_3:
            // 0x00BD511C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BD5120: LDR x1, [x21]              | X1 = typeof(BMSymbol);                  
            // 0x00BD5124: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD5128: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD512C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD5130: B.LO #0xbd5148             | if (mem[null + 260] < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD5134: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD5138: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD513C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD5140: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD5144: B.EQ #0xbd5178             | if ((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD5148: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD514C: ADD x8, sp, #0x10          | X8 = (1152921510070039040 + 16) = 1152921510070039056 (0x1000000145A1B210);
            // 0x00BD5150: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD5154: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510070027120]
            // 0x00BD5158: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD515C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5160: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD5164: ADD x0, sp, #0x10          | X0 = (1152921510070039040 + 16) = 1152921510070039056 (0x1000000145A1B210);
            // 0x00BD5168: BL #0x299a140              | 
            // 0x00BD516C: B #0xbd5174                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD5170: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14C4, ????);     
            label_6:
            // 0x00BD5174: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x00BD5178: CBZ x19, #0xbd51b8         | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x00BD517C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BD5180: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BD5184: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BD5188: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD518C: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x00BD5190: B.EQ #0xbd51bc             | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x00BD5194: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD5198: ADD x8, sp, #0x18          | X8 = (1152921510070039040 + 24) = 1152921510070039064 (0x1000000145A1B218);
            // 0x00BD519C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BD51A0: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510070027120]
            // 0x00BD51A4: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD51A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD51AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD51B0: ADD x0, sp, #0x18          | X0 = (1152921510070039040 + 24) = 1152921510070039064 (0x1000000145A1B218);
            // 0x00BD51B4: BL #0x299a140              | 
            label_7:
            // 0x00BD51B8: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x00BD51BC: STR x19, [x20, #0x10]      | mem[16] = 0x0;                           //  dest_result_addr=16
            mem[16] = val_7;
            // 0x00BD51C0: SUB sp, x29, #0x20         | SP = (1152921510070039104 - 32) = 1152921510070039072 (0x1000000145A1B220);
            // 0x00BD51C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD51C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD51CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD51D0: RET                        |  return;                                
            return;
            // 0x00BD51D4: MOV x19, x0                | 
            // 0x00BD51D8: ADD x0, sp, #8             | 
            // 0x00BD51DC: B #0xbd51f4                | 
            // 0x00BD51E0: MOV x19, x0                | 
            // 0x00BD51E4: ADD x0, sp, #0x10          | 
            // 0x00BD51E8: B #0xbd51f4                | 
            // 0x00BD51EC: MOV x19, x0                | 
            // 0x00BD51F0: ADD x0, sp, #0x18          | 
            label_10:
            // 0x00BD51F4: BL #0x299a140              | 
            // 0x00BD51F8: MOV x0, x19                | 
            // 0x00BD51FC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5200 (12407296), len: 288  VirtAddr: 0x00BD5200 RVA: 0x00BD5200 token: 100663922 methodIndex: 29967 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_spriteName_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BD5200: STP x20, x19, [sp, #-0x20]! | stack[1152921510070163216] = ???;  stack[1152921510070163224] = ???;  //  dest_result_addr=1152921510070163216 |  dest_result_addr=1152921510070163224
            // 0x00BD5204: STP x29, x30, [sp, #0x10]  | stack[1152921510070163232] = ???;  stack[1152921510070163240] = ???;  //  dest_result_addr=1152921510070163232 |  dest_result_addr=1152921510070163240
            // 0x00BD5208: ADD x29, sp, #0x10         | X29 = (1152921510070163216 + 16) = 1152921510070163232 (0x1000000145A39720);
            // 0x00BD520C: SUB sp, sp, #0x10          | SP = (1152921510070163216 - 16) = 1152921510070163200 (0x1000000145A39700);
            // 0x00BD5210: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD5214: LDRB w8, [x20, #0xbf6]     | W8 = (bool)static_value_03733BF6;       
            // 0x00BD5218: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BD521C: TBNZ w8, #0, #0xbd5238     | if (static_value_03733BF6 == true) goto label_0;
            // 0x00BD5220: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00BD5224: LDR x8, [x8, #0x130]       | X8 = 0x2B8F7EC;                         
            // 0x00BD5228: LDR w0, [x8]               | W0 = 0x14BF;                            
            // 0x00BD522C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14BF, ????);     
            // 0x00BD5230: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5234: STRB w8, [x20, #0xbf6]     | static_value_03733BF6 = true;            //  dest_result_addr=57883638
            label_0:
            // 0x00BD5238: ADRP x20, #0x35c0000       | X20 = 56360960 (0x35C0000);             
            // 0x00BD523C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BD5240: LDR x20, [x20, #0x610]     | X20 = 1152921504876015616;              
            // 0x00BD5244: CBZ x19, #0xbd5298         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BD5248: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD524C: LDR x1, [x20]              | X1 = typeof(BMSymbol);                  
            // 0x00BD5250: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD5254: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD5258: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD525C: B.LO #0xbd5274             | if (X1 + 260 < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD5260: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD5264: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD5268: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD526C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD5270: B.EQ #0xbd529c             | if ((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD5274: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD5278: MOV x8, sp                 | X8 = 1152921510070163200 (0x1000000145A39700);//ML01
            // 0x00BD527C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD5280: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510070151248]
            // 0x00BD5284: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD5288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD528C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD5290: MOV x0, sp                 | X0 = 1152921510070163200 (0x1000000145A39700);//ML01
            // 0x00BD5294: BL #0x299a140              | 
            label_1:
            // 0x00BD5298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145A39700, ????);
            label_3:
            // 0x00BD529C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BD52A0: LDR x1, [x20]              | X1 = typeof(BMSymbol);                  
            // 0x00BD52A4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BD52A8: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD52AC: CMP w10, w9                | STATE = COMPARE(X1 + 260, BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD52B0: B.LO #0xbd52dc             | if (X1 + 260 < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BD52B4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BD52B8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD52BC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD52C0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD52C4: B.NE #0xbd52dc             | if ((X1 + 176 + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BD52C8: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x00BD52CC: SUB sp, x29, #0x10         | SP = (1152921510070163232 - 16) = 1152921510070163216 (0x1000000145A39710);
            // 0x00BD52D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD52D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD52D8: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BD52DC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BD52E0: ADD x8, sp, #8             | X8 = (1152921510070163200 + 8) = 1152921510070163208 (0x1000000145A39708);
            // 0x00BD52E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BD52E8: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510070151248]
            // 0x00BD52EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD52F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD52F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD52F8: ADD x0, sp, #8             | X0 = (1152921510070163200 + 8) = 1152921510070163208 (0x1000000145A39708);
            // 0x00BD52FC: BL #0x299a140              | 
            // 0x00BD5300: MOV x19, x0                | X19 = 1152921510070163208 (0x1000000145A39708);//ML01
            // 0x00BD5304: MOV x0, sp                 | X0 = 1152921510070163200 (0x1000000145A39700);//ML01
            label_6:
            // 0x00BD5308: BL #0x299a140              | 
            // 0x00BD530C: MOV x0, x19                | X0 = 1152921510070163208 (0x1000000145A39708);//ML01
            // 0x00BD5310: BL #0x980800               | X0 = sub_980800( ?? 0x1000000145A39708, ????);
            // 0x00BD5314: MOV x19, x0                | X19 = 1152921510070163208 (0x1000000145A39708);//ML01
            // 0x00BD5318: ADD x0, sp, #8             | X0 = (1152921510070163200 + 8) = 1152921510070163208 (0x1000000145A39708);
            // 0x00BD531C: B #0xbd5308                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD5320 (12407584), len: 392  VirtAddr: 0x00BD5320 RVA: 0x00BD5320 token: 100663923 methodIndex: 29968 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_spriteName_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BD5320: STP x22, x21, [sp, #-0x30]! | stack[1152921510070287328] = ???;  stack[1152921510070287336] = ???;  //  dest_result_addr=1152921510070287328 |  dest_result_addr=1152921510070287336
            // 0x00BD5324: STP x20, x19, [sp, #0x10]  | stack[1152921510070287344] = ???;  stack[1152921510070287352] = ???;  //  dest_result_addr=1152921510070287344 |  dest_result_addr=1152921510070287352
            // 0x00BD5328: STP x29, x30, [sp, #0x20]  | stack[1152921510070287360] = ???;  stack[1152921510070287368] = ???;  //  dest_result_addr=1152921510070287360 |  dest_result_addr=1152921510070287368
            // 0x00BD532C: ADD x29, sp, #0x20         | X29 = (1152921510070287328 + 32) = 1152921510070287360 (0x1000000145A57C00);
            // 0x00BD5330: SUB sp, sp, #0x20          | SP = (1152921510070287328 - 32) = 1152921510070287296 (0x1000000145A57BC0);
            // 0x00BD5334: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BD5338: LDRB w8, [x21, #0xbf7]     | W8 = (bool)static_value_03733BF7;       
            // 0x00BD533C: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BD5340: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BD5344: TBNZ w8, #0, #0xbd5360     | if (static_value_03733BF7 == true) goto label_0;
            // 0x00BD5348: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00BD534C: LDR x8, [x8, #0xd70]       | X8 = 0x2B8F804;                         
            // 0x00BD5350: LDR w0, [x8]               | W0 = 0x14C5;                            
            // 0x00BD5354: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C5, ????);     
            // 0x00BD5358: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD535C: STRB w8, [x21, #0xbf7]     | static_value_03733BF7 = true;            //  dest_result_addr=57883639
            label_0:
            // 0x00BD5360: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BD5364: CBZ x20, #0xbd5418         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BD5368: ADRP x21, #0x35c0000       | X21 = 56360960 (0x35C0000);             
            // 0x00BD536C: LDR x21, [x21, #0x610]     | X21 = 1152921504876015616;              
            val_6 = 1152921504876015616;
            // 0x00BD5370: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BD5374: LDR x1, [x21]              | X1 = typeof(BMSymbol);                  
            // 0x00BD5378: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD537C: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD5380: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD5384: B.LO #0xbd539c             | if (mem[null + 260] < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BD5388: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD538C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD5390: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD5394: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD5398: B.EQ #0xbd53c4             | if ((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BD539C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD53A0: ADD x8, sp, #8             | X8 = (1152921510070287296 + 8) = 1152921510070287304 (0x1000000145A57BC8);
            // 0x00BD53A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD53A8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510070275376]
            // 0x00BD53AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BD53B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD53B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BD53B8: ADD x0, sp, #8             | X0 = (1152921510070287296 + 8) = 1152921510070287304 (0x1000000145A57BC8);
            // 0x00BD53BC: BL #0x299a140              | 
            // 0x00BD53C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145A57BC8, ????);
            label_3:
            // 0x00BD53C4: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BD53C8: LDR x1, [x21]              | X1 = typeof(BMSymbol);                  
            // 0x00BD53CC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BD53D0: LDRB w9, [x1, #0x104]      | W9 = BMSymbol.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BD53D4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], BMSymbol.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BD53D8: B.LO #0xbd53f0             | if (mem[null + 260] < BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BD53DC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BD53E0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BD53E4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BD53E8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(BMSymbol))
            // 0x00BD53EC: B.EQ #0xbd5420             | if ((mem[null + 176] + (BMSymbol.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BD53F0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BD53F4: ADD x8, sp, #0x10          | X8 = (1152921510070287296 + 16) = 1152921510070287312 (0x1000000145A57BD0);
            // 0x00BD53F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BD53FC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510070275376]
            // 0x00BD5400: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BD5404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5408: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BD540C: ADD x0, sp, #0x10          | X0 = (1152921510070287296 + 16) = 1152921510070287312 (0x1000000145A57BD0);
            // 0x00BD5410: BL #0x299a140              | 
            // 0x00BD5414: B #0xbd541c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BD5418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14C5, ????);     
            label_6:
            // 0x00BD541C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x00BD5420: CBZ x19, #0xbd5460         | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x00BD5424: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BD5428: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BD542C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BD5430: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BD5434: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x00BD5438: B.EQ #0xbd5464             | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x00BD543C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BD5440: ADD x8, sp, #0x18          | X8 = (1152921510070287296 + 24) = 1152921510070287320 (0x1000000145A57BD8);
            // 0x00BD5444: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BD5448: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510070275376]
            // 0x00BD544C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BD5450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD5454: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BD5458: ADD x0, sp, #0x18          | X0 = (1152921510070287296 + 24) = 1152921510070287320 (0x1000000145A57BD8);
            // 0x00BD545C: BL #0x299a140              | 
            label_7:
            // 0x00BD5460: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x00BD5464: STR x19, [x20, #0x18]      | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_7;
            // 0x00BD5468: SUB sp, x29, #0x20         | SP = (1152921510070287360 - 32) = 1152921510070287328 (0x1000000145A57BE0);
            // 0x00BD546C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5470: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5474: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD5478: RET                        |  return;                                
            return;
            // 0x00BD547C: MOV x19, x0                | 
            // 0x00BD5480: ADD x0, sp, #8             | 
            // 0x00BD5484: B #0xbd549c                | 
            // 0x00BD5488: MOV x19, x0                | 
            // 0x00BD548C: ADD x0, sp, #0x10          | 
            // 0x00BD5490: B #0xbd549c                | 
            // 0x00BD5494: MOV x19, x0                | 
            // 0x00BD5498: ADD x0, sp, #0x18          | 
            label_10:
            // 0x00BD549C: BL #0x299a140              | 
            // 0x00BD54A0: MOV x0, x19                | 
            // 0x00BD54A4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD54A8 (12407976), len: 180  VirtAddr: 0x00BD54A8 RVA: 0x00BD54A8 token: 100663924 methodIndex: 29969 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BD54A8: STP x22, x21, [sp, #-0x30]! | stack[1152921510070423824] = ???;  stack[1152921510070423832] = ???;  //  dest_result_addr=1152921510070423824 |  dest_result_addr=1152921510070423832
            // 0x00BD54AC: STP x20, x19, [sp, #0x10]  | stack[1152921510070423840] = ???;  stack[1152921510070423848] = ???;  //  dest_result_addr=1152921510070423840 |  dest_result_addr=1152921510070423848
            // 0x00BD54B0: STP x29, x30, [sp, #0x20]  | stack[1152921510070423856] = ???;  stack[1152921510070423864] = ???;  //  dest_result_addr=1152921510070423856 |  dest_result_addr=1152921510070423864
            // 0x00BD54B4: ADD x29, sp, #0x20         | X29 = (1152921510070423824 + 32) = 1152921510070423856 (0x1000000145A79130);
            // 0x00BD54B8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BD54BC: LDRB w8, [x22, #0xbf8]     | W8 = (bool)static_value_03733BF8;       
            // 0x00BD54C0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BD54C4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BD54C8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BD54CC: TBNZ w8, #0, #0xbd54e8     | if (static_value_03733BF8 == true) goto label_0;
            // 0x00BD54D0: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x00BD54D4: LDR x8, [x8, #0x340]       | X8 = 0x2B8F7D0;                         
            // 0x00BD54D8: LDR w0, [x8]               | W0 = 0x14B8;                            
            // 0x00BD54DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B8, ????);     
            // 0x00BD54E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD54E4: STRB w8, [x22, #0xbf8]     | static_value_03733BF8 = true;            //  dest_result_addr=57883640
            label_0:
            // 0x00BD54E8: CBNZ x21, #0xbd54f0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BD54EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14B8, ????);     
            label_1:
            // 0x00BD54F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD54F4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BD54F8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BD54FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD5500: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BD5504: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BD5508: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BD550C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BD5510: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00BD5514: LDR x8, [x8, #0x610]       | X8 = 1152921504876015616;               
            // 0x00BD5518: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BD551C: LDR x8, [x8]               | X8 = typeof(BMSymbol);                  
            // 0x00BD5520: MOV x0, x8                 | X0 = 1152921504876015616 (0x10000000100B3000);//ML01
            BMSymbol val_3 = null;
            // 0x00BD5524: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMSymbol), ????);
            // 0x00BD5528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD552C: MOV x21, x0                | X21 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD5530: BL #0xb929e8               | .ctor();                                
            val_3 = new BMSymbol();
            // 0x00BD5534: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BD5538: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BD553C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5540: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5544: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BD5548: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BD554C: MOV x3, x21                | X3 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD5550: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BD5554: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BD5558: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD555C (12408156), len: 92  VirtAddr: 0x00BD555C RVA: 0x00BD555C token: 100663925 methodIndex: 29970 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BD555C: STP x20, x19, [sp, #-0x20]! | stack[1152921510070552224] = ???;  stack[1152921510070552232] = ???;  //  dest_result_addr=1152921510070552224 |  dest_result_addr=1152921510070552232
            // 0x00BD5560: STP x29, x30, [sp, #0x10]  | stack[1152921510070552240] = ???;  stack[1152921510070552248] = ???;  //  dest_result_addr=1152921510070552240 |  dest_result_addr=1152921510070552248
            // 0x00BD5564: ADD x29, sp, #0x10         | X29 = (1152921510070552224 + 16) = 1152921510070552240 (0x1000000145A986B0);
            // 0x00BD5568: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BD556C: LDRB w8, [x19, #0xbf9]     | W8 = (bool)static_value_03733BF9;       
            // 0x00BD5570: TBNZ w8, #0, #0xbd558c     | if (static_value_03733BF9 == true) goto label_0;
            // 0x00BD5574: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00BD5578: LDR x8, [x8, #0xe68]       | X8 = 0x2B8F808;                         
            // 0x00BD557C: LDR w0, [x8]               | W0 = 0x14C6;                            
            // 0x00BD5580: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C6, ????);     
            // 0x00BD5584: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD5588: STRB w8, [x19, #0xbf9]     | static_value_03733BF9 = true;            //  dest_result_addr=57883641
            label_0:
            // 0x00BD558C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00BD5590: LDR x8, [x8, #0x610]       | X8 = 1152921504876015616;               
            // 0x00BD5594: LDR x0, [x8]               | X0 = typeof(BMSymbol);                  
            BMSymbol val_1 = null;
            // 0x00BD5598: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMSymbol), ????);
            // 0x00BD559C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BD55A0: MOV x19, x0                | X19 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD55A4: BL #0xb929e8               | .ctor();                                
            val_1 = new BMSymbol();
            // 0x00BD55A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD55AC: MOV x0, x19                | X0 = 1152921504876015616 (0x10000000100B3000);//ML01
            // 0x00BD55B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD55B4: RET                        |  return (System.Object)typeof(BMSymbol);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BD55B8 (12408248), len: 92  VirtAddr: 0x00BD55B8 RVA: 0x00BD55B8 token: 100663926 methodIndex: 29971 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BD55B8: STP x20, x19, [sp, #-0x20]! | stack[1152921510070668320] = ???;  stack[1152921510070668328] = ???;  //  dest_result_addr=1152921510070668320 |  dest_result_addr=1152921510070668328
            // 0x00BD55BC: STP x29, x30, [sp, #0x10]  | stack[1152921510070668336] = ???;  stack[1152921510070668344] = ???;  //  dest_result_addr=1152921510070668336 |  dest_result_addr=1152921510070668344
            // 0x00BD55C0: ADD x29, sp, #0x10         | X29 = (1152921510070668320 + 16) = 1152921510070668336 (0x1000000145AB4C30);
            // 0x00BD55C4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BD55C8: LDRB w8, [x20, #0xbfa]     | W8 = (bool)static_value_03733BFA;       
            // 0x00BD55CC: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BD55D0: TBNZ w8, #0, #0xbd55ec     | if (static_value_03733BFA == true) goto label_0;
            // 0x00BD55D4: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BD55D8: LDR x8, [x8, #0x4d0]       | X8 = 0x2B8F80C;                         
            // 0x00BD55DC: LDR w0, [x8]               | W0 = 0x14C7;                            
            // 0x00BD55E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C7, ????);     
            // 0x00BD55E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BD55E8: STRB w8, [x20, #0xbfa]     | static_value_03733BFA = true;            //  dest_result_addr=57883642
            label_0:
            // 0x00BD55EC: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x00BD55F0: LDR x8, [x8, #0xa98]       | X8 = 1152921510070652256;               
            // 0x00BD55F4: LDR x20, [x8]              | X20 = typeof(BMSymbol[]);               
            // 0x00BD55F8: MOV x0, x20                | X0 = 1152921510070652256 (0x1000000145AB0D60);//ML01
            // 0x00BD55FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(BMSymbol[]), ????);
            // 0x00BD5600: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BD5604: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BD5608: MOV x0, x20                | X0 = 1152921510070652256 (0x1000000145AB0D60);//ML01
            // 0x00BD560C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BD5610: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(BMSymbol[]), ????);
        
        }
    
    }

}
