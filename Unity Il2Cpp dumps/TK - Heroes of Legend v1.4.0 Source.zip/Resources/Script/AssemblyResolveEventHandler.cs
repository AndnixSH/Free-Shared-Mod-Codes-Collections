using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class AssemblyResolveEventHandler : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E561E8 (15032808), len: 16  VirtAddr: 0x00E561E8 RVA: 0x00E561E8 token: 100663724 methodIndex: 19320 delegateWrapperIndex: 0 methodInvoker: 0
        public AssemblyResolveEventHandler(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x00E561E8: LDR x8, [x2]               | X8 = method;                            
            // 0x00E561EC: STP x1, x2, [x0, #0x20]    | mem[1152921509461340032] = object;  mem[1152921509461340040] = method;  //  dest_result_addr=1152921509461340032 |  dest_result_addr=1152921509461340040
            mem[1152921509461340032] = object;
            mem[1152921509461340040] = method;
            // 0x00E561F0: STR x8, [x0, #0x10]        | mem[1152921509461340016] = method;       //  dest_result_addr=1152921509461340016
            mem[1152921509461340016] = method;
            // 0x00E561F4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E561F8 (15032824), len: 968  VirtAddr: 0x00E561F8 RVA: 0x00E561F8 token: 100663725 methodIndex: 19321 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Mono.Cecil.AssemblyDefinition Invoke(object sender, ILRuntime.Mono.Cecil.AssemblyNameReference reference)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            label_1:
            // 0x00E561F8: STP x24, x23, [sp, #-0x40]! | stack[1152921509461468608] = ???;  stack[1152921509461468616] = ???;  //  dest_result_addr=1152921509461468608 |  dest_result_addr=1152921509461468616
            // 0x00E561FC: STP x22, x21, [sp, #0x10]  | stack[1152921509461468624] = ???;  stack[1152921509461468632] = ???;  //  dest_result_addr=1152921509461468624 |  dest_result_addr=1152921509461468632
            // 0x00E56200: STP x20, x19, [sp, #0x20]  | stack[1152921509461468640] = ???;  stack[1152921509461468648] = ???;  //  dest_result_addr=1152921509461468640 |  dest_result_addr=1152921509461468648
            // 0x00E56204: STP x29, x30, [sp, #0x30]  | stack[1152921509461468656] = ???;  stack[1152921509461468664] = ???;  //  dest_result_addr=1152921509461468656 |  dest_result_addr=1152921509461468664
            // 0x00E56208: ADD x29, sp, #0x30         | X29 = (1152921509461468608 + 48) = 1152921509461468656 (0x10000001215BA5F0);
            // 0x00E5620C: SUB sp, sp, #0x10          | SP = (1152921509461468608 - 16) = 1152921509461468592 (0x10000001215BA5B0);
            // 0x00E56210: MOV x23, x0                | X23 = 1152921509461480672 (0x10000001215BD4E0);//ML01
            // 0x00E56214: LDR x0, [x23, #0x58]       | 
            // 0x00E56218: MOV x19, x2                | X19 = reference;//m1                    
            // 0x00E5621C: MOV x20, x1                | X20 = sender;//m1                       
            // 0x00E56220: CBZ x0, #0xe56230          | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x00E56224: MOV x1, x20                | X1 = sender;//m1                        
            // 0x00E56228: MOV x2, x19                | X2 = reference;//m1                     
            val_13 = reference;
            // 0x00E5622C: BL #0xe561f8               |  R0 = label_1();                        
            label_0:
            // 0x00E56230: LDR x0, [x23, #0x10]       | 
            // 0x00E56234: STR x0, [sp, #8]           | stack[1152921509461468600] = this;       //  dest_result_addr=1152921509461468600
            // 0x00E56238: LDP x22, x21, [x23, #0x20] |                                          //  | 
            // 0x00E5623C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E56240: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
            // 0x00E56244: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E56248: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
            // 0x00E5624C: LDRB w9, [x21, #0x4e]      | W9 = X21 + 78;                          
            // 0x00E56250: AND w8, w0, #1             | W8 = (X21 & 1);                         
            var val_1 = X21 & 1;
            // 0x00E56254: TBZ w8, #0, #0xe562f0      | if (((X21 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x00E56258: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x00E5625C: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
            // 0x00E56260: B.NE #0xe56300             | if (X21 + 78 != 0x2) goto label_3;      
            if((X21 + 78) != 2)
            {
                goto label_3;
            }
            // 0x00E56264: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x00E56268: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
            // 0x00E5626C: B.EQ #0xe563bc             | if (X21 + 76 == 65535) goto label_7;    
            if((X21 + 76) == 65535)
            {
                goto label_7;
            }
            // 0x00E56270: CBZ x22, #0xe56280         | if (X22 == 0) goto label_5;             
            if(X22 == 0)
            {
                goto label_5;
            }
            // 0x00E56274: LDR x8, [x22]              | X8 = X22;                               
            // 0x00E56278: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
            // 0x00E5627C: TBNZ w8, #0, #0xe563bc     | if ((X22 + 237 & 0x1) != 0) goto label_7;
            if(((X22 + 237) & 1) != 0)
            {
                goto label_7;
            }
            label_5:
            // 0x00E56280: LDR x8, [x23, #0x18]       | 
            // 0x00E56284: CBZ x8, #0xe563bc          | if (X22 + 237 == 0) goto label_7;       
            if((X22 + 237) == 0)
            {
                goto label_7;
            }
            // 0x00E56288: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E5628C: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x00E56290: MOV w23, w0                | W23 = X21;//m1                          
            // 0x00E56294: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E56298: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X21.pressedSprite;
            // 0x00E5629C: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x00E562A0: TBZ w23, #0, #0xe56410     | if ((X21 & 0x1) == 0) goto label_8;     
            if((X21 & 1) == 0)
            {
                goto label_8;
            }
            // 0x00E562A4: TBZ w0, #0, #0xe564c8      | if ((val_2 & 0x1) == 0) goto label_9;   
            if((val_2 & 1) == 0)
            {
                goto label_9;
            }
            // 0x00E562A8: LDR x8, [x22]              | X8 = X22;                               
            var val_19 = X22;
            // 0x00E562AC: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x00E562B0: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x00E562B4: LDRH w9, [x8, #0x102]      | W9 = X22 + 258;                         
            // 0x00E562B8: CBZ x9, #0xe562e4          | if (X22 + 258 == 0) goto label_10;      
            if((X22 + 258) == 0)
            {
                goto label_10;
            }
            // 0x00E562BC: LDR x10, [x8, #0x98]       | X10 = X22 + 152;                        
            var val_11 = X22 + 152;
            // 0x00E562C0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x00E562C4: ADD x10, x10, #8           | X10 = (X22 + 152 + 8);                  
            val_11 = val_11 + 8;
            label_12:
            // 0x00E562C8: LDUR x12, [x10, #-8]       | X12 = (X22 + 152 + 8) + -8;             
            // 0x00E562CC: CMP x12, x1                | STATE = COMPARE((X22 + 152 + 8) + -8, X21 + 24)
            // 0x00E562D0: B.EQ #0xe56510             | if ((X22 + 152 + 8) + -8 == X21 + 24) goto label_11;
            if(((X22 + 152 + 8) + -8) == (X21 + 24))
            {
                goto label_11;
            }
            // 0x00E562D4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x00E562D8: ADD x10, x10, #0x10        | X10 = ((X22 + 152 + 8) + 16);           
            val_11 = val_11 + 16;
            // 0x00E562DC: CMP x11, x9                | STATE = COMPARE((0 + 1), X22 + 258)     
            // 0x00E562E0: B.LO #0xe562c8             | if (0 < X22 + 258) goto label_12;       
            if(val_12 < (X22 + 258))
            {
                goto label_12;
            }
            label_10:
            // 0x00E562E4: MOV x0, x22                | X0 = X22;//m1                           
            val_14 = X22;
            // 0x00E562E8: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
            // 0x00E562EC: B #0xe56520                |  goto label_13;                         
            goto label_13;
            label_2:
            // 0x00E562F0: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
            // 0x00E562F4: B.NE #0xe5638c             | if (X21 + 78 != 0x2) goto label_14;     
            if((X21 + 78) != 2)
            {
                goto label_14;
            }
            // 0x00E562F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E562FC: B #0xe563c0                |  goto label_15;                         
            goto label_15;
            label_3:
            // 0x00E56300: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x00E56304: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
            // 0x00E56308: B.EQ #0xe563e8             | if (X21 + 76 == 65535) goto label_19;   
            if((X21 + 76) == 65535)
            {
                goto label_19;
            }
            // 0x00E5630C: CBZ x22, #0xe5631c         | if (X22 == 0) goto label_17;            
            if(X22 == 0)
            {
                goto label_17;
            }
            // 0x00E56310: LDR x8, [x22]              | X8 = X22;                               
            // 0x00E56314: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
            // 0x00E56318: TBNZ w8, #0, #0xe563e8     | if ((X22 + 237 & 0x1) != 0) goto label_19;
            if(((X22 + 237) & 1) != 0)
            {
                goto label_19;
            }
            label_17:
            // 0x00E5631C: LDR x8, [x23, #0x18]       | 
            // 0x00E56320: CBZ x8, #0xe563e8          | if (X22 + 237 == 0) goto label_19;      
            if((X22 + 237) == 0)
            {
                goto label_19;
            }
            // 0x00E56324: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E56328: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x00E5632C: MOV w22, w0                | W22 = X21;//m1                          
            // 0x00E56330: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E56334: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X21.pressedSprite;
            // 0x00E56338: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
            // 0x00E5633C: TBZ w22, #0, #0xe5646c     | if ((X21 & 0x1) == 0) goto label_20;    
            if((X21 & 1) == 0)
            {
                goto label_20;
            }
            // 0x00E56340: TBZ w0, #0, #0xe564dc      | if ((val_3 & 0x1) == 0) goto label_21;  
            if((val_3 & 1) == 0)
            {
                goto label_21;
            }
            // 0x00E56344: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x00E56348: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x00E5634C: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x00E56350: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E56354: CBZ x9, #0xe56380          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x00E56358: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E5635C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x00E56360: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_24:
            // 0x00E56364: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E56368: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X21 + 24)
            // 0x00E5636C: B.EQ #0xe56548             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X21 + 24) goto label_23;
            // 0x00E56370: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x00E56374: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00E56378: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E5637C: B.LO #0xe56364             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x00E56380: MOV x0, x20                | X0 = sender;//m1                        
            val_15 = sender;
            // 0x00E56384: BL #0x2776c24              | X0 = sub_2776C24( ?? sender, ????);     
            // 0x00E56388: B #0xe56558                |  goto label_25;                         
            goto label_25;
            label_14:
            // 0x00E5638C: LDR x5, [sp, #8]           | X5 = this;                              
            // 0x00E56390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56394: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00E56398: MOV x2, x20                | X2 = sender;//m1                        
            // 0x00E5639C: MOV x3, x19                | X3 = reference;//m1                     
            // 0x00E563A0: MOV x4, x21                | X4 = X21;//m1                           
            // 0x00E563A4: SUB sp, x29, #0x30         | SP = (1152921509461468656 - 48) = 1152921509461468608 (0x10000001215BA5C0);
            // 0x00E563A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E563AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E563B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E563B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E563B8: BR x5                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x00E563BC: MOV x0, x22                | X0 = X22;//m1                           
            label_15:
            // 0x00E563C0: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x00E563C4: MOV x1, x20                | X1 = sender;//m1                        
            // 0x00E563C8: MOV x2, x19                | X2 = reference;//m1                     
            // 0x00E563CC: MOV x3, x21                | X3 = X21;//m1                           
            label_42:
            // 0x00E563D0: SUB sp, x29, #0x30         | SP = (1152921509461468656 - 48) = 1152921509461468608 (0x10000001215BA5C0);
            // 0x00E563D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E563D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E563DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E563E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E563E4: BR x4                      | X0 = this( ?? X22, ????);               
            label_19:
            // 0x00E563E8: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x00E563EC: MOV x0, x20                | X0 = sender;//m1                        
            // 0x00E563F0: MOV x1, x19                | X1 = reference;//m1                     
            // 0x00E563F4: MOV x2, x21                | X2 = X21;//m1                           
            label_43:
            // 0x00E563F8: SUB sp, x29, #0x30         | SP = (1152921509461468656 - 48) = 1152921509461468608 (0x10000001215BA5C0);
            // 0x00E563FC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E56400: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E56404: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E56408: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5640C: BR x3                      | X0 = this( ?? sender, ????);            
            label_8:
            // 0x00E56410: LDRH w23, [x21, #0x4c]     | W23 = X21 + 76;                         
            // 0x00E56414: TBZ w0, #0, #0xe564f0      | if ((val_2 & 0x1) == 0) goto label_26;  
            if((val_2 & 1) == 0)
            {
                goto label_26;
            }
            // 0x00E56418: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E5641C: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_4 = X21.pressedSprite;
            // 0x00E56420: LDR x9, [x22]              | X9 = X22;                               
            // 0x00E56424: MOV x8, x0                 | X8 = val_4;//m1                         
            // 0x00E56428: LDRH w10, [x9, #0x102]     | W10 = X22 + 258;                        
            // 0x00E5642C: CBZ x10, #0xe56458         | if (X22 + 258 == 0) goto label_27;      
            if((X22 + 258) == 0)
            {
                goto label_27;
            }
            // 0x00E56430: LDR x11, [x9, #0x98]       | X11 = X22 + 152;                        
            var val_14 = X22 + 152;
            // 0x00E56434: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x00E56438: ADD x11, x11, #8           | X11 = (X22 + 152 + 8);                  
            val_14 = val_14 + 8;
            label_29:
            // 0x00E5643C: LDUR x13, [x11, #-8]       | X13 = (X22 + 152 + 8) + -8;             
            // 0x00E56440: CMP x13, x8                | STATE = COMPARE((X22 + 152 + 8) + -8, val_4)
            // 0x00E56444: B.EQ #0xe5657c             | if ((X22 + 152 + 8) + -8 == val_4) goto label_28;
            if(((X22 + 152 + 8) + -8) == val_4)
            {
                goto label_28;
            }
            // 0x00E56448: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x00E5644C: ADD x11, x11, #0x10        | X11 = ((X22 + 152 + 8) + 16);           
            val_14 = val_14 + 16;
            // 0x00E56450: CMP x12, x10               | STATE = COMPARE((0 + 1), X22 + 258)     
            // 0x00E56454: B.LO #0xe5643c             | if (0 < X22 + 258) goto label_29;       
            if(val_15 < (X22 + 258))
            {
                goto label_29;
            }
            label_27:
            // 0x00E56458: MOV x0, x22                | X0 = X22;//m1                           
            val_16 = X22;
            // 0x00E5645C: MOV x1, x8                 | X1 = val_4;//m1                         
            // 0x00E56460: MOV w2, w23                | W2 = X21 + 76;//m1                      
            // 0x00E56464: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
            // 0x00E56468: B #0xe5658c                |  goto label_30;                         
            goto label_30;
            label_20:
            // 0x00E5646C: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
            // 0x00E56470: TBZ w0, #0, #0xe56500      | if ((val_3 & 0x1) == 0) goto label_31;  
            if((val_3 & 1) == 0)
            {
                goto label_31;
            }
            // 0x00E56474: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00E56478: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_5 = X21.pressedSprite;
            // 0x00E5647C: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x00E56480: MOV x8, x0                 | X8 = val_5;//m1                         
            // 0x00E56484: LDRH w10, [x9, #0x102]     | W10 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E56488: CBZ x10, #0xe564b4         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
            // 0x00E5648C: LDR x11, [x9, #0x98]       | X11 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E56490: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_16 = 0;
            // 0x00E56494: ADD x11, x11, #8           | X11 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_34:
            // 0x00E56498: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E5649C: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_5)
            // 0x00E564A0: B.EQ #0xe565a0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_5) goto label_33;
            // 0x00E564A4: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x00E564A8: ADD x11, x11, #0x10        | X11 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00E564AC: CMP x12, x10               | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E564B0: B.LO #0xe56498             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_34;
            label_32:
            // 0x00E564B4: MOV x0, x20                | X0 = sender;//m1                        
            val_17 = sender;
            // 0x00E564B8: MOV x1, x8                 | X1 = val_5;//m1                         
            // 0x00E564BC: MOV w2, w22                | W2 = X21 + 76;//m1                      
            val_13 = X21 + 76;
            // 0x00E564C0: BL #0x2776c24              | X0 = sub_2776C24( ?? sender, ????);     
            // 0x00E564C4: B #0xe565b0                |  goto label_35;                         
            goto label_35;
            label_9:
            // 0x00E564C8: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x00E564CC: LDR x9, [x22]              | X9 = X22;                               
            // 0x00E564D0: ADD x8, x9, x8, lsl #4     | X8 = (X22 + (X21 + 76) << 4);           
            var val_6 = X22 + ((X21 + 76) << 4);
            // 0x00E564D4: LDR x0, [x8, #0x118]       | X0 = (X22 + (X21 + 76) << 4) + 280;     
            val_18 = mem[(X22 + (X21 + 76) << 4) + 280];
            val_18 = (X22 + (X21 + 76) << 4) + 280;
            // 0x00E564D8: B #0xe56524                |  goto label_36;                         
            goto label_36;
            label_21:
            // 0x00E564DC: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x00E564E0: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x00E564E4: ADD x8, x9, x8, lsl #4     | X8 = (1152921504606900224 + (X21 + 76) << 4);
            object val_7 = 1152921504606900224 + ((X21 + 76) << 4);
            // 0x00E564E8: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
            val_19 = mem[(1152921504606900224 + (X21 + 76) << 4) + 280];
            // 0x00E564EC: B #0xe5655c                |  goto label_37;                         
            goto label_37;
            label_26:
            // 0x00E564F0: LDR x8, [x22]              | X8 = X22;                               
            var val_17 = X22;
            // 0x00E564F4: ADD x8, x8, w23, uxtw #4   | X8 = (X22 + X21 + 76);                  
            val_17 = val_17 + (X21 + 76);
            // 0x00E564F8: LDP x4, x3, [x8, #0x110]   | X4 = (X22 + X21 + 76) + 272; X3 = (X22 + X21 + 76) + 272 + 8; //  | 
            // 0x00E564FC: B #0xe56590                |  goto label_38;                         
            goto label_38;
            label_31:
            // 0x00E56500: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x00E56504: ADD x8, x8, w22, uxtw #4   | X8 = (1152921504606900224 + X21 + 76);  
            object val_8 = 1152921504606900224 + (X21 + 76);
            // 0x00E56508: LDP x3, x2, [x8, #0x110]   |                                          //  not_find_field!1:272 |  not_find_field!1:280
            // 0x00E5650C: B #0xe565b4                |  goto label_39;                         
            goto label_39;
            label_11:
            // 0x00E56510: LDR w9, [x10]              | W9 = (X22 + 152 + 8);                   
            var val_18 = val_11;
            // 0x00E56514: ADD w9, w9, w2             | W9 = ((X22 + 152 + 8) + X21 + 76);      
            val_18 = val_18 + (X21 + 76);
            // 0x00E56518: ADD x8, x8, w9, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
            val_19 = val_19 + val_18;
            // 0x00E5651C: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
            val_14 = val_19 + 272;
            label_13:
            // 0x00E56520: LDR x0, [x0, #8]           | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            val_18 = mem[((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8];
            val_18 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            label_36:
            // 0x00E56524: MOV x1, x21                | X1 = X21;//m1                           
            // 0x00E56528: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
            // 0x00E5652C: MOV x8, x0                 | X8 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x00E56530: LDR x4, [x8]               | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            // 0x00E56534: MOV x0, x22                | X0 = X22;//m1                           
            // 0x00E56538: MOV x1, x20                | X1 = sender;//m1                        
            // 0x00E5653C: MOV x2, x19                | X2 = reference;//m1                     
            // 0x00E56540: MOV x3, x8                 | X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x00E56544: B #0xe563d0                |  goto label_42;                         
            goto label_42;
            label_23:
            // 0x00E56548: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E5654C: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
            // 0x00E56550: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
            // 0x00E56554: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
            label_25:
            // 0x00E56558: LDR x0, [x0, #8]           | 
            label_37:
            // 0x00E5655C: MOV x1, x21                | X1 = X21;//m1                           
            // 0x00E56560: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_3, ????);      
            // 0x00E56564: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x00E56568: LDR x3, [x8]               | X3 = typeof(UnityEngine.Sprite);        
            // 0x00E5656C: MOV x0, x20                | X0 = sender;//m1                        
            // 0x00E56570: MOV x1, x19                | X1 = reference;//m1                     
            // 0x00E56574: MOV x2, x8                 | X2 = val_3;//m1                         
            // 0x00E56578: B #0xe563f8                |  goto label_43;                         
            goto label_43;
            label_28:
            // 0x00E5657C: LDR w8, [x11]              | W8 = (X22 + 152 + 8);                   
            var val_20 = val_14;
            // 0x00E56580: ADD w8, w8, w23            | W8 = ((X22 + 152 + 8) + X21 + 76);      
            val_20 = val_20 + (X21 + 76);
            // 0x00E56584: ADD x8, x9, w8, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
            val_20 = X22 + val_20;
            // 0x00E56588: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
            val_16 = val_20 + 272;
            label_30:
            // 0x00E5658C: LDP x4, x3, [x0]           | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272); X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
            label_38:
            // 0x00E56590: MOV x0, x22                | X0 = X22;//m1                           
            // 0x00E56594: MOV x1, x20                | X1 = sender;//m1                        
            // 0x00E56598: MOV x2, x19                | X2 = reference;//m1                     
            // 0x00E5659C: B #0xe563d0                |  goto label_42;                         
            goto label_42;
            label_33:
            // 0x00E565A0: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E565A4: ADD w8, w8, w22            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
            // 0x00E565A8: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
            // 0x00E565AC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
            label_35:
            // 0x00E565B0: LDP x3, x2, [x0]           | X3 = typeof(UnityEngine.Sprite);         //  | 
            label_39:
            // 0x00E565B4: MOV x0, x20                | X0 = sender;//m1                        
            // 0x00E565B8: MOV x1, x19                | X1 = reference;//m1                     
            // 0x00E565BC: B #0xe563f8                |  goto label_43;                         
            goto label_43;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E565C0 (15033792), len: 52  VirtAddr: 0x00E565C0 RVA: 0x00E565C0 token: 100663726 methodIndex: 19322 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(object sender, ILRuntime.Mono.Cecil.AssemblyNameReference reference, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x00E565C0: STP x29, x30, [sp, #-0x10]! | stack[1152921509461621616] = ???;  stack[1152921509461621624] = ???;  //  dest_result_addr=1152921509461621616 |  dest_result_addr=1152921509461621624
            // 0x00E565C4: MOV x29, sp                | X29 = 1152921509461621616 (0x10000001215DFB70);//ML01
            // 0x00E565C8: SUB sp, sp, #0x20          | SP = (1152921509461621616 - 32) = 1152921509461621584 (0x10000001215DFB50);
            // 0x00E565CC: STP xzr, xzr, [sp, #0x10]  | stack[1152921509461621600] = 0x0;  stack[1152921509461621608] = 0x0;  //  dest_result_addr=1152921509461621600 |  dest_result_addr=1152921509461621608
            // 0x00E565D0: STP xzr, x2, [sp, #8]      | stack[1152921509461621592] = 0x0;  stack[1152921509461621600] = reference;  //  dest_result_addr=1152921509461621592 |  dest_result_addr=1152921509461621600
            // 0x00E565D4: STR x1, [sp, #8]           | stack[1152921509461621592] = sender;     //  dest_result_addr=1152921509461621592
            // 0x00E565D8: ADD x1, sp, #8             | X1 = (1152921509461621584 + 8) = 1152921509461621592 (0x10000001215DFB58);
            // 0x00E565DC: MOV x2, x3                 | X2 = callback;//m1                      
            // 0x00E565E0: MOV x3, x4                 | X3 = object;//m1                        
            // 0x00E565E4: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x00E565E8: MOV sp, x29                | SP = 1152921509461621616 (0x10000001215DFB70);//ML01
            // 0x00E565EC: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00E565F0: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E565F4 (15033844), len: 16  VirtAddr: 0x00E565F4 RVA: 0x00E565F4 token: 100663727 methodIndex: 19323 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Mono.Cecil.AssemblyDefinition EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x00E565F4: MOV x8, x1                 | X8 = result;//m1                        
            // 0x00E565F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E565FC: MOV x0, x8                 | X0 = result;//m1                        
            // 0x00E56600: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
        
        }
    
    }

}
