using UnityEngine;
public class AssetShaderList : MonoBehaviour
{
    // Fields
    public UnityEngine.Shader[] goList; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B34744 (11749188), len: 108  VirtAddr: 0x00B34744 RVA: 0x00B34744 token: 100696531 methodIndex: 24955 delegateWrapperIndex: 0 methodInvoker: 0
    public AssetShaderList()
    {
        //
        // Disasemble & Code
        // 0x00B34744: STP x20, x19, [sp, #-0x20]! | stack[1152921515546598544] = ???;  stack[1152921515546598552] = ???;  //  dest_result_addr=1152921515546598544 |  dest_result_addr=1152921515546598552
        // 0x00B34748: STP x29, x30, [sp, #0x10]  | stack[1152921515546598560] = ???;  stack[1152921515546598568] = ???;  //  dest_result_addr=1152921515546598560 |  dest_result_addr=1152921515546598568
        // 0x00B3474C: ADD x29, sp, #0x10         | X29 = (1152921515546598544 + 16) = 1152921515546598560 (0x100000028C0F5CA0);
        // 0x00B34750: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B34754: LDRB w8, [x20, #0x7a3]     | W8 = (bool)static_value_037337A3;       
        // 0x00B34758: MOV x19, x0                | X19 = 1152921515546610576 (0x100000028C0F8B90);//ML01
        // 0x00B3475C: TBNZ w8, #0, #0xb34778     | if (static_value_037337A3 == true) goto label_0;
        // 0x00B34760: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00B34764: LDR x8, [x8, #0xb88]       | X8 = 0x2B8EBB8;                         
        // 0x00B34768: LDR w0, [x8]               | W0 = 0x11AE;                            
        // 0x00B3476C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11AE, ????);     
        // 0x00B34770: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B34774: STRB w8, [x20, #0x7a3]     | static_value_037337A3 = true;            //  dest_result_addr=57882531
        label_0:
        // 0x00B34778: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
        // 0x00B3477C: LDR x8, [x8, #0x8f0]       | X8 = 1152921515546582480;               
        // 0x00B34780: LDR x20, [x8]              | X20 = typeof(UnityEngine.Shader[]);     
        // 0x00B34784: MOV x0, x20                | X0 = 1152921515546582480 (0x100000028C0F1DD0);//ML01
        // 0x00B34788: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Shader[]), ????);
        // 0x00B3478C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34790: MOV x0, x20                | X0 = 1152921515546582480 (0x100000028C0F1DD0);//ML01
        // 0x00B34794: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Shader[]), ????);
        // 0x00B34798: STR x0, [x19, #0x18]       | this.goList = typeof(UnityEngine.Shader[]);  //  dest_result_addr=1152921515546610600
        this.goList = null;
        // 0x00B3479C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B347A0: MOV x0, x19                | X0 = 1152921515546610576 (0x100000028C0F8B90);//ML01
        // 0x00B347A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B347A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B347AC: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }

}
