using UnityEngine;
public sealed class BuglyAgent
{
    // Fields
    private static readonly string GAME_AGENT_CLASS; // static_offset: 0x00000000
    private static readonly int TYPE_U3D_CRASH; // static_offset: 0x00000008
    private static readonly int GAME_TYPE_UNITY; // static_offset: 0x0000000C
    private static bool hasSetGameType; // static_offset: 0x00000010
    private static UnityEngine.AndroidJavaClass _gameAgentClass; // static_offset: 0x00000018
    private static string _configChannel; // static_offset: 0x00000020
    private static string _configVersion; // static_offset: 0x00000028
    private static string _configUser; // static_offset: 0x00000030
    private static long _configDelayTime; // static_offset: 0x00000038
    private static bool _configCrashReporterPackage; // static_offset: 0x00000040
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2819C7C
    private static BuglyAgent.LogCallbackDelegate _LogCallbackEventHandler; // static_offset: 0x00000048
    private static bool _isInitialized; // static_offset: 0x00000050
    private static LogSeverity _autoReportLogLevel; // static_offset: 0x00000054
    private static int _crashReporterType; // static_offset: 0x00000058
    private static string _crashReporterPackage; // static_offset: 0x00000060
    private static bool _debugMode; // static_offset: 0x00000068
    private static bool _autoQuitApplicationAfterReport; // static_offset: 0x00000069
    private static readonly int EXCEPTION_TYPE_UNCAUGHT; // static_offset: 0x0000006C
    private static readonly int EXCEPTION_TYPE_CAUGHT; // static_offset: 0x00000070
    private static readonly string _pluginVersion; // static_offset: 0x00000078
    private static System.Func<System.Collections.Generic.Dictionary<string, string>> _LogCallbackExtrasHandler; // static_offset: 0x00000080
    private static bool _uncaughtAutoReportOnce; // static_offset: 0x00000088
    private static UnityEngine.Application.LogCallback <>f__mg$cache0; // static_offset: 0x00000090
    private static System.UnhandledExceptionEventHandler <>f__mg$cache1; // static_offset: 0x00000098
    private static System.UnhandledExceptionEventHandler <>f__mg$cache2; // static_offset: 0x000000A0
    
    // Properties
    public static UnityEngine.AndroidJavaClass GameAgent { get; }
    public static string PluginVersion { get; }
    public static bool IsInitialized { get; }
    public static bool AutoQuitApplicationAfterReport { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0272B64C (41072204), len: 8  VirtAddr: 0x0272B64C RVA: 0x0272B64C token: 100663297 methodIndex: 24265 delegateWrapperIndex: 0 methodInvoker: 0
    public BuglyAgent()
    {
        //
        // Disasemble & Code
        // 0x0272B64C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B650: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B654 (41072212), len: 100  VirtAddr: 0x0272B654 RVA: 0x0272B654 token: 100663298 methodIndex: 24266 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ConfigCrashReporter(int type, int logLevel)
    {
        //
        // Disasemble & Code
        // 0x0272B654: STP x20, x19, [sp, #-0x20]! | stack[1152921509924326400] = ???;  stack[1152921509924326408] = ???;  //  dest_result_addr=1152921509924326400 |  dest_result_addr=1152921509924326408
        // 0x0272B658: STP x29, x30, [sp, #0x10]  | stack[1152921509924326416] = ???;  stack[1152921509924326424] = ???;  //  dest_result_addr=1152921509924326416 |  dest_result_addr=1152921509924326424
        // 0x0272B65C: ADD x29, sp, #0x10         | X29 = (1152921509924326400 + 16) = 1152921509924326416 (0x100000013CF24C10);
        // 0x0272B660: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272B664: LDRB w8, [x20, #0xa9a]     | W8 = (bool)static_value_03743A9A;       
        // 0x0272B668: MOV w19, w1                | W19 = logLevel;//m1                     
        // 0x0272B66C: TBNZ w8, #0, #0x272b688    | if (static_value_03743A9A == true) goto label_0;
        // 0x0272B670: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x0272B674: LDR x8, [x8, #0x28]        | X8 = 0x2B8FE10;                         
        // 0x0272B678: LDR w0, [x8]               | W0 = 0x1648;                            
        // 0x0272B67C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1648, ????);     
        // 0x0272B680: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B684: STRB w8, [x20, #0xa9a]     | static_value_03743A9A = true;            //  dest_result_addr=57948826
        label_0:
        // 0x0272B688: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272B68C: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272B690: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x0272B694: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B698: TBZ w8, #0, #0x272b6a8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272B69C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B6A0: CBNZ w8, #0x272b6a8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272B6A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272B6A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B6AC: MOV w1, w19                | W1 = logLevel;//m1                      
        // 0x0272B6B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B6B4: B #0x272b6b8               | BuglyAgent._SetCrashReporterType(type:  169914368); return;
        BuglyAgent._SetCrashReporterType(type:  169914368);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B768 (41072488), len: 424  VirtAddr: 0x0272B768 RVA: 0x0272B768 token: 100663299 methodIndex: 24267 delegateWrapperIndex: 0 methodInvoker: 0
    public static void InitWithAppId(string appId)
    {
        //
        // Disasemble & Code
        //  | 
        string val_4;
        // 0x0272B768: STP x20, x19, [sp, #-0x20]! | stack[1152921509924442784] = ???;  stack[1152921509924442792] = ???;  //  dest_result_addr=1152921509924442784 |  dest_result_addr=1152921509924442792
        // 0x0272B76C: STP x29, x30, [sp, #0x10]  | stack[1152921509924442800] = ???;  stack[1152921509924442808] = ???;  //  dest_result_addr=1152921509924442800 |  dest_result_addr=1152921509924442808
        // 0x0272B770: ADD x29, sp, #0x10         | X29 = (1152921509924442784 + 16) = 1152921509924442800 (0x100000013CF412B0);
        // 0x0272B774: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272B778: LDRB w8, [x20, #0xa9b]     | W8 = (bool)static_value_03743A9B;       
        // 0x0272B77C: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272B780: TBNZ w8, #0, #0x272b79c    | if (static_value_03743A9B == true) goto label_0;
        // 0x0272B784: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x0272B788: LDR x8, [x8, #0xc38]       | X8 = 0x2B8FE44;                         
        // 0x0272B78C: LDR w0, [x8]               | W0 = 0x1655;                            
        // 0x0272B790: BL #0x2782188              | X0 = sub_2782188( ?? 0x1655, ????);     
        // 0x0272B794: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B798: STRB w8, [x20, #0xa9b]     | static_value_03743A9B = true;            //  dest_result_addr=57948827
        label_0:
        // 0x0272B79C: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272B7A0: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272B7A4: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272B7A8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B7AC: TBZ w8, #0, #0x272b7bc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272B7B0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B7B4: CBNZ w8, #0x272b7bc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272B7B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272B7BC: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272B7C0: TBZ w0, #0, #0x272b820     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272B7C4: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272B7C8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B7CC: TBZ w8, #0, #0x272b7dc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272B7D0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B7D4: CBNZ w8, #0x272b7dc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272B7D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272B7DC: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272B7E0: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x0272B7E4: LDR x8, [x8, #0x900]       | X8 = (string**)(1152921509924430528)("BuglyAgent has already been initialized.");
        // 0x0272B7E8: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
        // 0x0272B7EC: LDR x19, [x8]              | X19 = "BuglyAgent has already been initialized.";
        // 0x0272B7F0: LDR x20, [x9]              | X20 = typeof(System.Object[]);          
        // 0x0272B7F4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272B7F8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272B7FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B800: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272B804: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272B808: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B80C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B810: MOV x2, x19                | X2 = 1152921509924430528 (0x100000013CF3E2C0);//ML01
        // 0x0272B814: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272B818: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B81C: B #0x272b978               | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "BuglyAgent has already been initialized."); return;
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "BuglyAgent has already been initialized.");
        return;
        label_3:
        // 0x0272B820: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x0272B824: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x0272B828: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x0272B82C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272B830: TBZ w8, #0, #0x272b840     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272B834: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272B838: CBNZ w8, #0x272b840        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272B83C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_7:
        // 0x0272B840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B844: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272B848: MOV x1, x19                | X1 = X1;//m1                            
        // 0x0272B84C: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_2 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272B850: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x0272B854: TBZ w8, #0, #0x272b864     | if ((val_2 & 1) == false) goto label_8; 
        if(val_3 == false)
        {
            goto label_8;
        }
        // 0x0272B858: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B85C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B860: RET                        |  return;                                
        return;
        label_8:
        // 0x0272B864: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272B868: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B86C: TBZ w8, #0, #0x272b87c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x0272B870: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B874: CBNZ w8, #0x272b87c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0272B878: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_10:
        // 0x0272B87C: MOV x1, x19                | X1 = X1;//m1                            
        // 0x0272B880: BL #0x272bab0              | BuglyAgent.InitBuglyAgent(appId:  null);
        BuglyAgent.InitBuglyAgent(appId:  null);
        // 0x0272B884: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272B888: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272B88C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272B890: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272B894: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272B898: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272B89C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_4 = null;
        // 0x0272B8A0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272B8A4: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272B8A8: CBNZ x20, #0x272b8b0       | if ( != null) goto label_11;            
        if(null != null)
        {
            goto label_11;
        }
        // 0x0272B8AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_11:
        // 0x0272B8B0: CBZ x19, #0x272b8d4        | if (X1 == 0) goto label_13;             
        if(X1 == 0)
        {
            goto label_13;
        }
        // 0x0272B8B4: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272B8B8: MOV x0, x19                | X0 = X1;//m1                            
        val_4 = X1;
        // 0x0272B8BC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272B8C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
        // 0x0272B8C4: CBNZ x0, #0x272b8d4        | if (X1 != 0) goto label_13;             
        if(val_4 != 0)
        {
            goto label_13;
        }
        // 0x0272B8C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
        // 0x0272B8CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B8D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_13:
        // 0x0272B8D4: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272B8D8: CBNZ w8, #0x272b8e8        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_14;
        // 0x0272B8DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
        // 0x0272B8E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B8E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_14:
        // 0x0272B8E8: STR x19, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
        // 0x0272B8EC: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x0272B8F0: LDR x8, [x8, #0x2f8]       | X8 = (string**)(1152921509924430688)("Initialized with app id: {0}");
        // 0x0272B8F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B8F8: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272B8FC: LDR x2, [x8]               | X2 = "Initialized with app id: {0}";    
        // 0x0272B900: BL #0x272b978              | BuglyAgent.DebugLog(tag:  val_4 = X1, format:  0, args:  "Initialized with app id: {0}");
        BuglyAgent.DebugLog(tag:  val_4, format:  0, args:  "Initialized with app id: {0}");
        // 0x0272B904: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B908: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B90C: B #0x272bdc0               | BuglyAgent._RegisterExceptionHandler(); return;
        BuglyAgent._RegisterExceptionHandler();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272C098 (41074840), len: 288  VirtAddr: 0x0272C098 RVA: 0x0272C098 token: 100663300 methodIndex: 24268 delegateWrapperIndex: 0 methodInvoker: 0
    public static void EnableExceptionHandler()
    {
        //
        // Disasemble & Code
        // 0x0272C098: STP x20, x19, [sp, #-0x20]! | stack[1152921509924559232] = ???;  stack[1152921509924559240] = ???;  //  dest_result_addr=1152921509924559232 |  dest_result_addr=1152921509924559240
        // 0x0272C09C: STP x29, x30, [sp, #0x10]  | stack[1152921509924559248] = ???;  stack[1152921509924559256] = ???;  //  dest_result_addr=1152921509924559248 |  dest_result_addr=1152921509924559256
        // 0x0272C0A0: ADD x29, sp, #0x10         | X29 = (1152921509924559232 + 16) = 1152921509924559248 (0x100000013CF5D990);
        // 0x0272C0A4: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272C0A8: LDRB w8, [x19, #0xa9c]     | W8 = (bool)static_value_03743A9C;       
        // 0x0272C0AC: TBNZ w8, #0, #0x272c0c8    | if (static_value_03743A9C == true) goto label_0;
        // 0x0272C0B0: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x0272C0B4: LDR x8, [x8, #0x350]       | X8 = 0x2B8FE2C;                         
        // 0x0272C0B8: LDR w0, [x8]               | W0 = 0x164F;                            
        // 0x0272C0BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x164F, ????);     
        // 0x0272C0C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272C0C4: STRB w8, [x19, #0xa9c]     | static_value_03743A9C = true;            //  dest_result_addr=57948828
        label_0:
        // 0x0272C0C8: ADRP x19, #0x3652000       | X19 = 56958976 (0x3652000);             
        // 0x0272C0CC: LDR x19, [x19, #0x938]     | X19 = 1152921504776761344;              
        // 0x0272C0D0: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        // 0x0272C0D4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C0D8: TBZ w8, #0, #0x272c0e8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272C0DC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C0E0: CBNZ w8, #0x272c0e8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272C0E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272C0E8: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272C0EC: LDR x8, [x19]              | X8 = typeof(BuglyAgent);                
        // 0x0272C0F0: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504776761609 (0x100000000A20B109);
        // 0x0272C0F4: LDRH w9, [x9]              | W9 = BuglyAgent.__il2cppRuntimeField_109;
        // 0x0272C0F8: AND w9, w9, #0x100         | W9 = (BuglyAgent.__il2cppRuntimeField_109 & 256);
        // 0x0272C0FC: AND w9, w9, #0xffff        | W9 = ((BuglyAgent.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x0272C100: TBZ w0, #0, #0x272c15c     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272C104: CBZ w9, #0x272c118         | if (((BuglyAgent.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_5;
        // 0x0272C108: LDR w9, [x8, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C10C: CBNZ w9, #0x272c118        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272C110: MOV x0, x8                 | X0 = 1152921504776761344 (0x100000000A20B000);//ML01
        // 0x0272C114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272C118: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272C11C: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x0272C120: LDR x8, [x8, #0x900]       | X8 = (string**)(1152921509924430528)("BuglyAgent has already been initialized.");
        // 0x0272C124: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
        // 0x0272C128: LDR x19, [x8]              | X19 = "BuglyAgent has already been initialized.";
        // 0x0272C12C: LDR x20, [x9]              | X20 = typeof(System.Object[]);          
        // 0x0272C130: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C134: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272C138: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C13C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C140: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272C144: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C14C: MOV x2, x19                | X2 = 1152921509924430528 (0x100000013CF3E2C0);//ML01
        // 0x0272C150: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C154: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272C158: B #0x272b978               | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "BuglyAgent has already been initialized."); return;
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "BuglyAgent has already been initialized.");
        return;
        label_3:
        // 0x0272C15C: CBZ w9, #0x272c170         | if (((BuglyAgent.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_7;
        // 0x0272C160: LDR w9, [x8, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C164: CBNZ w9, #0x272c170        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272C168: MOV x0, x8                 | X0 = 1152921504776761344 (0x100000000A20B000);//ML01
        // 0x0272C16C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_7:
        // 0x0272C170: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
        // 0x0272C174: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x0272C178: LDR x8, [x8, #0x980]       | X8 = (string**)(1152921509924546912)("Only enable the exception handler, please make sure you has initialized the sdk in the native code in associated Android or iOS project.");
        // 0x0272C17C: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
        // 0x0272C180: LDR x19, [x8]              | X19 = "Only enable the exception handler, please make sure you has initialized the sdk in the native code in associated Android or iOS project.";
        // 0x0272C184: LDR x20, [x9]              | X20 = typeof(System.Object[]);          
        // 0x0272C188: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C18C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272C190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C194: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C198: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272C19C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C1A0: MOV x2, x19                | X2 = 1152921509924546912 (0x100000013CF5A960);//ML01
        // 0x0272C1A4: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C1A8: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Only enable the exception handler, please make sure you has initialized the sdk in the native code in associated Android or iOS project.");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Only enable the exception handler, please make sure you has initialized the sdk in the native code in associated Android or iOS project.");
        // 0x0272C1AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C1B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272C1B4: B #0x272bdc0               | BuglyAgent._RegisterExceptionHandler(); return;
        BuglyAgent._RegisterExceptionHandler();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272C1B8 (41075128), len: 240  VirtAddr: 0x0272C1B8 RVA: 0x0272C1B8 token: 100663301 methodIndex: 24269 delegateWrapperIndex: 0 methodInvoker: 0
    public static void RegisterLogCallback(BuglyAgent.LogCallbackDelegate handler)
    {
        //
        // Disasemble & Code
        // 0x0272C1B8: STP x20, x19, [sp, #-0x20]! | stack[1152921509924675456] = ???;  stack[1152921509924675464] = ???;  //  dest_result_addr=1152921509924675456 |  dest_result_addr=1152921509924675464
        // 0x0272C1BC: STP x29, x30, [sp, #0x10]  | stack[1152921509924675472] = ???;  stack[1152921509924675480] = ???;  //  dest_result_addr=1152921509924675472 |  dest_result_addr=1152921509924675480
        // 0x0272C1C0: ADD x29, sp, #0x10         | X29 = (1152921509924675456 + 16) = 1152921509924675472 (0x100000013CF79F90);
        // 0x0272C1C4: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272C1C8: LDRB w8, [x20, #0xa9d]     | W8 = (bool)static_value_03743A9D;       
        // 0x0272C1CC: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272C1D0: TBNZ w8, #0, #0x272c1ec    | if (static_value_03743A9D == true) goto label_0;
        // 0x0272C1D4: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x0272C1D8: LDR x8, [x8, #0x550]       | X8 = 0x2B8FE50;                         
        // 0x0272C1DC: LDR w0, [x8]               | W0 = 0x1658;                            
        // 0x0272C1E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1658, ????);     
        // 0x0272C1E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272C1E8: STRB w8, [x20, #0xa9d]     | static_value_03743A9D = true;            //  dest_result_addr=57948829
        label_0:
        // 0x0272C1EC: CBZ x19, #0x272c29c        | if (X1 == 0) goto label_1;              
        if(X1 == 0)
        {
            goto label_1;
        }
        // 0x0272C1F0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272C1F4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272C1F8: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272C1FC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C200: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272C204: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272C208: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C20C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272C210: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C214: CBNZ x20, #0x272c21c       | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x0272C218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x0272C21C: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272C220: MOV x0, x19                | X0 = X1;//m1                            
        // 0x0272C224: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272C228: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
        // 0x0272C22C: CBNZ x0, #0x272c23c        | if (X1 != 0) goto label_3;              
        if(X1 != 0)
        {
            goto label_3;
        }
        // 0x0272C230: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
        // 0x0272C234: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C238: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_3:
        // 0x0272C23C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272C240: CBNZ w8, #0x272c250        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x0272C244: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
        // 0x0272C248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C24C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_4:
        // 0x0272C250: STR x19, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
        // 0x0272C254: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272C258: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272C25C: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x0272C260: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C264: TBZ w8, #0, #0x272c274     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x0272C268: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C26C: CBNZ w8, #0x272c274        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x0272C270: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_6:
        // 0x0272C274: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x0272C278: LDR x8, [x8, #0xfb8]       | X8 = (string**)(1152921509924663360)("Add log callback handler: {0}");
        // 0x0272C27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C280: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C284: LDR x2, [x8]               | X2 = "Add log callback handler: {0}";   
        // 0x0272C288: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Add log callback handler: {0}");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Add log callback handler: {0}");
        // 0x0272C28C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C290: MOV x1, x19                | X1 = X1;//m1                            
        // 0x0272C294: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272C298: B #0x272c2a8               | BuglyAgent.add__LogCallbackEventHandler(value:  null); return;
        BuglyAgent.add__LogCallbackEventHandler(value:  null);
        return;
        label_1:
        // 0x0272C29C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C2A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272C2A4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272C3E4 (41075684), len: 244  VirtAddr: 0x0272C3E4 RVA: 0x0272C3E4 token: 100663302 methodIndex: 24270 delegateWrapperIndex: 0 methodInvoker: 0
    public static void SetLogCallbackExtrasHandler(System.Func<System.Collections.Generic.Dictionary<string, string>> handler)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x0272C3E4: STP x20, x19, [sp, #-0x20]! | stack[1152921509924795808] = ???;  stack[1152921509924795816] = ???;  //  dest_result_addr=1152921509924795808 |  dest_result_addr=1152921509924795816
        // 0x0272C3E8: STP x29, x30, [sp, #0x10]  | stack[1152921509924795824] = ???;  stack[1152921509924795832] = ???;  //  dest_result_addr=1152921509924795824 |  dest_result_addr=1152921509924795832
        // 0x0272C3EC: ADD x29, sp, #0x10         | X29 = (1152921509924795808 + 16) = 1152921509924795824 (0x100000013CF975B0);
        // 0x0272C3F0: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272C3F4: LDRB w8, [x20, #0xa9e]     | W8 = (bool)static_value_03743A9E;       
        // 0x0272C3F8: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272C3FC: TBNZ w8, #0, #0x272c418    | if (static_value_03743A9E == true) goto label_0;
        // 0x0272C400: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x0272C404: LDR x8, [x8, #0x2a8]       | X8 = 0x2B8FE68;                         
        // 0x0272C408: LDR w0, [x8]               | W0 = 0x165E;                            
        // 0x0272C40C: BL #0x2782188              | X0 = sub_2782188( ?? 0x165E, ????);     
        // 0x0272C410: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272C414: STRB w8, [x20, #0xa9e]     | static_value_03743A9E = true;            //  dest_result_addr=57948830
        label_0:
        // 0x0272C418: CBZ x19, #0x272c4cc        | if (X1 == 0) goto label_1;              
        if(X1 == 0)
        {
            goto label_1;
        }
        // 0x0272C41C: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272C420: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272C424: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272C428: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C42C: TBZ w8, #0, #0x272c440     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x0272C430: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C434: CBNZ w8, #0x272c440        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x0272C438: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272C43C: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_3:
        // 0x0272C440: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272C444: STR x19, [x8, #0x80]       | BuglyAgent._LogCallbackExtrasHandler = X1;  //  dest_result_addr=1152921504776765568
        BuglyAgent._LogCallbackExtrasHandler = X1;
        // 0x0272C448: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272C44C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272C450: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272C454: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C458: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272C45C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272C460: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C464: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272C468: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C46C: CBNZ x20, #0x272c474       | if ( != null) goto label_4;             
        if(null != null)
        {
            goto label_4;
        }
        // 0x0272C470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_4:
        // 0x0272C474: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272C478: MOV x0, x19                | X0 = X1;//m1                            
        // 0x0272C47C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272C480: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
        // 0x0272C484: CBNZ x0, #0x272c494        | if (X1 != 0) goto label_5;              
        if(X1 != 0)
        {
            goto label_5;
        }
        // 0x0272C488: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
        // 0x0272C48C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C490: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_5:
        // 0x0272C494: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272C498: CBNZ w8, #0x272c4a8        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_6;
        // 0x0272C49C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
        // 0x0272C4A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C4A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_6:
        // 0x0272C4A8: STR x19, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
        // 0x0272C4AC: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x0272C4B0: LDR x8, [x8, #0x698]       | X8 = (string**)(1152921509924783680)("Add log callback extra data handler : {0}");
        // 0x0272C4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C4B8: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C4BC: LDR x2, [x8]               | X2 = "Add log callback extra data handler : {0}";
        // 0x0272C4C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C4C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272C4C8: B #0x272b978               | BuglyAgent.DebugLog(tag:  X1, format:  0, args:  "Add log callback extra data handler : {0}"); return;
        BuglyAgent.DebugLog(tag:  X1, format:  0, args:  "Add log callback extra data handler : {0}");
        return;
        label_1:
        // 0x0272C4CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C4D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272C4D4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272C4D8 (41075928), len: 360  VirtAddr: 0x0272C4D8 RVA: 0x0272C4D8 token: 100663303 methodIndex: 24271 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ReportException(System.Exception e, string message)
    {
        //
        // Disasemble & Code
        // 0x0272C4D8: STP x22, x21, [sp, #-0x30]! | stack[1152921509924920256] = ???;  stack[1152921509924920264] = ???;  //  dest_result_addr=1152921509924920256 |  dest_result_addr=1152921509924920264
        // 0x0272C4DC: STP x20, x19, [sp, #0x10]  | stack[1152921509924920272] = ???;  stack[1152921509924920280] = ???;  //  dest_result_addr=1152921509924920272 |  dest_result_addr=1152921509924920280
        // 0x0272C4E0: STP x29, x30, [sp, #0x20]  | stack[1152921509924920288] = ???;  stack[1152921509924920296] = ???;  //  dest_result_addr=1152921509924920288 |  dest_result_addr=1152921509924920296
        // 0x0272C4E4: ADD x29, sp, #0x20         | X29 = (1152921509924920256 + 32) = 1152921509924920288 (0x100000013CFB5BE0);
        // 0x0272C4E8: ADRP x21, #0x3743000       | X21 = 57946112 (0x3743000);             
        // 0x0272C4EC: LDRB w8, [x21, #0xa9f]     | W8 = (bool)static_value_03743A9F;       
        // 0x0272C4F0: MOV x19, x2                | X19 = X2;//m1                           
        // 0x0272C4F4: MOV x20, x1                | X20 = message;//m1                      
        // 0x0272C4F8: TBNZ w8, #0, #0x272c514    | if (static_value_03743A9F == true) goto label_0;
        // 0x0272C4FC: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x0272C500: LDR x8, [x8, #0x3d0]       | X8 = 0x2B8FE60;                         
        // 0x0272C504: LDR w0, [x8]               | W0 = 0x165C;                            
        // 0x0272C508: BL #0x2782188              | X0 = sub_2782188( ?? 0x165C, ????);     
        // 0x0272C50C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272C510: STRB w8, [x21, #0xa9f]     | static_value_03743A9F = true;            //  dest_result_addr=57948831
        label_0:
        // 0x0272C514: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272C518: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272C51C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272C520: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C524: TBZ w8, #0, #0x272c534     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272C528: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C52C: CBNZ w8, #0x272c534        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272C530: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272C534: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272C538: TBZ w0, #0, #0x272c630     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272C53C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272C540: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272C544: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x0272C548: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C54C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272C550: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x0272C554: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C558: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272C55C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C560: CBNZ x21, #0x272c568       | if ( != null) goto label_4;             
        if(null != null)
        {
            goto label_4;
        }
        // 0x0272C564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_4:
        // 0x0272C568: CBZ x19, #0x272c58c        | if (X2 == 0) goto label_6;              
        if(X2 == 0)
        {
            goto label_6;
        }
        // 0x0272C56C: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272C570: MOV x0, x19                | X0 = X2;//m1                            
        // 0x0272C574: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272C578: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
        // 0x0272C57C: CBNZ x0, #0x272c58c        | if (X2 != 0) goto label_6;              
        if(X2 != 0)
        {
            goto label_6;
        }
        // 0x0272C580: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X2, ????);         
        // 0x0272C584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C588: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
        label_6:
        // 0x0272C58C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272C590: CBNZ w8, #0x272c5a0        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_7;
        // 0x0272C594: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
        // 0x0272C598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C59C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
        label_7:
        // 0x0272C5A0: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = X2;
        // 0x0272C5A4: CBZ x20, #0x272c5c8        | if (message == null) goto label_9;      
        if(message == null)
        {
            goto label_9;
        }
        // 0x0272C5A8: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272C5AC: MOV x0, x20                | X0 = message;//m1                       
        // 0x0272C5B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272C5B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? message, ????);    
        // 0x0272C5B8: CBNZ x0, #0x272c5c8        | if (message != null) goto label_9;      
        if(message != null)
        {
            goto label_9;
        }
        // 0x0272C5BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? message, ????);    
        // 0x0272C5C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C5C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? message, ????);    
        label_9:
        // 0x0272C5C8: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272C5CC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272C5D0: B.HI #0x272c5e0            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_10;
        // 0x0272C5D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? message, ????);    
        // 0x0272C5D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C5DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? message, ????);    
        label_10:
        // 0x0272C5E0: STR x20, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = message;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = message;
        // 0x0272C5E4: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272C5E8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C5EC: TBZ w8, #0, #0x272c5fc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x0272C5F0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C5F4: CBNZ w8, #0x272c5fc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x0272C5F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_12:
        // 0x0272C5FC: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x0272C600: LDR x8, [x8, #0xa58]       | X8 = (string**)(1152921509924908128)("Report exception: {0}\n------------\n{1}\n------------");
        // 0x0272C604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C608: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272C60C: LDR x2, [x8]               | X2 = "Report exception: {0}\n------------\n{1}\n------------";
        // 0x0272C610: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Report exception: {0}\n------------\n{1}\n------------");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Report exception: {0}\n------------\n{1}\n------------");
        // 0x0272C614: MOV x1, x20                | X1 = message;//m1                       
        // 0x0272C618: MOV x2, x19                | X2 = X2;//m1                            
        // 0x0272C61C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C620: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272C624: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x0272C628: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272C62C: B #0x272c640               | BuglyAgent._HandleException(e:  null, message:  message, uncaught:  X2); return;
        BuglyAgent._HandleException(e:  null, message:  message, uncaught:  X2);
        return;
        label_3:
        // 0x0272C630: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C634: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272C638: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272C63C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272CD0C (41078028), len: 448  VirtAddr: 0x0272CD0C RVA: 0x0272CD0C token: 100663304 methodIndex: 24272 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ReportException(string name, string message, string stackTrace)
    {
        //
        // Disasemble & Code
        // 0x0272CD0C: STP x24, x23, [sp, #-0x40]! | stack[1152921509925052864] = ???;  stack[1152921509925052872] = ???;  //  dest_result_addr=1152921509925052864 |  dest_result_addr=1152921509925052872
        // 0x0272CD10: STP x22, x21, [sp, #0x10]  | stack[1152921509925052880] = ???;  stack[1152921509925052888] = ???;  //  dest_result_addr=1152921509925052880 |  dest_result_addr=1152921509925052888
        // 0x0272CD14: STP x20, x19, [sp, #0x20]  | stack[1152921509925052896] = ???;  stack[1152921509925052904] = ???;  //  dest_result_addr=1152921509925052896 |  dest_result_addr=1152921509925052904
        // 0x0272CD18: STP x29, x30, [sp, #0x30]  | stack[1152921509925052912] = ???;  stack[1152921509925052920] = ???;  //  dest_result_addr=1152921509925052912 |  dest_result_addr=1152921509925052920
        // 0x0272CD1C: ADD x29, sp, #0x30         | X29 = (1152921509925052864 + 48) = 1152921509925052912 (0x100000013CFD61F0);
        // 0x0272CD20: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x0272CD24: LDRB w8, [x22, #0xaa0]     | W8 = (bool)static_value_03743AA0;       
        // 0x0272CD28: MOV x19, x3                | X19 = X3;//m1                           
        // 0x0272CD2C: MOV x20, x2                | X20 = stackTrace;//m1                   
        // 0x0272CD30: MOV x21, x1                | X21 = message;//m1                      
        // 0x0272CD34: TBNZ w8, #0, #0x272cd50    | if (static_value_03743AA0 == true) goto label_0;
        // 0x0272CD38: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x0272CD3C: LDR x8, [x8, #0x6c8]       | X8 = 0x2B8FE58;                         
        // 0x0272CD40: LDR w0, [x8]               | W0 = 0x165A;                            
        // 0x0272CD44: BL #0x2782188              | X0 = sub_2782188( ?? 0x165A, ????);     
        // 0x0272CD48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272CD4C: STRB w8, [x22, #0xaa0]     | static_value_03743AA0 = true;            //  dest_result_addr=57948832
        label_0:
        // 0x0272CD50: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
        // 0x0272CD54: LDR x23, [x23, #0x938]     | X23 = 1152921504776761344;              
        // 0x0272CD58: LDR x0, [x23]              | X0 = typeof(BuglyAgent);                
        // 0x0272CD5C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272CD60: TBZ w8, #0, #0x272cd70     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272CD64: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272CD68: CBNZ w8, #0x272cd70        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272CD6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272CD70: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272CD74: TBZ w0, #0, #0x272ceb8     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272CD78: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272CD7C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272CD80: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
        // 0x0272CD84: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272CD88: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272CD8C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x0272CD90: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272CD94: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272CD98: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272CD9C: CBNZ x22, #0x272cda4       | if ( != null) goto label_4;             
        if(null != null)
        {
            goto label_4;
        }
        // 0x0272CDA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_4:
        // 0x0272CDA4: CBZ x21, #0x272cdc8        | if (message == null) goto label_6;      
        if(message == null)
        {
            goto label_6;
        }
        // 0x0272CDA8: LDR x8, [x22]              | X8 = ;                                  
        // 0x0272CDAC: MOV x0, x21                | X0 = message;//m1                       
        // 0x0272CDB0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272CDB4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? message, ????);    
        // 0x0272CDB8: CBNZ x0, #0x272cdc8        | if (message != null) goto label_6;      
        if(message != null)
        {
            goto label_6;
        }
        // 0x0272CDBC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? message, ????);    
        // 0x0272CDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CDC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? message, ????);    
        label_6:
        // 0x0272CDC8: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272CDCC: CBNZ w8, #0x272cddc        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_7;
        // 0x0272CDD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? message, ????);    
        // 0x0272CDD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CDD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? message, ????);    
        label_7:
        // 0x0272CDDC: STR x21, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = message;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = message;
        // 0x0272CDE0: CBZ x20, #0x272ce04        | if (stackTrace == null) goto label_9;   
        if(stackTrace == null)
        {
            goto label_9;
        }
        // 0x0272CDE4: LDR x8, [x22]              | X8 = ;                                  
        // 0x0272CDE8: MOV x0, x20                | X0 = stackTrace;//m1                    
        // 0x0272CDEC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272CDF0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? stackTrace, ????); 
        // 0x0272CDF4: CBNZ x0, #0x272ce04        | if (stackTrace != null) goto label_9;   
        if(stackTrace != null)
        {
            goto label_9;
        }
        // 0x0272CDF8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? stackTrace, ????); 
        // 0x0272CDFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CE00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? stackTrace, ????); 
        label_9:
        // 0x0272CE04: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272CE08: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272CE0C: B.HI #0x272ce1c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_10;
        // 0x0272CE10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? stackTrace, ????); 
        // 0x0272CE14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CE18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? stackTrace, ????); 
        label_10:
        // 0x0272CE1C: STR x20, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = stackTrace;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = stackTrace;
        // 0x0272CE20: CBZ x19, #0x272ce44        | if (X3 == 0) goto label_12;             
        if(X3 == 0)
        {
            goto label_12;
        }
        // 0x0272CE24: LDR x8, [x22]              | X8 = ;                                  
        // 0x0272CE28: MOV x0, x19                | X0 = X3;//m1                            
        // 0x0272CE2C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272CE30: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X3, ????);         
        // 0x0272CE34: CBNZ x0, #0x272ce44        | if (X3 != 0) goto label_12;             
        if(X3 != 0)
        {
            goto label_12;
        }
        // 0x0272CE38: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X3, ????);         
        // 0x0272CE3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CE40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X3, ????);         
        label_12:
        // 0x0272CE44: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272CE48: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x0272CE4C: B.HI #0x272ce5c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_13;
        // 0x0272CE50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X3, ????);         
        // 0x0272CE54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CE58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X3, ????);         
        label_13:
        // 0x0272CE5C: STR x19, [x22, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = X3;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = X3;
        // 0x0272CE60: LDR x0, [x23]              | X0 = typeof(BuglyAgent);                
        // 0x0272CE64: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272CE68: TBZ w8, #0, #0x272ce78     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x0272CE6C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272CE70: CBNZ w8, #0x272ce78        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x0272CE74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_15:
        // 0x0272CE78: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
        // 0x0272CE7C: LDR x8, [x8, #0x388]       | X8 = (string**)(1152921509925040784)("Report exception: {0} {1} \n{2}");
        // 0x0272CE80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CE84: MOV x3, x22                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272CE88: LDR x2, [x8]               | X2 = "Report exception: {0} {1} \n{2}"; 
        // 0x0272CE8C: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Report exception: {0} {1} \n{2}");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Report exception: {0} {1} \n{2}");
        // 0x0272CE90: MOV x2, x21                | X2 = message;//m1                       
        // 0x0272CE94: MOV x3, x20                | X3 = stackTrace;//m1                    
        // 0x0272CE98: MOV x4, x19                | X4 = X3;//m1                            
        // 0x0272CE9C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272CEA0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272CEA4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272CEA8: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
        // 0x0272CEAC: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x0272CEB0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272CEB4: B #0x272cecc               | BuglyAgent._HandleException(logLevel:  null, name:  6, message:  message, stackTrace:  stackTrace, uncaught:  X3); return;
        BuglyAgent._HandleException(logLevel:  null, name:  6, message:  message, stackTrace:  stackTrace, uncaught:  X3);
        return;
        label_3:
        // 0x0272CEB8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272CEBC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272CEC0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272CEC4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272CEC8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272DB80 (41081728), len: 188  VirtAddr: 0x0272DB80 RVA: 0x0272DB80 token: 100663305 methodIndex: 24273 delegateWrapperIndex: 0 methodInvoker: 0
    public static void UnregisterLogCallback(BuglyAgent.LogCallbackDelegate handler)
    {
        //
        // Disasemble & Code
        // 0x0272DB80: STP x22, x21, [sp, #-0x30]! | stack[1152921509925181392] = ???;  stack[1152921509925181400] = ???;  //  dest_result_addr=1152921509925181392 |  dest_result_addr=1152921509925181400
        // 0x0272DB84: STP x20, x19, [sp, #0x10]  | stack[1152921509925181408] = ???;  stack[1152921509925181416] = ???;  //  dest_result_addr=1152921509925181408 |  dest_result_addr=1152921509925181416
        // 0x0272DB88: STP x29, x30, [sp, #0x20]  | stack[1152921509925181424] = ???;  stack[1152921509925181432] = ???;  //  dest_result_addr=1152921509925181424 |  dest_result_addr=1152921509925181432
        // 0x0272DB8C: ADD x29, sp, #0x20         | X29 = (1152921509925181392 + 32) = 1152921509925181424 (0x100000013CFF57F0);
        // 0x0272DB90: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272DB94: LDRB w8, [x20, #0xaa1]     | W8 = (bool)static_value_03743AA1;       
        // 0x0272DB98: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272DB9C: TBNZ w8, #0, #0x272dbb8    | if (static_value_03743AA1 == true) goto label_0;
        // 0x0272DBA0: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x0272DBA4: LDR x8, [x8, #0xb70]       | X8 = 0x2B8FE7C;                         
        // 0x0272DBA8: LDR w0, [x8]               | W0 = 0x1663;                            
        // 0x0272DBAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1663, ????);     
        // 0x0272DBB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272DBB4: STRB w8, [x20, #0xaa1]     | static_value_03743AA1 = true;            //  dest_result_addr=57948833
        label_0:
        // 0x0272DBB8: CBZ x19, #0x272dc2c        | if (X1 == 0) goto label_1;              
        if(X1 == 0)
        {
            goto label_1;
        }
        // 0x0272DBBC: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272DBC0: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272DBC4: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x0272DBC8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DBCC: TBZ w8, #0, #0x272dbdc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x0272DBD0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DBD4: CBNZ w8, #0x272dbdc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x0272DBD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_3:
        // 0x0272DBDC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x0272DBE0: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x0272DBE4: LDR x8, [x8, #0xf00]       | X8 = (string**)(1152921509925169312)("Remove log callback handler");
        // 0x0272DBE8: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
        // 0x0272DBEC: LDR x20, [x8]              | X20 = "Remove log callback handler";    
        // 0x0272DBF0: LDR x21, [x9]              | X21 = typeof(System.Object[]);          
        // 0x0272DBF4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DBF8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272DBFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DC00: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DC04: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272DC08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DC0C: MOV x2, x20                | X2 = 1152921509925169312 (0x100000013CFF28A0);//ML01
        // 0x0272DC10: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DC14: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Remove log callback handler");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Remove log callback handler");
        // 0x0272DC18: MOV x1, x19                | X1 = X1;//m1                            
        // 0x0272DC1C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DC20: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DC24: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272DC28: B #0x272dc3c               | BuglyAgent.remove__LogCallbackEventHandler(value:  null); return;
        BuglyAgent.remove__LogCallbackEventHandler(value:  null);
        return;
        label_1:
        // 0x0272DC2C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DC30: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DC34: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272DC38: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272DD78 (41082232), len: 284  VirtAddr: 0x0272DD78 RVA: 0x0272DD78 token: 100663306 methodIndex: 24274 delegateWrapperIndex: 0 methodInvoker: 0
    public static void SetUserId(string userId)
    {
        //
        // Disasemble & Code
        // 0x0272DD78: STP x22, x21, [sp, #-0x30]! | stack[1152921509925301696] = ???;  stack[1152921509925301704] = ???;  //  dest_result_addr=1152921509925301696 |  dest_result_addr=1152921509925301704
        // 0x0272DD7C: STP x20, x19, [sp, #0x10]  | stack[1152921509925301712] = ???;  stack[1152921509925301720] = ???;  //  dest_result_addr=1152921509925301712 |  dest_result_addr=1152921509925301720
        // 0x0272DD80: STP x29, x30, [sp, #0x20]  | stack[1152921509925301728] = ???;  stack[1152921509925301736] = ???;  //  dest_result_addr=1152921509925301728 |  dest_result_addr=1152921509925301736
        // 0x0272DD84: ADD x29, sp, #0x20         | X29 = (1152921509925301696 + 32) = 1152921509925301728 (0x100000013D012DE0);
        // 0x0272DD88: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272DD8C: LDRB w8, [x20, #0xaa2]     | W8 = (bool)static_value_03743AA2;       
        // 0x0272DD90: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272DD94: TBNZ w8, #0, #0x272ddb0    | if (static_value_03743AA2 == true) goto label_0;
        // 0x0272DD98: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x0272DD9C: LDR x8, [x8, #0x218]       | X8 = 0x2B8FE74;                         
        // 0x0272DDA0: LDR w0, [x8]               | W0 = 0x1661;                            
        // 0x0272DDA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1661, ????);     
        // 0x0272DDA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272DDAC: STRB w8, [x20, #0xaa2]     | static_value_03743AA2 = true;            //  dest_result_addr=57948834
        label_0:
        // 0x0272DDB0: ADRP x21, #0x3652000       | X21 = 56958976 (0x3652000);             
        // 0x0272DDB4: LDR x21, [x21, #0x938]     | X21 = 1152921504776761344;              
        // 0x0272DDB8: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        // 0x0272DDBC: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DDC0: TBZ w8, #0, #0x272ddd0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272DDC4: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DDC8: CBNZ w8, #0x272ddd0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272DDCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272DDD0: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272DDD4: TBZ w0, #0, #0x272de84     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272DDD8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272DDDC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272DDE0: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272DDE4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DDE8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272DDEC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272DDF0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DDF4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272DDF8: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DDFC: CBNZ x20, #0x272de04       | if ( != null) goto label_4;             
        if(null != null)
        {
            goto label_4;
        }
        // 0x0272DE00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_4:
        // 0x0272DE04: CBZ x19, #0x272de28        | if (X1 == 0) goto label_6;              
        if(X1 == 0)
        {
            goto label_6;
        }
        // 0x0272DE08: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272DE0C: MOV x0, x19                | X0 = X1;//m1                            
        // 0x0272DE10: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272DE14: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
        // 0x0272DE18: CBNZ x0, #0x272de28        | if (X1 != 0) goto label_6;              
        if(X1 != 0)
        {
            goto label_6;
        }
        // 0x0272DE1C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
        // 0x0272DE20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DE24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_6:
        // 0x0272DE28: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272DE2C: CBNZ w8, #0x272de3c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_7;
        // 0x0272DE30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
        // 0x0272DE34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DE38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_7:
        // 0x0272DE3C: STR x19, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
        // 0x0272DE40: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        // 0x0272DE44: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DE48: TBZ w8, #0, #0x272de58     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x0272DE4C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DE50: CBNZ w8, #0x272de58        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x0272DE54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_9:
        // 0x0272DE58: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x0272DE5C: LDR x8, [x8, #0xc48]       | X8 = (string**)(1152921509925289632)("Set user id: {0}");
        // 0x0272DE60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DE64: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DE68: LDR x2, [x8]               | X2 = "Set user id: {0}";                
        // 0x0272DE6C: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Set user id: {0}");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Set user id: {0}");
        // 0x0272DE70: MOV x1, x19                | X1 = X1;//m1                            
        // 0x0272DE74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DE78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DE7C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272DE80: B #0x272de94               | BuglyAgent.SetUserInfo(userInfo:  null); return;
        BuglyAgent.SetUserInfo(userInfo:  null);
        return;
        label_3:
        // 0x0272DE84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DE88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DE8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272DE90: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E024 (41082916), len: 312  VirtAddr: 0x0272E024 RVA: 0x0272E024 token: 100663307 methodIndex: 24275 delegateWrapperIndex: 0 methodInvoker: 0
    public static void SetScene(int sceneId)
    {
        //
        // Disasemble & Code
        // 0x0272E024: STP x22, x21, [sp, #-0x30]! | stack[1152921509925421984] = ???;  stack[1152921509925421992] = ???;  //  dest_result_addr=1152921509925421984 |  dest_result_addr=1152921509925421992
        // 0x0272E028: STP x20, x19, [sp, #0x10]  | stack[1152921509925422000] = ???;  stack[1152921509925422008] = ???;  //  dest_result_addr=1152921509925422000 |  dest_result_addr=1152921509925422008
        // 0x0272E02C: STP x29, x30, [sp, #0x20]  | stack[1152921509925422016] = ???;  stack[1152921509925422024] = ???;  //  dest_result_addr=1152921509925422016 |  dest_result_addr=1152921509925422024
        // 0x0272E030: ADD x29, sp, #0x20         | X29 = (1152921509925421984 + 32) = 1152921509925422016 (0x100000013D0303C0);
        // 0x0272E034: SUB sp, sp, #0x10          | SP = (1152921509925421984 - 16) = 1152921509925421968 (0x100000013D030390);
        // 0x0272E038: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272E03C: LDRB w8, [x20, #0xaa3]     | W8 = (bool)static_value_03743AA3;       
        // 0x0272E040: MOV w19, w1                | W19 = W1;//m1                           
        // 0x0272E044: TBNZ w8, #0, #0x272e060    | if (static_value_03743AA3 == true) goto label_0;
        // 0x0272E048: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x0272E04C: LDR x8, [x8, #0x360]       | X8 = 0x2B8FE6C;                         
        // 0x0272E050: LDR w0, [x8]               | W0 = 0x165F;                            
        // 0x0272E054: BL #0x2782188              | X0 = sub_2782188( ?? 0x165F, ????);     
        // 0x0272E058: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E05C: STRB w8, [x20, #0xaa3]     | static_value_03743AA3 = true;            //  dest_result_addr=57948835
        label_0:
        // 0x0272E060: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272E064: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272E068: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272E06C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E070: TBZ w8, #0, #0x272e080     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E074: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E078: CBNZ w8, #0x272e080        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E07C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272E080: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272E084: TBZ w0, #0, #0x272e148     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272E088: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272E08C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272E090: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272E094: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E098: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272E09C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272E0A0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E0A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272E0A8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272E0AC: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x0272E0B0: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E0B4: ADD x1, sp, #0xc           | X1 = (1152921509925421968 + 12) = 1152921509925421980 (0x100000013D03039C);
        // 0x0272E0B8: STR w19, [sp, #0xc]        | stack[1152921509925421980] = W1;         //  dest_result_addr=1152921509925421980
        // 0x0272E0BC: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x0272E0C0: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x0272E0C4: BL #0x27bc028              | X0 = 1152921509925466032 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), W1);
        // 0x0272E0C8: MOV x21, x0                | X21 = 1152921509925466032 (0x100000013D03AFB0);//ML01
        // 0x0272E0CC: CBNZ x20, #0x272e0d4       | if ( != null) goto label_4;             
        if(null != null)
        {
            goto label_4;
        }
        // 0x0272E0D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? W1, ????);         
        label_4:
        // 0x0272E0D4: CBZ x21, #0x272e0f8        | if (W1 == 0) goto label_6;              
        if(W1 == 0)
        {
            goto label_6;
        }
        // 0x0272E0D8: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272E0DC: MOV x0, x21                | X0 = 1152921509925466032 (0x100000013D03AFB0);//ML01
        // 0x0272E0E0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E0E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? W1, ????);         
        // 0x0272E0E8: CBNZ x0, #0x272e0f8        | if (W1 != 0) goto label_6;              
        if(W1 != 0)
        {
            goto label_6;
        }
        // 0x0272E0EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? W1, ????);         
        // 0x0272E0F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E0F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? W1, ????);         
        label_6:
        // 0x0272E0F8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E0FC: CBNZ w8, #0x272e10c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_7;
        // 0x0272E100: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? W1, ????);         
        // 0x0272E104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E108: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? W1, ????);         
        label_7:
        // 0x0272E10C: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = W1; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000001;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = W1;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435457;
        // 0x0272E110: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272E114: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E118: TBZ w8, #0, #0x272e128     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x0272E11C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E120: CBNZ w8, #0x272e128        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x0272E124: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_9:
        // 0x0272E128: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x0272E12C: LDR x8, [x8, #0x4b8]       | X8 = (string**)(1152921509925409936)("Set scene: {0}");
        // 0x0272E130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E134: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E138: LDR x2, [x8]               | X2 = "Set scene: {0}";                  
        // 0x0272E13C: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Set scene: {0}");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Set scene: {0}");
        // 0x0272E140: MOV w1, w19                | W1 = W1;//m1                            
        // 0x0272E144: BL #0x272e15c              | BuglyAgent.SetCurrentScene(sceneId:  169914368);
        BuglyAgent.SetCurrentScene(sceneId:  169914368);
        label_3:
        // 0x0272E148: SUB sp, x29, #0x20         | SP = (1152921509925422016 - 32) = 1152921509925421984 (0x100000013D0303A0);
        // 0x0272E14C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E150: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E154: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E158: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E308 (41083656), len: 356  VirtAddr: 0x0272E308 RVA: 0x0272E308 token: 100663308 methodIndex: 24276 delegateWrapperIndex: 0 methodInvoker: 0
    public static void AddSceneData(string key, string value)
    {
        //
        // Disasemble & Code
        // 0x0272E308: STP x22, x21, [sp, #-0x30]! | stack[1152921509925546400] = ???;  stack[1152921509925546408] = ???;  //  dest_result_addr=1152921509925546400 |  dest_result_addr=1152921509925546408
        // 0x0272E30C: STP x20, x19, [sp, #0x10]  | stack[1152921509925546416] = ???;  stack[1152921509925546424] = ???;  //  dest_result_addr=1152921509925546416 |  dest_result_addr=1152921509925546424
        // 0x0272E310: STP x29, x30, [sp, #0x20]  | stack[1152921509925546432] = ???;  stack[1152921509925546440] = ???;  //  dest_result_addr=1152921509925546432 |  dest_result_addr=1152921509925546440
        // 0x0272E314: ADD x29, sp, #0x20         | X29 = (1152921509925546400 + 32) = 1152921509925546432 (0x100000013D04E9C0);
        // 0x0272E318: ADRP x21, #0x3743000       | X21 = 57946112 (0x3743000);             
        // 0x0272E31C: LDRB w8, [x21, #0xaa4]     | W8 = (bool)static_value_03743AA4;       
        // 0x0272E320: MOV x19, x2                | X19 = X2;//m1                           
        // 0x0272E324: MOV x20, x1                | X20 = value;//m1                        
        // 0x0272E328: TBNZ w8, #0, #0x272e344    | if (static_value_03743AA4 == true) goto label_0;
        // 0x0272E32C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x0272E330: LDR x8, [x8, #0x6b8]       | X8 = 0x2B8FE04;                         
        // 0x0272E334: LDR w0, [x8]               | W0 = 0x1645;                            
        // 0x0272E338: BL #0x2782188              | X0 = sub_2782188( ?? 0x1645, ????);     
        // 0x0272E33C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E340: STRB w8, [x21, #0xaa4]     | static_value_03743AA4 = true;            //  dest_result_addr=57948836
        label_0:
        // 0x0272E344: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272E348: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272E34C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272E350: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E354: TBZ w8, #0, #0x272e364     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E358: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E35C: CBNZ w8, #0x272e364        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E360: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272E364: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272E368: TBZ w0, #0, #0x272e45c     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x0272E36C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272E370: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272E374: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x0272E378: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E37C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272E380: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x0272E384: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E388: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272E38C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E390: CBNZ x21, #0x272e398       | if ( != null) goto label_4;             
        if(null != null)
        {
            goto label_4;
        }
        // 0x0272E394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_4:
        // 0x0272E398: CBZ x20, #0x272e3bc        | if (value == null) goto label_6;        
        if(value == null)
        {
            goto label_6;
        }
        // 0x0272E39C: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272E3A0: MOV x0, x20                | X0 = value;//m1                         
        // 0x0272E3A4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E3A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
        // 0x0272E3AC: CBNZ x0, #0x272e3bc        | if (value != null) goto label_6;        
        if(value != null)
        {
            goto label_6;
        }
        // 0x0272E3B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? value, ????);      
        // 0x0272E3B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E3B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? value, ????);      
        label_6:
        // 0x0272E3BC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E3C0: CBNZ w8, #0x272e3d0        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_7;
        // 0x0272E3C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? value, ????);      
        // 0x0272E3C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E3CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? value, ????);      
        label_7:
        // 0x0272E3D0: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = value;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = value;
        // 0x0272E3D4: CBZ x19, #0x272e3f8        | if (X2 == 0) goto label_9;              
        if(X2 == 0)
        {
            goto label_9;
        }
        // 0x0272E3D8: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272E3DC: MOV x0, x19                | X0 = X2;//m1                            
        // 0x0272E3E0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E3E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
        // 0x0272E3E8: CBNZ x0, #0x272e3f8        | if (X2 != 0) goto label_9;              
        if(X2 != 0)
        {
            goto label_9;
        }
        // 0x0272E3EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X2, ????);         
        // 0x0272E3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E3F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
        label_9:
        // 0x0272E3F8: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E3FC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272E400: B.HI #0x272e410            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_10;
        // 0x0272E404: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
        // 0x0272E408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E40C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
        label_10:
        // 0x0272E410: STR x19, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = X2;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = X2;
        // 0x0272E414: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272E418: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E41C: TBZ w8, #0, #0x272e42c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x0272E420: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E424: CBNZ w8, #0x272e42c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x0272E428: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_12:
        // 0x0272E42C: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
        // 0x0272E430: LDR x8, [x8, #0x3d0]       | X8 = (string**)(1152921509925534320)("Add scene data: [{0}, {1}]");
        // 0x0272E434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E438: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E43C: LDR x2, [x8]               | X2 = "Add scene data: [{0}, {1}]";      
        // 0x0272E440: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Add scene data: [{0}, {1}]");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Add scene data: [{0}, {1}]");
        // 0x0272E444: MOV x1, x20                | X1 = value;//m1                         
        // 0x0272E448: MOV x2, x19                | X2 = X2;//m1                            
        // 0x0272E44C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E450: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E454: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E458: B #0x272e46c               | BuglyAgent.AddKeyAndValueInScene(key:  null, value:  value); return;
        BuglyAgent.AddKeyAndValueInScene(key:  null, value:  value);
        return;
        label_3:
        // 0x0272E45C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E460: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E464: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E468: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E640 (41084480), len: 292  VirtAddr: 0x0272E640 RVA: 0x0272E640 token: 100663309 methodIndex: 24277 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ConfigDebugMode(bool enable)
    {
        //
        // Disasemble & Code
        // 0x0272E640: STP x22, x21, [sp, #-0x30]! | stack[1152921509925666912] = ???;  stack[1152921509925666920] = ???;  //  dest_result_addr=1152921509925666912 |  dest_result_addr=1152921509925666920
        // 0x0272E644: STP x20, x19, [sp, #0x10]  | stack[1152921509925666928] = ???;  stack[1152921509925666936] = ???;  //  dest_result_addr=1152921509925666928 |  dest_result_addr=1152921509925666936
        // 0x0272E648: STP x29, x30, [sp, #0x20]  | stack[1152921509925666944] = ???;  stack[1152921509925666952] = ???;  //  dest_result_addr=1152921509925666944 |  dest_result_addr=1152921509925666952
        // 0x0272E64C: ADD x29, sp, #0x20         | X29 = (1152921509925666912 + 32) = 1152921509925666944 (0x100000013D06C080);
        // 0x0272E650: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272E654: LDRB w8, [x20, #0xaa5]     | W8 = (bool)static_value_03743AA5;       
        // 0x0272E658: MOV w19, w1                | W19 = W1;//m1                           
        // 0x0272E65C: TBNZ w8, #0, #0x272e678    | if (static_value_03743AA5 == true) goto label_0;
        // 0x0272E660: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x0272E664: LDR x8, [x8, #0x550]       | X8 = 0x2B8FE18;                         
        // 0x0272E668: LDR w0, [x8]               | W0 = 0x164A;                            
        // 0x0272E66C: BL #0x2782188              | X0 = sub_2782188( ?? 0x164A, ????);     
        // 0x0272E670: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E674: STRB w8, [x20, #0xaa5]     | static_value_03743AA5 = true;            //  dest_result_addr=57948837
        label_0:
        // 0x0272E678: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272E67C: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272E680: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272E684: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E688: TBZ w8, #0, #0x272e698     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E68C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E690: CBNZ w8, #0x272e698        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E694: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272E698: AND w1, w19, #1            | W1 = (W1 & 1);                          
        var val_1 = W1 & 1;
        // 0x0272E69C: BL #0x272e764              | BuglyAgent.EnableDebugMode(enable:  false);
        BuglyAgent.EnableDebugMode(enable:  false);
        // 0x0272E6A0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272E6A4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272E6A8: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272E6AC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E6B0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272E6B4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272E6B8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E6BC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272E6C0: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x0272E6C4: ADRP x9, #0x3640000        | X9 = 56885248 (0x3640000);              
        // 0x0272E6C8: ADRP x10, #0x366c000       | X10 = 57065472 (0x366C000);             
        // 0x0272E6CC: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921509925654640)("{0} the log message print to console");
        // 0x0272E6D0: LDR x9, [x9, #0x38]        | X9 = (string**)(1152921509925654784)("Enable");
        // 0x0272E6D4: LDR x10, [x10, #0xc28]     | X10 = (string**)(1152921509925654864)("Disable");
        // 0x0272E6D8: TST w19, #1                | STATE = COMPARE(W1, 0x1)                
        // 0x0272E6DC: LDR x19, [x8]              | X19 = "{0} the log message print to console";
        // 0x0272E6E0: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E6E4: CSEL x8, x9, x10, ne       | X8 = W1 != 0x1 ? "Enable" : "Disable";  
        var val_2 = (W1 != 1) ? ("Enable") : ("Disable");
        // 0x0272E6E8: LDR x21, [x8]              | X21 = W1 != 0x1 ? "Enable" : "Disable"; 
        // 0x0272E6EC: CBNZ x20, #0x272e6f4       | if ( != null) goto label_3;             
        if(null != null)
        {
            goto label_3;
        }
        // 0x0272E6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_3:
        // 0x0272E6F4: CBZ x21, #0x272e718        | if (W1 != 0x1 ? "Enable" : "Disable" == 0) goto label_5;
        if(val_2 == 0)
        {
            goto label_5;
        }
        // 0x0272E6F8: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272E6FC: MOV x0, x21                | X0 = W1 != 0x1 ? "Enable" : "Disable";//m1
        // 0x0272E700: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E704: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? W1 != 0x1 ? "Enable" : "Disable", ????);
        // 0x0272E708: CBNZ x0, #0x272e718        | if (W1 != 0x1 ? "Enable" : "Disable" != 0) goto label_5;
        if(val_2 != 0)
        {
            goto label_5;
        }
        // 0x0272E70C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? W1 != 0x1 ? "Enable" : "Disable", ????);
        // 0x0272E710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E714: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? W1 != 0x1 ? "Enable" : "Disable", ????);
        label_5:
        // 0x0272E718: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E71C: CBNZ w8, #0x272e72c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_6;
        // 0x0272E720: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? W1 != 0x1 ? "Enable" : "Disable", ????);
        // 0x0272E724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E728: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? W1 != 0x1 ? "Enable" : "Disable", ????);
        label_6:
        // 0x0272E72C: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = W1 != 0x1 ? "Enable" : "Disable";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x0272E730: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272E734: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E738: TBZ w8, #0, #0x272e748     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x0272E73C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E740: CBNZ w8, #0x272e748        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x0272E744: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_8:
        // 0x0272E748: MOV x2, x19                | X2 = 1152921509925654640 (0x100000013D069070);//ML01
        // 0x0272E74C: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E750: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E754: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E75C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E760: B #0x272b978               | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "{0} the log message print to console"); return;
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "{0} the log message print to console");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E920 (41085216), len: 112  VirtAddr: 0x0272E920 RVA: 0x0272E920 token: 100663310 methodIndex: 24278 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ConfigAutoQuitApplication(bool autoQuit)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x0272E920: STP x20, x19, [sp, #-0x20]! | stack[1152921509925778928] = ???;  stack[1152921509925778936] = ???;  //  dest_result_addr=1152921509925778928 |  dest_result_addr=1152921509925778936
        // 0x0272E924: STP x29, x30, [sp, #0x10]  | stack[1152921509925778944] = ???;  stack[1152921509925778952] = ???;  //  dest_result_addr=1152921509925778944 |  dest_result_addr=1152921509925778952
        // 0x0272E928: ADD x29, sp, #0x10         | X29 = (1152921509925778928 + 16) = 1152921509925778944 (0x100000013D087600);
        // 0x0272E92C: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272E930: LDRB w8, [x20, #0xaa6]     | W8 = (bool)static_value_03743AA6;       
        // 0x0272E934: MOV w19, w1                | W19 = W1;//m1                           
        // 0x0272E938: TBNZ w8, #0, #0x272e954    | if (static_value_03743AA6 == true) goto label_0;
        // 0x0272E93C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x0272E940: LDR x8, [x8, #0xeb8]       | X8 = 0x2B8FE08;                         
        // 0x0272E944: LDR w0, [x8]               | W0 = 0x1646;                            
        // 0x0272E948: BL #0x2782188              | X0 = sub_2782188( ?? 0x1646, ????);     
        // 0x0272E94C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E950: STRB w8, [x20, #0xaa6]     | static_value_03743AA6 = true;            //  dest_result_addr=57948838
        label_0:
        // 0x0272E954: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272E958: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272E95C: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_2 = null;
        // 0x0272E960: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E964: TBZ w8, #0, #0x272e978     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E968: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E96C: CBNZ w8, #0x272e978        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E970: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272E974: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_2 = null;
        label_2:
        // 0x0272E978: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272E97C: AND w9, w19, #1            | W9 = (W1 & 1);                          
        bool val_1 = W1 & 1;
        // 0x0272E980: STRB w9, [x8, #0x69]       | BuglyAgent._autoQuitApplicationAfterReport = (W1 & 1);  //  dest_result_addr=1152921504776765545
        BuglyAgent._autoQuitApplicationAfterReport = val_1;
        // 0x0272E984: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E988: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272E98C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E990 (41085328), len: 108  VirtAddr: 0x0272E990 RVA: 0x0272E990 token: 100663311 methodIndex: 24279 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ConfigAutoReportLogLevel(LogSeverity level)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x0272E990: STP x20, x19, [sp, #-0x20]! | stack[1152921509925895024] = ???;  stack[1152921509925895032] = ???;  //  dest_result_addr=1152921509925895024 |  dest_result_addr=1152921509925895032
        // 0x0272E994: STP x29, x30, [sp, #0x10]  | stack[1152921509925895040] = ???;  stack[1152921509925895048] = ???;  //  dest_result_addr=1152921509925895040 |  dest_result_addr=1152921509925895048
        // 0x0272E998: ADD x29, sp, #0x10         | X29 = (1152921509925895024 + 16) = 1152921509925895040 (0x100000013D0A3B80);
        // 0x0272E99C: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272E9A0: LDRB w8, [x20, #0xaa7]     | W8 = (bool)static_value_03743AA7;       
        // 0x0272E9A4: MOV w19, w1                | W19 = W1;//m1                           
        // 0x0272E9A8: TBNZ w8, #0, #0x272e9c4    | if (static_value_03743AA7 == true) goto label_0;
        // 0x0272E9AC: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x0272E9B0: LDR x8, [x8, #0x7b8]       | X8 = 0x2B8FE0C;                         
        // 0x0272E9B4: LDR w0, [x8]               | W0 = 0x1647;                            
        // 0x0272E9B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1647, ????);     
        // 0x0272E9BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E9C0: STRB w8, [x20, #0xaa7]     | static_value_03743AA7 = true;            //  dest_result_addr=57948839
        label_0:
        // 0x0272E9C4: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272E9C8: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272E9CC: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272E9D0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E9D4: TBZ w8, #0, #0x272e9e8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E9D8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E9DC: CBNZ w8, #0x272e9e8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E9E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272E9E4: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_2:
        // 0x0272E9E8: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272E9EC: STR w19, [x8, #0x54]       | BuglyAgent._autoReportLogLevel = W1;     //  dest_result_addr=1152921504776765524
        BuglyAgent._autoReportLogLevel = W1;
        // 0x0272E9F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E9F4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272E9F8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E9FC (41085436), len: 500  VirtAddr: 0x0272E9FC RVA: 0x0272E9FC token: 100663312 methodIndex: 24280 delegateWrapperIndex: 0 methodInvoker: 0
    public static void ConfigDefault(string channel, string version, string user, long delay)
    {
        //
        // Disasemble & Code
        // 0x0272E9FC: STP x24, x23, [sp, #-0x40]! | stack[1152921509926027664] = ???;  stack[1152921509926027672] = ???;  //  dest_result_addr=1152921509926027664 |  dest_result_addr=1152921509926027672
        // 0x0272EA00: STP x22, x21, [sp, #0x10]  | stack[1152921509926027680] = ???;  stack[1152921509926027688] = ???;  //  dest_result_addr=1152921509926027680 |  dest_result_addr=1152921509926027688
        // 0x0272EA04: STP x20, x19, [sp, #0x20]  | stack[1152921509926027696] = ???;  stack[1152921509926027704] = ???;  //  dest_result_addr=1152921509926027696 |  dest_result_addr=1152921509926027704
        // 0x0272EA08: STP x29, x30, [sp, #0x30]  | stack[1152921509926027712] = ???;  stack[1152921509926027720] = ???;  //  dest_result_addr=1152921509926027712 |  dest_result_addr=1152921509926027720
        // 0x0272EA0C: ADD x29, sp, #0x30         | X29 = (1152921509926027664 + 48) = 1152921509926027712 (0x100000013D0C41C0);
        // 0x0272EA10: SUB sp, sp, #0x10          | SP = (1152921509926027664 - 16) = 1152921509926027648 (0x100000013D0C4180);
        // 0x0272EA14: ADRP x23, #0x3743000       | X23 = 57946112 (0x3743000);             
        // 0x0272EA18: LDRB w8, [x23, #0xaa8]     | W8 = (bool)static_value_03743AA8;       
        // 0x0272EA1C: MOV x19, x4                | X19 = X4;//m1                           
        // 0x0272EA20: MOV x20, x3                | X20 = delay;//m1                        
        // 0x0272EA24: MOV x21, x2                | X21 = user;//m1                         
        // 0x0272EA28: MOV x22, x1                | X22 = version;//m1                      
        // 0x0272EA2C: TBNZ w8, #0, #0x272ea48    | if (static_value_03743AA8 == true) goto label_0;
        // 0x0272EA30: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x0272EA34: LDR x8, [x8, #0x6a8]       | X8 = 0x2B8FE1C;                         
        // 0x0272EA38: LDR w0, [x8]               | W0 = 0x164B;                            
        // 0x0272EA3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x164B, ????);     
        // 0x0272EA40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272EA44: STRB w8, [x23, #0xaa8]     | static_value_03743AA8 = true;            //  dest_result_addr=57948840
        label_0:
        // 0x0272EA48: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272EA4C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272EA50: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x0272EA54: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EA58: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272EA5C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x0272EA60: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EA64: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272EA68: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EA6C: CBNZ x23, #0x272ea74       | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x0272EA70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_1:
        // 0x0272EA74: CBZ x22, #0x272ea98        | if (version == null) goto label_3;      
        if(version == null)
        {
            goto label_3;
        }
        // 0x0272EA78: LDR x8, [x23]              | X8 = ;                                  
        // 0x0272EA7C: MOV x0, x22                | X0 = version;//m1                       
        // 0x0272EA80: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272EA84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? version, ????);    
        // 0x0272EA88: CBNZ x0, #0x272ea98        | if (version != null) goto label_3;      
        if(version != null)
        {
            goto label_3;
        }
        // 0x0272EA8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? version, ????);    
        // 0x0272EA90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EA94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? version, ????);    
        label_3:
        // 0x0272EA98: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272EA9C: CBNZ w8, #0x272eaac        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x0272EAA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? version, ????);    
        // 0x0272EAA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EAA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? version, ????);    
        label_4:
        // 0x0272EAAC: STR x22, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = version;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = version;
        // 0x0272EAB0: CBZ x21, #0x272ead4        | if (user == null) goto label_6;         
        if(user == null)
        {
            goto label_6;
        }
        // 0x0272EAB4: LDR x8, [x23]              | X8 = ;                                  
        // 0x0272EAB8: MOV x0, x21                | X0 = user;//m1                          
        // 0x0272EABC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272EAC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? user, ????);       
        // 0x0272EAC4: CBNZ x0, #0x272ead4        | if (user != null) goto label_6;         
        if(user != null)
        {
            goto label_6;
        }
        // 0x0272EAC8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? user, ????);       
        // 0x0272EACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EAD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? user, ????);       
        label_6:
        // 0x0272EAD4: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272EAD8: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272EADC: B.HI #0x272eaec            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
        // 0x0272EAE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? user, ????);       
        // 0x0272EAE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EAE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? user, ????);       
        label_7:
        // 0x0272EAEC: STR x21, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = user;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = user;
        // 0x0272EAF0: CBZ x20, #0x272eb14        | if (delay == 0) goto label_9;           
        if(delay == 0)
        {
            goto label_9;
        }
        // 0x0272EAF4: LDR x8, [x23]              | X8 = ;                                  
        // 0x0272EAF8: MOV x0, x20                | X0 = delay;//m1                         
        // 0x0272EAFC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272EB00: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? delay, ????);      
        // 0x0272EB04: CBNZ x0, #0x272eb14        | if (delay != 0) goto label_9;           
        if(delay != 0)
        {
            goto label_9;
        }
        // 0x0272EB08: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? delay, ????);      
        // 0x0272EB0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EB10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? delay, ????);      
        label_9:
        // 0x0272EB14: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272EB18: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x0272EB1C: B.HI #0x272eb2c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_10;
        // 0x0272EB20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? delay, ????);      
        // 0x0272EB24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EB28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? delay, ????);      
        label_10:
        // 0x0272EB2C: STR x20, [x23, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = delay;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = delay;
        // 0x0272EB30: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x0272EB34: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
        // 0x0272EB38: ADD x1, sp, #8             | X1 = (1152921509926027648 + 8) = 1152921509926027656 (0x100000013D0C4188);
        // 0x0272EB3C: STR x19, [sp, #8]          | stack[1152921509926027656] = X4;         //  dest_result_addr=1152921509926027656
        // 0x0272EB40: LDR x0, [x8]               | X0 = typeof(System.Int64);              
        // 0x0272EB44: BL #0x27bc028              | X0 = 1152921509926084016 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), X4);
        // 0x0272EB48: MOV x24, x0                | X24 = 1152921509926084016 (0x100000013D0D1DB0);//ML01
        // 0x0272EB4C: CBZ x24, #0x272eb70        | if (X4 == 0) goto label_12;             
        if(X4 == 0)
        {
            goto label_12;
        }
        // 0x0272EB50: LDR x8, [x23]              | X8 = ;                                  
        // 0x0272EB54: MOV x0, x24                | X0 = 1152921509926084016 (0x100000013D0D1DB0);//ML01
        // 0x0272EB58: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272EB5C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X4, ????);         
        // 0x0272EB60: CBNZ x0, #0x272eb70        | if (X4 != 0) goto label_12;             
        if(X4 != 0)
        {
            goto label_12;
        }
        // 0x0272EB64: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X4, ????);         
        // 0x0272EB68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EB6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X4, ????);         
        label_12:
        // 0x0272EB70: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272EB74: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x0272EB78: B.HI #0x272eb88            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_13;
        // 0x0272EB7C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X4, ????);         
        // 0x0272EB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EB84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X4, ????);         
        label_13:
        // 0x0272EB88: STR x24, [x23, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = X4;  //  dest_result_addr=1152921504954501320
        typeof(System.Object[]).__il2cppRuntimeField_38 = X4;
        // 0x0272EB8C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272EB90: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272EB94: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x0272EB98: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272EB9C: TBZ w8, #0, #0x272ebac     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x0272EBA0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272EBA4: CBNZ w8, #0x272ebac        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x0272EBA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_15:
        // 0x0272EBAC: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x0272EBB0: LDR x8, [x8, #0x8b0]       | X8 = (string**)(1152921509926015536)("Config default channel:{0}, version:{1}, user:{2}, delay:{3}");
        // 0x0272EBB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EBB8: MOV x3, x23                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EBBC: LDR x2, [x8]               | X2 = "Config default channel:{0}, version:{1}, user:{2}, delay:{3}";
        // 0x0272EBC0: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Config default channel:{0}, version:{1}, user:{2}, delay:{3}");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Config default channel:{0}, version:{1}, user:{2}, delay:{3}");
        // 0x0272EBC4: MOV x1, x22                | X1 = version;//m1                       
        // 0x0272EBC8: MOV x2, x21                | X2 = user;//m1                          
        // 0x0272EBCC: MOV x3, x20                | X3 = delay;//m1                         
        // 0x0272EBD0: MOV x4, x19                | X4 = X4;//m1                            
        // 0x0272EBD4: BL #0x272ebf0              | BuglyAgent.ConfigDefaultBeforeInit(channel:  null, version:  version, user:  user, delay:  delay);
        BuglyAgent.ConfigDefaultBeforeInit(channel:  null, version:  version, user:  user, delay:  delay);
        // 0x0272EBD8: SUB sp, x29, #0x30         | SP = (1152921509926027712 - 48) = 1152921509926027664 (0x100000013D0C4190);
        // 0x0272EBDC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272EBE0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272EBE4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272EBE8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272EBEC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B978 (41073016), len: 312  VirtAddr: 0x0272B978 RVA: 0x0272B978 token: 100663313 methodIndex: 24281 delegateWrapperIndex: 0 methodInvoker: 0
    public static void DebugLog(string tag, string format, object[] args)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x0272B978: STP x22, x21, [sp, #-0x30]! | stack[1152921509926205360] = ???;  stack[1152921509926205368] = ???;  //  dest_result_addr=1152921509926205360 |  dest_result_addr=1152921509926205368
        // 0x0272B97C: STP x20, x19, [sp, #0x10]  | stack[1152921509926205376] = ???;  stack[1152921509926205384] = ???;  //  dest_result_addr=1152921509926205376 |  dest_result_addr=1152921509926205384
        // 0x0272B980: STP x29, x30, [sp, #0x20]  | stack[1152921509926205392] = ???;  stack[1152921509926205400] = ???;  //  dest_result_addr=1152921509926205392 |  dest_result_addr=1152921509926205400
        // 0x0272B984: ADD x29, sp, #0x20         | X29 = (1152921509926205360 + 32) = 1152921509926205392 (0x100000013D0EF7D0);
        // 0x0272B988: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x0272B98C: LDRB w8, [x22, #0xaa9]     | W8 = (bool)static_value_03743AA9;       
        // 0x0272B990: MOV x20, x3                | X20 = X3;//m1                           
        // 0x0272B994: MOV x21, x2                | X21 = args;//m1                         
        // 0x0272B998: MOV x19, x1                | X19 = format;//m1                       
        // 0x0272B99C: TBNZ w8, #0, #0x272b9b8    | if (static_value_03743AA9 == true) goto label_0;
        // 0x0272B9A0: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x0272B9A4: LDR x8, [x8, #0x818]       | X8 = 0x2B8FE24;                         
        // 0x0272B9A8: LDR w0, [x8]               | W0 = 0x164D;                            
        // 0x0272B9AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x164D, ????);     
        // 0x0272B9B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B9B4: STRB w8, [x22, #0xaa9]     | static_value_03743AA9 = true;            //  dest_result_addr=57948841
        label_0:
        // 0x0272B9B8: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272B9BC: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272B9C0: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_4 = null;
        // 0x0272B9C4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B9C8: TBZ w8, #0, #0x272b9dc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272B9CC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B9D0: CBNZ w8, #0x272b9dc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272B9D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272B9D8: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_4 = null;
        label_2:
        // 0x0272B9DC: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272B9E0: LDRB w8, [x8, #0x68]       | W8 = BuglyAgent._debugMode;             
        // 0x0272B9E4: CBZ w8, #0x272ba20         | if (BuglyAgent._debugMode == false) goto label_3;
        if(BuglyAgent._debugMode == false)
        {
            goto label_3;
        }
        // 0x0272B9E8: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
        // 0x0272B9EC: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
        // 0x0272B9F0: LDR x0, [x22]              | X0 = typeof(System.String);             
        // 0x0272B9F4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272B9F8: TBZ w8, #0, #0x272ba08     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272B9FC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272BA00: CBNZ w8, #0x272ba08        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272BA04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_5:
        // 0x0272BA08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272BA0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272BA10: MOV x1, x21                | X1 = args;//m1                          
        // 0x0272BA14: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_1 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272BA18: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x0272BA1C: TBZ w8, #0, #0x272ba30     | if ((val_1 & 1) == false) goto label_6; 
        if(val_2 == false)
        {
            goto label_6;
        }
        label_3:
        // 0x0272BA20: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272BA24: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272BA28: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272BA2C: RET                        |  return;                                
        return;
        label_6:
        // 0x0272BA30: LDR x0, [x22]              | X0 = typeof(System.String);             
        // 0x0272BA34: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272BA38: TBZ w8, #0, #0x272ba48     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x0272BA3C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272BA40: CBNZ w8, #0x272ba48        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x0272BA44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_8:
        // 0x0272BA48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272BA4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272BA50: MOV x1, x21                | X1 = args;//m1                          
        // 0x0272BA54: MOV x2, x20                | X2 = X3;//m1                            
        // 0x0272BA58: BL #0x18af5dc              | X0 = System.String.Format(format:  0, args:  args);
        string val_3 = System.String.Format(format:  0, args:  args);
        // 0x0272BA5C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x0272BA60: LDR x8, [x8, #0xf50]       | X8 = 1152921504652480512;               
        // 0x0272BA64: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x0272BA68: LDR x8, [x8]               | X8 = typeof(System.Console);            
        // 0x0272BA6C: LDRB w9, [x8, #0x10a]      | W9 = System.Console.__il2cppRuntimeField_10A;
        // 0x0272BA70: TBZ w9, #0, #0x272ba84     | if (System.Console.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x0272BA74: LDR w9, [x8, #0xbc]        | W9 = System.Console.__il2cppRuntimeField_cctor_finished;
        // 0x0272BA78: CBNZ w9, #0x272ba84        | if (System.Console.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0272BA7C: MOV x0, x8                 | X0 = 1152921504652480512 (0x1000000002B85000);//ML01
        // 0x0272BA80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Console), ????);
        label_10:
        // 0x0272BA84: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x0272BA88: LDR x8, [x8, #0x2a0]       | X8 = (string**)(1152921509926193264)("[BuglyAgent] <Debug> - {0} : {1}");
        // 0x0272BA8C: MOV x2, x19                | X2 = format;//m1                        
        // 0x0272BA90: MOV x3, x20                | X3 = val_3;//m1                         
        // 0x0272BA94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272BA98: LDR x1, [x8]               | X1 = "[BuglyAgent] <Debug> - {0} : {1}";
        // 0x0272BA9C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272BAA0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272BAA4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272BAA8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272BAAC: B #0x1ba15dc               | System.Console.WriteLine(format:  0, arg0:  "[BuglyAgent] <Debug> - {0} : {1}", arg1:  format); return;
        System.Console.WriteLine(format:  0, arg0:  "[BuglyAgent] <Debug> - {0} : {1}", arg1:  format);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272EC9C (41086108), len: 244  VirtAddr: 0x0272EC9C RVA: 0x0272EC9C token: 100663314 methodIndex: 24282 delegateWrapperIndex: 0 methodInvoker: 0
    public static void PrintLog(LogSeverity level, string format, object[] args)
    {
        //
        // Disasemble & Code
        //  | 
        LogSeverity val_4;
        // 0x0272EC9C: STP x22, x21, [sp, #-0x30]! | stack[1152921509926415664] = ???;  stack[1152921509926415672] = ???;  //  dest_result_addr=1152921509926415664 |  dest_result_addr=1152921509926415672
        // 0x0272ECA0: STP x20, x19, [sp, #0x10]  | stack[1152921509926415680] = ???;  stack[1152921509926415688] = ???;  //  dest_result_addr=1152921509926415680 |  dest_result_addr=1152921509926415688
        // 0x0272ECA4: STP x29, x30, [sp, #0x20]  | stack[1152921509926415696] = ???;  stack[1152921509926415704] = ???;  //  dest_result_addr=1152921509926415696 |  dest_result_addr=1152921509926415704
        // 0x0272ECA8: ADD x29, sp, #0x20         | X29 = (1152921509926415664 + 32) = 1152921509926415696 (0x100000013D122D50);
        // 0x0272ECAC: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x0272ECB0: LDRB w8, [x22, #0xaaa]     | W8 = (bool)static_value_03743AAA;       
        // 0x0272ECB4: MOV x20, x3                | X20 = X3;//m1                           
        // 0x0272ECB8: MOV x21, x2                | X21 = args;//m1                         
        // 0x0272ECBC: MOV w19, w1                | W19 = format;//m1                       
        // 0x0272ECC0: TBNZ w8, #0, #0x272ecdc    | if (static_value_03743AAA == true) goto label_0;
        // 0x0272ECC4: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x0272ECC8: LDR x8, [x8, #0x5c8]       | X8 = 0x2B8FE4C;                         
        // 0x0272ECCC: LDR w0, [x8]               | W0 = 0x1657;                            
        // 0x0272ECD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1657, ????);     
        // 0x0272ECD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272ECD8: STRB w8, [x22, #0xaaa]     | static_value_03743AAA = true;            //  dest_result_addr=57948842
        label_0:
        // 0x0272ECDC: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
        // 0x0272ECE0: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
        // 0x0272ECE4: LDR x0, [x22]              | X0 = typeof(System.String);             
        // 0x0272ECE8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272ECEC: TBZ w8, #0, #0x272ecfc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272ECF0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272ECF4: CBNZ w8, #0x272ecfc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272ECF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_2:
        // 0x0272ECFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272ED00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272ED04: MOV x1, x21                | X1 = args;//m1                          
        // 0x0272ED08: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_1 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272ED0C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x0272ED10: TBZ w8, #0, #0x272ed24     | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x0272ED14: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272ED18: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272ED1C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272ED20: RET                        |  return;                                
        return;
        label_3:
        // 0x0272ED24: LDR x0, [x22]              | X0 = typeof(System.String);             
        // 0x0272ED28: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272ED2C: TBZ w8, #0, #0x272ed3c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272ED30: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272ED34: CBNZ w8, #0x272ed3c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272ED38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_5:
        // 0x0272ED3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272ED40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272ED44: MOV x1, x21                | X1 = args;//m1                          
        // 0x0272ED48: MOV x2, x20                | X2 = X3;//m1                            
        // 0x0272ED4C: BL #0x18af5dc              | X0 = System.String.Format(format:  0, args:  args);
        string val_3 = System.String.Format(format:  0, args:  args);
        // 0x0272ED50: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272ED54: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272ED58: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x0272ED5C: LDR x8, [x8]               | X8 = typeof(BuglyAgent);                
        // 0x0272ED60: LDRB w9, [x8, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272ED64: TBZ w9, #0, #0x272ed78     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272ED68: LDR w9, [x8, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272ED6C: CBNZ w9, #0x272ed78        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272ED70: MOV x0, x8                 | X0 = 1152921504776761344 (0x100000000A20B000);//ML01
        val_4 = null;
        // 0x0272ED74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_7:
        // 0x0272ED78: MOV w1, w19                | W1 = format;//m1                        
        // 0x0272ED7C: MOV x2, x20                | X2 = val_3;//m1                         
        // 0x0272ED80: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272ED84: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272ED88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272ED8C: B #0x272ed90               | BuglyAgent.LogRecord(level:  val_4 = null, message:  format); return;
        BuglyAgent.LogRecord(level:  val_4, message:  format);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F05C (41087068), len: 508  VirtAddr: 0x0272F05C RVA: 0x0272F05C token: 100663315 methodIndex: 24283 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.AndroidJavaClass get_GameAgent()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.AndroidJavaClass val_2;
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x0272F05C: STP x22, x21, [sp, #-0x30]! | stack[1152921509926581008] = ???;  stack[1152921509926581016] = ???;  //  dest_result_addr=1152921509926581008 |  dest_result_addr=1152921509926581016
        // 0x0272F060: STP x20, x19, [sp, #0x10]  | stack[1152921509926581024] = ???;  stack[1152921509926581032] = ???;  //  dest_result_addr=1152921509926581024 |  dest_result_addr=1152921509926581032
        // 0x0272F064: STP x29, x30, [sp, #0x20]  | stack[1152921509926581040] = ???;  stack[1152921509926581048] = ???;  //  dest_result_addr=1152921509926581040 |  dest_result_addr=1152921509926581048
        // 0x0272F068: ADD x29, sp, #0x20         | X29 = (1152921509926581008 + 32) = 1152921509926581040 (0x100000013D14B330);
        // 0x0272F06C: SUB sp, sp, #0x10          | SP = (1152921509926581008 - 16) = 1152921509926580992 (0x100000013D14B300);
        // 0x0272F070: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F074: LDRB w8, [x19, #0xaab]     | W8 = (bool)static_value_03743AAB;       
        // 0x0272F078: TBNZ w8, #0, #0x272f094    | if (static_value_03743AAB == true) goto label_0;
        // 0x0272F07C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x0272F080: LDR x8, [x8, #0x138]       | X8 = 0x2B8FE34;                         
        // 0x0272F084: LDR w0, [x8]               | W0 = 0x1651;                            
        // 0x0272F088: BL #0x2782188              | X0 = sub_2782188( ?? 0x1651, ????);     
        // 0x0272F08C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F090: STRB w8, [x19, #0xaab]     | static_value_03743AAB = true;            //  dest_result_addr=57948843
        label_0:
        // 0x0272F094: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272F098: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272F09C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272F0A0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F0A4: TBZ w8, #0, #0x272f0b8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272F0A8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F0AC: CBNZ w8, #0x272f0b8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272F0B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F0B4: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_2:
        // 0x0272F0B8: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F0BC: LDR x9, [x8, #0x18]        | X9 = BuglyAgent._gameAgentClass;        
        // 0x0272F0C0: CBNZ x9, #0x272f114        | if (BuglyAgent._gameAgentClass != null) goto label_3;
        if(BuglyAgent._gameAgentClass != null)
        {
            goto label_3;
        }
        // 0x0272F0C4: LDRB w9, [x0, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F0C8: TBZ w9, #0, #0x272f0e0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272F0CC: LDR w9, [x0, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F0D0: CBNZ w9, #0x272f0e0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272F0D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F0D8: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F0DC: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        label_5:
        // 0x0272F0E0: LDR x19, [x8]              | X19 = BuglyAgent.GAME_AGENT_CLASS;      
        // 0x0272F0E4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0272F0E8: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x0272F0EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x0272F0F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x0272F0F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272F0F8: MOV x1, x19                | X1 = BuglyAgent.GAME_AGENT_CLASS;//m1   
        // 0x0272F0FC: MOV x20, x0                | X20 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x0272F100: BL #0x20b9834              | .ctor(className:  BuglyAgent.__il2cppRuntimeField_static_fields);
        val_1 = new UnityEngine.AndroidJavaClass(className:  BuglyAgent.__il2cppRuntimeField_static_fields);
        // 0x0272F104: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F108: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F10C: STR x20, [x8, #0x18]       | BuglyAgent._gameAgentClass = typeof(UnityEngine.AndroidJavaClass);  //  dest_result_addr=1152921504776765464
        BuglyAgent._gameAgentClass = val_1;
        // 0x0272F110: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_3:
        // 0x0272F114: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F118: TBZ w8, #0, #0x272f12c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272F11C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F120: CBNZ w8, #0x272f12c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272F124: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F128: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_7:
        // 0x0272F12C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F130: LDRB w9, [x8, #0x10]       | W9 = BuglyAgent.hasSetGameType;         
        // 0x0272F134: CBNZ w9, #0x272f224        | if (BuglyAgent.hasSetGameType == true) goto label_8;
        if(BuglyAgent.hasSetGameType == true)
        {
            goto label_8;
        }
        // 0x0272F138: LDRB w9, [x0, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F13C: TBZ w9, #0, #0x272f154     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x0272F140: LDR w9, [x0, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F144: CBNZ w9, #0x272f154        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0272F148: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F14C: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F150: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        label_10:
        // 0x0272F154: LDR x19, [x8, #0x18]       | X19 = typeof(UnityEngine.AndroidJavaClass);
        val_2 = BuglyAgent._gameAgentClass;
        // 0x0272F158: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272F15C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272F160: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272F164: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F168: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272F16C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272F170: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F174: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272F178: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F17C: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F180: ADD x1, sp, #0xc           | X1 = (1152921509926580992 + 12) = 1152921509926581004 (0x100000013D14B30C);
        // 0x0272F184: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F188: LDR w9, [x8, #0xc]         | W9 = BuglyAgent.GAME_TYPE_UNITY;        
        // 0x0272F18C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272F190: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x0272F194: STR w9, [sp, #0xc]         | stack[1152921509926581004] = BuglyAgent.GAME_TYPE_UNITY;  //  dest_result_addr=1152921509926581004
        // 0x0272F198: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x0272F19C: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x0272F1A0: BL #0x27bc028              | X0 = 1152921509926625056 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), BuglyAgent.GAME_TYPE_UNITY);
        // 0x0272F1A4: MOV x21, x0                | X21 = 1152921509926625056 (0x100000013D155F20);//ML01
        // 0x0272F1A8: CBNZ x20, #0x272f1b0       | if ( != null) goto label_11;            
        if(null != null)
        {
            goto label_11;
        }
        // 0x0272F1AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        label_11:
        // 0x0272F1B0: CBZ x21, #0x272f1d4        | if (BuglyAgent.GAME_TYPE_UNITY == 0) goto label_13;
        if(BuglyAgent.GAME_TYPE_UNITY == 0)
        {
            goto label_13;
        }
        // 0x0272F1B4: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F1B8: MOV x0, x21                | X0 = 1152921509926625056 (0x100000013D155F20);//ML01
        // 0x0272F1BC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F1C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        // 0x0272F1C4: CBNZ x0, #0x272f1d4        | if (BuglyAgent.GAME_TYPE_UNITY != 0) goto label_13;
        if(BuglyAgent.GAME_TYPE_UNITY != 0)
        {
            goto label_13;
        }
        // 0x0272F1C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        // 0x0272F1CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F1D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        label_13:
        // 0x0272F1D4: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F1D8: CBNZ w8, #0x272f1e8        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_14;
        // 0x0272F1DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        // 0x0272F1E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F1E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        label_14:
        // 0x0272F1E8: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = BuglyAgent.GAME_TYPE_UNITY; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000001;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = BuglyAgent.GAME_TYPE_UNITY;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435457;
        // 0x0272F1EC: CBNZ x19, #0x272f1f4       | if ( != 0) goto label_15;               
        if(null != 0)
        {
            goto label_15;
        }
        // 0x0272F1F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BuglyAgent.GAME_TYPE_UNITY, ????);
        label_15:
        // 0x0272F1F4: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x0272F1F8: LDR x8, [x8, #0x758]       | X8 = (string**)(1152921509926568960)("setGameType");
        // 0x0272F1FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272F200: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x0272F204: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F208: LDR x1, [x8]               | X1 = "setGameType";                     
        // 0x0272F20C: BL #0x20bdcfc              | CallStatic(methodName:  "setGameType", args:  null);
        CallStatic(methodName:  "setGameType", args:  null);
        // 0x0272F210: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F214: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x0272F218: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F21C: STRB w9, [x8, #0x10]       | BuglyAgent.hasSetGameType = true;        //  dest_result_addr=1152921504776765456
        BuglyAgent.hasSetGameType = true;
        // 0x0272F220: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_8:
        // 0x0272F224: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F228: TBZ w8, #0, #0x272f23c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x0272F22C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F230: CBNZ w8, #0x272f23c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x0272F234: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F238: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_17:
        // 0x0272F23C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F240: LDR x0, [x8, #0x18]        | X0 = typeof(UnityEngine.AndroidJavaClass);
        // 0x0272F244: SUB sp, x29, #0x20         | SP = (1152921509926581040 - 32) = 1152921509926581008 (0x100000013D14B310);
        // 0x0272F248: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272F24C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272F250: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272F254: RET                        |  return (UnityEngine.AndroidJavaClass)typeof(UnityEngine.AndroidJavaClass);
        return BuglyAgent._gameAgentClass;
        //  |  // // {name=val_0, type=UnityEngine.AndroidJavaClass, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0272EBF0 (41085936), len: 172  VirtAddr: 0x0272EBF0 RVA: 0x0272EBF0 token: 100663316 methodIndex: 24284 delegateWrapperIndex: 0 methodInvoker: 0
    private static void ConfigDefaultBeforeInit(string channel, string version, string user, long delay)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x0272EBF0: STP x24, x23, [sp, #-0x40]! | stack[1152921509926709376] = ???;  stack[1152921509926709384] = ???;  //  dest_result_addr=1152921509926709376 |  dest_result_addr=1152921509926709384
        // 0x0272EBF4: STP x22, x21, [sp, #0x10]  | stack[1152921509926709392] = ???;  stack[1152921509926709400] = ???;  //  dest_result_addr=1152921509926709392 |  dest_result_addr=1152921509926709400
        // 0x0272EBF8: STP x20, x19, [sp, #0x20]  | stack[1152921509926709408] = ???;  stack[1152921509926709416] = ???;  //  dest_result_addr=1152921509926709408 |  dest_result_addr=1152921509926709416
        // 0x0272EBFC: STP x29, x30, [sp, #0x30]  | stack[1152921509926709424] = ???;  stack[1152921509926709432] = ???;  //  dest_result_addr=1152921509926709424 |  dest_result_addr=1152921509926709432
        // 0x0272EC00: ADD x29, sp, #0x30         | X29 = (1152921509926709376 + 48) = 1152921509926709424 (0x100000013D16A8B0);
        // 0x0272EC04: ADRP x23, #0x3743000       | X23 = 57946112 (0x3743000);             
        // 0x0272EC08: LDRB w8, [x23, #0xaac]     | W8 = (bool)static_value_03743AAC;       
        // 0x0272EC0C: MOV x19, x4                | X19 = X4;//m1                           
        // 0x0272EC10: MOV x20, x3                | X20 = delay;//m1                        
        // 0x0272EC14: MOV x21, x2                | X21 = user;//m1                         
        // 0x0272EC18: MOV x22, x1                | X22 = version;//m1                      
        // 0x0272EC1C: TBNZ w8, #0, #0x272ec38    | if (static_value_03743AAC == true) goto label_0;
        // 0x0272EC20: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x0272EC24: LDR x8, [x8, #0x9b0]       | X8 = 0x2B8FE20;                         
        // 0x0272EC28: LDR w0, [x8]               | W0 = 0x164C;                            
        // 0x0272EC2C: BL #0x2782188              | X0 = sub_2782188( ?? 0x164C, ????);     
        // 0x0272EC30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272EC34: STRB w8, [x23, #0xaac]     | static_value_03743AAC = true;            //  dest_result_addr=57948844
        label_0:
        // 0x0272EC38: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
        // 0x0272EC3C: LDR x23, [x23, #0x938]     | X23 = 1152921504776761344;              
        // 0x0272EC40: LDR x0, [x23]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272EC44: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272EC48: TBZ w8, #0, #0x272ec5c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272EC4C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272EC50: CBNZ w8, #0x272ec5c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272EC54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272EC58: LDR x0, [x23]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_2:
        // 0x0272EC5C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272EC60: STR x22, [x8, #0x20]       | BuglyAgent._configChannel = version;     //  dest_result_addr=1152921504776765472
        BuglyAgent._configChannel = version;
        // 0x0272EC64: LDR x8, [x23]              | X8 = typeof(BuglyAgent);                
        // 0x0272EC68: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272EC6C: STR x21, [x8, #0x28]       | BuglyAgent._configVersion = user;        //  dest_result_addr=1152921504776765480
        BuglyAgent._configVersion = user;
        // 0x0272EC70: LDR x8, [x23]              | X8 = typeof(BuglyAgent);                
        // 0x0272EC74: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272EC78: STR x20, [x8, #0x30]       | BuglyAgent._configUser = delay;          //  dest_result_addr=1152921504776765488
        BuglyAgent._configUser = delay;
        // 0x0272EC7C: LDR x8, [x23]              | X8 = typeof(BuglyAgent);                
        // 0x0272EC80: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272EC84: STR x19, [x8, #0x38]       | BuglyAgent._configDelayTime = X4;        //  dest_result_addr=1152921504776765496
        BuglyAgent._configDelayTime = X4;
        // 0x0272EC88: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272EC8C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272EC90: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272EC94: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272EC98: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F258 (41087576), len: 432  VirtAddr: 0x0272F258 RVA: 0x0272F258 token: 100663317 methodIndex: 24285 delegateWrapperIndex: 0 methodInvoker: 0
    private static void ConfigCrashReporterPackage()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        // 0x0272F258: STP x22, x21, [sp, #-0x30]! | stack[1152921509926837888] = ???;  stack[1152921509926837896] = ???;  //  dest_result_addr=1152921509926837888 |  dest_result_addr=1152921509926837896
        // 0x0272F25C: STP x20, x19, [sp, #0x10]  | stack[1152921509926837904] = ???;  stack[1152921509926837912] = ???;  //  dest_result_addr=1152921509926837904 |  dest_result_addr=1152921509926837912
        // 0x0272F260: STP x29, x30, [sp, #0x20]  | stack[1152921509926837920] = ???;  stack[1152921509926837928] = ???;  //  dest_result_addr=1152921509926837920 |  dest_result_addr=1152921509926837928
        // 0x0272F264: ADD x29, sp, #0x20         | X29 = (1152921509926837888 + 32) = 1152921509926837920 (0x100000013D189EA0);
        // 0x0272F268: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F26C: LDRB w8, [x19, #0xaad]     | W8 = (bool)static_value_03743AAD;       
        // 0x0272F270: TBNZ w8, #0, #0x272f28c    | if (static_value_03743AAD == true) goto label_0;
        // 0x0272F274: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x0272F278: LDR x8, [x8, #0xf00]       | X8 = 0x2B8FE14;                         
        // 0x0272F27C: LDR w0, [x8]               | W0 = 0x1649;                            
        // 0x0272F280: BL #0x2782188              | X0 = sub_2782188( ?? 0x1649, ????);     
        // 0x0272F284: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F288: STRB w8, [x19, #0xaad]     | static_value_03743AAD = true;            //  dest_result_addr=57948845
        label_0:
        // 0x0272F28C: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272F290: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272F294: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272F298: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F29C: TBZ w8, #0, #0x272f2b0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272F2A0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F2A4: CBNZ w8, #0x272f2b0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272F2A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F2AC: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_2:
        // 0x0272F2B0: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F2B4: LDRB w8, [x8, #0x40]       | W8 = BuglyAgent._configCrashReporterPackage;
        // 0x0272F2B8: CBNZ w8, #0x272f380        | if (BuglyAgent._configCrashReporterPackage == true) goto label_3;
        if(BuglyAgent._configCrashReporterPackage == true)
        {
            goto label_3;
        }
        // 0x0272F2BC: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F2C0: TBZ w8, #0, #0x272f2d0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272F2C4: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F2C8: CBNZ w8, #0x272f2d0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272F2CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272F2D0: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_1 = BuglyAgent.GameAgent;
        // 0x0272F2D4: MOV x19, x0                | X19 = val_1;//m1                        
        val_2 = val_1;
        // 0x0272F2D8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272F2DC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272F2E0: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272F2E4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F2E8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272F2EC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272F2F0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F2F4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272F2F8: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F2FC: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F300: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F304: LDR x21, [x8, #0x60]       | X21 = BuglyAgent._crashReporterPackage; 
        // 0x0272F308: CBNZ x20, #0x272f310       | if ( != null) goto label_6;             
        if(null != null)
        {
            goto label_6;
        }
        // 0x0272F30C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_6:
        // 0x0272F310: CBZ x21, #0x272f334        | if (BuglyAgent._crashReporterPackage == null) goto label_8;
        if(BuglyAgent._crashReporterPackage == null)
        {
            goto label_8;
        }
        // 0x0272F314: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F318: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F31C: MOV x0, x21                | X0 = BuglyAgent._crashReporterPackage;//m1
        // 0x0272F320: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent._crashReporterPackage, ????);
        // 0x0272F324: CBNZ x0, #0x272f334        | if (BuglyAgent._crashReporterPackage != null) goto label_8;
        if(BuglyAgent._crashReporterPackage != null)
        {
            goto label_8;
        }
        // 0x0272F328: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent._crashReporterPackage, ????);
        // 0x0272F32C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F330: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._crashReporterPackage, ????);
        label_8:
        // 0x0272F334: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F338: CBNZ w8, #0x272f348        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_9;
        // 0x0272F33C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent._crashReporterPackage, ????);
        // 0x0272F340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F344: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._crashReporterPackage, ????);
        label_9:
        // 0x0272F348: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = BuglyAgent._crashReporterPackage;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = BuglyAgent._crashReporterPackage;
        // 0x0272F34C: CBNZ x19, #0x272f354       | if (val_1 != null) goto label_10;       
        if(val_2 != null)
        {
            goto label_10;
        }
        // 0x0272F350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BuglyAgent._crashReporterPackage, ????);
        label_10:
        // 0x0272F354: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x0272F358: LDR x8, [x8, #0xfb0]       | X8 = (string**)(1152921509926825824)("setSdkPackageName");
        // 0x0272F35C: LDR x1, [x8]               | X1 = "setSdkPackageName";               
        // 0x0272F360: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272F364: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x0272F368: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F36C: BL #0x20bdcfc              | val_1.CallStatic(methodName:  "setSdkPackageName", args:  null);
        val_2.CallStatic(methodName:  "setSdkPackageName", args:  null);
        // 0x0272F370: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272F374: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x0272F378: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F37C: STRB w9, [x8, #0x40]       | BuglyAgent._configCrashReporterPackage = true;  //  dest_result_addr=1152921504776765504
        BuglyAgent._configCrashReporterPackage = true;
        label_3:
        // 0x0272F380: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272F384: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272F388: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272F38C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272BAB0 (41073328), len: 784  VirtAddr: 0x0272BAB0 RVA: 0x0272BAB0 token: 100663318 methodIndex: 24286 delegateWrapperIndex: 0 methodInvoker: 0
    private static void InitBuglyAgent(string appId)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        long val_5;
        // 0x0272BAB0: STP x22, x21, [sp, #-0x30]! | stack[1152921509926966384] = ???;  stack[1152921509926966392] = ???;  //  dest_result_addr=1152921509926966384 |  dest_result_addr=1152921509926966392
        // 0x0272BAB4: STP x20, x19, [sp, #0x10]  | stack[1152921509926966400] = ???;  stack[1152921509926966408] = ???;  //  dest_result_addr=1152921509926966400 |  dest_result_addr=1152921509926966408
        // 0x0272BAB8: STP x29, x30, [sp, #0x20]  | stack[1152921509926966416] = ???;  stack[1152921509926966424] = ???;  //  dest_result_addr=1152921509926966416 |  dest_result_addr=1152921509926966424
        // 0x0272BABC: ADD x29, sp, #0x20         | X29 = (1152921509926966384 + 32) = 1152921509926966416 (0x100000013D1A9490);
        // 0x0272BAC0: SUB sp, sp, #0x10          | SP = (1152921509926966384 - 16) = 1152921509926966368 (0x100000013D1A9460);
        // 0x0272BAC4: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272BAC8: LDRB w8, [x19, #0xaae]     | W8 = (bool)static_value_03743AAE;       
        // 0x0272BACC: MOV x21, x1                | X21 = X1;//m1                           
        val_5 = X1;
        // 0x0272BAD0: TBNZ w8, #0, #0x272baec    | if (static_value_03743AAE == true) goto label_0;
        // 0x0272BAD4: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x0272BAD8: LDR x8, [x8, #0x6f8]       | X8 = 0x2B8FE40;                         
        // 0x0272BADC: LDR w0, [x8]               | W0 = 0x1654;                            
        // 0x0272BAE0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1654, ????);     
        // 0x0272BAE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272BAE8: STRB w8, [x19, #0xaae]     | static_value_03743AAE = true;            //  dest_result_addr=57948846
        label_0:
        // 0x0272BAEC: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272BAF0: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272BAF4: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272BAF8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BAFC: TBZ w8, #0, #0x272bb0c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272BB00: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BB04: CBNZ w8, #0x272bb0c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272BB08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272BB0C: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272BB10: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x0272BB14: TBNZ w8, #0, #0x272bd3c    | if ((val_1 & 1) == true) goto label_3;  
        if(val_2 == true)
        {
            goto label_3;
        }
        // 0x0272BB18: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272BB1C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BB20: TBZ w8, #0, #0x272bb30     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272BB24: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BB28: CBNZ w8, #0x272bb30        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272BB2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272BB30: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272BB34: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272BB38: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BB3C: TBZ w8, #0, #0x272bb4c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272BB40: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BB44: CBNZ w8, #0x272bb4c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272BB48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_7:
        // 0x0272BB4C: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_3 = BuglyAgent.GameAgent;
        // 0x0272BB50: MOV x19, x0                | X19 = val_3;//m1                        
        val_4 = val_3;
        // 0x0272BB54: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272BB58: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272BB5C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272BB60: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BB64: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272BB68: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x0272BB6C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BB70: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272BB74: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BB78: CBNZ x20, #0x272bb80       | if ( != null) goto label_8;             
        if(null != null)
        {
            goto label_8;
        }
        // 0x0272BB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_8:
        // 0x0272BB80: CBZ x21, #0x272bba4        | if (X1 == 0) goto label_10;             
        if(val_5 == 0)
        {
            goto label_10;
        }
        // 0x0272BB84: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272BB88: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272BB8C: MOV x0, x21                | X0 = X1;//m1                            
        // 0x0272BB90: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
        // 0x0272BB94: CBNZ x0, #0x272bba4        | if (X1 != 0) goto label_10;             
        if(val_5 != 0)
        {
            goto label_10;
        }
        // 0x0272BB98: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
        // 0x0272BB9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BBA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_10:
        // 0x0272BBA4: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272BBA8: CBNZ w8, #0x272bbb8        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_11;
        // 0x0272BBAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
        // 0x0272BBB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BBB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_11:
        // 0x0272BBB8: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_5;
        // 0x0272BBBC: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272BBC0: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BBC4: LDR x21, [x8, #0x20]       | X21 = BuglyAgent._configChannel;        
        // 0x0272BBC8: CBZ x21, #0x272bbec        | if (BuglyAgent._configChannel == null) goto label_13;
        if(BuglyAgent._configChannel == null)
        {
            goto label_13;
        }
        // 0x0272BBCC: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272BBD0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272BBD4: MOV x0, x21                | X0 = BuglyAgent._configChannel;//m1     
        // 0x0272BBD8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent._configChannel, ????);
        // 0x0272BBDC: CBNZ x0, #0x272bbec        | if (BuglyAgent._configChannel != null) goto label_13;
        if(BuglyAgent._configChannel != null)
        {
            goto label_13;
        }
        // 0x0272BBE0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent._configChannel, ????);
        // 0x0272BBE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BBE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configChannel, ????);
        label_13:
        // 0x0272BBEC: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272BBF0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272BBF4: B.HI #0x272bc04            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_14;
        // 0x0272BBF8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent._configChannel, ????);
        // 0x0272BBFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BC00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configChannel, ????);
        label_14:
        // 0x0272BC04: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = BuglyAgent._configChannel;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = BuglyAgent._configChannel;
        // 0x0272BC08: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272BC0C: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BC10: LDR x21, [x8, #0x28]       | X21 = BuglyAgent._configVersion;        
        // 0x0272BC14: CBZ x21, #0x272bc38        | if (BuglyAgent._configVersion == null) goto label_16;
        if(BuglyAgent._configVersion == null)
        {
            goto label_16;
        }
        // 0x0272BC18: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272BC1C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272BC20: MOV x0, x21                | X0 = BuglyAgent._configVersion;//m1     
        // 0x0272BC24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent._configVersion, ????);
        // 0x0272BC28: CBNZ x0, #0x272bc38        | if (BuglyAgent._configVersion != null) goto label_16;
        if(BuglyAgent._configVersion != null)
        {
            goto label_16;
        }
        // 0x0272BC2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent._configVersion, ????);
        // 0x0272BC30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BC34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configVersion, ????);
        label_16:
        // 0x0272BC38: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272BC3C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x0272BC40: B.HI #0x272bc50            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_17;
        // 0x0272BC44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent._configVersion, ????);
        // 0x0272BC48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BC4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configVersion, ????);
        label_17:
        // 0x0272BC50: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = BuglyAgent._configVersion;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = BuglyAgent._configVersion;
        // 0x0272BC54: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272BC58: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BC5C: LDR x21, [x8, #0x30]       | X21 = BuglyAgent._configUser;           
        // 0x0272BC60: CBZ x21, #0x272bc84        | if (BuglyAgent._configUser == null) goto label_19;
        if(BuglyAgent._configUser == null)
        {
            goto label_19;
        }
        // 0x0272BC64: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272BC68: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272BC6C: MOV x0, x21                | X0 = BuglyAgent._configUser;//m1        
        // 0x0272BC70: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent._configUser, ????);
        // 0x0272BC74: CBNZ x0, #0x272bc84        | if (BuglyAgent._configUser != null) goto label_19;
        if(BuglyAgent._configUser != null)
        {
            goto label_19;
        }
        // 0x0272BC78: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent._configUser, ????);
        // 0x0272BC7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BC80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configUser, ????);
        label_19:
        // 0x0272BC84: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272BC88: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x0272BC8C: B.HI #0x272bc9c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_20;
        // 0x0272BC90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent._configUser, ????);
        // 0x0272BC94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BC98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configUser, ????);
        label_20:
        // 0x0272BC9C: STR x21, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = BuglyAgent._configUser;  //  dest_result_addr=1152921504954501320
        typeof(System.Object[]).__il2cppRuntimeField_38 = BuglyAgent._configUser;
        // 0x0272BCA0: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272BCA4: ADRP x9, #0x3632000        | X9 = 56827904 (0x3632000);              
        // 0x0272BCA8: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BCAC: LDR x8, [x8, #0x38]        | X8 = BuglyAgent._configDelayTime;       
        // 0x0272BCB0: LDR x9, [x9, #0x4b0]       | X9 = 1152921504607592448;               
        // 0x0272BCB4: STR x8, [sp, #8]           | stack[1152921509926966376] = BuglyAgent._configDelayTime;  //  dest_result_addr=1152921509926966376
        // 0x0272BCB8: LDR x0, [x9]               | X0 = typeof(System.Int64);              
        // 0x0272BCBC: ADD x1, sp, #8             | X1 = (1152921509926966368 + 8) = 1152921509926966376 (0x100000013D1A9468);
        // 0x0272BCC0: BL #0x27bc028              | X0 = 1152921509927018624 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), BuglyAgent._configDelayTime);
        // 0x0272BCC4: MOV x21, x0                | X21 = 1152921509927018624 (0x100000013D1B6080);//ML01
        val_5 = BuglyAgent._configDelayTime;
        // 0x0272BCC8: CBZ x21, #0x272bcec        | if (BuglyAgent._configDelayTime == 0) goto label_22;
        if(BuglyAgent._configDelayTime == 0)
        {
            goto label_22;
        }
        // 0x0272BCCC: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272BCD0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272BCD4: MOV x0, x21                | X0 = 1152921509927018624 (0x100000013D1B6080);//ML01
        // 0x0272BCD8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent._configDelayTime, ????);
        // 0x0272BCDC: CBNZ x0, #0x272bcec        | if (BuglyAgent._configDelayTime != 0) goto label_22;
        if(BuglyAgent._configDelayTime != 0)
        {
            goto label_22;
        }
        // 0x0272BCE0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent._configDelayTime, ????);
        // 0x0272BCE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BCE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configDelayTime, ????);
        label_22:
        // 0x0272BCEC: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272BCF0: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x0272BCF4: B.HI #0x272bd04            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_23;
        // 0x0272BCF8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent._configDelayTime, ????);
        // 0x0272BCFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BD00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent._configDelayTime, ????);
        label_23:
        // 0x0272BD04: STR x21, [x20, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = BuglyAgent._configDelayTime;  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = val_5;
        // 0x0272BD08: CBNZ x19, #0x272bd10       | if (val_3 != null) goto label_24;       
        if(val_4 != null)
        {
            goto label_24;
        }
        // 0x0272BD0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BuglyAgent._configDelayTime, ????);
        label_24:
        // 0x0272BD10: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x0272BD14: LDR x8, [x8, #0x680]       | X8 = (string**)(1152921509926954320)("initCrashReport");
        // 0x0272BD18: LDR x1, [x8]               | X1 = "initCrashReport";                 
        // 0x0272BD1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272BD20: MOV x0, x19                | X0 = val_3;//m1                         
        // 0x0272BD24: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BD28: BL #0x20bdcfc              | val_3.CallStatic(methodName:  "initCrashReport", args:  null);
        val_4.CallStatic(methodName:  "initCrashReport", args:  null);
        // 0x0272BD2C: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272BD30: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x0272BD34: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BD38: STRB w9, [x8, #0x50]       | BuglyAgent._isInitialized = true;        //  dest_result_addr=1152921504776765520
        BuglyAgent._isInitialized = true;
        label_3:
        // 0x0272BD3C: SUB sp, x29, #0x20         | SP = (1152921509926966416 - 32) = 1152921509926966384 (0x100000013D1A9470);
        // 0x0272BD40: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272BD44: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272BD48: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272BD4C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E764 (41084772), len: 444  VirtAddr: 0x0272E764 RVA: 0x0272E764 token: 100663319 methodIndex: 24287 delegateWrapperIndex: 0 methodInvoker: 0
    private static void EnableDebugMode(bool enable)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x0272E764: STP x22, x21, [sp, #-0x30]! | stack[1152921509927098960] = ???;  stack[1152921509927098968] = ???;  //  dest_result_addr=1152921509927098960 |  dest_result_addr=1152921509927098968
        // 0x0272E768: STP x20, x19, [sp, #0x10]  | stack[1152921509927098976] = ???;  stack[1152921509927098984] = ???;  //  dest_result_addr=1152921509927098976 |  dest_result_addr=1152921509927098984
        // 0x0272E76C: STP x29, x30, [sp, #0x20]  | stack[1152921509927098992] = ???;  stack[1152921509927099000] = ???;  //  dest_result_addr=1152921509927098992 |  dest_result_addr=1152921509927099000
        // 0x0272E770: ADD x29, sp, #0x20         | X29 = (1152921509927098960 + 32) = 1152921509927098992 (0x100000013D1C9A70);
        // 0x0272E774: SUB sp, sp, #0x10          | SP = (1152921509927098960 - 16) = 1152921509927098944 (0x100000013D1C9A40);
        // 0x0272E778: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272E77C: LDRB w8, [x20, #0xaaf]     | W8 = (bool)static_value_03743AAF;       
        // 0x0272E780: MOV w19, w1                | W19 = W1;//m1                           
        // 0x0272E784: TBNZ w8, #0, #0x272e7a0    | if (static_value_03743AAF == true) goto label_0;
        // 0x0272E788: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x0272E78C: LDR x8, [x8, #0x88]        | X8 = 0x2B8FE28;                         
        // 0x0272E790: LDR w0, [x8]               | W0 = 0x164E;                            
        // 0x0272E794: BL #0x2782188              | X0 = sub_2782188( ?? 0x164E, ????);     
        // 0x0272E798: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E79C: STRB w8, [x20, #0xaaf]     | static_value_03743AAF = true;            //  dest_result_addr=57948847
        label_0:
        // 0x0272E7A0: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272E7A4: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272E7A8: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272E7AC: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E7B0: TBZ w8, #0, #0x272e7c4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E7B4: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E7B8: CBNZ w8, #0x272e7c4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E7BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272E7C0: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_2:
        // 0x0272E7C4: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272E7C8: AND w21, w19, #1           | W21 = (W1 & 1);                         
        bool val_1 = W1 & 1;
        // 0x0272E7CC: STRB w21, [x8, #0x68]      | BuglyAgent._debugMode = (W1 & 1);        //  dest_result_addr=1152921504776765544
        BuglyAgent._debugMode = val_1;
        // 0x0272E7D0: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272E7D4: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272E7D8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E7DC: TBZ w8, #0, #0x272e7ec     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272E7E0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E7E4: CBNZ w8, #0x272e7ec        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272E7E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_4:
        // 0x0272E7EC: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_2 = BuglyAgent.GameAgent;
        // 0x0272E7F0: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x0272E7F4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272E7F8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272E7FC: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272E800: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E804: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272E808: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272E80C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E810: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272E814: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E818: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x0272E81C: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x0272E820: STRB w21, [sp, #0xf]       | stack[1152921509927098959] = (W1 & 1);   //  dest_result_addr=1152921509927098959
        // 0x0272E824: LDR x0, [x8]               | X0 = typeof(System.Boolean);            
        // 0x0272E828: ADD x1, sp, #0xf           | X1 = (1152921509927098944 + 15) = 1152921509927098959 (0x100000013D1C9A4F);
        // 0x0272E82C: BL #0x27bc028              | X0 = 1152921509927147104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (W1 & 1));
        // 0x0272E830: MOV x21, x0                | X21 = 1152921509927147104 (0x100000013D1D5660);//ML01
        // 0x0272E834: CBNZ x20, #0x272e83c       | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x0272E838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (W1 & 1), ????);   
        label_5:
        // 0x0272E83C: CBZ x21, #0x272e860        | if ((W1 & 1) == false) goto label_7;    
        if(val_1 == false)
        {
            goto label_7;
        }
        // 0x0272E840: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272E844: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E848: MOV x0, x21                | X0 = 1152921509927147104 (0x100000013D1D5660);//ML01
        // 0x0272E84C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (W1 & 1), ????);   
        // 0x0272E850: CBNZ x0, #0x272e860        | if ((W1 & 1) == true) goto label_7;     
        if(val_1 == true)
        {
            goto label_7;
        }
        // 0x0272E854: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (W1 & 1), ????);   
        // 0x0272E858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E85C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (W1 & 1), ????);   
        label_7:
        // 0x0272E860: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E864: CBNZ w8, #0x272e874        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x0272E868: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (W1 & 1), ????);   
        // 0x0272E86C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E870: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (W1 & 1), ????);   
        label_8:
        // 0x0272E874: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = (W1 & 1); typeof(System.Object[]).__il2cppRuntimeField_21 = 0x100000013D1D56;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501297
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_1;
        typeof(System.Object[]).__il2cppRuntimeField_21 = 20782422;
        // 0x0272E878: CBNZ x19, #0x272e880       | if (val_2 != null) goto label_9;        
        if(val_2 != null)
        {
            goto label_9;
        }
        // 0x0272E87C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (W1 & 1), ????);   
        label_9:
        // 0x0272E880: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x0272E884: LDR x8, [x8, #0x4f0]       | X8 = (string**)(1152921509927086912)("setLogEnable");
        // 0x0272E888: LDR x1, [x8]               | X1 = "setLogEnable";                    
        // 0x0272E88C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272E890: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x0272E894: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E898: BL #0x20bdcfc              | val_2.CallStatic(methodName:  "setLogEnable", args:  null);
        val_2.CallStatic(methodName:  "setLogEnable", args:  null);
        // 0x0272E89C: SUB sp, x29, #0x20         | SP = (1152921509927098992 - 32) = 1152921509927098960 (0x100000013D1C9A50);
        // 0x0272E8A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E8A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E8A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E8AC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272DE94 (41082516), len: 400  VirtAddr: 0x0272DE94 RVA: 0x0272DE94 token: 100663320 methodIndex: 24288 delegateWrapperIndex: 0 methodInvoker: 0
    private static void SetUserInfo(string userInfo)
    {
        //
        // Disasemble & Code
        // 0x0272DE94: STP x22, x21, [sp, #-0x30]! | stack[1152921509927227440] = ???;  stack[1152921509927227448] = ???;  //  dest_result_addr=1152921509927227440 |  dest_result_addr=1152921509927227448
        // 0x0272DE98: STP x20, x19, [sp, #0x10]  | stack[1152921509927227456] = ???;  stack[1152921509927227464] = ???;  //  dest_result_addr=1152921509927227456 |  dest_result_addr=1152921509927227464
        // 0x0272DE9C: STP x29, x30, [sp, #0x20]  | stack[1152921509927227472] = ???;  stack[1152921509927227480] = ???;  //  dest_result_addr=1152921509927227472 |  dest_result_addr=1152921509927227480
        // 0x0272DEA0: ADD x29, sp, #0x20         | X29 = (1152921509927227440 + 32) = 1152921509927227472 (0x100000013D1E9050);
        // 0x0272DEA4: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272DEA8: LDRB w8, [x20, #0xab0]     | W8 = (bool)static_value_03743AB0;       
        // 0x0272DEAC: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272DEB0: TBNZ w8, #0, #0x272decc    | if (static_value_03743AB0 == true) goto label_0;
        // 0x0272DEB4: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
        // 0x0272DEB8: LDR x8, [x8, #0xfb8]       | X8 = 0x2B8FE78;                         
        // 0x0272DEBC: LDR w0, [x8]               | W0 = 0x1662;                            
        // 0x0272DEC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1662, ????);     
        // 0x0272DEC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272DEC8: STRB w8, [x20, #0xab0]     | static_value_03743AB0 = true;            //  dest_result_addr=57948848
        label_0:
        // 0x0272DECC: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272DED0: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272DED4: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272DED8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DEDC: TBZ w8, #0, #0x272deec     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272DEE0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DEE4: CBNZ w8, #0x272deec        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272DEE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272DEEC: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272DEF0: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272DEF4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DEF8: TBZ w8, #0, #0x272df08     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272DEFC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DF00: CBNZ w8, #0x272df08        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272DF04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_4:
        // 0x0272DF08: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_1 = BuglyAgent.GameAgent;
        // 0x0272DF0C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x0272DF10: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272DF14: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272DF18: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x0272DF1C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DF20: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272DF24: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272DF28: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DF2C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272DF30: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DF34: CBNZ x21, #0x272df3c       | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x0272DF38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_5:
        // 0x0272DF3C: CBZ x19, #0x272df60        | if (X1 == 0) goto label_7;              
        if(X1 == 0)
        {
            goto label_7;
        }
        // 0x0272DF40: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272DF44: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272DF48: MOV x0, x19                | X0 = X1;//m1                            
        // 0x0272DF4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
        // 0x0272DF50: CBNZ x0, #0x272df60        | if (X1 != 0) goto label_7;              
        if(X1 != 0)
        {
            goto label_7;
        }
        // 0x0272DF54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
        // 0x0272DF58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DF5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_7:
        // 0x0272DF60: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272DF64: CBNZ w8, #0x272df74        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x0272DF68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
        // 0x0272DF6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DF70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
        label_8:
        // 0x0272DF74: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
        // 0x0272DF78: CBNZ x20, #0x272df80       | if (val_1 != null) goto label_9;        
        if(val_1 != null)
        {
            goto label_9;
        }
        // 0x0272DF7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
        label_9:
        // 0x0272DF80: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x0272DF84: LDR x8, [x8, #0x7b8]       | X8 = (string**)(1152921509927215392)("setUserId");
        // 0x0272DF88: LDR x1, [x8]               | X1 = "setUserId";                       
        // 0x0272DF8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272DF90: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x0272DF94: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272DF98: BL #0x20bdcfc              | val_1.CallStatic(methodName:  "setUserId", args:  null);
        val_1.CallStatic(methodName:  "setUserId", args:  null);
        // 0x0272DF9C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DFA0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DFA4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272DFA8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F408 (41088008), len: 756  VirtAddr: 0x0272F408 RVA: 0x0272F408 token: 100663321 methodIndex: 24289 delegateWrapperIndex: 0 methodInvoker: 0
    private static void ReportException(int type, string name, string reason, string stackTrace, bool quitProgram)
    {
        //
        // Disasemble & Code
        // 0x0272F408: STP x26, x25, [sp, #-0x50]! | stack[1152921509927372272] = ???;  stack[1152921509927372280] = ???;  //  dest_result_addr=1152921509927372272 |  dest_result_addr=1152921509927372280
        // 0x0272F40C: STP x24, x23, [sp, #0x10]  | stack[1152921509927372288] = ???;  stack[1152921509927372296] = ???;  //  dest_result_addr=1152921509927372288 |  dest_result_addr=1152921509927372296
        // 0x0272F410: STP x22, x21, [sp, #0x20]  | stack[1152921509927372304] = ???;  stack[1152921509927372312] = ???;  //  dest_result_addr=1152921509927372304 |  dest_result_addr=1152921509927372312
        // 0x0272F414: STP x20, x19, [sp, #0x30]  | stack[1152921509927372320] = ???;  stack[1152921509927372328] = ???;  //  dest_result_addr=1152921509927372320 |  dest_result_addr=1152921509927372328
        // 0x0272F418: STP x29, x30, [sp, #0x40]  | stack[1152921509927372336] = ???;  stack[1152921509927372344] = ???;  //  dest_result_addr=1152921509927372336 |  dest_result_addr=1152921509927372344
        // 0x0272F41C: ADD x29, sp, #0x40         | X29 = (1152921509927372272 + 64) = 1152921509927372336 (0x100000013D20C630);
        // 0x0272F420: SUB sp, sp, #0x10          | SP = (1152921509927372272 - 16) = 1152921509927372256 (0x100000013D20C5E0);
        // 0x0272F424: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F428: LDRB w8, [x19, #0xab1]     | W8 = (bool)static_value_03743AB1;       
        // 0x0272F42C: MOV w21, w5                | W21 = W5;//m1                           
        // 0x0272F430: MOV x22, x4                | X22 = quitProgram;//m1                  
        // 0x0272F434: MOV x23, x3                | X23 = stackTrace;//m1                   
        // 0x0272F438: MOV x24, x2                | X24 = reason;//m1                       
        // 0x0272F43C: TBNZ w8, #0, #0x272f458    | if (static_value_03743AB1 == true) goto label_0;
        // 0x0272F440: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x0272F444: LDR x8, [x8, #0x510]       | X8 = 0x2B8FE5C;                         
        // 0x0272F448: LDR w0, [x8]               | W0 = 0x165B;                            
        // 0x0272F44C: BL #0x2782188              | X0 = sub_2782188( ?? 0x165B, ????);     
        // 0x0272F450: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F454: STRB w8, [x19, #0xab1]     | static_value_03743AB1 = true;            //  dest_result_addr=57948849
        label_0:
        // 0x0272F458: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x0272F45C: LDR x25, [x25, #0x938]     | X25 = 1152921504776761344;              
        // 0x0272F460: LDR x0, [x25]              | X0 = typeof(BuglyAgent);                
        // 0x0272F464: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F468: TBZ w8, #0, #0x272f478     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272F46C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F470: CBNZ w8, #0x272f478        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272F474: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272F478: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272F47C: LDR x0, [x25]              | X0 = typeof(BuglyAgent);                
        // 0x0272F480: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F484: TBZ w8, #0, #0x272f494     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272F488: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F48C: CBNZ w8, #0x272f494        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272F490: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_4:
        // 0x0272F494: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_1 = BuglyAgent.GameAgent;
        // 0x0272F498: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x0272F49C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272F4A0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272F4A4: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272F4A8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F4AC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272F4B0: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x0272F4B4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F4B8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272F4BC: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F4C0: LDR x8, [x25]              | X8 = typeof(BuglyAgent);                
        // 0x0272F4C4: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x0272F4C8: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F4CC: LDR w8, [x8, #8]           | W8 = BuglyAgent.TYPE_U3D_CRASH;         
        // 0x0272F4D0: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x0272F4D4: STR w8, [sp, #0xc]         | stack[1152921509927372268] = BuglyAgent.TYPE_U3D_CRASH;  //  dest_result_addr=1152921509927372268
        // 0x0272F4D8: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x0272F4DC: ADD x1, sp, #0xc           | X1 = (1152921509927372256 + 12) = 1152921509927372268 (0x100000013D20C5EC);
        // 0x0272F4E0: BL #0x27bc028              | X0 = 1152921509927432736 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), BuglyAgent.TYPE_U3D_CRASH);
        // 0x0272F4E4: MOV x25, x0                | X25 = 1152921509927432736 (0x100000013D21B220);//ML01
        // 0x0272F4E8: CBNZ x20, #0x272f4f0       | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x0272F4EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? BuglyAgent.TYPE_U3D_CRASH, ????);
        label_5:
        // 0x0272F4F0: CBZ x25, #0x272f514        | if (BuglyAgent.TYPE_U3D_CRASH == 0) goto label_7;
        if(BuglyAgent.TYPE_U3D_CRASH == 0)
        {
            goto label_7;
        }
        // 0x0272F4F4: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F4F8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F4FC: MOV x0, x25                | X0 = 1152921509927432736 (0x100000013D21B220);//ML01
        // 0x0272F500: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? BuglyAgent.TYPE_U3D_CRASH, ????);
        // 0x0272F504: CBNZ x0, #0x272f514        | if (BuglyAgent.TYPE_U3D_CRASH != 0) goto label_7;
        if(BuglyAgent.TYPE_U3D_CRASH != 0)
        {
            goto label_7;
        }
        // 0x0272F508: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? BuglyAgent.TYPE_U3D_CRASH, ????);
        // 0x0272F50C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F510: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent.TYPE_U3D_CRASH, ????);
        label_7:
        // 0x0272F514: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F518: CBNZ w8, #0x272f528        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x0272F51C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? BuglyAgent.TYPE_U3D_CRASH, ????);
        // 0x0272F520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F524: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? BuglyAgent.TYPE_U3D_CRASH, ????);
        label_8:
        // 0x0272F528: STR x25, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = BuglyAgent.TYPE_U3D_CRASH; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000001;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = BuglyAgent.TYPE_U3D_CRASH;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435457;
        // 0x0272F52C: CBZ x24, #0x272f550        | if (reason == null) goto label_10;      
        if(reason == null)
        {
            goto label_10;
        }
        // 0x0272F530: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F534: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F538: MOV x0, x24                | X0 = reason;//m1                        
        // 0x0272F53C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? reason, ????);     
        // 0x0272F540: CBNZ x0, #0x272f550        | if (reason != null) goto label_10;      
        if(reason != null)
        {
            goto label_10;
        }
        // 0x0272F544: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? reason, ????);     
        // 0x0272F548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F54C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? reason, ????);     
        label_10:
        // 0x0272F550: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F554: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272F558: B.HI #0x272f568            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_11;
        // 0x0272F55C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? reason, ????);     
        // 0x0272F560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F564: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? reason, ????);     
        label_11:
        // 0x0272F568: STR x24, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = reason;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = reason;
        // 0x0272F56C: CBZ x23, #0x272f590        | if (stackTrace == null) goto label_13;  
        if(stackTrace == null)
        {
            goto label_13;
        }
        // 0x0272F570: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F574: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F578: MOV x0, x23                | X0 = stackTrace;//m1                    
        // 0x0272F57C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? stackTrace, ????); 
        // 0x0272F580: CBNZ x0, #0x272f590        | if (stackTrace != null) goto label_13;  
        if(stackTrace != null)
        {
            goto label_13;
        }
        // 0x0272F584: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? stackTrace, ????); 
        // 0x0272F588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F58C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? stackTrace, ????); 
        label_13:
        // 0x0272F590: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F594: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x0272F598: B.HI #0x272f5a8            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_14;
        // 0x0272F59C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? stackTrace, ????); 
        // 0x0272F5A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F5A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? stackTrace, ????); 
        label_14:
        // 0x0272F5A8: STR x23, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = stackTrace;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = stackTrace;
        // 0x0272F5AC: CBZ x22, #0x272f5d0        | if (quitProgram == false) goto label_16;
        if(quitProgram == false)
        {
            goto label_16;
        }
        // 0x0272F5B0: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F5B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F5B8: MOV x0, x22                | X0 = quitProgram;//m1                   
        // 0x0272F5BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? quitProgram, ????);
        // 0x0272F5C0: CBNZ x0, #0x272f5d0        | if (quitProgram == true) goto label_16; 
        if(quitProgram == true)
        {
            goto label_16;
        }
        // 0x0272F5C4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? quitProgram, ????);
        // 0x0272F5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F5CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? quitProgram, ????);
        label_16:
        // 0x0272F5D0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F5D4: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x0272F5D8: B.HI #0x272f5e8            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_17;
        // 0x0272F5DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? quitProgram, ????);
        // 0x0272F5E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F5E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? quitProgram, ????);
        label_17:
        // 0x0272F5E8: STR x22, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = quitProgram;  //  dest_result_addr=1152921504954501320
        typeof(System.Object[]).__il2cppRuntimeField_38 = quitProgram;
        // 0x0272F5EC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x0272F5F0: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x0272F5F4: LDR x0, [x8]               | X0 = typeof(System.Boolean);            
        // 0x0272F5F8: AND w8, w21, #1            | W8 = (W5 & 1);                          
        bool val_2 = W5 & 1;
        // 0x0272F5FC: STRB w8, [sp, #0xb]        | stack[1152921509927372267] = (W5 & 1);   //  dest_result_addr=1152921509927372267
        // 0x0272F600: ADD x1, sp, #0xb           | X1 = (1152921509927372256 + 11) = 1152921509927372267 (0x100000013D20C5EB);
        // 0x0272F604: BL #0x27bc028              | X0 = 1152921509927436832 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (W5 & 1));
        // 0x0272F608: MOV x21, x0                | X21 = 1152921509927436832 (0x100000013D21C220);//ML01
        // 0x0272F60C: CBZ x21, #0x272f630        | if ((W5 & 1) == false) goto label_19;   
        if(val_2 == false)
        {
            goto label_19;
        }
        // 0x0272F610: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F614: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F618: MOV x0, x21                | X0 = 1152921509927436832 (0x100000013D21C220);//ML01
        // 0x0272F61C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (W5 & 1), ????);   
        // 0x0272F620: CBNZ x0, #0x272f630        | if ((W5 & 1) == true) goto label_19;    
        if(val_2 == true)
        {
            goto label_19;
        }
        // 0x0272F624: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (W5 & 1), ????);   
        // 0x0272F628: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F62C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (W5 & 1), ????);   
        label_19:
        // 0x0272F630: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F634: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x0272F638: B.HI #0x272f648            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_20;
        // 0x0272F63C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (W5 & 1), ????);   
        // 0x0272F640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F644: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (W5 & 1), ????);   
        label_20:
        // 0x0272F648: STR x21, [x20, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = (W5 & 1); typeof(System.Object[]).__il2cppRuntimeField_41 = 0x100000013D21C2;  //  dest_result_addr=1152921504954501328 dest_result_addr=1152921504954501329
        typeof(System.Object[]).__il2cppRuntimeField_40 = val_2;
        typeof(System.Object[]).__il2cppRuntimeField_41 = 20783554;
        // 0x0272F64C: CBNZ x19, #0x272f654       | if (val_1 != null) goto label_21;       
        if(val_1 != null)
        {
            goto label_21;
        }
        // 0x0272F650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (W5 & 1), ????);   
        label_21:
        // 0x0272F654: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x0272F658: LDR x8, [x8, #0x278]       | X8 = (string**)(1152921509927360256)("postException");
        // 0x0272F65C: LDR x1, [x8]               | X1 = "postException";                   
        // 0x0272F660: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272F664: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x0272F668: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F66C: BL #0x20bdcfc              | val_1.CallStatic(methodName:  "postException", args:  null);
        val_1.CallStatic(methodName:  "postException", args:  null);
        // 0x0272F670: SUB sp, x29, #0x40         | SP = (1152921509927372336 - 64) = 1152921509927372272 (0x100000013D20C5F0);
        // 0x0272F674: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0272F678: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x0272F67C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x0272F680: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x0272F684: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x0272F688: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E15C (41083228), len: 428  VirtAddr: 0x0272E15C RVA: 0x0272E15C token: 100663322 methodIndex: 24290 delegateWrapperIndex: 0 methodInvoker: 0
    private static void SetCurrentScene(int sceneId)
    {
        //
        // Disasemble & Code
        // 0x0272E15C: STP x22, x21, [sp, #-0x30]! | stack[1152921509927517184] = ???;  stack[1152921509927517192] = ???;  //  dest_result_addr=1152921509927517184 |  dest_result_addr=1152921509927517192
        // 0x0272E160: STP x20, x19, [sp, #0x10]  | stack[1152921509927517200] = ???;  stack[1152921509927517208] = ???;  //  dest_result_addr=1152921509927517200 |  dest_result_addr=1152921509927517208
        // 0x0272E164: STP x29, x30, [sp, #0x20]  | stack[1152921509927517216] = ???;  stack[1152921509927517224] = ???;  //  dest_result_addr=1152921509927517216 |  dest_result_addr=1152921509927517224
        // 0x0272E168: ADD x29, sp, #0x20         | X29 = (1152921509927517184 + 32) = 1152921509927517216 (0x100000013D22FC20);
        // 0x0272E16C: SUB sp, sp, #0x10          | SP = (1152921509927517184 - 16) = 1152921509927517168 (0x100000013D22FBF0);
        // 0x0272E170: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272E174: LDRB w8, [x19, #0xab2]     | W8 = (bool)static_value_03743AB2;       
        // 0x0272E178: MOV w21, w1                | W21 = W1;//m1                           
        // 0x0272E17C: TBNZ w8, #0, #0x272e198    | if (static_value_03743AB2 == true) goto label_0;
        // 0x0272E180: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x0272E184: LDR x8, [x8, #0x38]        | X8 = 0x2B8FE64;                         
        // 0x0272E188: LDR w0, [x8]               | W0 = 0x165D;                            
        // 0x0272E18C: BL #0x2782188              | X0 = sub_2782188( ?? 0x165D, ????);     
        // 0x0272E190: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E194: STRB w8, [x19, #0xab2]     | static_value_03743AB2 = true;            //  dest_result_addr=57948850
        label_0:
        // 0x0272E198: ADRP x19, #0x3652000       | X19 = 56958976 (0x3652000);             
        // 0x0272E19C: LDR x19, [x19, #0x938]     | X19 = 1152921504776761344;              
        // 0x0272E1A0: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        // 0x0272E1A4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E1A8: TBZ w8, #0, #0x272e1b8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E1AC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E1B0: CBNZ w8, #0x272e1b8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E1B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272E1B8: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272E1BC: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        // 0x0272E1C0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E1C4: TBZ w8, #0, #0x272e1d4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272E1C8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E1CC: CBNZ w8, #0x272e1d4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272E1D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_4:
        // 0x0272E1D4: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_1 = BuglyAgent.GameAgent;
        // 0x0272E1D8: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x0272E1DC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272E1E0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272E1E4: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272E1E8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E1EC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272E1F0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272E1F4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E1F8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272E1FC: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E200: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272E204: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x0272E208: STR w21, [sp, #0xc]        | stack[1152921509927517180] = W1;         //  dest_result_addr=1152921509927517180
        // 0x0272E20C: LDR x0, [x8]               | X0 = typeof(System.Int32);              
        // 0x0272E210: ADD x1, sp, #0xc           | X1 = (1152921509927517168 + 12) = 1152921509927517180 (0x100000013D22FBFC);
        // 0x0272E214: BL #0x27bc028              | X0 = 1152921509927565328 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), W1);
        // 0x0272E218: MOV x21, x0                | X21 = 1152921509927565328 (0x100000013D23B810);//ML01
        // 0x0272E21C: CBNZ x20, #0x272e224       | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x0272E220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? W1, ????);         
        label_5:
        // 0x0272E224: CBZ x21, #0x272e248        | if (W1 == 0) goto label_7;              
        if(W1 == 0)
        {
            goto label_7;
        }
        // 0x0272E228: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272E22C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E230: MOV x0, x21                | X0 = 1152921509927565328 (0x100000013D23B810);//ML01
        // 0x0272E234: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? W1, ????);         
        // 0x0272E238: CBNZ x0, #0x272e248        | if (W1 != 0) goto label_7;              
        if(W1 != 0)
        {
            goto label_7;
        }
        // 0x0272E23C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? W1, ????);         
        // 0x0272E240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E244: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? W1, ????);         
        label_7:
        // 0x0272E248: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E24C: CBNZ w8, #0x272e25c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x0272E250: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? W1, ????);         
        // 0x0272E254: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E258: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? W1, ????);         
        label_8:
        // 0x0272E25C: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = W1; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000001;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = W1;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435457;
        // 0x0272E260: CBNZ x19, #0x272e268       | if (val_1 != null) goto label_9;        
        if(val_1 != null)
        {
            goto label_9;
        }
        // 0x0272E264: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? W1, ????);         
        label_9:
        // 0x0272E268: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x0272E26C: LDR x8, [x8, #0xee0]       | X8 = (string**)(1152921509927505120)("setUserSceneTag");
        // 0x0272E270: LDR x1, [x8]               | X1 = "setUserSceneTag";                 
        // 0x0272E274: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272E278: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x0272E27C: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E280: BL #0x20bdcfc              | val_1.CallStatic(methodName:  "setUserSceneTag", args:  null);
        val_1.CallStatic(methodName:  "setUserSceneTag", args:  null);
        // 0x0272E284: SUB sp, x29, #0x20         | SP = (1152921509927517216 - 32) = 1152921509927517184 (0x100000013D22FC00);
        // 0x0272E288: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E28C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E290: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E294: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F6FC (41088764), len: 488  VirtAddr: 0x0272F6FC RVA: 0x0272F6FC token: 100663323 methodIndex: 24291 delegateWrapperIndex: 0 methodInvoker: 0
    private static void SetUnityVersion()
    {
        //
        // Disasemble & Code
        // 0x0272F6FC: STP x22, x21, [sp, #-0x30]! | stack[1152921509927645760] = ???;  stack[1152921509927645768] = ???;  //  dest_result_addr=1152921509927645760 |  dest_result_addr=1152921509927645768
        // 0x0272F700: STP x20, x19, [sp, #0x10]  | stack[1152921509927645776] = ???;  stack[1152921509927645784] = ???;  //  dest_result_addr=1152921509927645776 |  dest_result_addr=1152921509927645784
        // 0x0272F704: STP x29, x30, [sp, #0x20]  | stack[1152921509927645792] = ???;  stack[1152921509927645800] = ???;  //  dest_result_addr=1152921509927645792 |  dest_result_addr=1152921509927645800
        // 0x0272F708: ADD x29, sp, #0x20         | X29 = (1152921509927645760 + 32) = 1152921509927645792 (0x100000013D24F260);
        // 0x0272F70C: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F710: LDRB w8, [x19, #0xab3]     | W8 = (bool)static_value_03743AB3;       
        // 0x0272F714: TBNZ w8, #0, #0x272f730    | if (static_value_03743AB3 == true) goto label_0;
        // 0x0272F718: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x0272F71C: LDR x8, [x8, #0x7a0]       | X8 = 0x2B8FE70;                         
        // 0x0272F720: LDR w0, [x8]               | W0 = 0x1660;                            
        // 0x0272F724: BL #0x2782188              | X0 = sub_2782188( ?? 0x1660, ????);     
        // 0x0272F728: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F72C: STRB w8, [x19, #0xab3]     | static_value_03743AB3 = true;            //  dest_result_addr=57948851
        label_0:
        // 0x0272F730: ADRP x19, #0x3652000       | X19 = 56958976 (0x3652000);             
        // 0x0272F734: LDR x19, [x19, #0x938]     | X19 = 1152921504776761344;              
        // 0x0272F738: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        // 0x0272F73C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F740: TBZ w8, #0, #0x272f750     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272F744: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F748: CBNZ w8, #0x272f750        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272F74C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272F750: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272F754: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        // 0x0272F758: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F75C: TBZ w8, #0, #0x272f76c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272F760: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F764: CBNZ w8, #0x272f76c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272F768: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_4:
        // 0x0272F76C: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_1 = BuglyAgent.GameAgent;
        // 0x0272F770: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x0272F774: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272F778: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272F77C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x0272F780: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F784: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272F788: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x0272F78C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F790: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272F794: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F798: CBNZ x20, #0x272f7a0       | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x0272F79C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_5:
        // 0x0272F7A0: ADRP x21, #0x361d000       | X21 = 56741888 (0x361D000);             
        // 0x0272F7A4: LDR x21, [x21, #0x4e0]     | X21 = (string**)(1152921509927629520)("UnityVersion");
        // 0x0272F7A8: LDR x0, [x21]              | X0 = "UnityVersion";                    
        // 0x0272F7AC: CBZ x0, #0x272f7cc         | if ("UnityVersion" == null) goto label_7;
        // 0x0272F7B0: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F7B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F7B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "UnityVersion", ????);
        // 0x0272F7BC: CBNZ x0, #0x272f7cc        | if ("UnityVersion" != null) goto label_7;
        if("UnityVersion" != null)
        {
            goto label_7;
        }
        // 0x0272F7C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "UnityVersion", ????);
        // 0x0272F7C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F7C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UnityVersion", ????);
        label_7:
        // 0x0272F7CC: LDR x21, [x21]             | X21 = "UnityVersion";                   
        // 0x0272F7D0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F7D4: CBNZ w8, #0x272f7e4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x0272F7D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "UnityVersion", ????);
        // 0x0272F7DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F7E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UnityVersion", ????);
        label_8:
        // 0x0272F7E4: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "UnityVersion";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "UnityVersion";
        // 0x0272F7E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272F7EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F7F0: BL #0x20c7568              | X0 = UnityEngine.Application.get_unityVersion();
        string val_2 = UnityEngine.Application.unityVersion;
        // 0x0272F7F4: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x0272F7F8: CBZ x21, #0x272f81c        | if (val_2 == null) goto label_10;       
        if(val_2 == null)
        {
            goto label_10;
        }
        // 0x0272F7FC: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272F800: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272F804: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x0272F808: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x0272F80C: CBNZ x0, #0x272f81c        | if (val_2 != null) goto label_10;       
        if(val_2 != null)
        {
            goto label_10;
        }
        // 0x0272F810: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x0272F814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F818: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_10:
        // 0x0272F81C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272F820: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272F824: B.HI #0x272f834            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_11;
        // 0x0272F828: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x0272F82C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F830: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_11:
        // 0x0272F834: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;
        // 0x0272F838: CBNZ x19, #0x272f840       | if (val_1 != null) goto label_12;       
        if(val_1 != null)
        {
            goto label_12;
        }
        // 0x0272F83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_12:
        // 0x0272F840: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x0272F844: LDR x8, [x8, #0xfe0]       | X8 = (string**)(1152921509927633712)("setSdkConfig");
        // 0x0272F848: LDR x1, [x8]               | X1 = "setSdkConfig";                    
        // 0x0272F84C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272F850: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x0272F854: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272F858: BL #0x20bdcfc              | val_1.CallStatic(methodName:  "setSdkConfig", args:  null);
        val_1.CallStatic(methodName:  "setSdkConfig", args:  null);
        // 0x0272F85C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272F860: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272F864: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272F868: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272E46C (41084012), len: 468  VirtAddr: 0x0272E46C RVA: 0x0272E46C token: 100663324 methodIndex: 24292 delegateWrapperIndex: 0 methodInvoker: 0
    private static void AddKeyAndValueInScene(string key, string value)
    {
        //
        // Disasemble & Code
        // 0x0272E46C: STP x22, x21, [sp, #-0x30]! | stack[1152921509927778336] = ???;  stack[1152921509927778344] = ???;  //  dest_result_addr=1152921509927778336 |  dest_result_addr=1152921509927778344
        // 0x0272E470: STP x20, x19, [sp, #0x10]  | stack[1152921509927778352] = ???;  stack[1152921509927778360] = ???;  //  dest_result_addr=1152921509927778352 |  dest_result_addr=1152921509927778360
        // 0x0272E474: STP x29, x30, [sp, #0x20]  | stack[1152921509927778368] = ???;  stack[1152921509927778376] = ???;  //  dest_result_addr=1152921509927778368 |  dest_result_addr=1152921509927778376
        // 0x0272E478: ADD x29, sp, #0x20         | X29 = (1152921509927778336 + 32) = 1152921509927778368 (0x100000013D26F840);
        // 0x0272E47C: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272E480: LDRB w8, [x20, #0xab4]     | W8 = (bool)static_value_03743AB4;       
        // 0x0272E484: MOV x19, x2                | X19 = X2;//m1                           
        // 0x0272E488: MOV x22, x1                | X22 = value;//m1                        
        // 0x0272E48C: TBNZ w8, #0, #0x272e4a8    | if (static_value_03743AB4 == true) goto label_0;
        // 0x0272E490: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x0272E494: LDR x8, [x8, #0xb10]       | X8 = 0x2B8FE00;                         
        // 0x0272E498: LDR w0, [x8]               | W0 = 0x1644;                            
        // 0x0272E49C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1644, ????);     
        // 0x0272E4A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272E4A4: STRB w8, [x20, #0xab4]     | static_value_03743AB4 = true;            //  dest_result_addr=57948852
        label_0:
        // 0x0272E4A8: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272E4AC: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272E4B0: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272E4B4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E4B8: TBZ w8, #0, #0x272e4c8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272E4BC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E4C0: CBNZ w8, #0x272e4c8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272E4C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272E4C8: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272E4CC: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272E4D0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272E4D4: TBZ w8, #0, #0x272e4e4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272E4D8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272E4DC: CBNZ w8, #0x272e4e4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272E4E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_4:
        // 0x0272E4E4: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_1 = BuglyAgent.GameAgent;
        // 0x0272E4E8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x0272E4EC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272E4F0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272E4F4: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x0272E4F8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E4FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272E500: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x0272E504: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E508: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272E50C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E510: CBNZ x21, #0x272e518       | if ( != null) goto label_5;             
        if(null != null)
        {
            goto label_5;
        }
        // 0x0272E514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_5:
        // 0x0272E518: CBZ x22, #0x272e53c        | if (value == null) goto label_7;        
        if(value == null)
        {
            goto label_7;
        }
        // 0x0272E51C: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272E520: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E524: MOV x0, x22                | X0 = value;//m1                         
        // 0x0272E528: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
        // 0x0272E52C: CBNZ x0, #0x272e53c        | if (value != null) goto label_7;        
        if(value != null)
        {
            goto label_7;
        }
        // 0x0272E530: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? value, ????);      
        // 0x0272E534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E538: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? value, ????);      
        label_7:
        // 0x0272E53C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E540: CBNZ w8, #0x272e550        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x0272E544: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? value, ????);      
        // 0x0272E548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E54C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? value, ????);      
        label_8:
        // 0x0272E550: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = value;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = value;
        // 0x0272E554: CBZ x19, #0x272e578        | if (X2 == 0) goto label_10;             
        if(X2 == 0)
        {
            goto label_10;
        }
        // 0x0272E558: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272E55C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272E560: MOV x0, x19                | X0 = X2;//m1                            
        // 0x0272E564: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
        // 0x0272E568: CBNZ x0, #0x272e578        | if (X2 != 0) goto label_10;             
        if(X2 != 0)
        {
            goto label_10;
        }
        // 0x0272E56C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X2, ????);         
        // 0x0272E570: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E574: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
        label_10:
        // 0x0272E578: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272E57C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272E580: B.HI #0x272e590            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_11;
        // 0x0272E584: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
        // 0x0272E588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272E58C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
        label_11:
        // 0x0272E590: STR x19, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = X2;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = X2;
        // 0x0272E594: CBNZ x20, #0x272e59c       | if (val_1 != null) goto label_12;       
        if(val_1 != null)
        {
            goto label_12;
        }
        // 0x0272E598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
        label_12:
        // 0x0272E59C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x0272E5A0: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921509927766288)("putUserData");
        // 0x0272E5A4: LDR x1, [x8]               | X1 = "putUserData";                     
        // 0x0272E5A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272E5AC: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x0272E5B0: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272E5B4: BL #0x20bdcfc              | val_1.CallStatic(methodName:  "putUserData", args:  null);
        val_1.CallStatic(methodName:  "putUserData", args:  null);
        // 0x0272E5B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272E5BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272E5C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272E5C4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F8E4 (41089252), len: 4  VirtAddr: 0x0272F8E4 RVA: 0x0272F8E4 token: 100663325 methodIndex: 24293 delegateWrapperIndex: 0 methodInvoker: 0
    private static void AddExtraDataWithException(string key, string value)
    {
        //
        // Disasemble & Code
        // 0x0272F8E4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272ED90 (41086352), len: 716  VirtAddr: 0x0272ED90 RVA: 0x0272ED90 token: 100663326 methodIndex: 24294 delegateWrapperIndex: 0 methodInvoker: 0
    private static void LogRecord(LogSeverity level, string message)
    {
        //
        // Disasemble & Code
        // 0x0272ED90: STP x24, x23, [sp, #-0x40]! | stack[1152921509928063952] = ???;  stack[1152921509928063960] = ???;  //  dest_result_addr=1152921509928063952 |  dest_result_addr=1152921509928063960
        // 0x0272ED94: STP x22, x21, [sp, #0x10]  | stack[1152921509928063968] = ???;  stack[1152921509928063976] = ???;  //  dest_result_addr=1152921509928063968 |  dest_result_addr=1152921509928063976
        // 0x0272ED98: STP x20, x19, [sp, #0x20]  | stack[1152921509928063984] = ???;  stack[1152921509928063992] = ???;  //  dest_result_addr=1152921509928063984 |  dest_result_addr=1152921509928063992
        // 0x0272ED9C: STP x29, x30, [sp, #0x30]  | stack[1152921509928064000] = ???;  stack[1152921509928064008] = ???;  //  dest_result_addr=1152921509928064000 |  dest_result_addr=1152921509928064008
        // 0x0272EDA0: ADD x29, sp, #0x30         | X29 = (1152921509928063952 + 48) = 1152921509928064000 (0x100000013D2B5400);
        // 0x0272EDA4: SUB sp, sp, #0x10          | SP = (1152921509928063952 - 16) = 1152921509928063936 (0x100000013D2B53C0);
        // 0x0272EDA8: ADRP x21, #0x3743000       | X21 = 57946112 (0x3743000);             
        // 0x0272EDAC: LDRB w8, [x21, #0xab5]     | W8 = (bool)static_value_03743AB5;       
        // 0x0272EDB0: MOV x19, x2                | X19 = X2;//m1                           
        // 0x0272EDB4: MOV w20, w1                | W20 = message;//m1                      
        // 0x0272EDB8: STR w20, [sp, #0xc]        | stack[1152921509928063948] = message;    //  dest_result_addr=1152921509928063948
        // 0x0272EDBC: TBNZ w8, #0, #0x272edd8    | if (static_value_03743AB5 == true) goto label_0;
        // 0x0272EDC0: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x0272EDC4: LDR x8, [x8, #0x28]        | X8 = 0x2B8FE48;                         
        // 0x0272EDC8: LDR w0, [x8]               | W0 = 0x1656;                            
        // 0x0272EDCC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1656, ????);     
        // 0x0272EDD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272EDD4: STRB w8, [x21, #0xab5]     | static_value_03743AB5 = true;            //  dest_result_addr=57948853
        label_0:
        // 0x0272EDD8: CMP w20, #2                | STATE = COMPARE(message, 0x2)           
        // 0x0272EDDC: B.GT #0x272ee7c            | if (message > 0x2) goto label_1;        
        if(message > 2)
        {
            goto label_1;
        }
        // 0x0272EDE0: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x0272EDE4: LDR x8, [x8, #0x6d0]       | X8 = 1152921504776708096;               
        // 0x0272EDE8: ADD x1, sp, #0xc           | X1 = (1152921509928063936 + 12) = 1152921509928063948 (0x100000013D2B53CC);
        // 0x0272EDEC: LDR x0, [x8]               | X0 = typeof(LogSeverity);               
        // 0x0272EDF0: BL #0x27bc028              | X0 = 1152921509928116208 = (Il2CppObject*)Box((RuntimeClass*)typeof(LogSeverity), message);
        // 0x0272EDF4: MOV x21, x0                | X21 = 1152921509928116208 (0x100000013D2C1FF0);//ML01
        // 0x0272EDF8: CBNZ x21, #0x272ee00       | if (message != 0) goto label_2;         
        if(message != 0)
        {
            goto label_2;
        }
        // 0x0272EDFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? message, ????);    
        label_2:
        // 0x0272EE00: LDR x8, [x21]              | X8 = typeof(LogSeverity);               
        // 0x0272EE04: MOV x0, x21                | X0 = 1152921509928116208 (0x100000013D2C1FF0);//ML01
        // 0x0272EE08: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x0272EE0C: BLR x9                     | X0 = message.ToString();                
        string val_1 = message.ToString();
        // 0x0272EE10: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x0272EE14: CBNZ x21, #0x272ee1c       | if (message != 0) goto label_3;         
        if(message != 0)
        {
            goto label_3;
        }
        // 0x0272EE18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x0272EE1C: MOV x0, x21                | X0 = 1152921509928116208 (0x100000013D2C1FF0);//ML01
        // 0x0272EE20: BL #0x27bc4e8              | message.System.IDisposable.Dispose();   
        message.System.IDisposable.Dispose();
        // 0x0272EE24: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x0272EE28: LDR w8, [x0]               | W8 = typeof(LogSeverity);               
        // 0x0272EE2C: LDR x9, [x9, #0x938]       | X9 = 1152921504776761344;               
        // 0x0272EE30: STR w8, [sp, #0xc]         | stack[1152921509928063948] = typeof(LogSeverity);  //  dest_result_addr=1152921509928063948
        // 0x0272EE34: LDR x0, [x9]               | X0 = typeof(BuglyAgent);                
        // 0x0272EE38: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272EE3C: TBZ w8, #0, #0x272ee4c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272EE40: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272EE44: CBNZ w8, #0x272ee4c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272EE48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272EE4C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272EE50: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272EE54: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x0272EE58: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EE5C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272EE60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EE64: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EE68: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272EE6C: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x0272EE70: MOV x2, x19                | X2 = X2;//m1                            
        // 0x0272EE74: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EE78: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  val_1, args:  X2);
        BuglyAgent.DebugLog(tag:  null, format:  val_1, args:  X2);
        label_1:
        // 0x0272EE7C: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272EE80: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272EE84: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272EE88: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272EE8C: TBZ w8, #0, #0x272ee9c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272EE90: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272EE94: CBNZ w8, #0x272ee9c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272EE98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_7:
        // 0x0272EE9C: BL #0x272f258              | BuglyAgent.ConfigCrashReporterPackage();
        BuglyAgent.ConfigCrashReporterPackage();
        // 0x0272EEA0: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272EEA4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272EEA8: TBZ w8, #0, #0x272eeb8     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x0272EEAC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272EEB0: CBNZ w8, #0x272eeb8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x0272EEB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_9:
        // 0x0272EEB8: BL #0x272f05c              | X0 = BuglyAgent.get_GameAgent();        
        UnityEngine.AndroidJavaClass val_2 = BuglyAgent.GameAgent;
        // 0x0272EEBC: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x0272EEC0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272EEC4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272EEC8: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x0272EECC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EED0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272EED4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272EED8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EEDC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272EEE0: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EEE4: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x0272EEE8: LDR x8, [x8, #0x6d0]       | X8 = 1152921504776708096;               
        // 0x0272EEEC: LDR x0, [x8]               | X0 = typeof(LogSeverity);               
        // 0x0272EEF0: ADD x1, sp, #0xc           | X1 = (1152921509928063936 + 12) = 1152921509928063948 (0x100000013D2B53CC);
        // 0x0272EEF4: BL #0x27bc028              | X0 = 1152921509928128496 = (Il2CppObject*)Box((RuntimeClass*)typeof(LogSeverity), typeof(LogSeverity));
        // 0x0272EEF8: MOV x23, x0                | X23 = 1152921509928128496 (0x100000013D2C4FF0);//ML01
        // 0x0272EEFC: CBNZ x23, #0x272ef04       | if (typeof(LogSeverity) != 0) goto label_10;
        if(null != 0)
        {
            goto label_10;
        }
        // 0x0272EF00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(LogSeverity), ????);
        label_10:
        // 0x0272EF04: LDR x8, [x23]              | X8 = typeof(LogSeverity);               
        // 0x0272EF08: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x0272EF0C: MOV x0, x23                | X0 = 1152921509928128496 (0x100000013D2C4FF0);//ML01
        // 0x0272EF10: BLR x9                     | X0 = typeof(LogSeverity).ToString();    
        string val_3 = null.ToString();
        // 0x0272EF14: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x0272EF18: MOV x0, x23                | X0 = 1152921509928128496 (0x100000013D2C4FF0);//ML01
        // 0x0272EF1C: BL #0x27bc4e8              | typeof(LogSeverity).System.IDisposable.Dispose();
        null.System.IDisposable.Dispose();
        // 0x0272EF20: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
        // 0x0272EF24: LDR w8, [x0]               | W8 = typeof(LogSeverity);               
        // 0x0272EF28: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
        // 0x0272EF2C: STR w8, [sp, #0xc]         | stack[1152921509928063948] = typeof(LogSeverity);  //  dest_result_addr=1152921509928063948
        // 0x0272EF30: LDR x0, [x9]               | X0 = typeof(System.String);             
        // 0x0272EF34: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272EF38: TBZ w8, #0, #0x272ef48     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x0272EF3C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272EF40: CBNZ w8, #0x272ef48        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x0272EF44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_12:
        // 0x0272EF48: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x0272EF4C: LDR x8, [x8, #0x6f8]       | X8 = (string**)(1152921509928047728)("<{0}> - {1}");
        // 0x0272EF50: LDR x1, [x8]               | X1 = "<{0}> - {1}";                     
        // 0x0272EF54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272EF58: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272EF5C: MOV x2, x22                | X2 = val_3;//m1                         
        // 0x0272EF60: MOV x3, x19                | X3 = X2;//m1                            
        // 0x0272EF64: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "<{0}> - {1}", arg1:  val_3);
        string val_4 = System.String.Format(format:  0, arg0:  "<{0}> - {1}", arg1:  val_3);
        // 0x0272EF68: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x0272EF6C: CBNZ x21, #0x272ef74       | if ( != null) goto label_13;            
        if(null != null)
        {
            goto label_13;
        }
        // 0x0272EF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x0272EF74: CBZ x19, #0x272ef98        | if (val_4 == null) goto label_15;       
        if(val_4 == null)
        {
            goto label_15;
        }
        // 0x0272EF78: LDR x8, [x21]              | X8 = ;                                  
        // 0x0272EF7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272EF80: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x0272EF84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x0272EF88: CBNZ x0, #0x272ef98        | if (val_4 != null) goto label_15;       
        if(val_4 != null)
        {
            goto label_15;
        }
        // 0x0272EF8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
        // 0x0272EF90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EF94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_15:
        // 0x0272EF98: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272EF9C: CBNZ w8, #0x272efac        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x0272EFA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x0272EFA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272EFA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_16:
        // 0x0272EFAC: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;
        // 0x0272EFB0: CBNZ x20, #0x272efb8       | if (val_2 != null) goto label_17;       
        if(val_2 != null)
        {
            goto label_17;
        }
        // 0x0272EFB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_17:
        // 0x0272EFB8: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x0272EFBC: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921509928051920)("printLog");
        // 0x0272EFC0: LDR x1, [x8]               | X1 = "printLog";                        
        // 0x0272EFC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272EFC8: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x0272EFCC: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272EFD0: BL #0x20bdcfc              | val_2.CallStatic(methodName:  "printLog", args:  null);
        val_2.CallStatic(methodName:  "printLog", args:  null);
        // 0x0272EFD4: SUB sp, x29, #0x30         | SP = (1152921509928064000 - 48) = 1152921509928063952 (0x100000013D2B53D0);
        // 0x0272EFD8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272EFDC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272EFE0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272EFE4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272EFE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272C2A8 (41075368), len: 316  VirtAddr: 0x0272C2A8 RVA: 0x0272C2A8 token: 100663327 methodIndex: 24295 delegateWrapperIndex: 0 methodInvoker: 0
    private static void add__LogCallbackEventHandler(BuglyAgent.LogCallbackDelegate value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        //  | 
        LogCallbackDelegate val_4;
        //  | 
        var val_5;
        // 0x0272C2A8: STP x24, x23, [sp, #-0x40]! | stack[1152921509928216912] = ???;  stack[1152921509928216920] = ???;  //  dest_result_addr=1152921509928216912 |  dest_result_addr=1152921509928216920
        // 0x0272C2AC: STP x22, x21, [sp, #0x10]  | stack[1152921509928216928] = ???;  stack[1152921509928216936] = ???;  //  dest_result_addr=1152921509928216928 |  dest_result_addr=1152921509928216936
        // 0x0272C2B0: STP x20, x19, [sp, #0x20]  | stack[1152921509928216944] = ???;  stack[1152921509928216952] = ???;  //  dest_result_addr=1152921509928216944 |  dest_result_addr=1152921509928216952
        // 0x0272C2B4: STP x29, x30, [sp, #0x30]  | stack[1152921509928216960] = ???;  stack[1152921509928216968] = ???;  //  dest_result_addr=1152921509928216960 |  dest_result_addr=1152921509928216968
        // 0x0272C2B8: ADD x29, sp, #0x30         | X29 = (1152921509928216912 + 48) = 1152921509928216960 (0x100000013D2DA980);
        // 0x0272C2BC: SUB sp, sp, #0x10          | SP = (1152921509928216912 - 16) = 1152921509928216896 (0x100000013D2DA940);
        // 0x0272C2C0: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272C2C4: LDRB w8, [x20, #0xab6]     | W8 = (bool)static_value_03743AB6;       
        // 0x0272C2C8: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272C2CC: TBNZ w8, #0, #0x272c2e8    | if (static_value_03743AB6 == true) goto label_0;
        // 0x0272C2D0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0272C2D4: LDR x8, [x8, #0xdd8]       | X8 = 0x2B8FDFC;                         
        // 0x0272C2D8: LDR w0, [x8]               | W0 = 0x1643;                            
        // 0x0272C2DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1643, ????);     
        // 0x0272C2E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272C2E4: STRB w8, [x20, #0xab6]     | static_value_03743AB6 = true;            //  dest_result_addr=57948854
        label_0:
        // 0x0272C2E8: ADRP x21, #0x3652000       | X21 = 56958976 (0x3652000);             
        // 0x0272C2EC: LDR x21, [x21, #0x938]     | X21 = 1152921504776761344;              
        // 0x0272C2F0: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272C2F4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C2F8: TBZ w8, #0, #0x272c30c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272C2FC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C300: CBNZ w8, #0x272c30c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272C304: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272C308: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_2:
        // 0x0272C30C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272C310: ADRP x22, #0x35e2000       | X22 = 56500224 (0x35E2000);             
        // 0x0272C314: LDR x20, [x8, #0x48]       | X20 = BuglyAgent._LogCallbackEventHandler;
        val_4 = BuglyAgent._LogCallbackEventHandler;
        // 0x0272C318: LDR x22, [x22, #0x660]     | X22 = 1152921504776814592;              
        // 0x0272C31C: B #0x272c328               |  goto label_3;                          
        goto label_3;
        label_8:
        // 0x0272C320: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272C324: MOV x20, x8                | X20 = 1152921504776765440 (0x100000000A20C000);//ML01
        val_4 = BuglyAgent.__il2cppRuntimeField_static_fields;
        label_3:
        // 0x0272C328: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C32C: TBZ w8, #0, #0x272c33c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272C330: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C334: CBNZ w8, #0x272c33c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272C338: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272C33C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272C340: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272C344: MOV x1, x20                | X1 = 1152921504776765440 (0x100000000A20C000);//ML01
        // 0x0272C348: MOV x2, x19                | X2 = X1;//m1                            
        // 0x0272C34C: BL #0x1c34bb4              | X0 = System.Delegate.Combine(a:  0, b:  val_4);
        System.Delegate val_1 = System.Delegate.Combine(a:  0, b:  val_4);
        // 0x0272C350: LDR x8, [x21]              | X8 = typeof(BuglyAgent);                
        // 0x0272C354: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_5 = 0;
        // 0x0272C358: LDR x23, [x8, #0xa0]       | X23 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272C35C: CBZ x0, #0x272c39c         | if (val_1 == null) goto label_7;        
        if(val_1 == null)
        {
            goto label_7;
        }
        // 0x0272C360: LDR x1, [x22]              | X1 = typeof(BuglyAgent.LogCallbackDelegate);
        // 0x0272C364: LDR x8, [x0]               | X8 = typeof(System.Delegate);           
        // 0x0272C368: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(BuglyAgent.LogCallbackDelegate))
        // 0x0272C36C: MOV x2, x0                 | X2 = val_1;//m1                         
        val_5 = val_1;
        // 0x0272C370: B.EQ #0x272c39c            | if (typeof(System.Delegate) == null) goto label_7;
        if(null == null)
        {
            goto label_7;
        }
        // 0x0272C374: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
        // 0x0272C378: ADD x8, sp, #8             | X8 = (1152921509928216896 + 8) = 1152921509928216904 (0x100000013D2DA948);
        // 0x0272C37C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
        // 0x0272C380: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921509928204976]
        // 0x0272C384: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
        // 0x0272C388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C38C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        // 0x0272C390: ADD x0, sp, #8             | X0 = (1152921509928216896 + 8) = 1152921509928216904 (0x100000013D2DA948);
        // 0x0272C394: BL #0x299a140              | 
        // 0x0272C398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_5 = 0;
        label_7:
        // 0x0272C39C: ADD x0, x23, #0x48         | X0 = (BuglyAgent.__il2cppRuntimeField_static_fields + 72) = 1152921504776765512 (0x100000000A20C048);
        // 0x0272C3A0: MOV x1, x2                 | X1 = 0 (0x0);//ML01                     
        // 0x0272C3A4: MOV x2, x20                | X2 = 1152921504776765440 (0x100000000A20C000);//ML01
        // 0x0272C3A8: BL #0x27c686c              | X0 = sub_27C686C( ?? BuglyAgent._LogCallbackEventHandler, ????);
        // 0x0272C3AC: MOV x8, x0                 | X8 = 1152921504776765512 (0x100000000A20C048);//ML01
        // 0x0272C3B0: CMP x8, x20                | STATE = COMPARE(BuglyAgent._LogCallbackEventHandler, BuglyAgent.__il2cppRuntimeField_static_fields)
        // 0x0272C3B4: B.NE #0x272c320            | if (1152921504776765512 != val_4) goto label_8;
        if(1152921504776765512 != val_4)
        {
            goto label_8;
        }
        // 0x0272C3B8: SUB sp, x29, #0x30         | SP = (1152921509928216960 - 48) = 1152921509928216912 (0x100000013D2DA950);
        // 0x0272C3BC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C3C0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272C3C4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272C3C8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272C3CC: RET                        |  return;                                
        return;
        // 0x0272C3D0: MOV x19, x0                | 
        // 0x0272C3D4: ADD x0, sp, #8             | 
        // 0x0272C3D8: BL #0x299a140              | 
        // 0x0272C3DC: MOV x0, x19                | 
        // 0x0272C3E0: BL #0x980800               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x0272DC3C (41081916), len: 316  VirtAddr: 0x0272DC3C RVA: 0x0272DC3C token: 100663328 methodIndex: 24296 delegateWrapperIndex: 0 methodInvoker: 0
    private static void remove__LogCallbackEventHandler(BuglyAgent.LogCallbackDelegate value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        //  | 
        LogCallbackDelegate val_4;
        //  | 
        var val_5;
        // 0x0272DC3C: STP x24, x23, [sp, #-0x40]! | stack[1152921509928345296] = ???;  stack[1152921509928345304] = ???;  //  dest_result_addr=1152921509928345296 |  dest_result_addr=1152921509928345304
        // 0x0272DC40: STP x22, x21, [sp, #0x10]  | stack[1152921509928345312] = ???;  stack[1152921509928345320] = ???;  //  dest_result_addr=1152921509928345312 |  dest_result_addr=1152921509928345320
        // 0x0272DC44: STP x20, x19, [sp, #0x20]  | stack[1152921509928345328] = ???;  stack[1152921509928345336] = ???;  //  dest_result_addr=1152921509928345328 |  dest_result_addr=1152921509928345336
        // 0x0272DC48: STP x29, x30, [sp, #0x30]  | stack[1152921509928345344] = ???;  stack[1152921509928345352] = ???;  //  dest_result_addr=1152921509928345344 |  dest_result_addr=1152921509928345352
        // 0x0272DC4C: ADD x29, sp, #0x30         | X29 = (1152921509928345296 + 48) = 1152921509928345344 (0x100000013D2F9F00);
        // 0x0272DC50: SUB sp, sp, #0x10          | SP = (1152921509928345296 - 16) = 1152921509928345280 (0x100000013D2F9EC0);
        // 0x0272DC54: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272DC58: LDRB w8, [x20, #0xab7]     | W8 = (bool)static_value_03743AB7;       
        // 0x0272DC5C: MOV x19, x1                | X19 = X1;//m1                           
        // 0x0272DC60: TBNZ w8, #0, #0x272dc7c    | if (static_value_03743AB7 == true) goto label_0;
        // 0x0272DC64: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x0272DC68: LDR x8, [x8, #0xbd0]       | X8 = 0x2B8FE54;                         
        // 0x0272DC6C: LDR w0, [x8]               | W0 = 0x1659;                            
        // 0x0272DC70: BL #0x2782188              | X0 = sub_2782188( ?? 0x1659, ????);     
        // 0x0272DC74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272DC78: STRB w8, [x20, #0xab7]     | static_value_03743AB7 = true;            //  dest_result_addr=57948855
        label_0:
        // 0x0272DC7C: ADRP x21, #0x3652000       | X21 = 56958976 (0x3652000);             
        // 0x0272DC80: LDR x21, [x21, #0x938]     | X21 = 1152921504776761344;              
        // 0x0272DC84: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272DC88: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DC8C: TBZ w8, #0, #0x272dca0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272DC90: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DC94: CBNZ w8, #0x272dca0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272DC98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272DC9C: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        label_2:
        // 0x0272DCA0: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272DCA4: ADRP x22, #0x35e2000       | X22 = 56500224 (0x35E2000);             
        // 0x0272DCA8: LDR x20, [x8, #0x48]       | X20 = BuglyAgent._LogCallbackEventHandler;
        val_4 = BuglyAgent._LogCallbackEventHandler;
        // 0x0272DCAC: LDR x22, [x22, #0x660]     | X22 = 1152921504776814592;              
        // 0x0272DCB0: B #0x272dcbc               |  goto label_3;                          
        goto label_3;
        label_8:
        // 0x0272DCB4: LDR x0, [x21]              | X0 = typeof(BuglyAgent);                
        val_3 = null;
        // 0x0272DCB8: MOV x20, x8                | X20 = 1152921504776765440 (0x100000000A20C000);//ML01
        val_4 = BuglyAgent.__il2cppRuntimeField_static_fields;
        label_3:
        // 0x0272DCBC: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DCC0: TBZ w8, #0, #0x272dcd0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272DCC4: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DCC8: CBNZ w8, #0x272dcd0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272DCCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_5:
        // 0x0272DCD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272DCD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272DCD8: MOV x1, x20                | X1 = 1152921504776765440 (0x100000000A20C000);//ML01
        // 0x0272DCDC: MOV x2, x19                | X2 = X1;//m1                            
        // 0x0272DCE0: BL #0x1c34dc4              | X0 = System.Delegate.Remove(source:  0, value:  val_4);
        System.Delegate val_1 = System.Delegate.Remove(source:  0, value:  val_4);
        // 0x0272DCE4: LDR x8, [x21]              | X8 = typeof(BuglyAgent);                
        // 0x0272DCE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_5 = 0;
        // 0x0272DCEC: LDR x23, [x8, #0xa0]       | X23 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272DCF0: CBZ x0, #0x272dd30         | if (val_1 == null) goto label_7;        
        if(val_1 == null)
        {
            goto label_7;
        }
        // 0x0272DCF4: LDR x1, [x22]              | X1 = typeof(BuglyAgent.LogCallbackDelegate);
        // 0x0272DCF8: LDR x8, [x0]               | X8 = typeof(System.Delegate);           
        // 0x0272DCFC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Delegate), typeof(BuglyAgent.LogCallbackDelegate))
        // 0x0272DD00: MOV x2, x0                 | X2 = val_1;//m1                         
        val_5 = val_1;
        // 0x0272DD04: B.EQ #0x272dd30            | if (typeof(System.Delegate) == null) goto label_7;
        if(null == null)
        {
            goto label_7;
        }
        // 0x0272DD08: LDR x0, [x8, #0x30]        | X0 = System.Delegate.__il2cppRuntimeField_element_class;
        // 0x0272DD0C: ADD x8, sp, #8             | X8 = (1152921509928345280 + 8) = 1152921509928345288 (0x100000013D2F9EC8);
        // 0x0272DD10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Delegate.__il2cppRuntimeField_element_class, ????);
        // 0x0272DD14: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921509928333360]
        // 0x0272DD18: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
        // 0x0272DD1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272DD20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        // 0x0272DD24: ADD x0, sp, #8             | X0 = (1152921509928345280 + 8) = 1152921509928345288 (0x100000013D2F9EC8);
        // 0x0272DD28: BL #0x299a140              | 
        // 0x0272DD2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_5 = 0;
        label_7:
        // 0x0272DD30: ADD x0, x23, #0x48         | X0 = (BuglyAgent.__il2cppRuntimeField_static_fields + 72) = 1152921504776765512 (0x100000000A20C048);
        // 0x0272DD34: MOV x1, x2                 | X1 = 0 (0x0);//ML01                     
        // 0x0272DD38: MOV x2, x20                | X2 = 1152921504776765440 (0x100000000A20C000);//ML01
        // 0x0272DD3C: BL #0x27c686c              | X0 = sub_27C686C( ?? BuglyAgent._LogCallbackEventHandler, ????);
        // 0x0272DD40: MOV x8, x0                 | X8 = 1152921504776765512 (0x100000000A20C048);//ML01
        // 0x0272DD44: CMP x8, x20                | STATE = COMPARE(BuglyAgent._LogCallbackEventHandler, BuglyAgent.__il2cppRuntimeField_static_fields)
        // 0x0272DD48: B.NE #0x272dcb4            | if (1152921504776765512 != val_4) goto label_8;
        if(1152921504776765512 != val_4)
        {
            goto label_8;
        }
        // 0x0272DD4C: SUB sp, x29, #0x30         | SP = (1152921509928345344 - 48) = 1152921509928345296 (0x100000013D2F9ED0);
        // 0x0272DD50: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DD54: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DD58: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0272DD5C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0272DD60: RET                        |  return;                                
        return;
        // 0x0272DD64: MOV x19, x0                | 
        // 0x0272DD68: ADD x0, sp, #8             | 
        // 0x0272DD6C: BL #0x299a140              | 
        // 0x0272DD70: MOV x0, x19                | 
        // 0x0272DD74: BL #0x980800               | 
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F8E8 (41089256), len: 104  VirtAddr: 0x0272F8E8 RVA: 0x0272F8E8 token: 100663329 methodIndex: 24297 delegateWrapperIndex: 0 methodInvoker: 0
    public static string get_PluginVersion()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x0272F8E8: STP x20, x19, [sp, #-0x20]! | stack[1152921509928465520] = ???;  stack[1152921509928465528] = ???;  //  dest_result_addr=1152921509928465520 |  dest_result_addr=1152921509928465528
        // 0x0272F8EC: STP x29, x30, [sp, #0x10]  | stack[1152921509928465536] = ???;  stack[1152921509928465544] = ???;  //  dest_result_addr=1152921509928465536 |  dest_result_addr=1152921509928465544
        // 0x0272F8F0: ADD x29, sp, #0x10         | X29 = (1152921509928465520 + 16) = 1152921509928465536 (0x100000013D317480);
        // 0x0272F8F4: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F8F8: LDRB w8, [x19, #0xab8]     | W8 = (bool)static_value_03743AB8;       
        // 0x0272F8FC: TBNZ w8, #0, #0x272f918    | if (static_value_03743AB8 == true) goto label_0;
        // 0x0272F900: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x0272F904: LDR x8, [x8, #0x4f8]       | X8 = 0x2B8FE3C;                         
        // 0x0272F908: LDR w0, [x8]               | W0 = 0x1653;                            
        // 0x0272F90C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1653, ????);     
        // 0x0272F910: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F914: STRB w8, [x19, #0xab8]     | static_value_03743AB8 = true;            //  dest_result_addr=57948856
        label_0:
        // 0x0272F918: ADRP x19, #0x3652000       | X19 = 56958976 (0x3652000);             
        // 0x0272F91C: LDR x19, [x19, #0x938]     | X19 = 1152921504776761344;              
        // 0x0272F920: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272F924: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F928: TBZ w8, #0, #0x272f93c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272F92C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F930: CBNZ w8, #0x272f93c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272F934: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F938: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_2:
        // 0x0272F93C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F940: LDR x0, [x8, #0x78]        | X0 = BuglyAgent._pluginVersion;         
        // 0x0272F944: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272F948: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272F94C: RET                        |  return (System.String)BuglyAgent._pluginVersion;
        return BuglyAgent._pluginVersion;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B910 (41072912), len: 104  VirtAddr: 0x0272B910 RVA: 0x0272B910 token: 100663330 methodIndex: 24298 delegateWrapperIndex: 0 methodInvoker: 0
    public static bool get_IsInitialized()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x0272B910: STP x20, x19, [sp, #-0x20]! | stack[1152921509928577520] = ???;  stack[1152921509928577528] = ???;  //  dest_result_addr=1152921509928577520 |  dest_result_addr=1152921509928577528
        // 0x0272B914: STP x29, x30, [sp, #0x10]  | stack[1152921509928577536] = ???;  stack[1152921509928577544] = ???;  //  dest_result_addr=1152921509928577536 |  dest_result_addr=1152921509928577544
        // 0x0272B918: ADD x29, sp, #0x10         | X29 = (1152921509928577520 + 16) = 1152921509928577536 (0x100000013D332A00);
        // 0x0272B91C: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272B920: LDRB w8, [x19, #0xab9]     | W8 = (bool)static_value_03743AB9;       
        // 0x0272B924: TBNZ w8, #0, #0x272b940    | if (static_value_03743AB9 == true) goto label_0;
        // 0x0272B928: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x0272B92C: LDR x8, [x8, #0x200]       | X8 = 0x2B8FE38;                         
        // 0x0272B930: LDR w0, [x8]               | W0 = 0x1652;                            
        // 0x0272B934: BL #0x2782188              | X0 = sub_2782188( ?? 0x1652, ????);     
        // 0x0272B938: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B93C: STRB w8, [x19, #0xab9]     | static_value_03743AB9 = true;            //  dest_result_addr=57948857
        label_0:
        // 0x0272B940: ADRP x19, #0x3652000       | X19 = 56958976 (0x3652000);             
        // 0x0272B944: LDR x19, [x19, #0x938]     | X19 = 1152921504776761344;              
        // 0x0272B948: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272B94C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B950: TBZ w8, #0, #0x272b964     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272B954: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B958: CBNZ w8, #0x272b964        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272B95C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272B960: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_2:
        // 0x0272B964: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272B968: LDRB w0, [x8, #0x50]       | W0 = BuglyAgent._isInitialized;         
        // 0x0272B96C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B970: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B974: RET                        |  return (System.Boolean)BuglyAgent._isInitialized;
        return BuglyAgent._isInitialized;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F950 (41089360), len: 104  VirtAddr: 0x0272F950 RVA: 0x0272F950 token: 100663331 methodIndex: 24299 delegateWrapperIndex: 0 methodInvoker: 0
    public static bool get_AutoQuitApplicationAfterReport()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x0272F950: STP x20, x19, [sp, #-0x20]! | stack[1152921509928689520] = ???;  stack[1152921509928689528] = ???;  //  dest_result_addr=1152921509928689520 |  dest_result_addr=1152921509928689528
        // 0x0272F954: STP x29, x30, [sp, #0x10]  | stack[1152921509928689536] = ???;  stack[1152921509928689544] = ???;  //  dest_result_addr=1152921509928689536 |  dest_result_addr=1152921509928689544
        // 0x0272F958: ADD x29, sp, #0x10         | X29 = (1152921509928689520 + 16) = 1152921509928689536 (0x100000013D34DF80);
        // 0x0272F95C: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F960: LDRB w8, [x19, #0xaba]     | W8 = (bool)static_value_03743ABA;       
        // 0x0272F964: TBNZ w8, #0, #0x272f980    | if (static_value_03743ABA == true) goto label_0;
        // 0x0272F968: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x0272F96C: LDR x8, [x8, #0x860]       | X8 = 0x2B8FE30;                         
        // 0x0272F970: LDR w0, [x8]               | W0 = 0x1650;                            
        // 0x0272F974: BL #0x2782188              | X0 = sub_2782188( ?? 0x1650, ????);     
        // 0x0272F978: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F97C: STRB w8, [x19, #0xaba]     | static_value_03743ABA = true;            //  dest_result_addr=57948858
        label_0:
        // 0x0272F980: ADRP x19, #0x3652000       | X19 = 56958976 (0x3652000);             
        // 0x0272F984: LDR x19, [x19, #0x938]     | X19 = 1152921504776761344;              
        // 0x0272F988: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272F98C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272F990: TBZ w8, #0, #0x272f9a4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272F994: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272F998: CBNZ w8, #0x272f9a4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272F99C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272F9A0: LDR x0, [x19]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_2:
        // 0x0272F9A4: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272F9A8: LDRB w0, [x8, #0x69]       | W0 = BuglyAgent._autoQuitApplicationAfterReport;
        // 0x0272F9AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272F9B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272F9B4: RET                        |  return (System.Boolean)BuglyAgent._autoQuitApplicationAfterReport;
        return BuglyAgent._autoQuitApplicationAfterReport;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B6B8 (41072312), len: 172  VirtAddr: 0x0272B6B8 RVA: 0x0272B6B8 token: 100663332 methodIndex: 24300 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _SetCrashReporterType(int type)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_2;
        // 0x0272B6B8: STP x20, x19, [sp, #-0x20]! | stack[1152921509928801632] = ???;  stack[1152921509928801640] = ???;  //  dest_result_addr=1152921509928801632 |  dest_result_addr=1152921509928801640
        // 0x0272B6BC: STP x29, x30, [sp, #0x10]  | stack[1152921509928801648] = ???;  stack[1152921509928801656] = ???;  //  dest_result_addr=1152921509928801648 |  dest_result_addr=1152921509928801656
        // 0x0272B6C0: ADD x29, sp, #0x10         | X29 = (1152921509928801632 + 16) = 1152921509928801648 (0x100000013D369570);
        // 0x0272B6C4: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272B6C8: LDRB w8, [x20, #0xabb]     | W8 = (bool)static_value_03743ABB;       
        // 0x0272B6CC: MOV w19, w1                | W19 = W1;//m1                           
        // 0x0272B6D0: TBNZ w8, #0, #0x272b6ec    | if (static_value_03743ABB == true) goto label_0;
        // 0x0272B6D4: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x0272B6D8: LDR x8, [x8, #0x7a8]       | X8 = 0x2B8FDF4;                         
        // 0x0272B6DC: LDR w0, [x8]               | W0 = 0x1641;                            
        // 0x0272B6E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1641, ????);     
        // 0x0272B6E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B6E8: STRB w8, [x20, #0xabb]     | static_value_03743ABB = true;            //  dest_result_addr=57948859
        label_0:
        // 0x0272B6EC: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0272B6F0: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x0272B6F4: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        // 0x0272B6F8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B6FC: TBZ w8, #0, #0x272b710     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272B700: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B704: CBNZ w8, #0x272b710        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272B708: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272B70C: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_1 = null;
        label_2:
        // 0x0272B710: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272B714: STR w19, [x8, #0x58]       | BuglyAgent._crashReporterType = W1;      //  dest_result_addr=1152921504776765528
        BuglyAgent._crashReporterType = W1;
        // 0x0272B718: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x0272B71C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272B720: LDR w9, [x8, #0x58]        | W9 = W1;                                
        // 0x0272B724: CMP w9, #2                 | STATE = COMPARE(W1, 0x2)                
        // 0x0272B728: B.NE #0x272b758            | if (BuglyAgent._crashReporterType != 2) goto label_3;
        if(BuglyAgent._crashReporterType != 2)
        {
            goto label_3;
        }
        // 0x0272B72C: LDRB w9, [x0, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272B730: TBZ w9, #0, #0x272b748     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272B734: LDR w9, [x0, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272B738: CBNZ w9, #0x272b748        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272B73C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272B740: LDR x8, [x20]              | X8 = typeof(BuglyAgent);                
        // 0x0272B744: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        label_5:
        // 0x0272B748: ADRP x9, #0x3636000        | X9 = 56844288 (0x3636000);              
        // 0x0272B74C: LDR x9, [x9, #0xf58]       | X9 = (string**)(1152921509928789552)("com.tencent.bugly.msdk");
        // 0x0272B750: LDR x9, [x9]               | X9 = "com.tencent.bugly.msdk";          
        // 0x0272B754: STR x9, [x8, #0x60]        | BuglyAgent._crashReporterPackage = "com.tencent.bugly.msdk";  //  dest_result_addr=1152921504776765536
        BuglyAgent._crashReporterPackage = "com.tencent.bugly.msdk";
        label_3:
        // 0x0272B758: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B75C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B760: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B764 (41072484), len: 4  VirtAddr: 0x0272B764 RVA: 0x0272B764 token: 100663333 methodIndex: 24301 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _SetCrashReporterLogLevel(int logLevel)
    {
        //
        // Disasemble & Code
        // 0x0272B764: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272BDC0 (41074112), len: 728  VirtAddr: 0x0272BDC0 RVA: 0x0272BDC0 token: 100663334 methodIndex: 24302 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _RegisterExceptionHandler()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        string val_9;
        // 0x0272BDC0: STP x22, x21, [sp, #-0x30]! | stack[1152921509929036000] = ???;  stack[1152921509929036008] = ???;  //  dest_result_addr=1152921509929036000 |  dest_result_addr=1152921509929036008
        // 0x0272BDC4: STP x20, x19, [sp, #0x10]  | stack[1152921509929036016] = ???;  stack[1152921509929036024] = ???;  //  dest_result_addr=1152921509929036016 |  dest_result_addr=1152921509929036024
        // 0x0272BDC8: STP x29, x30, [sp, #0x20]  | stack[1152921509929036032] = ???;  stack[1152921509929036040] = ???;  //  dest_result_addr=1152921509929036032 |  dest_result_addr=1152921509929036040
        // 0x0272BDCC: ADD x29, sp, #0x20         | X29 = (1152921509929036000 + 32) = 1152921509929036032 (0x100000013D3A2900);
        // 0x0272BDD0: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272BDD4: LDRB w8, [x19, #0xabc]     | W8 = (bool)static_value_03743ABC;       
        // 0x0272BDD8: TBNZ w8, #0, #0x272bdf4    | if (static_value_03743ABC == true) goto label_0;
        // 0x0272BDDC: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x0272BDE0: LDR x8, [x8, #0x1d8]       | X8 = 0x2B8FDEC;                         
        // 0x0272BDE4: LDR w0, [x8]               | W0 = 0x163F;                            
        // 0x0272BDE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x163F, ????);     
        // 0x0272BDEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272BDF0: STRB w8, [x19, #0xabc]     | static_value_03743ABC = true;            //  dest_result_addr=57948860
        label_0:
        // 0x0272BDF4: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272BDF8: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272BDFC: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_5 = null;
        // 0x0272BE00: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BE04: TBZ w8, #0, #0x272be18     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272BE08: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BE0C: CBNZ w8, #0x272be18        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272BE10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272BE14: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_5 = null;
        label_2:
        // 0x0272BE18: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BE1C: LDR x8, [x8, #0x90]        | X8 = BuglyAgent.<>f__mg$cache0;         
        // 0x0272BE20: CBNZ x8, #0x272be80        | if (BuglyAgent.<>f__mg$cache0 != null) goto label_3;
        if((BuglyAgent.<>f__mg$cache0) != null)
        {
            goto label_3;
        }
        // 0x0272BE24: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x0272BE28: ADRP x9, #0x362b000        | X9 = 56799232 (0x362B000);              
        // 0x0272BE2C: LDR x8, [x8, #0x640]       | X8 = 1152921509929013664;               
        // 0x0272BE30: LDR x9, [x9, #0x570]       | X9 = 1152921504690659328;               
        // 0x0272BE34: LDR x20, [x8]              | X20 = static System.Void BuglyAgent::_OnLogCallbackHandler(string condition, string stackTrace, UnityEngine.LogType type);
        // 0x0272BE38: LDR x0, [x9]               | X0 = typeof(Application.LogCallback);   
        // 0x0272BE3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Application.LogCallback), ????);
        // 0x0272BE40: MOV x19, x0                | X19 = 1152921504690659328 (0x1000000004FEE000);//ML01
        // 0x0272BE44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BE48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272BE4C: MOV x0, x19                | X0 = 1152921504690659328 (0x1000000004FEE000);//ML01
        Application.LogCallback val_1 = null;
        // 0x0272BE50: MOV x2, x20                | X2 = 1152921509929013664 (0x100000013D39D1A0);//ML01
        // 0x0272BE54: BL #0x20c8f1c              | .ctor(object:  0, method:  static System.Void BuglyAgent::_OnLogCallbackHandler(string condition, string stackTrace, UnityEngine.LogType type));
        val_1 = new Application.LogCallback(object:  0, method:  static System.Void BuglyAgent::_OnLogCallbackHandler(string condition, string stackTrace, UnityEngine.LogType type));
        // 0x0272BE58: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_6 = null;
        // 0x0272BE5C: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BE60: TBZ w8, #0, #0x272be74     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272BE64: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BE68: CBNZ w8, #0x272be74        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272BE6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272BE70: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_6 = null;
        label_5:
        // 0x0272BE74: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BE78: STR x19, [x8, #0x90]       | BuglyAgent.<>f__mg$cache0 = typeof(Application.LogCallback);  //  dest_result_addr=1152921504776765584
        BuglyAgent.<>f__mg$cache0 = null;
        // 0x0272BE7C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_5 = null;
        label_3:
        // 0x0272BE80: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BE84: TBZ w8, #0, #0x272be98     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272BE88: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BE8C: CBNZ w8, #0x272be98        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272BE90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272BE94: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_5 = null;
        label_7:
        // 0x0272BE98: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BE9C: LDR x1, [x8, #0x90]        | X1 = typeof(Application.LogCallback);   
        // 0x0272BEA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272BEA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272BEA8: BL #0x20c8898              | UnityEngine.Application.RegisterLogCallback(handler:  0);
        UnityEngine.Application.RegisterLogCallback(handler:  0);
        // 0x0272BEAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272BEB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BEB4: BL #0x18c9f00              | X0 = System.AppDomain.get_CurrentDomain();
        System.AppDomain val_2 = System.AppDomain.CurrentDomain;
        // 0x0272BEB8: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x0272BEBC: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_7 = null;
        // 0x0272BEC0: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BEC4: LDR x8, [x8, #0x98]        | X8 = BuglyAgent.<>f__mg$cache1;         
        // 0x0272BEC8: CBNZ x8, #0x272bf28        | if (BuglyAgent.<>f__mg$cache1 != null) goto label_8;
        if((BuglyAgent.<>f__mg$cache1) != null)
        {
            goto label_8;
        }
        // 0x0272BECC: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x0272BED0: ADRP x9, #0x363d000        | X9 = 56872960 (0x363D000);              
        // 0x0272BED4: LDR x8, [x8, #0x230]       | X8 = 1152921509929018784;               
        // 0x0272BED8: LDR x9, [x9, #0xfa8]       | X9 = 1152921504658444288;               
        // 0x0272BEDC: LDR x21, [x8]              | X21 = static System.Void BuglyAgent::_OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args);
        // 0x0272BEE0: LDR x0, [x9]               | X0 = typeof(System.UnhandledExceptionEventHandler);
        // 0x0272BEE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.UnhandledExceptionEventHandler), ????);
        // 0x0272BEE8: MOV x20, x0                | X20 = 1152921504658444288 (0x1000000003135000);//ML01
        // 0x0272BEEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BEF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272BEF4: MOV x0, x20                | X0 = 1152921504658444288 (0x1000000003135000);//ML01
        System.UnhandledExceptionEventHandler val_3 = null;
        // 0x0272BEF8: MOV x2, x21                | X2 = 1152921509929018784 (0x100000013D39E5A0);//ML01
        // 0x0272BEFC: BL #0x273a72c              | .ctor(object:  0, method:  static System.Void BuglyAgent::_OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args));
        val_3 = new System.UnhandledExceptionEventHandler(object:  0, method:  static System.Void BuglyAgent::_OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args));
        // 0x0272BF00: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_8 = null;
        // 0x0272BF04: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BF08: TBZ w8, #0, #0x272bf1c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x0272BF0C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BF10: CBNZ w8, #0x272bf1c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0272BF14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272BF18: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_8 = null;
        label_10:
        // 0x0272BF1C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BF20: STR x20, [x8, #0x98]       | BuglyAgent.<>f__mg$cache1 = typeof(System.UnhandledExceptionEventHandler);  //  dest_result_addr=1152921504776765592
        BuglyAgent.<>f__mg$cache1 = null;
        // 0x0272BF24: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_7 = null;
        label_8:
        // 0x0272BF28: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272BF2C: TBZ w8, #0, #0x272bf40     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x0272BF30: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272BF34: CBNZ w8, #0x272bf40        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x0272BF38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272BF3C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_7 = null;
        label_12:
        // 0x0272BF40: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BF44: LDR x20, [x8, #0x98]       | X20 = typeof(System.UnhandledExceptionEventHandler);
        // 0x0272BF48: CBNZ x19, #0x272bf50       | if (val_2 != null) goto label_13;       
        if(val_2 != null)
        {
            goto label_13;
        }
        // 0x0272BF4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BuglyAgent), ????);
        label_13:
        // 0x0272BF50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272BF54: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x0272BF58: MOV x1, x20                | X1 = 1152921504658444288 (0x1000000003135000);//ML01
        // 0x0272BF5C: BL #0x18c9d60              | val_2.add_UnhandledException(value:  BuglyAgent.<>f__mg$cache1);
        val_2.add_UnhandledException(value:  BuglyAgent.<>f__mg$cache1);
        // 0x0272BF60: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272BF64: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x0272BF68: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272BF6C: STRB w9, [x8, #0x50]       | BuglyAgent._isInitialized = true;        //  dest_result_addr=1152921504776765520
        BuglyAgent._isInitialized = true;
        // 0x0272BF70: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272BF74: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272BF78: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
        // 0x0272BF7C: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BF80: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272BF84: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272BF88: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BF8C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272BF90: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BF94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272BF98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BF9C: BL #0x20c7568              | X0 = UnityEngine.Application.get_unityVersion();
        string val_4 = UnityEngine.Application.unityVersion;
        // 0x0272BFA0: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x0272BFA4: CBNZ x19, #0x272bfac       | if ( != null) goto label_14;            
        if(null != null)
        {
            goto label_14;
        }
        // 0x0272BFA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_14:
        // 0x0272BFAC: CBZ x20, #0x272bfd0        | if (val_4 == null) goto label_16;       
        if(val_4 == null)
        {
            goto label_16;
        }
        // 0x0272BFB0: LDR x8, [x19]              | X8 = ;                                  
        // 0x0272BFB4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272BFB8: MOV x0, x20                | X0 = val_4;//m1                         
        val_9 = val_4;
        // 0x0272BFBC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x0272BFC0: CBNZ x0, #0x272bfd0        | if (val_4 != null) goto label_16;       
        if(val_9 != null)
        {
            goto label_16;
        }
        // 0x0272BFC4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
        // 0x0272BFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BFCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_16:
        // 0x0272BFD0: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272BFD4: CBNZ w8, #0x272bfe4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_17;
        // 0x0272BFD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x0272BFDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BFE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_17:
        // 0x0272BFE4: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;
        // 0x0272BFE8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x0272BFEC: LDR x8, [x8, #0xd8]        | X8 = (string**)(1152921509929023904)("Register the log callback in Unity {0}");
        // 0x0272BFF0: LDR x2, [x8]               | X2 = "Register the log callback in Unity {0}";
        // 0x0272BFF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272BFF8: MOV x3, x19                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272BFFC: BL #0x272b978              | BuglyAgent.DebugLog(tag:  val_9 = val_4, format:  0, args:  "Register the log callback in Unity {0}");
        BuglyAgent.DebugLog(tag:  val_9, format:  0, args:  "Register the log callback in Unity {0}");
        // 0x0272C000: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        // 0x0272C004: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C008: TBZ w8, #0, #0x272c018     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x0272C00C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C010: CBNZ w8, #0x272c018        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x0272C014: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_19:
        // 0x0272C018: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272C01C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272C020: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272C024: B #0x272f6fc               | BuglyAgent.SetUnityVersion(); return;   
        BuglyAgent.SetUnityVersion();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272F9B8 (41089464), len: 560  VirtAddr: 0x0272F9B8 RVA: 0x0272F9B8 token: 100663335 methodIndex: 24303 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _UnregisterExceptionHandler()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        string val_6;
        // 0x0272F9B8: STP x22, x21, [sp, #-0x30]! | stack[1152921509929164544] = ???;  stack[1152921509929164552] = ???;  //  dest_result_addr=1152921509929164544 |  dest_result_addr=1152921509929164552
        // 0x0272F9BC: STP x20, x19, [sp, #0x10]  | stack[1152921509929164560] = ???;  stack[1152921509929164568] = ???;  //  dest_result_addr=1152921509929164560 |  dest_result_addr=1152921509929164568
        // 0x0272F9C0: STP x29, x30, [sp, #0x20]  | stack[1152921509929164576] = ???;  stack[1152921509929164584] = ???;  //  dest_result_addr=1152921509929164576 |  dest_result_addr=1152921509929164584
        // 0x0272F9C4: ADD x29, sp, #0x20         | X29 = (1152921509929164544 + 32) = 1152921509929164576 (0x100000013D3C1F20);
        // 0x0272F9C8: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272F9CC: LDRB w8, [x19, #0xabd]     | W8 = (bool)static_value_03743ABD;       
        // 0x0272F9D0: TBNZ w8, #0, #0x272f9ec    | if (static_value_03743ABD == true) goto label_0;
        // 0x0272F9D4: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x0272F9D8: LDR x8, [x8, #0xc8]        | X8 = 0x2B8FDF8;                         
        // 0x0272F9DC: LDR w0, [x8]               | W0 = 0x1642;                            
        // 0x0272F9E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1642, ????);     
        // 0x0272F9E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272F9E8: STRB w8, [x19, #0xabd]     | static_value_03743ABD = true;            //  dest_result_addr=57948861
        label_0:
        // 0x0272F9EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272F9F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272F9F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272F9F8: BL #0x20c8898              | UnityEngine.Application.RegisterLogCallback(handler:  0);
        UnityEngine.Application.RegisterLogCallback(handler:  0);
        // 0x0272F9FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272FA00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272FA04: BL #0x18c9f00              | X0 = System.AppDomain.get_CurrentDomain();
        System.AppDomain val_1 = System.AppDomain.CurrentDomain;
        // 0x0272FA08: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x0272FA0C: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272FA10: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272FA14: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_4 = null;
        // 0x0272FA18: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FA1C: TBZ w8, #0, #0x272fa30     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272FA20: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FA24: CBNZ w8, #0x272fa30        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272FA28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272FA2C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_4 = null;
        label_2:
        // 0x0272FA30: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272FA34: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.<>f__mg$cache2;         
        // 0x0272FA38: CBNZ x8, #0x272fa98        | if (BuglyAgent.<>f__mg$cache2 != null) goto label_3;
        if((BuglyAgent.<>f__mg$cache2) != null)
        {
            goto label_3;
        }
        // 0x0272FA3C: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x0272FA40: ADRP x9, #0x363d000        | X9 = 56872960 (0x363D000);              
        // 0x0272FA44: LDR x8, [x8, #0x230]       | X8 = 1152921509929018784;               
        // 0x0272FA48: LDR x9, [x9, #0xfa8]       | X9 = 1152921504658444288;               
        // 0x0272FA4C: LDR x21, [x8]              | X21 = static System.Void BuglyAgent::_OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args);
        // 0x0272FA50: LDR x0, [x9]               | X0 = typeof(System.UnhandledExceptionEventHandler);
        // 0x0272FA54: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.UnhandledExceptionEventHandler), ????);
        // 0x0272FA58: MOV x20, x0                | X20 = 1152921504658444288 (0x1000000003135000);//ML01
        // 0x0272FA5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272FA60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272FA64: MOV x0, x20                | X0 = 1152921504658444288 (0x1000000003135000);//ML01
        System.UnhandledExceptionEventHandler val_2 = null;
        // 0x0272FA68: MOV x2, x21                | X2 = 1152921509929018784 (0x100000013D39E5A0);//ML01
        // 0x0272FA6C: BL #0x273a72c              | .ctor(object:  0, method:  static System.Void BuglyAgent::_OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args));
        val_2 = new System.UnhandledExceptionEventHandler(object:  0, method:  static System.Void BuglyAgent::_OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args));
        // 0x0272FA70: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_5 = null;
        // 0x0272FA74: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FA78: TBZ w8, #0, #0x272fa8c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x0272FA7C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FA80: CBNZ w8, #0x272fa8c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0272FA84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272FA88: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_5 = null;
        label_5:
        // 0x0272FA8C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272FA90: STR x20, [x8, #0xa0]       | BuglyAgent.<>f__mg$cache2 = typeof(System.UnhandledExceptionEventHandler);  //  dest_result_addr=1152921504776765600
        BuglyAgent.<>f__mg$cache2 = null;
        // 0x0272FA94: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_4 = null;
        label_3:
        // 0x0272FA98: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FA9C: TBZ w8, #0, #0x272fab0     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272FAA0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FAA4: CBNZ w8, #0x272fab0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272FAA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272FAAC: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_4 = null;
        label_7:
        // 0x0272FAB0: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272FAB4: LDR x20, [x8, #0xa0]       | X20 = typeof(System.UnhandledExceptionEventHandler);
        // 0x0272FAB8: CBNZ x19, #0x272fac0       | if (val_1 != null) goto label_8;        
        if(val_1 != null)
        {
            goto label_8;
        }
        // 0x0272FABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BuglyAgent), ????);
        label_8:
        // 0x0272FAC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272FAC4: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x0272FAC8: MOV x1, x20                | X1 = 1152921504658444288 (0x1000000003135000);//ML01
        // 0x0272FACC: BL #0x18c9e2c              | val_1.remove_UnhandledException(value:  BuglyAgent.<>f__mg$cache2);
        val_1.remove_UnhandledException(value:  BuglyAgent.<>f__mg$cache2);
        // 0x0272FAD0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272FAD4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272FAD8: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
        // 0x0272FADC: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272FAE0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272FAE4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272FAE8: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272FAEC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272FAF0: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272FAF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272FAF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272FAFC: BL #0x20c7568              | X0 = UnityEngine.Application.get_unityVersion();
        string val_3 = UnityEngine.Application.unityVersion;
        // 0x0272FB00: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x0272FB04: CBNZ x19, #0x272fb0c       | if ( != null) goto label_9;             
        if(null != null)
        {
            goto label_9;
        }
        // 0x0272FB08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x0272FB0C: CBZ x20, #0x272fb30        | if (val_3 == null) goto label_11;       
        if(val_3 == null)
        {
            goto label_11;
        }
        // 0x0272FB10: LDR x8, [x19]              | X8 = ;                                  
        // 0x0272FB14: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272FB18: MOV x0, x20                | X0 = val_3;//m1                         
        val_6 = val_3;
        // 0x0272FB1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x0272FB20: CBNZ x0, #0x272fb30        | if (val_3 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x0272FB24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
        // 0x0272FB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272FB2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_11:
        // 0x0272FB30: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272FB34: CBNZ w8, #0x272fb44        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_12;
        // 0x0272FB38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x0272FB3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272FB40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_12:
        // 0x0272FB44: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;
        // 0x0272FB48: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x0272FB4C: LDR x8, [x8, #0x8d8]       | X8 = (string**)(1152921509929152432)("Unregister the log callback in unity {0}");
        // 0x0272FB50: LDR x2, [x8]               | X2 = "Unregister the log callback in unity {0}";
        // 0x0272FB54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272FB58: MOV x3, x19                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272FB5C: BL #0x272b978              | BuglyAgent.DebugLog(tag:  val_6 = val_3, format:  0, args:  "Unregister the log callback in unity {0}");
        BuglyAgent.DebugLog(tag:  val_6, format:  0, args:  "Unregister the log callback in unity {0}");
        // 0x0272FB60: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272FB64: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272FB68: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272FB6C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272FBE8 (41090024), len: 440  VirtAddr: 0x0272FBE8 RVA: 0x0272FBE8 token: 100663336 methodIndex: 24304 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _OnLogCallbackHandler(string condition, string stackTrace, UnityEngine.LogType type)
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        LogCallbackDelegate val_7;
        //  | 
        LogSeverity val_8;
        // 0x0272FBE8: STP x22, x21, [sp, #-0x30]! | stack[1152921509929297136] = ???;  stack[1152921509929297144] = ???;  //  dest_result_addr=1152921509929297136 |  dest_result_addr=1152921509929297144
        // 0x0272FBEC: STP x20, x19, [sp, #0x10]  | stack[1152921509929297152] = ???;  stack[1152921509929297160] = ???;  //  dest_result_addr=1152921509929297152 |  dest_result_addr=1152921509929297160
        // 0x0272FBF0: STP x29, x30, [sp, #0x20]  | stack[1152921509929297168] = ???;  stack[1152921509929297176] = ???;  //  dest_result_addr=1152921509929297168 |  dest_result_addr=1152921509929297176
        // 0x0272FBF4: ADD x29, sp, #0x20         | X29 = (1152921509929297136 + 32) = 1152921509929297168 (0x100000013D3E2510);
        // 0x0272FBF8: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x0272FBFC: LDRB w8, [x22, #0xabe]     | W8 = (bool)static_value_03743ABE;       
        // 0x0272FC00: MOV w21, w3                | W21 = W3;//m1                           
        // 0x0272FC04: MOV x19, x2                | X19 = type;//m1                         
        // 0x0272FC08: MOV x20, x1                | X20 = stackTrace;//m1                   
        // 0x0272FC0C: TBNZ w8, #0, #0x272fc28    | if (static_value_03743ABE == true) goto label_0;
        // 0x0272FC10: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
        // 0x0272FC14: LDR x8, [x8, #0x628]       | X8 = 0x2B8FDE4;                         
        // 0x0272FC18: LDR w0, [x8]               | W0 = 0x163D;                            
        // 0x0272FC1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x163D, ????);     
        // 0x0272FC20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272FC24: STRB w8, [x22, #0xabe]     | static_value_03743ABE = true;            //  dest_result_addr=57948862
        label_0:
        // 0x0272FC28: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x0272FC2C: LDR x22, [x22, #0x938]     | X22 = 1152921504776761344;              
        // 0x0272FC30: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_6 = null;
        // 0x0272FC34: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FC38: TBZ w8, #0, #0x272fc4c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272FC3C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FC40: CBNZ w8, #0x272fc4c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272FC44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272FC48: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_6 = null;
        label_2:
        // 0x0272FC4C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272FC50: LDR x8, [x8, #0x48]        | X8 = BuglyAgent._LogCallbackEventHandler;
        val_7 = BuglyAgent._LogCallbackEventHandler;
        // 0x0272FC54: CBZ x8, #0x272fca0         | if (BuglyAgent._LogCallbackEventHandler == null) goto label_3;
        if(val_7 == null)
        {
            goto label_3;
        }
        // 0x0272FC58: LDRB w9, [x0, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FC5C: TBZ w9, #0, #0x272fc84     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x0272FC60: LDR w9, [x0, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FC64: CBNZ w9, #0x272fc84        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x0272FC68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272FC6C: LDR x8, [x22]              | X8 = typeof(BuglyAgent);                
        // 0x0272FC70: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272FC74: LDR x8, [x8, #0x48]        | X8 = BuglyAgent._LogCallbackEventHandler;
        val_7 = BuglyAgent._LogCallbackEventHandler;
        // 0x0272FC78: CBNZ x8, #0x272fc84        | if (BuglyAgent._LogCallbackEventHandler != null) goto label_6;
        if(val_7 != null)
        {
            goto label_6;
        }
        // 0x0272FC7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BuglyAgent), ????);
        // 0x0272FC80: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
        val_7 = 0;
        label_6:
        // 0x0272FC84: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272FC88: MOV x0, x8                 | X0 = 0 (0x0);//ML01                     
        // 0x0272FC8C: MOV x1, x20                | X1 = stackTrace;//m1                    
        // 0x0272FC90: MOV x2, x19                | X2 = type;//m1                          
        // 0x0272FC94: MOV w3, w21                | W3 = W3;//m1                            
        // 0x0272FC98: BL #0x272fda0              | val_7.Invoke(condition:  stackTrace, stackTrace:  type, type:  W3);
        val_7.Invoke(condition:  stackTrace, stackTrace:  type, type:  W3);
        // 0x0272FC9C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_6 = null;
        label_3:
        // 0x0272FCA0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FCA4: TBZ w8, #0, #0x272fcb4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x0272FCA8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FCAC: CBNZ w8, #0x272fcb4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x0272FCB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_8:
        // 0x0272FCB4: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272FCB8: TBZ w0, #0, #0x272fd90     | if (val_1 == false) goto label_18;      
        if(val_1 == false)
        {
            goto label_18;
        }
        // 0x0272FCBC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x0272FCC0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x0272FCC4: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x0272FCC8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272FCCC: TBZ w8, #0, #0x272fcdc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x0272FCD0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272FCD4: CBNZ w8, #0x272fcdc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x0272FCD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_11:
        // 0x0272FCDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272FCE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272FCE4: MOV x1, x20                | X1 = stackTrace;//m1                    
        // 0x0272FCE8: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_2 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272FCEC: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x0272FCF0: TBNZ w8, #0, #0x272fd1c    | if ((val_2 & 1) == true) goto label_12; 
        if(val_3 == true)
        {
            goto label_12;
        }
        // 0x0272FCF4: CBNZ x20, #0x272fcfc       | if (stackTrace != null) goto label_13;  
        if(stackTrace != null)
        {
            goto label_13;
        }
        // 0x0272FCF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_13:
        // 0x0272FCFC: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x0272FD00: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921509929285072)("[BuglyAgent] <Log>");
        // 0x0272FD04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272FD08: MOV x0, x20                | X0 = stackTrace;//m1                    
        // 0x0272FD0C: LDR x1, [x8]               | X1 = "[BuglyAgent] <Log>";              
        // 0x0272FD10: BL #0x18ad42c              | X0 = stackTrace.Contains(value:  "[BuglyAgent] <Log>");
        bool val_4 = stackTrace.Contains(value:  "[BuglyAgent] <Log>");
        // 0x0272FD14: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x0272FD18: TBNZ w8, #0, #0x272fd90    | if ((val_4 & 1) == true) goto label_18; 
        if(val_5 == true)
        {
            goto label_18;
        }
        label_12:
        // 0x0272FD1C: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_8 = null;
        // 0x0272FD20: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FD24: TBZ w8, #0, #0x272fd38     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x0272FD28: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FD2C: CBNZ w8, #0x272fd38        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x0272FD30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272FD34: LDR x0, [x22]              | X0 = typeof(BuglyAgent);                
        val_8 = null;
        label_16:
        // 0x0272FD38: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272FD3C: LDRB w8, [x8, #0x88]       | W8 = BuglyAgent._uncaughtAutoReportOnce;
        // 0x0272FD40: CBNZ w8, #0x272fd90        | if (BuglyAgent._uncaughtAutoReportOnce == true) goto label_18;
        if(BuglyAgent._uncaughtAutoReportOnce == true)
        {
            goto label_18;
        }
        // 0x0272FD44: CMP w21, #4                | STATE = COMPARE(W3, 0x4)                
        // 0x0272FD48: B.HI #0x272fd90            | if (W3 > 0x4) goto label_18;            
        if(W3 > 4)
        {
            goto label_18;
        }
        // 0x0272FD4C: ADRP x8, #0x2adc000        | X8 = 44941312 (0x2ADC000);              
        // 0x0272FD50: ADD x8, x8, #0xda0         | X8 = (44941312 + 3488) = 44944800 (0x02ADCDA0);
        // 0x0272FD54: LDR w21, [x8, w21, sxtw #2] | W21 = 44944800 + (W3) << 2;             
        // 0x0272FD58: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272FD5C: TBZ w8, #0, #0x272fd6c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x0272FD60: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272FD64: CBNZ w8, #0x272fd6c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x0272FD68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_20:
        // 0x0272FD6C: MOV x3, x20                | X3 = stackTrace;//m1                    
        // 0x0272FD70: MOV x4, x19                | X4 = type;//m1                          
        // 0x0272FD74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272FD78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272FD7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272FD80: ORR w5, wzr, #1            | W5 = 1(0x1);                            
        // 0x0272FD84: MOV w1, w21                | W1 = 44944800 + (W3) << 2;//m1          
        // 0x0272FD88: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272FD8C: B #0x272cecc               | BuglyAgent._HandleException(logLevel:  val_8 = null, name:  44944800 + (W3) << 2, message:  0, stackTrace:  stackTrace, uncaught:  type); return;
        BuglyAgent._HandleException(logLevel:  val_8, name:  44944800 + (W3) << 2, message:  0, stackTrace:  stackTrace, uncaught:  type);
        return;
        label_18:
        // 0x0272FD90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272FD94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272FD98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272FD9C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0273018C (41091468), len: 680  VirtAddr: 0x0273018C RVA: 0x0273018C token: 100663337 methodIndex: 24305 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _OnUncaughtExceptionHandler(object sender, System.UnhandledExceptionEventArgs args)
    {
        //
        // Disasemble & Code
        //  | 
        System.Exception val_8;
        //  | 
        string val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        // 0x0273018C: STP x22, x21, [sp, #-0x30]! | stack[1152921509929450096] = ???;  stack[1152921509929450104] = ???;  //  dest_result_addr=1152921509929450096 |  dest_result_addr=1152921509929450104
        // 0x02730190: STP x20, x19, [sp, #0x10]  | stack[1152921509929450112] = ???;  stack[1152921509929450120] = ???;  //  dest_result_addr=1152921509929450112 |  dest_result_addr=1152921509929450120
        // 0x02730194: STP x29, x30, [sp, #0x20]  | stack[1152921509929450128] = ???;  stack[1152921509929450136] = ???;  //  dest_result_addr=1152921509929450128 |  dest_result_addr=1152921509929450136
        // 0x02730198: ADD x29, sp, #0x20         | X29 = (1152921509929450096 + 32) = 1152921509929450128 (0x100000013D407A90);
        // 0x0273019C: SUB sp, sp, #0x10          | SP = (1152921509929450096 - 16) = 1152921509929450080 (0x100000013D407A60);
        // 0x027301A0: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x027301A4: LDRB w8, [x20, #0xabf]     | W8 = (bool)static_value_03743ABF;       
        // 0x027301A8: MOV x19, x2                | X19 = X2;//m1                           
        val_9 = X2;
        // 0x027301AC: TBNZ w8, #0, #0x27301c8    | if (static_value_03743ABF == true) goto label_0;
        // 0x027301B0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x027301B4: LDR x8, [x8, #0x718]       | X8 = 0x2B8FDE8;                         
        // 0x027301B8: LDR w0, [x8]               | W0 = 0x163E;                            
        // 0x027301BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x163E, ????);     
        // 0x027301C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x027301C4: STRB w8, [x20, #0xabf]     | static_value_03743ABF = true;            //  dest_result_addr=57948863
        label_0:
        // 0x027301C8: CBZ x19, #0x2730334        | if (X2 == 0) goto label_12;             
        if(val_9 == 0)
        {
            goto label_12;
        }
        // 0x027301CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027301D0: MOV x0, x19                | X0 = X2;//m1                            
        // 0x027301D4: BL #0x273a71c              | X0 = X2.get_ExceptionObject();          
        object val_1 = val_9.ExceptionObject;
        // 0x027301D8: CBZ x0, #0x2730334         | if (val_1 == null) goto label_12;       
        if(val_1 == null)
        {
            goto label_12;
        }
        // 0x027301DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027301E0: MOV x0, x19                | X0 = X2;//m1                            
        // 0x027301E4: BL #0x273a71c              | X0 = X2.get_ExceptionObject();          
        object val_2 = val_9.ExceptionObject;
        // 0x027301E8: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x027301EC: CBNZ x20, #0x27301f4       | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x027301F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x027301F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027301F8: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x027301FC: BL #0x16fb28c              | X0 = val_2.GetType();                   
        System.Type val_3 = val_2.GetType();
        // 0x02730200: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x02730204: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x02730208: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
        // 0x0273020C: LDR x0, [x8]               | X0 = typeof(System.Type);               
        // 0x02730210: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x02730214: LDR x8, [x8, #0x2b0]       | X8 = 1152921504609882112;               
        // 0x02730218: LDR x21, [x8]              | X21 = typeof(System.Exception);         
        // 0x0273021C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
        // 0x02730220: TBZ w8, #0, #0x2730230     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02730224: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
        // 0x02730228: CBNZ w8, #0x2730230        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x0273022C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
        label_5:
        // 0x02730230: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02730234: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730238: MOV x1, x21                | X1 = 1152921504609882112 (0x10000000002E5000);//ML01
        // 0x0273023C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x02730240: CMP x20, x0                | STATE = COMPARE(val_3, val_4)           
        // 0x02730244: B.NE #0x2730334            | if (val_3 != val_4) goto label_12;      
        if(val_3 != val_4)
        {
            goto label_12;
        }
        // 0x02730248: ADRP x20, #0x3652000       | X20 = 56958976 (0x3652000);             
        // 0x0273024C: LDR x20, [x20, #0x938]     | X20 = 1152921504776761344;              
        // 0x02730250: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        // 0x02730254: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730258: TBZ w8, #0, #0x2730268     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x0273025C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730260: CBNZ w8, #0x2730268        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02730264: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_8:
        // 0x02730268: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_5 = BuglyAgent.IsInitialized;
        // 0x0273026C: TBZ w0, #0, #0x2730334     | if (val_5 == false) goto label_12;      
        if(val_5 == false)
        {
            goto label_12;
        }
        // 0x02730270: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_10 = null;
        // 0x02730274: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730278: TBZ w8, #0, #0x273028c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x0273027C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730280: CBNZ w8, #0x273028c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x02730284: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x02730288: LDR x0, [x20]              | X0 = typeof(BuglyAgent);                
        val_10 = null;
        label_11:
        // 0x0273028C: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730290: LDRB w8, [x8, #0x88]       | W8 = BuglyAgent._uncaughtAutoReportOnce;
        // 0x02730294: CBNZ w8, #0x2730334        | if (BuglyAgent._uncaughtAutoReportOnce == true) goto label_12;
        if(BuglyAgent._uncaughtAutoReportOnce == true)
        {
            goto label_12;
        }
        // 0x02730298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0273029C: MOV x0, x19                | X0 = X2;//m1                            
        // 0x027302A0: BL #0x273a71c              | X0 = X2.get_ExceptionObject();          
        object val_6 = val_9.ExceptionObject;
        // 0x027302A4: LDR x8, [x20]              | X8 = typeof(BuglyAgent);                
        // 0x027302A8: MOV x19, x0                | X19 = val_6;//m1                        
        val_9 = val_6;
        // 0x027302AC: LDRB w9, [x8, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x027302B0: TBZ w9, #0, #0x27302c4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x027302B4: LDR w9, [x8, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x027302B8: CBNZ w9, #0x27302c4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x027302BC: MOV x0, x8                 | X0 = 1152921504776761344 (0x100000000A20B000);//ML01
        val_11 = null;
        // 0x027302C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_14:
        // 0x027302C4: CBZ x19, #0x2730320        | if (val_6 == null) goto label_15;       
        if(val_9 == null)
        {
            goto label_15;
        }
        // 0x027302C8: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
        // 0x027302CC: LDR x9, [x9, #0xf98]       | X9 = 1152921504609882112;               
        // 0x027302D0: LDR x8, [x19]              | X8 = typeof(System.Object);             
        // 0x027302D4: LDR x1, [x9]               | X1 = typeof(System.Exception);          
        // 0x027302D8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x027302DC: LDRB w9, [x1, #0x104]      | W9 = System.Exception.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x027302E0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Exception.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x027302E4: B.LO #0x27302fc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Exception.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
        // 0x027302E8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
        // 0x027302EC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Exception.__il2cppRuntimeField_type
        // 0x027302F0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Exception.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x027302F4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Exception.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Exception))
        // 0x027302F8: B.EQ #0x2730324            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Exception.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
        label_16:
        // 0x027302FC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x02730300: ADD x8, sp, #8             | X8 = (1152921509929450080 + 8) = 1152921509929450088 (0x100000013D407A68);
        // 0x02730304: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x02730308: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921509929438144]
        // 0x0273030C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
        // 0x02730310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730314: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        // 0x02730318: ADD x0, sp, #8             | X0 = (1152921509929450080 + 8) = 1152921509929450088 (0x100000013D407A68);
        // 0x0273031C: BL #0x299a140              | 
        label_15:
        // 0x02730320: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        val_9 = 0;
        label_17:
        // 0x02730324: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730328: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x0273032C: MOV x1, x19                | X1 = 0 (0x0);//ML01                     
        // 0x02730330: BL #0x272c640              | BuglyAgent._HandleException(e:  System.Exception val_8, message:  val_9, uncaught:  false);
        BuglyAgent._HandleException(e:  val_8, message:  val_9, uncaught:  false);
        label_12:
        // 0x02730334: SUB sp, x29, #0x20         | SP = (1152921509929450128 - 32) = 1152921509929450096 (0x100000013D407A70);
        // 0x02730338: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0273033C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02730340: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02730344: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272C640 (41076288), len: 1740  VirtAddr: 0x0272C640 RVA: 0x0272C640 token: 100663338 methodIndex: 24306 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _HandleException(System.Exception e, string message, bool uncaught)
    {
        //
        // Disasemble & Code
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        object val_32;
        //  | 
        var val_33;
        //  | 
        var val_34;
        //  | 
        object val_35;
        //  | 
        var val_36;
        //  | 
        string val_37;
        //  | 
        string val_38;
        //  | 
        object val_39;
        //  | 
        string val_40;
        //  | 
        int val_41;
        //  | 
        var val_42;
        // 0x0272C640: STP x28, x27, [sp, #-0x60]! | stack[1152921509929669456] = ???;  stack[1152921509929669464] = ???;  //  dest_result_addr=1152921509929669456 |  dest_result_addr=1152921509929669464
        // 0x0272C644: STP x26, x25, [sp, #0x10]  | stack[1152921509929669472] = ???;  stack[1152921509929669480] = ???;  //  dest_result_addr=1152921509929669472 |  dest_result_addr=1152921509929669480
        // 0x0272C648: STP x24, x23, [sp, #0x20]  | stack[1152921509929669488] = ???;  stack[1152921509929669496] = ???;  //  dest_result_addr=1152921509929669488 |  dest_result_addr=1152921509929669496
        // 0x0272C64C: STP x22, x21, [sp, #0x30]  | stack[1152921509929669504] = ???;  stack[1152921509929669512] = ???;  //  dest_result_addr=1152921509929669504 |  dest_result_addr=1152921509929669512
        // 0x0272C650: STP x20, x19, [sp, #0x40]  | stack[1152921509929669520] = ???;  stack[1152921509929669528] = ???;  //  dest_result_addr=1152921509929669520 |  dest_result_addr=1152921509929669528
        // 0x0272C654: STP x29, x30, [sp, #0x50]  | stack[1152921509929669536] = ???;  stack[1152921509929669544] = ???;  //  dest_result_addr=1152921509929669536 |  dest_result_addr=1152921509929669544
        // 0x0272C658: ADD x29, sp, #0x50         | X29 = (1152921509929669456 + 80) = 1152921509929669536 (0x100000013D43D3A0);
        // 0x0272C65C: SUB sp, sp, #0x30          | SP = (1152921509929669456 - 48) = 1152921509929669408 (0x100000013D43D320);
        // 0x0272C660: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272C664: LDRB w8, [x19, #0xac0]     | W8 = (bool)static_value_03743AC0;       
        // 0x0272C668: MOV w21, w3                | W21 = W3;//m1                           
        val_30 = W3;
        // 0x0272C66C: MOV x22, x2                | X22 = uncaught;//m1                     
        // 0x0272C670: MOV x24, x1                | X24 = message;//m1                      
        // 0x0272C674: TBNZ w8, #0, #0x272c690    | if (static_value_03743AC0 == true) goto label_0;
        // 0x0272C678: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x0272C67C: LDR x8, [x8, #0xeb8]       | X8 = 0x2B8FDDC;                         
        // 0x0272C680: LDR w0, [x8]               | W0 = 0x163B;                            
        // 0x0272C684: BL #0x2782188              | X0 = sub_2782188( ?? 0x163B, ????);     
        // 0x0272C688: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272C68C: STRB w8, [x19, #0xac0]     | static_value_03743AC0 = true;            //  dest_result_addr=57948864
        label_0:
        // 0x0272C690: CBZ x24, #0x272ccec        | if (message == null) goto label_4;      
        if(message == null)
        {
            goto label_4;
        }
        // 0x0272C694: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272C698: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272C69C: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x0272C6A0: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272C6A4: TBZ w8, #0, #0x272c6b4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x0272C6A8: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272C6AC: CBNZ w8, #0x272c6b4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x0272C6B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_3:
        // 0x0272C6B4: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272C6B8: TBZ w0, #0, #0x272ccec     | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x0272C6BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C6C0: MOV x0, x24                | X0 = message;//m1                       
        // 0x0272C6C4: BL #0x1c3e6b4              | X0 = message.GetType();                 
        System.Type val_2 = message.GetType();
        // 0x0272C6C8: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x0272C6CC: CBNZ x20, #0x272c6d4       | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x0272C6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x0272C6D4: LDR x8, [x20]              | X8 = typeof(System.Type);               
        // 0x0272C6D8: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x0272C6DC: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Type).__il2cppRuntimeField_190; X1 = typeof(System.Type).__il2cppRuntimeField_198; //  | 
        // 0x0272C6E0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_190();
        // 0x0272C6E4: LDR x8, [x24]              | X8 = typeof(System.String);             
        // 0x0272C6E8: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x0272C6EC: MOV x0, x24                | X0 = message;//m1                       
        // 0x0272C6F0: LDR x9, [x8, #0x260]       | X9 = typeof(System.String).__il2cppRuntimeField_260;
        // 0x0272C6F4: LDR x1, [x8, #0x268]       | X1 = typeof(System.String).__il2cppRuntimeField_268;
        // 0x0272C6F8: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_260();
        // 0x0272C6FC: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
        // 0x0272C700: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
        val_31 = 1152921504608284672;
        // 0x0272C704: MOV x20, x0                | X20 = message;//m1                      
        val_32 = message;
        // 0x0272C708: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x0272C70C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x0272C710: TBZ w9, #0, #0x272c724     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272C714: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272C718: CBNZ w9, #0x272c724        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272C71C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x0272C720: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_7:
        // 0x0272C724: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272C728: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272C72C: MOV x1, x22                | X1 = uncaught;//m1                      
        // 0x0272C730: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_3 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272C734: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x0272C738: TBNZ w8, #0, #0x272c798    | if ((val_3 & 1) == true) goto label_8;  
        if(val_4 == true)
        {
            goto label_8;
        }
        // 0x0272C73C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272C740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272C744: BL #0x1c368ec              | X0 = System.Environment.get_NewLine();  
        string val_5 = System.Environment.NewLine;
        // 0x0272C748: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x0272C74C: MOV x25, x23               | X25 = 57977240 (0x374A998);//ML01       
        val_33 = val_31;
        // 0x0272C750: MOV x23, x0                | X23 = val_5;//m1                        
        // 0x0272C754: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x0272C758: TBZ w9, #0, #0x272c76c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x0272C75C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272C760: CBNZ w9, #0x272c76c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0272C764: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x0272C768: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x0272C76C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x0272C770: LDR x8, [x8, #0xaf0]       | X8 = (string**)(1152921509929595200)("{0}{1}***{2}");
        // 0x0272C774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272C778: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0272C77C: MOV x2, x20                | X2 = message;//m1                       
        // 0x0272C780: LDR x1, [x8]               | X1 = "{0}{1}***{2}";                    
        // 0x0272C784: MOV x3, x23                | X3 = val_5;//m1                         
        // 0x0272C788: MOV x4, x22                | X4 = uncaught;//m1                      
        // 0x0272C78C: BL #0x18af46c              | X0 = System.String.Format(format:  0, arg0:  "{0}{1}***{2}", arg1:  val_32, arg2:  val_5);
        string val_6 = System.String.Format(format:  0, arg0:  "{0}{1}***{2}", arg1:  val_32, arg2:  val_5);
        // 0x0272C790: MOV x20, x0                | X20 = val_6;//m1                        
        val_32 = val_6;
        // 0x0272C794: MOV x23, x25               | X23 = 57977240 (0x374A998);//ML01       
        val_31 = val_33;
        label_8:
        // 0x0272C798: LDR x0, [x23]              | X0 = typeof(System.String);             
        // 0x0272C79C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272C7A0: TBNZ w8, #0, #0x272c7b0    | if (System.String.__il2cppRuntimeField_has_cctor != 0) goto label_11;
        // 0x0272C7A4: STP x20, x19, [sp, #8]     | stack[1152921509929669416] = val_6;  stack[1152921509929669424] = val_2;  //  dest_result_addr=1152921509929669416 |  dest_result_addr=1152921509929669424
        // 0x0272C7A8: STR w21, [sp, #0x18]       | stack[1152921509929669432] = W3;         //  dest_result_addr=1152921509929669432
        // 0x0272C7AC: B #0x272c7c8               |  goto label_13;                         
        goto label_13;
        label_11:
        // 0x0272C7B0: STP x20, x19, [sp, #8]     | stack[1152921509929669416] = val_6;  stack[1152921509929669424] = val_2;  //  dest_result_addr=1152921509929669416 |  dest_result_addr=1152921509929669424
        // 0x0272C7B4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272C7B8: STR w21, [sp, #0x18]       | stack[1152921509929669432] = W3;         //  dest_result_addr=1152921509929669432
        // 0x0272C7BC: CBNZ w8, #0x272c7c8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x0272C7C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x0272C7C4: LDR x0, [x23]              | X0 = typeof(System.String);             
        val_34 = null;
        label_13:
        // 0x0272C7C8: ADRP x9, #0x35fd000        | X9 = 56610816 (0x35FD000);              
        // 0x0272C7CC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x0272C7D0: LDR x9, [x9, #0x978]       | X9 = 1152921504649605120;               
        // 0x0272C7D4: LDR x20, [x8]              | X20 = System.String.Empty;              
        // 0x0272C7D8: LDR x0, [x9]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_7 = null;
        // 0x0272C7DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x0272C7E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272C7E4: MOV x1, x20                | X1 = System.String.Empty;//m1           
        // 0x0272C7E8: MOV x22, x0                | X22 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272C7EC: BL #0x1b5a314              | .ctor(value:  System.String.Empty);     
        val_7 = new System.Text.StringBuilder(value:  System.String.Empty);
        // 0x0272C7F0: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x0272C7F4: LDR x8, [x8, #0xf0]        | X8 = 1152921504619520000;               
        // 0x0272C7F8: LDR x0, [x8]               | X0 = typeof(System.Diagnostics.StackTrace);
        System.Diagnostics.StackTrace val_8 = null;
        // 0x0272C7FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Diagnostics.StackTrace), ????);
        // 0x0272C800: MOV x19, x0                | X19 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C804: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272C808: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        val_35 = 1;
        // 0x0272C80C: MOV x1, x24                | X1 = message;//m1                       
        // 0x0272C810: STR x19, [sp, #0x20]       | stack[1152921509929669440] = typeof(System.Diagnostics.StackTrace);  //  dest_result_addr=1152921509929669440
        // 0x0272C814: BL #0x1c35e90              | .ctor(e:  message, fNeedFileInfo:  true);
        val_8 = new System.Diagnostics.StackTrace(e:  message, fNeedFileInfo:  true);
        // 0x0272C818: CBNZ x19, #0x272c820       | if ( != 0) goto label_14;               
        if(null != 0)
        {
            goto label_14;
        }
        // 0x0272C81C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(e:  message, fNeedFileInfo:  true), ????);
        label_14:
        // 0x0272C820: LDR x8, [x19]              | X8 = ;                                  
        // 0x0272C824: MOV x0, x19                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C828: LDP x9, x1, [x8, #0x150]   |                                          //  not_find_field!1:336 |  not_find_field!1:344
        val_36 = mem[null + 336 + 8];
        // 0x0272C82C: BLR x9                     | X0 = mem[null + 336]();                 
        // 0x0272C830: MOV w21, w0                | W21 = 1152921504619520000 (0x1000000000C16000);//ML01
        val_30 = val_8;
        // 0x0272C834: STR w21, [sp, #0x1c]       | stack[1152921509929669436] = typeof(System.Diagnostics.StackTrace);  //  dest_result_addr=1152921509929669436
        // 0x0272C838: CMP w21, #1                | STATE = COMPARE(typeof(System.Diagnostics.StackTrace), 0x1)
        // 0x0272C83C: B.LT #0x272cc98            | if (val_30 < 0x1) goto label_15;        
        if(val_30 < 1)
        {
            goto label_15;
        }
        // 0x0272C840: ADRP x24, #0x360a000       | X24 = 56664064 (0x360A000);             
        // 0x0272C844: LDR x24, [x24, #0x9a8]     | X24 = (string**)(1152921509929599392)("{0}.{1}");
        // 0x0272C848: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        label_57:
        // 0x0272C84C: CBNZ x19, #0x272c854       | if ( != 0) goto label_16;               
        if(null != 0)
        {
            goto label_16;
        }
        // 0x0272C850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_16:
        // 0x0272C854: LDR x8, [x19]              | X8 = ;                                  
        // 0x0272C858: MOV x0, x19                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C85C: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
        // 0x0272C860: LDP x9, x2, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
        // 0x0272C864: BLR x9                     | X0 = mem[null + 352]();                 
        // 0x0272C868: MOV x26, x0                | X26 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C86C: CBNZ x26, #0x272c874       | if ( != 0) goto label_17;               
        if(null != 0)
        {
            goto label_17;
        }
        // 0x0272C870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_17:
        // 0x0272C874: LDR x8, [x26]              | X8 = ;                                  
        // 0x0272C878: MOV x0, x26                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C87C: LDP x9, x1, [x8, #0x180]   |                                          //  not_find_field!1:384 |  not_find_field!1:392
        // 0x0272C880: BLR x9                     | X0 = mem[null + 384]();                 
        // 0x0272C884: MOV x20, x0                | X20 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C888: CBNZ x20, #0x272c890       | if ( != 0) goto label_18;               
        if(null != 0)
        {
            goto label_18;
        }
        // 0x0272C88C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_18:
        // 0x0272C890: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272C894: MOV x0, x20                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C898: LDP x9, x1, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
        // 0x0272C89C: BLR x9                     | X0 = mem[null + 368]();                 
        // 0x0272C8A0: MOV x20, x0                | X20 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8A4: CBNZ x20, #0x272c8ac       | if ( != 0) goto label_19;               
        if(null != 0)
        {
            goto label_19;
        }
        // 0x0272C8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_19:
        // 0x0272C8AC: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272C8B0: MOV x0, x20                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8B4: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
        // 0x0272C8B8: BLR x9                     | X0 = mem[null + 400]();                 
        // 0x0272C8BC: MOV x27, x0                | X27 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8C0: CBNZ x26, #0x272c8c8       | if ( != 0) goto label_20;               
        if(null != 0)
        {
            goto label_20;
        }
        // 0x0272C8C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_20:
        // 0x0272C8C8: LDR x8, [x26]              | X8 = ;                                  
        // 0x0272C8CC: MOV x0, x26                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8D0: LDP x9, x1, [x8, #0x180]   |                                          //  not_find_field!1:384 |  not_find_field!1:392
        // 0x0272C8D4: BLR x9                     | X0 = mem[null + 384]();                 
        // 0x0272C8D8: MOV x20, x0                | X20 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8DC: CBNZ x20, #0x272c8e4       | if ( != 0) goto label_21;               
        if(null != 0)
        {
            goto label_21;
        }
        // 0x0272C8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_21:
        // 0x0272C8E4: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272C8E8: MOV x0, x20                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8EC: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
        // 0x0272C8F0: BLR x9                     | X0 = mem[null + 400]();                 
        // 0x0272C8F4: MOV x20, x0                | X20 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C8F8: CBNZ x22, #0x272c900       | if ( != 0) goto label_22;               
        if(null != 0)
        {
            goto label_22;
        }
        // 0x0272C8FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_22:
        // 0x0272C900: LDR x1, [x24]              | X1 = "{0}.{1}";                         
        // 0x0272C904: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272C908: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272C90C: MOV x2, x27                | X2 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C910: MOV x3, x20                | X3 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C914: BL #0x1b5c224              | X0 = AppendFormat(format:  "{0}.{1}", arg0:  val_8, arg1:  val_8);
        System.Text.StringBuilder val_9 = AppendFormat(format:  "{0}.{1}", arg0:  val_8, arg1:  val_8);
        // 0x0272C918: CBNZ x26, #0x272c920       | if ( != 0) goto label_23;               
        if(null != 0)
        {
            goto label_23;
        }
        // 0x0272C91C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_23:
        // 0x0272C920: LDR x8, [x26]              | X8 = ;                                  
        // 0x0272C924: MOV x0, x26                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C928: LDP x9, x1, [x8, #0x180]   |                                          //  not_find_field!1:384 |  not_find_field!1:392
        // 0x0272C92C: BLR x9                     | X0 = mem[null + 384]();                 
        // 0x0272C930: MOV x20, x0                | X20 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C934: CBNZ x20, #0x272c93c       | if ( != 0) goto label_24;               
        if(null != 0)
        {
            goto label_24;
        }
        // 0x0272C938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_24:
        // 0x0272C93C: LDR x8, [x20]              | X8 = ;                                  
        // 0x0272C940: MOV x0, x20                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C944: LDR x9, [x8, #0x200]       |  //  not_find_field!1:512
        // 0x0272C948: LDR x1, [x8, #0x208]       |  //  not_find_field!1:520
        // 0x0272C94C: BLR x9                     | X0 = mem[null + 512]();                 
        // 0x0272C950: MOV x27, x0                | X27 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272C954: CBZ x27, #0x272ca98        | if ( == 0) goto label_26;               
        if(null == 0)
        {
            goto label_26;
        }
        // 0x0272C958: LDR w8, [x27, #0x18]       | W8 = System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze;
        // 0x0272C95C: CBZ w8, #0x272ca98         | if (System.Diagnostics == null) goto label_26;
        if(System.Diagnostics == null)
        {
            goto label_26;
        }
        // 0x0272C960: CBNZ x22, #0x272c968       | if ( != 0) goto label_27;               
        if(null != 0)
        {
            goto label_27;
        }
        // 0x0272C964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_27:
        // 0x0272C968: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x0272C96C: LDR x8, [x8, #0xb40]       | X8 = (string**)(1152921509929603584)(" (");
        // 0x0272C970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272C974: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272C978: LDR x1, [x8]               | X1 = " (";                              
        val_37 = " (";
        // 0x0272C97C: BL #0x1b5b818              | X0 = Append(value:  val_37 = " (");     
        System.Text.StringBuilder val_10 = Append(value:  val_37);
        // 0x0272C980: LDR x24, [x27, #0x18]      | X24 = System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze;
        // 0x0272C984: CMP w24, #1                | STATE = COMPARE(System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272C988: B.LT #0x272ca5c            | if (System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze < 0x1) goto label_28;
        // 0x0272C98C: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        var val_29 = 0;
        // 0x0272C990: SUB w23, w24, #1           | W23 = (System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze - 1) = 1152921505068996191 (0x100000001B8BD65F);
        // 0x0272C994: ADD x21, x27, #0x20        | X21 = (val_8 + 32) = 1152921504619520032 (0x1000000000C16020);
        label_35:
        // 0x0272C998: LDR w8, [x27, #0x18]       | W8 = System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze;
        // 0x0272C99C: CMP x19, x8                | STATE = COMPARE(0x0, System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze)
        // 0x0272C9A0: B.LO #0x272c9b0            | if (0 < System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze) goto label_29;
        // 0x0272C9A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
        // 0x0272C9A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_37 = 0;
        // 0x0272C9AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
        label_29:
        // 0x0272C9B0: LDR x28, [x21, x19, lsl #3] | X28 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;
        // 0x0272C9B4: CBNZ x28, #0x272c9bc       | if (System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg != 0) goto label_30;
        // 0x0272C9B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_30:
        // 0x0272C9BC: LDR x8, [x28]              | X8 =  typeof(Il2CppType*);              
        // 0x0272C9C0: MOV x0, x28                | X0 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272C9C4: LDP x9, x1, [x8, #0x170]   | X9 = 0x0; X1 = 0x0;                      //  | 
        // 0x0272C9C8: BLR x9                     | X0 = x9();                              
        // 0x0272C9CC: MOV x20, x0                | X20 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272C9D0: CBNZ x20, #0x272c9d8       | if (System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg != 0) goto label_31;
        // 0x0272C9D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg, ????);
        label_31:
        // 0x0272C9D8: LDR x8, [x20]              | X8 =  typeof(Il2CppType*);              
        // 0x0272C9DC: MOV x0, x20                | X0 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272C9E0: LDP x9, x1, [x8, #0x190]   | X9 = 0x1400000004; X1 = 0x554E4700000003; //  | 
        // 0x0272C9E4: BLR x9                     | X0 = sub_1400000004( ?? System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg, ????);
        // 0x0272C9E8: LDR x8, [x28]              | X8 =  typeof(Il2CppType*);              
        // 0x0272C9EC: MOV x20, x0                | X20 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272C9F0: MOV x0, x28                | X0 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272C9F4: LDP x9, x1, [x8, #0x1a0]   | X9 = 0x4ECDD30E414271A; X1 = 0x7C18E9D84027EF82; //  | 
        // 0x0272C9F8: BLR x9                     | X0 = sub_4ECDD30E414271A( ?? System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg, ????);
        // 0x0272C9FC: MOV x28, x0                | X28 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272CA00: CBNZ x22, #0x272ca08       | if ( != 0) goto label_32;               
        if(null != 0)
        {
            goto label_32;
        }
        // 0x0272CA04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg, ????);
        label_32:
        // 0x0272CA08: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x0272CA0C: LDR x8, [x8, #0xc50]       | X8 = (string**)(1152921509929607760)("{0} {1}");
        // 0x0272CA10: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272CA14: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CA18: MOV x2, x20                | X2 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272CA1C: LDR x1, [x8]               | X1 = "{0} {1}";                         
        // 0x0272CA20: MOV x3, x28                | X3 = System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg;//m1
        // 0x0272CA24: BL #0x1b5c224              | X0 = AppendFormat(format:  "{0} {1}", arg0:  System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg, arg1:  System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg);
        System.Text.StringBuilder val_11 = AppendFormat(format:  "{0} {1}", arg0:  System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg, arg1:  System.Diagnostics.StackTrace.__il2cppRuntimeField_byval_arg);
        // 0x0272CA28: CMP x23, x19               | STATE = COMPARE(0x100000001B8BD65F, 0x0)
        // 0x0272CA2C: B.EQ #0x272ca50            | if (1152921505068996191 == 0) goto label_33;
        if(1152921505068996191 == val_29)
        {
            goto label_33;
        }
        // 0x0272CA30: CBNZ x22, #0x272ca38       | if ( != 0) goto label_34;               
        if(null != 0)
        {
            goto label_34;
        }
        // 0x0272CA34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_34:
        // 0x0272CA38: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x0272CA3C: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
        // 0x0272CA40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272CA44: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CA48: LDR x1, [x8]               | X1 = ", ";                              
        // 0x0272CA4C: BL #0x1b5b818              | X0 = Append(value:  ", ");              
        System.Text.StringBuilder val_12 = Append(value:  ", ");
        label_33:
        // 0x0272CA50: ADD x19, x19, #1           | X19 = (0 + 1);                          
        val_29 = val_29 + 1;
        // 0x0272CA54: CMP w24, w19               | STATE = COMPARE(System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze, (0 + 1))
        // 0x0272CA58: B.NE #0x272c998            | if (System.Diagnostics.StackTrace.__il2cppRuntimeField_namespaze != 0) goto label_35;
        label_28:
        // 0x0272CA5C: ADRP x24, #0x360a000       | X24 = 56664064 (0x360A000);             
        // 0x0272CA60: LDR x24, [x24, #0x9a8]     | X24 = (string**)(1152921509929599392)("{0}.{1}");
        // 0x0272CA64: CBNZ x22, #0x272ca6c       | if ( != 0) goto label_36;               
        if(null != 0)
        {
            goto label_36;
        }
        // 0x0272CA68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_36:
        // 0x0272CA6C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x0272CA70: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921509929616048)(") ");
        // 0x0272CA74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272CA78: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CA7C: LDR x1, [x8]               | X1 = ") ";                              
        val_38 = ") ";
        // 0x0272CA80: BL #0x1b5b818              | X0 = Append(value:  val_38 = ") ");     
        System.Text.StringBuilder val_13 = Append(value:  val_38);
        // 0x0272CA84: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
        // 0x0272CA88: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
        val_31 = 1152921504608284672;
        // 0x0272CA8C: LDR x19, [sp, #0x20]       | X19 = typeof(System.Diagnostics.StackTrace);
        // 0x0272CA90: LDR w21, [sp, #0x1c]       | W21 = typeof(System.Diagnostics.StackTrace);
        val_30 = val_30;
        // 0x0272CA94: B #0x272cab8               |  goto label_37;                         
        goto label_37;
        label_26:
        // 0x0272CA98: CBNZ x22, #0x272caa0       | if ( != 0) goto label_38;               
        if(null != 0)
        {
            goto label_38;
        }
        // 0x0272CA9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_38:
        // 0x0272CAA0: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x0272CAA4: LDR x8, [x8, #0x2a8]       | X8 = (string**)(1152921509929620224)(" () ");
        // 0x0272CAA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272CAAC: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CAB0: LDR x1, [x8]               | X1 = " () ";                            
        val_38 = " () ";
        // 0x0272CAB4: BL #0x1b5b818              | X0 = Append(value:  val_38 = " () ");   
        System.Text.StringBuilder val_14 = Append(value:  val_38);
        label_37:
        // 0x0272CAB8: CBNZ x26, #0x272cac0       | if ( != 0) goto label_39;               
        if(null != 0)
        {
            goto label_39;
        }
        // 0x0272CABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_39:
        // 0x0272CAC0: LDR x8, [x26]              | X8 = ;                                  
        // 0x0272CAC4: MOV x0, x26                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272CAC8: LDP x9, x1, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
        // 0x0272CACC: BLR x9                     | X0 = mem[null + 352]();                 
        // 0x0272CAD0: LDR x8, [x23]              | X8 = typeof(System.String);             
        // 0x0272CAD4: MOV x27, x0                | X27 = 1152921504619520000 (0x1000000000C16000);//ML01
        val_39 = val_8;
        // 0x0272CAD8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x0272CADC: TBZ w9, #0, #0x272caf0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_41;
        // 0x0272CAE0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272CAE4: CBNZ w9, #0x272caf0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
        // 0x0272CAE8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x0272CAEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_41:
        // 0x0272CAF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272CAF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_35 = 0;
        // 0x0272CAF8: MOV x1, x27                | X1 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272CAFC: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_15 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272CB00: AND w8, w0, #1             | W8 = (val_15 & 1);                      
        bool val_16 = val_15;
        // 0x0272CB04: TBNZ w8, #0, #0x272cc78    | if ((val_15 & 1) == true) goto label_45;
        if(val_16 == true)
        {
            goto label_45;
        }
        // 0x0272CB08: CBNZ x27, #0x272cb10       | if ( != 0) goto label_43;               
        if(null != 0)
        {
            goto label_43;
        }
        // 0x0272CB0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_43:
        // 0x0272CB10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CB14: MOV x0, x27                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272CB18: BL #0x18aedb8              | X0 = ToLower();                         
        string val_17 = ToLower();
        // 0x0272CB1C: MOV x20, x0                | X20 = val_17;//m1                       
        // 0x0272CB20: CBNZ x20, #0x272cb28       | if (val_17 != null) goto label_44;      
        if(val_17 != null)
        {
            goto label_44;
        }
        // 0x0272CB24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_44:
        // 0x0272CB28: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x0272CB2C: LDR x8, [x8, #0x190]       | X8 = (string**)(1152921509929628496)("unknown");
        // 0x0272CB30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_35 = 0;
        // 0x0272CB34: MOV x0, x20                | X0 = val_17;//m1                        
        // 0x0272CB38: LDR x1, [x8]               | X1 = "unknown";                         
        // 0x0272CB3C: BL #0x18a8334              | X0 = val_17.Equals(value:  "unknown");  
        bool val_18 = val_17.Equals(value:  "unknown");
        // 0x0272CB40: AND w8, w0, #1             | W8 = (val_18 & 1);                      
        bool val_19 = val_18;
        // 0x0272CB44: TBNZ w8, #0, #0x272cc78    | if ((val_18 & 1) == true) goto label_45;
        if(val_19 == true)
        {
            goto label_45;
        }
        // 0x0272CB48: CBNZ x27, #0x272cb50       | if ( != 0) goto label_46;               
        if(null != 0)
        {
            goto label_46;
        }
        // 0x0272CB4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_46:
        // 0x0272CB50: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272CB54: LDR x8, [x8, #0x920]       | X8 = (string**)(1152921509644894992)("\\");
        // 0x0272CB58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272CB5C: MOV x0, x27                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272CB60: LDR x1, [x8]               | X1 = "\\";                              
        // 0x0272CB64: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x0272CB68: LDR x8, [x8, #0x458]       | X8 = (string**)(1152921509471652944)("/");
        // 0x0272CB6C: LDR x2, [x8]               | X2 = "/";                               
        // 0x0272CB70: BL #0x18ae7e4              | X0 = Replace(oldValue:  "\\", newValue:  "/");
        string val_20 = Replace(oldValue:  "\\", newValue:  "/");
        // 0x0272CB74: MOV x27, x0                | X27 = val_20;//m1                       
        val_39 = val_20;
        // 0x0272CB78: CBNZ x27, #0x272cb80       | if (val_20 != null) goto label_47;      
        if(val_39 != null)
        {
            goto label_47;
        }
        // 0x0272CB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_47:
        // 0x0272CB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CB84: MOV x0, x27                | X0 = val_20;//m1                        
        // 0x0272CB88: BL #0x18aedb8              | X0 = val_20.ToLower();                  
        string val_21 = val_39.ToLower();
        // 0x0272CB8C: MOV x20, x0                | X20 = val_21;//m1                       
        // 0x0272CB90: CBNZ x20, #0x272cb98       | if (val_21 != null) goto label_48;      
        if(val_21 != null)
        {
            goto label_48;
        }
        // 0x0272CB94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_48:
        // 0x0272CB98: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x0272CB9C: LDR x8, [x8, #0x318]       | X8 = (string**)(1152921509929636784)("/assets/");
        // 0x0272CBA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272CBA4: MOV x0, x20                | X0 = val_21;//m1                        
        // 0x0272CBA8: LDR x1, [x8]               | X1 = "/assets/";                        
        val_40 = "/assets/";
        // 0x0272CBAC: BL #0x18a590c              | X0 = val_21.IndexOf(value:  val_40 = "/assets/");
        int val_22 = val_21.IndexOf(value:  val_40);
        // 0x0272CBB0: MOV w28, w0                | W28 = val_22;//m1                       
        val_41 = val_22;
        // 0x0272CBB4: TBZ w28, #0x1f, #0x272cbf4 | if ((val_22 & 0x80000000) == 0) goto label_49;
        if((val_41 & 2147483648) == 0)
        {
            goto label_49;
        }
        // 0x0272CBB8: CBNZ x27, #0x272cbc0       | if (val_20 != null) goto label_50;      
        if(val_39 != null)
        {
            goto label_50;
        }
        // 0x0272CBBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_50:
        // 0x0272CBC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272CBC4: MOV x0, x27                | X0 = val_20;//m1                        
        // 0x0272CBC8: BL #0x18aedb8              | X0 = val_20.ToLower();                  
        string val_23 = val_39.ToLower();
        // 0x0272CBCC: MOV x20, x0                | X20 = val_23;//m1                       
        // 0x0272CBD0: CBNZ x20, #0x272cbd8       | if (val_23 != null) goto label_51;      
        if(val_23 != null)
        {
            goto label_51;
        }
        // 0x0272CBD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_51:
        // 0x0272CBD8: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x0272CBDC: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921509929640976)("assets/");
        // 0x0272CBE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272CBE4: MOV x0, x20                | X0 = val_23;//m1                        
        // 0x0272CBE8: LDR x1, [x8]               | X1 = "assets/";                         
        val_40 = "assets/";
        // 0x0272CBEC: BL #0x18a590c              | X0 = val_23.IndexOf(value:  val_40 = "assets/");
        int val_24 = val_23.IndexOf(value:  val_40);
        // 0x0272CBF0: MOV w28, w0                | W28 = val_24;//m1                       
        val_41 = val_24;
        label_49:
        // 0x0272CBF4: CMP w28, #1                | STATE = COMPARE(val_24, 0x1)            
        // 0x0272CBF8: B.LT #0x272cc18            | if (val_41 < 1) goto label_52;          
        if(val_41 < 1)
        {
            goto label_52;
        }
        // 0x0272CBFC: CBNZ x27, #0x272cc04       | if (val_20 != null) goto label_53;      
        if(val_39 != null)
        {
            goto label_53;
        }
        // 0x0272CC00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_53:
        // 0x0272CC04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272CC08: MOV x0, x27                | X0 = val_20;//m1                        
        // 0x0272CC0C: MOV w1, w28                | W1 = val_24;//m1                        
        val_40 = val_41;
        // 0x0272CC10: BL #0x18a5a40              | X0 = val_20.Substring(startIndex:  val_40 = val_41);
        string val_25 = val_39.Substring(startIndex:  val_40);
        // 0x0272CC14: MOV x27, x0                | X27 = val_25;//m1                       
        val_39 = val_25;
        label_52:
        // 0x0272CC18: CBNZ x26, #0x272cc20       | if ( != 0) goto label_54;               
        if(null != 0)
        {
            goto label_54;
        }
        // 0x0272CC1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_54:
        // 0x0272CC20: LDR x8, [x26]              | X8 = ;                                  
        // 0x0272CC24: MOV x0, x26                | X0 = 1152921504619520000 (0x1000000000C16000);//ML01
        // 0x0272CC28: LDP x9, x1, [x8, #0x150]   |                                          //  not_find_field!1:336 |  not_find_field!1:344
        // 0x0272CC2C: BLR x9                     | X0 = mem[null + 336]();                 
        // 0x0272CC30: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272CC34: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x0272CC38: STR w0, [sp, #0x2c]        | stack[1152921509929669452] = typeof(System.Diagnostics.StackTrace);  //  dest_result_addr=1152921509929669452
        // 0x0272CC3C: ADD x1, sp, #0x2c          | X1 = (1152921509929669408 + 44) = 1152921509929669452 (0x100000013D43D34C);
        // 0x0272CC40: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x0272CC44: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x0272CC48: BL #0x27bc028              | X0 = 1152921509929779088 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Diagnostics.StackTrace));
        // 0x0272CC4C: MOV x20, x0                | X20 = 1152921509929779088 (0x100000013D457F90);//ML01
        // 0x0272CC50: CBNZ x22, #0x272cc58       | if ( != 0) goto label_55;               
        if(null != 0)
        {
            goto label_55;
        }
        // 0x0272CC54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Diagnostics.StackTrace), ????);
        label_55:
        // 0x0272CC58: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x0272CC5C: LDR x8, [x8, #0xc38]       | X8 = (string**)(1152921509929649264)("(at {0}:{1})");
        // 0x0272CC60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272CC64: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CC68: MOV x2, x27                | X2 = val_25;//m1                        
        val_35 = val_39;
        // 0x0272CC6C: LDR x1, [x8]               | X1 = "(at {0}:{1})";                    
        // 0x0272CC70: MOV x3, x20                | X3 = 1152921509929779088 (0x100000013D457F90);//ML01
        // 0x0272CC74: BL #0x1b5c224              | X0 = AppendFormat(format:  "(at {0}:{1})", arg0:  val_35 = val_39, arg1:  val_8);
        System.Text.StringBuilder val_26 = AppendFormat(format:  "(at {0}:{1})", arg0:  val_35, arg1:  val_8);
        label_45:
        // 0x0272CC78: CBNZ x22, #0x272cc80       | if ( != 0) goto label_56;               
        if(null != 0)
        {
            goto label_56;
        }
        // 0x0272CC7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_56:
        // 0x0272CC80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_36 = 0;
        // 0x0272CC84: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CC88: BL #0x1b5c038              | X0 = AppendLine();                      
        System.Text.StringBuilder val_27 = AppendLine();
        // 0x0272CC8C: ADD w25, w25, #1           | W25 = (0 + 1);                          
        val_33 = 0 + 1;
        // 0x0272CC90: CMP w25, w21               | STATE = COMPARE((0 + 1), typeof(System.Diagnostics.StackTrace))
        // 0x0272CC94: B.NE #0x272c84c            | if (val_33 != val_30) goto label_57;    
        if(val_33 != val_30)
        {
            goto label_57;
        }
        label_15:
        // 0x0272CC98: CBNZ x22, #0x272cca0       | if ( != 0) goto label_58;               
        if(null != 0)
        {
            goto label_58;
        }
        // 0x0272CC9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_58:
        // 0x0272CCA0: LDR x8, [x22]              | X8 = ;                                  
        // 0x0272CCA4: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        val_42 = val_7;
        // 0x0272CCA8: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
        // 0x0272CCAC: BLR x9                     | X0 = mem[null + 320]();                 
        // 0x0272CCB0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x0272CCB4: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x0272CCB8: LDR w19, [sp, #0x18]       | W19 = W3;                               
        val_29 = val_30;
        // 0x0272CCBC: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CCC0: LDR x8, [x8]               | X8 = typeof(BuglyAgent);                
        // 0x0272CCC4: LDRB w9, [x8, #0x10a]      | W9 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272CCC8: TBZ w9, #0, #0x272ccdc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_60;
        // 0x0272CCCC: LDR w9, [x8, #0xbc]        | W9 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272CCD0: CBNZ w9, #0x272ccdc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
        // 0x0272CCD4: MOV x0, x8                 | X0 = 1152921504776761344 (0x100000000A20B000);//ML01
        val_42 = null;
        // 0x0272CCD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_60:
        // 0x0272CCDC: LDP x3, x2, [sp, #8]       | X3 = val_6; X2 = val_2;                  //  | 
        // 0x0272CCE0: AND w1, w19, #1            | W1 = (W3 & 1);                          
        string val_28 = val_29 & 1;
        // 0x0272CCE4: MOV x4, x20                | X4 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0272CCE8: BL #0x2730434              | BuglyAgent._reportException(uncaught:  false, name:  string val_28 = val_29 & 1, reason:  val_2, stackTrace:  val_32);
        BuglyAgent._reportException(uncaught:  false, name:  val_28, reason:  val_2, stackTrace:  val_32);
        label_4:
        // 0x0272CCEC: SUB sp, x29, #0x50         | SP = (1152921509929669536 - 80) = 1152921509929669456 (0x100000013D43D350);
        // 0x0272CCF0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x0272CCF4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x0272CCF8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x0272CCFC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x0272CD00: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x0272CD04: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x0272CD08: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02730434 (41092148), len: 2116  VirtAddr: 0x02730434 RVA: 0x02730434 token: 100663339 methodIndex: 24307 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _reportException(bool uncaught, string name, string reason, string stackTrace)
    {
        //
        // Disasemble & Code
        //  | 
        var val_36;
        //  | 
        string val_37;
        //  | 
        object val_38;
        //  | 
        var val_39;
        //  | 
        var val_40;
        //  | 
        bool val_41;
        //  | 
        var val_42;
        //  | 
        bool val_43;
        // 0x02730434: STP x28, x27, [sp, #-0x60]! | stack[1152921509929958688] = ???;  stack[1152921509929958696] = ???;  //  dest_result_addr=1152921509929958688 |  dest_result_addr=1152921509929958696
        // 0x02730438: STP x26, x25, [sp, #0x10]  | stack[1152921509929958704] = ???;  stack[1152921509929958712] = ???;  //  dest_result_addr=1152921509929958704 |  dest_result_addr=1152921509929958712
        // 0x0273043C: STP x24, x23, [sp, #0x20]  | stack[1152921509929958720] = ???;  stack[1152921509929958728] = ???;  //  dest_result_addr=1152921509929958720 |  dest_result_addr=1152921509929958728
        // 0x02730440: STP x22, x21, [sp, #0x30]  | stack[1152921509929958736] = ???;  stack[1152921509929958744] = ???;  //  dest_result_addr=1152921509929958736 |  dest_result_addr=1152921509929958744
        // 0x02730444: STP x20, x19, [sp, #0x40]  | stack[1152921509929958752] = ???;  stack[1152921509929958760] = ???;  //  dest_result_addr=1152921509929958752 |  dest_result_addr=1152921509929958760
        // 0x02730448: STP x29, x30, [sp, #0x50]  | stack[1152921509929958768] = ???;  stack[1152921509929958776] = ???;  //  dest_result_addr=1152921509929958768 |  dest_result_addr=1152921509929958776
        // 0x0273044C: ADD x29, sp, #0x50         | X29 = (1152921509929958688 + 80) = 1152921509929958768 (0x100000013D483D70);
        // 0x02730450: SUB sp, sp, #0x20          | SP = (1152921509929958688 - 32) = 1152921509929958656 (0x100000013D483D00);
        // 0x02730454: ADRP x23, #0x3743000       | X23 = 57946112 (0x3743000);             
        // 0x02730458: LDRB w8, [x23, #0xac1]     | W8 = (bool)static_value_03743AC1;       
        // 0x0273045C: MOV x21, x4                | X21 = X4;//m1                           
        val_36 = X4;
        // 0x02730460: MOV x19, x3                | X19 = stackTrace;//m1                   
        // 0x02730464: MOV x20, x2                | X20 = reason;//m1                       
        // 0x02730468: MOV w22, w1                | W22 = name;//m1                         
        // 0x0273046C: TBNZ w8, #0, #0x2730488    | if (static_value_03743AC1 == true) goto label_0;
        // 0x02730470: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x02730474: LDR x8, [x8, #0x458]       | X8 = 0x2B8FDF0;                         
        // 0x02730478: LDR w0, [x8]               | W0 = 0x1640;                            
        // 0x0273047C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1640, ????);     
        // 0x02730480: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02730484: STRB w8, [x23, #0xac1]     | static_value_03743AC1 = true;            //  dest_result_addr=57948865
        label_0:
        // 0x02730488: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
        // 0x0273048C: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
        // 0x02730490: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x02730494: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02730498: TBZ w8, #0, #0x27304a8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0273049C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x027304A0: CBNZ w8, #0x27304a8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x027304A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_2:
        // 0x027304A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027304AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027304B0: MOV x1, x20                | X1 = reason;//m1                        
        // 0x027304B4: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_1 = System.String.IsNullOrEmpty(value:  0);
        // 0x027304B8: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x027304BC: TBZ w8, #0, #0x27304e0     | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x027304C0: SUB sp, x29, #0x50         | SP = (1152921509929958768 - 80) = 1152921509929958688 (0x100000013D483D20);
        // 0x027304C4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x027304C8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x027304CC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x027304D0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x027304D4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x027304D8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x027304DC: RET                        |  return;                                
        return;
        label_3:
        // 0x027304E0: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x027304E4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x027304E8: TBZ w8, #0, #0x27304f8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x027304EC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x027304F0: CBNZ w8, #0x27304f8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x027304F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_5:
        // 0x027304F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027304FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730500: MOV x1, x21                | X1 = X4;//m1                            
        // 0x02730504: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_3 = System.String.IsNullOrEmpty(value:  0);
        // 0x02730508: TBZ w0, #0, #0x273053c     | if (val_3 == false) goto label_6;       
        if(val_3 == false)
        {
            goto label_6;
        }
        // 0x0273050C: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x02730510: LDR x8, [x8, #0x910]       | X8 = 1152921504706793472;               
        // 0x02730514: LDR x0, [x8]               | X0 = typeof(UnityEngine.StackTraceUtility);
        // 0x02730518: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.StackTraceUtility.__il2cppRuntimeField_10A;
        // 0x0273051C: TBZ w8, #0, #0x273052c     | if (UnityEngine.StackTraceUtility.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x02730520: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.StackTraceUtility.__il2cppRuntimeField_cctor_finished;
        // 0x02730524: CBNZ w8, #0x273052c        | if (UnityEngine.StackTraceUtility.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02730528: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.StackTraceUtility), ????);
        label_8:
        // 0x0273052C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02730530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730534: BL #0x268bb34              | X0 = UnityEngine.StackTraceUtility.ExtractStackTrace();
        string val_4 = UnityEngine.StackTraceUtility.ExtractStackTrace();
        // 0x02730538: MOV x21, x0                | X21 = val_4;//m1                        
        val_36 = val_4;
        label_6:
        // 0x0273053C: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x02730540: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02730544: TBZ w8, #0, #0x2730554     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x02730548: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0273054C: CBNZ w8, #0x2730554        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x02730550: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x02730554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02730558: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0273055C: MOV x1, x21                | X1 = val_4;//m1                         
        // 0x02730560: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_5 = System.String.IsNullOrEmpty(value:  0);
        // 0x02730564: TBZ w0, #0, #0x2730578     | if (val_5 == false) goto label_11;      
        if(val_5 == false)
        {
            goto label_11;
        }
        // 0x02730568: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x0273056C: LDR x8, [x8, #0x5a0]       | X8 = (string**)(1152921509929863760)("Empty");
        // 0x02730570: LDR x21, [x8]              | X21 = "Empty";                          
        val_36 = "Empty";
        // 0x02730574: B #0x2730a20               |  goto label_52;                         
        goto label_52;
        label_11:
        // 0x02730578: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x0273057C: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
        // 0x02730580: LDR x23, [x8]              | X23 = typeof(System.Char[]);            
        // 0x02730584: MOV x0, x23                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x02730588: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x0273058C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02730590: MOV x0, x23                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x02730594: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x02730598: MOV x23, x0                | X23 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x0273059C: CBNZ x23, #0x27305a4       | if ( != null) goto label_13;            
        if(null != null)
        {
            goto label_13;
        }
        // 0x027305A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_13:
        // 0x027305A4: LDR w8, [x23, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x027305A8: CBNZ w8, #0x27305b8        | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_14;
        // 0x027305AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x027305B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027305B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_14:
        // 0x027305B8: MOVZ w8, #0xa              | W8 = 10 (0xA);//ML01                    
        // 0x027305BC: STRH w8, [x23, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0xA;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 10;
        // 0x027305C0: CBNZ x21, #0x27305c8       | if (val_4 != null) goto label_15;       
        if(val_36 != null)
        {
            goto label_15;
        }
        // 0x027305C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_15:
        // 0x027305C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027305CC: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x027305D0: MOV x1, x23                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x027305D4: BL #0x18a881c              | X0 = val_4.Split(separator:  null);     
        System.String[] val_6 = val_36.Split(separator:  null);
        // 0x027305D8: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x027305DC: CBZ x23, #0x2730a20        | if (val_6 == null) goto label_52;       
        if(val_6 == null)
        {
            goto label_52;
        }
        // 0x027305E0: LDR w8, [x23, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x027305E4: CMP w8, #1                 | STATE = COMPARE(val_6.Length, 0x1)      
        // 0x027305E8: B.LT #0x2730a20            | if (val_6.Length < 1) goto label_52;    
        if(val_6.Length < 1)
        {
            goto label_52;
        }
        // 0x027305EC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x027305F0: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x027305F4: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        // 0x027305F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x027305FC: MOV x24, x0                | X24 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x02730600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_37 = 0;
        // 0x02730604: MOV x0, x24                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        System.Text.StringBuilder val_7 = null;
        // 0x02730608: BL #0x1b5a30c              | .ctor();                                
        val_7 = new System.Text.StringBuilder();
        // 0x0273060C: STR x24, [sp, #0x10]       | stack[1152921509929958672] = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921509929958672
        // 0x02730610: LDR x8, [x23, #0x18]       | X8 = val_6.Length; //P2                 
        // 0x02730614: CMP w8, #1                 | STATE = COMPARE(val_6.Length, 0x1)      
        // 0x02730618: B.LT #0x2730918            | if (val_6.Length < 1) goto label_18;    
        if(val_6.Length < 1)
        {
            goto label_18;
        }
        // 0x0273061C: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
        var val_36 = 0;
        // 0x02730620: SXTW x8, w8                | X8 = (long)(int)(val_6.Length);         
        // 0x02730624: ADD x24, x23, #0x20        | X24 = val_6[0x20]; //PARR1              
        // 0x02730628: STR x8, [sp, #0x18]        | stack[1152921509929958680] = (long)(int)(val_6.Length);  //  dest_result_addr=1152921509929958680
        label_50:
        // 0x0273062C: LDR w8, [x23, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x02730630: CMP x27, x8                | STATE = COMPARE(0x0, val_6.Length)      
        // 0x02730634: B.LO #0x2730644            | if (0 < val_6.Length) goto label_19;    
        if(val_36 < val_6.Length)
        {
            goto label_19;
        }
        // 0x02730638: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
        // 0x0273063C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730640: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
        label_19:
        // 0x02730644: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x02730648: LDR x25, [x24, x27, lsl #3] | X25 = typeof(System.String[]);          
        // 0x0273064C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02730650: TBZ w8, #0, #0x2730660     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x02730654: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x02730658: CBNZ w8, #0x2730660        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x0273065C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_21:
        // 0x02730660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02730664: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730668: MOV x1, x25                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        val_37 = 1152921504948897168;
        // 0x0273066C: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_8 = System.String.IsNullOrEmpty(value:  0);
        // 0x02730670: AND w8, w0, #1             | W8 = (val_8 & 1);                       
        bool val_9 = val_8;
        // 0x02730674: TBNZ w8, #0, #0x2730908    | if ((val_8 & 1) == true) goto label_35; 
        if(val_9 == true)
        {
            goto label_35;
        }
        // 0x02730678: CBNZ x25, #0x2730680       | if (typeof(System.String[]) != null) goto label_23;
        if(null != null)
        {
            goto label_23;
        }
        // 0x0273067C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_23:
        // 0x02730680: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730684: MOV x0, x25                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x02730688: BL #0x18a946c              | X0 = 1152921504948897168.Trim();        
        string val_10 = 1152921504948897168.Trim();
        // 0x0273068C: MOV x26, x0                | X26 = val_10;//m1                       
        // 0x02730690: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x02730694: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02730698: TBZ w8, #0, #0x27306a8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x0273069C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x027306A0: CBNZ w8, #0x27306a8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x027306A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_25:
        // 0x027306A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027306AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027306B0: MOV x1, x26                | X1 = val_10;//m1                        
        val_37 = val_10;
        // 0x027306B4: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_11 = System.String.IsNullOrEmpty(value:  0);
        // 0x027306B8: AND w8, w0, #1             | W8 = (val_11 & 1);                      
        bool val_12 = val_11;
        // 0x027306BC: TBNZ w8, #0, #0x2730908    | if ((val_11 & 1) == true) goto label_35;
        if(val_12 == true)
        {
            goto label_35;
        }
        // 0x027306C0: CBNZ x25, #0x27306c8       | if (typeof(System.String[]) != null) goto label_27;
        if(null != null)
        {
            goto label_27;
        }
        // 0x027306C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_27:
        // 0x027306C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027306CC: MOV x0, x25                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x027306D0: BL #0x18a946c              | X0 = 1152921504948897168.Trim();        
        string val_13 = 1152921504948897168.Trim();
        // 0x027306D4: MOV x25, x0                | X25 = val_13;//m1                       
        val_38 = val_13;
        // 0x027306D8: CBNZ x25, #0x27306e0       | if (val_13 != null) goto label_28;      
        if(val_38 != null)
        {
            goto label_28;
        }
        // 0x027306DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_28:
        // 0x027306E0: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x027306E4: LDR x8, [x8, #0xd0]        | X8 = (string**)(1152921509929908896)("System.Collections.Generic.");
        // 0x027306E8: LDR x1, [x8]               | X1 = "System.Collections.Generic.";     
        val_37 = "System.Collections.Generic.";
        // 0x027306EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027306F0: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x027306F4: BL #0x18add38              | X0 = val_13.StartsWith(value:  val_37 = "System.Collections.Generic.");
        bool val_14 = val_38.StartsWith(value:  val_37);
        // 0x027306F8: AND w8, w0, #1             | W8 = (val_14 & 1);                      
        bool val_15 = val_14;
        // 0x027306FC: TBNZ w8, #0, #0x2730908    | if ((val_14 & 1) == true) goto label_35;
        if(val_15 == true)
        {
            goto label_35;
        }
        // 0x02730700: CBNZ x25, #0x2730708       | if (val_13 != null) goto label_30;      
        if(val_38 != null)
        {
            goto label_30;
        }
        // 0x02730704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_30:
        // 0x02730708: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x0273070C: LDR x8, [x8, #0x5c0]       | X8 = (string**)(1152921509929909024)("ShimEnumerator");
        // 0x02730710: LDR x1, [x8]               | X1 = "ShimEnumerator";                  
        val_37 = "ShimEnumerator";
        // 0x02730714: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730718: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x0273071C: BL #0x18add38              | X0 = val_13.StartsWith(value:  val_37 = "ShimEnumerator");
        bool val_16 = val_38.StartsWith(value:  val_37);
        // 0x02730720: AND w8, w0, #1             | W8 = (val_16 & 1);                      
        bool val_17 = val_16;
        // 0x02730724: TBNZ w8, #0, #0x2730908    | if ((val_16 & 1) == true) goto label_35;
        if(val_17 == true)
        {
            goto label_35;
        }
        // 0x02730728: CBNZ x25, #0x2730730       | if (val_13 != null) goto label_32;      
        if(val_38 != null)
        {
            goto label_32;
        }
        // 0x0273072C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_32:
        // 0x02730730: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x02730734: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921509929909120)("Bugly");
        // 0x02730738: LDR x1, [x8]               | X1 = "Bugly";                           
        val_37 = "Bugly";
        // 0x0273073C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730740: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x02730744: BL #0x18add38              | X0 = val_13.StartsWith(value:  val_37 = "Bugly");
        bool val_18 = val_38.StartsWith(value:  val_37);
        // 0x02730748: AND w8, w0, #1             | W8 = (val_18 & 1);                      
        bool val_19 = val_18;
        // 0x0273074C: TBNZ w8, #0, #0x2730908    | if ((val_18 & 1) == true) goto label_35;
        if(val_19 == true)
        {
            goto label_35;
        }
        // 0x02730750: CBNZ x25, #0x2730758       | if (val_13 != null) goto label_34;      
        if(val_38 != null)
        {
            goto label_34;
        }
        // 0x02730754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_34:
        // 0x02730758: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x0273075C: LDR x8, [x8, #0x470]       | X8 = (string**)(1152921509929909200)("..ctor");
        // 0x02730760: LDR x1, [x8]               | X1 = "..ctor";                          
        val_37 = "..ctor";
        // 0x02730764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730768: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x0273076C: BL #0x18ad42c              | X0 = val_13.Contains(value:  val_37 = "..ctor");
        bool val_20 = val_38.Contains(value:  val_37);
        // 0x02730770: AND w8, w0, #1             | W8 = (val_20 & 1);                      
        bool val_21 = val_20;
        // 0x02730774: TBNZ w8, #0, #0x2730908    | if ((val_20 & 1) == true) goto label_35;
        if(val_21 == true)
        {
            goto label_35;
        }
        // 0x02730778: CBNZ x25, #0x2730780       | if (val_13 != null) goto label_36;      
        if(val_38 != null)
        {
            goto label_36;
        }
        // 0x0273077C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_36:
        // 0x02730780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730784: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x02730788: BL #0x18aedb8              | X0 = val_13.ToLower();                  
        string val_22 = val_38.ToLower();
        // 0x0273078C: MOV x26, x0                | X26 = val_22;//m1                       
        // 0x02730790: CBNZ x26, #0x2730798       | if (val_22 != null) goto label_37;      
        if(val_22 != null)
        {
            goto label_37;
        }
        // 0x02730794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_37:
        // 0x02730798: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x0273079C: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921509929913376)("(at");
        // 0x027307A0: LDR x1, [x8]               | X1 = "(at";                             
        // 0x027307A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027307A8: MOV x0, x26                | X0 = val_22;//m1                        
        // 0x027307AC: BL #0x18a590c              | X0 = val_22.IndexOf(value:  "(at");     
        int val_23 = val_22.IndexOf(value:  "(at");
        // 0x027307B0: STR w0, [sp, #0xc]         | stack[1152921509929958668] = val_23;     //  dest_result_addr=1152921509929958668
        // 0x027307B4: CBNZ x25, #0x27307bc       | if (val_13 != null) goto label_38;      
        if(val_38 != null)
        {
            goto label_38;
        }
        // 0x027307B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_38:
        // 0x027307BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027307C0: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x027307C4: BL #0x18aedb8              | X0 = val_13.ToLower();                  
        string val_24 = val_38.ToLower();
        // 0x027307C8: MOV x26, x0                | X26 = val_24;//m1                       
        // 0x027307CC: CBNZ x26, #0x27307d4       | if (val_24 != null) goto label_39;      
        if(val_24 != null)
        {
            goto label_39;
        }
        // 0x027307D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_39:
        // 0x027307D4: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x027307D8: LDR x8, [x8, #0x318]       | X8 = (string**)(1152921509929636784)("/assets/");
        // 0x027307DC: LDR x1, [x8]               | X1 = "/assets/";                        
        // 0x027307E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027307E4: MOV x0, x26                | X0 = val_24;//m1                        
        // 0x027307E8: BL #0x18a590c              | X0 = val_24.IndexOf(value:  "/assets/");
        int val_25 = val_24.IndexOf(value:  "/assets/");
        // 0x027307EC: STR w0, [sp, #8]           | stack[1152921509929958664] = val_25;     //  dest_result_addr=1152921509929958664
        // 0x027307F0: LDR w8, [sp, #0xc]         | W8 = val_23;                            
        // 0x027307F4: CMP w8, #1                 | STATE = COMPARE(val_23, 0x1)            
        // 0x027307F8: B.LT #0x27308a4            | if (val_23 < 1) goto label_41;          
        if(val_23 < 1)
        {
            goto label_41;
        }
        // 0x027307FC: LDR w8, [sp, #8]           | W8 = val_25;                            
        // 0x02730800: CMP w8, #1                 | STATE = COMPARE(val_25, 0x1)            
        // 0x02730804: B.LT #0x27308a4            | if (val_25 < 1) goto label_41;          
        if(val_25 < 1)
        {
            goto label_41;
        }
        // 0x02730808: CBNZ x25, #0x2730810       | if (val_13 != null) goto label_42;      
        if(val_38 != null)
        {
            goto label_42;
        }
        // 0x0273080C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_42:
        // 0x02730810: LDR w2, [sp, #0xc]         | W2 = val_23;                            
        // 0x02730814: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02730818: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0273081C: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x02730820: BL #0x18a920c              | X0 = val_13.Substring(startIndex:  0, length:  val_23);
        string val_26 = val_38.Substring(startIndex:  0, length:  val_23);
        // 0x02730824: MOV x26, x0                | X26 = val_26;//m1                       
        // 0x02730828: CBNZ x26, #0x2730830       | if (val_26 != null) goto label_43;      
        if(val_26 != null)
        {
            goto label_43;
        }
        // 0x0273082C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_43:
        // 0x02730830: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x02730834: LDR x8, [x8, #0xc30]       | X8 = (string**)(1152921509929921648)(":");
        // 0x02730838: LDR x1, [x8]               | X1 = ":";                               
        // 0x0273083C: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x02730840: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
        // 0x02730844: LDR x2, [x8]               | X2 = ".";                               
        // 0x02730848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0273084C: MOV x0, x26                | X0 = val_26;//m1                        
        // 0x02730850: BL #0x18ae7e4              | X0 = val_26.Replace(oldValue:  ":", newValue:  ".");
        string val_27 = val_26.Replace(oldValue:  ":", newValue:  ".");
        // 0x02730854: MOV x26, x0                | X26 = val_27;//m1                       
        // 0x02730858: CBNZ x25, #0x2730860       | if (val_13 != null) goto label_44;      
        if(val_38 != null)
        {
            goto label_44;
        }
        // 0x0273085C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_44:
        // 0x02730860: LDR w1, [sp, #8]           | W1 = val_25;                            
        // 0x02730864: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730868: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x0273086C: BL #0x18a5a40              | X0 = val_13.Substring(startIndex:  val_25);
        string val_28 = val_38.Substring(startIndex:  val_25);
        // 0x02730870: MOV x25, x0                | X25 = val_28;//m1                       
        val_38 = val_28;
        // 0x02730874: LDR x8, [sp, #0x10]        | X8 = typeof(System.Text.StringBuilder); 
        // 0x02730878: CBNZ x8, #0x2730880        | if ( != 0) goto label_45;               
        if(null != 0)
        {
            goto label_45;
        }
        // 0x0273087C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_45:
        // 0x02730880: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x02730884: LDR x8, [x8, #0x820]       | X8 = (string**)(1152921509929929920)("{0}(at {1}");
        // 0x02730888: LDR x1, [x8]               | X1 = "{0}(at {1}";                      
        // 0x0273088C: LDR x0, [sp, #0x10]        | X0 = typeof(System.Text.StringBuilder); 
        // 0x02730890: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02730894: MOV x2, x26                | X2 = val_27;//m1                        
        // 0x02730898: MOV x3, x25                | X3 = val_28;//m1                        
        // 0x0273089C: BL #0x1b5c224              | X0 = AppendFormat(format:  "{0}(at {1}", arg0:  val_27, arg1:  val_38);
        System.Text.StringBuilder val_29 = AppendFormat(format:  "{0}(at {1}", arg0:  val_27, arg1:  val_38);
        // 0x027308A0: B #0x27308f0               |  goto label_46;                         
        goto label_46;
        label_41:
        // 0x027308A4: CBNZ x25, #0x27308ac       | if (val_13 != null) goto label_47;      
        if(val_38 != null)
        {
            goto label_47;
        }
        // 0x027308A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_47:
        // 0x027308AC: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x027308B0: LDR x8, [x8, #0xc30]       | X8 = (string**)(1152921509929921648)(":");
        // 0x027308B4: LDR x1, [x8]               | X1 = ":";                               
        // 0x027308B8: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x027308BC: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
        // 0x027308C0: LDR x2, [x8]               | X2 = ".";                               
        // 0x027308C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x027308C8: MOV x0, x25                | X0 = val_13;//m1                        
        // 0x027308CC: BL #0x18ae7e4              | X0 = val_13.Replace(oldValue:  ":", newValue:  ".");
        string val_30 = val_38.Replace(oldValue:  ":", newValue:  ".");
        // 0x027308D0: MOV x25, x0                | X25 = val_30;//m1                       
        val_38 = val_30;
        // 0x027308D4: LDR x8, [sp, #0x10]        | X8 = typeof(System.Text.StringBuilder); 
        // 0x027308D8: CBNZ x8, #0x27308e0        | if ( != 0) goto label_48;               
        if(null != 0)
        {
            goto label_48;
        }
        // 0x027308DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_48:
        // 0x027308E0: LDR x0, [sp, #0x10]        | X0 = typeof(System.Text.StringBuilder); 
        // 0x027308E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x027308E8: MOV x1, x25                | X1 = val_30;//m1                        
        // 0x027308EC: BL #0x1b5b818              | X0 = Append(value:  val_38);            
        System.Text.StringBuilder val_31 = Append(value:  val_38);
        label_46:
        // 0x027308F0: LDR x8, [sp, #0x10]        | X8 = typeof(System.Text.StringBuilder); 
        // 0x027308F4: CBNZ x8, #0x27308fc        | if ( != 0) goto label_49;               
        if(null != 0)
        {
            goto label_49;
        }
        // 0x027308F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_49:
        // 0x027308FC: LDR x0, [sp, #0x10]        | X0 = typeof(System.Text.StringBuilder); 
        // 0x02730900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_37 = 0;
        // 0x02730904: BL #0x1b5c038              | X0 = AppendLine();                      
        System.Text.StringBuilder val_32 = AppendLine();
        label_35:
        // 0x02730908: LDR x8, [sp, #0x18]        | X8 = (long)(int)(val_6.Length);         
        // 0x0273090C: ADD x27, x27, #1           | X27 = (0 + 1);                          
        val_36 = val_36 + 1;
        // 0x02730910: CMP x27, x8                | STATE = COMPARE((0 + 1), (long)(int)(val_6.Length))
        // 0x02730914: B.LT #0x273062c            | if (0 < (long)val_6.Length) goto label_50;
        if(val_36 < (long)val_6.Length)
        {
            goto label_50;
        }
        label_18:
        // 0x02730918: LDR x23, [sp, #0x10]       | X23 = typeof(System.Text.StringBuilder);
        // 0x0273091C: CBNZ x23, #0x2730924       | if ( != 0) goto label_51;               
        if(null != 0)
        {
            goto label_51;
        }
        // 0x02730920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_51:
        // 0x02730924: LDR x8, [x23]              | X8 = ;                                  
        // 0x02730928: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
        // 0x0273092C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x02730930: BLR x9                     | X0 = mem[null + 320]();                 
        // 0x02730934: MOV x21, x0                | X21 = 1152921504649605120 (0x10000000028C7000);//ML01
        val_36 = null;
        // 0x02730938: B #0x2730a20               |  goto label_52;                         
        goto label_52;
        label_89:
        // 0x0273093C: MOV x23, x0                | X23 = 1152921504649605120 (0x10000000028C7000);//ML01
        val_39 = null;
        // 0x02730940: CMP w1, #1                 | STATE = COMPARE(mem[null + 320 + 8], 0x1)
        // 0x02730944: B.NE #0x2730c6c            | if (mem[null + 320 + 8] != 0x1) goto label_53;
        if((mem[null + 320 + 8]) != 1)
        {
            goto label_53;
        }
        // 0x02730948: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x0273094C: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Text.StringBuilder), ????);
        // 0x02730950: MOV x23, x0                | X23 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x02730954: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x02730958: LDR x8, [x23]              | X8 = ;                                  
        // 0x0273095C: LDR x9, [x9, #0xf90]       | X9 = 1152921504606900224;               
        // 0x02730960: LDR x1, [x8]               |  //  not_find_field!1:0
        // 0x02730964: LDR x0, [x9]               | X0 = typeof(System.Object);             
        // 0x02730968: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Object), ????);
        // 0x0273096C: TBZ w0, #0, #0x2730c44     | if ((typeof(System.Object) & 0x1) == 0) goto label_54;
        if((null & 1) == 0)
        {
            goto label_54;
        }
        // 0x02730970: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Object), ????);
        // 0x02730974: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x02730978: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0273097C: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x02730980: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730984: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x02730988: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0273098C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730990: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x02730994: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730998: CBNZ x23, #0x27309a0       | if ( != null) goto label_55;            
        if(null != null)
        {
            goto label_55;
        }
        // 0x0273099C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_55:
        // 0x027309A0: ADRP x24, #0x3612000       | X24 = 56696832 (0x3612000);             
        // 0x027309A4: LDR x24, [x24, #0xf48]     | X24 = (string**)(1152921509929946400)("Error to parse the stack trace");
        // 0x027309A8: LDR x0, [x24]              | X0 = "Error to parse the stack trace";  
        // 0x027309AC: CBZ x0, #0x27309cc         | if ("Error to parse the stack trace" == null) goto label_57;
        // 0x027309B0: LDR x8, [x23]              | X8 = ;                                  
        // 0x027309B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x027309B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Error to parse the stack trace", ????);
        // 0x027309BC: CBNZ x0, #0x27309cc        | if ("Error to parse the stack trace" != null) goto label_57;
        if("Error to parse the stack trace" != null)
        {
            goto label_57;
        }
        // 0x027309C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Error to parse the stack trace", ????);
        // 0x027309C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027309C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Error to parse the stack trace", ????);
        label_57:
        // 0x027309CC: LDR x24, [x24]             | X24 = "Error to parse the stack trace"; 
        // 0x027309D0: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x027309D4: CBNZ w8, #0x27309e4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_58;
        // 0x027309D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Error to parse the stack trace", ????);
        // 0x027309DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027309E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Error to parse the stack trace", ????);
        label_58:
        // 0x027309E4: STR x24, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "Error to parse the stack trace";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "Error to parse the stack trace";
        // 0x027309E8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x027309EC: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x027309F0: LDR x0, [x8]               | X0 = typeof(BuglyAgent);                
        // 0x027309F4: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x027309F8: TBZ w8, #0, #0x2730a08     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_60;
        // 0x027309FC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730A00: CBNZ w8, #0x2730a08        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
        // 0x02730A04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_60:
        // 0x02730A08: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x02730A0C: LDR x8, [x8, #0x6b8]       | X8 = (string**)(1152921509929946528)("{0}");
        // 0x02730A10: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x02730A14: MOV x3, x23                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730A18: LDR x2, [x8]               | X2 = "{0}";                             
        // 0x02730A1C: BL #0x272ec9c              | BuglyAgent.PrintLog(level:  null, format:  3, args:  "{0}");
        BuglyAgent.PrintLog(level:  null, format:  3, args:  "{0}");
        label_52:
        // 0x02730A20: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x02730A24: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x02730A28: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x02730A2C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730A30: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x02730A34: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x02730A38: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730A3C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x02730A40: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730A44: CBNZ x23, #0x2730a4c       | if ( != null) goto label_61;            
        if(null != null)
        {
            goto label_61;
        }
        // 0x02730A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_61:
        // 0x02730A4C: CBZ x20, #0x2730a70        | if (reason == null) goto label_63;      
        if(reason == null)
        {
            goto label_63;
        }
        // 0x02730A50: LDR x8, [x23]              | X8 = ;                                  
        // 0x02730A54: MOV x0, x20                | X0 = reason;//m1                        
        // 0x02730A58: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x02730A5C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? reason, ????);     
        // 0x02730A60: CBNZ x0, #0x2730a70        | if (reason != null) goto label_63;      
        if(reason != null)
        {
            goto label_63;
        }
        // 0x02730A64: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? reason, ????);     
        // 0x02730A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730A6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? reason, ????);     
        label_63:
        // 0x02730A70: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x02730A74: CBNZ w8, #0x2730a84        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_64;
        // 0x02730A78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? reason, ????);     
        // 0x02730A7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730A80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? reason, ????);     
        label_64:
        // 0x02730A84: STR x20, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = reason;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = reason;
        // 0x02730A88: CBZ x19, #0x2730aac        | if (stackTrace == null) goto label_66;  
        if(stackTrace == null)
        {
            goto label_66;
        }
        // 0x02730A8C: LDR x8, [x23]              | X8 = ;                                  
        // 0x02730A90: MOV x0, x19                | X0 = stackTrace;//m1                    
        // 0x02730A94: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x02730A98: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? stackTrace, ????); 
        // 0x02730A9C: CBNZ x0, #0x2730aac        | if (stackTrace != null) goto label_66;  
        if(stackTrace != null)
        {
            goto label_66;
        }
        // 0x02730AA0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? stackTrace, ????); 
        // 0x02730AA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730AA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? stackTrace, ????); 
        label_66:
        // 0x02730AAC: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x02730AB0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x02730AB4: B.HI #0x2730ac4            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_67;
        // 0x02730AB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? stackTrace, ????); 
        // 0x02730ABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730AC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? stackTrace, ????); 
        label_67:
        // 0x02730AC4: STR x19, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = stackTrace;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = stackTrace;
        // 0x02730AC8: CBZ x21, #0x2730aec        | if ( == 0) goto label_69;               
        if(null == 0)
        {
            goto label_69;
        }
        // 0x02730ACC: LDR x8, [x23]              | X8 = ;                                  
        // 0x02730AD0: MOV x0, x21                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x02730AD4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x02730AD8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Text.StringBuilder), ????);
        // 0x02730ADC: CBNZ x0, #0x2730aec        | if ( != 0) goto label_69;               
        if(null != 0)
        {
            goto label_69;
        }
        // 0x02730AE0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(System.Text.StringBuilder), ????);
        // 0x02730AE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730AE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Text.StringBuilder), ????);
        label_69:
        // 0x02730AEC: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x02730AF0: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x02730AF4: B.HI #0x2730b04            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_70;
        // 0x02730AF8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Text.StringBuilder), ????);
        // 0x02730AFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02730B00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Text.StringBuilder), ????);
        label_70:
        // 0x02730B04: STR x21, [x23, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_36;
        // 0x02730B08: ADRP x24, #0x3652000       | X24 = 56958976 (0x3652000);             
        // 0x02730B0C: LDR x24, [x24, #0x938]     | X24 = 1152921504776761344;              
        // 0x02730B10: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        // 0x02730B14: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730B18: TBZ w8, #0, #0x2730b28     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_72;
        // 0x02730B1C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730B20: CBNZ w8, #0x2730b28        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
        // 0x02730B24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_72:
        // 0x02730B28: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x02730B2C: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921509929946608)("ReportException: {0} {1}\n*********\n{2}\n*********");
        // 0x02730B30: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x02730B34: MOV x3, x23                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x02730B38: LDR x2, [x8]               | X2 = "ReportException: {0} {1}\n*********\n{2}\n*********";
        // 0x02730B3C: BL #0x272ec9c              | BuglyAgent.PrintLog(level:  null, format:  5, args:  "ReportException: {0} {1}\n*********\n{2}\n*********");
        BuglyAgent.PrintLog(level:  null, format:  5, args:  "ReportException: {0} {1}\n*********\n{2}\n*********");
        // 0x02730B40: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        val_40 = null;
        // 0x02730B44: TBZ w22, #0, #0x2730b6c    | if ((name & 0x1) == 0) goto label_73;   
        if((name & 1) == 0)
        {
            goto label_73;
        }
        // 0x02730B48: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730B4C: TBZ w8, #0, #0x2730b60     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_75;
        // 0x02730B50: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730B54: CBNZ w8, #0x2730b60        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_75;
        // 0x02730B58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x02730B5C: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        val_40 = null;
        label_75:
        // 0x02730B60: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730B64: LDRB w23, [x8, #0x69]      | W23 = BuglyAgent._autoQuitApplicationAfterReport;
        val_41 = BuglyAgent._autoQuitApplicationAfterReport;
        // 0x02730B68: B #0x2730b70               |  goto label_76;                         
        goto label_76;
        label_73:
        // 0x02730B6C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_41 = false;
        label_76:
        // 0x02730B70: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730B74: TBZ w8, #0, #0x2730b88     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_78;
        // 0x02730B78: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730B7C: CBNZ w8, #0x2730b88        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_78;
        // 0x02730B80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x02730B84: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        val_40 = null;
        label_78:
        // 0x02730B88: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730B8C: STRB w23, [x8, #0x88]      | BuglyAgent._uncaughtAutoReportOnce = false;  //  dest_result_addr=1152921504776765576
        BuglyAgent._uncaughtAutoReportOnce = val_41;
        // 0x02730B90: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        // 0x02730B94: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504776761609 (0x100000000A20B109);
        // 0x02730B98: LDRH w8, [x8]              | W8 = BuglyAgent.__il2cppRuntimeField_109;
        // 0x02730B9C: AND w8, w8, #0x100         | W8 = (BuglyAgent.__il2cppRuntimeField_109 & 256);
        // 0x02730BA0: AND w8, w8, #0xffff        | W8 = ((BuglyAgent.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x02730BA4: TBZ w22, #0, #0x2730be0    | if ((name & 0x1) == 0) goto label_79;   
        if((name & 1) == 0)
        {
            goto label_79;
        }
        // 0x02730BA8: CBZ w8, #0x2730bb8         | if (((BuglyAgent.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_81;
        // 0x02730BAC: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730BB0: CBNZ w8, #0x2730bb8        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_81;
        // 0x02730BB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_81:
        // 0x02730BB8: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        val_42 = null;
        // 0x02730BBC: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730BC0: TBZ w8, #0, #0x2730bd4     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_83;
        // 0x02730BC4: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730BC8: CBNZ w8, #0x2730bd4        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
        // 0x02730BCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x02730BD0: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        val_42 = null;
        label_83:
        // 0x02730BD4: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730BD8: LDRB w22, [x8, #0x69]      | W22 = BuglyAgent._autoQuitApplicationAfterReport;
        val_43 = BuglyAgent._autoQuitApplicationAfterReport;
        // 0x02730BDC: B #0x2730bf8               |  goto label_84;                         
        goto label_84;
        label_79:
        // 0x02730BE0: CBZ w8, #0x2730bf0         | if (((BuglyAgent.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_86;
        // 0x02730BE4: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730BE8: CBNZ w8, #0x2730bf0        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
        // 0x02730BEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_86:
        // 0x02730BF0: LDR x0, [x24]              | X0 = typeof(BuglyAgent);                
        val_42 = null;
        // 0x02730BF4: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_43 = 0;
        label_84:
        // 0x02730BF8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x02730BFC: TBZ w8, #0, #0x2730c0c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_88;
        // 0x02730C00: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x02730C04: CBNZ w8, #0x2730c0c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_88;
        // 0x02730C08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_88:
        // 0x02730C0C: CMP w22, #0                | STATE = COMPARE(0x0, 0x0)               
        // 0x02730C10: CSET w5, ne                | W5 = val_43 != 0x0 ? 1 : 0;             
        var val_35 = (val_43 != 0) ? 1 : 0;
        // 0x02730C14: MOV x2, x20                | X2 = reason;//m1                        
        // 0x02730C18: MOV x3, x19                | X3 = stackTrace;//m1                    
        // 0x02730C1C: MOV x4, x21                | X4 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x02730C20: SUB sp, x29, #0x50         | SP = (1152921509929958768 - 80) = 1152921509929958688 (0x100000013D483D20);
        // 0x02730C24: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x02730C28: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02730C2C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02730C30: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x02730C34: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x02730C38: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x02730C3C: B #0x272f408               | BuglyAgent.ReportException(type:  169914368, name:  5, reason:  reason, stackTrace:  stackTrace, quitProgram:  false); return;
        BuglyAgent.ReportException(type:  169914368, name:  5, reason:  reason, stackTrace:  stackTrace, quitProgram:  false);
        return;
        // 0x02730C40: B #0x273093c               |  goto label_89;                         
        goto label_89;
        label_54:
        // 0x02730C44: ORR w0, wzr, #8            | W0 = 8(0x8);                            
        // 0x02730C48: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
        // 0x02730C4C: LDR x8, [x23]              | X8 = ;                                  
        // 0x02730C50: STR x8, [x0]               | mem[8] = ;                               //  dest_result_addr=8
        mem[8] = null;
        // 0x02730C54: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
        // 0x02730C58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02730C5C: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
        // 0x02730C60: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
        // 0x02730C64: MOV x23, x0                | X23 = 8 (0x8);//ML01                    
        val_39 = 8;
        // 0x02730C68: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
        label_53:
        // 0x02730C6C: MOV x0, x23                | X0 = 8 (0x8);//ML01                     
        // 0x02730C70: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
        // 0x02730C74: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
    
    }
    //
    // Offset in libil2cpp.so: 0x0272CECC (41078476), len: 3252  VirtAddr: 0x0272CECC RVA: 0x0272CECC token: 100663340 methodIndex: 24308 delegateWrapperIndex: 0 methodInvoker: 0
    private static void _HandleException(LogSeverity logLevel, string name, string message, string stackTrace, bool uncaught)
    {
        //
        // Disasemble & Code
        //  | 
        var val_57;
        //  | 
        var val_58;
        //  | 
        object val_59;
        //  | 
        string val_60;
        //  | 
        string val_61;
        //  | 
        var val_62;
        //  | 
        var val_63;
        //  | 
        var val_64;
        //  | 
        string val_65;
        //  | 
        var val_66;
        //  | 
        int val_67;
        //  | 
        var val_68;
        // 0x0272CECC: STP x28, x27, [sp, #-0x60]! | stack[1152921509930318576] = ???;  stack[1152921509930318584] = ???;  //  dest_result_addr=1152921509930318576 |  dest_result_addr=1152921509930318584
        // 0x0272CED0: STP x26, x25, [sp, #0x10]  | stack[1152921509930318592] = ???;  stack[1152921509930318600] = ???;  //  dest_result_addr=1152921509930318592 |  dest_result_addr=1152921509930318600
        // 0x0272CED4: STP x24, x23, [sp, #0x20]  | stack[1152921509930318608] = ???;  stack[1152921509930318616] = ???;  //  dest_result_addr=1152921509930318608 |  dest_result_addr=1152921509930318616
        // 0x0272CED8: STP x22, x21, [sp, #0x30]  | stack[1152921509930318624] = ???;  stack[1152921509930318632] = ???;  //  dest_result_addr=1152921509930318624 |  dest_result_addr=1152921509930318632
        // 0x0272CEDC: STP x20, x19, [sp, #0x40]  | stack[1152921509930318640] = ???;  stack[1152921509930318648] = ???;  //  dest_result_addr=1152921509930318640 |  dest_result_addr=1152921509930318648
        // 0x0272CEE0: STP x29, x30, [sp, #0x50]  | stack[1152921509930318656] = ???;  stack[1152921509930318664] = ???;  //  dest_result_addr=1152921509930318656 |  dest_result_addr=1152921509930318664
        // 0x0272CEE4: ADD x29, sp, #0x50         | X29 = (1152921509930318576 + 80) = 1152921509930318656 (0x100000013D4DBB40);
        // 0x0272CEE8: SUB sp, sp, #0x10          | SP = (1152921509930318576 - 16) = 1152921509930318560 (0x100000013D4DBAE0);
        // 0x0272CEEC: ADRP x23, #0x3743000       | X23 = 57946112 (0x3743000);             
        // 0x0272CEF0: LDRB w8, [x23, #0xac2]     | W8 = (bool)static_value_03743AC2;       
        // 0x0272CEF4: MOV w19, w5                | W19 = W5;//m1                           
        val_58 = W5;
        // 0x0272CEF8: MOV x20, x4                | X20 = uncaught;//m1                     
        val_59 = uncaught;
        // 0x0272CEFC: MOV x22, x3                | X22 = stackTrace;//m1                   
        // 0x0272CF00: MOV x21, x2                | X21 = message;//m1                      
        val_60 = message;
        // 0x0272CF04: MOV w24, w1                | W24 = name;//m1                         
        val_61 = name;
        // 0x0272CF08: STR w24, [sp, #0xc]        | stack[1152921509930318572] = name;       //  dest_result_addr=1152921509930318572
        // 0x0272CF0C: TBNZ w8, #0, #0x272cf28    | if (static_value_03743AC2 == true) goto label_0;
        // 0x0272CF10: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x0272CF14: LDR x8, [x8, #0xf28]       | X8 = 0x2B8FDE0;                         
        // 0x0272CF18: LDR w0, [x8]               | W0 = 0x163C;                            
        // 0x0272CF1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x163C, ????);     
        // 0x0272CF20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272CF24: STRB w8, [x23, #0xac2]     | static_value_03743AC2 = true;            //  dest_result_addr=57948866
        label_0:
        // 0x0272CF28: ADRP x28, #0x3652000       | X28 = 56958976 (0x3652000);             
        // 0x0272CF2C: LDR x28, [x28, #0x938]     | X28 = 1152921504776761344;              
        // 0x0272CF30: LDR x0, [x28]              | X0 = typeof(BuglyAgent);                
        // 0x0272CF34: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272CF38: TBZ w8, #0, #0x272cf48     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272CF3C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272CF40: CBNZ w8, #0x272cf48        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272CF44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_2:
        // 0x0272CF48: BL #0x272b910              | X0 = BuglyAgent.get_IsInitialized();    
        bool val_1 = BuglyAgent.IsInitialized;
        // 0x0272CF4C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x0272CF50: TBZ w8, #0, #0x272d074     | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x0272CF54: CBZ w24, #0x272daf0        | if (name == null) goto label_17;        
        if(val_61 == null)
        {
            goto label_17;
        }
        // 0x0272CF58: TBZ w19, #0, #0x272d0e4    | if ((W5 & 0x1) == 0) goto label_8;      
        if((val_58 & 1) == 0)
        {
            goto label_8;
        }
        // 0x0272CF5C: LDR x0, [x28]              | X0 = typeof(BuglyAgent);                
        val_62 = null;
        // 0x0272CF60: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272CF64: TBZ w8, #0, #0x272cf78     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272CF68: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272CF6C: CBNZ w8, #0x272cf78        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272CF70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        // 0x0272CF74: LDR x0, [x28]              | X0 = typeof(BuglyAgent);                
        val_62 = null;
        label_7:
        // 0x0272CF78: LDR x8, [x0, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x0272CF7C: LDR w8, [x8, #0x54]        | W8 = BuglyAgent._autoReportLogLevel;    
        // 0x0272CF80: CMP w8, w24                | STATE = COMPARE(BuglyAgent._autoReportLogLevel, name)
        // 0x0272CF84: B.LE #0x272d0e4            | if (BuglyAgent._autoReportLogLevel <= val_61) goto label_8;
        if(BuglyAgent._autoReportLogLevel <= val_61)
        {
            goto label_8;
        }
        // 0x0272CF88: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x0272CF8C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x0272CF90: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
        // 0x0272CF94: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272CF98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272CF9C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272CFA0: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272CFA4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272CFA8: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x0272CFAC: LDR x8, [x8, #0x6d0]       | X8 = 1152921504776708096;               
        // 0x0272CFB0: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_58 = null;
        // 0x0272CFB4: ADD x1, sp, #0xc           | X1 = (1152921509930318560 + 12) = 1152921509930318572 (0x100000013D4DBAEC);
        // 0x0272CFB8: LDR x8, [x8]               | X8 = typeof(LogSeverity);               
        // 0x0272CFBC: MOV x0, x8                 | X0 = 1152921504776708096 (0x100000000A1FE000);//ML01
        // 0x0272CFC0: BL #0x27bc028              | X0 = 1152921509930379056 = (Il2CppObject*)Box((RuntimeClass*)typeof(LogSeverity), name);
        // 0x0272CFC4: MOV x21, x0                | X21 = 1152921509930379056 (0x100000013D4EA730);//ML01
        val_60 = val_61;
        // 0x0272CFC8: CBNZ x21, #0x272cfd0       | if (name != 0) goto label_9;            
        if(val_61 != 0)
        {
            goto label_9;
        }
        // 0x0272CFCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? name, ????);       
        label_9:
        // 0x0272CFD0: LDR x8, [x21]              | X8 = typeof(LogSeverity);               
        // 0x0272CFD4: MOV x0, x21                | X0 = 1152921509930379056 (0x100000013D4EA730);//ML01
        // 0x0272CFD8: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x0272CFDC: BLR x9                     | X0 = name.ToString();                   
        string val_3 = val_61.ToString();
        // 0x0272CFE0: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x0272CFE4: CBNZ x21, #0x272cfec       | if (name != 0) goto label_10;           
        if(val_61 != 0)
        {
            goto label_10;
        }
        // 0x0272CFE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x0272CFEC: MOV x0, x21                | X0 = 1152921509930379056 (0x100000013D4EA730);//ML01
        // 0x0272CFF0: BL #0x27bc4e8              | name.System.IDisposable.Dispose();      
        val_61.System.IDisposable.Dispose();
        // 0x0272CFF4: LDR w8, [x0]               | W8 = typeof(LogSeverity);               
        // 0x0272CFF8: STR w8, [sp, #0xc]         | stack[1152921509930318572] = typeof(LogSeverity);  //  dest_result_addr=1152921509930318572
        // 0x0272CFFC: CBNZ x19, #0x272d004       | if ( != null) goto label_11;            
        if(null != null)
        {
            goto label_11;
        }
        // 0x0272D000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? name, ????);       
        label_11:
        // 0x0272D004: CBZ x20, #0x272d028        | if (val_3 == null) goto label_13;       
        if(val_3 == null)
        {
            goto label_13;
        }
        // 0x0272D008: LDR x8, [x19]              | X8 = ;                                  
        // 0x0272D00C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x0272D010: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x0272D014: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x0272D018: CBNZ x0, #0x272d028        | if (val_3 != null) goto label_13;       
        if(val_3 != null)
        {
            goto label_13;
        }
        // 0x0272D01C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
        // 0x0272D020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D024: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_13:
        // 0x0272D028: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x0272D02C: CBNZ w8, #0x272d03c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_14;
        // 0x0272D030: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x0272D034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D038: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_14:
        // 0x0272D03C: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_3;
        // 0x0272D040: LDR x0, [x28]              | X0 = typeof(BuglyAgent);                
        // 0x0272D044: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272D048: TBZ w8, #0, #0x272d058     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x0272D04C: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272D050: CBNZ w8, #0x272d058        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x0272D054: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_16:
        // 0x0272D058: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x0272D05C: LDR x8, [x8, #0x978]       | X8 = (string**)(1152921509930181664)("Not report exception for level {0}");
        // 0x0272D060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D064: MOV x3, x19                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272D068: LDR x2, [x8]               | X2 = "Not report exception for level {0}";
        // 0x0272D06C: BL #0x272b978              | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Not report exception for level {0}");
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "Not report exception for level {0}");
        // 0x0272D070: B #0x272daf0               |  goto label_17;                         
        goto label_17;
        label_3:
        // 0x0272D074: LDR x0, [x28]              | X0 = typeof(BuglyAgent);                
        // 0x0272D078: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272D07C: TBZ w8, #0, #0x272d08c     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x0272D080: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272D084: CBNZ w8, #0x272d08c        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x0272D088: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_19:
        // 0x0272D08C: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x0272D090: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x0272D094: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921509930181808)("It has not been initialized.");
        // 0x0272D098: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
        // 0x0272D09C: LDR x19, [x8]              | X19 = "It has not been initialized.";   
        // 0x0272D0A0: LDR x20, [x9]              | X20 = typeof(System.Object[]);          
        // 0x0272D0A4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272D0A8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x0272D0AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D0B0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272D0B4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x0272D0B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D0BC: MOV x2, x19                | X2 = 1152921509930181808 (0x100000013D4BA4B0);//ML01
        // 0x0272D0C0: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x0272D0C4: SUB sp, x29, #0x50         | SP = (1152921509930318656 - 80) = 1152921509930318576 (0x100000013D4DBAF0);
        // 0x0272D0C8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x0272D0CC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x0272D0D0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x0272D0D4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x0272D0D8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x0272D0DC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x0272D0E0: B #0x272b978               | BuglyAgent.DebugLog(tag:  null, format:  0, args:  "It has not been initialized."); return;
        BuglyAgent.DebugLog(tag:  null, format:  0, args:  "It has not been initialized.");
        return;
        label_8:
        // 0x0272D0E4: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x0272D0E8: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        val_63 = 1152921504608284672;
        // 0x0272D0EC: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x0272D0F0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272D0F4: TBZ w8, #0, #0x272d104     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x0272D0F8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272D0FC: CBNZ w8, #0x272d104        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x0272D100: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_21:
        // 0x0272D104: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272D108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D10C: MOV x1, x22                | X1 = stackTrace;//m1                    
        // 0x0272D110: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_4 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272D114: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_57 = 0;
        // 0x0272D118: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x0272D11C: TBZ w8, #0, #0x272d128     | if ((val_4 & 1) == false) goto label_22;
        if(val_5 == false)
        {
            goto label_22;
        }
        // 0x0272D120: MOV x24, x23               | X24 = 0 (0x0);//ML01                    
        val_64 = val_57;
        // 0x0272D124: B #0x272d9e4               |  goto label_23;                         
        goto label_23;
        label_22:
        // 0x0272D128: CMP w24, #6                | STATE = COMPARE(name, 0x6)              
        // 0x0272D12C: B.NE #0x272d34c            | if (val_61 != 0x6) goto label_24;       
        if(val_61 != 6)
        {
            goto label_24;
        }
        // 0x0272D130: CBNZ x22, #0x272d140       | if (stackTrace != null) goto label_25;  
        if(stackTrace != null)
        {
            goto label_25;
        }
        // 0x0272D134: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D138: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D13C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_25:
        // 0x0272D140: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x0272D144: LDR x8, [x8, #0x1b8]       | X8 = (string**)(1152921509554343904)("Exception");
        // 0x0272D148: LDR x1, [x8]               | X1 = "Exception";                       
        // 0x0272D14C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D150: MOV x0, x22                | X0 = stackTrace;//m1                    
        // 0x0272D154: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D158: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D15C: BL #0x18ad42c              | X0 = stackTrace.Contains(value:  "Exception");
        bool val_6 = stackTrace.Contains(value:  "Exception");
        // 0x0272D160: AND w8, w0, #1             | W8 = (val_6 & 1);                       
        bool val_7 = val_6;
        // 0x0272D164: TBZ w8, #0, #0x272d340     | if ((val_6 & 1) == false) goto label_26;
        if(val_7 == false)
        {
            goto label_26;
        }
        // 0x0272D168: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x0272D16C: LDR x8, [x8, #0x3a0]       | X8 = 1152921504681553920;               
        // 0x0272D170: LDR x0, [x8]               | X0 = typeof(System.Text.RegularExpressions.Regex);
        // 0x0272D174: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D178: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D17C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.RegularExpressions.Regex), ????);
        // 0x0272D180: MOV x25, x0                | X25 = 1152921504681553920 (0x100000000473F000);//ML01
        // 0x0272D184: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x0272D188: LDR x8, [x8, #0x8f8]       | X8 = (string**)(1152921509930181936)("^(?<errorType>\\S+):\\s*(?<errorMessage>.*)");
        // 0x0272D18C: LDR x1, [x8]               | X1 = "^(?<errorType>\\S+):\\s*(?<errorMessage>.*)";
        // 0x0272D190: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D194: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
        // 0x0272D198: MOV x0, x25                | X0 = 1152921504681553920 (0x100000000473F000);//ML01
        System.Text.RegularExpressions.Regex val_8 = null;
        // 0x0272D19C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D1A0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D1A4: BL #0x1ebe580              | .ctor(pattern:  "^(?<errorType>\\S+):\\s*(?<errorMessage>.*)", options:  16);
        val_8 = new System.Text.RegularExpressions.Regex(pattern:  "^(?<errorType>\\S+):\\s*(?<errorMessage>.*)", options:  16);
        // 0x0272D1A8: CBNZ x25, #0x272d1b8       | if ( != 0) goto label_27;               
        if(null != 0)
        {
            goto label_27;
        }
        // 0x0272D1AC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D1B0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D1B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(pattern:  "^(?<errorType>\\S+):\\s*(?<errorMessage>.*)", options:  16), ????);
        label_27:
        // 0x0272D1B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D1BC: MOV x0, x25                | X0 = 1152921504681553920 (0x100000000473F000);//ML01
        // 0x0272D1C0: MOV x1, x22                | X1 = stackTrace;//m1                    
        // 0x0272D1C4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D1C8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D1CC: BL #0x1ec0180              | X0 = Match(input:  stackTrace);         
        System.Text.RegularExpressions.Match val_9 = Match(input:  stackTrace);
        // 0x0272D1D0: MOV x25, x0                | X25 = val_9;//m1                        
        // 0x0272D1D4: CBNZ x25, #0x272d1e4       | if (val_9 != null) goto label_28;       
        if(val_9 != null)
        {
            goto label_28;
        }
        // 0x0272D1D8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D1DC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D1E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_28:
        // 0x0272D1E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D1E8: MOV x0, x25                | X0 = val_9;//m1                         
        // 0x0272D1EC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D1F0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D1F4: BL #0x1eb458c              | X0 = val_9.get_Success();               
        bool val_10 = val_9.Success;
        // 0x0272D1F8: TBZ w0, #0, #0x272d7d0     | if (val_10 == false) goto label_44;     
        if(val_10 == false)
        {
            goto label_44;
        }
        // 0x0272D1FC: CBNZ x25, #0x272d20c       | if (val_9 != null) goto label_30;       
        if(val_9 != null)
        {
            goto label_30;
        }
        // 0x0272D200: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D204: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_30:
        // 0x0272D20C: LDR x8, [x25]              | X8 = typeof(System.Text.RegularExpressions.Match);
        // 0x0272D210: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150; X1 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_158; //  | 
        // 0x0272D214: MOV x0, x25                | X0 = val_9;//m1                         
        // 0x0272D218: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D21C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D220: BLR x9                     | X0 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150();
        // 0x0272D224: MOV x26, x0                | X26 = val_9;//m1                        
        // 0x0272D228: CBNZ x26, #0x272d238       | if (val_9 != null) goto label_31;       
        if(val_9 != null)
        {
            goto label_31;
        }
        // 0x0272D22C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D230: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_31:
        // 0x0272D238: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x0272D23C: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921509930186192)("errorType");
        // 0x0272D240: LDR x1, [x8]               | X1 = "errorType";                       
        // 0x0272D244: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D248: MOV x0, x26                | X0 = val_9;//m1                         
        // 0x0272D24C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D250: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D254: BL #0x1eb6d50              | X0 = val_9.get_Item(groupName:  "errorType");
        System.Text.RegularExpressions.Group val_11 = val_9.Item["errorType"];
        // 0x0272D258: MOV x26, x0                | X26 = val_11;//m1                       
        // 0x0272D25C: CBNZ x26, #0x272d26c       | if (val_11 != null) goto label_32;      
        if(val_11 != null)
        {
            goto label_32;
        }
        // 0x0272D260: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D264: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_32:
        // 0x0272D26C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D270: MOV x0, x26                | X0 = val_11;//m1                        
        // 0x0272D274: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D278: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D27C: BL #0x1eb4ff4              | X0 = val_11.get_Value();                
        string val_12 = val_11.Value;
        // 0x0272D280: MOV x26, x0                | X26 = val_12;//m1                       
        // 0x0272D284: CBNZ x26, #0x272d294       | if (val_12 != null) goto label_33;      
        if(val_12 != null)
        {
            goto label_33;
        }
        // 0x0272D288: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D28C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D290: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_33:
        // 0x0272D294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D298: MOV x0, x26                | X0 = val_12;//m1                        
        // 0x0272D29C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D2A0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D2A4: BL #0x18a946c              | X0 = val_12.Trim();                     
        string val_13 = val_12.Trim();
        // 0x0272D2A8: MOV x24, x0                | X24 = val_13;//m1                       
        val_64 = val_13;
        // 0x0272D2AC: CBNZ x25, #0x272d2b8       | if (val_9 != null) goto label_34;       
        if(val_9 != null)
        {
            goto label_34;
        }
        // 0x0272D2B0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D2B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_34:
        // 0x0272D2B8: LDR x8, [x25]              | X8 = typeof(System.Text.RegularExpressions.Match);
        // 0x0272D2BC: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150; X1 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_158; //  | 
        // 0x0272D2C0: MOV x0, x25                | X0 = val_9;//m1                         
        // 0x0272D2C4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D2C8: BLR x9                     | X0 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150();
        // 0x0272D2CC: MOV x25, x0                | X25 = val_9;//m1                        
        // 0x0272D2D0: CBNZ x25, #0x272d2dc       | if (val_9 != null) goto label_35;       
        if(val_9 != null)
        {
            goto label_35;
        }
        // 0x0272D2D4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_35:
        // 0x0272D2DC: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x0272D2E0: LDR x8, [x8, #0xce0]       | X8 = (string**)(1152921509930198576)("errorMessage");
        // 0x0272D2E4: LDR x1, [x8]               | X1 = "errorMessage";                    
        // 0x0272D2E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D2EC: MOV x0, x25                | X0 = val_9;//m1                         
        // 0x0272D2F0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D2F4: BL #0x1eb6d50              | X0 = val_9.get_Item(groupName:  "errorMessage");
        System.Text.RegularExpressions.Group val_14 = val_9.Item["errorMessage"];
        // 0x0272D2F8: MOV x25, x0                | X25 = val_14;//m1                       
        // 0x0272D2FC: CBNZ x25, #0x272d308       | if (val_14 != null) goto label_36;      
        if(val_14 != null)
        {
            goto label_36;
        }
        // 0x0272D300: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_36:
        // 0x0272D308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D30C: MOV x0, x25                | X0 = val_14;//m1                        
        // 0x0272D310: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D314: BL #0x1eb4ff4              | X0 = val_14.get_Value();                
        string val_15 = val_14.Value;
        // 0x0272D318: MOV x25, x0                | X25 = val_15;//m1                       
        // 0x0272D31C: CBNZ x25, #0x272d328       | if (val_15 != null) goto label_37;      
        if(val_15 != null)
        {
            goto label_37;
        }
        // 0x0272D320: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_37:
        // 0x0272D328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D32C: MOV x0, x25                | X0 = val_15;//m1                        
        // 0x0272D330: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D334: BL #0x18a946c              | X0 = val_15.Trim();                     
        string val_16 = val_15.Trim();
        // 0x0272D338: MOV x23, x0                | X23 = val_16;//m1                       
        val_65 = val_16;
        // 0x0272D33C: B #0x272d9ac               |  goto label_85;                         
        goto label_85;
        label_26:
        // 0x0272D340: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x0272D344: LDR w24, [sp, #0xc]        | W24 = typeof(LogSeverity);              
        val_61 = null;
        // 0x0272D348: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        val_63 = 1152921504608284672;
        label_24:
        // 0x0272D34C: CMP w24, #5                | STATE = COMPARE(typeof(LogSeverity), 0x5)
        // 0x0272D350: B.NE #0x272d7dc            | if (val_61 != 0x5) goto label_39;       
        if(val_61 != 5)
        {
            goto label_39;
        }
        // 0x0272D354: CBNZ x22, #0x272d364       | if (stackTrace != null) goto label_40;  
        if(stackTrace != null)
        {
            goto label_40;
        }
        // 0x0272D358: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D35C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_40:
        // 0x0272D364: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x0272D368: LDR x8, [x8, #0x538]       | X8 = (string**)(1152921509930210960)("Unhandled Exception:");
        // 0x0272D36C: LDR x1, [x8]               | X1 = "Unhandled Exception:";            
        // 0x0272D370: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D374: MOV x0, x22                | X0 = stackTrace;//m1                    
        // 0x0272D378: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D37C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D380: BL #0x18add38              | X0 = stackTrace.StartsWith(value:  "Unhandled Exception:");
        bool val_17 = stackTrace.StartsWith(value:  "Unhandled Exception:");
        // 0x0272D384: TBZ w0, #0, #0x272d7d0     | if (val_17 == false) goto label_44;     
        if(val_17 == false)
        {
            goto label_44;
        }
        // 0x0272D388: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x0272D38C: LDR x8, [x8, #0x3a0]       | X8 = 1152921504681553920;               
        // 0x0272D390: LDR x0, [x8]               | X0 = typeof(System.Text.RegularExpressions.Regex);
        // 0x0272D394: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D398: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D39C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.RegularExpressions.Regex), ????);
        // 0x0272D3A0: MOV x25, x0                | X25 = 1152921504681553920 (0x100000000473F000);//ML01
        // 0x0272D3A4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x0272D3A8: LDR x8, [x8, #0x18]        | X8 = (string**)(1152921509930211072)("^Unhandled\\s+Exception:\\s*(?<exceptionName>\\S+):\\s*(?<exceptionDetail>.*)");
        // 0x0272D3AC: LDR x1, [x8]               | X1 = "^Unhandled\\s+Exception:\\s*(?<exceptionName>\\S+):\\s*(?<exceptionDetail>.*)";
        // 0x0272D3B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D3B4: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
        // 0x0272D3B8: MOV x0, x25                | X0 = 1152921504681553920 (0x100000000473F000);//ML01
        System.Text.RegularExpressions.Regex val_18 = null;
        // 0x0272D3BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D3C0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D3C4: BL #0x1ebe580              | .ctor(pattern:  "^Unhandled\\s+Exception:\\s*(?<exceptionName>\\S+):\\s*(?<exceptionDetail>.*)", options:  16);
        val_18 = new System.Text.RegularExpressions.Regex(pattern:  "^Unhandled\\s+Exception:\\s*(?<exceptionName>\\S+):\\s*(?<exceptionDetail>.*)", options:  16);
        // 0x0272D3C8: CBNZ x25, #0x272d3d8       | if ( != 0) goto label_42;               
        if(null != 0)
        {
            goto label_42;
        }
        // 0x0272D3CC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D3D0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D3D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(pattern:  "^Unhandled\\s+Exception:\\s*(?<exceptionName>\\S+):\\s*(?<exceptionDetail>.*)", options:  16), ????);
        label_42:
        // 0x0272D3D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D3DC: MOV x0, x25                | X0 = 1152921504681553920 (0x100000000473F000);//ML01
        // 0x0272D3E0: MOV x1, x22                | X1 = stackTrace;//m1                    
        // 0x0272D3E4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D3E8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D3EC: BL #0x1ec0180              | X0 = Match(input:  stackTrace);         
        System.Text.RegularExpressions.Match val_19 = Match(input:  stackTrace);
        // 0x0272D3F0: MOV x26, x0                | X26 = val_19;//m1                       
        // 0x0272D3F4: CBNZ x26, #0x272d404       | if (val_19 != null) goto label_43;      
        if(val_19 != null)
        {
            goto label_43;
        }
        // 0x0272D3F8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D3FC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D400: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_43:
        // 0x0272D404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D408: MOV x0, x26                | X0 = val_19;//m1                        
        // 0x0272D40C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D410: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D414: BL #0x1eb458c              | X0 = val_19.get_Success();              
        bool val_20 = val_19.Success;
        // 0x0272D418: TBZ w0, #0, #0x272d7d0     | if (val_20 == false) goto label_44;     
        if(val_20 == false)
        {
            goto label_44;
        }
        // 0x0272D41C: CBNZ x26, #0x272d42c       | if (val_19 != null) goto label_45;      
        if(val_19 != null)
        {
            goto label_45;
        }
        // 0x0272D420: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D424: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_45:
        // 0x0272D42C: LDR x8, [x26]              | X8 = typeof(System.Text.RegularExpressions.Match);
        // 0x0272D430: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150; X1 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_158; //  | 
        // 0x0272D434: MOV x0, x26                | X0 = val_19;//m1                        
        // 0x0272D438: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D43C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D440: BLR x9                     | X0 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150();
        // 0x0272D444: MOV x25, x0                | X25 = val_19;//m1                       
        // 0x0272D448: CBNZ x25, #0x272d458       | if (val_19 != null) goto label_46;      
        if(val_19 != null)
        {
            goto label_46;
        }
        // 0x0272D44C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D450: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_46:
        // 0x0272D458: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x0272D45C: LDR x8, [x8, #0x480]       | X8 = (string**)(1152921509930215392)("exceptionName");
        // 0x0272D460: LDR x1, [x8]               | X1 = "exceptionName";                   
        // 0x0272D464: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D468: MOV x0, x25                | X0 = val_19;//m1                        
        // 0x0272D46C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D470: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D474: BL #0x1eb6d50              | X0 = val_19.get_Item(groupName:  "exceptionName");
        System.Text.RegularExpressions.Group val_21 = val_19.Item["exceptionName"];
        // 0x0272D478: MOV x25, x0                | X25 = val_21;//m1                       
        // 0x0272D47C: CBNZ x25, #0x272d48c       | if (val_21 != null) goto label_47;      
        if(val_21 != null)
        {
            goto label_47;
        }
        // 0x0272D480: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D484: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D488: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_47:
        // 0x0272D48C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D490: MOV x0, x25                | X0 = val_21;//m1                        
        // 0x0272D494: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D498: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D49C: BL #0x1eb4ff4              | X0 = val_21.get_Value();                
        string val_22 = val_21.Value;
        // 0x0272D4A0: MOV x25, x0                | X25 = val_22;//m1                       
        // 0x0272D4A4: CBNZ x25, #0x272d4b4       | if (val_22 != null) goto label_48;      
        if(val_22 != null)
        {
            goto label_48;
        }
        // 0x0272D4A8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D4AC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D4B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_48:
        // 0x0272D4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D4B8: MOV x0, x25                | X0 = val_22;//m1                        
        // 0x0272D4BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D4C0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D4C4: BL #0x18a946c              | X0 = val_22.Trim();                     
        string val_23 = val_22.Trim();
        // 0x0272D4C8: MOV x25, x0                | X25 = val_23;//m1                       
        val_66 = val_23;
        // 0x0272D4CC: CBNZ x26, #0x272d4dc       | if (val_19 != null) goto label_49;      
        if(val_19 != null)
        {
            goto label_49;
        }
        // 0x0272D4D0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D4D4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D4D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_49:
        // 0x0272D4DC: LDR x8, [x26]              | X8 = typeof(System.Text.RegularExpressions.Match);
        // 0x0272D4E0: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150; X1 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_158; //  | 
        // 0x0272D4E4: MOV x0, x26                | X0 = val_19;//m1                        
        // 0x0272D4E8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D4EC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D4F0: BLR x9                     | X0 = typeof(System.Text.RegularExpressions.Match).__il2cppRuntimeField_150();
        // 0x0272D4F4: MOV x26, x0                | X26 = val_19;//m1                       
        // 0x0272D4F8: CBNZ x26, #0x272d508       | if (val_19 != null) goto label_50;      
        if(val_19 != null)
        {
            goto label_50;
        }
        // 0x0272D4FC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D500: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_50:
        // 0x0272D508: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x0272D50C: LDR x8, [x8, #0xde8]       | X8 = (string**)(1152921509930227776)("exceptionDetail");
        // 0x0272D510: LDR x1, [x8]               | X1 = "exceptionDetail";                 
        // 0x0272D514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D518: MOV x0, x26                | X0 = val_19;//m1                        
        // 0x0272D51C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D520: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D524: BL #0x1eb6d50              | X0 = val_19.get_Item(groupName:  "exceptionDetail");
        System.Text.RegularExpressions.Group val_24 = val_19.Item["exceptionDetail"];
        // 0x0272D528: MOV x26, x0                | X26 = val_24;//m1                       
        // 0x0272D52C: CBNZ x26, #0x272d53c       | if (val_24 != null) goto label_51;      
        if(val_24 != null)
        {
            goto label_51;
        }
        // 0x0272D530: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D534: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_51:
        // 0x0272D53C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D540: MOV x0, x26                | X0 = val_24;//m1                        
        // 0x0272D544: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D548: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D54C: BL #0x1eb4ff4              | X0 = val_24.get_Value();                
        string val_25 = val_24.Value;
        // 0x0272D550: MOV x26, x0                | X26 = val_25;//m1                       
        // 0x0272D554: CBNZ x26, #0x272d564       | if (val_25 != null) goto label_52;      
        if(val_25 != null)
        {
            goto label_52;
        }
        // 0x0272D558: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D55C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_52:
        // 0x0272D564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D568: MOV x0, x26                | X0 = val_25;//m1                        
        // 0x0272D56C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D570: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D574: BL #0x18a946c              | X0 = val_25.Trim();                     
        string val_26 = val_25.Trim();
        // 0x0272D578: STR x0, [sp]               | stack[1152921509930318560] = val_26;     //  dest_result_addr=1152921509930318560
        // 0x0272D57C: CBNZ x25, #0x272d58c       | if (val_23 != null) goto label_53;      
        if(val_66 != null)
        {
            goto label_53;
        }
        // 0x0272D580: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D584: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_53:
        // 0x0272D58C: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x0272D590: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
        // 0x0272D594: LDR x1, [x8]               | X1 = ".";                               
        // 0x0272D598: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D59C: MOV x0, x25                | X0 = val_23;//m1                        
        // 0x0272D5A0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D5A4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D5A8: BL #0x18ad1e4              | X0 = val_23.LastIndexOf(value:  ".");   
        int val_27 = val_66.LastIndexOf(value:  ".");
        // 0x0272D5AC: MOV w27, w0                | W27 = val_27;//m1                       
        // 0x0272D5B0: CMP w27, #1                | STATE = COMPARE(val_27, 0x1)            
        // 0x0272D5B4: B.LT #0x272d610            | if (val_27 < 1) goto label_56;          
        if(val_27 < 1)
        {
            goto label_56;
        }
        // 0x0272D5B8: CBNZ x25, #0x272d5c8       | if (val_23 != null) goto label_55;      
        if(val_66 != null)
        {
            goto label_55;
        }
        // 0x0272D5BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D5C0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D5C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_55:
        // 0x0272D5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D5CC: MOV x0, x25                | X0 = val_23;//m1                        
        // 0x0272D5D0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D5D4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D5D8: BL #0x18a4460              | X0 = val_23.get_Length();               
        int val_28 = val_66.Length;
        // 0x0272D5DC: CMP w27, w0                | STATE = COMPARE(val_27, val_28)         
        // 0x0272D5E0: B.EQ #0x272d610            | if (val_27 == val_28) goto label_56;    
        if(val_27 == val_28)
        {
            goto label_56;
        }
        // 0x0272D5E4: CBNZ x25, #0x272d5f4       | if (val_23 != null) goto label_57;      
        if(val_66 != null)
        {
            goto label_57;
        }
        // 0x0272D5E8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D5EC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D5F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_57:
        // 0x0272D5F4: ADD w1, w27, #1            | W1 = (val_27 + 1);                      
        int val_29 = val_27 + 1;
        // 0x0272D5F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D5FC: MOV x0, x25                | X0 = val_23;//m1                        
        // 0x0272D600: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D604: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D608: BL #0x18a5a40              | X0 = val_23.Substring(startIndex:  int val_29 = val_27 + 1);
        string val_30 = val_66.Substring(startIndex:  val_29);
        // 0x0272D60C: MOV x25, x0                | X25 = val_30;//m1                       
        val_66 = val_30;
        label_56:
        // 0x0272D610: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D614: CBNZ x8, #0x272d624        | if (val_26 != 0) goto label_58;         
        if(val_26 != 0)
        {
            goto label_58;
        }
        // 0x0272D618: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D61C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_58:
        // 0x0272D624: ADRP x26, #0x35c4000       | X26 = 56377344 (0x35C4000);             
        // 0x0272D628: LDR x26, [x26, #0xaf0]     | X26 = (string**)(1152921509930244272)(" at ");
        // 0x0272D62C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D630: LDR x1, [x26]              | X1 = " at ";                            
        // 0x0272D634: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D638: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D63C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D640: BL #0x18a590c              | X0 = val_26.IndexOf(value:  " at ");    
        int val_31 = val_26.IndexOf(value:  " at ");
        // 0x0272D644: MOV w27, w0                | W27 = val_31;//m1                       
        val_67 = val_31;
        // 0x0272D648: CMP w27, #1                | STATE = COMPARE(val_31, 0x1)            
        // 0x0272D64C: B.LT #0x272d7e8            | if (val_67 < 1) goto label_59;          
        if(val_67 < 1)
        {
            goto label_59;
        }
        // 0x0272D650: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D654: CBNZ x8, #0x272d664        | if (val_26 != 0) goto label_60;         
        if(val_26 != 0)
        {
            goto label_60;
        }
        // 0x0272D658: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D65C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_60:
        // 0x0272D664: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D668: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D66C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x0272D670: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D674: MOV w2, w27                | W2 = val_31;//m1                        
        // 0x0272D678: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        // 0x0272D67C: BL #0x18a920c              | X0 = val_26.Substring(startIndex:  0, length:  val_67);
        string val_32 = val_26.Substring(startIndex:  0, length:  val_67);
        // 0x0272D680: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D684: MOV x23, x0                | X23 = val_32;//m1                       
        val_65 = val_32;
        // 0x0272D688: CBNZ x8, #0x272d694        | if (val_26 != 0) goto label_61;         
        if(val_26 != 0)
        {
            goto label_61;
        }
        // 0x0272D68C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_61:
        // 0x0272D694: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D698: ADD w1, w27, #3            | W1 = (val_31 + 3);                      
        int val_33 = val_67 + 3;
        // 0x0272D69C: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D6A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D6A4: BL #0x18a5a40              | X0 = val_26.Substring(startIndex:  int val_33 = val_67 + 3);
        string val_34 = val_26.Substring(startIndex:  val_33);
        // 0x0272D6A8: MOV x27, x0                | X27 = val_34;//m1                       
        // 0x0272D6AC: CBNZ x27, #0x272d6b8       | if (val_34 != null) goto label_62;      
        if(val_34 != null)
        {
            goto label_62;
        }
        // 0x0272D6B0: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D6B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_62:
        // 0x0272D6B8: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x0272D6BC: LDR x1, [x26]              | X1 = " at ";                            
        // 0x0272D6C0: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509777796272)("\n");
        // 0x0272D6C4: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D6C8: LDR x2, [x8]               | X2 = "\n";                              
        // 0x0272D6CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D6D0: MOV x0, x27                | X0 = val_34;//m1                        
        // 0x0272D6D4: BL #0x18ae7e4              | X0 = val_34.Replace(oldValue:  " at ", newValue:  "\n");
        string val_35 = val_34.Replace(oldValue:  " at ", newValue:  "\n");
        // 0x0272D6D8: MOV x27, x0                | X27 = val_35;//m1                       
        // 0x0272D6DC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x0272D6E0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x0272D6E4: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_68 = null;
        // 0x0272D6E8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272D6EC: TBZ w8, #0, #0x272d70c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_64;
        // 0x0272D6F0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272D6F4: CBNZ w8, #0x272d70c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_64;
        // 0x0272D6F8: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D6FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x0272D700: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x0272D704: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x0272D708: LDR x0, [x8]               | X0 = typeof(System.String);             
        val_68 = null;
        label_64:
        // 0x0272D70C: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x0272D710: LDR x26, [x8]              | X26 = System.String.Empty;              
        // 0x0272D714: CBNZ x27, #0x272d720       | if (val_35 != null) goto label_65;      
        if(val_35 != null)
        {
            goto label_65;
        }
        // 0x0272D718: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D71C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
        label_65:
        // 0x0272D720: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x0272D724: LDR x8, [x8, #0x458]       | X8 = (string**)(1152921509930256640)("in <filename unknown>:0");
        // 0x0272D728: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D72C: LDR x1, [x8]               | X1 = "in <filename unknown>:0";         
        // 0x0272D730: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D734: MOV x0, x27                | X0 = val_35;//m1                        
        // 0x0272D738: MOV x2, x26                | X2 = System.String.Empty;//m1           
        // 0x0272D73C: BL #0x18ae7e4              | X0 = val_35.Replace(oldValue:  "in <filename unknown>:0", newValue:  System.String.Empty);
        string val_36 = val_35.Replace(oldValue:  "in <filename unknown>:0", newValue:  System.String.Empty);
        // 0x0272D740: MOV x27, x0                | X27 = val_36;//m1                       
        // 0x0272D744: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x0272D748: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x0272D74C: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x0272D750: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x0272D754: LDR x26, [x8]              | X26 = System.String.Empty;              
        // 0x0272D758: CBNZ x27, #0x272d764       | if (val_36 != null) goto label_66;      
        if(val_36 != null)
        {
            goto label_66;
        }
        // 0x0272D75C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_66:
        // 0x0272D764: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x0272D768: LDR x8, [x8, #0xb10]       | X8 = (string**)(1152921509930260864)("[0x00000]");
        // 0x0272D76C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D770: LDR x1, [x8]               | X1 = "[0x00000]";                       
        // 0x0272D774: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D778: MOV x0, x27                | X0 = val_36;//m1                        
        // 0x0272D77C: MOV x2, x26                | X2 = System.String.Empty;//m1           
        // 0x0272D780: BL #0x18ae7e4              | X0 = val_36.Replace(oldValue:  "[0x00000]", newValue:  System.String.Empty);
        string val_37 = val_36.Replace(oldValue:  "[0x00000]", newValue:  System.String.Empty);
        // 0x0272D784: MOV x27, x0                | X27 = val_37;//m1                       
        val_67 = val_37;
        // 0x0272D788: CBNZ x27, #0x272d794       | if (val_37 != null) goto label_67;      
        if(val_67 != null)
        {
            goto label_67;
        }
        // 0x0272D78C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_67:
        // 0x0272D794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D798: MOV x0, x27                | X0 = val_37;//m1                        
        // 0x0272D79C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D7A0: BL #0x18a946c              | X0 = val_37.Trim();                     
        string val_38 = val_67.Trim();
        // 0x0272D7A4: MOV x3, x0                 | X3 = val_38;//m1                        
        // 0x0272D7A8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x0272D7AC: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921509930269152)("{0}\n{1}");
        // 0x0272D7B0: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D7B4: LDR x1, [x8]               | X1 = "{0}\n{1}";                        
        // 0x0272D7B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272D7BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272D7C0: MOV x2, x20                | X2 = uncaught;//m1                      
        // 0x0272D7C4: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "{0}\n{1}", arg1:  val_59);
        string val_39 = System.String.Format(format:  0, arg0:  "{0}\n{1}", arg1:  val_59);
        // 0x0272D7C8: MOV x20, x0                | X20 = val_39;//m1                       
        val_59 = val_39;
        // 0x0272D7CC: B #0x272d7ec               |  goto label_68;                         
        goto label_68;
        label_44:
        // 0x0272D7D0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_65 = 0;
        // 0x0272D7D4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        val_64 = 0;
        // 0x0272D7D8: B #0x272d9ac               |  goto label_85;                         
        goto label_85;
        label_39:
        // 0x0272D7DC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_65 = 0;
        // 0x0272D7E0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        val_64 = 0;
        // 0x0272D7E4: B #0x272d9b4               |  goto label_70;                         
        goto label_70;
        label_59:
        // 0x0272D7E8: LDR x23, [sp]              | X23 = val_26;                           
        val_65 = val_26;
        label_68:
        // 0x0272D7EC: CBNZ x25, #0x272d7f8       | if (val_30 != null) goto label_71;      
        if(val_66 != null)
        {
            goto label_71;
        }
        // 0x0272D7F0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        // 0x0272D7F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_71:
        // 0x0272D7F8: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
        // 0x0272D7FC: LDR x8, [x8, #0xdc0]       | X8 = (string**)(1152921509930273344)("LuaScriptException");
        // 0x0272D800: LDR x1, [x8]               | X1 = "LuaScriptException";              
        // 0x0272D804: MOV x0, x25                | X0 = val_30;//m1                        
        // 0x0272D808: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D80C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D810: BL #0x18a8334              | X0 = val_30.Equals(value:  "LuaScriptException");
        bool val_40 = val_66.Equals(value:  "LuaScriptException");
        // 0x0272D814: TBZ w0, #0, #0x272d9a8     | if (val_40 == false) goto label_78;     
        if(val_40 == false)
        {
            goto label_78;
        }
        // 0x0272D818: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D81C: CBNZ x8, #0x272d828        | if (val_26 != 0) goto label_73;         
        if(val_26 != 0)
        {
            goto label_73;
        }
        // 0x0272D820: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_73:
        // 0x0272D828: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x0272D82C: LDR x8, [x8, #0x588]       | X8 = (string**)(1152921509930273456)(".lua");
        // 0x0272D830: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D834: LDR x1, [x8]               | X1 = ".lua";                            
        // 0x0272D838: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D83C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D840: BL #0x18ad42c              | X0 = val_26.Contains(value:  ".lua");   
        bool val_41 = val_26.Contains(value:  ".lua");
        // 0x0272D844: TBZ w0, #0, #0x272d9a8     | if (val_41 == false) goto label_78;     
        if(val_41 == false)
        {
            goto label_78;
        }
        // 0x0272D848: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D84C: CBNZ x8, #0x272d858        | if (val_26 != 0) goto label_75;         
        if(val_26 != 0)
        {
            goto label_75;
        }
        // 0x0272D850: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        label_75:
        // 0x0272D858: ADRP x26, #0x3650000       | X26 = 56950784 (0x3650000);             
        // 0x0272D85C: LDR x26, [x26, #0x630]     | X26 = (string**)(1152921509930273536)("stack traceback:");
        // 0x0272D860: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D864: LDR x1, [x26]              | X1 = "stack traceback:";                
        // 0x0272D868: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D86C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D870: BL #0x18ad42c              | X0 = val_26.Contains(value:  "stack traceback:");
        bool val_42 = val_26.Contains(value:  "stack traceback:");
        // 0x0272D874: TBZ w0, #0, #0x272d9a8     | if (val_42 == false) goto label_78;     
        if(val_42 == false)
        {
            goto label_78;
        }
        // 0x0272D878: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D87C: CBNZ x8, #0x272d888        | if (val_26 != 0) goto label_77;         
        if(val_26 != 0)
        {
            goto label_77;
        }
        // 0x0272D880: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_77:
        // 0x0272D888: LDR x1, [x26]              | X1 = "stack traceback:";                
        // 0x0272D88C: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D890: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D898: BL #0x18a590c              | X0 = val_26.IndexOf(value:  "stack traceback:");
        int val_43 = val_26.IndexOf(value:  "stack traceback:");
        // 0x0272D89C: MOV w27, w0                | W27 = val_43;//m1                       
        val_67 = val_43;
        // 0x0272D8A0: CMP w27, #1                | STATE = COMPARE(val_43, 0x1)            
        // 0x0272D8A4: B.LT #0x272d9a8            | if (val_67 < 1) goto label_78;          
        if(val_67 < 1)
        {
            goto label_78;
        }
        // 0x0272D8A8: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D8AC: CBNZ x8, #0x272d8b8        | if (val_26 != 0) goto label_79;         
        if(val_26 != 0)
        {
            goto label_79;
        }
        // 0x0272D8B0: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D8B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_79:
        // 0x0272D8B8: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D8BC: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D8C0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x0272D8C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D8C8: MOV w2, w27                | W2 = val_43;//m1                        
        // 0x0272D8CC: BL #0x18a920c              | X0 = val_26.Substring(startIndex:  0, length:  val_67);
        string val_44 = val_26.Substring(startIndex:  0, length:  val_67);
        // 0x0272D8D0: LDR x8, [sp]               | X8 = val_26;                            
        // 0x0272D8D4: MOV x23, x0                | X23 = val_44;//m1                       
        val_65 = val_44;
        // 0x0272D8D8: CBNZ x8, #0x272d8e4        | if (val_26 != 0) goto label_80;         
        if(val_26 != 0)
        {
            goto label_80;
        }
        // 0x0272D8DC: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_80:
        // 0x0272D8E4: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D8E8: ADD w1, w27, #0x10         | W1 = (val_43 + 16);                     
        int val_45 = val_67 + 16;
        // 0x0272D8EC: LDR x0, [sp]               | X0 = val_26;                            
        // 0x0272D8F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D8F4: BL #0x18a5a40              | X0 = val_26.Substring(startIndex:  int val_45 = val_67 + 16);
        string val_46 = val_26.Substring(startIndex:  val_45);
        // 0x0272D8F8: MOV x26, x0                | X26 = val_46;//m1                       
        // 0x0272D8FC: CBNZ x26, #0x272d908       | if (val_46 != null) goto label_81;      
        if(val_46 != null)
        {
            goto label_81;
        }
        // 0x0272D900: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D904: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
        label_81:
        // 0x0272D908: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x0272D90C: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509930281840)(" [");
        // 0x0272D910: ADRP x9, #0x3621000        | X9 = 56758272 (0x3621000);              
        // 0x0272D914: LDR x9, [x9, #0x400]       | X9 = (string**)(1152921509930281920)(" \n[");
        // 0x0272D918: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D91C: LDR x1, [x8]               | X1 = " [";                              
        // 0x0272D920: LDR x2, [x9]               | X2 = " \n[";                            
        // 0x0272D924: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272D928: MOV x0, x26                | X0 = val_46;//m1                        
        // 0x0272D92C: BL #0x18ae7e4              | X0 = val_46.Replace(oldValue:  " [", newValue:  " \n[");
        string val_47 = val_46.Replace(oldValue:  " [", newValue:  " \n[");
        // 0x0272D930: MOV x26, x0                | X26 = val_47;//m1                       
        // 0x0272D934: CBNZ x26, #0x272d940       | if (val_47 != null) goto label_82;      
        if(val_47 != null)
        {
            goto label_82;
        }
        // 0x0272D938: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D93C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_82:
        // 0x0272D940: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272D944: MOV x0, x26                | X0 = val_47;//m1                        
        // 0x0272D948: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D94C: BL #0x18a946c              | X0 = val_47.Trim();                     
        string val_48 = val_47.Trim();
        // 0x0272D950: MOV x26, x0                | X26 = val_48;//m1                       
        // 0x0272D954: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x0272D958: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x0272D95C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x0272D960: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272D964: TBZ w8, #0, #0x272d978     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_84;
        // 0x0272D968: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272D96C: CBNZ w8, #0x272d978        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_84;
        // 0x0272D970: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D974: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_84:
        // 0x0272D978: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x0272D97C: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921509930269152)("{0}\n{1}");
        // 0x0272D980: MOV x24, x25               | X24 = val_30;//m1                       
        // 0x0272D984: LDR x1, [x8]               | X1 = "{0}\n{1}";                        
        // 0x0272D988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272D98C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272D990: MOV x2, x20                | X2 = uncaught;//m1                      
        // 0x0272D994: MOV x3, x26                | X3 = val_48;//m1                        
        // 0x0272D998: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "{0}\n{1}", arg1:  val_59);
        string val_49 = System.String.Format(format:  0, arg0:  "{0}\n{1}", arg1:  val_59);
        // 0x0272D99C: MOV x24, x25               | X24 = val_30;//m1                       
        val_64 = val_66;
        // 0x0272D9A0: MOV x20, x0                | X20 = val_49;//m1                       
        val_59 = val_49;
        // 0x0272D9A4: B #0x272d9ac               |  goto label_85;                         
        goto label_85;
        label_78:
        // 0x0272D9A8: MOV x24, x25               | X24 = val_30;//m1                       
        val_64 = val_66;
        label_85:
        // 0x0272D9AC: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x0272D9B0: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        val_63 = 1152921504608284672;
        label_70:
        // 0x0272D9B4: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x0272D9B8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272D9BC: TBZ w8, #0, #0x272d9cc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_87;
        // 0x0272D9C0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272D9C4: CBNZ w8, #0x272d9cc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_87;
        // 0x0272D9C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_87:
        // 0x0272D9CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272D9D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272D9D4: MOV x1, x23                | X1 = val_26;//m1                        
        // 0x0272D9D8: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_50 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272D9DC: TST w0, #1                 | STATE = COMPARE(val_50, 0x1)            
        // 0x0272D9E0: CSEL x23, x22, x23, ne     | X23 = val_50 != true ? stackTrace : val_26;
        string val_51 = (val_50 != true) ? (stackTrace) : (val_65);
        label_23:
        // 0x0272D9E4: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x0272D9E8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272D9EC: TBZ w8, #0, #0x272d9fc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_89;
        // 0x0272D9F0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272D9F4: CBNZ w8, #0x272d9fc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_89;
        // 0x0272D9F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_89:
        // 0x0272D9FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272DA00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272DA04: MOV x1, x21                | X1 = message;//m1                       
        // 0x0272DA08: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_52 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272DA0C: TBZ w0, #0, #0x272dac4     | if (val_52 == false) goto label_93;     
        if(val_52 == false)
        {
            goto label_93;
        }
        // 0x0272DA10: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x0272DA14: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272DA18: TBZ w8, #0, #0x272da28     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_92;
        // 0x0272DA1C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272DA20: CBNZ w8, #0x272da28        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_92;
        // 0x0272DA24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_92:
        // 0x0272DA28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272DA2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272DA30: MOV x1, x24                | X1 = val_30;//m1                        
        // 0x0272DA34: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_53 = System.String.IsNullOrEmpty(value:  0);
        // 0x0272DA38: MOV x21, x24               | X21 = val_30;//m1                       
        val_60 = val_64;
        // 0x0272DA3C: TBZ w0, #0, #0x272dac4     | if (val_53 == false) goto label_93;     
        if(val_53 == false)
        {
            goto label_93;
        }
        // 0x0272DA40: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x0272DA44: LDR x8, [x8, #0x6d0]       | X8 = 1152921504776708096;               
        // 0x0272DA48: ADD x1, sp, #0xc           | X1 = (1152921509930318560 + 12) = 1152921509930318572 (0x100000013D4DBAEC);
        // 0x0272DA4C: LDR x0, [x8]               | X0 = typeof(LogSeverity);               
        // 0x0272DA50: BL #0x27bc028              | X0 = 1152921509930497840 = (Il2CppObject*)Box((RuntimeClass*)typeof(LogSeverity), typeof(LogSeverity));
        // 0x0272DA54: MOV x22, x0                | X22 = 1152921509930497840 (0x100000013D507730);//ML01
        // 0x0272DA58: CBNZ x22, #0x272da60       | if (typeof(LogSeverity) != 0) goto label_94;
        if(null != 0)
        {
            goto label_94;
        }
        // 0x0272DA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(LogSeverity), ????);
        label_94:
        // 0x0272DA60: LDR x8, [x22]              | X8 = typeof(LogSeverity);               
        // 0x0272DA64: MOV x0, x22                | X0 = 1152921509930497840 (0x100000013D507730);//ML01
        // 0x0272DA68: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x0272DA6C: BLR x9                     | X0 = typeof(LogSeverity).ToString();    
        string val_54 = null.ToString();
        // 0x0272DA70: MOV x21, x0                | X21 = val_54;//m1                       
        // 0x0272DA74: CBNZ x22, #0x272da7c       | if (typeof(LogSeverity) != 0) goto label_95;
        if(null != 0)
        {
            goto label_95;
        }
        // 0x0272DA78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        label_95:
        // 0x0272DA7C: MOV x0, x22                | X0 = 1152921509930497840 (0x100000013D507730);//ML01
        // 0x0272DA80: BL #0x27bc4e8              | typeof(LogSeverity).System.IDisposable.Dispose();
        null.System.IDisposable.Dispose();
        // 0x0272DA84: LDR w8, [x0]               | W8 = typeof(LogSeverity);               
        // 0x0272DA88: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x0272DA8C: STR w8, [sp, #0xc]         | stack[1152921509930318572] = typeof(LogSeverity);  //  dest_result_addr=1152921509930318572
        // 0x0272DA90: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x0272DA94: TBZ w8, #0, #0x272daa4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_97;
        // 0x0272DA98: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0272DA9C: CBNZ w8, #0x272daa4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_97;
        // 0x0272DAA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_97:
        // 0x0272DAA4: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x0272DAA8: LDR x8, [x8, #0xa38]       | X8 = (string**)(1152921509930302480)("Unity{0}");
        // 0x0272DAAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272DAB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272DAB4: MOV x2, x21                | X2 = val_54;//m1                        
        // 0x0272DAB8: LDR x1, [x8]               | X1 = "Unity{0}";                        
        // 0x0272DABC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "Unity{0}");
        string val_55 = System.String.Format(format:  0, arg0:  "Unity{0}");
        // 0x0272DAC0: MOV x21, x0                | X21 = val_55;//m1                       
        val_60 = val_55;
        label_93:
        // 0x0272DAC4: LDR x0, [x28]              | X0 = typeof(BuglyAgent);                
        // 0x0272DAC8: LDRB w8, [x0, #0x10a]      | W8 = BuglyAgent.__il2cppRuntimeField_10A;
        // 0x0272DACC: TBZ w8, #0, #0x272dadc     | if (BuglyAgent.__il2cppRuntimeField_has_cctor == 0) goto label_99;
        // 0x0272DAD0: LDR w8, [x0, #0xbc]        | W8 = BuglyAgent.__il2cppRuntimeField_cctor_finished;
        // 0x0272DAD4: CBNZ w8, #0x272dadc        | if (BuglyAgent.__il2cppRuntimeField_cctor_finished != 0) goto label_99;
        // 0x0272DAD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BuglyAgent), ????);
        label_99:
        // 0x0272DADC: AND w1, w19, #1            | W1 = (W5 & 1);                          
        string val_56 = val_58 & 1;
        // 0x0272DAE0: MOV x2, x21                | X2 = val_55;//m1                        
        // 0x0272DAE4: MOV x3, x23                | X3 = val_50 != true ? stackTrace : val_26;//m1
        // 0x0272DAE8: MOV x4, x20                | X4 = uncaught;//m1                      
        // 0x0272DAEC: BL #0x2730434              | BuglyAgent._reportException(uncaught:  false, name:  string val_56 = val_58 & 1, reason:  val_60, stackTrace:  val_51);
        BuglyAgent._reportException(uncaught:  false, name:  val_56, reason:  val_60, stackTrace:  val_51);
        label_17:
        // 0x0272DAF0: SUB sp, x29, #0x50         | SP = (1152921509930318656 - 80) = 1152921509930318576 (0x100000013D4DBAF0);
        // 0x0272DAF4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x0272DAF8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x0272DAFC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x0272DB00: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x0272DB04: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x0272DB08: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x0272DB0C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02730C78 (41094264), len: 328  VirtAddr: 0x02730C78 RVA: 0x02730C78 token: 100663341 methodIndex: 24309 delegateWrapperIndex: 0 methodInvoker: 0
    private static BuglyAgent()
    {
        //
        // Disasemble & Code
        // 0x02730C78: STP x20, x19, [sp, #-0x20]! | stack[1152921509930578432] = ???;  stack[1152921509930578440] = ???;  //  dest_result_addr=1152921509930578432 |  dest_result_addr=1152921509930578440
        // 0x02730C7C: STP x29, x30, [sp, #0x10]  | stack[1152921509930578448] = ???;  stack[1152921509930578456] = ???;  //  dest_result_addr=1152921509930578448 |  dest_result_addr=1152921509930578456
        // 0x02730C80: ADD x29, sp, #0x10         | X29 = (1152921509930578432 + 16) = 1152921509930578448 (0x100000013D51B210);
        // 0x02730C84: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x02730C88: LDRB w8, [x19, #0xac3]     | W8 = (bool)static_value_03743AC3;       
        // 0x02730C8C: TBNZ w8, #0, #0x2730ca8    | if (static_value_03743AC3 == true) goto label_0;
        // 0x02730C90: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x02730C94: LDR x8, [x8, #0x828]       | X8 = 0x2B8FDD8;                         
        // 0x02730C98: LDR w0, [x8]               | W0 = 0x163A;                            
        // 0x02730C9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x163A, ????);     
        // 0x02730CA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02730CA4: STRB w8, [x19, #0xac3]     | static_value_03743AC3 = true;            //  dest_result_addr=57948867
        label_0:
        // 0x02730CA8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x02730CAC: LDR x8, [x8, #0x938]       | X8 = 1152921504776761344;               
        // 0x02730CB0: ADRP x10, #0x3640000       | X10 = 56885248 (0x3640000);             
        // 0x02730CB4: MOVZ w11, #0x5             | W11 = 5 (0x5);//ML01                    
        // 0x02730CB8: ADRP x12, #0x3652000       | X12 = 56958976 (0x3652000);             
        // 0x02730CBC: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730CC0: LDR x10, [x10, #0xc60]     | X10 = (string**)(1152921509930566128)("com.tencent.bugly.agent.GameAgent");
        // 0x02730CC4: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730CC8: LDR x10, [x10]             | X10 = "com.tencent.bugly.agent.GameAgent";
        // 0x02730CCC: STR x10, [x9]              | BuglyAgent.GAME_AGENT_CLASS = "com.tencent.bugly.agent.GameAgent";  //  dest_result_addr=1152921504776765440
        BuglyAgent.GAME_AGENT_CLASS = "com.tencent.bugly.agent.GameAgent";
        // 0x02730CD0: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730CD4: ORR w10, wzr, #4           | W10 = 4(0x4);                           
        // 0x02730CD8: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730CDC: STR w10, [x9, #8]          | BuglyAgent.TYPE_U3D_CRASH = 4;           //  dest_result_addr=1152921504776765448
        BuglyAgent.TYPE_U3D_CRASH = 4;
        // 0x02730CE0: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730CE4: ORR w10, wzr, #2           | W10 = 2(0x2);                           
        // 0x02730CE8: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730CEC: STR w10, [x9, #0xc]        | BuglyAgent.GAME_TYPE_UNITY = 2;          //  dest_result_addr=1152921504776765452
        BuglyAgent.GAME_TYPE_UNITY = 2;
        // 0x02730CF0: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730CF4: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730CF8: STR w11, [x9, #0x54]       | BuglyAgent._autoReportLogLevel = 0x5;    //  dest_result_addr=1152921504776765524
        BuglyAgent._autoReportLogLevel = 5;
        // 0x02730CFC: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730D00: ORR w11, wzr, #1           | W11 = 1(0x1);                           
        // 0x02730D04: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730D08: STR w11, [x9, #0x58]       | BuglyAgent._crashReporterType = 1;       //  dest_result_addr=1152921504776765528
        BuglyAgent._crashReporterType = 1;
        // 0x02730D0C: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730D10: LDR x12, [x12, #0x760]     | X12 = (string**)(1152921509930566272)("com.tencent.bugly");
        // 0x02730D14: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730D18: LDR x12, [x12]             | X12 = "com.tencent.bugly";              
        // 0x02730D1C: STR x12, [x9, #0x60]       | BuglyAgent._crashReporterPackage = "com.tencent.bugly";  //  dest_result_addr=1152921504776765536
        BuglyAgent._crashReporterPackage = "com.tencent.bugly";
        // 0x02730D20: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730D24: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730D28: STR w11, [x9, #0x6c]       | BuglyAgent.EXCEPTION_TYPE_UNCAUGHT = 1;  //  dest_result_addr=1152921504776765548
        BuglyAgent.EXCEPTION_TYPE_UNCAUGHT = 1;
        // 0x02730D2C: LDR x9, [x8]               | X9 = typeof(BuglyAgent);                
        // 0x02730D30: LDR x9, [x9, #0xa0]        | X9 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730D34: STR w10, [x9, #0x70]       | BuglyAgent.EXCEPTION_TYPE_CAUGHT = 2;    //  dest_result_addr=1152921504776765552
        BuglyAgent.EXCEPTION_TYPE_CAUGHT = 2;
        // 0x02730D38: ADRP x9, #0x3618000        | X9 = 56721408 (0x3618000);              
        // 0x02730D3C: LDR x8, [x8]               | X8 = typeof(BuglyAgent);                
        // 0x02730D40: LDR x9, [x9, #0x7d8]       | X9 = (string**)(1152921509930566384)("1.5.1");
        // 0x02730D44: LDR x8, [x8, #0xa0]        | X8 = BuglyAgent.__il2cppRuntimeField_static_fields;
        // 0x02730D48: LDR x9, [x9]               | X9 = "1.5.1";                           
        // 0x02730D4C: STR x9, [x8, #0x78]        | BuglyAgent._pluginVersion = "1.5.1";     //  dest_result_addr=1152921504776765560
        BuglyAgent._pluginVersion = "1.5.1";
        // 0x02730D50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02730D54: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02730D58: RET                        |  return;                                
        return;
    
    }

}
