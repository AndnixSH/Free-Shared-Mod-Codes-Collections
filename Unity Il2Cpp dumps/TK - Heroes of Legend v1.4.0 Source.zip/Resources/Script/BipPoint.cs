using UnityEngine;
public class BipPoint : MonoBehaviour
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B90938 (12126520), len: 8  VirtAddr: 0x00B90938 RVA: 0x00B90938 token: 100690106 methodIndex: 25144 delegateWrapperIndex: 0 methodInvoker: 0
    public BipPoint()
    {
        //
        // Disasemble & Code
        // 0x00B90938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9093C: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90940 (12126528), len: 52  VirtAddr: 0x00B90940 RVA: 0x00B90940 token: 100690107 methodIndex: 25145 delegateWrapperIndex: 0 methodInvoker: 0
    public bool IsShow()
    {
        //
        // Disasemble & Code
        // 0x00B90940: STP x20, x19, [sp, #-0x20]! | stack[1152921514473607072] = ???;  stack[1152921514473607080] = ???;  //  dest_result_addr=1152921514473607072 |  dest_result_addr=1152921514473607080
        // 0x00B90944: STP x29, x30, [sp, #0x10]  | stack[1152921514473607088] = ???;  stack[1152921514473607096] = ???;  //  dest_result_addr=1152921514473607088 |  dest_result_addr=1152921514473607096
        // 0x00B90948: ADD x29, sp, #0x10         | X29 = (1152921514473607072 + 16) = 1152921514473607088 (0x100000024C1ACFB0);
        // 0x00B9094C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90950: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B90954: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B90958: CBNZ x19, #0xb90960        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B9095C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B90960: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90964: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90968: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B9096C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B90970: B #0x1a62ddc               | return val_1.get_activeSelf();          
        return val_1.activeSelf;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90974 (12126580), len: 60  VirtAddr: 0x00B90974 RVA: 0x00B90974 token: 100690108 methodIndex: 25146 delegateWrapperIndex: 0 methodInvoker: 0
    public void Show(bool isShow)
    {
        //
        // Disasemble & Code
        // 0x00B90974: STP x20, x19, [sp, #-0x20]! | stack[1152921514473727264] = ???;  stack[1152921514473727272] = ???;  //  dest_result_addr=1152921514473727264 |  dest_result_addr=1152921514473727272
        // 0x00B90978: STP x29, x30, [sp, #0x10]  | stack[1152921514473727280] = ???;  stack[1152921514473727288] = ???;  //  dest_result_addr=1152921514473727280 |  dest_result_addr=1152921514473727288
        // 0x00B9097C: ADD x29, sp, #0x10         | X29 = (1152921514473727264 + 16) = 1152921514473727280 (0x100000024C1CA530);
        // 0x00B90980: MOV w19, w1                | W19 = isShow;//m1                       
        // 0x00B90984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90988: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B9098C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B90990: CBNZ x20, #0xb90998        | if (val_1 != null) goto label_0;        
        if(val_1 != null)
        {
            goto label_0;
        }
        // 0x00B90994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_0:
        // 0x00B90998: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9099C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B909A0: AND w1, w19, #1            | W1 = (isShow & 1);                      
        bool val_2 = isShow;
        // 0x00B909A4: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B909A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B909AC: B #0x1a62d64               | val_1.SetActive(value:  bool val_2 = isShow); return;
        val_1.SetActive(value:  val_2);
        return;
    
    }

}
