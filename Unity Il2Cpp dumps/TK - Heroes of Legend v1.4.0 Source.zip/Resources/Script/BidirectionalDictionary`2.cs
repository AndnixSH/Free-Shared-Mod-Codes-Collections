using UnityEngine;

namespace Newtonsoft.Json.Utilities
{
    internal class BidirectionalDictionary<TFirst, TSecond>
    {
        // Fields
        private readonly System.Collections.Generic.IDictionary<TFirst, TSecond> _firstToSecond; //  0x00000010
        private readonly System.Collections.Generic.IDictionary<TSecond, TFirst> _secondToFirst; //  0x00000010
        
        // Methods
        // Generic instance method:
        //
        // file offset: 0x019E824C VirtAddr: 0x019E824C -RVA: 0x019E824C 
        // -BidirectionalDictionary<object, object>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x019E824C (27165260), len: 300  VirtAddr: 0x019E824C RVA: 0x019E824C token: 100686540 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public BidirectionalDictionary<TFirst, TSecond>()
        {
            //
            // Disasemble & Code
            // 0x019E824C: STP x22, x21, [sp, #-0x30]! | stack[1152921513961052464] = ???;  stack[1152921513961052472] = ???;  //  dest_result_addr=1152921513961052464 |  dest_result_addr=1152921513961052472
            // 0x019E8250: STP x20, x19, [sp, #0x10]  | stack[1152921513961052480] = ???;  stack[1152921513961052488] = ???;  //  dest_result_addr=1152921513961052480 |  dest_result_addr=1152921513961052488
            // 0x019E8254: STP x29, x30, [sp, #0x20]  | stack[1152921513961052496] = ???;  stack[1152921513961052504] = ???;  //  dest_result_addr=1152921513961052496 |  dest_result_addr=1152921513961052504
            // 0x019E8258: ADD x29, sp, #0x20         | X29 = (1152921513961052464 + 32) = 1152921513961052496 (0x100000022D8DD950);
            // 0x019E825C: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E8260: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8264: MOV x20, x0                | X20 = 1152921513961064512 (0x100000022D8E0840);//ML01
            // 0x019E8268: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E826C: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E8270: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E8274: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E8278: LDRB w8, [x21, #0x10a]     | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 8 + 266;
            // 0x019E827C: TBZ w8, #0, #0x19e82b8     | if ((__RuntimeMethodHiddenParam + 24 + 168 + 8 + 266 & 0x1) == 0) goto label_1;
            if(((__RuntimeMethodHiddenParam + 24 + 168 + 8 + 266) & 1) == 0)
            {
                goto label_1;
            }
            // 0x019E8280: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8284: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8288: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E828C: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E8290: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E8294: LDR w8, [x21, #0xbc]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 8 + 188;
            // 0x019E8298: CBNZ w8, #0x19e82b8        | if (__RuntimeMethodHiddenParam + 24 + 168 + 8 + 188 != 0) goto label_1;
            if((__RuntimeMethodHiddenParam + 24 + 168 + 8 + 188) != 0)
            {
                goto label_1;
            }
            // 0x019E829C: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E82A0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E82A4: LDR x21, [x8, #8]          | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
            // 0x019E82A8: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E82AC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            // 0x019E82B0: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8;//m1
            // 0x019E82B4: BL #0x27977a4              | X0 = sub_27977A4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 8, ????);
            label_1:
            // 0x019E82B8: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E82BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E82C0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E82C4: LDR x1, [x8]               | X1 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E82C8: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E82CC: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168();
            // 0x019E82D0: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E82D4: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            // 0x019E82D8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E82DC: LDR x22, [x8, #0x18]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x019E82E0: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x019E82E4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x019E82E8: LDRB w8, [x22, #0x10a]     | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 24 + 266;
            // 0x019E82EC: TBZ w8, #0, #0x19e8328     | if ((__RuntimeMethodHiddenParam + 24 + 168 + 24 + 266 & 0x1) == 0) goto label_3;
            if(((__RuntimeMethodHiddenParam + 24 + 168 + 24 + 266) & 1) == 0)
            {
                goto label_3;
            }
            // 0x019E82F0: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E82F4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E82F8: LDR x22, [x8, #0x18]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x019E82FC: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x019E8300: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x019E8304: LDR w8, [x22, #0xbc]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 24 + 188;
            // 0x019E8308: CBNZ w8, #0x19e8328        | if (__RuntimeMethodHiddenParam + 24 + 168 + 24 + 188 != 0) goto label_3;
            if((__RuntimeMethodHiddenParam + 24 + 168 + 24 + 188) != 0)
            {
                goto label_3;
            }
            // 0x019E830C: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8310: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8314: LDR x22, [x8, #0x18]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x019E8318: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x019E831C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x019E8320: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x019E8324: BL #0x27977a4              | X0 = sub_27977A4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            label_3:
            // 0x019E8328: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E832C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x019E8330: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8334: LDR x1, [x8, #0x10]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x019E8338: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x019E833C: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16();
            // 0x019E8340: MOV x22, x0                | X22 = 0 (0x0);//ML01                    
            // 0x019E8344: CBNZ x20, #0x19e834c       | if (this != null) goto label_4;         
            if(this != null)
            {
                goto label_4;
            }
            // 0x019E8348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_4:
            // 0x019E834C: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8350: MOV x0, x20                | X0 = 1152921513961064512 (0x100000022D8E0840);//ML01
            // 0x019E8354: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x019E8358: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x019E835C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8360: LDR x3, [x8, #0x20]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E8364: LDR x4, [x3]               | X4 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x019E8368: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E836C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8370: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E8374: BR x4                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 32;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 32;
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8378 VirtAddr: 0x019E8378 -RVA: 0x019E8378 
        // -BidirectionalDictionary<object, object>..ctor
        // -BidirectionalDictionary<string, string>..ctor
        // -BidirectionalDictionary<string, object>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x019E8378 (27165560), len: 196  VirtAddr: 0x019E8378 RVA: 0x019E8378 token: 100686541 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public BidirectionalDictionary<TFirst, TSecond>(System.Collections.Generic.IEqualityComparer<TFirst> firstEqualityComparer, System.Collections.Generic.IEqualityComparer<TSecond> secondEqualityComparer)
        {
            //
            // Disasemble & Code
            // 0x019E8378: STP x24, x23, [sp, #-0x40]! | stack[1152921513961172640] = ???;  stack[1152921513961172648] = ???;  //  dest_result_addr=1152921513961172640 |  dest_result_addr=1152921513961172648
            // 0x019E837C: STP x22, x21, [sp, #0x10]  | stack[1152921513961172656] = ???;  stack[1152921513961172664] = ???;  //  dest_result_addr=1152921513961172656 |  dest_result_addr=1152921513961172664
            // 0x019E8380: STP x20, x19, [sp, #0x20]  | stack[1152921513961172672] = ???;  stack[1152921513961172680] = ???;  //  dest_result_addr=1152921513961172672 |  dest_result_addr=1152921513961172680
            // 0x019E8384: STP x29, x30, [sp, #0x30]  | stack[1152921513961172688] = ???;  stack[1152921513961172696] = ???;  //  dest_result_addr=1152921513961172688 |  dest_result_addr=1152921513961172696
            // 0x019E8388: ADD x29, sp, #0x30         | X29 = (1152921513961172640 + 48) = 1152921513961172688 (0x100000022D8FAED0);
            // 0x019E838C: MOV x21, x3                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E8390: MOV x20, x2                | X20 = secondEqualityComparer;//m1       
            // 0x019E8394: MOV x22, x1                | X22 = firstEqualityComparer;//m1        
            // 0x019E8398: MOV x19, x0                | X19 = 1152921513961184704 (0x100000022D8FDDC0);//ML01
            // 0x019E839C: CBNZ x19, #0x19e83a4       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x019E83A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x019E83A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019E83A8: MOV x0, x19                | X0 = 1152921513961184704 (0x100000022D8FDDC0);//ML01
            // 0x019E83AC: BL #0x16f59f0              | this..ctor();                           
            // 0x019E83B0: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E83B4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E83B8: LDR x23, [x8, #0x28]       | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 40;
            // 0x019E83BC: MOV x0, x23                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 40;//m1
            // 0x019E83C0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 40, ????);
            // 0x019E83C4: MOV x0, x23                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 40;//m1
            // 0x019E83C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? __RuntimeMethodHiddenParam + 24 + 168 + 40, ????);
            // 0x019E83CC: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E83D0: MOV x1, x22                | X1 = firstEqualityComparer;//m1         
            // 0x019E83D4: MOV x23, x0                | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 40;//m1
            // 0x019E83D8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E83DC: LDR x2, [x8, #0x30]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            // 0x019E83E0: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            // 0x019E83E4: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48();
            // 0x019E83E8: STR x23, [x19, #0x10]      | mem[1152921513961184720] = __RuntimeMethodHiddenParam + 24 + 168 + 40;  //  dest_result_addr=1152921513961184720
            mem[1152921513961184720] = __RuntimeMethodHiddenParam + 24 + 168 + 40;
            // 0x019E83EC: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E83F0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E83F4: LDR x22, [x8, #0x38]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 56;
            // 0x019E83F8: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x019E83FC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x019E8400: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x019E8404: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x019E8408: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E840C: MOV x1, x20                | X1 = secondEqualityComparer;//m1        
            // 0x019E8410: MOV x21, x0                | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x019E8414: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8418: LDR x2, [x8, #0x40]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E841C: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x019E8420: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64();
            // 0x019E8424: STR x21, [x19, #0x18]      | mem[1152921513961184728] = __RuntimeMethodHiddenParam + 24 + 168 + 56;  //  dest_result_addr=1152921513961184728
            mem[1152921513961184728] = __RuntimeMethodHiddenParam + 24 + 168 + 56;
            // 0x019E8428: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019E842C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019E8430: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019E8434: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019E8438: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E843C VirtAddr: 0x019E843C -RVA: 0x019E843C 
        // -BidirectionalDictionary<object, object>.Add
        // -BidirectionalDictionary<string, string>.Add
        // -BidirectionalDictionary<string, object>.Add
        //
        //
        // Offset in libil2cpp.so: 0x019E843C (27165756), len: 708  VirtAddr: 0x019E843C RVA: 0x019E843C token: 100686542 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void Add(TFirst first, TSecond second)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x019E843C: STP x24, x23, [sp, #-0x40]! | stack[1152921513961302176] = ???;  stack[1152921513961302184] = ???;  //  dest_result_addr=1152921513961302176 |  dest_result_addr=1152921513961302184
            // 0x019E8440: STP x22, x21, [sp, #0x10]  | stack[1152921513961302192] = ???;  stack[1152921513961302200] = ???;  //  dest_result_addr=1152921513961302192 |  dest_result_addr=1152921513961302200
            // 0x019E8444: STP x20, x19, [sp, #0x20]  | stack[1152921513961302208] = ???;  stack[1152921513961302216] = ???;  //  dest_result_addr=1152921513961302208 |  dest_result_addr=1152921513961302216
            // 0x019E8448: STP x29, x30, [sp, #0x30]  | stack[1152921513961302224] = ???;  stack[1152921513961302232] = ???;  //  dest_result_addr=1152921513961302224 |  dest_result_addr=1152921513961302232
            // 0x019E844C: ADD x29, sp, #0x30         | X29 = (1152921513961302176 + 48) = 1152921513961302224 (0x100000022D91A8D0);
            // 0x019E8450: ADRP x23, #0x3739000       | X23 = 57905152 (0x3739000);             
            // 0x019E8454: LDRB w8, [x23, #0x661]     | W8 = (bool)static_value_03739661;       
            // 0x019E8458: MOV x21, x3                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E845C: MOV x19, x2                | X19 = second;//m1                       
            // 0x019E8460: MOV x20, x1                | X20 = first;//m1                        
            // 0x019E8464: MOV x22, x0                | X22 = 1152921513961314240 (0x100000022D91D7C0);//ML01
            // 0x019E8468: TBNZ w8, #0, #0x19e8484    | if (static_value_03739661 == true) goto label_0;
            // 0x019E846C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x019E8470: LDR x8, [x8, #0xd40]       | X8 = 0x2B8F3C8;                         
            // 0x019E8474: LDR w0, [x8]               | W0 = 0x13B4;                            
            // 0x019E8478: BL #0x2782188              | X0 = sub_2782188( ?? 0x13B4, ????);     
            // 0x019E847C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019E8480: STRB w8, [x23, #0x661]     | static_value_03739661 = true;            //  dest_result_addr=57906785
            label_0:
            // 0x019E8484: LDR x23, [x22, #0x10]      | 
            // 0x019E8488: CBNZ x23, #0x19e8490       | if ( != 0) goto label_1;                
            if(!=0)
            {
                goto label_1;
            }
            // 0x019E848C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13B4, ????);     
            label_1:
            // 0x019E8490: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8494: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8498: LDR x24, [x8, #0x48]       | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 72;
            // 0x019E849C: MOV x0, x24                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 72;//m1
            // 0x019E84A0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 72, ????);
            // 0x019E84A4: LDR x8, [x23]              | X8 = mem[57905152];                     
            var val_6 = mem[57905152];
            // 0x019E84A8: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E84AC: CBZ x9, #0x19e84d8         | if (mem[57905152] + 258 == 0) goto label_2;
            if((mem[57905152] + 258) == 0)
            {
                goto label_2;
            }
            // 0x019E84B0: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_3 = mem[57905152] + 152;
            // 0x019E84B4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x019E84B8: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_3 = val_3 + 8;
            label_4:
            // 0x019E84BC: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E84C0: CMP x12, x24               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 72)
            // 0x019E84C4: B.EQ #0x19e84ec            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168 + 72) goto label_3;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168 + 72))
            {
                goto label_3;
            }
            // 0x019E84C8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x019E84CC: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_3 = val_3 + 16;
            // 0x019E84D0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E84D4: B.LO #0x19e84bc            | if (0 < mem[57905152] + 258) goto label_4;
            if(val_4 < (mem[57905152] + 258))
            {
                goto label_4;
            }
            label_2:
            // 0x019E84D8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x019E84DC: MOV x0, x23                | X0 = 57905152 (0x3739000);//ML01        
            val_6 = 57905152;
            // 0x019E84E0: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 72;//m1
            // 0x019E84E4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E84E8: B #0x19e84fc               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x019E84EC: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            var val_5 = val_3;
            // 0x019E84F0: ADD w9, w9, #1             | W9 = ((mem[57905152] + 152 + 8) + 1);   
            val_5 = val_5 + 1;
            // 0x019E84F4: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 1));
            val_6 = val_6 + val_5;
            // 0x019E84F8: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
            val_6 = val_6 + 272;
            label_5:
            // 0x019E84FC: LDP x8, x2, [x0]           | X8 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272); X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272) + 8; //  | 
            val_7 = mem[((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272) + 8];
            val_7 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272) + 8;
            // 0x019E8500: MOV x0, x23                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E8504: MOV x1, x20                | X1 = first;//m1                         
            // 0x019E8508: BLR x8                     | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272)();
            // 0x019E850C: AND w8, w0, #1             | W8 = (57905152 & 1) = 0 (0x00000000);   
            // 0x019E8510: TBNZ w8, #0, #0x19e86c0    | if ((0x0 & 0x1) != 0) goto label_12;    
            if((0 & 1) != 0)
            {
                goto label_12;
            }
            // 0x019E8514: LDR x23, [x22, #0x18]      | 
            // 0x019E8518: CBNZ x23, #0x19e8520       | if ( != 0) goto label_7;                
            if(!=0)
            {
                goto label_7;
            }
            // 0x019E851C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3739000, ????);  
            label_7:
            // 0x019E8520: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8524: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8528: LDR x24, [x8, #0x50]       | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 80;
            // 0x019E852C: MOV x0, x24                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 80;//m1
            // 0x019E8530: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 80, ????);
            // 0x019E8534: LDR x8, [x23]              | X8 = mem[57905152];                     
            var val_10 = mem[57905152];
            // 0x019E8538: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E853C: CBZ x9, #0x19e8568         | if (mem[57905152] + 258 == 0) goto label_8;
            if((mem[57905152] + 258) == 0)
            {
                goto label_8;
            }
            // 0x019E8540: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_7 = mem[57905152] + 152;
            // 0x019E8544: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x019E8548: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_7 = val_7 + 8;
            label_10:
            // 0x019E854C: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E8550: CMP x12, x24               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 80)
            // 0x019E8554: B.EQ #0x19e857c            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168 + 80) goto label_9;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168 + 80))
            {
                goto label_9;
            }
            // 0x019E8558: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x019E855C: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_7 = val_7 + 16;
            // 0x019E8560: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E8564: B.LO #0x19e854c            | if (0 < mem[57905152] + 258) goto label_10;
            if(val_8 < (mem[57905152] + 258))
            {
                goto label_10;
            }
            label_8:
            // 0x019E8568: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            val_7 = 1;
            // 0x019E856C: MOV x0, x23                | X0 = 57905152 (0x3739000);//ML01        
            val_8 = 57905152;
            // 0x019E8570: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 80;//m1
            // 0x019E8574: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E8578: B #0x19e858c               |  goto label_11;                         
            goto label_11;
            label_9:
            // 0x019E857C: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            var val_9 = val_7;
            // 0x019E8580: ADD w9, w9, #1             | W9 = ((mem[57905152] + 152 + 8) + 1);   
            val_9 = val_9 + 1;
            // 0x019E8584: ADD x8, x8, w9, uxtw #4    | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8) + 1));
            val_10 = val_10 + val_9;
            // 0x019E8588: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272);
            val_8 = val_10 + 272;
            label_11:
            // 0x019E858C: LDP x8, x2, [x0]           | X8 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272); X2 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272) + 8; //  | 
            // 0x019E8590: MOV x0, x23                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E8594: MOV x1, x19                | X1 = second;//m1                        
            // 0x019E8598: BLR x8                     | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8) + 1)) + 272)();
            // 0x019E859C: TBNZ w0, #0, #0x19e86c0    | if ((0x3739000 & 0x1) != 0) goto label_12;
            if((57905152 & 1) != 0)
            {
                goto label_12;
            }
            // 0x019E85A0: LDR x23, [x22, #0x10]      | 
            // 0x019E85A4: CBNZ x23, #0x19e85ac       | if ( != 0) goto label_13;               
            if(!=0)
            {
                goto label_13;
            }
            // 0x019E85A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3739000, ????);  
            label_13:
            // 0x019E85AC: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E85B0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E85B4: LDR x24, [x8, #0x48]       | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 72;
            // 0x019E85B8: MOV x0, x24                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 72;//m1
            // 0x019E85BC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 72, ????);
            // 0x019E85C0: LDR x8, [x23]              | X8 = mem[57905152];                     
            var val_13 = mem[57905152];
            // 0x019E85C4: LDRH w9, [x8, #0x102]      | W9 = mem[57905152] + 258;               
            // 0x019E85C8: CBZ x9, #0x19e85f4         | if (mem[57905152] + 258 == 0) goto label_14;
            if((mem[57905152] + 258) == 0)
            {
                goto label_14;
            }
            // 0x019E85CC: LDR x10, [x8, #0x98]       | X10 = mem[57905152] + 152;              
            var val_11 = mem[57905152] + 152;
            // 0x019E85D0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x019E85D4: ADD x10, x10, #8           | X10 = (mem[57905152] + 152 + 8);        
            val_11 = val_11 + 8;
            label_16:
            // 0x019E85D8: LDUR x12, [x10, #-8]       | X12 = (mem[57905152] + 152 + 8) + -8;   
            // 0x019E85DC: CMP x12, x24               | STATE = COMPARE((mem[57905152] + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 72)
            // 0x019E85E0: B.EQ #0x19e8608            | if ((mem[57905152] + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168 + 72) goto label_15;
            if(((mem[57905152] + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168 + 72))
            {
                goto label_15;
            }
            // 0x019E85E4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x019E85E8: ADD x10, x10, #0x10        | X10 = ((mem[57905152] + 152 + 8) + 16); 
            val_11 = val_11 + 16;
            // 0x019E85EC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[57905152] + 258)
            // 0x019E85F0: B.LO #0x19e85d8            | if (0 < mem[57905152] + 258) goto label_16;
            if(val_12 < (mem[57905152] + 258))
            {
                goto label_16;
            }
            label_14:
            // 0x019E85F4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E85F8: MOV x0, x23                | X0 = 57905152 (0x3739000);//ML01        
            val_9 = 57905152;
            // 0x019E85FC: MOV x1, x24                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 72;//m1
            // 0x019E8600: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x3739000, ????);  
            // 0x019E8604: B #0x19e8614               |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x019E8608: LDR w9, [x10]              | W9 = (mem[57905152] + 152 + 8);         
            // 0x019E860C: ADD x8, x8, x9, lsl #4     | X8 = (mem[57905152] + ((mem[57905152] + 152 + 8)) << 4);
            val_13 = val_13 + (((mem[57905152] + 152 + 8)) << 4);
            // 0x019E8610: ADD x0, x8, #0x110         | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272);
            val_9 = val_13 + 272;
            label_17:
            // 0x019E8614: LDP x8, x3, [x0]           | X8 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272); X3 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272) + 8; //  | 
            // 0x019E8618: MOV x0, x23                | X0 = 57905152 (0x3739000);//ML01        
            // 0x019E861C: MOV x1, x20                | X1 = first;//m1                         
            // 0x019E8620: MOV x2, x19                | X2 = second;//m1                        
            // 0x019E8624: BLR x8                     | X0 = ((mem[57905152] + ((mem[57905152] + 152 + 8)) << 4) + 272)();
            // 0x019E8628: LDR x22, [x22, #0x18]      | 
            // 0x019E862C: CBNZ x22, #0x19e8634       | if (this != null) goto label_18;        
            if(this != null)
            {
                goto label_18;
            }
            // 0x019E8630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3739000, ????);  
            label_18:
            // 0x019E8634: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E8638: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E863C: LDR x21, [x8, #0x50]       | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 80;
            // 0x019E8640: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 80;//m1
            // 0x019E8644: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 80, ????);
            // 0x019E8648: LDR x8, [x22]              | X8 = typeof(Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>);
            // 0x019E864C: LDRH w9, [x8, #0x102]      | W9 = Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>.__il2cppRuntimeField_interface_offsets_count;
            // 0x019E8650: CBZ x9, #0x19e867c         | if (Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_19;
            // 0x019E8654: LDR x10, [x8, #0x98]       | X10 = Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>.__il2cppRuntimeField_interfaceOffsets;
            // 0x019E8658: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x019E865C: ADD x10, x10, #8           | X10 = (Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504866680840 (0x100000000F7CC008);
            label_21:
            // 0x019E8660: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x019E8664: CMP x12, x21               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, __RuntimeMethodHiddenParam + 24 + 168 + 80)
            // 0x019E8668: B.EQ #0x19e8690            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == __RuntimeMethodHiddenParam + 24 + 168 + 80) goto label_20;
            // 0x019E866C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x019E8670: ADD x10, x10, #0x10        | X10 = (1152921504866680840 + 16) = 1152921504866680856 (0x100000000F7CC018);
            // 0x019E8674: CMP x11, x9                | STATE = COMPARE((0 + 1), Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>.__il2cppRuntimeField_interface_offsets_count)
            // 0x019E8678: B.LO #0x19e8660            | if (0 < Newtonsoft.Json.Utilities.BidirectionalDictionary<TFirst, TSecond>.__il2cppRuntimeField_interface_offsets_count) goto label_21;
            label_19:
            // 0x019E867C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x019E8680: MOV x0, x22                | X0 = 1152921513961314240 (0x100000022D91D7C0);//ML01
            val_10 = this;
            // 0x019E8684: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 80;//m1
            // 0x019E8688: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x019E868C: B #0x19e869c               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x019E8690: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x019E8694: ADD x8, x8, x9, lsl #4     | X8 = (1152921504866643968 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x019E8698: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504866643968 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_22:
            // 0x019E869C: LDP x4, x3, [x0]           | X4 = __RuntimeMethodHiddenParam + 24 + 168 + 80; X3 = __RuntimeMethodHiddenParam + 24 + 168 + 80 + 8; //  | 
            // 0x019E86A0: MOV x0, x22                | X0 = 1152921513961314240 (0x100000022D91D7C0);//ML01
            // 0x019E86A4: MOV x1, x19                | X1 = second;//m1                        
            // 0x019E86A8: MOV x2, x20                | X2 = first;//m1                         
            // 0x019E86AC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x019E86B0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x019E86B4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x019E86B8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x019E86BC: BR x4                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 80;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 80;
            label_12:
            // 0x019E86C0: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x019E86C4: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x019E86C8: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            System.ArgumentException val_2 = null;
            // 0x019E86CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x019E86D0: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x019E86D4: LDR x8, [x8, #0xc10]       | X8 = (string**)(1152921513961289088)("Duplicate first or second");
            // 0x019E86D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x019E86DC: MOV x19, x0                | X19 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x019E86E0: LDR x1, [x8]               | X1 = "Duplicate first or second";       
            // 0x019E86E4: BL #0x18b5590              | .ctor(message:  "Duplicate first or second");
            val_2 = new System.ArgumentException(message:  "Duplicate first or second");
            // 0x019E86E8: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x019E86EC: LDR x8, [x8, #0xc40]       | X8 = 1152921513961289216;               
            // 0x019E86F0: MOV x0, x19                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x019E86F4: LDR x1, [x8]               | X1 = public System.Void Newtonsoft.Json.Utilities.BidirectionalDictionary<System.Object, System.Object>::Add(System.Object first, System.Object second);
            // 0x019E86F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x019E86FC: BL #0x19e29cc              | Add(first:  public System.Void Newtonsoft.Json.Utilities.BidirectionalDictionary<System.Object, System.Object>::Add(System.Object first, System.Object second), second:  0);
            Add(first:  public System.Void Newtonsoft.Json.Utilities.BidirectionalDictionary<System.Object, System.Object>::Add(System.Object first, System.Object second), second:  0);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E8700 VirtAddr: 0x019E8700 -RVA: 0x019E8700 
        // -BidirectionalDictionary<object, object>.TryGetByFirst
        // -BidirectionalDictionary<string, string>.TryGetByFirst
        // -BidirectionalDictionary<string, object>.TryGetByFirst
        //
        //
        // Offset in libil2cpp.so: 0x019E8700 (27166464), len: 180  VirtAddr: 0x019E8700 RVA: 0x019E8700 token: 100686543 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public bool TryGetByFirst(TFirst first, out TSecond second)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x019E8700: STP x22, x21, [sp, #-0x30]! | stack[1152921513961430512] = ???;  stack[1152921513961430520] = ???;  //  dest_result_addr=1152921513961430512 |  dest_result_addr=1152921513961430520
            // 0x019E8704: STP x20, x19, [sp, #0x10]  | stack[1152921513961430528] = ???;  stack[1152921513961430536] = ???;  //  dest_result_addr=1152921513961430528 |  dest_result_addr=1152921513961430536
            // 0x019E8708: STP x29, x30, [sp, #0x20]  | stack[1152921513961430544] = ???;  stack[1152921513961430552] = ???;  //  dest_result_addr=1152921513961430544 |  dest_result_addr=1152921513961430552
            // 0x019E870C: ADD x29, sp, #0x20         | X29 = (1152921513961430512 + 32) = 1152921513961430544 (0x100000022D939E10);
            // 0x019E8710: LDR x20, [x0, #0x10]       | 
            // 0x019E8714: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E8718: MOV x19, x2                | X19 = 1152921513961478656 (0x100000022D945A00);//ML01
            // 0x019E871C: MOV x21, x1                | X21 = first;//m1                        
            // 0x019E8720: CBNZ x20, #0x19e8728       | if (X20 != 0) goto label_0;             
            if(X20 != 0)
            {
                goto label_0;
            }
            // 0x019E8724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x019E8728: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E872C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E8730: LDR x22, [x8, #0x48]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 72;
            // 0x019E8734: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 72;//m1
            // 0x019E8738: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 72, ????);
            // 0x019E873C: LDR x8, [x20]              | X8 = X20;                               
            var val_4 = X20;
            // 0x019E8740: LDRH w9, [x8, #0x102]      | W9 = X20 + 258;                         
            // 0x019E8744: CBZ x9, #0x19e8770         | if (X20 + 258 == 0) goto label_1;       
            if((X20 + 258) == 0)
            {
                goto label_1;
            }
            // 0x019E8748: LDR x10, [x8, #0x98]       | X10 = X20 + 152;                        
            var val_1 = X20 + 152;
            // 0x019E874C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E8750: ADD x10, x10, #8           | X10 = (X20 + 152 + 8);                  
            val_1 = val_1 + 8;
            label_3:
            // 0x019E8754: LDUR x12, [x10, #-8]       | X12 = (X20 + 152 + 8) + -8;             
            // 0x019E8758: CMP x12, x22               | STATE = COMPARE((X20 + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 72)
            // 0x019E875C: B.EQ #0x19e8784            | if ((X20 + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168 + 72) goto label_2;
            if(((X20 + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168 + 72))
            {
                goto label_2;
            }
            // 0x019E8760: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E8764: ADD x10, x10, #0x10        | X10 = ((X20 + 152 + 8) + 16);           
            val_1 = val_1 + 16;
            // 0x019E8768: CMP x11, x9                | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x019E876C: B.LO #0x19e8754            | if (0 < X20 + 258) goto label_3;        
            if(val_2 < (X20 + 258))
            {
                goto label_3;
            }
            label_1:
            // 0x019E8770: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x019E8774: MOV x0, x20                | X0 = X20;//m1                           
            val_2 = X20;
            // 0x019E8778: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 72;//m1
            // 0x019E877C: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x019E8780: B #0x19e8794               |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x019E8784: LDR w9, [x10]              | W9 = (X20 + 152 + 8);                   
            var val_3 = val_1;
            // 0x019E8788: ADD w9, w9, #3             | W9 = ((X20 + 152 + 8) + 3);             
            val_3 = val_3 + 3;
            // 0x019E878C: ADD x8, x8, w9, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + 3));     
            val_4 = val_4 + val_3;
            // 0x019E8790: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + 3)) + 272);
            val_2 = val_4 + 272;
            label_4:
            // 0x019E8794: LDP x4, x3, [x0]           | X4 = ((X20 + ((X20 + 152 + 8) + 3)) + 272); X3 = ((X20 + ((X20 + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x019E8798: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019E879C: MOV x2, x19                | X2 = 1152921513961478656 (0x100000022D945A00);//ML01
            // 0x019E87A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E87A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E87A8: MOV x1, x21                | X1 = first;//m1                         
            // 0x019E87AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E87B0: BR x4                      | goto ((X20 + ((X20 + 152 + 8) + 3)) + 272);
            goto ((X20 + ((X20 + 152 + 8) + 3)) + 272);
        
        }
        // Generic instance method:
        //
        // file offset: 0x019E87B4 VirtAddr: 0x019E87B4 -RVA: 0x019E87B4 
        // -BidirectionalDictionary<object, object>.TryGetBySecond
        // -BidirectionalDictionary<string, string>.TryGetBySecond
        // -BidirectionalDictionary<string, object>.TryGetBySecond
        //
        //
        // Offset in libil2cpp.so: 0x019E87B4 (27166644), len: 180  VirtAddr: 0x019E87B4 RVA: 0x019E87B4 token: 100686544 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public bool TryGetBySecond(TSecond second, out TFirst first)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x019E87B4: STP x22, x21, [sp, #-0x30]! | stack[1152921513961558768] = ???;  stack[1152921513961558776] = ???;  //  dest_result_addr=1152921513961558768 |  dest_result_addr=1152921513961558776
            // 0x019E87B8: STP x20, x19, [sp, #0x10]  | stack[1152921513961558784] = ???;  stack[1152921513961558792] = ???;  //  dest_result_addr=1152921513961558784 |  dest_result_addr=1152921513961558792
            // 0x019E87BC: STP x29, x30, [sp, #0x20]  | stack[1152921513961558800] = ???;  stack[1152921513961558808] = ???;  //  dest_result_addr=1152921513961558800 |  dest_result_addr=1152921513961558808
            // 0x019E87C0: ADD x29, sp, #0x20         | X29 = (1152921513961558768 + 32) = 1152921513961558800 (0x100000022D959310);
            // 0x019E87C4: LDR x20, [x0, #0x18]       | 
            // 0x019E87C8: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x019E87CC: MOV x19, x2                | X19 = 1152921513961606912 (0x100000022D964F00);//ML01
            // 0x019E87D0: MOV x21, x1                | X21 = second;//m1                       
            // 0x019E87D4: CBNZ x20, #0x19e87dc       | if (X20 != 0) goto label_0;             
            if(X20 != 0)
            {
                goto label_0;
            }
            // 0x019E87D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x019E87DC: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x019E87E0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x019E87E4: LDR x22, [x8, #0x50]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 80;
            // 0x019E87E8: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 80;//m1
            // 0x019E87EC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 80, ????);
            // 0x019E87F0: LDR x8, [x20]              | X8 = X20;                               
            var val_4 = X20;
            // 0x019E87F4: LDRH w9, [x8, #0x102]      | W9 = X20 + 258;                         
            // 0x019E87F8: CBZ x9, #0x19e8824         | if (X20 + 258 == 0) goto label_1;       
            if((X20 + 258) == 0)
            {
                goto label_1;
            }
            // 0x019E87FC: LDR x10, [x8, #0x98]       | X10 = X20 + 152;                        
            var val_1 = X20 + 152;
            // 0x019E8800: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x019E8804: ADD x10, x10, #8           | X10 = (X20 + 152 + 8);                  
            val_1 = val_1 + 8;
            label_3:
            // 0x019E8808: LDUR x12, [x10, #-8]       | X12 = (X20 + 152 + 8) + -8;             
            // 0x019E880C: CMP x12, x22               | STATE = COMPARE((X20 + 152 + 8) + -8, __RuntimeMethodHiddenParam + 24 + 168 + 80)
            // 0x019E8810: B.EQ #0x19e8838            | if ((X20 + 152 + 8) + -8 == __RuntimeMethodHiddenParam + 24 + 168 + 80) goto label_2;
            if(((X20 + 152 + 8) + -8) == (__RuntimeMethodHiddenParam + 24 + 168 + 80))
            {
                goto label_2;
            }
            // 0x019E8814: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x019E8818: ADD x10, x10, #0x10        | X10 = ((X20 + 152 + 8) + 16);           
            val_1 = val_1 + 16;
            // 0x019E881C: CMP x11, x9                | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x019E8820: B.LO #0x19e8808            | if (0 < X20 + 258) goto label_3;        
            if(val_2 < (X20 + 258))
            {
                goto label_3;
            }
            label_1:
            // 0x019E8824: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x019E8828: MOV x0, x20                | X0 = X20;//m1                           
            val_2 = X20;
            // 0x019E882C: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 80;//m1
            // 0x019E8830: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x019E8834: B #0x19e8848               |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x019E8838: LDR w9, [x10]              | W9 = (X20 + 152 + 8);                   
            var val_3 = val_1;
            // 0x019E883C: ADD w9, w9, #3             | W9 = ((X20 + 152 + 8) + 3);             
            val_3 = val_3 + 3;
            // 0x019E8840: ADD x8, x8, w9, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + 3));     
            val_4 = val_4 + val_3;
            // 0x019E8844: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + 3)) + 272);
            val_2 = val_4 + 272;
            label_4:
            // 0x019E8848: LDP x4, x3, [x0]           | X4 = ((X20 + ((X20 + 152 + 8) + 3)) + 272); X3 = ((X20 + ((X20 + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x019E884C: MOV x0, x20                | X0 = X20;//m1                           
            // 0x019E8850: MOV x2, x19                | X2 = 1152921513961606912 (0x100000022D964F00);//ML01
            // 0x019E8854: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019E8858: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019E885C: MOV x1, x21                | X1 = second;//m1                        
            // 0x019E8860: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019E8864: BR x4                      | goto ((X20 + ((X20 + 152 + 8) + 3)) + 272);
            goto ((X20 + ((X20 + 152 + 8) + 3)) + 272);
        
        }
    
    }

}
