using UnityEngine;
public class BarrierGat : Monster
{
    // Fields
    public bool IsState; //  0x00000634
    private barrierGateCfg _barrierGateCfg; //  0x00000638
    private UnityEngine.ParticleSystem _particle; //  0x00000640
    private UnityEngine.BoxCollider _col; //  0x00000648
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8CB7C (12110716), len: 8  VirtAddr: 0x00B8CB7C RVA: 0x00B8CB7C token: 100691372 methodIndex: 25076 delegateWrapperIndex: 0 methodInvoker: 0
    public BarrierGat()
    {
        //
        // Disasemble & Code
        // 0x00B8CB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CB80: B #0xac4934                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8CB84 (12110724), len: 4  VirtAddr: 0x00B8CB84 RVA: 0x00B8CB84 token: 100691373 methodIndex: 25077 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnTriggerFun(int effectId = 365)
    {
        //
        // Disasemble & Code
        // 0x00B8CB84: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8CB88 (12110728), len: 4  VirtAddr: 0x00B8CB88 RVA: 0x00B8CB88 token: 100691374 methodIndex: 25078 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnTriggerFun(CombatEntity main, int effectId = 365)
    {
        //
        // Disasemble & Code
        // 0x00B8CB88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8CB8C (12110732), len: 4  VirtAddr: 0x00B8CB8C RVA: 0x00B8CB8C token: 100691375 methodIndex: 25079 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void OnTriggerBehaivir(CombatEntity main)
    {
        //
        // Disasemble & Code
        // 0x00B8CB8C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8CB90 (12110736), len: 260  VirtAddr: 0x00B8CB90 RVA: 0x00B8CB90 token: 100691376 methodIndex: 25080 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void Init()
    {
        //
        // Disasemble & Code
        // 0x00B8CB90: STP x24, x23, [sp, #-0x40]! | stack[1152921514652566112] = ???;  stack[1152921514652566120] = ???;  //  dest_result_addr=1152921514652566112 |  dest_result_addr=1152921514652566120
        // 0x00B8CB94: STP x22, x21, [sp, #0x10]  | stack[1152921514652566128] = ???;  stack[1152921514652566136] = ???;  //  dest_result_addr=1152921514652566128 |  dest_result_addr=1152921514652566136
        // 0x00B8CB98: STP x20, x19, [sp, #0x20]  | stack[1152921514652566144] = ???;  stack[1152921514652566152] = ???;  //  dest_result_addr=1152921514652566144 |  dest_result_addr=1152921514652566152
        // 0x00B8CB9C: STP x29, x30, [sp, #0x30]  | stack[1152921514652566160] = ???;  stack[1152921514652566168] = ???;  //  dest_result_addr=1152921514652566160 |  dest_result_addr=1152921514652566168
        // 0x00B8CBA0: ADD x29, sp, #0x30         | X29 = (1152921514652566112 + 48) = 1152921514652566160 (0x1000000256C58290);
        // 0x00B8CBA4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8CBA8: LDRB w8, [x20, #0xa13]     | W8 = (bool)static_value_03733A13;       
        // 0x00B8CBAC: MOV x19, x0                | X19 = 1152921514652578176 (0x1000000256C5B180);//ML01
        // 0x00B8CBB0: TBNZ w8, #0, #0xb8cbcc     | if (static_value_03733A13 == true) goto label_0;
        // 0x00B8CBB4: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B8CBB8: LDR x8, [x8, #0xd90]       | X8 = 0x2B8EFBC;                         
        // 0x00B8CBBC: LDR w0, [x8]               | W0 = 0x12B1;                            
        // 0x00B8CBC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B1, ????);     
        // 0x00B8CBC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8CBC8: STRB w8, [x20, #0xa13]     | static_value_03733A13 = true;            //  dest_result_addr=57883155
        label_0:
        // 0x00B8CBCC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8CBD0: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00B8CBD4: LDR x8, [x8, #0xc98]       | X8 = 1152921514652552128;               
        // 0x00B8CBD8: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00B8CBDC: LDR x21, [x8]              | X21 = public System.Void BarrierGat::EventOpened(CEvent.ZEvent ev);
        // 0x00B8CBE0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00B8CBE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8CBE8: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00B8CBEC: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00B8CBF0: MOV x1, x19                | X1 = 1152921514652578176 (0x1000000256C5B180);//ML01
        // 0x00B8CBF4: MOV x2, x21                | X2 = 1152921514652552128 (0x1000000256C54BC0);//ML01
        // 0x00B8CBF8: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8CBFC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8CC00: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void BarrierGat::EventOpened(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void BarrierGat::EventOpened(CEvent.ZEvent ev));
        // 0x00B8CC04: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B8CC08: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B8CC0C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B8CC10: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B8CC14: TBZ w8, #0, #0xb8cc24      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8CC18: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B8CC1C: CBNZ w8, #0xb8cc24         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8CC20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00B8CC24: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B8CC28: LDR x8, [x8, #0x9c0]       | X8 = (string**)(1152921510361988960)("BATTLE_START");
        // 0x00B8CC2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CC30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8CC34: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8CC38: LDR x1, [x8]               | X1 = "BATTLE_START";                    
        // 0x00B8CC3C: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_START");
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_START");
        // 0x00B8CC40: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
        // 0x00B8CC44: LDR x8, [x8, #0xe8]        | X8 = 1152921514652553152;               
        // 0x00B8CC48: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00B8CC4C: LDR x20, [x8]              | X20 = public System.Void BarrierGat::EventClosed(CEvent.ZEvent ev);
        // 0x00B8CC50: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8CC54: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8CC58: MOV x1, x19                | X1 = 1152921514652578176 (0x1000000256C5B180);//ML01
        // 0x00B8CC5C: MOV x2, x20                | X2 = 1152921514652553152 (0x1000000256C54FC0);//ML01
        // 0x00B8CC60: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8CC64: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void BarrierGat::EventClosed(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void BarrierGat::EventClosed(CEvent.ZEvent ev));
        // 0x00B8CC68: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B8CC6C: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921510361990080)("BATTLE_ENDED");
        // 0x00B8CC70: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8CC74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CC78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8CC7C: LDR x1, [x8]               | X1 = "BATTLE_ENDED";                    
        // 0x00B8CC80: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8CC84: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8CC88: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8CC8C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B8CC90: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_ENDED"); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  "BATTLE_ENDED");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8CC94 (12110996), len: 600  VirtAddr: 0x00B8CC94 RVA: 0x00B8CC94 token: 100691377 methodIndex: 25081 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Create(monstersCfg mcfg, JSCLevelMonsterConfig lmcfg)
    {
        //
        // Disasemble & Code
        // 0x00B8CC94: STP x22, x21, [sp, #-0x30]! | stack[1152921514652727504] = ???;  stack[1152921514652727512] = ???;  //  dest_result_addr=1152921514652727504 |  dest_result_addr=1152921514652727512
        // 0x00B8CC98: STP x20, x19, [sp, #0x10]  | stack[1152921514652727520] = ???;  stack[1152921514652727528] = ???;  //  dest_result_addr=1152921514652727520 |  dest_result_addr=1152921514652727528
        // 0x00B8CC9C: STP x29, x30, [sp, #0x20]  | stack[1152921514652727536] = ???;  stack[1152921514652727544] = ???;  //  dest_result_addr=1152921514652727536 |  dest_result_addr=1152921514652727544
        // 0x00B8CCA0: ADD x29, sp, #0x20         | X29 = (1152921514652727504 + 32) = 1152921514652727536 (0x1000000256C7F8F0);
        // 0x00B8CCA4: SUB sp, sp, #0x10          | SP = (1152921514652727504 - 16) = 1152921514652727488 (0x1000000256C7F8C0);
        // 0x00B8CCA8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B8CCAC: LDRB w8, [x22, #0xa14]     | W8 = (bool)static_value_03733A14;       
        // 0x00B8CCB0: MOV x21, x2                | X21 = lmcfg;//m1                        
        // 0x00B8CCB4: MOV x20, x1                | X20 = mcfg;//m1                         
        // 0x00B8CCB8: MOV x19, x0                | X19 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CCBC: TBNZ w8, #0, #0xb8ccd8     | if (static_value_03733A14 == true) goto label_0;
        // 0x00B8CCC0: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B8CCC4: LDR x8, [x8, #0xb58]       | X8 = 0x2B8EFB0;                         
        // 0x00B8CCC8: LDR w0, [x8]               | W0 = 0x12AE;                            
        // 0x00B8CCCC: BL #0x2782188              | X0 = sub_2782188( ?? 0x12AE, ????);     
        // 0x00B8CCD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8CCD4: STRB w8, [x22, #0xa14]     | static_value_03733A14 = true;            //  dest_result_addr=57883156
        label_0:
        // 0x00B8CCD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8CCDC: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CCE0: MOV x1, x20                | X1 = mcfg;//m1                          
        // 0x00B8CCE4: MOV x2, x21                | X2 = lmcfg;//m1                         
        // 0x00B8CCE8: BL #0xac53d4               | this.Create(mcfg:  mcfg, lmcfg:  lmcfg);
        this.Create(mcfg:  mcfg, lmcfg:  lmcfg);
        // 0x00B8CCEC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B8CCF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CCF4: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CCF8: BL #0xd89a34               | this.set_unitCamp(value:  0);           
        this.unitCamp = 0;
        // 0x00B8CCFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CD00: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CD04: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B8CD08: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
        // 0x00B8CD0C: LDR x8, [x8, #0xbf8]       | X8 = (string**)(1152921514652678464)("Default");
        // 0x00B8CD10: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B8CD14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CD18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CD1C: LDR x1, [x8]               | X1 = "Default";                         
        // 0x00B8CD20: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_2 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00B8CD24: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B8CD28: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00B8CD2C: MOV w22, w0                | W22 = val_2;//m1                        
        // 0x00B8CD30: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00B8CD34: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B8CD38: TBZ w9, #0, #0xb8cd4c      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8CD3C: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B8CD40: CBNZ w9, #0xb8cd4c         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8CD44: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B8CD48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_2:
        // 0x00B8CD4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CD50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8CD54: MOV x1, x21                | X1 = val_1;//m1                         
        // 0x00B8CD58: MOV w2, w22                | W2 = val_2;//m1                         
        // 0x00B8CD5C: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_1);
        NGUITools.SetLayer(go:  0, layer:  val_1);
        // 0x00B8CD60: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B8CD64: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B8CD68: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B8CD6C: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B8CD70: TBZ w8, #0, #0xb8cd80      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B8CD74: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B8CD78: CBNZ w8, #0xb8cd80         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B8CD7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_4:
        // 0x00B8CD80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CD84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CD88: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_3 = ZMG.CfgDataMgr;
        // 0x00B8CD8C: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B8CD90: CBNZ x20, #0xb8cd98        | if (mcfg != null) goto label_5;         
        if(mcfg != null)
        {
            goto label_5;
        }
        // 0x00B8CD94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B8CD98: LDR w22, [x20, #0x10]      | W22 = mcfg.id; //P2                     
        // 0x00B8CD9C: CBNZ x21, #0xb8cda4        | if (val_3 != null) goto label_6;        
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00B8CDA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B8CDA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CDA8: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B8CDAC: MOV w1, w22                | W1 = mcfg.id;//m1                       
        // 0x00B8CDB0: BL #0xb46f88               | X0 = val_3.GetbarrierGateCfg(id:  mcfg.id);
        barrierGateCfg val_4 = val_3.GetbarrierGateCfg(id:  mcfg.id);
        // 0x00B8CDB4: STR x0, [x19, #0x638]      | this._barrierGateCfg = val_4;            //  dest_result_addr=1152921514652741144
        this._barrierGateCfg = val_4;
        // 0x00B8CDB8: CBNZ x0, #0xb8ce38         | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B8CDBC: CBNZ x20, #0xb8cdc4        | if (mcfg != null) goto label_8;         
        if(mcfg != null)
        {
            goto label_8;
        }
        // 0x00B8CDC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00B8CDC4: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B8CDC8: LDR w8, [x20, #0x10]       | W8 = mcfg.id; //P2                      
        // 0x00B8CDCC: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B8CDD0: ADD x1, sp, #0xc           | X1 = (1152921514652727488 + 12) = 1152921514652727500 (0x1000000256C7F8CC);
        // 0x00B8CDD4: STR w8, [sp, #0xc]         | stack[1152921514652727500] = mcfg.id;    //  dest_result_addr=1152921514652727500
        // 0x00B8CDD8: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B8CDDC: BL #0x27bc028              | X0 = 1152921514652792032 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), mcfg.id);
        // 0x00B8CDE0: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B8CDE4: LDR x8, [x8, #0xbc0]       | X8 = (string**)(1152921514652690848)("barrierGat配表中找不到ID:{0}的信息");
        // 0x00B8CDE8: MOV x2, x0                 | X2 = 1152921514652792032 (0x1000000256C8F4E0);//ML01
        // 0x00B8CDEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CDF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8CDF4: LDR x1, [x8]               | X1 = "barrierGat配表中找不到ID:{0}的信息";       
        // 0x00B8CDF8: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "barrierGat配表中找不到ID:{0}的信息");
        string val_5 = EString.EFormat(format:  0, arg0:  "barrierGat配表中找不到ID:{0}的信息");
        // 0x00B8CDFC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B8CE00: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B8CE04: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B8CE08: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B8CE0C: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B8CE10: TBZ w9, #0, #0xb8ce24      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B8CE14: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B8CE18: CBNZ w9, #0xb8ce24         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B8CE1C: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B8CE20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_10:
        // 0x00B8CE24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8CE28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8CE2C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B8CE30: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x00B8CE34: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_5);
        EDebug.Log(message:  0, isShowStack:  val_5);
        label_7:
        // 0x00B8CE38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CE3C: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CE40: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_6 = this.transform;
        // 0x00B8CE44: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00B8CE48: CBNZ x20, #0xb8ce50        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B8CE4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B8CE50: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B8CE54: LDR x8, [x8]               | X8 = 1152921511727609552;               
        // 0x00B8CE58: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00B8CE5C: LDR x1, [x8]               | X1 = public UnityEngine.ParticleSystem UnityEngine.Component::GetComponentInChildren<UnityEngine.ParticleSystem>();
        // 0x00B8CE60: BL #0x23d54dc              | X0 = val_6.GetComponentInChildren<UnityEngine.ParticleSystem>();
        UnityEngine.ParticleSystem val_7 = val_6.GetComponentInChildren<UnityEngine.ParticleSystem>();
        // 0x00B8CE64: STR x0, [x19, #0x640]      | this._particle = val_7;                  //  dest_result_addr=1152921514652741152
        this._particle = val_7;
        // 0x00B8CE68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CE6C: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CE70: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_8 = this.transform;
        // 0x00B8CE74: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B8CE78: CBNZ x20, #0xb8ce80        | if (val_8 != null) goto label_12;       
        if(val_8 != null)
        {
            goto label_12;
        }
        // 0x00B8CE7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_12:
        // 0x00B8CE80: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00B8CE84: LDR x8, [x8, #0xe78]       | X8 = 1152921511726359632;               
        // 0x00B8CE88: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B8CE8C: LDR x1, [x8]               | X1 = public UnityEngine.BoxCollider UnityEngine.Component::GetComponent<UnityEngine.BoxCollider>();
        // 0x00B8CE90: BL #0x23d5410              | X0 = val_8.GetComponent<UnityEngine.BoxCollider>();
        UnityEngine.BoxCollider val_9 = val_8.GetComponent<UnityEngine.BoxCollider>();
        // 0x00B8CE94: STR x0, [x19, #0x648]      | this._col = val_9;                       //  dest_result_addr=1152921514652741160
        this._col = val_9;
        // 0x00B8CE98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CE9C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B8CEA0: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CEA4: BL #0xd89d7c               | this.set_isNotSelected(value:  true);   
        this.isNotSelected = true;
        // 0x00B8CEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CEAC: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CEB0: BL #0xd89828               | this.UpdateYPos();                      
        this.UpdateYPos();
        // 0x00B8CEB4: LDR x20, [x19, #0x638]     | X20 = this._barrierGateCfg; //P2        
        // 0x00B8CEB8: CBNZ x20, #0xb8cec0        | if (this._barrierGateCfg != null) goto label_13;
        if(this._barrierGateCfg != null)
        {
            goto label_13;
        }
        // 0x00B8CEBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_13:
        // 0x00B8CEC0: LDR w8, [x20, #0x14]       | W8 = this._barrierGateCfg.initState; //P2 
        // 0x00B8CEC4: CMP w8, #1                 | STATE = COMPARE(this._barrierGateCfg.initState, 0x1)
        // 0x00B8CEC8: CSET w1, eq                | W1 = this._barrierGateCfg.initState == 1 ? 1 : 0;
        bool val_10 = (this._barrierGateCfg.initState == 1) ? 1 : 0;
        // 0x00B8CECC: MOV x0, x19                | X0 = 1152921514652739552 (0x1000000256C827E0);//ML01
        // 0x00B8CED0: STRB w1, [x19, #0x634]     | this.IsState = this._barrierGateCfg.initState == 1 ? 1 : 0;  //  dest_result_addr=1152921514652741140
        this.IsState = val_10;
        // 0x00B8CED4: BL #0xb8ceec               | this.SetBarrierGateState(active:  bool val_10 = (this._barrierGateCfg.initState == 1) ? 1 : 0);
        this.SetBarrierGateState(active:  val_10);
        // 0x00B8CED8: SUB sp, x29, #0x20         | SP = (1152921514652727536 - 32) = 1152921514652727504 (0x1000000256C7F8D0);
        // 0x00B8CEDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8CEE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8CEE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8CEE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D074 (12111988), len: 284  VirtAddr: 0x00B8D074 RVA: 0x00B8D074 token: 100691378 methodIndex: 25082 delegateWrapperIndex: 0 methodInvoker: 0
    public void EventOpened(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        barrierGateCfg val_2;
        // 0x00B8D074: STP x22, x21, [sp, #-0x30]! | stack[1152921514652905040] = ???;  stack[1152921514652905048] = ???;  //  dest_result_addr=1152921514652905040 |  dest_result_addr=1152921514652905048
        // 0x00B8D078: STP x20, x19, [sp, #0x10]  | stack[1152921514652905056] = ???;  stack[1152921514652905064] = ???;  //  dest_result_addr=1152921514652905056 |  dest_result_addr=1152921514652905064
        // 0x00B8D07C: STP x29, x30, [sp, #0x20]  | stack[1152921514652905072] = ???;  stack[1152921514652905080] = ???;  //  dest_result_addr=1152921514652905072 |  dest_result_addr=1152921514652905080
        // 0x00B8D080: ADD x29, sp, #0x20         | X29 = (1152921514652905040 + 32) = 1152921514652905072 (0x1000000256CAAE70);
        // 0x00B8D084: SUB sp, sp, #0x10          | SP = (1152921514652905040 - 16) = 1152921514652905024 (0x1000000256CAAE40);
        // 0x00B8D088: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B8D08C: LDRB w8, [x21, #0xa15]     | W8 = (bool)static_value_03733A15;       
        // 0x00B8D090: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00B8D094: MOV x19, x0                | X19 = 1152921514652917088 (0x1000000256CADD60);//ML01
        // 0x00B8D098: TBNZ w8, #0, #0xb8d0b4     | if (static_value_03733A15 == true) goto label_0;
        // 0x00B8D09C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B8D0A0: LDR x8, [x8, #0xad0]       | X8 = 0x2B8EFB8;                         
        // 0x00B8D0A4: LDR w0, [x8]               | W0 = 0x12B0;                            
        // 0x00B8D0A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B0, ????);     
        // 0x00B8D0AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D0B0: STRB w8, [x21, #0xa15]     | static_value_03733A15 = true;            //  dest_result_addr=57883157
        label_0:
        // 0x00B8D0B4: CBNZ x20, #0xb8d0bc        | if (ev != null) goto label_1;           
        if(ev != null)
        {
            goto label_1;
        }
        // 0x00B8D0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12B0, ????);     
        label_1:
        // 0x00B8D0BC: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B8D0C0: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        // 0x00B8D0C4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B8D0C8: LDR x20, [x8]              | X20 = typeof(System.Int32);             
        // 0x00B8D0CC: CBNZ x21, #0xb8d0d4        | if (ev.arg != null) goto label_2;       
        if(ev.arg != null)
        {
            goto label_2;
        }
        // 0x00B8D0D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12B0, ????);     
        label_2:
        // 0x00B8D0D4: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00B8D0D8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00B8D0DC: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00B8D0E0: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00B8D0E4: B.NE #0xb8d158             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_3;
        // 0x00B8D0E8: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00B8D0EC: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        ev.arg.System.IDisposable.Dispose();
        // 0x00B8D0F0: LDR w20, [x0]              | W20 = typeof(System.Object);            
        // 0x00B8D0F4: LDR x21, [x19, #0x638]     | X21 = this._barrierGateCfg; //P2        
        val_2 = this._barrierGateCfg;
        // 0x00B8D0F8: CBNZ x21, #0xb8d100        | if (this._barrierGateCfg != null) goto label_4;
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B8D0FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ev.arg, ????);     
        label_4:
        // 0x00B8D100: LDR w8, [x21, #0x18]       | W8 = this._barrierGateCfg.openWay; //P2 
        // 0x00B8D104: CMP w8, #1                 | STATE = COMPARE(this._barrierGateCfg.openWay, 0x1)
        // 0x00B8D108: B.NE #0xb8d144             | if (this._barrierGateCfg.openWay != 1) goto label_7;
        if(this._barrierGateCfg.openWay != 1)
        {
            goto label_7;
        }
        // 0x00B8D10C: LDR x21, [x19, #0x638]     | X21 = this._barrierGateCfg; //P2        
        val_2 = this._barrierGateCfg;
        // 0x00B8D110: CBNZ x21, #0xb8d118        | if (this._barrierGateCfg != null) goto label_6;
        if(val_2 != null)
        {
            goto label_6;
        }
        // 0x00B8D114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ev.arg, ????);     
        label_6:
        // 0x00B8D118: LDR w8, [x21, #0x1c]       | W8 = this._barrierGateCfg.openParameter; //P2 
        int val_2 = this._barrierGateCfg.openParameter;
        // 0x00B8D11C: SUB w8, w8, #1             | W8 = (this._barrierGateCfg.openParameter - 1);
        val_2 = val_2 - 1;
        // 0x00B8D120: CMP w20, w8                | STATE = COMPARE(typeof(System.Object), (this._barrierGateCfg.openParameter - 1))
        // 0x00B8D124: B.NE #0xb8d144             | if (typeof(System.Object) != this._barrierGateCfg.openParameter) goto label_7;
        if(null != val_2)
        {
            goto label_7;
        }
        // 0x00B8D128: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B8D12C: MOV x0, x19                | X0 = 1152921514652917088 (0x1000000256CADD60);//ML01
        // 0x00B8D130: SUB sp, x29, #0x20         | SP = (1152921514652905072 - 32) = 1152921514652905040 (0x1000000256CAAE50);
        // 0x00B8D134: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D138: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D13C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D140: B #0xb8ceec                | this.SetBarrierGateState(active:  true); return;
        this.SetBarrierGateState(active:  true);
        return;
        label_7:
        // 0x00B8D144: SUB sp, x29, #0x20         | SP = (1152921514652905072 - 32) = 1152921514652905040 (0x1000000256CAAE50);
        // 0x00B8D148: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D14C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D150: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D154: RET                        |  return;                                
        return;
        label_3:
        // 0x00B8D158: ADD x8, sp, #8             | X8 = (1152921514652905024 + 8) = 1152921514652905032 (0x1000000256CAAE48);
        // 0x00B8D15C: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B8D160: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00B8D164: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514652893088]
        // 0x00B8D168: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
        // 0x00B8D16C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D170: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00B8D174: ADD x0, sp, #8             | X0 = (1152921514652905024 + 8) = 1152921514652905032 (0x1000000256CAAE48);
        // 0x00B8D178: BL #0x299a140              | 
        // 0x00B8D17C: MOV x19, x0                | X19 = 1152921514652905032 (0x1000000256CAAE48);//ML01
        // 0x00B8D180: ADD x0, sp, #8             | X0 = (1152921514652905024 + 8) = 1152921514652905032 (0x1000000256CAAE48);
        // 0x00B8D184: BL #0x299a140              | 
        // 0x00B8D188: MOV x0, x19                | X0 = 1152921514652905032 (0x1000000256CAAE48);//ML01
        // 0x00B8D18C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000256CAAE48, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D190 (12112272), len: 428  VirtAddr: 0x00B8D190 RVA: 0x00B8D190 token: 100691379 methodIndex: 25083 delegateWrapperIndex: 0 methodInvoker: 0
    public void EventClosed(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        barrierGateCfg val_8;
        // 0x00B8D190: STP x22, x21, [sp, #-0x30]! | stack[1152921514653062096] = ???;  stack[1152921514653062104] = ???;  //  dest_result_addr=1152921514653062096 |  dest_result_addr=1152921514653062104
        // 0x00B8D194: STP x20, x19, [sp, #0x10]  | stack[1152921514653062112] = ???;  stack[1152921514653062120] = ???;  //  dest_result_addr=1152921514653062112 |  dest_result_addr=1152921514653062120
        // 0x00B8D198: STP x29, x30, [sp, #0x20]  | stack[1152921514653062128] = ???;  stack[1152921514653062136] = ???;  //  dest_result_addr=1152921514653062128 |  dest_result_addr=1152921514653062136
        // 0x00B8D19C: ADD x29, sp, #0x20         | X29 = (1152921514653062096 + 32) = 1152921514653062128 (0x1000000256CD13F0);
        // 0x00B8D1A0: SUB sp, sp, #0x10          | SP = (1152921514653062096 - 16) = 1152921514653062080 (0x1000000256CD13C0);
        // 0x00B8D1A4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B8D1A8: LDRB w8, [x21, #0xa16]     | W8 = (bool)static_value_03733A16;       
        // 0x00B8D1AC: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00B8D1B0: MOV x19, x0                | X19 = 1152921514653074144 (0x1000000256CD42E0);//ML01
        // 0x00B8D1B4: TBNZ w8, #0, #0xb8d1d0     | if (static_value_03733A16 == true) goto label_0;
        // 0x00B8D1B8: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B8D1BC: LDR x8, [x8, #0x738]       | X8 = 0x2B8EFB4;                         
        // 0x00B8D1C0: LDR w0, [x8]               | W0 = 0x12AF;                            
        // 0x00B8D1C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x12AF, ????);     
        // 0x00B8D1C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D1CC: STRB w8, [x21, #0xa16]     | static_value_03733A16 = true;            //  dest_result_addr=57883158
        label_0:
        // 0x00B8D1D0: CBNZ x20, #0xb8d1d8        | if (ev != null) goto label_1;           
        if(ev != null)
        {
            goto label_1;
        }
        // 0x00B8D1D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12AF, ????);     
        label_1:
        // 0x00B8D1D8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B8D1DC: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        // 0x00B8D1E0: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B8D1E4: LDR x20, [x8]              | X20 = typeof(System.Int32);             
        // 0x00B8D1E8: CBNZ x21, #0xb8d1f0        | if (ev.arg != null) goto label_2;       
        if(ev.arg != null)
        {
            goto label_2;
        }
        // 0x00B8D1EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12AF, ????);     
        label_2:
        // 0x00B8D1F0: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00B8D1F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00B8D1F8: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00B8D1FC: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00B8D200: B.NE #0xb8d304             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_3;
        // 0x00B8D204: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00B8D208: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        ev.arg.System.IDisposable.Dispose();
        // 0x00B8D20C: LDR w20, [x0]              | W20 = typeof(System.Object);            
        // 0x00B8D210: LDR x21, [x19, #0x638]     | X21 = this._barrierGateCfg; //P2        
        val_8 = this._barrierGateCfg;
        // 0x00B8D214: CBNZ x21, #0xb8d21c        | if (this._barrierGateCfg != null) goto label_4;
        if(val_8 != null)
        {
            goto label_4;
        }
        // 0x00B8D218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ev.arg, ????);     
        label_4:
        // 0x00B8D21C: LDR w8, [x21, #0x20]       | W8 = this._barrierGateCfg.closeWay; //P2 
        // 0x00B8D220: CMP w8, #1                 | STATE = COMPARE(this._barrierGateCfg.closeWay, 0x1)
        // 0x00B8D224: B.NE #0xb8d2d4             | if (this._barrierGateCfg.closeWay != 1) goto label_7;
        if(this._barrierGateCfg.closeWay != 1)
        {
            goto label_7;
        }
        // 0x00B8D228: LDR x21, [x19, #0x638]     | X21 = this._barrierGateCfg; //P2        
        val_8 = this._barrierGateCfg;
        // 0x00B8D22C: CBNZ x21, #0xb8d234        | if (this._barrierGateCfg != null) goto label_6;
        if(val_8 != null)
        {
            goto label_6;
        }
        // 0x00B8D230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ev.arg, ????);     
        label_6:
        // 0x00B8D234: LDR w8, [x21, #0x24]       | W8 = this._barrierGateCfg.closeParameter; //P2 
        int val_8 = this._barrierGateCfg.closeParameter;
        // 0x00B8D238: SUB w8, w8, #1             | W8 = (this._barrierGateCfg.closeParameter - 1);
        val_8 = val_8 - 1;
        // 0x00B8D23C: CMP w20, w8                | STATE = COMPARE(typeof(System.Object), (this._barrierGateCfg.closeParameter - 1))
        // 0x00B8D240: B.NE #0xb8d2d4             | if (typeof(System.Object) != this._barrierGateCfg.closeParameter) goto label_7;
        if(null != val_8)
        {
            goto label_7;
        }
        // 0x00B8D244: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D24C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_1 = NpcMgr.instance;
        // 0x00B8D250: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8D254: CBNZ x20, #0xb8d25c        | if (val_1 != null) goto label_8;        
        if(val_1 != null)
        {
            goto label_8;
        }
        // 0x00B8D258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_8:
        // 0x00B8D25C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D260: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B8D264: BL #0xd0f68c               | X0 = val_1.get_curRound();              
        int val_2 = val_1.curRound;
        // 0x00B8D268: MOV w20, w0                | W20 = val_2;//m1                        
        // 0x00B8D26C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D274: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_3 = NpcMgr.instance;
        // 0x00B8D278: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B8D27C: CBNZ x21, #0xb8d284        | if (val_3 != null) goto label_9;        
        if(val_3 != null)
        {
            goto label_9;
        }
        // 0x00B8D280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B8D284: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D288: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B8D28C: BL #0xd16370               | X0 = val_3.get_TotalRound();            
        int val_4 = val_3.TotalRound;
        // 0x00B8D290: ADD w8, w20, #1            | W8 = (val_2 + 1);                       
        int val_5 = val_2 + 1;
        // 0x00B8D294: CMP w8, w0                 | STATE = COMPARE((val_2 + 1), val_4)     
        // 0x00B8D298: B.NE #0xb8d2e8             | if (val_5 != val_4) goto label_10;      
        if(val_5 != val_4)
        {
            goto label_10;
        }
        // 0x00B8D29C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D2A0: MOV x0, x19                | X0 = 1152921514653074144 (0x1000000256CD42E0);//ML01
        // 0x00B8D2A4: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_6 = this.gameObject;
        // 0x00B8D2A8: MOV x19, x0                | X19 = val_6;//m1                        
        // 0x00B8D2AC: CBNZ x19, #0xb8d2b4        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B8D2B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B8D2B4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B8D2B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D2BC: MOV x0, x19                | X0 = val_6;//m1                         
        // 0x00B8D2C0: SUB sp, x29, #0x20         | SP = (1152921514653062128 - 32) = 1152921514653062096 (0x1000000256CD13D0);
        // 0x00B8D2C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D2C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D2CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D2D0: B #0x1a62d64               | val_6.SetActive(value:  false); return; 
        val_6.SetActive(value:  false);
        return;
        label_7:
        // 0x00B8D2D4: SUB sp, x29, #0x20         | SP = (1152921514653062128 - 32) = 1152921514653062096 (0x1000000256CD13D0);
        // 0x00B8D2D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D2DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D2E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D2E4: RET                        |  return;                                
        return;
        label_10:
        // 0x00B8D2E8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B8D2EC: MOV x0, x19                | X0 = 1152921514653074144 (0x1000000256CD42E0);//ML01
        // 0x00B8D2F0: SUB sp, x29, #0x20         | SP = (1152921514653062128 - 32) = 1152921514653062096 (0x1000000256CD13D0);
        // 0x00B8D2F4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D2F8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D2FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D300: B #0xb8ceec                | this.SetBarrierGateState(active:  false); return;
        this.SetBarrierGateState(active:  false);
        return;
        label_3:
        // 0x00B8D304: ADD x8, sp, #8             | X8 = (1152921514653062080 + 8) = 1152921514653062088 (0x1000000256CD13C8);
        // 0x00B8D308: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00B8D30C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00B8D310: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921514653050144]
        // 0x00B8D314: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
        // 0x00B8D318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D31C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        // 0x00B8D320: ADD x0, sp, #8             | X0 = (1152921514653062080 + 8) = 1152921514653062088 (0x1000000256CD13C8);
        // 0x00B8D324: BL #0x299a140              | 
        // 0x00B8D328: MOV x19, x0                | X19 = 1152921514653062088 (0x1000000256CD13C8);//ML01
        // 0x00B8D32C: ADD x0, sp, #8             | X0 = (1152921514653062080 + 8) = 1152921514653062088 (0x1000000256CD13C8);
        // 0x00B8D330: BL #0x299a140              | 
        // 0x00B8D334: MOV x0, x19                | X0 = 1152921514653062088 (0x1000000256CD13C8);//ML01
        // 0x00B8D338: BL #0x980800               | X0 = sub_980800( ?? 0x1000000256CD13C8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8CEEC (12111596), len: 392  VirtAddr: 0x00B8CEEC RVA: 0x00B8CEEC token: 100691380 methodIndex: 25084 delegateWrapperIndex: 0 methodInvoker: 0
    private void SetBarrierGateState(bool active)
    {
        //
        // Disasemble & Code
        //  | 
        float val_2;
        //  | 
        float val_3;
        //  | 
        var val_8;
        //  | 
        bool val_9;
        //  | 
        var val_10;
        // 0x00B8CEEC: STP x22, x21, [sp, #-0x30]! | stack[1152921514653231376] = ???;  stack[1152921514653231384] = ???;  //  dest_result_addr=1152921514653231376 |  dest_result_addr=1152921514653231384
        // 0x00B8CEF0: STP x20, x19, [sp, #0x10]  | stack[1152921514653231392] = ???;  stack[1152921514653231400] = ???;  //  dest_result_addr=1152921514653231392 |  dest_result_addr=1152921514653231400
        // 0x00B8CEF4: STP x29, x30, [sp, #0x20]  | stack[1152921514653231408] = ???;  stack[1152921514653231416] = ???;  //  dest_result_addr=1152921514653231408 |  dest_result_addr=1152921514653231416
        // 0x00B8CEF8: ADD x29, sp, #0x20         | X29 = (1152921514653231376 + 32) = 1152921514653231408 (0x1000000256CFA930);
        // 0x00B8CEFC: SUB sp, sp, #0x60          | SP = (1152921514653231376 - 96) = 1152921514653231280 (0x1000000256CFA8B0);
        // 0x00B8CF00: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B8CF04: LDRB w8, [x21, #0xa17]     | W8 = (bool)static_value_03733A17;       
        // 0x00B8CF08: MOV w19, w1                | W19 = active;//m1                       
        // 0x00B8CF0C: MOV x20, x0                | X20 = 1152921514653243424 (0x1000000256CFD820);//ML01
        // 0x00B8CF10: TBNZ w8, #0, #0xb8cf2c     | if (static_value_03733A17 == true) goto label_0;
        // 0x00B8CF14: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B8CF18: LDR x8, [x8, #0x6c8]       | X8 = 0x2B8EFC0;                         
        // 0x00B8CF1C: LDR w0, [x8]               | W0 = 0x12B2;                            
        // 0x00B8CF20: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B2, ????);     
        // 0x00B8CF24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8CF28: STRB w8, [x21, #0xa17]     | static_value_03733A17 = true;            //  dest_result_addr=57883159
        label_0:
        // 0x00B8CF2C: STP xzr, xzr, [sp, #0x48]  | stack[1152921514653231352] = 0x0;  stack[1152921514653231360] = 0x0;  //  dest_result_addr=1152921514653231352 |  dest_result_addr=1152921514653231360
        // 0x00B8CF30: STR xzr, [sp, #0x40]       | stack[1152921514653231344] = 0x0;        //  dest_result_addr=1152921514653231344
        // 0x00B8CF34: LDR x21, [x20, #0x648]     | X21 = this._col; //P2                   
        // 0x00B8CF38: CBNZ x21, #0xb8cf40        | if (this._col != null) goto label_1;    
        if(this._col != null)
        {
            goto label_1;
        }
        // 0x00B8CF3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12B2, ????);     
        label_1:
        // 0x00B8CF40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CF44: ADD x8, sp, #0x20          | X8 = (1152921514653231280 + 32) = 1152921514653231312 (0x1000000256CFA8D0);
        // 0x00B8CF48: MOV x0, x21                | X0 = this._col;//m1                     
        // 0x00B8CF4C: BL #0x26f4a6c              | X0 = this._col.get_bounds();            
        UnityEngine.Bounds val_1 = this._col.bounds;
        // 0x00B8CF50: LDR x8, [sp, #0x30]        | X8 = val_2;                              //  find_add[1152921514653219424]
        // 0x00B8CF54: LDR q0, [sp, #0x20]        | Q0 = val_3;                              //  find_add[1152921514653219424]
        // 0x00B8CF58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CF5C: MOV x0, x20                | X0 = 1152921514653243424 (0x1000000256CFD820);//ML01
        // 0x00B8CF60: STR x8, [sp, #0x50]        | stack[1152921514653231360] = val_2;      //  dest_result_addr=1152921514653231360
        // 0x00B8CF64: STR q0, [sp, #0x40]        | stack[1152921514653231344] = val_3;      //  dest_result_addr=1152921514653231344
        // 0x00B8CF68: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_4 = this.gameObject;
        // 0x00B8CF6C: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B8CF70: CBNZ x22, #0xb8cf78        | if (val_4 != null) goto label_2;        
        if(val_4 != null)
        {
            goto label_2;
        }
        // 0x00B8CF74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_2:
        // 0x00B8CF78: AND w21, w19, #1           | W21 = (active & 1);                     
        val_9 = active;
        // 0x00B8CF7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CF80: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B8CF84: MOV w1, w21                | W1 = (active & 1);//m1                  
        // 0x00B8CF88: BL #0x1a62d64              | val_4.SetActive(value:  val_9);         
        val_4.SetActive(value:  val_9);
        // 0x00B8CF8C: LDR x22, [x20, #0x648]     | X22 = this._col; //P2                   
        // 0x00B8CF90: CBNZ x22, #0xb8cf98        | if (this._col != null) goto label_3;    
        if(this._col != null)
        {
            goto label_3;
        }
        // 0x00B8CF94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_3:
        // 0x00B8CF98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CF9C: MOV x0, x22                | X0 = this._col;//m1                     
        // 0x00B8CFA0: MOV w1, w21                | W1 = (active & 1);//m1                  
        // 0x00B8CFA4: BL #0x26f448c              | this._col.set_enabled(value:  val_9);   
        this._col.enabled = val_9;
        // 0x00B8CFA8: TBZ w19, #0, #0xb8cff4     | if (active == false) goto label_4;      
        if(active == false)
        {
            goto label_4;
        }
        // 0x00B8CFAC: LDR x21, [x20, #0x640]     | X21 = this._particle; //P2              
        // 0x00B8CFB0: CBNZ x21, #0xb8cfb8        | if (this._particle != null) goto label_5;
        if(this._particle != null)
        {
            goto label_5;
        }
        // 0x00B8CFB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._col, ????);  
        label_5:
        // 0x00B8CFB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8CFBC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B8CFC0: MOV x0, x21                | X0 = this._particle;//m1                
        // 0x00B8CFC4: BL #0x2745c68              | this._particle.Play(withChildren:  true);
        this._particle.Play(withChildren:  true);
        // 0x00B8CFC8: LDR x21, [x20, #0x648]     | X21 = this._col; //P2                   
        val_9 = this._col;
        // 0x00B8CFCC: CBNZ x21, #0xb8cfd4        | if (this._col != null) goto label_6;    
        if(val_9 != null)
        {
            goto label_6;
        }
        // 0x00B8CFD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._particle, ????);
        label_6:
        // 0x00B8CFD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CFD8: ADD x8, sp, #0x20          | X8 = (1152921514653231280 + 32) = 1152921514653231312 (0x1000000256CFA8D0);
        // 0x00B8CFDC: MOV x0, x21                | X0 = this._col;//m1                     
        // 0x00B8CFE0: BL #0x26f4a6c              | X0 = this._col.get_bounds();            
        UnityEngine.Bounds val_5 = val_9.bounds;
        // 0x00B8CFE4: LDR x8, [sp, #0x30]        | X8 = val_2;                              //  find_add[1152921514653219424]
        // 0x00B8CFE8: LDR q0, [sp, #0x20]        | Q0 = val_3;                              //  find_add[1152921514653219424]
        // 0x00B8CFEC: STR x8, [sp, #0x50]        | stack[1152921514653231360] = val_2;      //  dest_result_addr=1152921514653231360
        // 0x00B8CFF0: STR q0, [sp, #0x40]        | stack[1152921514653231344] = val_3;      //  dest_result_addr=1152921514653231344
        label_4:
        // 0x00B8CFF4: AND w8, w19, #1            | W8 = (active & 1);                      
        bool val_6 = active;
        // 0x00B8CFF8: STRB w8, [x20, #0x634]     | this.IsState = (active & 1);             //  dest_result_addr=1152921514653245012
        this.IsState = val_6;
        // 0x00B8CFFC: ADRP x19, #0x362c000       | X19 = 56803328 (0x362C000);             
        // 0x00B8D000: LDR x19, [x19, #0xe80]     | X19 = 1152921504837996544;              
        // 0x00B8D004: LDR x0, [x19]              | X0 = typeof(AstarPath);                 
        val_10 = null;
        // 0x00B8D008: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
        // 0x00B8D00C: TBZ w8, #0, #0xb8d020      | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B8D010: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D014: CBNZ w8, #0xb8d020         | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B8D018: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
        // 0x00B8D01C: LDR x0, [x19]              | X0 = typeof(AstarPath);                 
        val_10 = null;
        label_8:
        // 0x00B8D020: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
        // 0x00B8D024: LDR x9, [sp, #0x50]        | X9 = val_2;                             
        // 0x00B8D028: LDR q0, [sp, #0x40]        | Q0 = val_3;                             
        // 0x00B8D02C: LDR x19, [x8, #0x18]       | X19 = AstarPath.active;                 
        // 0x00B8D030: STR x9, [sp, #0x30]        | val_2 = val_2;                           //  dest_result_addr=1152921514653231328
        val_2 = val_2;
        // 0x00B8D034: STR q0, [sp, #0x20]        | val_3 = val_3;                           //  dest_result_addr=1152921514653231312
        val_3 = val_3;
        // 0x00B8D038: CBNZ x19, #0xb8d040        | if (AstarPath.active != null) goto label_9;
        if(AstarPath.active != null)
        {
            goto label_9;
        }
        // 0x00B8D03C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
        label_9:
        // 0x00B8D040: LDR x8, [sp, #0x30]        | X8 = val_2;                             
        // 0x00B8D044: LDR q0, [sp, #0x20]        | Q0 = val_3;                             
        // 0x00B8D048: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D04C: MOV x1, sp                 | X1 = 1152921514653231280 (0x1000000256CFA8B0);//ML01
        // 0x00B8D050: MOV x0, x19                | X0 = AstarPath.active;//m1              
        // 0x00B8D054: STR x8, [sp, #0x10]        | stack[1152921514653231296] = val_2;      //  dest_result_addr=1152921514653231296
        // 0x00B8D058: STR q0, [sp]               | stack[1152921514653231280] = val_3;      //  dest_result_addr=1152921514653231280
        // 0x00B8D05C: BL #0xb39e64               | AstarPath.active.UpdateGraphs(bounds:  new UnityEngine.Bounds() {m_Center = new UnityEngine.Vector3() {x = val_3, y = val_3, z = val_3}, m_Extents = new UnityEngine.Vector3() {x = val_3, y = val_2, z = val_2}});
        AstarPath.active.UpdateGraphs(bounds:  new UnityEngine.Bounds() {m_Center = new UnityEngine.Vector3() {x = val_3, y = val_3, z = val_3}, m_Extents = new UnityEngine.Vector3() {x = val_3, y = val_2, z = val_2}});
        // 0x00B8D060: SUB sp, x29, #0x20         | SP = (1152921514653231408 - 32) = 1152921514653231376 (0x1000000256CFA910);
        // 0x00B8D064: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D068: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D06C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D070: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D33C (12112700), len: 4  VirtAddr: 0x00B8D33C RVA: 0x00B8D33C token: 100691381 methodIndex: 25085 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void UpdateHpBar()
    {
        //
        // Disasemble & Code
        // 0x00B8D33C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D340 (12112704), len: 4  VirtAddr: 0x00B8D340 RVA: 0x00B8D340 token: 100691382 methodIndex: 25086 delegateWrapperIndex: 0 methodInvoker: 0
    public override void CalcuFinalProp()
    {
        //
        // Disasemble & Code
        // 0x00B8D340: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D344 (12112708), len: 4  VirtAddr: 0x00B8D344 RVA: 0x00B8D344 token: 100691383 methodIndex: 25087 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Update()
    {
        //
        // Disasemble & Code
        // 0x00B8D344: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D348 (12112712), len: 260  VirtAddr: 0x00B8D348 RVA: 0x00B8D348 token: 100691384 methodIndex: 25088 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B8D348: STP x24, x23, [sp, #-0x40]! | stack[1152921514653707968] = ???;  stack[1152921514653707976] = ???;  //  dest_result_addr=1152921514653707968 |  dest_result_addr=1152921514653707976
        // 0x00B8D34C: STP x22, x21, [sp, #0x10]  | stack[1152921514653707984] = ???;  stack[1152921514653707992] = ???;  //  dest_result_addr=1152921514653707984 |  dest_result_addr=1152921514653707992
        // 0x00B8D350: STP x20, x19, [sp, #0x20]  | stack[1152921514653708000] = ???;  stack[1152921514653708008] = ???;  //  dest_result_addr=1152921514653708000 |  dest_result_addr=1152921514653708008
        // 0x00B8D354: STP x29, x30, [sp, #0x30]  | stack[1152921514653708016] = ???;  stack[1152921514653708024] = ???;  //  dest_result_addr=1152921514653708016 |  dest_result_addr=1152921514653708024
        // 0x00B8D358: ADD x29, sp, #0x30         | X29 = (1152921514653707968 + 48) = 1152921514653708016 (0x1000000256D6EEF0);
        // 0x00B8D35C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8D360: LDRB w8, [x20, #0xa18]     | W8 = (bool)static_value_03733A18;       
        // 0x00B8D364: MOV x19, x0                | X19 = 1152921514653720032 (0x1000000256D71DE0);//ML01
        // 0x00B8D368: TBNZ w8, #0, #0xb8d384     | if (static_value_03733A18 == true) goto label_0;
        // 0x00B8D36C: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
        // 0x00B8D370: LDR x8, [x8, #0x8f0]       | X8 = 0x2B8EFAC;                         
        // 0x00B8D374: LDR w0, [x8]               | W0 = 0x12AD;                            
        // 0x00B8D378: BL #0x2782188              | X0 = sub_2782188( ?? 0x12AD, ????);     
        // 0x00B8D37C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D380: STRB w8, [x20, #0xa18]     | static_value_03733A18 = true;            //  dest_result_addr=57883160
        label_0:
        // 0x00B8D384: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8D388: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00B8D38C: LDR x8, [x8, #0xc98]       | X8 = 1152921514652552128;               
        // 0x00B8D390: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00B8D394: LDR x21, [x8]              | X21 = public System.Void BarrierGat::EventOpened(CEvent.ZEvent ev);
        // 0x00B8D398: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00B8D39C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8D3A0: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00B8D3A4: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00B8D3A8: MOV x1, x19                | X1 = 1152921514653720032 (0x1000000256D71DE0);//ML01
        // 0x00B8D3AC: MOV x2, x21                | X2 = 1152921514652552128 (0x1000000256C54BC0);//ML01
        // 0x00B8D3B0: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8D3B4: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8D3B8: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void BarrierGat::EventOpened(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void BarrierGat::EventOpened(CEvent.ZEvent ev));
        // 0x00B8D3BC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B8D3C0: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B8D3C4: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B8D3C8: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B8D3CC: TBZ w8, #0, #0xb8d3dc      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8D3D0: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B8D3D4: CBNZ w8, #0xb8d3dc         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8D3D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00B8D3DC: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B8D3E0: LDR x8, [x8, #0x9c0]       | X8 = (string**)(1152921510361988960)("BATTLE_START");
        // 0x00B8D3E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D3E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8D3EC: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8D3F0: LDR x1, [x8]               | X1 = "BATTLE_START";                    
        // 0x00B8D3F4: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_START");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_START");
        // 0x00B8D3F8: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
        // 0x00B8D3FC: LDR x8, [x8, #0xe8]        | X8 = 1152921514652553152;               
        // 0x00B8D400: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00B8D404: LDR x20, [x8]              | X20 = public System.Void BarrierGat::EventClosed(CEvent.ZEvent ev);
        // 0x00B8D408: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00B8D40C: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00B8D410: MOV x1, x19                | X1 = 1152921514653720032 (0x1000000256D71DE0);//ML01
        // 0x00B8D414: MOV x2, x20                | X2 = 1152921514652553152 (0x1000000256C54FC0);//ML01
        // 0x00B8D418: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8D41C: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void BarrierGat::EventClosed(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void BarrierGat::EventClosed(CEvent.ZEvent ev));
        // 0x00B8D420: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B8D424: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921510361990080)("BATTLE_ENDED");
        // 0x00B8D428: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00B8D42C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D430: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8D434: LDR x1, [x8]               | X1 = "BATTLE_ENDED";                    
        // 0x00B8D438: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D43C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D440: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D444: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B8D448: B #0xd77798                | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_ENDED"); return;
        CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  "BATTLE_ENDED");
        return;
    
    }

}
