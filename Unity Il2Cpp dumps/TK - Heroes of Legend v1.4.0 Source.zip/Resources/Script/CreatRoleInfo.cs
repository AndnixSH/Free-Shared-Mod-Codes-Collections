using UnityEngine;

namespace Mihua.SDK
{
    public class CreatRoleInfo
    {
        // Fields
        public string roleId; //  0x00000010
        public string roleName; //  0x00000018
        public string roleLv; //  0x00000020
        public string serverId; //  0x00000028
        public string serverName; //  0x00000030
        public string CreatRoleTime; //  0x00000038
        public string LvUpTime; //  0x00000040
        public string Balance; //  0x00000048
        public string VipLevel; //  0x00000050
        public string unionName; //  0x00000058
        public string welcomeAddress; //  0x00000060
        public string GoldID; //  0x00000068
        public string curGlodNum; //  0x00000070
        public string Power; //  0x00000078
        public string UnionID; //  0x00000080
        public string BuddyListToJson_360; //  0x00000088
        public string SDKtoken; //  0x00000090
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AC0C28 (11275304), len: 8  VirtAddr: 0x00AC0C28 RVA: 0x00AC0C28 token: 100696319 methodIndex: 47167 delegateWrapperIndex: 0 methodInvoker: 0
        public CreatRoleInfo()
        {
            //
            // Disasemble & Code
            // 0x00AC0C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AC0C2C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AC0C30 (11275312), len: 1392  VirtAddr: 0x00AC0C30 RVA: 0x00AC0C30 token: 100696320 methodIndex: 47168 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.SDK.CreatRoleInfo Parse(object[] crtRoleOjs)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x00AC0C30: STP x22, x21, [sp, #-0x30]! | stack[1152921515513591728] = ???;  stack[1152921515513591736] = ???;  //  dest_result_addr=1152921515513591728 |  dest_result_addr=1152921515513591736
            // 0x00AC0C34: STP x20, x19, [sp, #0x10]  | stack[1152921515513591744] = ???;  stack[1152921515513591752] = ???;  //  dest_result_addr=1152921515513591744 |  dest_result_addr=1152921515513591752
            // 0x00AC0C38: STP x29, x30, [sp, #0x20]  | stack[1152921515513591760] = ???;  stack[1152921515513591768] = ???;  //  dest_result_addr=1152921515513591760 |  dest_result_addr=1152921515513591768
            // 0x00AC0C3C: ADD x29, sp, #0x20         | X29 = (1152921515513591728 + 32) = 1152921515513591760 (0x100000028A17B7D0);
            // 0x00AC0C40: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AC0C44: LDRB w8, [x19, #0x477]     | W8 = (bool)static_value_03733477;       
            // 0x00AC0C48: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00AC0C4C: TBNZ w8, #0, #0xac0c68     | if (static_value_03733477 == true) goto label_0;
            // 0x00AC0C50: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00AC0C54: LDR x8, [x8, #0x5b8]       | X8 = 0x2B92DE0;                         
            // 0x00AC0C58: LDR w0, [x8]               | W0 = 0x223D;                            
            // 0x00AC0C5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x223D, ????);     
            // 0x00AC0C60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AC0C64: STRB w8, [x19, #0x477]     | static_value_03733477 = true;            //  dest_result_addr=57881719
            label_0:
            // 0x00AC0C68: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x00AC0C6C: LDR x8, [x8, #0xe30]       | X8 = 1152921504920264704;               
            // 0x00AC0C70: LDR x0, [x8]               | X0 = typeof(Mihua.SDK.CreatRoleInfo);   
            object val_1 = null;
            // 0x00AC0C74: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.SDK.CreatRoleInfo), ????);
            // 0x00AC0C78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_2 = 0;
            // 0x00AC0C7C: MOV x19, x0                | X19 = 1152921504920264704 (0x1000000012AE6000);//ML01
            // 0x00AC0C80: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x00AC0C84: CBNZ x20, #0xac0c8c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00AC0C88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x00AC0C8C: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0C90: CBNZ w8, #0xac0ca0         | if (X1 + 24 != 0) goto label_2;         
            if((X1 + 24) != 0)
            {
                goto label_2;
            }
            // 0x00AC0C94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x00AC0C98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_2 = 0;
            // 0x00AC0C9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_2:
            // 0x00AC0CA0: LDR x21, [x20, #0x20]      | X21 = X1 + 32;                          
            // 0x00AC0CA4: CBNZ x21, #0xac0cac        | if (X1 + 32 != 0) goto label_3;         
            if((X1 + 32) != 0)
            {
                goto label_3;
            }
            // 0x00AC0CA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x00AC0CAC: LDR x8, [x21]              | X8 = X1 + 32;                           
            // 0x00AC0CB0: MOV x0, x21                | X0 = X1 + 32;//m1                       
            // 0x00AC0CB4: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 32 + 320; X1 = X1 + 32 + 320 + 8; //  | 
            val_3 = mem[X1 + 32 + 320 + 8];
            val_3 = X1 + 32 + 320 + 8;
            // 0x00AC0CB8: BLR x9                     | X0 = X1 + 32 + 320();                   
            // 0x00AC0CBC: MOV x21, x0                | X21 = X1 + 32;//m1                      
            // 0x00AC0CC0: CBNZ x19, #0xac0cc8        | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x00AC0CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 32, ????);    
            label_4:
            // 0x00AC0CC8: STR x21, [x19, #0x10]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_10 = X1 + 32;  //  dest_result_addr=1152921504920264720
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_10 = X1 + 32;
            // 0x00AC0CCC: CBNZ x20, #0xac0cd4        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00AC0CD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 32, ????);    
            label_5:
            // 0x00AC0CD4: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0CD8: CMP w8, #1                 | STATE = COMPARE(X1 + 24, 0x1)           
            // 0x00AC0CDC: B.HI #0xac0cec             | if (X1 + 24 > 0x1) goto label_6;        
            if((X1 + 24) > 1)
            {
                goto label_6;
            }
            // 0x00AC0CE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 32, ????);    
            // 0x00AC0CE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x00AC0CE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 32, ????);    
            label_6:
            // 0x00AC0CEC: LDR x21, [x20, #0x28]      | X21 = X1 + 40;                          
            // 0x00AC0CF0: CBNZ x21, #0xac0cf8        | if (X1 + 40 != 0) goto label_7;         
            if((X1 + 40) != 0)
            {
                goto label_7;
            }
            // 0x00AC0CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 32, ????);    
            label_7:
            // 0x00AC0CF8: LDR x8, [x21]              | X8 = X1 + 40;                           
            // 0x00AC0CFC: MOV x0, x21                | X0 = X1 + 40;//m1                       
            // 0x00AC0D00: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 40 + 320; X1 = X1 + 40 + 320 + 8; //  | 
            val_4 = mem[X1 + 40 + 320 + 8];
            val_4 = X1 + 40 + 320 + 8;
            // 0x00AC0D04: BLR x9                     | X0 = X1 + 40 + 320();                   
            // 0x00AC0D08: MOV x21, x0                | X21 = X1 + 40;//m1                      
            // 0x00AC0D0C: CBNZ x19, #0xac0d14        | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x00AC0D10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 40, ????);    
            label_8:
            // 0x00AC0D14: STR x21, [x19, #0x18]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_18 = X1 + 40;  //  dest_result_addr=1152921504920264728
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_18 = X1 + 40;
            // 0x00AC0D18: CBNZ x20, #0xac0d20        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00AC0D1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 40, ????);    
            label_9:
            // 0x00AC0D20: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0D24: CMP w8, #2                 | STATE = COMPARE(X1 + 24, 0x2)           
            // 0x00AC0D28: B.HI #0xac0d38             | if (X1 + 24 > 0x2) goto label_10;       
            if((X1 + 24) > 2)
            {
                goto label_10;
            }
            // 0x00AC0D2C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 40, ????);    
            // 0x00AC0D30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_4 = 0;
            // 0x00AC0D34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 40, ????);    
            label_10:
            // 0x00AC0D38: LDR x21, [x20, #0x30]      | X21 = X1 + 48;                          
            // 0x00AC0D3C: CBNZ x21, #0xac0d44        | if (X1 + 48 != 0) goto label_11;        
            if((X1 + 48) != 0)
            {
                goto label_11;
            }
            // 0x00AC0D40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 40, ????);    
            label_11:
            // 0x00AC0D44: LDR x8, [x21]              | X8 = X1 + 48;                           
            // 0x00AC0D48: MOV x0, x21                | X0 = X1 + 48;//m1                       
            // 0x00AC0D4C: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 48 + 320; X1 = X1 + 48 + 320 + 8; //  | 
            val_5 = mem[X1 + 48 + 320 + 8];
            val_5 = X1 + 48 + 320 + 8;
            // 0x00AC0D50: BLR x9                     | X0 = X1 + 48 + 320();                   
            // 0x00AC0D54: MOV x21, x0                | X21 = X1 + 48;//m1                      
            // 0x00AC0D58: CBNZ x19, #0xac0d60        | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x00AC0D5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 48, ????);    
            label_12:
            // 0x00AC0D60: STR x21, [x19, #0x20]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_20 = X1 + 48;  //  dest_result_addr=1152921504920264736
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_20 = X1 + 48;
            // 0x00AC0D64: CBNZ x20, #0xac0d6c        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00AC0D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 48, ????);    
            label_13:
            // 0x00AC0D6C: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0D70: CMP w8, #3                 | STATE = COMPARE(X1 + 24, 0x3)           
            // 0x00AC0D74: B.HI #0xac0d84             | if (X1 + 24 > 0x3) goto label_14;       
            if((X1 + 24) > 3)
            {
                goto label_14;
            }
            // 0x00AC0D78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 48, ????);    
            // 0x00AC0D7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AC0D80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 48, ????);    
            label_14:
            // 0x00AC0D84: LDR x21, [x20, #0x38]      | X21 = X1 + 56;                          
            // 0x00AC0D88: CBNZ x21, #0xac0d90        | if (X1 + 56 != 0) goto label_15;        
            if((X1 + 56) != 0)
            {
                goto label_15;
            }
            // 0x00AC0D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 48, ????);    
            label_15:
            // 0x00AC0D90: LDR x8, [x21]              | X8 = X1 + 56;                           
            // 0x00AC0D94: MOV x0, x21                | X0 = X1 + 56;//m1                       
            // 0x00AC0D98: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 56 + 320; X1 = X1 + 56 + 320 + 8; //  | 
            val_6 = mem[X1 + 56 + 320 + 8];
            val_6 = X1 + 56 + 320 + 8;
            // 0x00AC0D9C: BLR x9                     | X0 = X1 + 56 + 320();                   
            // 0x00AC0DA0: MOV x21, x0                | X21 = X1 + 56;//m1                      
            // 0x00AC0DA4: CBNZ x19, #0xac0dac        | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x00AC0DA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 56, ????);    
            label_16:
            // 0x00AC0DAC: STR x21, [x19, #0x28]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_28 = X1 + 56;  //  dest_result_addr=1152921504920264744
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_28 = X1 + 56;
            // 0x00AC0DB0: CBNZ x20, #0xac0db8        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00AC0DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 56, ????);    
            label_17:
            // 0x00AC0DB8: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0DBC: CMP w8, #4                 | STATE = COMPARE(X1 + 24, 0x4)           
            // 0x00AC0DC0: B.HI #0xac0dd0             | if (X1 + 24 > 0x4) goto label_18;       
            if((X1 + 24) > 4)
            {
                goto label_18;
            }
            // 0x00AC0DC4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 56, ????);    
            // 0x00AC0DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_6 = 0;
            // 0x00AC0DCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 56, ????);    
            label_18:
            // 0x00AC0DD0: LDR x21, [x20, #0x40]      | X21 = X1 + 64;                          
            // 0x00AC0DD4: CBNZ x21, #0xac0ddc        | if (X1 + 64 != 0) goto label_19;        
            if((X1 + 64) != 0)
            {
                goto label_19;
            }
            // 0x00AC0DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 56, ????);    
            label_19:
            // 0x00AC0DDC: LDR x8, [x21]              | X8 = X1 + 64;                           
            // 0x00AC0DE0: MOV x0, x21                | X0 = X1 + 64;//m1                       
            // 0x00AC0DE4: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 64 + 320; X1 = X1 + 64 + 320 + 8; //  | 
            val_7 = mem[X1 + 64 + 320 + 8];
            val_7 = X1 + 64 + 320 + 8;
            // 0x00AC0DE8: BLR x9                     | X0 = X1 + 64 + 320();                   
            // 0x00AC0DEC: MOV x21, x0                | X21 = X1 + 64;//m1                      
            // 0x00AC0DF0: CBNZ x19, #0xac0df8        | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x00AC0DF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 64, ????);    
            label_20:
            // 0x00AC0DF8: STR x21, [x19, #0x30]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_30 = X1 + 64;  //  dest_result_addr=1152921504920264752
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_30 = X1 + 64;
            // 0x00AC0DFC: CBNZ x20, #0xac0e04        | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x00AC0E00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 64, ????);    
            label_21:
            // 0x00AC0E04: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0E08: CMP w8, #5                 | STATE = COMPARE(X1 + 24, 0x5)           
            // 0x00AC0E0C: B.HI #0xac0e1c             | if (X1 + 24 > 0x5) goto label_22;       
            if((X1 + 24) > 5)
            {
                goto label_22;
            }
            // 0x00AC0E10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 64, ????);    
            // 0x00AC0E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x00AC0E18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 64, ????);    
            label_22:
            // 0x00AC0E1C: LDR x21, [x20, #0x48]      | X21 = X1 + 72;                          
            // 0x00AC0E20: CBNZ x21, #0xac0e28        | if (X1 + 72 != 0) goto label_23;        
            if((X1 + 72) != 0)
            {
                goto label_23;
            }
            // 0x00AC0E24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 64, ????);    
            label_23:
            // 0x00AC0E28: LDR x8, [x21]              | X8 = X1 + 72;                           
            // 0x00AC0E2C: MOV x0, x21                | X0 = X1 + 72;//m1                       
            // 0x00AC0E30: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 72 + 320; X1 = X1 + 72 + 320 + 8; //  | 
            val_8 = mem[X1 + 72 + 320 + 8];
            val_8 = X1 + 72 + 320 + 8;
            // 0x00AC0E34: BLR x9                     | X0 = X1 + 72 + 320();                   
            // 0x00AC0E38: MOV x21, x0                | X21 = X1 + 72;//m1                      
            // 0x00AC0E3C: CBNZ x19, #0xac0e44        | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x00AC0E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 72, ????);    
            label_24:
            // 0x00AC0E44: STR x21, [x19, #0x38]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_38 = X1 + 72;  //  dest_result_addr=1152921504920264760
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_38 = X1 + 72;
            // 0x00AC0E48: CBNZ x20, #0xac0e50        | if (X1 != 0) goto label_25;             
            if(X1 != 0)
            {
                goto label_25;
            }
            // 0x00AC0E4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 72, ????);    
            label_25:
            // 0x00AC0E50: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0E54: CMP w8, #6                 | STATE = COMPARE(X1 + 24, 0x6)           
            // 0x00AC0E58: B.HI #0xac0e68             | if (X1 + 24 > 0x6) goto label_26;       
            if((X1 + 24) > 6)
            {
                goto label_26;
            }
            // 0x00AC0E5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 72, ????);    
            // 0x00AC0E60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x00AC0E64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 72, ????);    
            label_26:
            // 0x00AC0E68: LDR x21, [x20, #0x50]      | X21 = X1 + 80;                          
            // 0x00AC0E6C: CBNZ x21, #0xac0e74        | if (X1 + 80 != 0) goto label_27;        
            if((X1 + 80) != 0)
            {
                goto label_27;
            }
            // 0x00AC0E70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 72, ????);    
            label_27:
            // 0x00AC0E74: LDR x8, [x21]              | X8 = X1 + 80;                           
            // 0x00AC0E78: MOV x0, x21                | X0 = X1 + 80;//m1                       
            // 0x00AC0E7C: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 80 + 320; X1 = X1 + 80 + 320 + 8; //  | 
            val_9 = mem[X1 + 80 + 320 + 8];
            val_9 = X1 + 80 + 320 + 8;
            // 0x00AC0E80: BLR x9                     | X0 = X1 + 80 + 320();                   
            // 0x00AC0E84: MOV x21, x0                | X21 = X1 + 80;//m1                      
            // 0x00AC0E88: CBNZ x19, #0xac0e90        | if ( != 0) goto label_28;               
            if(null != 0)
            {
                goto label_28;
            }
            // 0x00AC0E8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 80, ????);    
            label_28:
            // 0x00AC0E90: STR x21, [x19, #0x40]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_40 = X1 + 80;  //  dest_result_addr=1152921504920264768
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_40 = X1 + 80;
            // 0x00AC0E94: CBNZ x20, #0xac0e9c        | if (X1 != 0) goto label_29;             
            if(X1 != 0)
            {
                goto label_29;
            }
            // 0x00AC0E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 80, ????);    
            label_29:
            // 0x00AC0E9C: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0EA0: CMP w8, #7                 | STATE = COMPARE(X1 + 24, 0x7)           
            // 0x00AC0EA4: B.HI #0xac0eb4             | if (X1 + 24 > 0x7) goto label_30;       
            if((X1 + 24) > 7)
            {
                goto label_30;
            }
            // 0x00AC0EA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 80, ????);    
            // 0x00AC0EAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x00AC0EB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 80, ????);    
            label_30:
            // 0x00AC0EB4: LDR x21, [x20, #0x58]      | X21 = X1 + 88;                          
            // 0x00AC0EB8: CBNZ x21, #0xac0ec0        | if (X1 + 88 != 0) goto label_31;        
            if((X1 + 88) != 0)
            {
                goto label_31;
            }
            // 0x00AC0EBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 80, ????);    
            label_31:
            // 0x00AC0EC0: LDR x8, [x21]              | X8 = X1 + 88;                           
            // 0x00AC0EC4: MOV x0, x21                | X0 = X1 + 88;//m1                       
            // 0x00AC0EC8: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 88 + 320; X1 = X1 + 88 + 320 + 8; //  | 
            val_10 = mem[X1 + 88 + 320 + 8];
            val_10 = X1 + 88 + 320 + 8;
            // 0x00AC0ECC: BLR x9                     | X0 = X1 + 88 + 320();                   
            // 0x00AC0ED0: MOV x21, x0                | X21 = X1 + 88;//m1                      
            // 0x00AC0ED4: CBNZ x19, #0xac0edc        | if ( != 0) goto label_32;               
            if(null != 0)
            {
                goto label_32;
            }
            // 0x00AC0ED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 88, ????);    
            label_32:
            // 0x00AC0EDC: STR x21, [x19, #0x48]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_48 = X1 + 88;  //  dest_result_addr=1152921504920264776
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_48 = X1 + 88;
            // 0x00AC0EE0: CBNZ x20, #0xac0ee8        | if (X1 != 0) goto label_33;             
            if(X1 != 0)
            {
                goto label_33;
            }
            // 0x00AC0EE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 88, ????);    
            label_33:
            // 0x00AC0EE8: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0EEC: CMP w8, #8                 | STATE = COMPARE(X1 + 24, 0x8)           
            // 0x00AC0EF0: B.HI #0xac0f00             | if (X1 + 24 > 0x8) goto label_34;       
            if((X1 + 24) > 8)
            {
                goto label_34;
            }
            // 0x00AC0EF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 88, ????);    
            // 0x00AC0EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x00AC0EFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 88, ????);    
            label_34:
            // 0x00AC0F00: LDR x21, [x20, #0x60]      | X21 = X1 + 96;                          
            // 0x00AC0F04: CBNZ x21, #0xac0f0c        | if (X1 + 96 != 0) goto label_35;        
            if((X1 + 96) != 0)
            {
                goto label_35;
            }
            // 0x00AC0F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 88, ????);    
            label_35:
            // 0x00AC0F0C: LDR x8, [x21]              | X8 = X1 + 96;                           
            // 0x00AC0F10: MOV x0, x21                | X0 = X1 + 96;//m1                       
            // 0x00AC0F14: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 96 + 320; X1 = X1 + 96 + 320 + 8; //  | 
            val_11 = mem[X1 + 96 + 320 + 8];
            val_11 = X1 + 96 + 320 + 8;
            // 0x00AC0F18: BLR x9                     | X0 = X1 + 96 + 320();                   
            // 0x00AC0F1C: MOV x21, x0                | X21 = X1 + 96;//m1                      
            // 0x00AC0F20: CBNZ x19, #0xac0f28        | if ( != 0) goto label_36;               
            if(null != 0)
            {
                goto label_36;
            }
            // 0x00AC0F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 96, ????);    
            label_36:
            // 0x00AC0F28: STR x21, [x19, #0x50]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_50 = X1 + 96;  //  dest_result_addr=1152921504920264784
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_50 = X1 + 96;
            // 0x00AC0F2C: CBNZ x20, #0xac0f34        | if (X1 != 0) goto label_37;             
            if(X1 != 0)
            {
                goto label_37;
            }
            // 0x00AC0F30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 96, ????);    
            label_37:
            // 0x00AC0F34: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0F38: CMP w8, #9                 | STATE = COMPARE(X1 + 24, 0x9)           
            // 0x00AC0F3C: B.HI #0xac0f4c             | if (X1 + 24 > 0x9) goto label_38;       
            if((X1 + 24) > 9)
            {
                goto label_38;
            }
            // 0x00AC0F40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 96, ????);    
            // 0x00AC0F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_11 = 0;
            // 0x00AC0F48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 96, ????);    
            label_38:
            // 0x00AC0F4C: LDR x21, [x20, #0x68]      | X21 = X1 + 104;                         
            // 0x00AC0F50: CBNZ x21, #0xac0f58        | if (X1 + 104 != 0) goto label_39;       
            if((X1 + 104) != 0)
            {
                goto label_39;
            }
            // 0x00AC0F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 96, ????);    
            label_39:
            // 0x00AC0F58: LDR x8, [x21]              | X8 = X1 + 104;                          
            // 0x00AC0F5C: MOV x0, x21                | X0 = X1 + 104;//m1                      
            // 0x00AC0F60: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 104 + 320; X1 = X1 + 104 + 320 + 8; //  | 
            val_12 = mem[X1 + 104 + 320 + 8];
            val_12 = X1 + 104 + 320 + 8;
            // 0x00AC0F64: BLR x9                     | X0 = X1 + 104 + 320();                  
            // 0x00AC0F68: MOV x21, x0                | X21 = X1 + 104;//m1                     
            // 0x00AC0F6C: CBNZ x19, #0xac0f74        | if ( != 0) goto label_40;               
            if(null != 0)
            {
                goto label_40;
            }
            // 0x00AC0F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 104, ????);   
            label_40:
            // 0x00AC0F74: STR x21, [x19, #0x58]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_58 = X1 + 104;  //  dest_result_addr=1152921504920264792
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_58 = X1 + 104;
            // 0x00AC0F78: CBNZ x20, #0xac0f80        | if (X1 != 0) goto label_41;             
            if(X1 != 0)
            {
                goto label_41;
            }
            // 0x00AC0F7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 104, ????);   
            label_41:
            // 0x00AC0F80: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0F84: CMP w8, #0xa               | STATE = COMPARE(X1 + 24, 0xA)           
            // 0x00AC0F88: B.HI #0xac0f98             | if (X1 + 24 > 0xA) goto label_42;       
            if((X1 + 24) > 10)
            {
                goto label_42;
            }
            // 0x00AC0F8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 104, ????);   
            // 0x00AC0F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x00AC0F94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 104, ????);   
            label_42:
            // 0x00AC0F98: LDR x21, [x20, #0x70]      | X21 = X1 + 112;                         
            // 0x00AC0F9C: CBNZ x21, #0xac0fa4        | if (X1 + 112 != 0) goto label_43;       
            if((X1 + 112) != 0)
            {
                goto label_43;
            }
            // 0x00AC0FA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 104, ????);   
            label_43:
            // 0x00AC0FA4: LDR x8, [x21]              | X8 = X1 + 112;                          
            // 0x00AC0FA8: MOV x0, x21                | X0 = X1 + 112;//m1                      
            // 0x00AC0FAC: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 112 + 320; X1 = X1 + 112 + 320 + 8; //  | 
            val_13 = mem[X1 + 112 + 320 + 8];
            val_13 = X1 + 112 + 320 + 8;
            // 0x00AC0FB0: BLR x9                     | X0 = X1 + 112 + 320();                  
            // 0x00AC0FB4: MOV x21, x0                | X21 = X1 + 112;//m1                     
            // 0x00AC0FB8: CBNZ x19, #0xac0fc0        | if ( != 0) goto label_44;               
            if(null != 0)
            {
                goto label_44;
            }
            // 0x00AC0FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 112, ????);   
            label_44:
            // 0x00AC0FC0: STR x21, [x19, #0x60]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_60 = X1 + 112;  //  dest_result_addr=1152921504920264800
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_60 = X1 + 112;
            // 0x00AC0FC4: CBNZ x20, #0xac0fcc        | if (X1 != 0) goto label_45;             
            if(X1 != 0)
            {
                goto label_45;
            }
            // 0x00AC0FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 112, ????);   
            label_45:
            // 0x00AC0FCC: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC0FD0: CMP w8, #0xb               | STATE = COMPARE(X1 + 24, 0xB)           
            // 0x00AC0FD4: B.HI #0xac0fe4             | if (X1 + 24 > 0xB) goto label_46;       
            if((X1 + 24) > 11)
            {
                goto label_46;
            }
            // 0x00AC0FD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 112, ????);   
            // 0x00AC0FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_13 = 0;
            // 0x00AC0FE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 112, ????);   
            label_46:
            // 0x00AC0FE4: LDR x21, [x20, #0x78]      | X21 = X1 + 120;                         
            // 0x00AC0FE8: CBNZ x21, #0xac0ff0        | if (X1 + 120 != 0) goto label_47;       
            if((X1 + 120) != 0)
            {
                goto label_47;
            }
            // 0x00AC0FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 112, ????);   
            label_47:
            // 0x00AC0FF0: LDR x8, [x21]              | X8 = X1 + 120;                          
            // 0x00AC0FF4: MOV x0, x21                | X0 = X1 + 120;//m1                      
            // 0x00AC0FF8: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 120 + 320; X1 = X1 + 120 + 320 + 8; //  | 
            val_14 = mem[X1 + 120 + 320 + 8];
            val_14 = X1 + 120 + 320 + 8;
            // 0x00AC0FFC: BLR x9                     | X0 = X1 + 120 + 320();                  
            // 0x00AC1000: MOV x21, x0                | X21 = X1 + 120;//m1                     
            // 0x00AC1004: CBNZ x19, #0xac100c        | if ( != 0) goto label_48;               
            if(null != 0)
            {
                goto label_48;
            }
            // 0x00AC1008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 120, ????);   
            label_48:
            // 0x00AC100C: STR x21, [x19, #0x68]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_68 = X1 + 120;  //  dest_result_addr=1152921504920264808
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_68 = X1 + 120;
            // 0x00AC1010: CBNZ x20, #0xac1018        | if (X1 != 0) goto label_49;             
            if(X1 != 0)
            {
                goto label_49;
            }
            // 0x00AC1014: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 120, ????);   
            label_49:
            // 0x00AC1018: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC101C: CMP w8, #0xc               | STATE = COMPARE(X1 + 24, 0xC)           
            // 0x00AC1020: B.HI #0xac1030             | if (X1 + 24 > 0xC) goto label_50;       
            if((X1 + 24) > 12)
            {
                goto label_50;
            }
            // 0x00AC1024: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 120, ????);   
            // 0x00AC1028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_14 = 0;
            // 0x00AC102C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 120, ????);   
            label_50:
            // 0x00AC1030: LDR x21, [x20, #0x80]      | X21 = X1 + 128;                         
            // 0x00AC1034: CBNZ x21, #0xac103c        | if (X1 + 128 != 0) goto label_51;       
            if((X1 + 128) != 0)
            {
                goto label_51;
            }
            // 0x00AC1038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 120, ????);   
            label_51:
            // 0x00AC103C: LDR x8, [x21]              | X8 = X1 + 128;                          
            // 0x00AC1040: MOV x0, x21                | X0 = X1 + 128;//m1                      
            // 0x00AC1044: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 128 + 320; X1 = X1 + 128 + 320 + 8; //  | 
            val_15 = mem[X1 + 128 + 320 + 8];
            val_15 = X1 + 128 + 320 + 8;
            // 0x00AC1048: BLR x9                     | X0 = X1 + 128 + 320();                  
            // 0x00AC104C: MOV x21, x0                | X21 = X1 + 128;//m1                     
            // 0x00AC1050: CBNZ x19, #0xac1058        | if ( != 0) goto label_52;               
            if(null != 0)
            {
                goto label_52;
            }
            // 0x00AC1054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 128, ????);   
            label_52:
            // 0x00AC1058: STR x21, [x19, #0x70]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_70 = X1 + 128;  //  dest_result_addr=1152921504920264816
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_70 = X1 + 128;
            // 0x00AC105C: CBNZ x20, #0xac1064        | if (X1 != 0) goto label_53;             
            if(X1 != 0)
            {
                goto label_53;
            }
            // 0x00AC1060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 128, ????);   
            label_53:
            // 0x00AC1064: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC1068: CMP w8, #0xd               | STATE = COMPARE(X1 + 24, 0xD)           
            // 0x00AC106C: B.HI #0xac107c             | if (X1 + 24 > 0xD) goto label_54;       
            if((X1 + 24) > 13)
            {
                goto label_54;
            }
            // 0x00AC1070: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 128, ????);   
            // 0x00AC1074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_15 = 0;
            // 0x00AC1078: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 128, ????);   
            label_54:
            // 0x00AC107C: LDR x21, [x20, #0x88]      | X21 = X1 + 136;                         
            // 0x00AC1080: CBNZ x21, #0xac1088        | if (X1 + 136 != 0) goto label_55;       
            if((X1 + 136) != 0)
            {
                goto label_55;
            }
            // 0x00AC1084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 128, ????);   
            label_55:
            // 0x00AC1088: LDR x8, [x21]              | X8 = X1 + 136;                          
            // 0x00AC108C: MOV x0, x21                | X0 = X1 + 136;//m1                      
            // 0x00AC1090: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 136 + 320; X1 = X1 + 136 + 320 + 8; //  | 
            val_16 = mem[X1 + 136 + 320 + 8];
            val_16 = X1 + 136 + 320 + 8;
            // 0x00AC1094: BLR x9                     | X0 = X1 + 136 + 320();                  
            // 0x00AC1098: MOV x21, x0                | X21 = X1 + 136;//m1                     
            // 0x00AC109C: CBNZ x19, #0xac10a4        | if ( != 0) goto label_56;               
            if(null != 0)
            {
                goto label_56;
            }
            // 0x00AC10A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 136, ????);   
            label_56:
            // 0x00AC10A4: STR x21, [x19, #0x78]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_78 = X1 + 136;  //  dest_result_addr=1152921504920264824
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_78 = X1 + 136;
            // 0x00AC10A8: CBNZ x20, #0xac10b0        | if (X1 != 0) goto label_57;             
            if(X1 != 0)
            {
                goto label_57;
            }
            // 0x00AC10AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 136, ????);   
            label_57:
            // 0x00AC10B0: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC10B4: CMP w8, #0xe               | STATE = COMPARE(X1 + 24, 0xE)           
            // 0x00AC10B8: B.HI #0xac10c8             | if (X1 + 24 > 0xE) goto label_58;       
            if((X1 + 24) > 14)
            {
                goto label_58;
            }
            // 0x00AC10BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 136, ????);   
            // 0x00AC10C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_16 = 0;
            // 0x00AC10C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 136, ????);   
            label_58:
            // 0x00AC10C8: LDR x21, [x20, #0x90]      | X21 = X1 + 144;                         
            // 0x00AC10CC: CBNZ x21, #0xac10d4        | if (X1 + 144 != 0) goto label_59;       
            if((X1 + 144) != 0)
            {
                goto label_59;
            }
            // 0x00AC10D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 136, ????);   
            label_59:
            // 0x00AC10D4: LDR x8, [x21]              | X8 = X1 + 144;                          
            // 0x00AC10D8: MOV x0, x21                | X0 = X1 + 144;//m1                      
            // 0x00AC10DC: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 144 + 320; X1 = X1 + 144 + 320 + 8; //  | 
            val_17 = mem[X1 + 144 + 320 + 8];
            val_17 = X1 + 144 + 320 + 8;
            // 0x00AC10E0: BLR x9                     | X0 = X1 + 144 + 320();                  
            // 0x00AC10E4: MOV x21, x0                | X21 = X1 + 144;//m1                     
            // 0x00AC10E8: CBNZ x19, #0xac10f0        | if ( != 0) goto label_60;               
            if(null != 0)
            {
                goto label_60;
            }
            // 0x00AC10EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 144, ????);   
            label_60:
            // 0x00AC10F0: STR x21, [x19, #0x80]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_80 = X1 + 144;  //  dest_result_addr=1152921504920264832
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_80 = X1 + 144;
            // 0x00AC10F4: CBNZ x20, #0xac10fc        | if (X1 != 0) goto label_61;             
            if(X1 != 0)
            {
                goto label_61;
            }
            // 0x00AC10F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 144, ????);   
            label_61:
            // 0x00AC10FC: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC1100: CMP w8, #0xf               | STATE = COMPARE(X1 + 24, 0xF)           
            // 0x00AC1104: B.HI #0xac1114             | if (X1 + 24 > 0xF) goto label_62;       
            if((X1 + 24) > 15)
            {
                goto label_62;
            }
            // 0x00AC1108: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 144, ????);   
            // 0x00AC110C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x00AC1110: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 144, ????);   
            label_62:
            // 0x00AC1114: LDR x21, [x20, #0x98]      | X21 = X1 + 152;                         
            // 0x00AC1118: CBNZ x21, #0xac1120        | if (X1 + 152 != 0) goto label_63;       
            if((X1 + 152) != 0)
            {
                goto label_63;
            }
            // 0x00AC111C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 144, ????);   
            label_63:
            // 0x00AC1120: LDR x8, [x21]              | X8 = X1 + 152;                          
            // 0x00AC1124: MOV x0, x21                | X0 = X1 + 152;//m1                      
            // 0x00AC1128: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 152 + 320; X1 = X1 + 152 + 320 + 8; //  | 
            val_18 = mem[X1 + 152 + 320 + 8];
            val_18 = X1 + 152 + 320 + 8;
            // 0x00AC112C: BLR x9                     | X0 = X1 + 152 + 320();                  
            // 0x00AC1130: MOV x21, x0                | X21 = X1 + 152;//m1                     
            // 0x00AC1134: CBNZ x19, #0xac113c        | if ( != 0) goto label_64;               
            if(null != 0)
            {
                goto label_64;
            }
            // 0x00AC1138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 152, ????);   
            label_64:
            // 0x00AC113C: STR x21, [x19, #0x88]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_88 = X1 + 152;  //  dest_result_addr=1152921504920264840
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_88 = X1 + 152;
            // 0x00AC1140: CBNZ x20, #0xac1148        | if (X1 != 0) goto label_65;             
            if(X1 != 0)
            {
                goto label_65;
            }
            // 0x00AC1144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 152, ????);   
            label_65:
            // 0x00AC1148: LDR w8, [x20, #0x18]       | W8 = X1 + 24;                           
            // 0x00AC114C: CMP w8, #0x10              | STATE = COMPARE(X1 + 24, 0x10)          
            // 0x00AC1150: B.HI #0xac1160             | if (X1 + 24 > 0x10) goto label_66;      
            if((X1 + 24) > 16)
            {
                goto label_66;
            }
            // 0x00AC1154: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1 + 152, ????);   
            // 0x00AC1158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_18 = 0;
            // 0x00AC115C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1 + 152, ????);   
            label_66:
            // 0x00AC1160: LDR x20, [x20, #0xa0]      | X20 = X1 + 160;                         
            // 0x00AC1164: CBNZ x20, #0xac116c        | if (X1 + 160 != 0) goto label_67;       
            if((X1 + 160) != 0)
            {
                goto label_67;
            }
            // 0x00AC1168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 152, ????);   
            label_67:
            // 0x00AC116C: LDR x8, [x20]              | X8 = X1 + 160;                          
            // 0x00AC1170: MOV x0, x20                | X0 = X1 + 160;//m1                      
            // 0x00AC1174: LDP x9, x1, [x8, #0x140]   | X9 = X1 + 160 + 320; X1 = X1 + 160 + 320 + 8; //  | 
            // 0x00AC1178: BLR x9                     | X0 = X1 + 160 + 320();                  
            // 0x00AC117C: MOV x20, x0                | X20 = X1 + 160;//m1                     
            // 0x00AC1180: CBNZ x19, #0xac1188        | if ( != 0) goto label_68;               
            if(null != 0)
            {
                goto label_68;
            }
            // 0x00AC1184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1 + 160, ????);   
            label_68:
            // 0x00AC1188: STR x20, [x19, #0x90]      | typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_90 = X1 + 160;  //  dest_result_addr=1152921504920264848
            typeof(Mihua.SDK.CreatRoleInfo).__il2cppRuntimeField_90 = X1 + 160;
            // 0x00AC118C: MOV x0, x19                | X0 = 1152921504920264704 (0x1000000012AE6000);//ML01
            // 0x00AC1190: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AC1194: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AC1198: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AC119C: RET                        |  return (Mihua.SDK.CreatRoleInfo)typeof(Mihua.SDK.CreatRoleInfo);
            return (Mihua.SDK.CreatRoleInfo)val_1;
            //  |  // // {name=val_0, type=Mihua.SDK.CreatRoleInfo, size=8, nGRN=0 }
        
        }
    
    }

}
