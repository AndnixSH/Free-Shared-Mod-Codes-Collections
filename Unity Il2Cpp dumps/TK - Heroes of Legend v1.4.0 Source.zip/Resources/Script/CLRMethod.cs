using UnityEngine;

namespace ILRuntime.CLR.Method
{
    public class CLRMethod : IMethod
    {
        // Fields
        private System.Reflection.MethodInfo def; //  0x00000010
        private System.Reflection.ConstructorInfo cDef; //  0x00000018
        private System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> parameters; //  0x00000020
        private System.Reflection.ParameterInfo[] parametersCLR; //  0x00000028
        private ILRuntime.Runtime.Enviorment.AppDomain appdomain; //  0x00000030
        private ILRuntime.CLR.TypeSystem.CLRType declaringType; //  0x00000038
        private System.Reflection.ParameterInfo[] param; //  0x00000040
        private bool isConstructor; //  0x00000048
        private ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate redirect; //  0x00000050
        private ILRuntime.CLR.TypeSystem.IType[] genericArguments; //  0x00000058
        private System.Type[] genericArgumentsCLR; //  0x00000060
        private object[] invocationParam; //  0x00000068
        private bool isDelegateInvoke; //  0x00000070
        private int hashCode; //  0x00000074
        private static int instance_id; // static_offset: 0x00000000
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x281B5AC
        private ILRuntime.CLR.TypeSystem.IType <ReturnType>k__BackingField; //  0x00000078
        
        // Properties
        public ILRuntime.CLR.TypeSystem.IType DeclearingType { get; }
        public string Name { get; }
        public bool HasThis { get; }
        public int GenericParameterCount { get; }
        public bool IsGenericInstance { get; }
        public bool IsDelegateInvoke { get; }
        public bool IsStatic { get; }
        public ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate Redirection { get; }
        public System.Reflection.MethodInfo MethodInfo { get; }
        public System.Reflection.ConstructorInfo ConstructorInfo { get; }
        public ILRuntime.CLR.TypeSystem.IType[] GenericArguments { get; }
        public System.Type[] GenericArgumentsCLR { get; }
        public int ParameterCount { get; }
        public System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> Parameters { get; }
        public System.Reflection.ParameterInfo[] ParametersCLR { get; }
        public ILRuntime.CLR.TypeSystem.IType ReturnType { get; set; }
        public bool IsConstructor { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x010EC5AC (17745324), len: 788  VirtAddr: 0x010EC5AC RVA: 0x010EC5AC token: 100663316 methodIndex: 28761 delegateWrapperIndex: 0 methodInvoker: 0
        internal CLRMethod(System.Reflection.MethodInfo def, ILRuntime.CLR.TypeSystem.CLRType type, ILRuntime.Runtime.Enviorment.AppDomain domain)
        {
            //
            // Disasemble & Code
            //  | 
            string val_15;
            //  | 
            ILRuntime.CLR.TypeSystem.CLRType val_16;
            //  | 
            string val_17;
            // 0x010EC5AC: STP x24, x23, [sp, #-0x40]! | stack[1152921509980692960] = ???;  stack[1152921509980692968] = ???;  //  dest_result_addr=1152921509980692960 |  dest_result_addr=1152921509980692968
            // 0x010EC5B0: STP x22, x21, [sp, #0x10]  | stack[1152921509980692976] = ???;  stack[1152921509980692984] = ???;  //  dest_result_addr=1152921509980692976 |  dest_result_addr=1152921509980692984
            // 0x010EC5B4: STP x20, x19, [sp, #0x20]  | stack[1152921509980692992] = ???;  stack[1152921509980693000] = ???;  //  dest_result_addr=1152921509980692992 |  dest_result_addr=1152921509980693000
            // 0x010EC5B8: STP x29, x30, [sp, #0x30]  | stack[1152921509980693008] = ???;  stack[1152921509980693016] = ???;  //  dest_result_addr=1152921509980693008 |  dest_result_addr=1152921509980693016
            // 0x010EC5BC: ADD x29, sp, #0x30         | X29 = (1152921509980692960 + 48) = 1152921509980693008 (0x10000001404E6210);
            // 0x010EC5C0: ADRP x23, #0x3735000       | X23 = 57888768 (0x3735000);             
            // 0x010EC5C4: LDRB w8, [x23, #0xadd]     | W8 = (bool)static_value_03735ADD;       
            // 0x010EC5C8: MOV x22, x3                | X22 = domain;//m1                       
            // 0x010EC5CC: MOV x21, x2                | X21 = type;//m1                         
            val_16 = val_1;
            // 0x010EC5D0: MOV x19, x1                | X19 = def;//m1                          
            // 0x010EC5D4: MOV x20, x0                | X20 = 1152921509980705024 (0x10000001404E9100);//ML01
            // 0x010EC5D8: TBNZ w8, #0, #0x10ec5f4    | if (static_value_03735ADD == true) goto label_0;
            // 0x010EC5DC: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x010EC5E0: LDR x8, [x8, #0x340]       | X8 = 0x2B90C90;                         
            // 0x010EC5E4: LDR w0, [x8]               | W0 = 0x19E8;                            
            // 0x010EC5E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E8, ????);     
            // 0x010EC5EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EC5F0: STRB w8, [x23, #0xadd]     | static_value_03735ADD = true;            //  dest_result_addr=57891549
            label_0:
            // 0x010EC5F4: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x010EC5F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EC5FC: MOV x0, x20                | X0 = 1152921509980705024 (0x10000001404E9100);//ML01
            // 0x010EC600: STR w8, [x20, #0x74]       | this.hashCode = 0;                       //  dest_result_addr=1152921509980705140
            this.hashCode = 0;
            // 0x010EC604: BL #0x16f59f0              | type..ctor();                           
            val_1 = new System.Object();
            // 0x010EC608: STR x19, [x20, #0x10]      | this.def = def;                          //  dest_result_addr=1152921509980705040
            this.def = def;
            // 0x010EC60C: STP x22, x21, [x20, #0x30] | this.appdomain = domain;  this.declaringType = type;  //  dest_result_addr=1152921509980705072 |  dest_result_addr=1152921509980705080
            this.appdomain = domain;
            this.declaringType = val_16;
            // 0x010EC610: CBNZ x19, #0x10ec618       | if (def != null) goto label_1;          
            if(def != null)
            {
                goto label_1;
            }
            // 0x010EC614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type..ctor(), ????);
            label_1:
            // 0x010EC618: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC61C: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC620: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_200;
            // 0x010EC624: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_208;
            // 0x010EC628: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_200();
            // 0x010EC62C: STR x0, [x20, #0x40]       | this.param = def;                        //  dest_result_addr=1152921509980705088
            this.param = def;
            // 0x010EC630: CBNZ x19, #0x10ec638       | if (def != null) goto label_2;          
            if(def != null)
            {
                goto label_2;
            }
            // 0x010EC634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_2:
            // 0x010EC638: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC63C: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC640: LDR x9, [x8, #0x340]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_340;
            // 0x010EC644: LDR x1, [x8, #0x348]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_348;
            // 0x010EC648: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_340();
            // 0x010EC64C: AND w8, w0, #1             | W8 = (def & 1);                         
            System.Reflection.MethodInfo val_2 = def & 1;
            // 0x010EC650: TBNZ w8, #0, #0x10ec708    | if (((def & 1) & 0x1) != 0) goto label_6;
            if((val_2 & 1) != 0)
            {
                goto label_6;
            }
            // 0x010EC654: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC658: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC65C: LDR x9, [x8, #0x380]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_380;
            // 0x010EC660: LDR x1, [x8, #0x388]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_388;
            // 0x010EC664: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_380();
            // 0x010EC668: MOV x23, x0                | X23 = def;//m1                          
            // 0x010EC66C: CBNZ x23, #0x10ec674       | if (def != null) goto label_4;          
            if(def != null)
            {
                goto label_4;
            }
            // 0x010EC670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_4:
            // 0x010EC674: LDR x8, [x23]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC678: MOV x0, x23                | X0 = def;//m1                           
            // 0x010EC67C: LDR x9, [x8, #0x230]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_230;
            // 0x010EC680: LDR x1, [x8, #0x238]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_238;
            // 0x010EC684: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_230();
            // 0x010EC688: MOV x23, x0                | X23 = def;//m1                          
            val_15 = def;
            // 0x010EC68C: CBNZ x22, #0x10ec694       | if (domain != null) goto label_5;       
            if(domain != null)
            {
                goto label_5;
            }
            // 0x010EC690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_5:
            // 0x010EC694: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010EC698: MOV x0, x22                | X0 = domain;//m1                        
            // 0x010EC69C: MOV x1, x23                | X1 = def;//m1                           
            val_17 = val_15;
            // 0x010EC6A0: BL #0x28e4a68              | X0 = domain.GetType(fullname:  val_17 = val_15);
            ILRuntime.CLR.TypeSystem.IType val_3 = domain.GetType(fullname:  val_17);
            // 0x010EC6A4: STR x0, [x20, #0x78]       | this.<ReturnType>k__BackingField = val_3;  //  dest_result_addr=1152921509980705144
            this.<ReturnType>k__BackingField = val_3;
            // 0x010EC6A8: CBNZ x0, #0x10ec708        | if (val_3 != null) goto label_6;        
            if(val_3 != null)
            {
                goto label_6;
            }
            // 0x010EC6AC: CBNZ x19, #0x10ec6b4       | if (def != null) goto label_7;          
            if(def != null)
            {
                goto label_7;
            }
            // 0x010EC6B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x010EC6B4: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC6B8: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC6BC: LDR x9, [x8, #0x380]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_380;
            // 0x010EC6C0: LDR x1, [x8, #0x388]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_388;
            // 0x010EC6C4: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_380();
            // 0x010EC6C8: MOV x23, x0                | X23 = def;//m1                          
            // 0x010EC6CC: CBNZ x23, #0x10ec6d4       | if (def != null) goto label_8;          
            if(def != null)
            {
                goto label_8;
            }
            // 0x010EC6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_8:
            // 0x010EC6D4: LDR x8, [x23]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC6D8: MOV x0, x23                | X0 = def;//m1                           
            // 0x010EC6DC: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_200;
            // 0x010EC6E0: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_208;
            // 0x010EC6E4: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_200();
            // 0x010EC6E8: MOV x23, x0                | X23 = def;//m1                          
            val_15 = def;
            // 0x010EC6EC: CBNZ x22, #0x10ec6f4       | if (domain != null) goto label_9;       
            if(domain != null)
            {
                goto label_9;
            }
            // 0x010EC6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_9:
            // 0x010EC6F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010EC6F8: MOV x0, x22                | X0 = domain;//m1                        
            // 0x010EC6FC: MOV x1, x23                | X1 = def;//m1                           
            val_17 = val_15;
            // 0x010EC700: BL #0x28e4a68              | X0 = domain.GetType(fullname:  val_17 = val_15);
            ILRuntime.CLR.TypeSystem.IType val_4 = domain.GetType(fullname:  val_17);
            // 0x010EC704: STR x0, [x20, #0x78]       | this.<ReturnType>k__BackingField = val_4;  //  dest_result_addr=1152921509980705144
            this.<ReturnType>k__BackingField = val_4;
            label_6:
            // 0x010EC708: CBNZ x21, #0x10ec710       | if (type != null) goto label_10;        
            if(val_16 != null)
            {
                goto label_10;
            }
            // 0x010EC70C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_10:
            // 0x010EC710: LDRB w8, [x21, #0xb8]      | W8 = type.isDelegate; //P2              
            // 0x010EC714: CBZ w8, #0x10ec780         | if (type.isDelegate == false) goto label_15;
            if(type.isDelegate == false)
            {
                goto label_15;
            }
            // 0x010EC718: CBNZ x19, #0x10ec720       | if (def != null) goto label_12;         
            if(def != null)
            {
                goto label_12;
            }
            // 0x010EC71C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x010EC720: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC724: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC728: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_198; //  | 
            // 0x010EC72C: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190();
            // 0x010EC730: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x010EC734: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x010EC738: MOV x21, x0                | X21 = def;//m1                          
            val_16 = def;
            // 0x010EC73C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x010EC740: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x010EC744: TBZ w9, #0, #0x10ec758     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x010EC748: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x010EC74C: CBNZ w9, #0x10ec758        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x010EC750: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x010EC754: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_14:
            // 0x010EC758: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x010EC75C: LDR x8, [x8, #0xda0]       | X8 = (string**)(1152921509980655344)("Invoke");
            // 0x010EC760: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010EC764: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EC768: MOV x1, x21                | X1 = def;//m1                           
            // 0x010EC76C: LDR x2, [x8]               | X2 = "Invoke";                          
            // 0x010EC770: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_16);
            bool val_5 = System.String.op_Equality(a:  0, b:  val_16);
            // 0x010EC774: TBZ w0, #0, #0x10ec780     | if (val_5 == false) goto label_15;      
            if(val_5 == false)
            {
                goto label_15;
            }
            // 0x010EC778: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EC77C: STRB w8, [x20, #0x70]      | this.isDelegateInvoke = true;            //  dest_result_addr=1152921509980705136
            this.isDelegateInvoke = true;
            label_15:
            // 0x010EC780: STRB wzr, [x20, #0x48]     | this.isConstructor = false;              //  dest_result_addr=1152921509980705096
            this.isConstructor = false;
            // 0x010EC784: CBZ x19, #0x10ec874        | if (def == null) goto label_16;         
            if(def == null)
            {
                goto label_16;
            }
            // 0x010EC788: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC78C: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC790: LDR x9, [x8, #0x360]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_360;
            // 0x010EC794: LDR x1, [x8, #0x368]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_368;
            // 0x010EC798: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_360();
            // 0x010EC79C: TBZ w0, #0, #0x10ec7bc     | if ((def & 0x1) == 0) goto label_17;    
            if((def & 1) == 0)
            {
                goto label_17;
            }
            // 0x010EC7A0: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC7A4: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC7A8: LDR x9, [x8, #0x350]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_350;
            // 0x010EC7AC: LDR x1, [x8, #0x358]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_358;
            // 0x010EC7B0: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_350();
            // 0x010EC7B4: AND w8, w0, #1             | W8 = (def & 1);                         
            System.Reflection.MethodInfo val_6 = def & 1;
            // 0x010EC7B8: TBZ w8, #0, #0x10ec810     | if (((def & 1) & 0x1) == 0) goto label_18;
            if((val_6 & 1) == 0)
            {
                goto label_18;
            }
            label_17:
            // 0x010EC7BC: LDR x21, [x20, #0x30]      | X21 = this.appdomain; //P2              
            // 0x010EC7C0: CBNZ x21, #0x10ec7c8       | if (this.appdomain != null) goto label_19;
            if(this.appdomain != null)
            {
                goto label_19;
            }
            // 0x010EC7C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_19:
            // 0x010EC7C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EC7CC: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010EC7D0: BL #0x28e4338              | X0 = this.appdomain.get_RedirectMap();  
            System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate> val_7 = this.appdomain.RedirectMap;
            // 0x010EC7D4: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x010EC7D8: ADD x20, x20, #0x50        | X20 = this.redirect;//AP2 res_addr=1152921509980705104
            // 0x010EC7DC: CBNZ x21, #0x10ec7e4       | if (val_7 != null) goto label_20;       
            if(val_7 != null)
            {
                goto label_20;
            }
            // 0x010EC7E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_20:
            // 0x010EC7E4: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x010EC7E8: LDR x8, [x8, #0xb8]        | X8 = 1152921509980663616;               
            // 0x010EC7EC: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x010EC7F0: MOV x1, x19                | X1 = def;//m1                           
            // 0x010EC7F4: MOV x2, x20                | X2 = this.redirect;//m1                 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = this.redirect;
            // 0x010EC7F8: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate>::TryGetValue(System.Reflection.MethodBase key, out ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate value);
            label_26:
            // 0x010EC7FC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010EC800: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010EC804: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010EC808: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010EC80C: B #0x23fe7ec               | X0 = val_7.TryGetValue(key:  def, value: out  ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = this.redirect); return;
            bool val_9 = val_7.TryGetValue(key:  def, value: out  val_8);
            return;
            label_18:
            // 0x010EC810: LDR x21, [x20, #0x30]      | X21 = this.appdomain; //P2              
            // 0x010EC814: CBNZ x21, #0x10ec81c       | if (this.appdomain != null) goto label_21;
            if(this.appdomain != null)
            {
                goto label_21;
            }
            // 0x010EC818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_21:
            // 0x010EC81C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EC820: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010EC824: BL #0x28e4338              | X0 = this.appdomain.get_RedirectMap();  
            System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate> val_10 = this.appdomain.RedirectMap;
            // 0x010EC828: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EC82C: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x010EC830: MOV x0, x19                | X0 = def;//m1                           
            // 0x010EC834: LDR x9, [x8, #0x3a0]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_3A0;
            // 0x010EC838: LDR x1, [x8, #0x3a8]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_3A8;
            // 0x010EC83C: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_3A0();
            // 0x010EC840: MOV x23, x0                | X23 = def;//m1                          
            val_15 = def;
            // 0x010EC844: ADD x21, x20, #0x50        | X21 = this.redirect;//AP2 res_addr=1152921509980705104
            val_16 = this.redirect;
            // 0x010EC848: CBNZ x22, #0x10ec850       | if (val_10 != null) goto label_22;      
            if(val_10 != null)
            {
                goto label_22;
            }
            // 0x010EC84C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_22:
            // 0x010EC850: ADRP x24, #0x364a000       | X24 = 56926208 (0x364A000);             
            // 0x010EC854: LDR x24, [x24, #0xb8]      | X24 = 1152921509980663616;              
            // 0x010EC858: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x010EC85C: MOV x1, x23                | X1 = def;//m1                           
            // 0x010EC860: MOV x2, x21                | X2 = this.redirect;//m1                 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = val_16;
            // 0x010EC864: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate>::TryGetValue(System.Reflection.MethodBase key, out ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate value);
            // 0x010EC868: BL #0x23fe7ec              | X0 = val_10.TryGetValue(key:  val_15, value: out  ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = val_16);
            bool val_12 = val_10.TryGetValue(key:  val_15, value: out  val_11);
            // 0x010EC86C: AND w8, w0, #1             | W8 = (val_12 & 1);                      
            bool val_13 = val_12;
            // 0x010EC870: TBZ w8, #0, #0x10ec888     | if ((val_12 & 1) == false) goto label_23;
            if(val_13 == false)
            {
                goto label_23;
            }
            label_16:
            // 0x010EC874: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010EC878: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010EC87C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010EC880: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010EC884: RET                        |  return;                                
            return;
            label_23:
            // 0x010EC888: LDR x20, [x20, #0x30]      | X20 = this.appdomain; //P2              
            // 0x010EC88C: CBNZ x20, #0x10ec894       | if (this.appdomain != null) goto label_24;
            if(this.appdomain != null)
            {
                goto label_24;
            }
            // 0x010EC890: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_24:
            // 0x010EC894: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EC898: MOV x0, x20                | X0 = this.appdomain;//m1                
            // 0x010EC89C: BL #0x28e4338              | X0 = this.appdomain.get_RedirectMap();  
            System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate> val_14 = this.appdomain.RedirectMap;
            // 0x010EC8A0: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x010EC8A4: CBNZ x20, #0x10ec8ac       | if (val_14 != null) goto label_25;      
            if(val_14 != null)
            {
                goto label_25;
            }
            // 0x010EC8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_25:
            // 0x010EC8AC: LDR x3, [x24]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate>::TryGetValue(System.Reflection.MethodBase key, out ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate value);
            // 0x010EC8B0: MOV x0, x20                | X0 = val_14;//m1                        
            // 0x010EC8B4: MOV x1, x19                | X1 = def;//m1                           
            // 0x010EC8B8: MOV x2, x21                | X2 = this.redirect;//m1                 
            // 0x010EC8BC: B #0x10ec7fc               |  goto label_26;                         
            goto label_26;
        
        }
        //
        // Offset in libil2cpp.so: 0x010EC8D8 (17746136), len: 268  VirtAddr: 0x010EC8D8 RVA: 0x010EC8D8 token: 100663317 methodIndex: 28762 delegateWrapperIndex: 0 methodInvoker: 0
        internal CLRMethod(System.Reflection.ConstructorInfo def, ILRuntime.CLR.TypeSystem.CLRType type, ILRuntime.Runtime.Enviorment.AppDomain domain)
        {
            //
            // Disasemble & Code
            // 0x010EC8D8: STP x24, x23, [sp, #-0x40]! | stack[1152921509980874592] = ???;  stack[1152921509980874600] = ???;  //  dest_result_addr=1152921509980874592 |  dest_result_addr=1152921509980874600
            // 0x010EC8DC: STP x22, x21, [sp, #0x10]  | stack[1152921509980874608] = ???;  stack[1152921509980874616] = ???;  //  dest_result_addr=1152921509980874608 |  dest_result_addr=1152921509980874616
            // 0x010EC8E0: STP x20, x19, [sp, #0x20]  | stack[1152921509980874624] = ???;  stack[1152921509980874632] = ???;  //  dest_result_addr=1152921509980874624 |  dest_result_addr=1152921509980874632
            // 0x010EC8E4: STP x29, x30, [sp, #0x30]  | stack[1152921509980874640] = ???;  stack[1152921509980874648] = ???;  //  dest_result_addr=1152921509980874640 |  dest_result_addr=1152921509980874648
            // 0x010EC8E8: ADD x29, sp, #0x30         | X29 = (1152921509980874592 + 48) = 1152921509980874640 (0x1000000140512790);
            // 0x010EC8EC: ADRP x23, #0x3735000       | X23 = 57888768 (0x3735000);             
            // 0x010EC8F0: LDRB w8, [x23, #0xade]     | W8 = (bool)static_value_03735ADE;       
            // 0x010EC8F4: MOV x22, x3                | X22 = domain;//m1                       
            // 0x010EC8F8: MOV x20, x2                | X20 = type;//m1                         
            // 0x010EC8FC: MOV x21, x1                | X21 = def;//m1                          
            // 0x010EC900: MOV x19, x0                | X19 = 1152921509980886656 (0x1000000140515680);//ML01
            // 0x010EC904: TBNZ w8, #0, #0x10ec920    | if (static_value_03735ADE == true) goto label_0;
            // 0x010EC908: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x010EC90C: LDR x8, [x8, #0xa8]        | X8 = 0x2B90C94;                         
            // 0x010EC910: LDR w0, [x8]               | W0 = 0x19E9;                            
            // 0x010EC914: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E9, ????);     
            // 0x010EC918: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EC91C: STRB w8, [x23, #0xade]     | static_value_03735ADE = true;            //  dest_result_addr=57891550
            label_0:
            // 0x010EC920: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x010EC924: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EC928: MOV x0, x19                | X0 = 1152921509980886656 (0x1000000140515680);//ML01
            // 0x010EC92C: STR w8, [x19, #0x74]       | this.hashCode = 0;                       //  dest_result_addr=1152921509980886772
            this.hashCode = 0;
            // 0x010EC930: BL #0x16f59f0              | type..ctor();                           
            val_1 = new System.Object();
            // 0x010EC934: STR x21, [x19, #0x18]      | this.cDef = def;                         //  dest_result_addr=1152921509980886680
            this.cDef = def;
            // 0x010EC938: STP x22, x20, [x19, #0x30] | this.appdomain = domain;  this.declaringType = type;  //  dest_result_addr=1152921509980886704 |  dest_result_addr=1152921509980886712
            this.appdomain = domain;
            this.declaringType = val_1;
            // 0x010EC93C: CBNZ x21, #0x10ec944       | if (def != null) goto label_1;          
            if(def != null)
            {
                goto label_1;
            }
            // 0x010EC940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? type..ctor(), ????);
            label_1:
            // 0x010EC944: LDR x8, [x21]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x010EC948: MOV x0, x21                | X0 = def;//m1                           
            // 0x010EC94C: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_200;
            // 0x010EC950: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_208;
            // 0x010EC954: BLR x9                     | X0 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_200();
            // 0x010EC958: STR x0, [x19, #0x40]       | this.param = def;                        //  dest_result_addr=1152921509980886720
            this.param = def;
            // 0x010EC95C: CBNZ x21, #0x10ec964       | if (def != null) goto label_2;          
            if(def != null)
            {
                goto label_2;
            }
            // 0x010EC960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_2:
            // 0x010EC964: LDR x8, [x21]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x010EC968: MOV x0, x21                | X0 = def;//m1                           
            // 0x010EC96C: LDR x9, [x8, #0x340]       | X9 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_340;
            // 0x010EC970: LDR x1, [x8, #0x348]       | X1 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_348;
            // 0x010EC974: BLR x9                     | X0 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_340();
            // 0x010EC978: AND w8, w0, #1             | W8 = (def & 1);                         
            System.Reflection.ConstructorInfo val_2 = def & 1;
            // 0x010EC97C: TBNZ w8, #0, #0x10ec984    | if (((def & 1) & 0x1) != 0) goto label_3;
            if((val_2 & 1) != 0)
            {
                goto label_3;
            }
            // 0x010EC980: STR x20, [x19, #0x78]      | this.<ReturnType>k__BackingField = type;  //  dest_result_addr=1152921509980886776
            this.<ReturnType>k__BackingField = val_1;
            label_3:
            // 0x010EC984: LDR x20, [x19, #0x30]      | X20 = this.appdomain; //P2              
            // 0x010EC988: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EC98C: STRB w8, [x19, #0x48]      | this.isConstructor = true;               //  dest_result_addr=1152921509980886728
            this.isConstructor = true;
            // 0x010EC990: CBNZ x20, #0x10ec998       | if (this.appdomain != null) goto label_4;
            if(this.appdomain != null)
            {
                goto label_4;
            }
            // 0x010EC994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? def, ????);        
            label_4:
            // 0x010EC998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EC99C: MOV x0, x20                | X0 = this.appdomain;//m1                
            // 0x010EC9A0: BL #0x28e4338              | X0 = this.appdomain.get_RedirectMap();  
            System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate> val_3 = this.appdomain.RedirectMap;
            // 0x010EC9A4: LDR x20, [x19, #0x18]      | X20 = this.cDef; //P2                   
            // 0x010EC9A8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x010EC9AC: ADD x19, x19, #0x50        | X19 = this.redirect;//AP2 res_addr=1152921509980886736
            // 0x010EC9B0: CBNZ x21, #0x10ec9b8       | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x010EC9B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x010EC9B8: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x010EC9BC: LDR x8, [x8, #0xb8]        | X8 = 1152921509980663616;               
            // 0x010EC9C0: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x010EC9C4: MOV x1, x20                | X1 = this.cDef;//m1                     
            // 0x010EC9C8: MOV x2, x19                | X2 = this.redirect;//m1                 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = this.redirect;
            // 0x010EC9CC: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Reflection.MethodBase, ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate>::TryGetValue(System.Reflection.MethodBase key, out ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate value);
            // 0x010EC9D0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x010EC9D4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x010EC9D8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x010EC9DC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x010EC9E0: B #0x23fe7ec               | X0 = val_3.TryGetValue(key:  this.cDef, value: out  ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = this.redirect); return;
            bool val_5 = val_3.TryGetValue(key:  this.cDef, value: out  val_4);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010EC9E4 (17746404), len: 8  VirtAddr: 0x010EC9E4 RVA: 0x010EC9E4 token: 100663318 methodIndex: 28763 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_DeclearingType()
        {
            //
            // Disasemble & Code
            // 0x010EC9E4: LDR x0, [x0, #0x38]        | X0 = this.declaringType; //P2           
            // 0x010EC9E8: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.declaringType;
            return (ILRuntime.CLR.TypeSystem.IType)this.declaringType;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010EC9EC (17746412), len: 48  VirtAddr: 0x010EC9EC RVA: 0x010EC9EC token: 100663319 methodIndex: 28764 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_Name()
        {
            //
            // Disasemble & Code
            // 0x010EC9EC: STP x20, x19, [sp, #-0x20]! | stack[1152921509981135488] = ???;  stack[1152921509981135496] = ???;  //  dest_result_addr=1152921509981135488 |  dest_result_addr=1152921509981135496
            // 0x010EC9F0: STP x29, x30, [sp, #0x10]  | stack[1152921509981135504] = ???;  stack[1152921509981135512] = ???;  //  dest_result_addr=1152921509981135504 |  dest_result_addr=1152921509981135512
            // 0x010EC9F4: ADD x29, sp, #0x10         | X29 = (1152921509981135488 + 16) = 1152921509981135504 (0x1000000140552290);
            // 0x010EC9F8: LDR x19, [x0, #0x10]       | X19 = this.def; //P2                    
            // 0x010EC9FC: CBNZ x19, #0x10eca04       | if (this.def != null) goto label_0;     
            if(this.def != null)
            {
                goto label_0;
            }
            // 0x010ECA00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010ECA04: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010ECA08: MOV x0, x19                | X0 = this.def;//m1                      
            // 0x010ECA0C: LDP x2, x1, [x8, #0x190]   | X2 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_198; //  | 
            // 0x010ECA10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ECA14: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ECA18: BR x2                      | goto typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190;
            goto typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_190;
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECA1C (17746460), len: 76  VirtAddr: 0x010ECA1C RVA: 0x010ECA1C token: 100663320 methodIndex: 28765 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasThis()
        {
            //
            // Disasemble & Code
            //  | 
            System.Reflection.ConstructorInfo val_2;
            // 0x010ECA1C: STP x20, x19, [sp, #-0x20]! | stack[1152921509981259776] = ???;  stack[1152921509981259784] = ???;  //  dest_result_addr=1152921509981259776 |  dest_result_addr=1152921509981259784
            // 0x010ECA20: STP x29, x30, [sp, #0x10]  | stack[1152921509981259792] = ???;  stack[1152921509981259800] = ???;  //  dest_result_addr=1152921509981259792 |  dest_result_addr=1152921509981259800
            // 0x010ECA24: ADD x29, sp, #0x10         | X29 = (1152921509981259776 + 16) = 1152921509981259792 (0x1000000140570810);
            // 0x010ECA28: LDRB w8, [x0, #0x48]       | W8 = this.isConstructor; //P2           
            // 0x010ECA2C: CBZ w8, #0x10eca3c         | if (this.isConstructor == false) goto label_0;
            if(this.isConstructor == false)
            {
                goto label_0;
            }
            // 0x010ECA30: LDR x19, [x0, #0x18]       | X19 = this.cDef; //P2                   
            val_2 = this.cDef;
            // 0x010ECA34: CBNZ x19, #0x10eca48       | if (this.cDef != null) goto label_3;    
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x010ECA38: B #0x10eca44               |  goto label_2;                          
            goto label_2;
            label_0:
            // 0x010ECA3C: LDR x19, [x0, #0x10]       | X19 = this.def; //P2                    
            val_2 = this.def;
            // 0x010ECA40: CBNZ x19, #0x10eca48       | if (this.def != null) goto label_3;     
            if(val_2 != null)
            {
                goto label_3;
            }
            label_2:
            // 0x010ECA44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x010ECA48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ECA4C: MOV x0, x19                | X0 = this.def;//m1                      
            // 0x010ECA50: BL #0x13bbe68              | X0 = this.def.get_IsStatic();           
            bool val_1 = val_2.IsStatic;
            // 0x010ECA54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ECA58: MVN w8, w0                 | W8 = ~(val_1);                          
            // 0x010ECA5C: AND w0, w8, #1             | W0 = (~(val_1) & 1);                    
            val_1 = (~val_1) & 1;
            // 0x010ECA60: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ECA64: RET                        |  return (System.Boolean)(~(val_1) & 1); 
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECA68 (17746536), len: 156  VirtAddr: 0x010ECA68 RVA: 0x010ECA68 token: 100663321 methodIndex: 28766 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_GenericParameterCount()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            // 0x010ECA68: STP x20, x19, [sp, #-0x20]! | stack[1152921509981392256] = ???;  stack[1152921509981392264] = ???;  //  dest_result_addr=1152921509981392256 |  dest_result_addr=1152921509981392264
            // 0x010ECA6C: STP x29, x30, [sp, #0x10]  | stack[1152921509981392272] = ???;  stack[1152921509981392280] = ???;  //  dest_result_addr=1152921509981392272 |  dest_result_addr=1152921509981392280
            // 0x010ECA70: ADD x29, sp, #0x10         | X29 = (1152921509981392256 + 16) = 1152921509981392272 (0x1000000140590D90);
            // 0x010ECA74: MOV x19, x0                | X19 = 1152921509981404288 (0x1000000140593C80);//ML01
            val_1 = this;
            // 0x010ECA78: LDR x20, [x19, #0x10]      | X20 = this.def; //P2                    
            // 0x010ECA7C: CBNZ x20, #0x10eca84       | if (this.def != null) goto label_0;     
            if(this.def != null)
            {
                goto label_0;
            }
            // 0x010ECA80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x010ECA84: LDR x8, [x20]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010ECA88: MOV x0, x20                | X0 = this.def;//m1                      
            // 0x010ECA8C: LDR x9, [x8, #0x340]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_340;
            // 0x010ECA90: LDR x1, [x8, #0x348]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_348;
            // 0x010ECA94: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_340();
            // 0x010ECA98: TBZ w0, #0, #0x10ecaf4     | if ((this.def & 0x1) == 0) goto label_3;
            if((this.def & 1) == 0)
            {
                goto label_3;
            }
            // 0x010ECA9C: LDR x20, [x19, #0x10]      | X20 = this.def; //P2                    
            // 0x010ECAA0: CBNZ x20, #0x10ecaa8       | if (this.def != null) goto label_2;     
            if(this.def != null)
            {
                goto label_2;
            }
            // 0x010ECAA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.def, ????);   
            label_2:
            // 0x010ECAA8: LDR x8, [x20]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010ECAAC: MOV x0, x20                | X0 = this.def;//m1                      
            // 0x010ECAB0: LDR x9, [x8, #0x350]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_350;
            // 0x010ECAB4: LDR x1, [x8, #0x358]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_358;
            // 0x010ECAB8: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_350();
            // 0x010ECABC: TBZ w0, #0, #0x10ecaf4     | if ((this.def & 0x1) == 0) goto label_3;
            if((this.def & 1) == 0)
            {
                goto label_3;
            }
            // 0x010ECAC0: LDR x19, [x19, #0x10]      | X19 = this.def; //P2                    
            // 0x010ECAC4: CBNZ x19, #0x10ecacc       | if (this.def != null) goto label_4;     
            if(this.def != null)
            {
                goto label_4;
            }
            // 0x010ECAC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.def, ????);   
            label_4:
            // 0x010ECACC: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010ECAD0: MOV x0, x19                | X0 = this.def;//m1                      
            // 0x010ECAD4: LDR x9, [x8, #0x330]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_330;
            // 0x010ECAD8: LDR x1, [x8, #0x338]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_338;
            // 0x010ECADC: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_330();
            // 0x010ECAE0: MOV x19, x0                | X19 = this.def;//m1                     
            val_1 = this.def;
            // 0x010ECAE4: CBNZ x19, #0x10ecaec       | if (this.def != null) goto label_5;     
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x010ECAE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.def, ????);   
            label_5:
            // 0x010ECAEC: LDR w0, [x19, #0x18]       | 
            // 0x010ECAF0: B #0x10ecaf8               |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x010ECAF4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_2 = 0;
            label_6:
            // 0x010ECAF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ECAFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ECB00: RET                        |  return (System.Int32)0;                
            return (int)val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB04 (17746692), len: 16  VirtAddr: 0x010ECB04 RVA: 0x010ECB04 token: 100663322 methodIndex: 28767 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsGenericInstance()
        {
            //
            // Disasemble & Code
            // 0x010ECB04: LDR x8, [x0, #0x58]        | X8 = this.genericArguments; //P2        
            // 0x010ECB08: CMP x8, #0                 | STATE = COMPARE(this.genericArguments, 0x0)
            // 0x010ECB0C: CSET w0, ne                | W0 = this.genericArguments != null ? 1 : 0;
            var val_1 = (this.genericArguments != null) ? 1 : 0;
            // 0x010ECB10: RET                        |  return (System.Boolean)this.genericArguments != null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB14 (17746708), len: 8  VirtAddr: 0x010ECB14 RVA: 0x010ECB14 token: 100663323 methodIndex: 28768 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsDelegateInvoke()
        {
            //
            // Disasemble & Code
            // 0x010ECB14: LDRB w0, [x0, #0x70]       | W0 = this.isDelegateInvoke; //P2        
            // 0x010ECB18: RET                        |  return (System.Boolean)this.isDelegateInvoke;
            return this.isDelegateInvoke;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB1C (17746716), len: 64  VirtAddr: 0x010ECB1C RVA: 0x010ECB1C token: 100663324 methodIndex: 28769 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsStatic()
        {
            //
            // Disasemble & Code
            // 0x010ECB1C: MOV x8, x0                 | X8 = 1152921509981834496 (0x10000001405FCD00);//ML01
            // 0x010ECB20: LDR x0, [x8, #0x18]        | X0 = this.cDef; //P2                    
            // 0x010ECB24: CBZ x0, #0x10ecb30         | if (this.cDef == null) goto label_0;    
            if(this.cDef == null)
            {
                goto label_0;
            }
            // 0x010ECB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ECB2C: B #0x13bbe68               | return this.cDef.get_IsStatic();        
            return this.cDef.IsStatic;
            label_0:
            // 0x010ECB30: STP x20, x19, [sp, #-0x20]! | stack[1152921509981822464] = ???;  stack[1152921509981822472] = ???;  //  dest_result_addr=1152921509981822464 |  dest_result_addr=1152921509981822472
            // 0x010ECB34: STP x29, x30, [sp, #0x10]  | stack[1152921509981822480] = ???;  stack[1152921509981822488] = ???;  //  dest_result_addr=1152921509981822480 |  dest_result_addr=1152921509981822488
            // 0x010ECB38: ADD x29, sp, #0x10         | X29 = (1152921509981822464 + 16) = 1152921509981822480 (0x10000001405F9E10);
            // 0x010ECB3C: LDR x19, [x8, #0x10]       | X19 = this.def; //P2                    
            // 0x010ECB40: CBNZ x19, #0x10ecb48       | if (this.def != null) goto label_1;     
            if(this.def != null)
            {
                goto label_1;
            }
            // 0x010ECB44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cDef, ????);  
            label_1:
            // 0x010ECB48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ECB4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ECB50: MOV x0, x19                | X0 = this.def;//m1                      
            // 0x010ECB54: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ECB58: B #0x13bbe68               | return this.def.get_IsStatic();         
            return this.def.IsStatic;
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB5C (17746780), len: 8  VirtAddr: 0x010ECB5C RVA: 0x010ECB5C token: 100663325 methodIndex: 28770 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate get_Redirection()
        {
            //
            // Disasemble & Code
            // 0x010ECB5C: LDR x0, [x0, #0x50]        | X0 = this.redirect; //P2                
            // 0x010ECB60: RET                        |  return (ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate)this.redirect;
            return this.redirect;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB64 (17746788), len: 8  VirtAddr: 0x010ECB64 RVA: 0x010ECB64 token: 100663326 methodIndex: 28771 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.MethodInfo get_MethodInfo()
        {
            //
            // Disasemble & Code
            // 0x010ECB64: LDR x0, [x0, #0x10]        | X0 = this.def; //P2                     
            // 0x010ECB68: RET                        |  return (System.Reflection.MethodInfo)this.def;
            return this.def;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB6C (17746796), len: 8  VirtAddr: 0x010ECB6C RVA: 0x010ECB6C token: 100663327 methodIndex: 28772 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.ConstructorInfo get_ConstructorInfo()
        {
            //
            // Disasemble & Code
            // 0x010ECB6C: LDR x0, [x0, #0x18]        | X0 = this.cDef; //P2                    
            // 0x010ECB70: RET                        |  return (System.Reflection.ConstructorInfo)this.cDef;
            return this.cDef;
            //  |  // // {name=val_0, type=System.Reflection.ConstructorInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB74 (17746804), len: 8  VirtAddr: 0x010ECB74 RVA: 0x010ECB74 token: 100663328 methodIndex: 28773 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType[] get_GenericArguments()
        {
            //
            // Disasemble & Code
            // 0x010ECB74: LDR x0, [x0, #0x58]        | X0 = this.genericArguments; //P2        
            // 0x010ECB78: RET                        |  return (ILRuntime.CLR.TypeSystem.IType[])this.genericArguments;
            return this.genericArguments;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECB7C (17746812), len: 96  VirtAddr: 0x010ECB7C RVA: 0x010ECB7C token: 100663329 methodIndex: 28774 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type[] get_GenericArgumentsCLR()
        {
            //
            // Disasemble & Code
            //  | 
            System.Type[] val_1;
            // 0x010ECB7C: STP x20, x19, [sp, #-0x20]! | stack[1152921509982534016] = ???;  stack[1152921509982534024] = ???;  //  dest_result_addr=1152921509982534016 |  dest_result_addr=1152921509982534024
            // 0x010ECB80: STP x29, x30, [sp, #0x10]  | stack[1152921509982534032] = ???;  stack[1152921509982534040] = ???;  //  dest_result_addr=1152921509982534032 |  dest_result_addr=1152921509982534040
            // 0x010ECB84: ADD x29, sp, #0x10         | X29 = (1152921509982534016 + 16) = 1152921509982534032 (0x10000001406A7990);
            // 0x010ECB88: MOV x19, x0                | X19 = 1152921509982546048 (0x10000001406AA880);//ML01
            // 0x010ECB8C: LDR x0, [x19, #0x60]       | X0 = this.genericArgumentsCLR; //P2     
            val_1 = this.genericArgumentsCLR;
            // 0x010ECB90: CBNZ x0, #0x10ecbd0        | if (this.genericArgumentsCLR != null) goto label_0;
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x010ECB94: LDR x0, [x19, #0x18]       | X0 = this.cDef; //P2                    
            val_1 = this.cDef;
            // 0x010ECB98: CBZ x0, #0x10ecbac         | if (this.cDef == null) goto label_1;    
            if(val_1 == null)
            {
                goto label_1;
            }
            // 0x010ECB9C: LDR x8, [x0]               | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x010ECBA0: LDR x9, [x8, #0x330]       | X9 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_330;
            // 0x010ECBA4: LDR x1, [x8, #0x338]       | X1 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_338;
            // 0x010ECBA8: B #0x10ecbc8               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x010ECBAC: LDR x20, [x19, #0x10]      | X20 = this.def; //P2                    
            // 0x010ECBB0: CBNZ x20, #0x10ecbb8       | if (this.def != null) goto label_3;     
            if(this.def != null)
            {
                goto label_3;
            }
            // 0x010ECBB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cDef, ????);  
            label_3:
            // 0x010ECBB8: LDR x8, [x20]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010ECBBC: MOV x0, x20                | X0 = this.def;//m1                      
            val_1 = this.def;
            // 0x010ECBC0: LDR x9, [x8, #0x330]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_330;
            // 0x010ECBC4: LDR x1, [x8, #0x338]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_338;
            label_2:
            // 0x010ECBC8: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_330();
            // 0x010ECBCC: STR x0, [x19, #0x60]       | this.genericArgumentsCLR = this.def;     //  dest_result_addr=1152921509982546144
            this.genericArgumentsCLR = val_1;
            label_0:
            // 0x010ECBD0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ECBD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ECBD8: RET                        |  return (System.Type[])this.def;        
            return val_1;
            //  |  // // {name=val_0, type=System.Type[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECBDC (17746908), len: 24  VirtAddr: 0x010ECBDC RVA: 0x010ECBDC token: 100663330 methodIndex: 28775 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_ParameterCount()
        {
            //
            // Disasemble & Code
            // 0x010ECBDC: LDR x8, [x0, #0x40]        | X8 = this.param; //P2                   
            // 0x010ECBE0: CBZ x8, #0x10ecbec         | if (this.param == null) goto label_0;   
            if(this.param == null)
            {
                goto label_0;
            }
            // 0x010ECBE4: LDR w0, [x8, #0x18]        | W0 = this.param.Length; //P2            
            // 0x010ECBE8: RET                        |  return (System.Int32)this.param.Length;
            return this.param.Length;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_0:
            // 0x010ECBEC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x010ECBF0: RET                        |  return (System.Int32)0;                
            return (int)0;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECBF4 (17746932), len: 48  VirtAddr: 0x010ECBF4 RVA: 0x010ECBF4 token: 100663331 methodIndex: 28776 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> get_Parameters()
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> val_1;
            // 0x010ECBF4: STP x20, x19, [sp, #-0x20]! | stack[1152921509982884992] = ???;  stack[1152921509982885000] = ???;  //  dest_result_addr=1152921509982884992 |  dest_result_addr=1152921509982885000
            // 0x010ECBF8: STP x29, x30, [sp, #0x10]  | stack[1152921509982885008] = ???;  stack[1152921509982885016] = ???;  //  dest_result_addr=1152921509982885008 |  dest_result_addr=1152921509982885016
            // 0x010ECBFC: ADD x29, sp, #0x10         | X29 = (1152921509982884992 + 16) = 1152921509982885008 (0x10000001406FD490);
            // 0x010ECC00: MOV x19, x0                | X19 = 1152921509982897024 (0x1000000140700380);//ML01
            // 0x010ECC04: LDR x0, [x19, #0x20]       | X0 = this.parameters; //P2              
            val_1 = this.parameters;
            // 0x010ECC08: CBNZ x0, #0x10ecc18        | if (this.parameters != null) goto label_0;
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x010ECC0C: MOV x0, x19                | X0 = 1152921509982897024 (0x1000000140700380);//ML01
            // 0x010ECC10: BL #0x10ecc24              | this.InitParameters();                  
            this.InitParameters();
            // 0x010ECC14: LDR x0, [x19, #0x20]       | X0 = this.parameters; //P2              
            val_1 = this.parameters;
            label_0:
            // 0x010ECC18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ECC1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ECC20: RET                        |  return (System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>)this.parameters;
            return val_1;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ED0A4 (17748132), len: 96  VirtAddr: 0x010ED0A4 RVA: 0x010ED0A4 token: 100663332 methodIndex: 28777 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.ParameterInfo[] get_ParametersCLR()
        {
            //
            // Disasemble & Code
            //  | 
            System.Reflection.ParameterInfo[] val_1;
            // 0x010ED0A4: STP x20, x19, [sp, #-0x20]! | stack[1152921509983050240] = ???;  stack[1152921509983050248] = ???;  //  dest_result_addr=1152921509983050240 |  dest_result_addr=1152921509983050248
            // 0x010ED0A8: STP x29, x30, [sp, #0x10]  | stack[1152921509983050256] = ???;  stack[1152921509983050264] = ???;  //  dest_result_addr=1152921509983050256 |  dest_result_addr=1152921509983050264
            // 0x010ED0AC: ADD x29, sp, #0x10         | X29 = (1152921509983050240 + 16) = 1152921509983050256 (0x1000000140725A10);
            // 0x010ED0B0: MOV x19, x0                | X19 = 1152921509983062272 (0x1000000140728900);//ML01
            // 0x010ED0B4: LDR x0, [x19, #0x28]       | X0 = this.parametersCLR; //P2           
            val_1 = this.parametersCLR;
            // 0x010ED0B8: CBNZ x0, #0x10ed0f8        | if (this.parametersCLR != null) goto label_0;
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x010ED0BC: LDR x0, [x19, #0x18]       | X0 = this.cDef; //P2                    
            val_1 = this.cDef;
            // 0x010ED0C0: CBZ x0, #0x10ed0d4         | if (this.cDef == null) goto label_1;    
            if(val_1 == null)
            {
                goto label_1;
            }
            // 0x010ED0C4: LDR x8, [x0]               | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x010ED0C8: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_200;
            // 0x010ED0CC: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.ConstructorInfo).__il2cppRuntimeField_208;
            // 0x010ED0D0: B #0x10ed0f0               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x010ED0D4: LDR x20, [x19, #0x10]      | X20 = this.def; //P2                    
            // 0x010ED0D8: CBNZ x20, #0x10ed0e0       | if (this.def != null) goto label_3;     
            if(this.def != null)
            {
                goto label_3;
            }
            // 0x010ED0DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cDef, ????);  
            label_3:
            // 0x010ED0E0: LDR x8, [x20]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010ED0E4: MOV x0, x20                | X0 = this.def;//m1                      
            val_1 = this.def;
            // 0x010ED0E8: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_200;
            // 0x010ED0EC: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_208;
            label_2:
            // 0x010ED0F0: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_200();
            // 0x010ED0F4: STR x0, [x19, #0x28]       | this.parametersCLR = this.def;           //  dest_result_addr=1152921509983062312
            this.parametersCLR = val_1;
            label_0:
            // 0x010ED0F8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010ED0FC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010ED100: RET                        |  return (System.Reflection.ParameterInfo[])this.def;
            return val_1;
            //  |  // // {name=val_0, type=System.Reflection.ParameterInfo[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010EC8C8 (17746120), len: 8  VirtAddr: 0x010EC8C8 RVA: 0x010EC8C8 token: 100663333 methodIndex: 28778 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ReturnType()
        {
            //
            // Disasemble & Code
            // 0x010EC8C8: LDR x0, [x0, #0x78]        | X0 = this.<ReturnType>k__BackingField; //P2 
            // 0x010EC8CC: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.<ReturnType>k__BackingField;
            return this.<ReturnType>k__BackingField;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010EC8C0 (17746112), len: 8  VirtAddr: 0x010EC8C0 RVA: 0x010EC8C0 token: 100663334 methodIndex: 28779 delegateWrapperIndex: 0 methodInvoker: 0
        private void set_ReturnType(ILRuntime.CLR.TypeSystem.IType value)
        {
            //
            // Disasemble & Code
            // 0x010EC8C0: STR x1, [x0, #0x78]        | this.<ReturnType>k__BackingField = value;  //  dest_result_addr=1152921509983343736
            this.<ReturnType>k__BackingField = value;
            // 0x010EC8C4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x010ED104 (17748228), len: 16  VirtAddr: 0x010ED104 RVA: 0x010ED104 token: 100663335 methodIndex: 28780 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsConstructor()
        {
            //
            // Disasemble & Code
            // 0x010ED104: LDR x8, [x0, #0x18]        | X8 = this.cDef; //P2                    
            // 0x010ED108: CMP x8, #0                 | STATE = COMPARE(this.cDef, 0x0)         
            // 0x010ED10C: CSET w0, ne                | W0 = this.cDef != null ? 1 : 0;         
            var val_1 = (this.cDef != 0) ? 1 : 0;
            // 0x010ED110: RET                        |  return (System.Boolean)this.cDef != null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ECC24 (17746980), len: 1152  VirtAddr: 0x010ECC24 RVA: 0x010ECC24 token: 100663336 methodIndex: 28781 delegateWrapperIndex: 0 methodInvoker: 0
        private void InitParameters()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_10;
            //  | 
            var val_11;
            //  | 
            ILRuntime.CLR.TypeSystem.CLRType val_12;
            //  | 
            string val_13;
            //  | 
            var val_14;
            //  | 
            string val_15;
            //  | 
            System.Reflection.MemberInfo val_16;
            //  | 
            var val_17;
            // 0x010ECC24: STP x26, x25, [sp, #-0x50]! | stack[1152921509983661008] = ???;  stack[1152921509983661016] = ???;  //  dest_result_addr=1152921509983661008 |  dest_result_addr=1152921509983661016
            // 0x010ECC28: STP x24, x23, [sp, #0x10]  | stack[1152921509983661024] = ???;  stack[1152921509983661032] = ???;  //  dest_result_addr=1152921509983661024 |  dest_result_addr=1152921509983661032
            // 0x010ECC2C: STP x22, x21, [sp, #0x20]  | stack[1152921509983661040] = ???;  stack[1152921509983661048] = ???;  //  dest_result_addr=1152921509983661040 |  dest_result_addr=1152921509983661048
            // 0x010ECC30: STP x20, x19, [sp, #0x30]  | stack[1152921509983661056] = ???;  stack[1152921509983661064] = ???;  //  dest_result_addr=1152921509983661056 |  dest_result_addr=1152921509983661064
            // 0x010ECC34: STP x29, x30, [sp, #0x40]  | stack[1152921509983661072] = ???;  stack[1152921509983661080] = ???;  //  dest_result_addr=1152921509983661072 |  dest_result_addr=1152921509983661080
            // 0x010ECC38: ADD x29, sp, #0x40         | X29 = (1152921509983661008 + 64) = 1152921509983661072 (0x10000001407BAC10);
            // 0x010ECC3C: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010ECC40: LDRB w8, [x20, #0xadf]     | W8 = (bool)static_value_03735ADF;       
            // 0x010ECC44: MOV x19, x0                | X19 = 1152921509983673088 (0x10000001407BDB00);//ML01
            // 0x010ECC48: TBNZ w8, #0, #0x10ecc64    | if (static_value_03735ADF == true) goto label_0;
            // 0x010ECC4C: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x010ECC50: LDR x8, [x8, #0xd20]       | X8 = 0x2B90CA0;                         
            // 0x010ECC54: LDR w0, [x8]               | W0 = 0x19EC;                            
            // 0x010ECC58: BL #0x2782188              | X0 = sub_2782188( ?? 0x19EC, ????);     
            // 0x010ECC5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010ECC60: STRB w8, [x20, #0xadf]     | static_value_03735ADF = true;            //  dest_result_addr=57891551
            label_0:
            // 0x010ECC64: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x010ECC68: LDR x8, [x8, #0xc40]       | X8 = 1152921504616644608;               
            // 0x010ECC6C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> val_1 = null;
            // 0x010ECC70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010ECC74: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x010ECC78: LDR x8, [x8, #0x3a0]       | X8 = 1152921509983555904;               
            // 0x010ECC7C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010ECC80: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::.ctor();
            val_10 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::.ctor();
            // 0x010ECC84: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>();
            // 0x010ECC88: STR x20, [x19, #0x20]      | this.parameters = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921509983673120
            this.parameters = val_1;
            // 0x010ECC8C: ADRP x25, #0x35bf000       | X25 = 56356864 (0x35BF000);             
            // 0x010ECC90: ADRP x26, #0x35f6000       | X26 = 56582144 (0x35F6000);             
            // 0x010ECC94: LDR x24, [x19, #0x40]      | X24 = this.param; //P2                  
            // 0x010ECC98: LDR x25, [x25, #0xad8]     | X25 = 1152921504782139392;              
            // 0x010ECC9C: LDR x26, [x26, #0x840]     | X26 = 1152921509983593792;              
            // 0x010ECCA0: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x010ECCA4: B #0x10eccbc               |  goto label_1;                          
            goto label_1;
            label_43:
            // 0x010ECCA8: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType>::Add(ILRuntime.CLR.TypeSystem.IType item);
            // 0x010ECCAC: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x010ECCB0: MOV x1, x21                | X1 = X21;//m1                           
            val_10 = X21;
            // 0x010ECCB4: BL #0x25ea480              | Add(item:  val_10 = X21);               
            Add(item:  val_10);
            // 0x010ECCB8: ADD w23, w23, #1           | W23 = (val_11 + 1) = val_11 (0x00000001);
            val_11 = 1;
            label_1:
            // 0x010ECCBC: CBNZ x24, #0x10eccc4       | if (this.param != null) goto label_2;   
            if(this.param != null)
            {
                goto label_2;
            }
            // 0x010ECCC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_2:
            // 0x010ECCC4: LDR w8, [x24, #0x18]       | W8 = this.param.Length; //P2            
            // 0x010ECCC8: CMP w23, w8                | STATE = COMPARE(0x1, this.param.Length) 
            // 0x010ECCCC: B.GE #0x10ed058            | if (val_11 >= this.param.Length) goto label_3;
            if(val_11 >= this.param.Length)
            {
                goto label_3;
            }
            // 0x010ECCD0: SXTW x20, w23              | X20 = 1 (0x00000001);                   
            // 0x010ECCD4: CMP w23, w8                | STATE = COMPARE(0x1, this.param.Length) 
            // 0x010ECCD8: B.LO #0x10ecce8            | if (val_11 < this.param.Length) goto label_4;
            if(val_11 < this.param.Length)
            {
                goto label_4;
            }
            // 0x010ECCDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x010ECCE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x010ECCE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_4:
            // 0x010ECCE8: ADD x8, x24, x20, lsl #3   | X8 = this.param[0x1]; //PARR1           
            // 0x010ECCEC: LDR x20, [x8, #0x20]       | X20 = this.param[0x1][0]                
            System.Reflection.ParameterInfo val_10 = this.param[1];
            // 0x010ECCF0: LDR x21, [x19, #0x30]      | X21 = this.appdomain; //P2              
            // 0x010ECCF4: CBNZ x20, #0x10eccfc       | if (this.param[0x1][0] != null) goto label_5;
            if(val_10 != null)
            {
                goto label_5;
            }
            // 0x010ECCF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_5:
            // 0x010ECCFC: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECD00: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECD04: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECD08: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECD0C: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECD10: CBNZ x22, #0x10ecd18       | if (this.param[0x1][0] != null) goto label_6;
            if(val_10 != null)
            {
                goto label_6;
            }
            // 0x010ECD14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_6:
            // 0x010ECD18: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECD1C: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECD20: LDR x9, [x8, #0x230]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_230;
            // 0x010ECD24: LDR x1, [x8, #0x238]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_238;
            // 0x010ECD28: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_230();
            // 0x010ECD2C: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECD30: CBNZ x21, #0x10ecd38       | if (this.appdomain != null) goto label_7;
            if(this.appdomain != null)
            {
                goto label_7;
            }
            // 0x010ECD34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_7:
            // 0x010ECD38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x010ECD3C: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010ECD40: MOV x1, x22                | X1 = this.param[0x1][0];//m1            
            val_13 = val_10;
            // 0x010ECD44: BL #0x28e4a68              | X0 = this.appdomain.GetType(fullname:  val_13 = this.param[1]);
            ILRuntime.CLR.TypeSystem.IType val_2 = this.appdomain.GetType(fullname:  val_13);
            // 0x010ECD48: MOV x21, x0                | X21 = val_2;//m1                        
            val_14 = val_2;
            // 0x010ECD4C: CBNZ x21, #0x10ecdac       | if (val_2 != null) goto label_8;        
            if(val_14 != null)
            {
                goto label_8;
            }
            // 0x010ECD50: LDR x21, [x19, #0x30]      | X21 = this.appdomain; //P2              
            // 0x010ECD54: CBNZ x20, #0x10ecd5c       | if (this.param[0x1][0] != null) goto label_9;
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x010ECD58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x010ECD5C: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECD60: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECD64: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECD68: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECD6C: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECD70: CBNZ x22, #0x10ecd78       | if (this.param[0x1][0] != null) goto label_10;
            if(val_10 != null)
            {
                goto label_10;
            }
            // 0x010ECD74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_10:
            // 0x010ECD78: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECD7C: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECD80: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_200;
            // 0x010ECD84: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_208;
            // 0x010ECD88: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_200();
            // 0x010ECD8C: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECD90: CBNZ x21, #0x10ecd98       | if (this.appdomain != null) goto label_11;
            if(this.appdomain != null)
            {
                goto label_11;
            }
            // 0x010ECD94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_11:
            // 0x010ECD98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x010ECD9C: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010ECDA0: MOV x1, x22                | X1 = this.param[0x1][0];//m1            
            val_13 = val_10;
            // 0x010ECDA4: BL #0x28e4a68              | X0 = this.appdomain.GetType(fullname:  val_13 = this.param[1]);
            ILRuntime.CLR.TypeSystem.IType val_3 = this.appdomain.GetType(fullname:  val_13);
            // 0x010ECDA8: MOV x21, x0                | X21 = val_3;//m1                        
            val_14 = val_3;
            label_8:
            // 0x010ECDAC: CBNZ x20, #0x10ecdb4       | if (this.param[0x1][0] != null) goto label_12;
            if(val_10 != null)
            {
                goto label_12;
            }
            // 0x010ECDB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_12:
            // 0x010ECDB4: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECDB8: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECDBC: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECDC0: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECDC4: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECDC8: CBNZ x22, #0x10ecdd0       | if (this.param[0x1][0] != null) goto label_13;
            if(val_10 != null)
            {
                goto label_13;
            }
            // 0x010ECDCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_13:
            // 0x010ECDD0: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECDD4: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECDD8: LDR x9, [x8, #0x740]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_740;
            // 0x010ECDDC: LDR x1, [x8, #0x748]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_748;
            // 0x010ECDE0: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_740();
            // 0x010ECDE4: CBNZ x21, #0x10ecee8       | if (val_3 != null) goto label_20;       
            if(val_14 != null)
            {
                goto label_20;
            }
            // 0x010ECDE8: TBZ w0, #0, #0x10ecee8     | if ((this.param[0x1][0] & 0x1) == 0) goto label_20;
            if((val_10 & 1) == 0)
            {
                goto label_20;
            }
            // 0x010ECDEC: LDR x21, [x19, #0x30]      | X21 = this.appdomain; //P2              
            // 0x010ECDF0: CBNZ x20, #0x10ecdf8       | if (this.param[0x1][0] != null) goto label_16;
            if(val_10 != null)
            {
                goto label_16;
            }
            // 0x010ECDF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_16:
            // 0x010ECDF8: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECDFC: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECE00: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECE04: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECE08: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECE0C: CBNZ x22, #0x10ece14       | if (this.param[0x1][0] != null) goto label_17;
            if(val_10 != null)
            {
                goto label_17;
            }
            // 0x010ECE10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_17:
            // 0x010ECE14: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECE18: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECE1C: LDR x9, [x8, #0x750]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_750;
            // 0x010ECE20: LDR x1, [x8, #0x758]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_758;
            // 0x010ECE24: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_750();
            // 0x010ECE28: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECE2C: CBNZ x22, #0x10ece34       | if (this.param[0x1][0] != null) goto label_18;
            if(val_10 != null)
            {
                goto label_18;
            }
            // 0x010ECE30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_18:
            // 0x010ECE34: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECE38: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECE3C: LDR x9, [x8, #0x230]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_230;
            // 0x010ECE40: LDR x1, [x8, #0x238]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_238;
            // 0x010ECE44: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_230();
            // 0x010ECE48: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECE4C: CBNZ x21, #0x10ece54       | if (this.appdomain != null) goto label_19;
            if(this.appdomain != null)
            {
                goto label_19;
            }
            // 0x010ECE50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_19:
            // 0x010ECE54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x010ECE58: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010ECE5C: MOV x1, x22                | X1 = this.param[0x1][0];//m1            
            val_15 = val_10;
            // 0x010ECE60: BL #0x28e4a68              | X0 = this.appdomain.GetType(fullname:  val_15 = this.param[1]);
            ILRuntime.CLR.TypeSystem.IType val_4 = this.appdomain.GetType(fullname:  val_15);
            // 0x010ECE64: MOV x21, x0                | X21 = val_4;//m1                        
            val_14 = val_4;
            // 0x010ECE68: CBNZ x21, #0x10ecee8       | if (val_4 != null) goto label_20;       
            if(val_14 != null)
            {
                goto label_20;
            }
            // 0x010ECE6C: LDR x21, [x19, #0x30]      | X21 = this.appdomain; //P2              
            // 0x010ECE70: CBNZ x20, #0x10ece78       | if (this.param[0x1][0] != null) goto label_21;
            if(val_10 != null)
            {
                goto label_21;
            }
            // 0x010ECE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_21:
            // 0x010ECE78: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECE7C: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECE80: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECE84: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECE88: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECE8C: CBNZ x22, #0x10ece94       | if (this.param[0x1][0] != null) goto label_22;
            if(val_10 != null)
            {
                goto label_22;
            }
            // 0x010ECE90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_22:
            // 0x010ECE94: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECE98: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECE9C: LDR x9, [x8, #0x750]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_750;
            // 0x010ECEA0: LDR x1, [x8, #0x758]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_758;
            // 0x010ECEA4: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_750();
            // 0x010ECEA8: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECEAC: CBNZ x22, #0x10eceb4       | if (this.param[0x1][0] != null) goto label_23;
            if(val_10 != null)
            {
                goto label_23;
            }
            // 0x010ECEB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_23:
            // 0x010ECEB4: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECEB8: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECEBC: LDR x9, [x8, #0x200]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_200;
            // 0x010ECEC0: LDR x1, [x8, #0x208]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_208;
            // 0x010ECEC4: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_200();
            // 0x010ECEC8: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECECC: CBNZ x21, #0x10eced4       | if (this.appdomain != null) goto label_24;
            if(this.appdomain != null)
            {
                goto label_24;
            }
            // 0x010ECED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_24:
            // 0x010ECED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x010ECED8: MOV x0, x21                | X0 = this.appdomain;//m1                
            // 0x010ECEDC: MOV x1, x22                | X1 = this.param[0x1][0];//m1            
            val_15 = val_10;
            // 0x010ECEE0: BL #0x28e4a68              | X0 = this.appdomain.GetType(fullname:  val_15 = this.param[1]);
            ILRuntime.CLR.TypeSystem.IType val_5 = this.appdomain.GetType(fullname:  val_15);
            // 0x010ECEE4: MOV x21, x0                | X21 = val_5;//m1                        
            val_14 = val_5;
            label_20:
            // 0x010ECEE8: CBNZ x20, #0x10ecef0       | if (this.param[0x1][0] != null) goto label_25;
            if(val_10 != null)
            {
                goto label_25;
            }
            // 0x010ECEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_25:
            // 0x010ECEF0: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECEF4: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECEF8: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECEFC: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECF00: MOV x22, x0                | X22 = this.param[0x1][0];//m1           
            // 0x010ECF04: CBNZ x22, #0x10ecf0c       | if (this.param[0x1][0] != null) goto label_26;
            if(val_10 != null)
            {
                goto label_26;
            }
            // 0x010ECF08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_26:
            // 0x010ECF0C: LDR x8, [x22]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECF10: MOV x0, x22                | X0 = this.param[0x1][0];//m1            
            // 0x010ECF14: LDR x9, [x8, #0x730]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_730;
            // 0x010ECF18: LDR x1, [x8, #0x738]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_738;
            // 0x010ECF1C: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_730();
            // 0x010ECF20: TBZ w0, #0, #0x10ed044     | if ((this.param[0x1][0] & 0x1) == 0) goto label_27;
            if((val_10 & 1) == 0)
            {
                goto label_27;
            }
            // 0x010ECF24: CBNZ x20, #0x10ecf2c       | if (this.param[0x1][0] != null) goto label_28;
            if(val_10 != null)
            {
                goto label_28;
            }
            // 0x010ECF28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_28:
            // 0x010ECF2C: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECF30: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECF34: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECF38: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECF3C: MOV x21, x0                | X21 = this.param[0x1][0];//m1           
            val_16 = val_10;
            // 0x010ECF40: CBNZ x21, #0x10ecf48       | if (this.param[0x1][0] != null) goto label_29;
            if(val_16 != null)
            {
                goto label_29;
            }
            // 0x010ECF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_29:
            // 0x010ECF48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ECF4C: MOV x0, x21                | X0 = this.param[0x1][0];//m1            
            // 0x010ECF50: BL #0x1b6d198              | X0 = this.param[0x1][0].get_HasElementType();
            bool val_6 = val_16.HasElementType;
            // 0x010ECF54: TBZ w0, #0, #0x10ecf98     | if (val_6 == false) goto label_30;      
            if(val_6 == false)
            {
                goto label_30;
            }
            // 0x010ECF58: CBNZ x20, #0x10ecf60       | if (this.param[0x1][0] != null) goto label_31;
            if(val_10 != null)
            {
                goto label_31;
            }
            // 0x010ECF5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_31:
            // 0x010ECF60: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECF64: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECF68: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ECF6C: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ECF70: MOV x20, x0                | X20 = this.param[0x1][0];//m1           
            // 0x010ECF74: CBNZ x20, #0x10ecf7c       | if (this.param[0x1][0] != null) goto label_32;
            if(val_10 != null)
            {
                goto label_32;
            }
            // 0x010ECF78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_32:
            // 0x010ECF7C: LDR x8, [x20]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECF80: MOV x0, x20                | X0 = this.param[0x1][0];//m1            
            // 0x010ECF84: LDR x9, [x8, #0x410]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_410;
            // 0x010ECF88: LDR x1, [x8, #0x418]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_418;
            // 0x010ECF8C: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_410();
            // 0x010ECF90: MOV x21, x0                | X21 = this.param[0x1][0];//m1           
            val_16 = val_10;
            // 0x010ECF94: B #0x10ed00c               |  goto label_36;                         
            goto label_36;
            label_30:
            // 0x010ECF98: CBNZ x21, #0x10ecfa0       | if (this.param[0x1][0] != null) goto label_34;
            if(val_16 != null)
            {
                goto label_34;
            }
            // 0x010ECF9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_34:
            // 0x010ECFA0: LDR x8, [x21]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECFA4: MOV x0, x21                | X0 = this.param[0x1][0];//m1            
            // 0x010ECFA8: LDR x9, [x8, #0x720]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_720;
            // 0x010ECFAC: LDR x1, [x8, #0x728]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_728;
            // 0x010ECFB0: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_720();
            // 0x010ECFB4: MOV x20, x0                | X20 = this.param[0x1][0];//m1           
            // 0x010ECFB8: CBNZ x20, #0x10ecfc0       | if (this.param[0x1][0] != null) goto label_35;
            if(val_16 != null)
            {
                goto label_35;
            }
            // 0x010ECFBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_35:
            // 0x010ECFC0: LDR w8, [x20, #0x18]       | W8 = this.param[0x1][0].DefaultValueImpl; //P2 
            // 0x010ECFC4: CMP w8, #1                 | STATE = COMPARE(this.param[0x1][0].DefaultValueImpl, 0x1)
            // 0x010ECFC8: B.LT #0x10ed00c            | if (this.param[0x1][0].DefaultValueImpl < 0x1) goto label_36;
            if(this.param[0x1][0].DefaultValueImpl < 1)
            {
                goto label_36;
            }
            // 0x010ECFCC: CBNZ x21, #0x10ecfd4       | if (this.param[0x1][0] != null) goto label_37;
            if(val_16 != null)
            {
                goto label_37;
            }
            // 0x010ECFD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_37:
            // 0x010ECFD4: LDR x8, [x21]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ECFD8: MOV x0, x21                | X0 = this.param[0x1][0];//m1            
            // 0x010ECFDC: LDR x9, [x8, #0x720]       | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_720;
            // 0x010ECFE0: LDR x1, [x8, #0x728]       | X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_728;
            // 0x010ECFE4: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_720();
            // 0x010ECFE8: MOV x20, x0                | X20 = this.param[0x1][0];//m1           
            // 0x010ECFEC: CBNZ x20, #0x10ecff4       | if (this.param[0x1][0] != null) goto label_38;
            if(val_16 != null)
            {
                goto label_38;
            }
            // 0x010ECFF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_38:
            // 0x010ECFF4: LDR w8, [x20, #0x18]       | W8 = this.param[0x1][0].DefaultValueImpl; //P2 
            // 0x010ECFF8: CBNZ w8, #0x10ed008        | if (this.param[0x1][0].DefaultValueImpl != null) goto label_39;
            if(this.param[0x1][0].DefaultValueImpl != null)
            {
                goto label_39;
            }
            // 0x010ECFFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.param[0x1][0], ????);
            // 0x010ED000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x010ED004: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.param[0x1][0], ????);
            label_39:
            // 0x010ED008: LDR x21, [x20, #0x20]      | X21 = this.param[0x1][0].MemberImpl; //P2 
            val_16 = this.param[0x1][0].MemberImpl;
            label_36:
            // 0x010ED00C: CBNZ x21, #0x10ed014       | if (this.param[0x1][0].MemberImpl != null) goto label_40;
            if(val_16 != null)
            {
                goto label_40;
            }
            // 0x010ED010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.param[0x1][0], ????);
            label_40:
            // 0x010ED014: LDR x8, [x21]              | X8 = typeof(System.Reflection.MemberInfo);
            // 0x010ED018: MOV x0, x21                | X0 = this.param[0x1][0].MemberImpl;//m1 
            // 0x010ED01C: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Reflection.MemberInfo).__il2cppRuntimeField_190; X1 = typeof(System.Reflection.MemberInfo).__il2cppRuntimeField_198; //  | 
            // 0x010ED020: BLR x9                     | X0 = typeof(System.Reflection.MemberInfo).__il2cppRuntimeField_190();
            // 0x010ED024: LDR x8, [x25]              | X8 = typeof(ILRuntime.CLR.TypeSystem.ILGenericParameterType);
            // 0x010ED028: MOV x20, x0                | X20 = this.param[0x1][0].MemberImpl;//m1
            // 0x010ED02C: MOV x0, x8                 | X0 = 1152921504782139392 (0x100000000A72C000);//ML01
            object val_7 = null;
            // 0x010ED030: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.TypeSystem.ILGenericParameterType), ????);
            // 0x010ED034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED038: MOV x21, x0                | X21 = 1152921504782139392 (0x100000000A72C000);//ML01
            val_14 = val_7;
            // 0x010ED03C: BL #0x16f59f0              | .ctor();                                
            val_7 = new System.Object();
            // 0x010ED040: STR x20, [x21, #0x10]      | typeof(ILRuntime.CLR.TypeSystem.ILGenericParameterType).__il2cppRuntimeField_10 = this.param[0x1][0].MemberImpl;  //  dest_result_addr=1152921504782139408
            typeof(ILRuntime.CLR.TypeSystem.ILGenericParameterType).__il2cppRuntimeField_10 = val_16;
            label_27:
            // 0x010ED044: CBZ x21, #0x10ed070        | if ( == 0) goto label_41;               
            if(null == 0)
            {
                goto label_41;
            }
            // 0x010ED048: LDR x20, [x19, #0x20]      | X20 = this.parameters; //P2             
            // 0x010ED04C: CBNZ x20, #0x10ecca8       | if (this.parameters != null) goto label_43;
            if(this.parameters != null)
            {
                goto label_43;
            }
            // 0x010ED050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x010ED054: B #0x10ecca8               |  goto label_43;                         
            goto label_43;
            label_3:
            // 0x010ED058: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x010ED05C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x010ED060: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x010ED064: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x010ED068: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x010ED06C: RET                        |  return;                                
            return;
            label_41:
            // 0x010ED070: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x010ED074: LDR x8, [x8, #0xd50]       | X8 = 1152921504657006592;               
            // 0x010ED078: LDR x0, [x8]               | X0 = typeof(System.TypeLoadException);  
            System.TypeLoadException val_8 = null;
            // 0x010ED07C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.TypeLoadException), ????);
            // 0x010ED080: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED084: MOV x19, x0                | X19 = 1152921504657006592 (0x1000000002FD6000);//ML01
            // 0x010ED088: BL #0x2735eb4              | .ctor();                                
            val_8 = new System.TypeLoadException();
            // 0x010ED08C: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x010ED090: LDR x8, [x8, #0x158]       | X8 = 1152921509983648064;               
            // 0x010ED094: MOV x0, x19                | X0 = 1152921504657006592 (0x1000000002FD6000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_9 = val_8;
            // 0x010ED098: LDR x1, [x8]               | X1 = System.Void ILRuntime.CLR.Method.CLRMethod::InitParameters();
            // 0x010ED09C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.TypeLoadException), ????);
            // 0x010ED0A0: BL #0x10ec5ac              | .ctor(def:  System.Void ILRuntime.CLR.Method.CLRMethod::InitParameters(), type:  val_12 = 0, domain:  null);
            val_9 = new ILRuntime.CLR.Method.CLRMethod(def:  System.Void ILRuntime.CLR.Method.CLRMethod::InitParameters(), type:  val_12, domain:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x010ED140 (17748288), len: 120  VirtAddr: 0x010ED140 RVA: 0x010ED140 token: 100663337 methodIndex: 28782 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Runtime.Stack.StackObject* Minus(ILRuntime.Runtime.Stack.StackObject* a, int b)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x010ED140: STP x22, x21, [sp, #-0x30]! | stack[1152921509983863152] = ???;  stack[1152921509983863160] = ???;  //  dest_result_addr=1152921509983863152 |  dest_result_addr=1152921509983863160
            // 0x010ED144: STP x20, x19, [sp, #0x10]  | stack[1152921509983863168] = ???;  stack[1152921509983863176] = ???;  //  dest_result_addr=1152921509983863168 |  dest_result_addr=1152921509983863176
            // 0x010ED148: STP x29, x30, [sp, #0x20]  | stack[1152921509983863184] = ???;  stack[1152921509983863192] = ???;  //  dest_result_addr=1152921509983863184 |  dest_result_addr=1152921509983863192
            // 0x010ED14C: ADD x29, sp, #0x20         | X29 = (1152921509983863152 + 32) = 1152921509983863184 (0x10000001407EC190);
            // 0x010ED150: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010ED154: LDRB w8, [x21, #0xae0]     | W8 = (bool)static_value_03735AE0;       
            // 0x010ED158: MOV w19, w2                | W19 = W2;//m1                           
            // 0x010ED15C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x010ED160: TBNZ w8, #0, #0x10ed17c    | if (static_value_03735AE0 == true) goto label_0;
            // 0x010ED164: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x010ED168: LDR x8, [x8, #0x358]       | X8 = 0x2B90CAC;                         
            // 0x010ED16C: LDR w0, [x8]               | W0 = 0x19EF;                            
            // 0x010ED170: BL #0x2782188              | X0 = sub_2782188( ?? 0x19EF, ????);     
            // 0x010ED174: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010ED178: STRB w8, [x21, #0xae0]     | static_value_03735AE0 = true;            //  dest_result_addr=57891552
            label_0:
            // 0x010ED17C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x010ED180: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x010ED184: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x010ED188: LDRB w8, [x0, #0x109]      | W8 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x010ED18C: TBNZ w8, #0, #0x10ed198    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x010ED190: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_2 = 8;
            // 0x010ED194: B #0x10ed1a0               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x010ED198: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x010ED19C: SUB w8, w0, #0x10          | W8 = (null - 16) = val_2 (0x100000000D137FF0);
            val_2 = 1152921504826228720;
            label_2:
            // 0x010ED1A0: MUL w8, w8, w19            | W8 = (val_2 * W2);                      
            val_2 = val_2 * W2;
            // 0x010ED1A4: SUB x0, x20, w8, sxtw      | X0 = (X1 - ((val_2 * W2)) << );         
            var val_1 = X1 - (val_2 << );
            // 0x010ED1A8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x010ED1AC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x010ED1B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x010ED1B4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(X1 - ((val_2 * W2)) << );
            return (ILRuntime.Runtime.Stack.StackObject*)val_1;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010ED1B8 (17748408), len: 1388  VirtAddr: 0x010ED1B8 RVA: 0x010ED1B8 token: 100663338 methodIndex: 28783 delegateWrapperIndex: 0 methodInvoker: 0
        public object Invoke(ILRuntime.Runtime.Intepreter.ILIntepreter intepreter, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, bool isNewObj = False)
        {
            //
            // Disasemble & Code
            //  | 
            System.Reflection.ConstructorInfo val_24;
            //  | 
            int val_25;
            //  | 
            System.Object[] val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            System.Type val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.AppDomain val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.AppDomain val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.AppDomain val_32;
            //  | 
            System.Reflection.ConstructorInfo val_33;
            //  | 
            var val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.AppDomain val_35;
            //  | 
            System.Type val_36;
            //  | 
            ILRuntime.CLR.Method.CLRMethod val_37;
            // 0x010ED1B8: STP x28, x27, [sp, #-0x60]! | stack[1152921509984205504] = ???;  stack[1152921509984205512] = ???;  //  dest_result_addr=1152921509984205504 |  dest_result_addr=1152921509984205512
            // 0x010ED1BC: STP x26, x25, [sp, #0x10]  | stack[1152921509984205520] = ???;  stack[1152921509984205528] = ???;  //  dest_result_addr=1152921509984205520 |  dest_result_addr=1152921509984205528
            // 0x010ED1C0: STP x24, x23, [sp, #0x20]  | stack[1152921509984205536] = ???;  stack[1152921509984205544] = ???;  //  dest_result_addr=1152921509984205536 |  dest_result_addr=1152921509984205544
            // 0x010ED1C4: STP x22, x21, [sp, #0x30]  | stack[1152921509984205552] = ???;  stack[1152921509984205560] = ???;  //  dest_result_addr=1152921509984205552 |  dest_result_addr=1152921509984205560
            // 0x010ED1C8: STP x20, x19, [sp, #0x40]  | stack[1152921509984205568] = ???;  stack[1152921509984205576] = ???;  //  dest_result_addr=1152921509984205568 |  dest_result_addr=1152921509984205576
            // 0x010ED1CC: STP x29, x30, [sp, #0x50]  | stack[1152921509984205584] = ???;  stack[1152921509984205592] = ???;  //  dest_result_addr=1152921509984205584 |  dest_result_addr=1152921509984205592
            // 0x010ED1D0: ADD x29, sp, #0x50         | X29 = (1152921509984205504 + 80) = 1152921509984205584 (0x100000014083FB10);
            // 0x010ED1D4: SUB sp, sp, #0x20          | SP = (1152921509984205504 - 32) = 1152921509984205472 (0x100000014083FAA0);
            // 0x010ED1D8: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010ED1DC: LDRB w8, [x20, #0xae1]     | W8 = (bool)static_value_03735AE1;       
            // 0x010ED1E0: MOV w21, w4                | W21 = W4;//m1                           
            // 0x010ED1E4: MOV x19, x0                | X19 = 1152921509984217600 (0x1000000140842A00);//ML01
            val_24 = this;
            // 0x010ED1E8: STR x3, [sp, #0x18]        | stack[1152921509984205496] = ???;        //  dest_result_addr=1152921509984205496
            // 0x010ED1EC: STR x2, [sp, #0x10]        | stack[1152921509984205488] = ???;        //  dest_result_addr=1152921509984205488
            // 0x010ED1F0: TBNZ w8, #0, #0x10ed20c    | if (static_value_03735AE1 == true) goto label_0;
            // 0x010ED1F4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x010ED1F8: LDR x8, [x8, #0xa28]       | X8 = 0x2B90CA4;                         
            // 0x010ED1FC: LDR w0, [x8]               | W0 = 0x19ED;                            
            // 0x010ED200: BL #0x2782188              | X0 = sub_2782188( ?? 0x19ED, ????);     
            // 0x010ED204: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010ED208: STRB w8, [x20, #0xae1]     | static_value_03735AE1 = true;            //  dest_result_addr=57891553
            label_0:
            // 0x010ED20C: LDR x8, [x19, #0x20]       | X8 = this.parameters; //P2              
            // 0x010ED210: CBNZ x8, #0x10ed21c        | if (this.parameters != null) goto label_1;
            if(this.parameters != null)
            {
                goto label_1;
            }
            // 0x010ED214: MOV x0, x19                | X0 = 1152921509984217600 (0x1000000140842A00);//ML01
            // 0x010ED218: BL #0x10ecc24              | this.InitParameters();                  
            this.InitParameters();
            label_1:
            // 0x010ED21C: LDR x8, [x19, #0x40]       | X8 = this.param; //P2                   
            // 0x010ED220: CBZ x8, #0x10ed230         | if (this.param == null) goto label_2;   
            if(this.param == null)
            {
                goto label_2;
            }
            // 0x010ED224: STR w21, [sp, #4]          | stack[1152921509984205476] = W4;         //  dest_result_addr=1152921509984205476
            // 0x010ED228: LDR w21, [x8, #0x18]       | W21 = this.param.Length; //P2           
            val_25 = this.param.Length;
            // 0x010ED22C: B #0x10ed238               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x010ED230: STR w21, [sp, #4]          | stack[1152921509984205476] = W4;         //  dest_result_addr=1152921509984205476
            // 0x010ED234: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_25 = 0;
            label_3:
            // 0x010ED238: LDR x20, [x19, #0x68]      | X20 = this.invocationParam; //P2        
            val_26 = this.invocationParam;
            // 0x010ED23C: CBNZ x20, #0x10ed268       | if (this.invocationParam != null) goto label_4;
            if(val_26 != null)
            {
                goto label_4;
            }
            // 0x010ED240: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x010ED244: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x010ED248: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x010ED24C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED250: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x010ED254: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x010ED258: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED25C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x010ED260: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_26 = null;
            // 0x010ED264: STR x20, [x19, #0x68]      | this.invocationParam = typeof(System.Object[]);  //  dest_result_addr=1152921509984217704
            this.invocationParam = val_26;
            label_4:
            // 0x010ED268: CMP w21, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x010ED26C: STR x21, [sp, #8]          | stack[1152921509984205480] = 0x0;        //  dest_result_addr=1152921509984205480
            // 0x010ED270: B.LT #0x10ed3cc            | if (val_25 < 0x1) goto label_5;         
            if(val_25 < 1)
            {
                goto label_5;
            }
            // 0x010ED274: LDR x9, [sp, #8]           | X9 = 0x0;                               
            // 0x010ED278: ADRP x22, #0x3619000       | X22 = 56725504 (0x3619000);             
            // 0x010ED27C: LDR x22, [x22, #0x4e8]     | X22 = 1152921504782352384;              
            // 0x010ED280: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            var val_27 = 0;
            // 0x010ED284: SXTW x8, w9                | X8 = 0 (0x00000000);                    
            // 0x010ED288: ADD x21, x20, #0x20        | X21 = (val_26 + 32) = val_25 (0x1000000014B8C8B0);
            val_25 = 1152921504954501296;
            // 0x010ED28C: ADD x23, x8, #1            | X23 = (0 + 1) = 1 (0x00000001);         
            // 0x010ED290: MOV w25, w9                | W25 = 0 (0x0);//ML01                    
            var val_26 = val_25;
            label_17:
            // 0x010ED294: LDR x1, [sp, #0x10]        | X1 = ;                                  
            val_27 = ???;
            // 0x010ED298: MOV w2, w25                | W2 = 0 (0x0);//ML01                     
            // 0x010ED29C: BL #0x10ed140              | X0 = Minus(a:  null, b:  0);            
            ILRuntime.Runtime.Stack.StackObject* val_1 = Minus(a:  null, b:  0);
            // 0x010ED2A0: LDR x27, [x19, #0x40]      | X27 = this.param; //P2                  
            // 0x010ED2A4: MOV x26, x0                | X26 = val_1;//m1                        
            // 0x010ED2A8: CBNZ x27, #0x10ed2b0       | if (this.param != null) goto label_6;   
            if(this.param != null)
            {
                goto label_6;
            }
            // 0x010ED2AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x010ED2B0: LDR w8, [x27, #0x18]       | W8 = this.param.Length; //P2            
            // 0x010ED2B4: CMP x24, x8                | STATE = COMPARE(0x0, this.param.Length) 
            // 0x010ED2B8: B.LO #0x10ed2c8            | if (0 < this.param.Length) goto label_7;
            if(val_27 < this.param.Length)
            {
                goto label_7;
            }
            // 0x010ED2BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x010ED2C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x010ED2C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_7:
            // 0x010ED2C8: ADD x8, x27, x24, lsl #3   | X8 = this.param[0x0]; //PARR1           
            // 0x010ED2CC: LDR x27, [x8, #0x20]       | X27 = this.param[0x0][0]                
            System.Reflection.ParameterInfo val_25 = this.param[val_27];
            // 0x010ED2D0: CBNZ x27, #0x10ed2d8       | if (this.param[0x0][0] != null) goto label_8;
            if(val_25 != null)
            {
                goto label_8;
            }
            // 0x010ED2D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_8:
            // 0x010ED2D8: LDR x8, [x27]              | X8 = typeof(System.Reflection.ParameterInfo);
            // 0x010ED2DC: MOV x0, x27                | X0 = this.param[0x0][0];//m1            
            // 0x010ED2E0: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170; X1 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_178; //  | 
            // 0x010ED2E4: BLR x9                     | X0 = typeof(System.Reflection.ParameterInfo).__il2cppRuntimeField_170();
            // 0x010ED2E8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x010ED2EC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x010ED2F0: LDR x28, [x19, #0x30]      | X28 = this.appdomain; //P2              
            // 0x010ED2F4: MOV x27, x0                | X27 = this.param[0x0][0];//m1           
            // 0x010ED2F8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x010ED2FC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x010ED300: TBZ w9, #0, #0x10ed314     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x010ED304: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x010ED308: CBNZ w9, #0x10ed314        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x010ED30C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x010ED310: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_10:
            // 0x010ED314: LDR x3, [sp, #0x18]        | X3 = ;                                  
            // 0x010ED318: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010ED31C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            val_28 = 0;
            // 0x010ED320: MOV x1, x26                | X1 = val_1;//m1                         
            // 0x010ED324: MOV x2, x28                | X2 = this.appdomain;//m1                
            // 0x010ED328: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  val_25, mStack:  ???);
            object val_2 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  val_25, mStack:  ???);
            // 0x010ED32C: LDR x8, [x22]              | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x010ED330: MOV x26, x0                | X26 = val_2;//m1                        
            // 0x010ED334: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x010ED338: TBZ w9, #0, #0x10ed34c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x010ED33C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x010ED340: CBNZ w9, #0x10ed34c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x010ED344: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            val_29 = null;
            // 0x010ED348: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_12:
            // 0x010ED34C: MOV x1, x27                | X1 = this.param[0x0][0];//m1            
            // 0x010ED350: MOV x2, x26                | X2 = val_2;//m1                         
            // 0x010ED354: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  val_29 = null, obj:  this.param[0]);
            object val_3 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  val_29, obj:  val_25);
            // 0x010ED358: LDR x2, [x19, #0x30]       | X2 = this.appdomain; //P2               
            val_30 = this.appdomain;
            // 0x010ED35C: MOV x1, x0                 | X1 = val_3;//m1                         
            // 0x010ED360: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010ED364: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            val_31 = 0;
            // 0x010ED368: BL #0x1f96424              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.CheckAndCloneValueType(obj:  0, domain:  val_3);
            object val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.CheckAndCloneValueType(obj:  0, domain:  val_3);
            // 0x010ED36C: MOV x26, x0                | X26 = val_4;//m1                        
            // 0x010ED370: CBNZ x20, #0x10ed378       | if ( != null) goto label_13;            
            if(null != null)
            {
                goto label_13;
            }
            // 0x010ED374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x010ED378: CBZ x26, #0x10ed39c        | if (val_4 == null) goto label_15;       
            if(val_4 == null)
            {
                goto label_15;
            }
            // 0x010ED37C: LDR x8, [x20]              | X8 = ;                                  
            // 0x010ED380: MOV x0, x26                | X0 = val_4;//m1                         
            // 0x010ED384: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x010ED388: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x010ED38C: CBNZ x0, #0x10ed39c        | if (val_4 != null) goto label_15;       
            if(val_4 != null)
            {
                goto label_15;
            }
            // 0x010ED390: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x010ED394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED398: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_15:
            // 0x010ED39C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x010ED3A0: CMP x24, x8                | STATE = COMPARE(0x0, System.Object[].__il2cppRuntimeField_namespaze)
            // 0x010ED3A4: B.LO #0x10ed3b4            | if (0 < System.Object[].__il2cppRuntimeField_namespaze) goto label_16;
            // 0x010ED3A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x010ED3AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED3B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_16:
            // 0x010ED3B4: STR x26, [x21, x24, lsl #3] | System.Object[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_4;  //  dest_result_addr=1152921504954501296
            System.Object[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_4;
            // 0x010ED3B8: SUB x23, x23, #1           | X23 = (1 - 1);                          
            val_32 = 1 - 1;
            // 0x010ED3BC: SUB w25, w25, #1           | W25 = (val_25 - 1);                     
            val_26 = val_26 - 1;
            // 0x010ED3C0: ADD x24, x24, #1           | X24 = (0 + 1);                          
            val_27 = val_27 + 1;
            // 0x010ED3C4: CMP x23, #1                | STATE = COMPARE((1 - 1), 0x1)           
            // 0x010ED3C8: B.GT #0x10ed294            | if (val_32 > 0x1) goto label_17;        
            if(val_32 > 1)
            {
                goto label_17;
            }
            label_5:
            // 0x010ED3CC: LDRB w8, [x19, #0x48]      | W8 = this.isConstructor; //P2           
            // 0x010ED3D0: CBZ w8, #0x10ed428         | if (this.isConstructor == false) goto label_18;
            if(this.isConstructor == false)
            {
                goto label_18;
            }
            // 0x010ED3D4: LDR x25, [x19, #0x18]      | X25 = this.cDef; //P2                   
            val_33 = this.cDef;
            // 0x010ED3D8: CBNZ x25, #0x10ed3e0       | if (this.cDef != null) goto label_19;   
            if(val_33 != null)
            {
                goto label_19;
            }
            // 0x010ED3DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_19:
            // 0x010ED3E0: LDR w8, [sp, #4]           | W8 = W4;                                
            var val_28 = W4;
            // 0x010ED3E4: LDR x26, [sp, #8]          | X26 = 0x0;                              
            // 0x010ED3E8: AND w8, w8, #1             | W8 = (W4 & 1);                          
            val_28 = val_28 & 1;
            // 0x010ED3EC: TBZ w8, #0, #0x10ed5b0     | if (((W4 & 1) & 0x1) == 0) goto label_20;
            if((val_28 & 1) == 0)
            {
                goto label_20;
            }
            // 0x010ED3F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010ED3F4: MOV x0, x25                | X0 = this.cDef;//m1                     
            // 0x010ED3F8: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED3FC: BL #0x170ec38              | X0 = this.cDef.Invoke(parameters:  val_26);
            object val_5 = val_33.Invoke(parameters:  val_26);
            // 0x010ED400: LDP x2, x4, [sp, #0x10]    | X2 = ; X4 = ;                            //  | 
            // 0x010ED404: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x010ED408: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x010ED40C: MOV w6, wzr                | W6 = 0 (0x0);//ML01                     
            // 0x010ED410: MOV x0, x19                | X0 = 1152921509984217600 (0x1000000140842A00);//ML01
            // 0x010ED414: MOV w1, w26                | W1 = 0 (0x0);//ML01                     
            // 0x010ED418: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED41C: BL #0x10ee258              | this.FixReference(paramCount:  0, esp:  null, param:  val_25, mStack:  ???, instance:  ???, hasThis:  ???);
            this.FixReference(paramCount:  0, esp:  null, param:  val_25, mStack:  ???, instance:  ???, hasThis:  ???);
            // 0x010ED420: MOV x0, x24                | X0 = val_5;//m1                         
            val_34 = val_5;
            // 0x010ED424: B #0x10ed6a8               |  goto label_21;                         
            goto label_21;
            label_18:
            // 0x010ED428: LDR x24, [x19, #0x10]      | X24 = this.def; //P2                    
            // 0x010ED42C: CBNZ x24, #0x10ed434       | if (this.def != null) goto label_22;    
            if(this.def != null)
            {
                goto label_22;
            }
            // 0x010ED430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_22:
            // 0x010ED434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED438: MOV x0, x24                | X0 = this.def;//m1                      
            // 0x010ED43C: BL #0x13bbe68              | X0 = this.def.get_IsStatic();           
            bool val_6 = this.def.IsStatic;
            // 0x010ED440: LDR x23, [sp, #8]          | X23 = 0x0;                              
            val_32 = val_25;
            // 0x010ED444: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_35 = 0;
            // 0x010ED448: AND w8, w0, #1             | W8 = (val_6 & 1);                       
            bool val_7 = val_6;
            // 0x010ED44C: TBNZ w8, #0, #0x10ed550    | if ((val_6 & 1) == true) goto label_23; 
            if(val_7 == true)
            {
                goto label_23;
            }
            // 0x010ED450: LDR x1, [sp, #0x10]        | X1 = ;                                  
            // 0x010ED454: ADD w2, w23, #1            | W2 = (val_32 + 1) = 1 (0x00000001);     
            // 0x010ED458: BL #0x10ed140              | X0 = val_6.Minus(a:  null, b:  0);      
            ILRuntime.Runtime.Stack.StackObject* val_8 = val_6.Minus(a:  null, b:  0);
            // 0x010ED45C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x010ED460: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x010ED464: LDR x24, [x19, #0x30]      | X24 = this.appdomain; //P2              
            // 0x010ED468: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x010ED46C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x010ED470: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x010ED474: TBZ w9, #0, #0x10ed488     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x010ED478: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x010ED47C: CBNZ w9, #0x10ed488        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x010ED480: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x010ED484: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_25:
            // 0x010ED488: LDR x3, [sp, #0x18]        | X3 = ;                                  
            // 0x010ED48C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010ED490: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            val_28 = 0;
            // 0x010ED494: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x010ED498: MOV x2, x24                | X2 = this.appdomain;//m1                
            // 0x010ED49C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  val_25, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  val_25, mStack:  ???);
            // 0x010ED4A0: MOV x24, x0                | X24 = val_9;//m1                        
            // 0x010ED4A4: CBZ x24, #0x10ed4dc        | if (val_9 == null) goto label_27;       
            if(val_9 == null)
            {
                goto label_27;
            }
            // 0x010ED4A8: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x010ED4AC: LDR x8, [x8, #0xc30]       | X8 = 1152921504821649408;               
            // 0x010ED4B0: LDR x9, [x24]              | X9 = typeof(System.Object);             
            // 0x010ED4B4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x010ED4B8: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010ED4BC: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010ED4C0: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010ED4C4: B.LO #0x10ed4dc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_27;
            // 0x010ED4C8: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x010ED4CC: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.
            // 0x010ED4D0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010ED4D4: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x010ED4D8: B.EQ #0x10ed6c8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_28;
            label_27:
            // 0x010ED4DC: MOV x21, x19               | X21 = 1152921509984217600 (0x1000000140842A00);//ML01
            // 0x010ED4E0: LDR x22, [x21, #0x38]!     | X22 = this.declaringType; //P2          
            // 0x010ED4E4: CBNZ x22, #0x10ed4ec       | if (this.declaringType != null) goto label_29;
            if(this.declaringType != null)
            {
                goto label_29;
            }
            // 0x010ED4E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_29:
            // 0x010ED4EC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x010ED4F0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x010ED4F4: LDR x25, [x22, #0x10]      | X25 = this.declaringType.clrType; //P2  
            // 0x010ED4F8: LDR x0, [x8]               | X0 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x010ED4FC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x010ED500: TBZ w8, #0, #0x10ed510     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x010ED504: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x010ED508: CBNZ w8, #0x10ed510        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x010ED50C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_31:
            // 0x010ED510: MOV x1, x25                | X1 = this.declaringType.clrType;//m1    
            // 0x010ED514: MOV x2, x24                | X2 = val_9;//m1                         
            // 0x010ED518: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  null, obj:  this.declaringType.clrType);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  null, obj:  this.declaringType.clrType);
            // 0x010ED51C: MOV x24, x0                | X24 = val_10;//m1                       
            val_35 = val_10;
            label_48:
            // 0x010ED520: LDR x21, [x21]             | X21 = this.declaringType;               
            val_25 = this.declaringType;
            // 0x010ED524: CBNZ x21, #0x10ed52c       | if (this.declaringType != null) goto label_32;
            if(val_25 != null)
            {
                goto label_32;
            }
            // 0x010ED528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_32:
            // 0x010ED52C: LDRB w8, [x21, #0x19]      | W8 = this.declaringType.isValueType; //P2 
            // 0x010ED530: CBZ w8, #0x10ed54c         | if (this.declaringType.isValueType == false) goto label_33;
            if(this.declaringType.isValueType == false)
            {
                goto label_33;
            }
            // 0x010ED534: LDR x2, [x19, #0x30]       | X2 = this.appdomain; //P2               
            val_30 = this.appdomain;
            // 0x010ED538: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010ED53C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            val_31 = 0;
            // 0x010ED540: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x010ED544: BL #0x1f96424              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.CheckAndCloneValueType(obj:  0, domain:  val_35);
            object val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.CheckAndCloneValueType(obj:  0, domain:  val_35);
            // 0x010ED548: MOV x24, x0                | X24 = val_11;//m1                       
            val_35 = val_11;
            label_33:
            // 0x010ED54C: CBZ x24, #0x10ed6d0        | if (val_11 == null) goto label_44;      
            if(val_35 == null)
            {
                goto label_44;
            }
            label_23:
            // 0x010ED550: LDR x25, [x19, #0x10]      | X25 = this.def; //P2                    
            // 0x010ED554: CBNZ x25, #0x10ed55c       | if (this.def != null) goto label_35;    
            if(this.def != null)
            {
                goto label_35;
            }
            // 0x010ED558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_35:
            // 0x010ED55C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010ED560: MOV x0, x25                | X0 = this.def;//m1                      
            // 0x010ED564: MOV x1, x24                | X1 = val_11;//m1                        
            // 0x010ED568: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED56C: BL #0x13be768              | X0 = this.def.Invoke(obj:  val_35, parameters:  val_26);
            object val_12 = this.def.Invoke(obj:  val_35, parameters:  val_26);
            // 0x010ED570: LDR x26, [x19, #0x10]      | X26 = this.def; //P2                    
            // 0x010ED574: MOV x25, x0                | X25 = val_12;//m1                       
            val_33 = val_12;
            // 0x010ED578: CBNZ x26, #0x10ed580       | if (this.def != null) goto label_36;    
            if(this.def != null)
            {
                goto label_36;
            }
            // 0x010ED57C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_36:
            // 0x010ED580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED584: MOV x0, x26                | X0 = this.def;//m1                      
            // 0x010ED588: BL #0x13bbe68              | X0 = this.def.get_IsStatic();           
            bool val_13 = this.def.IsStatic;
            // 0x010ED58C: LDP x2, x4, [sp, #0x10]    | X2 = ; X4 = ;                            //  | 
            // 0x010ED590: MVN w8, w0                 | W8 = ~(val_13);                         
            // 0x010ED594: AND w6, w8, #1             | W6 = (~(val_13) & 1);                   
            var val_14 = (~val_13) & 1;
            // 0x010ED598: MOV x0, x19                | X0 = 1152921509984217600 (0x1000000140842A00);//ML01
            // 0x010ED59C: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
            // 0x010ED5A0: MOV x3, x20                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED5A4: MOV x5, x24                | X5 = val_11;//m1                        
            // 0x010ED5A8: BL #0x10ee258              | this.FixReference(paramCount:  0, esp:  null, param:  val_25, mStack:  ???, instance:  ???, hasThis:  ???);
            this.FixReference(paramCount:  0, esp:  null, param:  val_25, mStack:  ???, instance:  ???, hasThis:  ???);
            // 0x010ED5AC: B #0x10ed6a4               |  goto label_46;                         
            goto label_46;
            label_20:
            // 0x010ED5B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED5B4: MOV x0, x25                | X0 = this.cDef;//m1                     
            // 0x010ED5B8: BL #0x13bbe68              | X0 = this.cDef.get_IsStatic();          
            bool val_15 = val_33.IsStatic;
            // 0x010ED5BC: AND w8, w0, #1             | W8 = (val_15 & 1);                      
            bool val_16 = val_15;
            // 0x010ED5C0: TBNZ w8, #0, #0x10ed6f0    | if ((val_15 & 1) == true) goto label_38;
            if(val_16 == true)
            {
                goto label_38;
            }
            // 0x010ED5C4: LDR x21, [x19, #0x38]      | X21 = this.declaringType; //P2          
            val_25 = this.declaringType;
            // 0x010ED5C8: CBNZ x21, #0x10ed5d0       | if (this.declaringType != null) goto label_39;
            if(val_25 != null)
            {
                goto label_39;
            }
            // 0x010ED5CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_39:
            // 0x010ED5D0: LDR x1, [sp, #0x10]        | X1 = ;                                  
            // 0x010ED5D4: LDR x24, [x21, #0x10]      | X24 = this.declaringType.clrType; //P2  
            // 0x010ED5D8: ADD w2, w26, #1            | W2 = (val_25 + 1);                      
            var val_17 = val_25 + 1;
            // 0x010ED5DC: BL #0x10ed140              | X0 = val_15.Minus(a:  null, b:  0);     
            ILRuntime.Runtime.Stack.StackObject* val_18 = val_15.Minus(a:  null, b:  0);
            // 0x010ED5E0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x010ED5E4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x010ED5E8: LDR x23, [x19, #0x30]      | X23 = this.appdomain; //P2              
            val_32 = this.appdomain;
            // 0x010ED5EC: MOV x25, x0                | X25 = val_18;//m1                       
            // 0x010ED5F0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x010ED5F4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x010ED5F8: TBZ w9, #0, #0x10ed60c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_41;
            // 0x010ED5FC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x010ED600: CBNZ w9, #0x10ed60c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x010ED604: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x010ED608: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_41:
            // 0x010ED60C: LDR x3, [sp, #0x18]        | X3 = ;                                  
            val_31 = ???;
            // 0x010ED610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010ED614: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x010ED618: MOV x1, x25                | X1 = val_18;//m1                        
            // 0x010ED61C: MOV x2, x23                | X2 = this.appdomain;//m1                
            // 0x010ED620: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  val_25, mStack:  ???);
            object val_19 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  val_25, mStack:  ???);
            // 0x010ED624: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x010ED628: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x010ED62C: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x010ED630: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x010ED634: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x010ED638: TBZ w9, #0, #0x10ed64c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x010ED63C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x010ED640: CBNZ w9, #0x10ed64c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x010ED644: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            val_36 = null;
            // 0x010ED648: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_43:
            // 0x010ED64C: MOV x1, x24                | X1 = this.declaringType.clrType;//m1    
            // 0x010ED650: MOV x2, x22                | X2 = val_19;//m1                        
            val_30 = val_19;
            // 0x010ED654: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  val_36 = null, obj:  this.declaringType.clrType);
            object val_20 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  val_36, obj:  this.declaringType.clrType);
            // 0x010ED658: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x010ED65C: CBZ x22, #0x10ed6d0        | if (val_20 == null) goto label_44;      
            if(val_20 == null)
            {
                goto label_44;
            }
            // 0x010ED660: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x010ED664: LDR x8, [x8, #0xa58]       | X8 = 1152921504824418304;               
            // 0x010ED668: MOV x0, x22                | X0 = val_20;//m1                        
            // 0x010ED66C: LDR x1, [x8]               | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x010ED670: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
            // 0x010ED674: CBNZ w26, #0x10ed680       | if (0x0 != 0) goto label_45;            
            if(val_25 != 0)
            {
                goto label_45;
            }
            // 0x010ED678: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_33 = 0;
            // 0x010ED67C: CBNZ x0, #0x10ed6a4        | if (val_20 != null) goto label_46;      
            if(val_20 != null)
            {
                goto label_46;
            }
            label_45:
            // 0x010ED680: LDR x19, [x19, #0x18]      | X19 = this.cDef; //P2                   
            val_24 = this.cDef;
            // 0x010ED684: CBNZ x19, #0x10ed68c       | if (this.cDef != null) goto label_47;   
            if(val_24 != null)
            {
                goto label_47;
            }
            // 0x010ED688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_47:
            // 0x010ED68C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010ED690: MOV x0, x19                | X0 = this.cDef;//m1                     
            // 0x010ED694: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x010ED698: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x010ED69C: BL #0x13be768              | X0 = this.cDef.Invoke(obj:  val_20, parameters:  val_26);
            object val_21 = val_24.Invoke(obj:  val_20, parameters:  val_26);
            // 0x010ED6A0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_33 = 0;
            label_46:
            // 0x010ED6A4: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            val_34 = val_33;
            label_21:
            // 0x010ED6A8: SUB sp, x29, #0x50         | SP = (1152921509984205584 - 80) = 1152921509984205504 (0x100000014083FAC0);
            // 0x010ED6AC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010ED6B0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010ED6B4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010ED6B8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010ED6BC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010ED6C0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010ED6C4: RET                        |  return (System.Object)null;            
            return (object)val_34;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_28:
            // 0x010ED6C8: ADD x21, x19, #0x38        | X21 = this.declaringType;//AP2 res_addr=1152921509984217656
            // 0x010ED6CC: B #0x10ed520               |  goto label_48;                         
            goto label_48;
            label_44:
            // 0x010ED6D0: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x010ED6D4: LDR x8, [x8, #0x688]       | X8 = 1152921504655462400;               
            // 0x010ED6D8: LDR x0, [x8]               | X0 = typeof(System.NullReferenceException);
            System.NullReferenceException val_22 = null;
            // 0x010ED6DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NullReferenceException), ????);
            // 0x010ED6E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED6E4: MOV x19, x0                | X19 = 1152921504655462400 (0x1000000002E5D000);//ML01
            val_37 = val_22;
            // 0x010ED6E8: BL #0x1701740              | .ctor();                                
            val_22 = new System.NullReferenceException();
            // 0x010ED6EC: B #0x10ed70c               |  goto label_49;                         
            goto label_49;
            label_38:
            // 0x010ED6F0: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x010ED6F4: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x010ED6F8: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_23 = null;
            // 0x010ED6FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x010ED700: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010ED704: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            val_37 = val_23;
            // 0x010ED708: BL #0x17014c0              | .ctor();                                
            val_23 = new System.NotImplementedException();
            label_49:
            // 0x010ED70C: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x010ED710: LDR x8, [x8, #0x740]       | X8 = 1152921509984192576;               
            // 0x010ED714: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_24 = val_37;
            // 0x010ED718: LDR x1, [x8]               | X1 = public System.Object ILRuntime.CLR.Method.CLRMethod::Invoke(ILRuntime.Runtime.Intepreter.ILIntepreter intepreter, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, bool isNewObj);
            // 0x010ED71C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x010ED720: BL #0x10ec5ac              | .ctor(def:  public System.Object ILRuntime.CLR.Method.CLRMethod::Invoke(ILRuntime.Runtime.Intepreter.ILIntepreter intepreter, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, bool isNewObj), type:  val_30 = this.appdomain, domain:  val_31 = 0);
            val_24 = new ILRuntime.CLR.Method.CLRMethod(def:  public System.Object ILRuntime.CLR.Method.CLRMethod::Invoke(ILRuntime.Runtime.Intepreter.ILIntepreter intepreter, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, bool isNewObj), type:  val_30, domain:  val_31);
        
        }
        //
        // Offset in libil2cpp.so: 0x010EE258 (17752664), len: 2188  VirtAddr: 0x010EE258 RVA: 0x010EE258 token: 100663339 methodIndex: 28784 delegateWrapperIndex: 0 methodInvoker: 0
        private void FixReference(int paramCount, ILRuntime.Runtime.Stack.StackObject* esp, object[] param, System.Collections.Generic.IList<object> mStack, object instance, bool hasThis)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_17;
            //  | 
            var val_19;
            //  | 
            var val_24;
            //  | 
            ILRuntime.Runtime.Enviorment.AppDomain val_25;
            //  | 
            var val_26;
            //  | 
            int val_27;
            //  | 
            object val_28;
            //  | 
            int val_29;
            //  | 
            object val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            object val_36;
            //  | 
            var val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            // 0x010EE258: STP x28, x27, [sp, #-0x60]! | stack[1152921509984612416] = ???;  stack[1152921509984612424] = ???;  //  dest_result_addr=1152921509984612416 |  dest_result_addr=1152921509984612424
            // 0x010EE25C: STP x26, x25, [sp, #0x10]  | stack[1152921509984612432] = ???;  stack[1152921509984612440] = ???;  //  dest_result_addr=1152921509984612432 |  dest_result_addr=1152921509984612440
            // 0x010EE260: STP x24, x23, [sp, #0x20]  | stack[1152921509984612448] = ???;  stack[1152921509984612456] = ???;  //  dest_result_addr=1152921509984612448 |  dest_result_addr=1152921509984612456
            // 0x010EE264: STP x22, x21, [sp, #0x30]  | stack[1152921509984612464] = ???;  stack[1152921509984612472] = ???;  //  dest_result_addr=1152921509984612464 |  dest_result_addr=1152921509984612472
            // 0x010EE268: STP x20, x19, [sp, #0x40]  | stack[1152921509984612480] = ???;  stack[1152921509984612488] = ???;  //  dest_result_addr=1152921509984612480 |  dest_result_addr=1152921509984612488
            // 0x010EE26C: STP x29, x30, [sp, #0x50]  | stack[1152921509984612496] = ???;  stack[1152921509984612504] = ???;  //  dest_result_addr=1152921509984612496 |  dest_result_addr=1152921509984612504
            // 0x010EE270: ADD x29, sp, #0x50         | X29 = (1152921509984612416 + 80) = 1152921509984612496 (0x10000001408A3090);
            // 0x010EE274: SUB sp, sp, #0x60          | SP = (1152921509984612416 - 96) = 1152921509984612320 (0x10000001408A2FE0);
            // 0x010EE278: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010EE27C: LDRB w8, [x20, #0xae2]     | W8 = (bool)static_value_03735AE2;       
            // 0x010EE280: MOV w24, w6                | W24 = W6;//m1                           
            // 0x010EE284: MOV x19, x5                | X19 = X5;//m1                           
            val_24 = X5;
            // 0x010EE288: MOV x28, x4                | X28 = X4;//m1                           
            val_25 = X4;
            // 0x010EE28C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x010EE290: MOV x22, x2                | X22 = X2;//m1                           
            // 0x010EE294: STP x22, x28, [sp, #0x10]  | stack[1152921509984612336] = X2;  stack[1152921509984612344] = X4;  //  dest_result_addr=1152921509984612336 |  dest_result_addr=1152921509984612344
            // 0x010EE298: STP x0, x1, [sp, #0x20]    | stack[1152921509984612352] = this;  stack[1152921509984612360] = paramCount;  //  dest_result_addr=1152921509984612352 |  dest_result_addr=1152921509984612360
            // 0x010EE29C: TBNZ w8, #0, #0x10ee2b8    | if (static_value_03735AE2 == true) goto label_0;
            // 0x010EE2A0: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x010EE2A4: LDR x8, [x8, #0x190]       | X8 = 0x2B90C98;                         
            // 0x010EE2A8: LDR w0, [x8]               | W0 = 0x19EA;                            
            // 0x010EE2AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x19EA, ????);     
            // 0x010EE2B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EE2B4: STRB w8, [x20, #0xae2]     | static_value_03735AE2 = true;            //  dest_result_addr=57891554
            label_0:
            // 0x010EE2B8: LDR x9, [sp, #0x28]        | X9 = paramCount;                        
            // 0x010EE2BC: AND w8, w24, #1            | W8 = (W6 & 1);                          
            var val_1 = W6 & 1;
            // 0x010EE2C0: ADD w8, w8, w9             | W8 = ((W6 & 1) + paramCount);           
            val_1 = val_1 + paramCount;
            // 0x010EE2C4: CMP w8, #1                 | STATE = COMPARE(((W6 & 1) + paramCount), 0x1)
            // 0x010EE2C8: B.LT #0x10eea74            | if (val_1 < 1) goto label_7;            
            if(val_1 < 1)
            {
                goto label_7;
            }
            // 0x010EE2CC: SXTW x25, w8               | X25 = (long)(int)(((W6 & 1) + paramCount));
            val_26 = (long)val_1;
            // 0x010EE2D0: LDR x8, [sp, #0x28]        | X8 = paramCount;                        
            // 0x010EE2D4: ADRP x20, #0x2a99000       | X20 = 44666880 (0x2A99000);             
            // 0x010EE2D8: ADD x20, x20, #0x7d0       | X20 = (44666880 + 2000) = 44668880 (0x02A997D0);
            // 0x010EE2DC: SXTW x24, w8               | X24 = (long)(int)(paramCount);          
            // 0x010EE2E0: STR x24, [sp, #8]          | stack[1152921509984612328] = (long)(int)(paramCount);  //  dest_result_addr=1152921509984612328
            label_75:
            // 0x010EE2E4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x010EE2E8: MOV w2, w25                | W2 = (long)(int)(((W6 & 1) + paramCount));//m1
            // 0x010EE2EC: BL #0x10ed140              | X0 = this.Minus(a:  null, b:  (long)paramCount);
            ILRuntime.Runtime.Stack.StackObject* val_2 = this.Minus(a:  null, b:  (long)paramCount);
            // 0x010EE2F0: MOV x27, x0                | X27 = val_2;//m1                        
            val_27 = val_2;
            // 0x010EE2F4: CMP x25, x24               | STATE = COMPARE((long)(int)(((W6 & 1) + paramCount)), (long)(int)(paramCount))
            // 0x010EE2F8: MOV x26, x19               | X26 = X5;//m1                           
            val_28 = val_24;
            // 0x010EE2FC: B.GT #0x10ee334            | if (val_26 > (long)paramCount) goto label_2;
            if(val_26 > (long)paramCount)
            {
                goto label_2;
            }
            // 0x010EE300: CBNZ x21, #0x10ee308       | if (X3 != 0) goto label_3;              
            if(X3 != 0)
            {
                goto label_3;
            }
            // 0x010EE304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x010EE308: LDR x9, [sp, #0x28]        | X9 = paramCount;                        
            int val_20 = paramCount;
            // 0x010EE30C: LDR w8, [x21, #0x18]       | W8 = X3 + 24;                           
            // 0x010EE310: SUB w9, w9, w25            | W9 = (paramCount - (long)(int)(((W6 & 1) + paramCount)));
            val_20 = val_20 - val_26;
            // 0x010EE314: SXTW x23, w9               | X23 = (long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))));
            val_29 = (long)val_20;
            // 0x010EE318: CMP w9, w8                 | STATE = COMPARE((paramCount - (long)(int)(((W6 & 1) + paramCount))), X3 + 24)
            // 0x010EE31C: B.LO #0x10ee32c            | if (paramCount < X3 + 24) goto label_4; 
            if(val_20 < (X3 + 24))
            {
                goto label_4;
            }
            // 0x010EE320: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x010EE324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE328: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_4:
            // 0x010EE32C: ADD x8, x21, x23, lsl #3   | X8 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3);
            var val_3 = X3 + (((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3);
            // 0x010EE330: LDR x26, [x8, #0x20]       | X26 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;
            val_28 = mem[(X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32];
            val_28 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;
            label_2:
            // 0x010EE334: CBNZ x27, #0x10ee33c       | if (val_2 != 0) goto label_5;           
            if(val_27 != 0)
            {
                goto label_5;
            }
            // 0x010EE338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x010EE33C: LDR w8, [x27]              | W8 = val_2;                             
            var val_21 = val_27;
            // 0x010EE340: SUB w8, w8, #5             | W8 = (val_2 - 5);                       
            val_21 = val_21 - 5;
            // 0x010EE344: CMP w8, #6                 | STATE = COMPARE((val_2 - 5), 0x6)       
            // 0x010EE348: B.HI #0x10eea6c            | if (val_27 > 0x6) goto label_68;        
            if(val_21 > 6)
            {
                goto label_68;
            }
            // 0x010EE34C: ADRP x9, #0x2a99000        | X9 = 44666880 (0x2A99000);              
            // 0x010EE350: ADD x9, x9, #0x8f0         | X9 = (44666880 + 2288) = 44669168 (0x02A998F0);
            // 0x010EE354: LDR w8, [x9, w8, sxtw #2]  | W8 = 44669168 + ((val_2 - 5)) << 2;     
            // 0x010EE358: CMP w8, #0xd               | STATE = COMPARE(44669168 + ((val_2 - 5)) << 2, 0xD)
            // 0x010EE35C: B.HI #0x10eea74            | if (44669168 + ((val_2 - 5)) << 2 > 0xD) goto label_7;
            if((44669168 + ((val_2 - 5)) << 2) > 13)
            {
                goto label_7;
            }
            // 0x010EE360: LDRSW x8, [x20, x8, lsl #2] | X8 = 44668880 + (44669168 + ((val_2 - 5)) << 2) << 2;
            var val_22 = 44668880 + (44669168 + ((val_2 - 5)) << 2) << 2;
            // 0x010EE364: ADD x8, x8, x20            | X8 = (44668880 + (44669168 + ((val_2 - 5)) << 2) << 2 + 44668880);
            val_22 = val_22 + 44668880;
            // 0x010EE368: BR x8                      | goto (44668880 + (44669168 + ((val_2 - 5)) << 2) << 2 + 44668880);
            goto (44668880 + (44669168 + ((val_2 - 5)) << 2) << 2 + 44668880);
            // 0x010EE36C: LDUR x27, [x27, #4]        | X27 = val_2 + 4;                        
            val_27 = mem[val_2 + 4];
            val_27 = val_2 + 4;
            // 0x010EE370: CBNZ x27, #0x10ee378       | if (val_2 + 4 != 0) goto label_8;       
            if(val_27 != 0)
            {
                goto label_8;
            }
            // 0x010EE374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x010EE378: LDR w8, [x27]              | W8 = val_2 + 4;                         
            // 0x010EE37C: CMP w8, #9                 | STATE = COMPARE(val_2 + 4, 0x9)         
            // 0x010EE380: B.GE #0x10ee5a4            | if (val_27 >= 0x9) goto label_9;        
            if(val_27 >= 9)
            {
                goto label_9;
            }
            // 0x010EE384: LDR x8, [sp, #0x20]        | X8 = this;                              
            // 0x010EE388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x010EE38C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x010EE390: MOV x1, x27                | X1 = val_2 + 4;//m1                     
            // 0x010EE394: LDR x4, [x8, #0x30]        | X4 = mem[1152921509984624560];          
            // 0x010EE398: MOV x2, x26                | X2 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE39C: MOV x3, x28                | X3 = X4;//m1                            
            // 0x010EE3A0: BL #0x1f9b634              | ILRuntime.Runtime.Intepreter.ILIntepreter.UnboxObject(esp:  null, obj:  (long)paramCount, mStack:  X2, domain:  val_25);
            ILRuntime.Runtime.Intepreter.ILIntepreter.UnboxObject(esp:  null, obj:  (long)paramCount, mStack:  X2, domain:  val_25);
            // 0x010EE3A4: B #0x10eea6c               |  goto label_68;                         
            goto label_68;
            // 0x010EE3A8: LDR x8, [sp, #0x20]        | X8 = this;                              
            // 0x010EE3AC: MOV x22, x19               | X22 = X5;//m1                           
            // 0x010EE3B0: MOV x19, x24               | X19 = (long)(int)(paramCount);//m1      
            // 0x010EE3B4: LDR w23, [x27, #4]         | W23 = val_2 + 4 + 4;                    
            val_29 = mem[val_2 + 4 + 4];
            val_29 = val_2 + 4 + 4;
            // 0x010EE3B8: LDR x24, [x8, #0x30]       | X24 = mem[1152921509984624560];         
            // 0x010EE3BC: CBNZ x24, #0x10ee3c4       | if (mem[1152921509984624560] != 0) goto label_11;
            if(mem[1152921509984624560] != 0)
            {
                goto label_11;
            }
            // 0x010EE3C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_11:
            // 0x010EE3C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010EE3C8: MOV x0, x24                | X0 = mem[1152921509984624560];//m1      
            // 0x010EE3CC: MOV w1, w23                | W1 = val_2 + 4 + 4;//m1                 
            // 0x010EE3D0: BL #0x28df874              | X0 = mem[1152921509984624560].GetType(hash:  val_29);
            ILRuntime.CLR.TypeSystem.IType val_4 = mem[1152921509984624560].GetType(hash:  val_29);
            // 0x010EE3D4: MOV x28, x0                | X28 = val_4;//m1                        
            val_30 = val_4;
            // 0x010EE3D8: CBZ x28, #0x10ee410        | if (val_4 == null) goto label_13;       
            if(val_30 == null)
            {
                goto label_13;
            }
            // 0x010EE3DC: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x010EE3E0: LDR x9, [x28]              | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EE3E4: LDR x8, [x8, #0x108]       | X8 = 1152921504782192640;               
            // 0x010EE3E8: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE3EC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.ILType);
            // 0x010EE3F0: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE3F4: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE3F8: B.LO #0x10ee410            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x010EE3FC: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010EE400: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010EE404: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE408: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.ILType))
            // 0x010EE40C: B.EQ #0x10ee838            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x010EE410: CBNZ x27, #0x10ee418       | if (val_2 + 4 != 0) goto label_15;      
            if(val_27 != 0)
            {
                goto label_15;
            }
            // 0x010EE414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_15:
            // 0x010EE418: LDR w27, [x27, #8]         | W27 = val_2 + 4 + 8;                    
            val_27 = mem[val_2 + 4 + 8];
            val_27 = val_2 + 4 + 8;
            // 0x010EE41C: MOV x24, x19               | X24 = (long)(int)(paramCount);//m1      
            // 0x010EE420: CBZ x28, #0x10ee658        | if (val_4 == null) goto label_16;       
            if(val_30 == null)
            {
                goto label_16;
            }
            // 0x010EE424: ADRP x9, #0x35c2000        | X9 = 56369152 (0x35C2000);              
            // 0x010EE428: LDR x8, [x28]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EE42C: LDR x9, [x9, #0x290]       | X9 = 1152921504782032896;               
            // 0x010EE430: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE434: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010EE438: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE43C: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE440: MOV x19, x22               | X19 = X5;//m1                           
            val_24 = val_24;
            // 0x010EE444: B.LO #0x10ee45c            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x010EE448: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010EE44C: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010EE450: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE454: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010EE458: B.EQ #0x10ee484            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_18;
            label_17:
            // 0x010EE45C: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010EE460: ADD x8, sp, #0x50          | X8 = (1152921509984612320 + 80) = 1152921509984612400 (0x10000001408A3030);
            // 0x010EE464: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010EE468: LDR x0, [sp, #0x50]        | X0 = val_6;                              //  find_add[1152921509984600512]
            // 0x010EE46C: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x010EE470: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE474: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x010EE478: ADD x0, sp, #0x50          | X0 = (1152921509984612320 + 80) = 1152921509984612400 (0x10000001408A3030);
            // 0x010EE47C: BL #0x299a140              | 
            // 0x010EE480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001408A3030, ????);
            label_18:
            // 0x010EE484: ADRP x9, #0x35c2000        | X9 = 56369152 (0x35C2000);              
            // 0x010EE488: LDR x8, [x28]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EE48C: LDR x9, [x9, #0x290]       | X9 = 1152921504782032896;               
            // 0x010EE490: LDR x22, [sp, #0x10]       | X22 = X2;                               
            // 0x010EE494: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE498: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010EE49C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE4A0: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE4A4: B.LO #0x10ee4bc            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_19;
            // 0x010EE4A8: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010EE4AC: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010EE4B0: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE4B4: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010EE4B8: B.EQ #0x10ee668            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_21;
            label_19:
            // 0x010EE4BC: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x010EE4C0: ADD x8, sp, #0x58          | X8 = (1152921509984612320 + 88) = 1152921509984612408 (0x10000001408A3038);
            // 0x010EE4C4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x010EE4C8: LDR x0, [sp, #0x58]        | X0 = val_8;                              //  find_add[1152921509984600512]
            // 0x010EE4CC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x010EE4D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE4D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x010EE4D8: ADD x0, sp, #0x58          | X0 = (1152921509984612320 + 88) = 1152921509984612408 (0x10000001408A3038);
            // 0x010EE4DC: BL #0x299a140              | 
            // 0x010EE4E0: MOV x28, xzr               | X28 = 0 (0x0);//ML01                    
            val_30 = 0;
            // 0x010EE4E4: B #0x10ee668               |  goto label_21;                         
            goto label_21;
            // 0x010EE4E8: LDR w24, [x27, #4]         | W24 = val_2 + 4 + 8 + 4;                
            // 0x010EE4EC: CBNZ x28, #0x10ee4f4       | if (0x0 != 0) goto label_22;            
            if(val_30 != 0)
            {
                goto label_22;
            }
            // 0x010EE4F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001408A3038, ????);
            label_22:
            // 0x010EE4F4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x010EE4F8: LDR x8, [x28]              | X8 = 0x10102464C457F;                   
            var val_28 = 1179403647;
            // 0x010EE4FC: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x010EE500: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x010EE504: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x010EE508: CBZ x9, #0x10ee534         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x010EE50C: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_23 = mem[282584257676823];
            // 0x010EE510: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x010EE514: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_23 = val_23 + 8;
            label_25:
            // 0x010EE518: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x010EE51C: CMP x12, x1                | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(System.Collections.Generic.IList<T>))
            // 0x010EE520: B.EQ #0x10ee680            | if ((mem[282584257676823] + 8) + -8 == null) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_24;
            }
            // 0x010EE524: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x010EE528: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_23 = val_23 + 16;
            // 0x010EE52C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x010EE530: B.LO #0x10ee518            | if (0 < mem[282584257676929]) goto label_25;
            if(val_24 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x010EE534: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x010EE538: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            val_31 = val_30;
            // 0x010EE53C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x010EE540: B #0x10ee690               |  goto label_26;                         
            goto label_26;
            // 0x010EE544: MOV x23, x24               | X23 = val_2 + 4 + 8 + 4;//m1            
            val_29 = val_2 + 4 + 8 + 4;
            // 0x010EE548: LDR w24, [x27, #4]         | W24 = val_2 + 4 + 8 + 4;                
            // 0x010EE54C: CBNZ x28, #0x10ee554       | if (0x0 != 0) goto label_27;            
            if(val_30 != 0)
            {
                goto label_27;
            }
            // 0x010EE550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_27:
            // 0x010EE554: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x010EE558: LDR x8, [x28]              | X8 = 0x10102464C457F;                   
            var val_30 = 1179403647;
            // 0x010EE55C: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x010EE560: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x010EE564: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x010EE568: CBZ x9, #0x10ee594         | if (mem[282584257676929] == 0) goto label_28;
            if(mem[282584257676929] == 0)
            {
                goto label_28;
            }
            // 0x010EE56C: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_25 = mem[282584257676823];
            // 0x010EE570: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_26 = 0;
            // 0x010EE574: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_25 = val_25 + 8;
            label_30:
            // 0x010EE578: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x010EE57C: CMP x12, x1                | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(System.Collections.Generic.IList<T>))
            // 0x010EE580: B.EQ #0x10ee74c            | if ((mem[282584257676823] + 8) + -8 == null) goto label_29;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_29;
            }
            // 0x010EE584: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_26 = val_26 + 1;
            // 0x010EE588: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_25 = val_25 + 16;
            // 0x010EE58C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x010EE590: B.LO #0x10ee578            | if (0 < mem[282584257676929]) goto label_30;
            if(val_26 < mem[282584257676929])
            {
                goto label_30;
            }
            label_28:
            // 0x010EE594: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x010EE598: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            val_32 = val_30;
            // 0x010EE59C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x010EE5A0: B #0x10ee75c               |  goto label_31;                         
            goto label_31;
            label_9:
            // 0x010EE5A4: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x010EE5A8: LDR x8, [x8, #0xa58]       | X8 = 1152921504824418304;               
            // 0x010EE5AC: MOV x0, x26                | X0 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE5B0: LDR x1, [x8]               | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_33 = null;
            // 0x010EE5B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32, ????);
            // 0x010EE5B8: MOV x23, x24               | X23 = (long)(int)(paramCount);//m1      
            val_29 = (long)paramCount;
            // 0x010EE5BC: CBZ x0, #0x10ee9e0         | if ((X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 == 0) goto label_32;
            if(val_28 == 0)
            {
                goto label_32;
            }
            // 0x010EE5C0: CBZ x26, #0x10ee880        | if ((X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 == 0) goto label_33;
            if(val_28 == 0)
            {
                goto label_33;
            }
            // 0x010EE5C4: ADRP x28, #0x365d000       | X28 = 57004032 (0x365D000);             
            // 0x010EE5C8: LDR x28, [x28, #0xa58]     | X28 = 1152921504824418304;              
            // 0x010EE5CC: MOV x0, x26                | X0 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE5D0: LDR x24, [x28]             | X24 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x010EE5D4: MOV x1, x24                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x010EE5D8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32, ????);
            // 0x010EE5DC: CBNZ x0, #0x10ee610        | if ((X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 != 0) goto label_34;
            if(val_28 != 0)
            {
                goto label_34;
            }
            // 0x010EE5E0: LDR x8, [x26]              | X8 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;
            // 0x010EE5E4: MOV x1, x24                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x010EE5E8: LDR x0, [x8, #0x30]        | X0 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 + 48;
            // 0x010EE5EC: ADD x8, sp, #0x30          | X8 = (1152921509984612320 + 48) = 1152921509984612368 (0x10000001408A3010);
            // 0x010EE5F0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 + 48, ????);
            // 0x010EE5F4: LDR x0, [sp, #0x30]        | X0 = val_9;                              //  find_add[1152921509984600512]
            // 0x010EE5F8: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x010EE5FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE600: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x010EE604: ADD x0, sp, #0x30          | X0 = (1152921509984612320 + 48) = 1152921509984612368 (0x10000001408A3010);
            // 0x010EE608: BL #0x299a140              | 
            // 0x010EE60C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001408A3010, ????);
            label_34:
            // 0x010EE610: LDR x28, [x28]             | X28 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_34 = null;
            // 0x010EE614: MOV x0, x26                | X0 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE618: MOV x1, x28                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_33 = val_34;
            // 0x010EE61C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32, ????);
            // 0x010EE620: MOV x24, x0                | X24 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            val_35 = val_28;
            // 0x010EE624: CBNZ x24, #0x10ee894       | if ((X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 != 0) goto label_35;
            if(val_35 != 0)
            {
                goto label_35;
            }
            // 0x010EE628: LDR x8, [x26]              | X8 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;
            // 0x010EE62C: MOV x1, x28                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x010EE630: LDR x0, [x8, #0x30]        | X0 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 + 48;
            // 0x010EE634: ADD x8, sp, #0x38          | X8 = (1152921509984612320 + 56) = 1152921509984612376 (0x10000001408A3018);
            // 0x010EE638: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32 + 48, ????);
            // 0x010EE63C: LDR x0, [sp, #0x38]        | X0 = val_10;                             //  find_add[1152921509984600512]
            // 0x010EE640: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x010EE644: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_33 = 0;
            // 0x010EE648: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x010EE64C: ADD x0, sp, #0x38          | X0 = (1152921509984612320 + 56) = 1152921509984612376 (0x10000001408A3018);
            // 0x010EE650: BL #0x299a140              | 
            // 0x010EE654: B #0x10ee890               |  goto label_36;                         
            goto label_36;
            label_16:
            // 0x010EE658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x010EE65C: MOV x19, x22               | X19 = X5;//m1                           
            val_24 = val_24;
            // 0x010EE660: LDR x22, [sp, #0x10]       | X22 = X2;                               
            // 0x010EE664: MOV x28, xzr               | X28 = 0 (0x0);//ML01                    
            val_30 = 0;
            label_21:
            // 0x010EE668: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            // 0x010EE66C: MOV w1, w27                | W1 = val_2 + 4 + 8;//m1                 
            // 0x010EE670: MOV x2, x26                | X2 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE674: BL #0x10eece4              | val_30.SetStaticFieldValue(hash:  val_27, value:  val_28);
            val_30.SetStaticFieldValue(hash:  val_27, value:  val_28);
            // 0x010EE678: LDR x28, [sp, #0x18]       | X28 = X4;                               
            // 0x010EE67C: B #0x10eea6c               |  goto label_68;                         
            goto label_68;
            label_24:
            // 0x010EE680: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_27 = val_23;
            // 0x010EE684: ADD w9, w9, #3             | W9 = ((mem[282584257676823] + 8) + 3);  
            val_27 = val_27 + 3;
            // 0x010EE688: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 3));
            val_28 = val_28 + val_27;
            // 0x010EE68C: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272);
            val_31 = val_28 + 272;
            label_26:
            // 0x010EE690: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272) + 8; //  | 
            // 0x010EE694: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            // 0x010EE698: MOV w1, w24                | W1 = val_2 + 4 + 8 + 4;//m1             
            // 0x010EE69C: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272)();
            // 0x010EE6A0: MOV x28, x0                | X28 = 0 (0x0);//ML01                    
            val_36 = val_30;
            // 0x010EE6A4: CBZ x28, #0x10ee6e8        | if (0x0 == 0) goto label_38;            
            if(val_36 == 0)
            {
                goto label_38;
            }
            // 0x010EE6A8: ADRP x9, #0x35dd000        | X9 = 56479744 (0x35DD000);              
            // 0x010EE6AC: LDR x8, [x28]              | X8 = 0x10102464C457F;                   
            // 0x010EE6B0: LDR x9, [x9, #0xb50]       | X9 = 1152921504825909248;               
            // 0x010EE6B4: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x010EE6B8: LDR x1, [x9]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x010EE6BC: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE6C0: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE6C4: B.LO #0x10ee6dc            | if (mem[282584257676931] < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_39;
            // 0x010EE6C8: LDR x11, [x8, #0xb0]       | X11 = mem[282584257676847];             
            // 0x010EE6CC: ADD x11, x11, x9, lsl #3   | X11 = (mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_type
            // 0x010EE6D0: LDUR x11, [x11, #-8]       | X11 = (mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE6D4: CMP x11, x1                | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x010EE6D8: B.EQ #0x10ee8dc            | if ((mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_40;
            label_39:
            // 0x010EE6DC: LDR x8, [sp, #0x20]        | X8 = this;                              
            // 0x010EE6E0: LDR x24, [x8, #0x30]       | X24 = mem[1152921509984624560];         
            val_37 = mem[1152921509984624560];
            // 0x010EE6E4: B #0x10ee6f4               |  goto label_41;                         
            goto label_41;
            label_38:
            // 0x010EE6E8: LDR x8, [sp, #0x20]        | X8 = this;                              
            // 0x010EE6EC: LDR x24, [x8, #0x30]       | X24 = mem[1152921509984624560];         
            val_37 = mem[1152921509984624560];
            // 0x010EE6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_41:
            // 0x010EE6F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE6F8: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            // 0x010EE6FC: BL #0x16fb28c              | X0 = val_36.GetType();                  
            System.Type val_11 = val_36.GetType();
            // 0x010EE700: MOV x23, x0                | X23 = val_11;//m1                       
            // 0x010EE704: CBNZ x24, #0x10ee70c       | if (mem[1152921509984624560] != 0) goto label_42;
            if(val_37 != 0)
            {
                goto label_42;
            }
            // 0x010EE708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_42:
            // 0x010EE70C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x010EE710: MOV x0, x24                | X0 = mem[1152921509984624560];//m1      
            // 0x010EE714: MOV x1, x23                | X1 = val_11;//m1                        
            // 0x010EE718: BL #0x28e5da8              | X0 = mem[1152921509984624560].GetType(t:  val_11);
            ILRuntime.CLR.TypeSystem.IType val_12 = val_37.GetType(t:  val_11);
            // 0x010EE71C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_38 = 0;
            // 0x010EE720: CBZ x0, #0x10ee7ec         | if (val_12 == null) goto label_45;      
            if(val_12 == null)
            {
                goto label_45;
            }
            // 0x010EE724: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x010EE728: LDR x9, [x0]               | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EE72C: LDR x8, [x8, #0x290]       | X8 = 1152921504782032896;               
            // 0x010EE730: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE734: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x010EE738: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE73C: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE740: B.HS #0x10ee7d8            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth >= ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_44;
            // 0x010EE744: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_38 = 0;
            // 0x010EE748: B #0x10ee7ec               |  goto label_45;                         
            goto label_45;
            label_29:
            // 0x010EE74C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_29 = val_25;
            // 0x010EE750: ADD w9, w9, #3             | W9 = ((mem[282584257676823] + 8) + 3);  
            val_29 = val_29 + 3;
            // 0x010EE754: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 3));
            val_30 = val_30 + val_29;
            // 0x010EE758: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272);
            val_32 = val_30 + 272;
            label_31:
            // 0x010EE75C: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272) + 8; //  | 
            // 0x010EE760: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            // 0x010EE764: MOV w1, w24                | W1 = val_2 + 4 + 8 + 4;//m1             
            // 0x010EE768: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 3)) + 272)();
            // 0x010EE76C: CBZ x0, #0x10ee790         | if (0x0 == 0) goto label_46;            
            if(val_30 == 0)
            {
                goto label_46;
            }
            // 0x010EE770: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x010EE774: LDR x9, [x0]               | X9 = 0x10102464C457F;                   
            // 0x010EE778: LDR x8, [x8, #0xcc0]       | X8 = 1152921504608976896;               
            // 0x010EE77C: LDRB w11, [x9, #0x104]     | W11 = (bool)mem[282584257676931];       
            // 0x010EE780: LDR x8, [x8]               | X8 = typeof(System.Array);              
            // 0x010EE784: LDRB w10, [x8, #0x104]     | W10 = System.Array.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE788: CMP w11, w10               | STATE = COMPARE(mem[282584257676931], System.Array.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE78C: B.HS #0x10ee798            | if (mem[282584257676931] >= System.Array.__il2cppRuntimeField_typeHierarchyDepth) goto label_47;
            label_46:
            // 0x010EE790: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_39 = 0;
            // 0x010EE794: B #0x10ee7ac               |  goto label_48;                         
            goto label_48;
            label_47:
            // 0x010EE798: LDR x9, [x9, #0xb0]        | X9 = mem[282584257676847];              
            // 0x010EE79C: ADD x9, x9, x10, lsl #3    | X9 = (mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x010EE7A0: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE7A4: CMP x9, x8                 | STATE = COMPARE((mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Array))
            // 0x010EE7A8: CSEL x24, x0, xzr, eq      | X24 = (mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_30 : 0;
            var val_13 = (((mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_30) : 0;
            label_48:
            // 0x010EE7AC: CBNZ x27, #0x10ee7b4       | if (val_2 + 4 + 8 != 0) goto label_49;  
            if(val_27 != 0)
            {
                goto label_49;
            }
            // 0x010EE7B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_49:
            // 0x010EE7B4: LDR w27, [x27, #8]         | W27 = val_2 + 4 + 8 + 8;                
            val_27 = mem[val_2 + 4 + 8 + 8];
            val_27 = val_2 + 4 + 8 + 8;
            // 0x010EE7B8: CBNZ x24, #0x10ee7c0       | if ((mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_30 : 0 != 0) goto label_50;
            // 0x010EE7BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_50:
            // 0x010EE7C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EE7C4: MOV x0, x24                | X0 = (mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_30 : 0;//m1
            // 0x010EE7C8: MOV x1, x26                | X1 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE7CC: MOV w2, w27                | W2 = val_2 + 4 + 8 + 8;//m1             
            // 0x010EE7D0: BL #0x18ccbcc              | (mem[282584257676847] + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_30 : 0.SetValue(value:  val_28, index:  val_27);
            val_13.SetValue(value:  val_28, index:  val_27);
            // 0x010EE7D4: B #0x10eea68               |  goto label_51;                         
            goto label_51;
            label_44:
            // 0x010EE7D8: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x010EE7DC: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x010EE7E0: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE7E4: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x010EE7E8: CSEL x24, x0, xzr, eq      | X24 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_12 : 0;
            var val_14 = (((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_12) : 0;
            label_45:
            // 0x010EE7EC: CBNZ x27, #0x10ee7f4       | if (val_2 + 4 + 8 != 0) goto label_52;  
            if(val_27 != 0)
            {
                goto label_52;
            }
            // 0x010EE7F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_52:
            // 0x010EE7F4: LDR w23, [x27, #8]         | W23 = val_2 + 4 + 8 + 8;                
            // 0x010EE7F8: CBNZ x24, #0x10ee800       | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_12 : 0 != 0) goto label_53;
            // 0x010EE7FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_53:
            // 0x010EE800: MOV x0, x24                | X0 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_12 : 0;//m1
            // 0x010EE804: MOV w1, w23                | W1 = val_2 + 4 + 8 + 8;//m1             
            // 0x010EE808: BL #0x10eeaec              | X0 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_12 : 0.GetField(hash:  val_2 + 4 + 8 + 8);
            System.Reflection.FieldInfo val_15 = val_14.GetField(hash:  val_2 + 4 + 8 + 8);
            // 0x010EE80C: MOV x23, x0                | X23 = val_15;//m1                       
            val_29 = val_15;
            // 0x010EE810: CBNZ x23, #0x10ee818       | if (val_15 != null) goto label_54;      
            if(val_29 != null)
            {
                goto label_54;
            }
            // 0x010EE814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_54:
            // 0x010EE818: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EE81C: MOV x0, x23                | X0 = val_15;//m1                        
            // 0x010EE820: MOV x1, x28                | X1 = 0 (0x0);//ML01                     
            // 0x010EE824: MOV x2, x26                | X2 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE828: BL #0x13bd088              | val_15.SetValue(obj:  val_36, value:  val_28);
            val_29.SetValue(obj:  val_36, value:  val_28);
            // 0x010EE82C: LDR x28, [sp, #0x18]       | X28 = X4;                               
            // 0x010EE830: LDR x24, [sp, #8]          | X24 = (long)(int)(paramCount);          
            // 0x010EE834: B #0x10eea6c               |  goto label_68;                         
            goto label_68;
            label_14:
            // 0x010EE838: MOV x0, x28                | X0 = val_4;//m1                         
            // 0x010EE83C: BL #0x10eeca4              | X0 = val_4.get_StaticInstance();        
            ILRuntime.Runtime.Intepreter.ILTypeStaticInstance val_16 = val_30.StaticInstance;
            // 0x010EE840: MOV x24, x0                | X24 = val_16;//m1                       
            // 0x010EE844: CBNZ x27, #0x10ee84c       | if (val_2 + 4 != 0) goto label_56;      
            if(val_27 != 0)
            {
                goto label_56;
            }
            // 0x010EE848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_56:
            // 0x010EE84C: LDR w23, [x27, #8]         | W23 = val_2 + 4 + 8;                    
            val_29 = mem[val_2 + 4 + 8];
            val_29 = val_2 + 4 + 8;
            // 0x010EE850: LDR x28, [sp, #0x18]       | X28 = X4;                               
            // 0x010EE854: CBNZ x24, #0x10ee85c       | if (val_16 != null) goto label_57;      
            if(val_16 != null)
            {
                goto label_57;
            }
            // 0x010EE858: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_57:
            // 0x010EE85C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EE860: MOV x0, x24                | X0 = val_16;//m1                        
            // 0x010EE864: MOV w1, w23                | W1 = val_2 + 4 + 8;//m1                 
            // 0x010EE868: MOV x2, x26                | X2 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE86C: BL #0x1f96638              | val_16.set_Item(index:  val_29, value:  val_28);
            val_16.set_Item(index:  val_29, value:  val_28);
            // 0x010EE870: MOV x24, x19               | X24 = (long)(int)(paramCount);//m1      
            // 0x010EE874: MOV x19, x22               | X19 = X5;//m1                           
            val_24 = val_24;
            // 0x010EE878: LDR x22, [sp, #0x10]       | X22 = X2;                               
            // 0x010EE87C: B #0x10eea6c               |  goto label_68;                         
            goto label_68;
            label_33:
            // 0x010EE880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32, ????);
            // 0x010EE884: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x010EE888: LDR x8, [x8, #0xa58]       | X8 = 1152921504824418304;               
            // 0x010EE88C: LDR x28, [x8]              | X28 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_34 = null;
            label_36:
            // 0x010EE890: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_35 = 0;
            label_35:
            // 0x010EE894: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x010EE898: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x010EE89C: CBZ x9, #0x10ee8c8         | if (mem[282584257676929] == 0) goto label_59;
            if(mem[282584257676929] == 0)
            {
                goto label_59;
            }
            // 0x010EE8A0: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_31 = mem[282584257676823];
            // 0x010EE8A4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_32 = 0;
            // 0x010EE8A8: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_31 = val_31 + 8;
            label_61:
            // 0x010EE8AC: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x010EE8B0: CMP x12, x28               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x010EE8B4: B.EQ #0x10ee9c0            | if ((mem[282584257676823] + 8) + -8 == val_34) goto label_60;
            if(((mem[282584257676823] + 8) + -8) == val_34)
            {
                goto label_60;
            }
            // 0x010EE8B8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_32 = val_32 + 1;
            // 0x010EE8BC: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_31 = val_31 + 16;
            // 0x010EE8C0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x010EE8C4: B.LO #0x10ee8ac            | if (0 < mem[282584257676929]) goto label_61;
            if(val_32 < mem[282584257676929])
            {
                goto label_61;
            }
            label_59:
            // 0x010EE8C8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x010EE8CC: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_40 = val_35;
            // 0x010EE8D0: MOV x1, x28                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_33 = val_34;
            // 0x010EE8D4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x010EE8D8: B #0x10ee9cc               |  goto label_62;                         
            goto label_62;
            label_40:
            // 0x010EE8DC: CBNZ x27, #0x10ee8fc       | if (val_2 + 4 + 8 != 0) goto label_63;  
            if(val_27 != 0)
            {
                goto label_63;
            }
            // 0x010EE8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x010EE8E4: ADRP x9, #0x35dd000        | X9 = 56479744 (0x35DD000);              
            // 0x010EE8E8: LDR x8, [x28]              | X8 = 0x10102464C457F;                   
            // 0x010EE8EC: LDR x9, [x9, #0xb50]       | X9 = 1152921504825909248;               
            // 0x010EE8F0: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x010EE8F4: LDR x1, [x9]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x010EE8F8: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            label_63:
            // 0x010EE8FC: LDR x24, [sp, #8]          | X24 = (long)(int)(paramCount);          
            // 0x010EE900: LDR w27, [x27, #8]         | W27 = val_2 + 4 + 8 + 8;                
            val_27 = mem[val_2 + 4 + 8 + 8];
            val_27 = val_2 + 4 + 8 + 8;
            // 0x010EE904: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE908: B.LO #0x10ee920            | if (mem[282584257676931] < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_64;
            // 0x010EE90C: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x010EE910: ADD x9, x10, w9, uxtw #3   | X9 = (mem[282584257676847] + ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHi
            // 0x010EE914: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) + -8;
            // 0x010EE918: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x010EE91C: B.EQ #0x10ee948            | if ((mem[282584257676847] + ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) + -8 == null) goto label_65;
            label_64:
            // 0x010EE920: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x010EE924: ADD x8, sp, #0x40          | X8 = (1152921509984612320 + 64) = 1152921509984612384 (0x10000001408A3020);
            // 0x010EE928: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x010EE92C: LDR x0, [sp, #0x40]        | X0 = val_17;                             //  find_add[1152921509984600512]
            // 0x010EE930: BL #0x27af090              | X0 = sub_27AF090( ?? val_17, ????);     
            // 0x010EE934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE938: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            // 0x010EE93C: ADD x0, sp, #0x40          | X0 = (1152921509984612320 + 64) = 1152921509984612384 (0x10000001408A3020);
            // 0x010EE940: BL #0x299a140              | 
            // 0x010EE944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001408A3020, ????);
            label_65:
            // 0x010EE948: ADRP x9, #0x35dd000        | X9 = 56479744 (0x35DD000);              
            // 0x010EE94C: LDR x8, [x28]              | X8 = 0x10102464C457F;                   
            // 0x010EE950: LDR x9, [x9, #0xb50]       | X9 = 1152921504825909248;               
            // 0x010EE954: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x010EE958: LDR x1, [x9]               | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x010EE95C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x010EE960: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x010EE964: B.LO #0x10ee97c            | if (mem[282584257676931] < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_66;
            // 0x010EE968: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x010EE96C: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeH
            // 0x010EE970: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x010EE974: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x010EE978: B.EQ #0x10ee9a4            | if ((mem[282584257676847] + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_67;
            label_66:
            // 0x010EE97C: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x010EE980: ADD x8, sp, #0x48          | X8 = (1152921509984612320 + 72) = 1152921509984612392 (0x10000001408A3028);
            // 0x010EE984: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x010EE988: LDR x0, [sp, #0x48]        | X0 = val_19;                             //  find_add[1152921509984600512]
            // 0x010EE98C: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x010EE990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EE994: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x010EE998: ADD x0, sp, #0x48          | X0 = (1152921509984612320 + 72) = 1152921509984612392 (0x10000001408A3028);
            // 0x010EE99C: BL #0x299a140              | 
            // 0x010EE9A0: MOV x28, xzr               | X28 = 0 (0x0);//ML01                    
            val_36 = 0;
            label_67:
            // 0x010EE9A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EE9A8: MOV x0, x28                | X0 = 0 (0x0);//ML01                     
            // 0x010EE9AC: MOV w1, w27                | W1 = val_2 + 4 + 8 + 8;//m1             
            // 0x010EE9B0: MOV x2, x26                | X2 = (X3 + ((long)(int)((paramCount - (long)(int)(((W6 & 1) + paramCount))))) << 3) + 32;//m1
            // 0x010EE9B4: BL #0x1f96638              | val_36.set_Item(index:  val_27, value:  val_28);
            val_36.set_Item(index:  val_27, value:  val_28);
            // 0x010EE9B8: LDR x28, [sp, #0x18]       | X28 = X4;                               
            // 0x010EE9BC: B #0x10eea6c               |  goto label_68;                         
            goto label_68;
            label_60:
            // 0x010EE9C0: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x010EE9C4: ADD x8, x8, x9, lsl #4     | X8 = (val_35 + ((mem[282584257676823] + 8)) << 4);
            val_35 = val_35 + (((mem[282584257676823] + 8)) << 4);
            // 0x010EE9C8: ADD x0, x8, #0x110         | X0 = ((val_35 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_40 = val_35 + 272;
            label_62:
            // 0x010EE9CC: LDP x8, x1, [x0]           | X8 = ((val_35 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_35 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x010EE9D0: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x010EE9D4: BLR x8                     | X0 = ((val_35 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x010EE9D8: LDR x28, [sp, #0x18]       | X28 = X4;                               
            val_25 = val_25;
            // 0x010EE9DC: MOV x26, x0                | X26 = 0 (0x0);//ML01                    
            val_28 = val_35;
            label_32:
            // 0x010EE9E0: CBNZ x27, #0x10ee9e8       | if (val_2 + 4 != 0) goto label_69;      
            if(val_27 != 0)
            {
                goto label_69;
            }
            // 0x010EE9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_69:
            // 0x010EE9E8: LDR w24, [x27, #4]         | W24 = val_2 + 4 + 4;                    
            // 0x010EE9EC: CBNZ x28, #0x10ee9f4       | if (X4 != 0) goto label_70;             
            if(val_25 != 0)
            {
                goto label_70;
            }
            // 0x010EE9F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_70:
            // 0x010EE9F4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x010EE9F8: LDR x8, [x28]              | X8 = X4;                                
            var val_36 = val_25;
            // 0x010EE9FC: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x010EEA00: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x010EEA04: LDRH w9, [x8, #0x102]      | W9 = X4 + 258;                          
            // 0x010EEA08: CBZ x9, #0x10eea34         | if (X4 + 258 == 0) goto label_71;       
            if((X4 + 258) == 0)
            {
                goto label_71;
            }
            // 0x010EEA0C: LDR x10, [x8, #0x98]       | X10 = X4 + 152;                         
            var val_33 = X4 + 152;
            // 0x010EEA10: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_34 = 0;
            // 0x010EEA14: ADD x10, x10, #8           | X10 = (X4 + 152 + 8);                   
            val_33 = val_33 + 8;
            label_73:
            // 0x010EEA18: LDUR x12, [x10, #-8]       | X12 = (X4 + 152 + 8) + -8;              
            // 0x010EEA1C: CMP x12, x1                | STATE = COMPARE((X4 + 152 + 8) + -8, typeof(System.Collections.Generic.IList<T>))
            // 0x010EEA20: B.EQ #0x10eea44            | if ((X4 + 152 + 8) + -8 == null) goto label_72;
            if(((X4 + 152 + 8) + -8) == null)
            {
                goto label_72;
            }
            // 0x010EEA24: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_34 = val_34 + 1;
            // 0x010EEA28: ADD x10, x10, #0x10        | X10 = ((X4 + 152 + 8) + 16);            
            val_33 = val_33 + 16;
            // 0x010EEA2C: CMP x11, x9                | STATE = COMPARE((0 + 1), X4 + 258)      
            // 0x010EEA30: B.LO #0x10eea18            | if (0 < X4 + 258) goto label_73;        
            if(val_34 < (X4 + 258))
            {
                goto label_73;
            }
            label_71:
            // 0x010EEA34: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x010EEA38: MOV x0, x28                | X0 = X4;//m1                            
            val_41 = val_25;
            // 0x010EEA3C: BL #0x2776c24              | X0 = sub_2776C24( ?? X4, ????);         
            // 0x010EEA40: B #0x10eea54               |  goto label_74;                         
            goto label_74;
            label_72:
            // 0x010EEA44: LDR w9, [x10]              | W9 = (X4 + 152 + 8);                    
            var val_35 = val_33;
            // 0x010EEA48: ADD w9, w9, #4             | W9 = ((X4 + 152 + 8) + 4);              
            val_35 = val_35 + 4;
            // 0x010EEA4C: ADD x8, x8, w9, uxtw #4    | X8 = (X4 + ((X4 + 152 + 8) + 4));       
            val_36 = val_36 + val_35;
            // 0x010EEA50: ADD x0, x8, #0x110         | X0 = ((X4 + ((X4 + 152 + 8) + 4)) + 272);
            val_41 = val_36 + 272;
            label_74:
            // 0x010EEA54: LDP x8, x3, [x0]           | X8 = ((X4 + ((X4 + 152 + 8) + 4)) + 272); X3 = ((X4 + ((X4 + 152 + 8) + 4)) + 272) + 8; //  | 
            // 0x010EEA58: MOV x0, x28                | X0 = X4;//m1                            
            // 0x010EEA5C: MOV w1, w24                | W1 = val_2 + 4 + 4;//m1                 
            // 0x010EEA60: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x010EEA64: BLR x8                     | X0 = ((X4 + ((X4 + 152 + 8) + 4)) + 272)();
            label_51:
            // 0x010EEA68: MOV x24, x23               | X24 = (long)(int)(paramCount);//m1      
            label_68:
            // 0x010EEA6C: SUBS x25, x25, #1          | X25 = ((long)(int)(((W6 & 1) + paramCount)) - 1);
            val_26 = val_26 - 1;
            // 0x010EEA70: B.GT #0x10ee2e4            | if ((X4 + 152 + 8) + -8 > null) goto label_75;
            if(((X4 + 152 + 8) + -8) > null)
            {
                goto label_75;
            }
            label_7:
            // 0x010EEA74: SUB sp, x29, #0x50         | SP = (1152921509984612496 - 80) = 1152921509984612416 (0x10000001408A3040);
            // 0x010EEA78: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x010EEA7C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x010EEA80: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x010EEA84: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x010EEA88: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x010EEA8C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x010EEA90: RET                        |  return;                                
            return;
            // 0x010EEA94: MOV x19, x0                | 
            // 0x010EEA98: ADD x0, sp, #0x50          | 
            // 0x010EEA9C: B #0x10eead8               | 
            // 0x010EEAA0: MOV x19, x0                | 
            // 0x010EEAA4: ADD x0, sp, #0x58          | 
            // 0x010EEAA8: B #0x10eead8               | 
            // 0x010EEAAC: MOV x19, x0                | 
            // 0x010EEAB0: ADD x0, sp, #0x40          | 
            // 0x010EEAB4: B #0x10eead8               | 
            // 0x010EEAB8: MOV x19, x0                | 
            // 0x010EEABC: ADD x0, sp, #0x48          | 
            // 0x010EEAC0: B #0x10eead8               | 
            // 0x010EEAC4: MOV x19, x0                | 
            // 0x010EEAC8: ADD x0, sp, #0x30          | 
            // 0x010EEACC: B #0x10eead8               | 
            // 0x010EEAD0: MOV x19, x0                | 
            // 0x010EEAD4: ADD x0, sp, #0x38          | 
            label_80:
            // 0x010EEAD8: BL #0x299a140              | 
            // 0x010EEADC: MOV x0, x19                | 
            // 0x010EEAE0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x010EED74 (17755508), len: 504  VirtAddr: 0x010EED74 RVA: 0x010EED74 token: 100663340 methodIndex: 28785 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod MakeGenericMethod(ILRuntime.CLR.TypeSystem.IType[] genericArguments)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x010EED74: STP x26, x25, [sp, #-0x50]! | stack[1152921509984843216] = ???;  stack[1152921509984843224] = ???;  //  dest_result_addr=1152921509984843216 |  dest_result_addr=1152921509984843224
            // 0x010EED78: STP x24, x23, [sp, #0x10]  | stack[1152921509984843232] = ???;  stack[1152921509984843240] = ???;  //  dest_result_addr=1152921509984843232 |  dest_result_addr=1152921509984843240
            // 0x010EED7C: STP x22, x21, [sp, #0x20]  | stack[1152921509984843248] = ???;  stack[1152921509984843256] = ???;  //  dest_result_addr=1152921509984843248 |  dest_result_addr=1152921509984843256
            // 0x010EED80: STP x20, x19, [sp, #0x30]  | stack[1152921509984843264] = ???;  stack[1152921509984843272] = ???;  //  dest_result_addr=1152921509984843264 |  dest_result_addr=1152921509984843272
            // 0x010EED84: STP x29, x30, [sp, #0x40]  | stack[1152921509984843280] = ???;  stack[1152921509984843288] = ???;  //  dest_result_addr=1152921509984843280 |  dest_result_addr=1152921509984843288
            // 0x010EED88: ADD x29, sp, #0x40         | X29 = (1152921509984843216 + 64) = 1152921509984843280 (0x10000001408DB610);
            // 0x010EED8C: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x010EED90: LDRB w8, [x21, #0xae3]     | W8 = (bool)static_value_03735AE3;       
            // 0x010EED94: MOV x19, x1                | X19 = genericArguments;//m1             
            // 0x010EED98: MOV x20, x0                | X20 = 1152921509984855296 (0x10000001408DE500);//ML01
            // 0x010EED9C: TBNZ w8, #0, #0x10eedb8    | if (static_value_03735AE3 == true) goto label_0;
            // 0x010EEDA0: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x010EEDA4: LDR x8, [x8, #0x730]       | X8 = 0x2B90CA8;                         
            // 0x010EEDA8: LDR w0, [x8]               | W0 = 0x19EE;                            
            // 0x010EEDAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x19EE, ????);     
            // 0x010EEDB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EEDB4: STRB w8, [x21, #0xae3]     | static_value_03735AE3 = true;            //  dest_result_addr=57891555
            label_0:
            // 0x010EEDB8: CBNZ x19, #0x10eedc0       | if (genericArguments != null) goto label_1;
            if(genericArguments != null)
            {
                goto label_1;
            }
            // 0x010EEDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19EE, ????);     
            label_1:
            // 0x010EEDC0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x010EEDC4: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x010EEDC8: LDR w22, [x19, #0x18]      | W22 = genericArguments.Length; //P2     
            // 0x010EEDCC: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x010EEDD0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010EEDD4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x010EEDD8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010EEDDC: MOV x1, x22                | X1 = genericArguments.Length;//m1       
            // 0x010EEDE0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x010EEDE4: ADRP x24, #0x3679000       | X24 = 57118720 (0x3679000);             
            // 0x010EEDE8: LDR x24, [x24, #0xdf8]     | X24 = 1152921504782245888;              
            // 0x010EEDEC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010EEDF0: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_4 = 0;
            // 0x010EEDF4: B #0x10eee04               |  goto label_2;                          
            goto label_2;
            label_15:
            // 0x010EEDF8: ADD x8, x21, x25, lsl #3   | X8 = (null + (X25) << 3);               
            var val_1 = null + ((X25) << 3);
            // 0x010EEDFC: ADD w23, w23, #1           | W23 = (val_4 + 1) = val_4 (0x00000001); 
            val_4 = 1;
            // 0x010EEE00: STR x22, [x8, #0x20]       | mem2[0] = genericArguments.Length;       //  dest_result_addr=0
            mem2[0] = genericArguments.Length;
            label_2:
            // 0x010EEE04: CBNZ x19, #0x10eee0c       | if (genericArguments != null) goto label_3;
            if(genericArguments != null)
            {
                goto label_3;
            }
            // 0x010EEE08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x010EEE0C: LDR w8, [x19, #0x18]       | W8 = genericArguments.Length; //P2      
            // 0x010EEE10: CMP w23, w8                | STATE = COMPARE(0x1, genericArguments.Length)
            // 0x010EEE14: B.GE #0x10eeef0            | if (val_4 >= genericArguments.Length) goto label_4;
            if(val_4 >= genericArguments.Length)
            {
                goto label_4;
            }
            // 0x010EEE18: SXTW x25, w23              | X25 = 1 (0x00000001);                   
            // 0x010EEE1C: CMP w23, w8                | STATE = COMPARE(0x1, genericArguments.Length)
            // 0x010EEE20: B.LO #0x10eee30            | if (val_4 < genericArguments.Length) goto label_5;
            if(val_4 < genericArguments.Length)
            {
                goto label_5;
            }
            // 0x010EEE24: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Type[]), ????);
            // 0x010EEE28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EEE2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Type[]), ????);
            label_5:
            // 0x010EEE30: ADD x8, x19, x25, lsl #3   | X8 = genericArguments[0x1]; //PARR1     
            // 0x010EEE34: LDR x22, [x8, #0x20]       | X22 = genericArguments[0x1][0]          
            ILRuntime.CLR.TypeSystem.IType val_4 = genericArguments[1];
            // 0x010EEE38: CBNZ x22, #0x10eee40       | if (genericArguments[0x1][0] != null) goto label_6;
            if(val_4 != null)
            {
                goto label_6;
            }
            // 0x010EEE3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x010EEE40: LDR x8, [x22]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EEE44: LDR x1, [x24]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x010EEE48: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x010EEE4C: CBZ x9, #0x10eee78         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_7;
            // 0x010EEE50: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x010EEE54: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x010EEE58: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_9:
            // 0x010EEE5C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x010EEE60: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x010EEE64: B.EQ #0x10eee88            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_8;
            // 0x010EEE68: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x010EEE6C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x010EEE70: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x010EEE74: B.LO #0x10eee5c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_9;
            label_7:
            // 0x010EEE78: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x010EEE7C: MOV x0, x22                | X0 = genericArguments[0x1][0];//m1      
            val_5 = val_4;
            // 0x010EEE80: BL #0x2776c24              | X0 = sub_2776C24( ?? genericArguments[0x1][0], ????);
            // 0x010EEE84: B #0x10eee98               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x010EEE88: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x010EEE8C: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x010EEE90: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x010EEE94: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_10:
            // 0x010EEE98: LDP x8, x1, [x0]           | X8 = ; X1 = System.Type[].__il2cppRuntimeField_gc_desc; //  | 
            // 0x010EEE9C: MOV x0, x22                | X0 = genericArguments[0x1][0];//m1      
            // 0x010EEEA0: BLR x8                     | X0 = x8();                              
            // 0x010EEEA4: MOV x22, x0                | X22 = genericArguments[0x1][0];//m1     
            // 0x010EEEA8: CBNZ x21, #0x10eeeb0       | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x010EEEAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? genericArguments[0x1][0], ????);
            label_11:
            // 0x010EEEB0: CBZ x22, #0x10eeed4        | if (genericArguments[0x1][0] == null) goto label_13;
            if(val_4 == null)
            {
                goto label_13;
            }
            // 0x010EEEB4: LDR x8, [x21]              | X8 = ;                                  
            // 0x010EEEB8: MOV x0, x22                | X0 = genericArguments[0x1][0];//m1      
            // 0x010EEEBC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x010EEEC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? genericArguments[0x1][0], ????);
            // 0x010EEEC4: CBNZ x0, #0x10eeed4        | if (genericArguments[0x1][0] != null) goto label_13;
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x010EEEC8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? genericArguments[0x1][0], ????);
            // 0x010EEECC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EEED0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? genericArguments[0x1][0], ????);
            label_13:
            // 0x010EEED4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x010EEED8: CMP w23, w8                | STATE = COMPARE(0x1, System.Type[].__il2cppRuntimeField_namespaze)
            // 0x010EEEDC: B.LO #0x10eedf8            | if (val_4 < System.Type[].__il2cppRuntimeField_namespaze) goto label_15;
            // 0x010EEEE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? genericArguments[0x1][0], ????);
            // 0x010EEEE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x010EEEE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? genericArguments[0x1][0], ????);
            // 0x010EEEEC: B #0x10eedf8               |  goto label_15;                         
            goto label_15;
            label_4:
            // 0x010EEEF0: LDR x22, [x20, #0x10]      | X22 = this.def; //P2                    
            // 0x010EEEF4: CBNZ x22, #0x10eeefc       | if (this.def != null) goto label_16;    
            if(this.def != null)
            {
                goto label_16;
            }
            // 0x010EEEF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_16:
            // 0x010EEEFC: LDR x8, [x22]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EEF00: MOV x0, x22                | X0 = this.def;//m1                      
            // 0x010EEF04: MOV x1, x21                | X1 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x010EEF08: LDR x9, [x8, #0x3b0]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_3B0;
            // 0x010EEF0C: LDR x2, [x8, #0x3b8]       | X2 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_3B8;
            // 0x010EEF10: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_3B0();
            // 0x010EEF14: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x010EEF18: LDP x21, x22, [x20, #0x30] | X21 = this.appdomain; //P2  X22 = this.declaringType; //P2  //  | 
            // 0x010EEF1C: LDR x8, [x8, #0xe08]       | X8 = 1152921504781766656;               
            // 0x010EEF20: MOV x23, x0                | X23 = this.def;//m1                     
            // 0x010EEF24: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Method.CLRMethod);
            // 0x010EEF28: MOV x0, x8                 | X0 = 1152921504781766656 (0x100000000A6D1000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_3 = null;
            // 0x010EEF2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.CLR.Method.CLRMethod), ????);
            // 0x010EEF30: MOV x1, x23                | X1 = this.def;//m1                      
            // 0x010EEF34: MOV x2, x22                | X2 = this.declaringType;//m1            
            // 0x010EEF38: MOV x3, x21                | X3 = this.appdomain;//m1                
            // 0x010EEF3C: MOV x20, x0                | X20 = 1152921504781766656 (0x100000000A6D1000);//ML01
            // 0x010EEF40: BL #0x10ec5ac              | .ctor(def:  this.def, type:  this.declaringType, domain:  this.appdomain);
            val_3 = new ILRuntime.CLR.Method.CLRMethod(def:  this.def, type:  this.declaringType, domain:  this.appdomain);
            // 0x010EEF44: CBNZ x20, #0x10eef4c       | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x010EEF48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(def:  this.def, type:  this.declaringType, domain:  this.appdomain), ????);
            label_17:
            // 0x010EEF4C: STR x19, [x20, #0x58]      | typeof(ILRuntime.CLR.Method.CLRMethod).__il2cppRuntimeField_58 = genericArguments;  //  dest_result_addr=1152921504781766744
            typeof(ILRuntime.CLR.Method.CLRMethod).__il2cppRuntimeField_58 = genericArguments;
            // 0x010EEF50: MOV x0, x20                | X0 = 1152921504781766656 (0x100000000A6D1000);//ML01
            // 0x010EEF54: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x010EEF58: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x010EEF5C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x010EEF60: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x010EEF64: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x010EEF68: RET                        |  return (ILRuntime.CLR.Method.IMethod)typeof(ILRuntime.CLR.Method.CLRMethod);
            return (ILRuntime.CLR.Method.IMethod)val_3;
            //  |  // // {name=val_0, type=ILRuntime.CLR.Method.IMethod, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010EEF6C (17756012), len: 72  VirtAddr: 0x010EEF6C RVA: 0x010EEF6C token: 100663341 methodIndex: 28786 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            // 0x010EEF6C: MOV x8, x0                 | X8 = 1152921509985028736 (0x1000000140908A80);//ML01
            // 0x010EEF70: LDR x0, [x8, #0x10]        | X0 = this.def; //P2                     
            // 0x010EEF74: CBZ x0, #0x10eef84         | if (this.def == null) goto label_0;     
            if(this.def == null)
            {
                goto label_0;
            }
            // 0x010EEF78: LDR x8, [x0]               | X8 = typeof(System.Reflection.MethodInfo);
            // 0x010EEF7C: LDP x2, x1, [x8, #0x140]   | X2 = public System.String System.Object::ToString(); X1 = public System.String System.Object::ToString(); //  | 
            // 0x010EEF80: BR x2                      | return this.def.ToString();             
            return this.def.ToString();
            label_0:
            // 0x010EEF84: STP x20, x19, [sp, #-0x20]! | stack[1152921509985016704] = ???;  stack[1152921509985016712] = ???;  //  dest_result_addr=1152921509985016704 |  dest_result_addr=1152921509985016712
            // 0x010EEF88: STP x29, x30, [sp, #0x10]  | stack[1152921509985016720] = ???;  stack[1152921509985016728] = ???;  //  dest_result_addr=1152921509985016720 |  dest_result_addr=1152921509985016728
            // 0x010EEF8C: ADD x29, sp, #0x10         | X29 = (1152921509985016704 + 16) = 1152921509985016720 (0x1000000140905B90);
            // 0x010EEF90: LDR x19, [x8, #0x18]       | X19 = this.cDef; //P2                   
            // 0x010EEF94: CBNZ x19, #0x10eef9c       | if (this.cDef != null) goto label_1;    
            if(this.cDef != null)
            {
                goto label_1;
            }
            // 0x010EEF98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.def, ????);   
            label_1:
            // 0x010EEF9C: LDR x8, [x19]              | X8 = typeof(System.Reflection.ConstructorInfo);
            // 0x010EEFA0: MOV x0, x19                | X0 = this.cDef;//m1                     
            // 0x010EEFA4: LDP x2, x1, [x8, #0x140]   | X2 = public System.String System.Object::ToString(); X1 = public System.String System.Object::ToString(); //  | 
            // 0x010EEFA8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010EEFAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010EEFB0: BR x2                      | return this.cDef.ToString();            
            return this.cDef.ToString();
        
        }
        //
        // Offset in libil2cpp.so: 0x010EEFB4 (17756084), len: 136  VirtAddr: 0x010EEFB4 RVA: 0x010EEFB4 token: 100663342 methodIndex: 28787 delegateWrapperIndex: 0 methodInvoker: 0
        public override int GetHashCode()
        {
            //
            // Disasemble & Code
            //  | 
            int val_3;
            //  | 
            var val_4;
            // 0x010EEFB4: STP x20, x19, [sp, #-0x20]! | stack[1152921509985136896] = ???;  stack[1152921509985136904] = ???;  //  dest_result_addr=1152921509985136896 |  dest_result_addr=1152921509985136904
            // 0x010EEFB8: STP x29, x30, [sp, #0x10]  | stack[1152921509985136912] = ???;  stack[1152921509985136920] = ???;  //  dest_result_addr=1152921509985136912 |  dest_result_addr=1152921509985136920
            // 0x010EEFBC: ADD x29, sp, #0x10         | X29 = (1152921509985136896 + 16) = 1152921509985136912 (0x1000000140923110);
            // 0x010EEFC0: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x010EEFC4: LDRB w8, [x20, #0xae4]     | W8 = (bool)static_value_03735AE4;       
            // 0x010EEFC8: MOV x19, x0                | X19 = 1152921509985148928 (0x1000000140926000);//ML01
            // 0x010EEFCC: TBNZ w8, #0, #0x10eefe8    | if (static_value_03735AE4 == true) goto label_0;
            // 0x010EEFD0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x010EEFD4: LDR x8, [x8, #0x9b0]       | X8 = 0x2B90C9C;                         
            // 0x010EEFD8: LDR w0, [x8]               | W0 = 0x19EB;                            
            // 0x010EEFDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x19EB, ????);     
            // 0x010EEFE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EEFE4: STRB w8, [x20, #0xae4]     | static_value_03735AE4 = true;            //  dest_result_addr=57891556
            label_0:
            // 0x010EEFE8: LDR w0, [x19, #0x74]       | W0 = this.hashCode; //P2                
            val_3 = this.hashCode;
            // 0x010EEFEC: CMN w0, #1                 | STATE = COMPARE(this.hashCode, 0x1)     
            // 0x010EEFF0: B.NE #0x10ef030            | if (val_3 != 1) goto label_1;           
            if(val_3 != 1)
            {
                goto label_1;
            }
            // 0x010EEFF4: ADRP x20, #0x3619000       | X20 = 56725504 (0x3619000);             
            // 0x010EEFF8: LDR x20, [x20, #0xe08]     | X20 = 1152921504781766656;              
            // 0x010EEFFC: LDR x0, [x20]              | X0 = typeof(ILRuntime.CLR.Method.CLRMethod);
            val_4 = null;
            // 0x010EF000: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_10A;
            // 0x010EF004: TBZ w8, #0, #0x10ef018     | if (ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x010EF008: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_cctor_finished;
            // 0x010EF00C: CBNZ w8, #0x10ef018        | if (ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x010EF010: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Method.CLRMethod), ????);
            // 0x010EF014: LDR x0, [x20]              | X0 = typeof(ILRuntime.CLR.Method.CLRMethod);
            val_4 = null;
            label_3:
            // 0x010EF018: LDR x1, [x0, #0xa0]        | X1 = ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_static_fields;
            // 0x010EF01C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x010EF020: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x010EF024: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x010EF028: BL #0x1b65adc              | X0 = System.Threading.Interlocked.Add(location1: ref  val_3 = 0, value:  174923776);
            int val_1 = System.Threading.Interlocked.Add(location1: ref  val_3, value:  174923776);
            // 0x010EF02C: STR w0, [x19, #0x74]       | this.hashCode = val_1;                   //  dest_result_addr=1152921509985149044
            this.hashCode = val_1;
            label_1:
            // 0x010EF030: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010EF034: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010EF038: RET                        |  return (System.Int32)val_1;            
            return val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x010EF03C (17756220), len: 84  VirtAddr: 0x010EF03C RVA: 0x010EF03C token: 100663343 methodIndex: 28788 delegateWrapperIndex: 0 methodInvoker: 0
        private static CLRMethod()
        {
            //
            // Disasemble & Code
            // 0x010EF03C: STP x20, x19, [sp, #-0x20]! | stack[1152921509985248896] = ???;  stack[1152921509985248904] = ???;  //  dest_result_addr=1152921509985248896 |  dest_result_addr=1152921509985248904
            // 0x010EF040: STP x29, x30, [sp, #0x10]  | stack[1152921509985248912] = ???;  stack[1152921509985248920] = ???;  //  dest_result_addr=1152921509985248912 |  dest_result_addr=1152921509985248920
            // 0x010EF044: ADD x29, sp, #0x10         | X29 = (1152921509985248896 + 16) = 1152921509985248912 (0x100000014093E690);
            // 0x010EF048: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x010EF04C: LDRB w8, [x19, #0xae5]     | W8 = (bool)static_value_03735AE5;       
            // 0x010EF050: TBNZ w8, #0, #0x10ef06c    | if (static_value_03735AE5 == true) goto label_0;
            // 0x010EF054: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x010EF058: LDR x8, [x8, #0x648]       | X8 = 0x2B90C8C;                         
            // 0x010EF05C: LDR w0, [x8]               | W0 = 0x19E7;                            
            // 0x010EF060: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E7, ????);     
            // 0x010EF064: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x010EF068: STRB w8, [x19, #0xae5]     | static_value_03735AE5 = true;            //  dest_result_addr=57891557
            label_0:
            // 0x010EF06C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x010EF070: LDR x8, [x8, #0xe08]       | X8 = 1152921504781766656;               
            // 0x010EF074: ORR w9, wzr, #0x20000000   | W9 = 536870912(0x20000000);             
            // 0x010EF078: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Method.CLRMethod);
            // 0x010EF07C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.CLR.Method.CLRMethod.__il2cppRuntimeField_static_fields;
            // 0x010EF080: STR w9, [x8]               | ILRuntime.CLR.Method.CLRMethod.instance_id = 536870912;  //  dest_result_addr=1152921504781770752
            ILRuntime.CLR.Method.CLRMethod.instance_id = 536870912;
            // 0x010EF084: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x010EF088: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x010EF08C: RET                        |  return;                                
            return;
        
        }
    
    }

}
