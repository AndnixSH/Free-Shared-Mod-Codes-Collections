using UnityEngine;
[Serializable]
public enum DepthOfFieldScatter.BlurSampleCount
{
    // Fields
    Low = 0
    ,Medium = 1
    ,High = 2
    

}
