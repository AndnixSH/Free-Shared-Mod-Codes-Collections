using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonRegex : BsonToken
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285EA24
        private Newtonsoft.Json.Bson.BsonString <Pattern>k__BackingField; //  0x00000020
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285EA60
        private Newtonsoft.Json.Bson.BsonString <Options>k__BackingField; //  0x00000028
        
        // Properties
        public Newtonsoft.Json.Bson.BsonString Pattern { get; set; }
        public Newtonsoft.Json.Bson.BsonString Options { get; set; }
        public override Newtonsoft.Json.Bson.BsonType Type { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD46C4 (11355844), len: 184  VirtAddr: 0x00AD46C4 RVA: 0x00AD46C4 token: 100684784 methodIndex: 47420 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonRegex(string pattern, string options)
        {
            //
            // Disasemble & Code
            // 0x00AD46C4: STP x24, x23, [sp, #-0x40]! | stack[1152921513724577040] = ???;  stack[1152921513724577048] = ???;  //  dest_result_addr=1152921513724577040 |  dest_result_addr=1152921513724577048
            // 0x00AD46C8: STP x22, x21, [sp, #0x10]  | stack[1152921513724577056] = ???;  stack[1152921513724577064] = ???;  //  dest_result_addr=1152921513724577056 |  dest_result_addr=1152921513724577064
            // 0x00AD46CC: STP x20, x19, [sp, #0x20]  | stack[1152921513724577072] = ???;  stack[1152921513724577080] = ???;  //  dest_result_addr=1152921513724577072 |  dest_result_addr=1152921513724577080
            // 0x00AD46D0: STP x29, x30, [sp, #0x30]  | stack[1152921513724577088] = ???;  stack[1152921513724577096] = ???;  //  dest_result_addr=1152921513724577088 |  dest_result_addr=1152921513724577096
            // 0x00AD46D4: ADD x29, sp, #0x30         | X29 = (1152921513724577040 + 48) = 1152921513724577088 (0x100000021F758540);
            // 0x00AD46D8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD46DC: LDRB w8, [x22, #0x4df]     | W8 = (bool)static_value_037334DF;       
            // 0x00AD46E0: MOV x19, x2                | X19 = options;//m1                      
            // 0x00AD46E4: MOV x21, x1                | X21 = pattern;//m1                      
            // 0x00AD46E8: MOV x20, x0                | X20 = 1152921513724589104 (0x100000021F75B430);//ML01
            // 0x00AD46EC: TBNZ w8, #0, #0xad4708     | if (static_value_037334DF == true) goto label_0;
            // 0x00AD46F0: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00AD46F4: LDR x8, [x8, #0x1e8]       | X8 = 0x2B8F9D4;                         
            // 0x00AD46F8: LDR w0, [x8]               | W0 = 0x1539;                            
            // 0x00AD46FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1539, ????);     
            // 0x00AD4700: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD4704: STRB w8, [x22, #0x4df]     | static_value_037334DF = true;            //  dest_result_addr=57881823
            label_0:
            // 0x00AD4708: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD470C: MOV x0, x20                | X0 = 1152921513724589104 (0x100000021F75B430);//ML01
            // 0x00AD4710: BL #0x16f59f0              | options..ctor();                        
            val_1 = new System.Object();
            // 0x00AD4714: ADRP x23, #0x3682000       | X23 = 57155584 (0x3682000);             
            // 0x00AD4718: LDR x23, [x23, #0x188]     | X23 = 1152921504857911296;              
            // 0x00AD471C: LDR x0, [x23]              | X0 = typeof(Newtonsoft.Json.Bson.BsonString);
            object val_2 = null;
            // 0x00AD4720: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD4724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4728: MOV x22, x0                | X22 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD472C: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x00AD4730: ORR w24, wzr, #2           | W24 = 2(0x2);                           
            // 0x00AD4734: STR x21, [x22, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = pattern;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = pattern;
            // 0x00AD4738: STRB wzr, [x22, #0x30]     | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x0;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0;
            // 0x00AD473C: STRB w24, [x22, #0x28]     | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD4740: STR x22, [x20, #0x20]      | this.<Pattern>k__BackingField = typeof(Newtonsoft.Json.Bson.BsonString);  //  dest_result_addr=1152921513724589136
            this.<Pattern>k__BackingField = val_2;
            // 0x00AD4744: LDR x0, [x23]              | X0 = typeof(Newtonsoft.Json.Bson.BsonString);
            object val_3 = null;
            // 0x00AD4748: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Bson.BsonString), ????);
            // 0x00AD474C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD4750: MOV x21, x0                | X21 = 1152921504857911296 (0x100000000EF6F000);//ML01
            // 0x00AD4754: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x00AD4758: STR x19, [x21, #0x20]      | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = options;  //  dest_result_addr=1152921504857911328
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_20 = val_1;
            // 0x00AD475C: STRB w24, [x21, #0x28]     | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 0x2;  //  dest_result_addr=1152921504857911336
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_28 = 2;
            // 0x00AD4760: STRB wzr, [x21, #0x30]     | typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0x0;  //  dest_result_addr=1152921504857911344
            typeof(Newtonsoft.Json.Bson.BsonString).__il2cppRuntimeField_30 = 0;
            // 0x00AD4764: STR x21, [x20, #0x28]      | this.<Options>k__BackingField = typeof(Newtonsoft.Json.Bson.BsonString);  //  dest_result_addr=1152921513724589144
            this.<Options>k__BackingField = val_3;
            // 0x00AD4768: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD476C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD4770: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD4774: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AD4778: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B18 (11344664), len: 8  VirtAddr: 0x00AD1B18 RVA: 0x00AD1B18 token: 100684785 methodIndex: 47421 delegateWrapperIndex: 0 methodInvoker: 0
        public Newtonsoft.Json.Bson.BsonString get_Pattern()
        {
            //
            // Disasemble & Code
            // 0x00AD1B18: LDR x0, [x0, #0x20]        | X0 = this.<Pattern>k__BackingField; //P2 
            // 0x00AD1B1C: RET                        |  return (Newtonsoft.Json.Bson.BsonString)this.<Pattern>k__BackingField;
            return this.<Pattern>k__BackingField;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonString, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD477C (11356028), len: 8  VirtAddr: 0x00AD477C RVA: 0x00AD477C token: 100684786 methodIndex: 47422 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Pattern(Newtonsoft.Json.Bson.BsonString value)
        {
            //
            // Disasemble & Code
            // 0x00AD477C: STR x1, [x0, #0x20]        | this.<Pattern>k__BackingField = value;   //  dest_result_addr=1152921513724833616
            this.<Pattern>k__BackingField = value;
            // 0x00AD4780: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B20 (11344672), len: 8  VirtAddr: 0x00AD1B20 RVA: 0x00AD1B20 token: 100684787 methodIndex: 47423 delegateWrapperIndex: 0 methodInvoker: 0
        public Newtonsoft.Json.Bson.BsonString get_Options()
        {
            //
            // Disasemble & Code
            // 0x00AD1B20: LDR x0, [x0, #0x28]        | X0 = this.<Options>k__BackingField; //P2 
            // 0x00AD1B24: RET                        |  return (Newtonsoft.Json.Bson.BsonString)this.<Options>k__BackingField;
            return this.<Options>k__BackingField;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonString, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD4784 (11356036), len: 8  VirtAddr: 0x00AD4784 RVA: 0x00AD4784 token: 100684788 methodIndex: 47424 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Options(Newtonsoft.Json.Bson.BsonString value)
        {
            //
            // Disasemble & Code
            // 0x00AD4784: STR x1, [x0, #0x28]        | this.<Options>k__BackingField = value;   //  dest_result_addr=1152921513725074008
            this.<Options>k__BackingField = value;
            // 0x00AD4788: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD478C (11356044), len: 8  VirtAddr: 0x00AD478C RVA: 0x00AD478C token: 100684789 methodIndex: 47425 delegateWrapperIndex: 0 methodInvoker: 0
        public override Newtonsoft.Json.Bson.BsonType get_Type()
        {
            //
            // Disasemble & Code
            // 0x00AD478C: MOVZ w0, #0xb              | W0 = 11 (0xB);//ML01                    
            // 0x00AD4790: RET                        |  return (Newtonsoft.Json.Bson.BsonType)0xB;
            return 11;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonType, size=8, nGRN=0 }
        
        }
    
    }

}
