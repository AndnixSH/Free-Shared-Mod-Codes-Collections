using UnityEngine;
public class ActorLine : IEffComponent
{
    // Fields
    public UnityEngine.Transform host; //  0x00000018
    public UnityEngine.Transform targetTr; //  0x00000020
    public float lifetime; //  0x00000028
    public float startTime; //  0x0000002C
    public UnityEngine.LineRenderer lineRenderer; //  0x00000030
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B20704 (11667204), len: 8  VirtAddr: 0x00B20704 RVA: 0x00B20704 token: 100693592 methodIndex: 24701 delegateWrapperIndex: 0 methodInvoker: 0
    public ActorLine()
    {
        //
        // Disasemble & Code
        // 0x00B20704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20708: B #0x28a4a40               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2070C (11667212), len: 268  VirtAddr: 0x00B2070C RVA: 0x00B2070C token: 100693593 methodIndex: 24702 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetLine(UnityEngine.Transform targetTr, UnityEngine.Transform host, float lifetime, UnityEngine.LineRenderer lineRenderer)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Object val_5;
        // 0x00B2070C: STP d9, d8, [sp, #-0x50]!  | stack[1152921515018283392] = ???;  stack[1152921515018283400] = ???;  //  dest_result_addr=1152921515018283392 |  dest_result_addr=1152921515018283400
        // 0x00B20710: STP x24, x23, [sp, #0x10]  | stack[1152921515018283408] = ???;  stack[1152921515018283416] = ???;  //  dest_result_addr=1152921515018283408 |  dest_result_addr=1152921515018283416
        // 0x00B20714: STP x22, x21, [sp, #0x20]  | stack[1152921515018283424] = ???;  stack[1152921515018283432] = ???;  //  dest_result_addr=1152921515018283424 |  dest_result_addr=1152921515018283432
        // 0x00B20718: STP x20, x19, [sp, #0x30]  | stack[1152921515018283440] = ???;  stack[1152921515018283448] = ???;  //  dest_result_addr=1152921515018283440 |  dest_result_addr=1152921515018283448
        // 0x00B2071C: STP x29, x30, [sp, #0x40]  | stack[1152921515018283456] = ???;  stack[1152921515018283464] = ???;  //  dest_result_addr=1152921515018283456 |  dest_result_addr=1152921515018283464
        // 0x00B20720: ADD x29, sp, #0x40         | X29 = (1152921515018283392 + 64) = 1152921515018283456 (0x100000026C91E9C0);
        // 0x00B20724: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B20728: LDRB w8, [x23, #0x71d]     | W8 = (bool)static_value_0373371D;       
        // 0x00B2072C: MOV x19, x3                | X19 = lineRenderer;//m1                 
        // 0x00B20730: MOV v8.16b, v0.16b         | V8 = lifetime;//m1                      
        // 0x00B20734: MOV x22, x2                | X22 = host;//m1                         
        // 0x00B20738: MOV x21, x1                | X21 = targetTr;//m1                     
        // 0x00B2073C: MOV x20, x0                | X20 = 1152921515018295472 (0x100000026C9218B0);//ML01
        // 0x00B20740: TBNZ w8, #0, #0xb2075c     | if (static_value_0373371D == true) goto label_0;
        // 0x00B20744: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00B20748: LDR x8, [x8, #0xf48]       | X8 = 0x2B8A9F0;                         
        // 0x00B2074C: LDR w0, [x8]               | W0 = 0x13A;                             
        // 0x00B20750: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A, ????);      
        // 0x00B20754: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20758: STRB w8, [x23, #0x71d]     | static_value_0373371D = true;            //  dest_result_addr=57882397
        label_0:
        // 0x00B2075C: STR x22, [x20, #0x18]      | this.host = host;                        //  dest_result_addr=1152921515018295496
        this.host = host;
        // 0x00B20760: CBNZ x21, #0xb20768        | if (targetTr != null) goto label_1;     
        if(targetTr != null)
        {
            goto label_1;
        }
        // 0x00B20764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A, ????);      
        label_1:
        // 0x00B20768: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B2076C: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921515015094960)("Bipbehit");
        // 0x00B20770: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20774: MOV x0, x21                | X0 = targetTr;//m1                      
        // 0x00B20778: LDR x1, [x8]               | X1 = "Bipbehit";                        
        // 0x00B2077C: BL #0x2695ac0              | X0 = targetTr.Find(name:  "Bipbehit");  
        UnityEngine.Transform val_1 = targetTr.Find(name:  "Bipbehit");
        // 0x00B20780: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B20784: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B20788: MOV x22, x0                | X22 = val_1;//m1                        
        val_5 = val_1;
        // 0x00B2078C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B20790: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B20794: TBZ w9, #0, #0xb207a8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B20798: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B2079C: CBNZ w9, #0xb207a8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B207A0: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B207A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B207A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B207AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B207B0: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x00B207B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B207B8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_5);
        bool val_2 = UnityEngine.Object.op_Equality(x:  0, y:  val_5);
        // 0x00B207BC: TBZ w0, #0, #0xb207e4      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B207C0: CBNZ x21, #0xb207c8        | if (targetTr != null) goto label_5;     
        if(targetTr != null)
        {
            goto label_5;
        }
        // 0x00B207C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B207C8: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B207CC: LDR x8, [x8, #0xbd0]       | X8 = (string**)(1152921515015099152)("waistpoint");
        // 0x00B207D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B207D4: MOV x0, x21                | X0 = targetTr;//m1                      
        // 0x00B207D8: LDR x1, [x8]               | X1 = "waistpoint";                      
        // 0x00B207DC: BL #0x2695ac0              | X0 = targetTr.Find(name:  "waistpoint");
        UnityEngine.Transform val_3 = targetTr.Find(name:  "waistpoint");
        // 0x00B207E0: MOV x22, x0                | X22 = val_3;//m1                        
        val_5 = val_3;
        label_4:
        // 0x00B207E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B207E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B207EC: STR x22, [x20, #0x20]      | this.targetTr = val_3;                   //  dest_result_addr=1152921515018295504
        this.targetTr = val_5;
        // 0x00B207F0: STR s8, [x20, #0x28]       | this.lifetime = lifetime;                //  dest_result_addr=1152921515018295512
        this.lifetime = lifetime;
        // 0x00B207F4: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_4 = UnityEngine.Time.time;
        // 0x00B207F8: STR x19, [x20, #0x30]      | this.lineRenderer = lineRenderer;        //  dest_result_addr=1152921515018295520
        this.lineRenderer = lineRenderer;
        // 0x00B207FC: STR s0, [x20, #0x2c]       | this.startTime = val_4;                  //  dest_result_addr=1152921515018295516
        this.startTime = val_4;
        // 0x00B20800: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B20804: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B20808: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2080C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B20810: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B20814: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20818 (11667480), len: 456  VirtAddr: 0x00B20818 RVA: 0x00B20818 token: 100693594 methodIndex: 24703 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Update()
    {
        //
        // Disasemble & Code
        // 0x00B20818: STP d11, d10, [sp, #-0x50]! | stack[1152921515018444544] = ???;  stack[1152921515018444552] = ???;  //  dest_result_addr=1152921515018444544 |  dest_result_addr=1152921515018444552
        // 0x00B2081C: STP d9, d8, [sp, #0x10]    | stack[1152921515018444560] = ???;  stack[1152921515018444568] = ???;  //  dest_result_addr=1152921515018444560 |  dest_result_addr=1152921515018444568
        // 0x00B20820: STP x22, x21, [sp, #0x20]  | stack[1152921515018444576] = ???;  stack[1152921515018444584] = ???;  //  dest_result_addr=1152921515018444576 |  dest_result_addr=1152921515018444584
        // 0x00B20824: STP x20, x19, [sp, #0x30]  | stack[1152921515018444592] = ???;  stack[1152921515018444600] = ???;  //  dest_result_addr=1152921515018444592 |  dest_result_addr=1152921515018444600
        // 0x00B20828: STP x29, x30, [sp, #0x40]  | stack[1152921515018444608] = ???;  stack[1152921515018444616] = ???;  //  dest_result_addr=1152921515018444608 |  dest_result_addr=1152921515018444616
        // 0x00B2082C: ADD x29, sp, #0x40         | X29 = (1152921515018444544 + 64) = 1152921515018444608 (0x100000026C945F40);
        // 0x00B20830: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B20834: LDRB w8, [x20, #0x71e]     | W8 = (bool)static_value_0373371E;       
        // 0x00B20838: MOV x19, x0                | X19 = 1152921515018456624 (0x100000026C948E30);//ML01
        // 0x00B2083C: TBNZ w8, #0, #0xb20858     | if (static_value_0373371E == true) goto label_0;
        // 0x00B20840: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
        // 0x00B20844: LDR x8, [x8, #0x270]       | X8 = 0x2B8A9F4;                         
        // 0x00B20848: LDR w0, [x8]               | W0 = 0x13B;                             
        // 0x00B2084C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13B, ????);      
        // 0x00B20850: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20854: STRB w8, [x20, #0x71e]     | static_value_0373371E = true;            //  dest_result_addr=57882398
        label_0:
        // 0x00B20858: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2085C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20860: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x00B20864: LDP s2, s1, [x19, #0x28]   | S2 = this.lifetime; //P2  S1 = this.startTime; //P2  //  | 
        // 0x00B20868: FSUB s0, s0, s1            | S0 = (val_1 - this.startTime);          
        val_1 = val_1 - this.startTime;
        // 0x00B2086C: FCMP s0, s2                | STATE = COMPARE((val_1 - this.startTime), this.lifetime)
        // 0x00B20870: B.LS #0xb20890             | if (val_1 <= this.lifetime) goto label_1;
        if(val_1 <= this.lifetime)
        {
            goto label_1;
        }
        // 0x00B20874: MOV x0, x19                | X0 = 1152921515018456624 (0x100000026C948E30);//ML01
        // 0x00B20878: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2087C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B20880: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B20884: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B20888: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B2088C: B #0xb209e0                | this.End(); return;                     
        this.End();
        return;
        label_1:
        // 0x00B20890: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B20894: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00B20898: LDR x20, [x19, #0x20]      | X20 = this.targetTr; //P2               
        // 0x00B2089C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B208A0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B208A4: TBZ w8, #0, #0xb208b4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B208A8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B208AC: CBNZ w8, #0xb208b4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B208B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B208B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B208B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B208BC: MOV x1, x20                | X1 = this.targetTr;//m1                 
        // 0x00B208C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B208C4: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.targetTr);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.targetTr);
        // 0x00B208C8: TBZ w0, #0, #0xb209c8      | if (val_2 == false) goto label_7;       
        if(val_2 == false)
        {
            goto label_7;
        }
        // 0x00B208CC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B208D0: LDR x20, [x19, #0x18]      | X20 = this.host; //P2                   
        // 0x00B208D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B208D8: TBZ w8, #0, #0xb208e8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B208DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B208E0: CBNZ w8, #0xb208e8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B208E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_6:
        // 0x00B208E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B208EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B208F0: MOV x1, x20                | X1 = this.host;//m1                     
        // 0x00B208F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B208F8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.host);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  this.host);
        // 0x00B208FC: TBZ w0, #0, #0xb209c8      | if (val_3 == false) goto label_7;       
        if(val_3 == false)
        {
            goto label_7;
        }
        // 0x00B20900: LDR x20, [x19, #0x30]      | X20 = this.lineRenderer; //P2           
        // 0x00B20904: CBNZ x20, #0xb2090c        | if (this.lineRenderer != null) goto label_8;
        if(this.lineRenderer != null)
        {
            goto label_8;
        }
        // 0x00B20908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B2090C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20910: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B20914: MOV x0, x20                | X0 = this.lineRenderer;//m1             
        // 0x00B20918: BL #0x1a75910              | this.lineRenderer.SetVertexCount(count:  2);
        this.lineRenderer.SetVertexCount(count:  2);
        // 0x00B2091C: LDR x20, [x19, #0x30]      | X20 = this.lineRenderer; //P2           
        // 0x00B20920: LDR x21, [x19, #0x18]      | X21 = this.host; //P2                   
        // 0x00B20924: CBNZ x21, #0xb2092c        | if (this.host != null) goto label_9;    
        if(this.host != null)
        {
            goto label_9;
        }
        // 0x00B20928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.lineRenderer, ????);
        label_9:
        // 0x00B2092C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20930: MOV x0, x21                | X0 = this.host;//m1                     
        // 0x00B20934: BL #0x2693510              | X0 = this.host.get_position();          
        UnityEngine.Vector3 val_4 = this.host.position;
        // 0x00B20938: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        // 0x00B2093C: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        // 0x00B20940: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x00B20944: CBNZ x20, #0xb2094c        | if (this.lineRenderer != null) goto label_10;
        if(this.lineRenderer != null)
        {
            goto label_10;
        }
        // 0x00B20948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_10:
        // 0x00B2094C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B20950: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20954: MOV x0, x20                | X0 = this.lineRenderer;//m1             
        // 0x00B20958: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x00B2095C: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x00B20960: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x00B20964: BL #0x1a7619c              | this.lineRenderer.SetPosition(index:  0, position:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        this.lineRenderer.SetPosition(index:  0, position:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        // 0x00B20968: LDR x20, [x19, #0x30]      | X20 = this.lineRenderer; //P2           
        // 0x00B2096C: LDR x19, [x19, #0x20]      | X19 = this.targetTr; //P2               
        // 0x00B20970: CBNZ x19, #0xb20978        | if (this.targetTr != null) goto label_11;
        if(this.targetTr != null)
        {
            goto label_11;
        }
        // 0x00B20974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.lineRenderer, ????);
        label_11:
        // 0x00B20978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2097C: MOV x0, x19                | X0 = this.targetTr;//m1                 
        // 0x00B20980: BL #0x2693510              | X0 = this.targetTr.get_position();      
        UnityEngine.Vector3 val_5 = this.targetTr.position;
        // 0x00B20984: MOV v8.16b, v0.16b         | V8 = val_5.x;//m1                       
        // 0x00B20988: MOV v9.16b, v1.16b         | V9 = val_5.y;//m1                       
        // 0x00B2098C: MOV v10.16b, v2.16b        | V10 = val_5.z;//m1                      
        // 0x00B20990: CBNZ x20, #0xb20998        | if (this.lineRenderer != null) goto label_12;
        if(this.lineRenderer != null)
        {
            goto label_12;
        }
        // 0x00B20994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.targetTr, ????);
        label_12:
        // 0x00B20998: MOV x0, x20                | X0 = this.lineRenderer;//m1             
        // 0x00B2099C: MOV v0.16b, v8.16b         | V0 = val_5.x;//m1                       
        // 0x00B209A0: MOV v1.16b, v9.16b         | V1 = val_5.y;//m1                       
        // 0x00B209A4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B209A8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B209AC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B209B0: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B209B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B209B8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B209BC: MOV v2.16b, v10.16b        | V2 = val_5.z;//m1                       
        // 0x00B209C0: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B209C4: B #0x1a7619c               | this.lineRenderer.SetPosition(index:  1, position:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}); return;
        this.lineRenderer.SetPosition(index:  1, position:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
        return;
        label_7:
        // 0x00B209C8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B209CC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B209D0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B209D4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B209D8: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B209DC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B209E0 (11667936), len: 148  VirtAddr: 0x00B209E0 RVA: 0x00B209E0 token: 100693595 methodIndex: 24704 delegateWrapperIndex: 0 methodInvoker: 0
    private void End()
    {
        //
        // Disasemble & Code
        // 0x00B209E0: STP x20, x19, [sp, #-0x20]! | stack[1152921515018593456] = ???;  stack[1152921515018593464] = ???;  //  dest_result_addr=1152921515018593456 |  dest_result_addr=1152921515018593464
        // 0x00B209E4: STP x29, x30, [sp, #0x10]  | stack[1152921515018593472] = ???;  stack[1152921515018593480] = ???;  //  dest_result_addr=1152921515018593472 |  dest_result_addr=1152921515018593480
        // 0x00B209E8: ADD x29, sp, #0x10         | X29 = (1152921515018593456 + 16) = 1152921515018593472 (0x100000026C96A4C0);
        // 0x00B209EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B209F0: LDRB w8, [x20, #0x71f]     | W8 = (bool)static_value_0373371F;       
        // 0x00B209F4: MOV x19, x0                | X19 = 1152921515018605488 (0x100000026C96D3B0);//ML01
        // 0x00B209F8: TBNZ w8, #0, #0xb20a14     | if (static_value_0373371F == true) goto label_0;
        // 0x00B209FC: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B20A00: LDR x8, [x8, #0x4c8]       | X8 = 0x2B8A9EC;                         
        // 0x00B20A04: LDR w0, [x8]               | W0 = 0x139;                             
        // 0x00B20A08: BL #0x2782188              | X0 = sub_2782188( ?? 0x139, ????);      
        // 0x00B20A0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20A10: STRB w8, [x20, #0x71f]     | static_value_0373371F = true;            //  dest_result_addr=57882399
        label_0:
        // 0x00B20A14: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B20A18: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B20A1C: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B20A20: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B20A24: TBZ w8, #0, #0xb20a34      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B20A28: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B20A2C: CBNZ w8, #0xb20a34         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B20A30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00B20A34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20A3C: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_1 = ZMG.EffectMgr;
        // 0x00B20A40: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B20A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20A48: MOV x0, x19                | X0 = 1152921515018605488 (0x100000026C96D3B0);//ML01
        // 0x00B20A4C: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_2 = this.effCtrl;
        // 0x00B20A50: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B20A54: CBNZ x20, #0xb20a5c        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B20A58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B20A5C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B20A60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20A64: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B20A68: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00B20A6C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B20A70: B #0xb60074                | val_1.ResetEffectGameObject(effectObj:  val_2); return;
        val_1.ResetEffectGameObject(effectObj:  val_2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20A74 (11668084), len: 12  VirtAddr: 0x00B20A74 RVA: 0x00B20A74 token: 100693596 methodIndex: 24705 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Reset()
    {
        //
        // Disasemble & Code
        // 0x00B20A74: STR xzr, [x0, #0x30]       | this.lineRenderer = null;                //  dest_result_addr=1152921515018725728
        this.lineRenderer = 0;
        // 0x00B20A78: STP xzr, xzr, [x0, #0x18]  | this.host = null;  this.targetTr = null;  //  dest_result_addr=1152921515018725704 |  dest_result_addr=1152921515018725712
        this.host = 0;
        this.targetTr = 0;
        // 0x00B20A7C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20A80 (11668096), len: 4  VirtAddr: 0x00B20A80 RVA: 0x00B20A80 token: 100693597 methodIndex: 24706 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(UnityEngine.GameObject effGO)
    {
        //
        // Disasemble & Code
        // 0x00B20A80: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20A84 (11668100), len: 4  VirtAddr: 0x00B20A84 RVA: 0x00B20A84 token: 100693598 methodIndex: 24707 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Play()
    {
        //
        // Disasemble & Code
        // 0x00B20A84: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20A88 (11668104), len: 12  VirtAddr: 0x00B20A88 RVA: 0x00B20A88 token: 100693599 methodIndex: 24708 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Stop()
    {
        //
        // Disasemble & Code
        // 0x00B20A88: LDR x8, [x0]               | X8 = typeof(ActorLine);                 
        // 0x00B20A8C: LDP x2, x1, [x8, #0x190]   | X2 = typeof(ActorLine).__il2cppRuntimeField_190; X1 = typeof(ActorLine).__il2cppRuntimeField_198; //  | 
        // 0x00B20A90: BR x2                      | goto typeof(ActorLine).__il2cppRuntimeField_190;
        goto typeof(ActorLine).__il2cppRuntimeField_190;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20A94 (11668116), len: 12  VirtAddr: 0x00B20A94 RVA: 0x00B20A94 token: 100693600 methodIndex: 24709 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B20A94: LDR x8, [x0]               | X8 = typeof(ActorLine);                 
        // 0x00B20A98: LDP x2, x1, [x8, #0x190]   | X2 = typeof(ActorLine).__il2cppRuntimeField_190; X1 = typeof(ActorLine).__il2cppRuntimeField_198; //  | 
        // 0x00B20A9C: BR x2                      | goto typeof(ActorLine).__il2cppRuntimeField_190;
        goto typeof(ActorLine).__il2cppRuntimeField_190;
    
    }

}
