using UnityEngine;
private sealed class TypeSystem.CoreTypeSystem : TypeSystem
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x011ECF34 (18796340), len: 44  VirtAddr: 0x011ECF34 RVA: 0x011ECF34 token: 100664461 methodIndex: 20618 delegateWrapperIndex: 0 methodInvoker: 0
    public TypeSystem.CoreTypeSystem(ILRuntime.Mono.Cecil.ModuleDefinition module)
    {
        //
        // Disasemble & Code
        // 0x011ECF34: STP x20, x19, [sp, #-0x20]! | stack[1152921509551881568] = ???;  stack[1152921509551881576] = ???;  //  dest_result_addr=1152921509551881568 |  dest_result_addr=1152921509551881576
        // 0x011ECF38: STP x29, x30, [sp, #0x10]  | stack[1152921509551881584] = ???;  stack[1152921509551881592] = ???;  //  dest_result_addr=1152921509551881584 |  dest_result_addr=1152921509551881592
        // 0x011ECF3C: ADD x29, sp, #0x10         | X29 = (1152921509551881568 + 16) = 1152921509551881584 (0x1000000126BF3D70);
        // 0x011ECF40: MOV x19, x1                | X19 = module;//m1                       
        // 0x011ECF44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ECF48: MOV x20, x0                | X20 = 1152921509551893600 (0x1000000126BF6C60);//ML01
        // 0x011ECF4C: BL #0x16f59f0              | this..ctor();                           
        val_1 = new System.Object();
        // 0x011ECF50: STR x19, [x20, #0x10]      | mem[1152921509551893616] = module;       //  dest_result_addr=1152921509551893616
        mem[1152921509551893616] = module;
        // 0x011ECF54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x011ECF58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x011ECF5C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED508 (18797832), len: 172  VirtAddr: 0x011ED508 RVA: 0x011ED508 token: 100664462 methodIndex: 20619 delegateWrapperIndex: 0 methodInvoker: 0
    internal override ILRuntime.Mono.Cecil.TypeReference LookupType(string namespace, string name)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x011ED508: STP x22, x21, [sp, #-0x30]! | stack[1152921509552019152] = ???;  stack[1152921509552019160] = ???;  //  dest_result_addr=1152921509552019152 |  dest_result_addr=1152921509552019160
        // 0x011ED50C: STP x20, x19, [sp, #0x10]  | stack[1152921509552019168] = ???;  stack[1152921509552019176] = ???;  //  dest_result_addr=1152921509552019168 |  dest_result_addr=1152921509552019176
        // 0x011ED510: STP x29, x30, [sp, #0x20]  | stack[1152921509552019184] = ???;  stack[1152921509552019192] = ???;  //  dest_result_addr=1152921509552019184 |  dest_result_addr=1152921509552019192
        // 0x011ED514: ADD x29, sp, #0x20         | X29 = (1152921509552019152 + 32) = 1152921509552019184 (0x1000000126C156F0);
        // 0x011ED518: ADRP x22, #0x3736000       | X22 = 57892864 (0x3736000);             
        // 0x011ED51C: LDRB w8, [x22, #0x17c]     | W8 = (bool)static_value_0373617C;       
        // 0x011ED520: MOV x19, x2                | X19 = name;//m1                         
        // 0x011ED524: MOV x20, x1                | X20 = namespace;//m1                    
        // 0x011ED528: MOV x21, x0                | X21 = 1152921509552031200 (0x1000000126C185E0);//ML01
        // 0x011ED52C: TBNZ w8, #0, #0x11ed548    | if (static_value_0373617C == true) goto label_0;
        // 0x011ED530: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x011ED534: LDR x8, [x8, #0xa8]        | X8 = 0x2B92D2C;                         
        // 0x011ED538: LDR w0, [x8]               | W0 = 0x2210;                            
        // 0x011ED53C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2210, ????);     
        // 0x011ED540: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x011ED544: STRB w8, [x22, #0x17c]     | static_value_0373617C = true;            //  dest_result_addr=57893244
        label_0:
        // 0x011ED548: MOV x0, x21                | X0 = 1152921509552031200 (0x1000000126C185E0);//ML01
        // 0x011ED54C: MOV x1, x20                | X1 = namespace;//m1                     
        // 0x011ED550: MOV x2, x19                | X2 = name;//m1                          
        // 0x011ED554: BL #0x11ed5b4              | X0 = this.LookupTypeDefinition(namespace:  namespace, name:  name);
        ILRuntime.Mono.Cecil.TypeReference val_1 = this.LookupTypeDefinition(namespace:  namespace, name:  name);
        // 0x011ED558: CBNZ x0, #0x11ed570        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x011ED55C: MOV x0, x21                | X0 = 1152921509552031200 (0x1000000126C185E0);//ML01
        // 0x011ED560: MOV x1, x20                | X1 = namespace;//m1                     
        // 0x011ED564: MOV x2, x19                | X2 = name;//m1                          
        // 0x011ED568: BL #0x11ed734              | X0 = this.LookupTypeForwarded(namespace:  namespace, name:  name);
        ILRuntime.Mono.Cecil.TypeReference val_2 = this.LookupTypeForwarded(namespace:  namespace, name:  name);
        // 0x011ED56C: CBZ x0, #0x11ed580         | if (val_2 == null) goto label_2;        
        if(val_2 == null)
        {
            goto label_2;
        }
        label_1:
        // 0x011ED570: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED574: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x011ED578: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x011ED57C: RET                        |  return (ILRuntime.Mono.Cecil.TypeReference)val_2;
        return val_2;
        //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.TypeReference, size=8, nGRN=0 }
        label_2:
        // 0x011ED580: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x011ED584: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
        // 0x011ED588: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
        System.NotSupportedException val_3 = null;
        // 0x011ED58C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
        // 0x011ED590: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ED594: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
        // 0x011ED598: BL #0x1701574              | .ctor();                                
        val_3 = new System.NotSupportedException();
        // 0x011ED59C: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
        // 0x011ED5A0: LDR x8, [x8, #0xa70]       | X8 = 1152921509552002080;               
        // 0x011ED5A4: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
        // 0x011ED5A8: LDR x1, [x8]               | X1 = ILRuntime.Mono.Cecil.TypeReference TypeSystem.CoreTypeSystem::LookupType(string namespace, string name);
        // 0x011ED5AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
        // 0x011ED5B0: BL #0x11d249c              | X0 = Resolve(type:  ILRuntime.Mono.Cecil.TypeReference TypeSystem.CoreTypeSystem::LookupType(string namespace, string name));
        ILRuntime.Mono.Cecil.TypeDefinition val_4 = Resolve(type:  ILRuntime.Mono.Cecil.TypeReference TypeSystem.CoreTypeSystem::LookupType(string namespace, string name));
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED5B4 (18798004), len: 384  VirtAddr: 0x011ED5B4 RVA: 0x011ED5B4 token: 100664463 methodIndex: 20620 delegateWrapperIndex: 0 methodInvoker: 0
    private ILRuntime.Mono.Cecil.TypeReference LookupTypeDefinition(string namespace, string name)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        System.Func<ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String>, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Cecil.TypeDefinition> val_6;
        // 0x011ED5B4: STP x26, x25, [sp, #-0x50]! | stack[1152921509552171056] = ???;  stack[1152921509552171064] = ???;  //  dest_result_addr=1152921509552171056 |  dest_result_addr=1152921509552171064
        // 0x011ED5B8: STP x24, x23, [sp, #0x10]  | stack[1152921509552171072] = ???;  stack[1152921509552171080] = ???;  //  dest_result_addr=1152921509552171072 |  dest_result_addr=1152921509552171080
        // 0x011ED5BC: STP x22, x21, [sp, #0x20]  | stack[1152921509552171088] = ???;  stack[1152921509552171096] = ???;  //  dest_result_addr=1152921509552171088 |  dest_result_addr=1152921509552171096
        // 0x011ED5C0: STP x20, x19, [sp, #0x30]  | stack[1152921509552171104] = ???;  stack[1152921509552171112] = ???;  //  dest_result_addr=1152921509552171104 |  dest_result_addr=1152921509552171112
        // 0x011ED5C4: STP x29, x30, [sp, #0x40]  | stack[1152921509552171120] = ???;  stack[1152921509552171128] = ???;  //  dest_result_addr=1152921509552171120 |  dest_result_addr=1152921509552171128
        // 0x011ED5C8: ADD x29, sp, #0x40         | X29 = (1152921509552171056 + 64) = 1152921509552171120 (0x1000000126C3A870);
        // 0x011ED5CC: SUB sp, sp, #0x10          | SP = (1152921509552171056 - 16) = 1152921509552171040 (0x1000000126C3A820);
        // 0x011ED5D0: ADRP x22, #0x3736000       | X22 = 57892864 (0x3736000);             
        // 0x011ED5D4: LDRB w8, [x22, #0x17d]     | W8 = (bool)static_value_0373617D;       
        // 0x011ED5D8: MOV x20, x2                | X20 = name;//m1                         
        // 0x011ED5DC: MOV x21, x1                | X21 = namespace;//m1                    
        // 0x011ED5E0: MOV x19, x0                | X19 = 1152921509552183136 (0x1000000126C3D760);//ML01
        // 0x011ED5E4: TBNZ w8, #0, #0x11ed600    | if (static_value_0373617D == true) goto label_0;
        // 0x011ED5E8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x011ED5EC: LDR x8, [x8, #0x70]        | X8 = 0x2B92D30;                         
        // 0x011ED5F0: LDR w0, [x8]               | W0 = 0x2211;                            
        // 0x011ED5F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2211, ????);     
        // 0x011ED5F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x011ED5FC: STRB w8, [x22, #0x17d]     | static_value_0373617D = true;            //  dest_result_addr=57893245
        label_0:
        // 0x011ED600: LDR x22, [x19, #0x10]      | 
        // 0x011ED604: CBNZ x22, #0x11ed60c       | if ( != 0) goto label_1;                
        if(!=0)
        {
            goto label_1;
        }
        // 0x011ED608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2211, ????);     
        label_1:
        // 0x011ED60C: LDR x22, [x22, #0x28]      | X22 = (bool)static_value_03736028;      
        // 0x011ED610: CBNZ x22, #0x11ed618       | if (static_value_03736028 == true) goto label_2;
        // 0x011ED614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2211, ????);     
        label_2:
        // 0x011ED618: LDR x8, [x22, #0x20]       | X8 = static_value_03736028 + 32;        
        // 0x011ED61C: CBNZ x8, #0x11ed634        | if (static_value_03736028 + 32 != 0) goto label_3;
        // 0x011ED620: LDR x22, [x19, #0x10]      | 
        // 0x011ED624: CBNZ x22, #0x11ed62c       | if (static_value_03736028 == true) goto label_4;
        // 0x011ED628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2211, ????);     
        label_4:
        // 0x011ED62C: MOV x0, x22                | X0 = static_value_03736028;//m1         
        // 0x011ED630: BL #0x11dda1c              | X0 = static_value_03736028.get_Types(); 
        ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.TypeDefinition> val_1 = static_value_03736028.Types;
        label_3:
        // 0x011ED634: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
        // 0x011ED638: LDR x19, [x19, #0x10]      | 
        // 0x011ED63C: LDR x8, [x8, #0xf8]        | X8 = 1152921509539198976;               
        // 0x011ED640: MOV x0, sp                 | X0 = 1152921509552171040 (0x1000000126C3A820);//ML01
        ConvertUtils.TypeConvertKey val_2;
        // 0x011ED644: MOV x1, x21                | X1 = namespace;//m1                     
        // 0x011ED648: MOV x2, x20                | X2 = name;//m1                          
        // 0x011ED64C: LDR x3, [x8]               | X3 = public System.Void ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String>::.ctor(System.String col1, System.String col2);
        // 0x011ED650: STP xzr, xzr, [sp]         | stack[1152921509552171040] = 0x0;  stack[1152921509552171048] = 0x0;  //  dest_result_addr=1152921509552171040 |  dest_result_addr=1152921509552171048
        // 0x011ED654: BL #0x19d1ed4              | null..ctor(initialType:  namespace, targetType:  name);
        val_2 = new ConvertUtils.TypeConvertKey(initialType:  namespace, targetType:  name);
        // 0x011ED658: ADRP x25, #0x35dd000       | X25 = 56479744 (0x35DD000);             
        // 0x011ED65C: LDR x25, [x25, #0x9e0]     | X25 = 1152921504744386560;              
        // 0x011ED660: LDR x0, [x25]              | X0 = typeof(TypeSystem.CoreTypeSystem.<>c);
        val_5 = null;
        // 0x011ED664: LDRB w8, [x0, #0x10a]      | W8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_10A;
        // 0x011ED668: TBZ w8, #0, #0x11ed67c     | if (TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x011ED66C: LDR w8, [x0, #0xbc]        | W8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_cctor_finished;
        // 0x011ED670: CBNZ w8, #0x11ed67c        | if (TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x011ED674: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(TypeSystem.CoreTypeSystem.<>c), ????);
        // 0x011ED678: LDR x0, [x25]              | X0 = typeof(TypeSystem.CoreTypeSystem.<>c);
        val_5 = null;
        label_6:
        // 0x011ED67C: LDR x8, [x0, #0xa0]        | X8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_static_fields;
        // 0x011ED680: LDP x20, x21, [sp]         | X20 = val_2._initialType; X21 = val_2._targetType; //  | 
        // 0x011ED684: LDR x22, [x8, #8]          | X22 = TypeSystem.CoreTypeSystem.<>c.<>9__2_0;
        val_6 = TypeSystem.CoreTypeSystem.<>c.<>9__2_0;
        // 0x011ED688: CBNZ x22, #0x11ed6f0       | if (TypeSystem.CoreTypeSystem.<>c.<>9__2_0 != null) goto label_7;
        if(val_6 != null)
        {
            goto label_7;
        }
        // 0x011ED68C: LDRB w8, [x0, #0x10a]      | W8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_10A;
        // 0x011ED690: TBZ w8, #0, #0x11ed6a4     | if (TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x011ED694: LDR w8, [x0, #0xbc]        | W8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_cctor_finished;
        // 0x011ED698: CBNZ w8, #0x11ed6a4        | if (TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x011ED69C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(TypeSystem.CoreTypeSystem.<>c), ????);
        // 0x011ED6A0: LDR x0, [x25]              | X0 = typeof(TypeSystem.CoreTypeSystem.<>c);
        val_5 = null;
        label_9:
        // 0x011ED6A4: ADRP x9, #0x3616000        | X9 = 56713216 (0x3616000);              
        // 0x011ED6A8: ADRP x10, #0x362f000       | X10 = 56815616 (0x362F000);             
        // 0x011ED6AC: LDR x8, [x0, #0xa0]        | X8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_static_fields;
        // 0x011ED6B0: LDR x9, [x9, #0x220]       | X9 = 1152921509552151968;               
        // 0x011ED6B4: LDR x10, [x10, #0x848]     | X10 = 1152921504688156672;              
        // 0x011ED6B8: LDR x24, [x8]              | X24 = TypeSystem.CoreTypeSystem.<>c.<>9;
        // 0x011ED6BC: LDR x23, [x9]              | X23 = ILRuntime.Mono.Cecil.TypeDefinition TypeSystem.CoreTypeSystem.<>c::<LookupTypeDefinition>b__2_0(ILRuntime.Mono.Cecil.Metadata.Row<string, string> row, ILRuntime.Mono.Cecil.MetadataReader reader);
        // 0x011ED6C0: LDR x0, [x10]              | X0 = typeof(System.Func<T1, T2, TResult>);
        System.Func<ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String>, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Cecil.TypeDefinition> val_3 = null;
        // 0x011ED6C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T1, T2, TResult>), ????);
        // 0x011ED6C8: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x011ED6CC: LDR x8, [x8, #0x340]       | X8 = 1152921509552152992;               
        // 0x011ED6D0: MOV x1, x24                | X1 = TypeSystem.CoreTypeSystem.<>c.<>9;//m1
        // 0x011ED6D4: MOV x2, x23                | X2 = 1152921509552151968 (0x1000000126C35DA0);//ML01
        // 0x011ED6D8: MOV x22, x0                | X22 = 1152921504688156672 (0x1000000004D8B000);//ML01
        val_6 = val_3;
        // 0x011ED6DC: LDR x3, [x8]               | X3 = public System.Void System.Func<ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String>, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Cecil.TypeDefinition>::.ctor(object object, IntPtr method);
        // 0x011ED6E0: BL #0x21d445c              | .ctor(object:  TypeSystem.CoreTypeSystem.<>c.<>9, method:  ILRuntime.Mono.Cecil.TypeDefinition TypeSystem.CoreTypeSystem.<>c::<LookupTypeDefinition>b__2_0(ILRuntime.Mono.Cecil.Metadata.Row<string, string> row, ILRuntime.Mono.Cecil.MetadataReader reader));
        val_3 = new System.Func<ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String>, ILRuntime.Mono.Cecil.MetadataReader, ILRuntime.Mono.Cecil.TypeDefinition>(object:  TypeSystem.CoreTypeSystem.<>c.<>9, method:  ILRuntime.Mono.Cecil.TypeDefinition TypeSystem.CoreTypeSystem.<>c::<LookupTypeDefinition>b__2_0(ILRuntime.Mono.Cecil.Metadata.Row<string, string> row, ILRuntime.Mono.Cecil.MetadataReader reader));
        // 0x011ED6E4: LDR x8, [x25]              | X8 = typeof(TypeSystem.CoreTypeSystem.<>c);
        // 0x011ED6E8: LDR x8, [x8, #0xa0]        | X8 = TypeSystem.CoreTypeSystem.<>c.__il2cppRuntimeField_static_fields;
        // 0x011ED6EC: STR x22, [x8, #8]          | TypeSystem.CoreTypeSystem.<>c.<>9__2_0 = typeof(System.Func<T1, T2, TResult>);  //  dest_result_addr=1152921504744390664
        TypeSystem.CoreTypeSystem.<>c.<>9__2_0 = val_6;
        label_7:
        // 0x011ED6F0: CBNZ x19, #0x11ed6f8       | if (this != null) goto label_10;        
        if(this != null)
        {
            goto label_10;
        }
        // 0x011ED6F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  TypeSystem.CoreTypeSystem.<>c.<>9, method:  ILRuntime.Mono.Cecil.TypeDefinition TypeSystem.CoreTypeSystem.<>c::<LookupTypeDefinition>b__2_0(ILRuntime.Mono.Cecil.Metadata.Row<string, string> row, ILRuntime.Mono.Cecil.MetadataReader reader)), ????);
        label_10:
        // 0x011ED6F8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x011ED6FC: LDR x8, [x8, #0x978]       | X8 = 1152921509552154016;               
        // 0x011ED700: MOV x0, x19                | X0 = 1152921509552183136 (0x1000000126C3D760);//ML01
        // 0x011ED704: MOV x1, x20                | X1 = val_2._initialType;//m1            
        // 0x011ED708: MOV x2, x21                | X2 = val_2._targetType;//m1             
        // 0x011ED70C: LDR x4, [x8]               | X4 = ILRuntime.Mono.Cecil.TypeDefinition ILRuntime.Mono.Cecil.ModuleDefinition::Read<ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String>, ILRuntime.Mono.Cecil.TypeDefinition>(ILRuntime.Mono.Cecil.Metadata.Row<System.String, System.String> item, System.Func<TItem, ILRuntime.Mono.Cecil.MetadataReader, TRet> read);
        // 0x011ED710: MOV x3, x22                | X3 = 1152921504688156672 (0x1000000004D8B000);//ML01
        // 0x011ED714: BL #0x23da9b4              | X0 = this.Read<ILRuntime.Mono.Cecil.Metadata.Row<System.Object, System.Object>, System.Object>(item:  new ILRuntime.Mono.Cecil.Metadata.Row<System.Object, System.Object>() {Col2 = val_2._initialType}, read:  val_2._targetType);
        object val_4 = this.Read<ILRuntime.Mono.Cecil.Metadata.Row<System.Object, System.Object>, System.Object>(item:  new ILRuntime.Mono.Cecil.Metadata.Row<System.Object, System.Object>() {Col2 = val_2._initialType}, read:  val_2._targetType);
        // 0x011ED718: SUB sp, x29, #0x40         | SP = (1152921509552171120 - 64) = 1152921509552171056 (0x1000000126C3A830);
        // 0x011ED71C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED720: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x011ED724: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x011ED728: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x011ED72C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x011ED730: RET                        |  return (ILRuntime.Mono.Cecil.TypeReference)val_4;
        return (ILRuntime.Mono.Cecil.TypeReference)val_4;
        //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.TypeReference, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED734 (18798388), len: 444  VirtAddr: 0x011ED734 RVA: 0x011ED734 token: 100664464 methodIndex: 20621 delegateWrapperIndex: 0 methodInvoker: 0
    private ILRuntime.Mono.Cecil.TypeReference LookupTypeForwarded(string namespace, string name)
    {
        //
        // Disasemble & Code
        //  | 
        var val_9;
        //  | 
        var val_10;
        // 0x011ED734: STP x28, x27, [sp, #-0x60]! | stack[1152921509552324000] = ???;  stack[1152921509552324008] = ???;  //  dest_result_addr=1152921509552324000 |  dest_result_addr=1152921509552324008
        // 0x011ED738: STP x26, x25, [sp, #0x10]  | stack[1152921509552324016] = ???;  stack[1152921509552324024] = ???;  //  dest_result_addr=1152921509552324016 |  dest_result_addr=1152921509552324024
        // 0x011ED73C: STP x24, x23, [sp, #0x20]  | stack[1152921509552324032] = ???;  stack[1152921509552324040] = ???;  //  dest_result_addr=1152921509552324032 |  dest_result_addr=1152921509552324040
        // 0x011ED740: STP x22, x21, [sp, #0x30]  | stack[1152921509552324048] = ???;  stack[1152921509552324056] = ???;  //  dest_result_addr=1152921509552324048 |  dest_result_addr=1152921509552324056
        // 0x011ED744: STP x20, x19, [sp, #0x40]  | stack[1152921509552324064] = ???;  stack[1152921509552324072] = ???;  //  dest_result_addr=1152921509552324064 |  dest_result_addr=1152921509552324072
        // 0x011ED748: STP x29, x30, [sp, #0x50]  | stack[1152921509552324080] = ???;  stack[1152921509552324088] = ???;  //  dest_result_addr=1152921509552324080 |  dest_result_addr=1152921509552324088
        // 0x011ED74C: ADD x29, sp, #0x50         | X29 = (1152921509552324000 + 80) = 1152921509552324080 (0x1000000126C5FDF0);
        // 0x011ED750: ADRP x22, #0x3736000       | X22 = 57892864 (0x3736000);             
        // 0x011ED754: LDRB w8, [x22, #0x17e]     | W8 = (bool)static_value_0373617E;       
        // 0x011ED758: MOV x19, x2                | X19 = name;//m1                         
        // 0x011ED75C: MOV x20, x1                | X20 = namespace;//m1                    
        // 0x011ED760: MOV x21, x0                | X21 = 1152921509552336096 (0x1000000126C62CE0);//ML01
        val_9 = this;
        // 0x011ED764: TBNZ w8, #0, #0x11ed780    | if (static_value_0373617E == true) goto label_0;
        // 0x011ED768: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x011ED76C: LDR x8, [x8, #0xe60]       | X8 = 0x2B92D34;                         
        // 0x011ED770: LDR w0, [x8]               | W0 = 0x2212;                            
        // 0x011ED774: BL #0x2782188              | X0 = sub_2782188( ?? 0x2212, ????);     
        // 0x011ED778: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x011ED77C: STRB w8, [x22, #0x17e]     | static_value_0373617E = true;            //  dest_result_addr=57893246
        label_0:
        // 0x011ED780: LDR x22, [x21, #0x10]      | 
        // 0x011ED784: CBNZ x22, #0x11ed78c       | if ( != 0) goto label_1;                
        if(!=0)
        {
            goto label_1;
        }
        // 0x011ED788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2212, ????);     
        label_1:
        // 0x011ED78C: MOV x0, x22                | X0 = 57892864 (0x3736000);//ML01        
        // 0x011ED790: BL #0x11d2d14              | X0 = get_HasExportedTypes();            
        bool val_1 = HasExportedTypes;
        // 0x011ED794: TBZ w0, #0, #0x11ed8d0     | if (val_1 == false) goto label_6;       
        if(val_1 == false)
        {
            goto label_6;
        }
        // 0x011ED798: LDR x21, [x21, #0x10]      | 
        // 0x011ED79C: CBNZ x21, #0x11ed7a4       | if (this != null) goto label_3;         
        if(this != null)
        {
            goto label_3;
        }
        // 0x011ED7A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x011ED7A4: MOV x0, x21                | X0 = 1152921509552336096 (0x1000000126C62CE0);//ML01
        // 0x011ED7A8: BL #0x11d2d90              | X0 = this.get_ExportedTypes();          
        ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ExportedType> val_2 = this.ExportedTypes;
        // 0x011ED7AC: ADRP x25, #0x3662000       | X25 = 57024512 (0x3662000);             
        // 0x011ED7B0: ADRP x26, #0x362c000       | X26 = 56803328 (0x362C000);             
        // 0x011ED7B4: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
        // 0x011ED7B8: LDR x25, [x25, #0xbf8]     | X25 = 1152921509489228304;              
        // 0x011ED7BC: LDR x26, [x26, #0x60]      | X26 = 1152921509451695648;              
        // 0x011ED7C0: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
        // 0x011ED7C4: MOV x21, x0                | X21 = val_2;//m1                        
        val_9 = val_2;
        // 0x011ED7C8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_10 = 0;
        // 0x011ED7CC: B #0x11ed7d4               |  goto label_4;                          
        goto label_4;
        label_15:
        // 0x011ED7D0: ADD w22, w22, #1           | W22 = (val_10 + 1) = val_10 (0x00000001);
        val_10 = 1;
        label_4:
        // 0x011ED7D4: CBNZ x21, #0x11ed7dc       | if (val_2 != null) goto label_5;        
        if(val_9 != null)
        {
            goto label_5;
        }
        // 0x011ED7D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x011ED7DC: LDR x1, [x25]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ExportedType>::get_Count();
        // 0x011ED7E0: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x011ED7E4: BL #0x1d46b60              | X0 = val_2.get_Count();                 
        int val_3 = val_9.Count;
        // 0x011ED7E8: CMP w22, w0                | STATE = COMPARE(0x1, val_3)             
        // 0x011ED7EC: B.GE #0x11ed8d0            | if (val_10 >= val_3) goto label_6;      
        if(val_10 >= val_3)
        {
            goto label_6;
        }
        // 0x011ED7F0: CBNZ x21, #0x11ed7f8       | if (val_2 != null) goto label_7;        
        if(val_9 != null)
        {
            goto label_7;
        }
        // 0x011ED7F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x011ED7F8: LDR x2, [x26]              | X2 = public ILRuntime.Mono.Cecil.ExportedType ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.ExportedType>::get_Item(int index);
        // 0x011ED7FC: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x011ED800: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x011ED804: BL #0x1d46b68              | X0 = val_2.get_Item(index:  1);         
        ILRuntime.Mono.Cecil.ExportedType val_4 = val_9.Item[1];
        // 0x011ED808: MOV x23, x0                | X23 = val_4;//m1                        
        // 0x011ED80C: CBNZ x23, #0x11ed814       | if (val_4 != null) goto label_8;        
        if(val_4 != null)
        {
            goto label_8;
        }
        // 0x011ED810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x011ED814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ED818: MOV x0, x23                | X0 = val_4;//m1                         
        // 0x011ED81C: BL #0xe663c0               | X0 = val_4.get_Name();                  
        string val_5 = val_4.Name;
        // 0x011ED820: LDR x8, [x27]              | X8 = typeof(System.String);             
        // 0x011ED824: MOV x24, x0                | X24 = val_5;//m1                        
        // 0x011ED828: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x011ED82C: TBZ w9, #0, #0x11ed840     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x011ED830: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x011ED834: CBNZ w9, #0x11ed840        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x011ED838: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x011ED83C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x011ED840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x011ED844: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x011ED848: MOV x1, x24                | X1 = val_5;//m1                         
        // 0x011ED84C: MOV x2, x19                | X2 = name;//m1                          
        // 0x011ED850: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_5);
        bool val_6 = System.String.op_Equality(a:  0, b:  val_5);
        // 0x011ED854: TBZ w0, #0, #0x11ed7d0     | if (val_6 == false) goto label_15;      
        if(val_6 == false)
        {
            goto label_15;
        }
        // 0x011ED858: CBNZ x23, #0x11ed860       | if (val_4 != null) goto label_12;       
        if(val_4 != null)
        {
            goto label_12;
        }
        // 0x011ED85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x011ED860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ED864: MOV x0, x23                | X0 = val_4;//m1                         
        // 0x011ED868: BL #0xe663b8               | X0 = val_4.get_Namespace();             
        string val_7 = val_4.Namespace;
        // 0x011ED86C: LDR x8, [x27]              | X8 = typeof(System.String);             
        // 0x011ED870: MOV x24, x0                | X24 = val_7;//m1                        
        // 0x011ED874: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x011ED878: TBZ w9, #0, #0x11ed88c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x011ED87C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x011ED880: CBNZ w9, #0x11ed88c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x011ED884: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x011ED888: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_14:
        // 0x011ED88C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x011ED890: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x011ED894: MOV x1, x24                | X1 = val_7;//m1                         
        // 0x011ED898: MOV x2, x20                | X2 = namespace;//m1                     
        // 0x011ED89C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_7);
        bool val_8 = System.String.op_Equality(a:  0, b:  val_7);
        // 0x011ED8A0: TBZ w0, #0, #0x11ed7d0     | if (val_8 == false) goto label_15;      
        if(val_8 == false)
        {
            goto label_15;
        }
        // 0x011ED8A4: CBNZ x23, #0x11ed8ac       | if (val_4 != null) goto label_16;       
        if(val_4 != null)
        {
            goto label_16;
        }
        // 0x011ED8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_16:
        // 0x011ED8AC: MOV x0, x23                | X0 = val_4;//m1                         
        // 0x011ED8B0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED8B4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x011ED8B8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x011ED8BC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x011ED8C0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x011ED8C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x011ED8C8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x011ED8CC: B #0xe66598                | return val_4.CreateReference();         
        return val_4.CreateReference();
        label_6:
        // 0x011ED8D0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x011ED8D4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x011ED8D8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x011ED8DC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x011ED8E0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x011ED8E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x011ED8E8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x011ED8EC: RET                        |  return (ILRuntime.Mono.Cecil.TypeReference)null;
        return (ILRuntime.Mono.Cecil.TypeReference)0;
        //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.TypeReference, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x011ED8F0 (18798832), len: 4  VirtAddr: 0x011ED8F0 RVA: 0x011ED8F0 token: 100664465 methodIndex: 20622 delegateWrapperIndex: 0 methodInvoker: 0
    private static void Initialize(object obj)
    {
        //
        // Disasemble & Code
        // 0x011ED8F0: RET                        |  return;                                
        return;
    
    }

}
