using UnityEngine;
public class CaptureScreenshotMgr
{
    // Fields
    public string ScreenshotPath; //  0x00000010
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D81048 (14159944), len: 360  VirtAddr: 0x00D81048 RVA: 0x00D81048 token: 100693324 methodIndex: 25937 delegateWrapperIndex: 0 methodInvoker: 0
    public CaptureScreenshotMgr()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00D81048: STP x22, x21, [sp, #-0x30]! | stack[1152921514971624512] = ???;  stack[1152921514971624520] = ???;  //  dest_result_addr=1152921514971624512 |  dest_result_addr=1152921514971624520
        // 0x00D8104C: STP x20, x19, [sp, #0x10]  | stack[1152921514971624528] = ???;  stack[1152921514971624536] = ???;  //  dest_result_addr=1152921514971624528 |  dest_result_addr=1152921514971624536
        // 0x00D81050: STP x29, x30, [sp, #0x20]  | stack[1152921514971624544] = ???;  stack[1152921514971624552] = ???;  //  dest_result_addr=1152921514971624544 |  dest_result_addr=1152921514971624552
        // 0x00D81054: ADD x29, sp, #0x20         | X29 = (1152921514971624512 + 32) = 1152921514971624544 (0x1000000269C9F460);
        // 0x00D81058: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D8105C: LDRB w8, [x20, #0x41c]     | W8 = (bool)static_value_0373441C;       
        // 0x00D81060: MOV x19, x0                | X19 = 1152921514971636560 (0x1000000269CA2350);//ML01
        // 0x00D81064: TBNZ w8, #0, #0xd81080     | if (static_value_0373441C == true) goto label_0;
        // 0x00D81068: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00D8106C: LDR x8, [x8, #0x7d8]       | X8 = 0x2B90444;                         
        // 0x00D81070: LDR w0, [x8]               | W0 = 0x17D5;                            
        // 0x00D81074: BL #0x2782188              | X0 = sub_2782188( ?? 0x17D5, ????);     
        // 0x00D81078: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D8107C: STRB w8, [x20, #0x41c]     | static_value_0373441C = true;            //  dest_result_addr=57885724
        label_0:
        // 0x00D81080: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00D81084: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00D81088: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_5 = null;
        // 0x00D8108C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00D81090: TBZ w8, #0, #0xd810a4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D81094: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D81098: CBNZ w8, #0xd810a4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D8109C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00D810A0: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_5 = null;
        label_2:
        // 0x00D810A4: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00D810A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D810AC: MOV x0, x19                | X0 = 1152921514971636560 (0x1000000269CA2350);//ML01
        // 0x00D810B0: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00D810B4: STR x8, [x19, #0x10]       | this.ScreenshotPath = System.String.Empty;  //  dest_result_addr=1152921514971636576
        this.ScreenshotPath = System.String.Empty;
        // 0x00D810B8: BL #0x16f59f0              | this..ctor();                           
        // 0x00D810BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D810C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D810C4: BL #0x20c7454              | X0 = UnityEngine.Application.get_persistentDataPath();
        string val_1 = UnityEngine.Application.persistentDataPath;
        // 0x00D810C8: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D810CC: LDR x8, [x8, #0x658]       | X8 = (string**)(1152921514971607216)("/Pictures/Screenshots/");
        // 0x00D810D0: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00D810D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D810D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D810DC: LDR x2, [x8]               | X2 = "/Pictures/Screenshots/";          
        // 0x00D810E0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_1);
        string val_2 = System.String.Concat(str0:  0, str1:  val_1);
        // 0x00D810E4: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00D810E8: STR x21, [x19, #0x10]      | this.ScreenshotPath = val_2;             //  dest_result_addr=1152921514971636576
        this.ScreenshotPath = val_2;
        // 0x00D810EC: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00D810F0: LDR x8, [x8, #0x298]       | X8 = 1152921504620851200;               
        // 0x00D810F4: LDR x0, [x8]               | X0 = typeof(System.IO.DirectoryInfo);   
        System.IO.DirectoryInfo val_3 = null;
        // 0x00D810F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.DirectoryInfo), ????);
        // 0x00D810FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D81100: MOV x1, x21                | X1 = val_2;//m1                         
        // 0x00D81104: MOV x20, x0                | X20 = 1152921504620851200 (0x1000000000D5B000);//ML01
        // 0x00D81108: BL #0x1e6c2ac              | .ctor(path:  val_2);                    
        val_3 = new System.IO.DirectoryInfo(path:  val_2);
        // 0x00D8110C: CBNZ x20, #0xd81114        | if ( != 0) goto label_3;                
        if(null != 0)
        {
            goto label_3;
        }
        // 0x00D81110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(path:  val_2), ????);
        label_3:
        // 0x00D81114: LDR x8, [x20]              | X8 = ;                                  
        // 0x00D81118: MOV x0, x20                | X0 = 1152921504620851200 (0x1000000000D5B000);//ML01
        // 0x00D8111C: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
        // 0x00D81120: BLR x9                     | X0 = mem[null + 400]();                 
        // 0x00D81124: AND w8, w0, #1             | W8 = (val_3 & 1) = 0 (0x00000000);      
        // 0x00D81128: TBNZ w8, #0, #0xd81138     | if ((0x0 & 0x1) != 0) goto label_4;     
        if((0 & 1) != 0)
        {
            goto label_4;
        }
        // 0x00D8112C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81130: MOV x0, x20                | X0 = 1152921504620851200 (0x1000000000D5B000);//ML01
        // 0x00D81134: BL #0x1e698c4              | Create();                               
        Create();
        label_4:
        // 0x00D81138: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00D8113C: ADRP x9, #0x3658000        | X9 = 56983552 (0x3658000);              
        // 0x00D81140: LDR x8, [x8, #0x500]       | X8 = 1152921514971611424;               
        // 0x00D81144: LDR x9, [x9, #0x980]       | X9 = 1152921504898113536;               
        // 0x00D81148: LDR x21, [x8]              | X21 = public System.Void CaptureScreenshotMgr::OnCapture(CEvent.ZEvent ev);
        // 0x00D8114C: LDR x0, [x9]               | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00D81150: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D81154: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D81158: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00D8115C: MOV x1, x19                | X1 = 1152921514971636560 (0x1000000269CA2350);//ML01
        // 0x00D81160: MOV x2, x21                | X2 = 1152921514971611424 (0x1000000269C9C120);//ML01
        // 0x00D81164: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D81168: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D8116C: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CaptureScreenshotMgr::OnCapture(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CaptureScreenshotMgr::OnCapture(CEvent.ZEvent ev));
        // 0x00D81170: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D81174: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D81178: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D8117C: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D81180: TBZ w8, #0, #0xd81190      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D81184: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D81188: CBNZ w8, #0xd81190         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D8118C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_6:
        // 0x00D81190: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00D81194: LDR x8, [x8, #0xbb0]       | X8 = (string**)(1152921514971612448)("EV_CAPTURE_SCREENSHOT");
        // 0x00D81198: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D8119C: LDR x1, [x8]               | X1 = "EV_CAPTURE_SCREENSHOT";           
        // 0x00D811A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D811A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D811A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D811AC: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "EV_CAPTURE_SCREENSHOT"); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "EV_CAPTURE_SCREENSHOT");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D811B0 (14160304), len: 220  VirtAddr: 0x00D811B0 RVA: 0x00D811B0 token: 100693325 methodIndex: 25938 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnCapture(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        // 0x00D811B0: STP x20, x19, [sp, #-0x20]! | stack[1152921514971773472] = ???;  stack[1152921514971773480] = ???;  //  dest_result_addr=1152921514971773472 |  dest_result_addr=1152921514971773480
        // 0x00D811B4: STP x29, x30, [sp, #0x10]  | stack[1152921514971773488] = ???;  stack[1152921514971773496] = ???;  //  dest_result_addr=1152921514971773488 |  dest_result_addr=1152921514971773496
        // 0x00D811B8: ADD x29, sp, #0x10         | X29 = (1152921514971773472 + 16) = 1152921514971773488 (0x1000000269CC3A30);
        // 0x00D811BC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D811C0: LDRB w8, [x20, #0x41d]     | W8 = (bool)static_value_0373441D;       
        // 0x00D811C4: MOV x19, x0                | X19 = 1152921514971785504 (0x1000000269CC6920);//ML01
        // 0x00D811C8: TBNZ w8, #0, #0xd811e4     | if (static_value_0373441D == true) goto label_0;
        // 0x00D811CC: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D811D0: LDR x8, [x8, #0x368]       | X8 = 0x2B90450;                         
        // 0x00D811D4: LDR w0, [x8]               | W0 = 0x17D8;                            
        // 0x00D811D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x17D8, ????);     
        // 0x00D811DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D811E0: STRB w8, [x20, #0x41d]     | static_value_0373441D = true;            //  dest_result_addr=57885725
        label_0:
        // 0x00D811E4: BL #0xd8128c               | X0 = this.GetCurTime();                 
        string val_1 = this.GetCurTime();
        // 0x00D811E8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00D811EC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00D811F0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D811F4: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00D811F8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00D811FC: TBZ w9, #0, #0xd81210      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D81200: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D81204: CBNZ w9, #0xd81210         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D81208: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00D8120C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_2:
        // 0x00D81210: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00D81214: LDR x8, [x8, #0xbb8]       | X8 = (string**)(1152921514971740944)(".png");
        // 0x00D81218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8121C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D81220: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00D81224: LDR x2, [x8]               | X2 = ".png";                            
        // 0x00D81228: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_1);
        string val_2 = System.String.Concat(str0:  0, str1:  val_1);
        // 0x00D8122C: LDR x1, [x19, #0x10]       | X1 = this.ScreenshotPath; //P2          
        // 0x00D81230: MOV x2, x0                 | X2 = val_2;//m1                         
        // 0x00D81234: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D81238: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D8123C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  this.ScreenshotPath);
        string val_3 = System.String.Concat(str0:  0, str1:  this.ScreenshotPath);
        // 0x00D81240: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00D81244: MOV x0, x19                | X0 = 1152921514971785504 (0x1000000269CC6920);//ML01
        // 0x00D81248: BL #0xd81628               | X0 = this.CutImage(name:  val_3);       
        System.Collections.IEnumerator val_4 = this.CutImage(name:  val_3);
        // 0x00D8124C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D81250: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00D81254: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x00D81258: LDR x8, [x8]               | X8 = typeof(BehaviourUtil);             
        // 0x00D8125C: LDRB w9, [x8, #0x10a]      | W9 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00D81260: TBZ w9, #0, #0xd81274      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D81264: LDR w9, [x8, #0xbc]        | W9 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00D81268: CBNZ w9, #0xd81274         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D8126C: MOV x0, x8                 | X0 = 1152921504922660864 (0x1000000012D2F000);//ML01
        // 0x00D81270: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_4:
        // 0x00D81274: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D81278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8127C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D81280: MOV x1, x19                | X1 = val_4;//m1                         
        // 0x00D81284: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D81288: B #0xb8d914                | X0 = BehaviourUtil.StartCoroutine(routine:  0); return;
        UnityEngine.Coroutine val_5 = BehaviourUtil.StartCoroutine(routine:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D81628 (14161448), len: 140  VirtAddr: 0x00D81628 RVA: 0x00D81628 token: 100693326 methodIndex: 25939 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x287851C
    private System.Collections.IEnumerator CutImage(string name)
    {
        //
        // Disasemble & Code
        // 0x00D81628: STP x22, x21, [sp, #-0x30]! | stack[1152921514971918224] = ???;  stack[1152921514971918232] = ???;  //  dest_result_addr=1152921514971918224 |  dest_result_addr=1152921514971918232
        // 0x00D8162C: STP x20, x19, [sp, #0x10]  | stack[1152921514971918240] = ???;  stack[1152921514971918248] = ???;  //  dest_result_addr=1152921514971918240 |  dest_result_addr=1152921514971918248
        // 0x00D81630: STP x29, x30, [sp, #0x20]  | stack[1152921514971918256] = ???;  stack[1152921514971918264] = ???;  //  dest_result_addr=1152921514971918256 |  dest_result_addr=1152921514971918264
        // 0x00D81634: ADD x29, sp, #0x20         | X29 = (1152921514971918224 + 32) = 1152921514971918256 (0x1000000269CE6FB0);
        // 0x00D81638: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D8163C: LDRB w8, [x21, #0x41e]     | W8 = (bool)static_value_0373441E;       
        // 0x00D81640: MOV x20, x1                | X20 = name;//m1                         
        // 0x00D81644: MOV x19, x0                | X19 = 1152921514971930272 (0x1000000269CE9EA0);//ML01
        // 0x00D81648: TBNZ w8, #0, #0xd81664     | if (static_value_0373441E == true) goto label_0;
        // 0x00D8164C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00D81650: LDR x8, [x8, #0x610]       | X8 = 0x2B90448;                         
        // 0x00D81654: LDR w0, [x8]               | W0 = 0x17D6;                            
        // 0x00D81658: BL #0x2782188              | X0 = sub_2782188( ?? 0x17D6, ????);     
        // 0x00D8165C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D81660: STRB w8, [x21, #0x41e]     | static_value_0373441E = true;            //  dest_result_addr=57885726
        label_0:
        // 0x00D81664: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00D81668: LDR x8, [x8, #0x480]       | X8 = 1152921504904077312;               
        // 0x00D8166C: LDR x0, [x8]               | X0 = typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0);
        object val_1 = null;
        // 0x00D81670: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0), ????);
        // 0x00D81674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81678: MOV x21, x0                | X21 = 1152921504904077312 (0x1000000011B76000);//ML01
        // 0x00D8167C: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D81680: CBZ x21, #0xd8168c         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00D81684: STR x20, [x21, #0x20]      | typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0).__il2cppRuntimeField_20 = name;  //  dest_result_addr=1152921504904077344
        typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0).__il2cppRuntimeField_20 = name;
        // 0x00D81688: B #0xd8169c                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00D8168C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00D81690: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00D81694: STR x20, [x8]              | mem[32] = name;                          //  dest_result_addr=32
        mem[32] = name;
        // 0x00D81698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00D8169C: STR x19, [x21, #0x28]      | typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0).__il2cppRuntimeField_28 = this;  //  dest_result_addr=1152921504904077352
        typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0).__il2cppRuntimeField_28 = this;
        // 0x00D816A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D816A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D816A8: MOV x0, x21                | X0 = 1152921504904077312 (0x1000000011B76000);//ML01
        // 0x00D816AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D816B0: RET                        |  return (System.Collections.IEnumerator)typeof(CaptureScreenshotMgr.<CutImage>c__Iterator0);
        return (System.Collections.IEnumerator)val_1;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D8128C (14160524), len: 924  VirtAddr: 0x00D8128C RVA: 0x00D8128C token: 100693327 methodIndex: 25940 delegateWrapperIndex: 0 methodInvoker: 0
    public string GetCurTime()
    {
        //
        // Disasemble & Code
        // 0x00D8128C: STP x20, x19, [sp, #-0x20]! | stack[1152921514972038432] = ???;  stack[1152921514972038440] = ???;  //  dest_result_addr=1152921514972038432 |  dest_result_addr=1152921514972038440
        // 0x00D81290: STP x29, x30, [sp, #0x10]  | stack[1152921514972038448] = ???;  stack[1152921514972038456] = ???;  //  dest_result_addr=1152921514972038448 |  dest_result_addr=1152921514972038456
        // 0x00D81294: ADD x29, sp, #0x10         | X29 = (1152921514972038432 + 16) = 1152921514972038448 (0x1000000269D04530);
        // 0x00D81298: SUB sp, sp, #0x90          | SP = (1152921514972038432 - 144) = 1152921514972038288 (0x1000000269D04490);
        // 0x00D8129C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
        // 0x00D812A0: LDRB w8, [x19, #0x41f]     | W8 = (bool)static_value_0373441F;       
        // 0x00D812A4: SUB x20, x29, #0x20        | X20 = (1152921514972038448 - 32) = 1152921514972038416 (0x1000000269D04510);
        // 0x00D812A8: TBNZ w8, #0, #0xd812c4     | if (static_value_0373441F == true) goto label_0;
        // 0x00D812AC: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00D812B0: LDR x8, [x8, #0x4f0]       | X8 = 0x2B9044C;                         
        // 0x00D812B4: LDR w0, [x8]               | W0 = 0x17D7;                            
        // 0x00D812B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x17D7, ????);     
        // 0x00D812BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D812C0: STRB w8, [x19, #0x41f]     | static_value_0373441F = true;            //  dest_result_addr=57885727
        label_0:
        // 0x00D812C4: STR xzr, [x20, #8]         | stack[1152921514972038424] = 0x0;        //  dest_result_addr=1152921514972038424
        // 0x00D812C8: STUR xzr, [x29, #-0x20]    | stack[1152921514972038416] = 0x0;        //  dest_result_addr=1152921514972038416
        // 0x00D812CC: STUR wzr, [x29, #-0x24]    | stack[1152921514972038412] = 0x0;        //  dest_result_addr=1152921514972038412
        // 0x00D812D0: STP xzr, xzr, [x29, #-0x38] | stack[1152921514972038392] = 0x0;  stack[1152921514972038400] = 0x0;  //  dest_result_addr=1152921514972038392 |  dest_result_addr=1152921514972038400
        // 0x00D812D4: STUR wzr, [x29, #-0x3c]    | stack[1152921514972038388] = 0x0;        //  dest_result_addr=1152921514972038388
        // 0x00D812D8: STP xzr, xzr, [sp, #0x50]  | stack[1152921514972038368] = 0x0;  stack[1152921514972038376] = 0x0;  //  dest_result_addr=1152921514972038368 |  dest_result_addr=1152921514972038376
        // 0x00D812DC: STR wzr, [sp, #0x4c]       | stack[1152921514972038364] = 0x0;        //  dest_result_addr=1152921514972038364
        // 0x00D812E0: STP xzr, xzr, [sp, #0x38]  | stack[1152921514972038344] = 0x0;  stack[1152921514972038352] = 0x0;  //  dest_result_addr=1152921514972038344 |  dest_result_addr=1152921514972038352
        // 0x00D812E4: STR wzr, [sp, #0x34]       | stack[1152921514972038340] = 0x0;        //  dest_result_addr=1152921514972038340
        // 0x00D812E8: STP xzr, xzr, [sp, #0x20]  | stack[1152921514972038320] = 0x0;  stack[1152921514972038328] = 0x0;  //  dest_result_addr=1152921514972038320 |  dest_result_addr=1152921514972038328
        // 0x00D812EC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00D812F0: STR wzr, [sp, #0x1c]       | stack[1152921514972038316] = 0x0;        //  dest_result_addr=1152921514972038316
        // 0x00D812F4: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00D812F8: LDR x19, [x8]              | X19 = typeof(System.String[]);          
        // 0x00D812FC: STP xzr, xzr, [sp, #8]     | stack[1152921514972038296] = 0x0;  stack[1152921514972038304] = 0x0;  //  dest_result_addr=1152921514972038296 |  dest_result_addr=1152921514972038304
        // 0x00D81300: STR wzr, [sp, #4]          | stack[1152921514972038292] = 0x0;        //  dest_result_addr=1152921514972038292
        // 0x00D81304: MOV x0, x19                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D81308: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00D8130C: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00D81310: MOV x0, x19                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D81314: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00D81318: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00D8131C: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00D81320: MOV x19, x0                | X19 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D81324: LDR x8, [x8]               | X8 = typeof(System.DateTime);           
        // 0x00D81328: LDRB w9, [x8, #0x10a]      | W9 = System.DateTime.__il2cppRuntimeField_10A;
        // 0x00D8132C: TBZ w9, #0, #0xd81340      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D81330: LDR w9, [x8, #0xbc]        | W9 = System.DateTime.__il2cppRuntimeField_cctor_finished;
        // 0x00D81334: CBNZ w9, #0xd81340         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D81338: MOV x0, x8                 | X0 = 1152921504652693504 (0x1000000002BB9000);//ML01
        // 0x00D8133C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
        label_2:
        // 0x00D81340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D81344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81348: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_1 = System.DateTime.Now;
        // 0x00D8134C: STUR x0, [x29, #-0x20]     | stack[1152921514972038416] = val_1.ticks._ticks;  //  dest_result_addr=1152921514972038416
        // 0x00D81350: STR x1, [x20, #8]          | stack[1152921514972038424] = val_1.kind;  //  dest_result_addr=1152921514972038424
        // 0x00D81354: SUB x0, x29, #0x20         | X0 = (1152921514972038448 - 32) = 1152921514972038416 (0x1000000269D04510);
        // 0x00D81358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8135C: BL #0x1bac62c              | X0 = sub_1BAC62C( ?? 0x1000000269D04510, ????);
        // 0x00D81360: STUR w0, [x29, #-0x24]     | stack[1152921514972038412] = val_1.ticks._ticks;  //  dest_result_addr=1152921514972038412
        // 0x00D81364: SUB x0, x29, #0x24         | X0 = (1152921514972038448 - 36) = 1152921514972038412 (0x1000000269D0450C);
        // 0x00D81368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8136C: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00D81370: MOV x20, x0                | X20 = 1152921514972038412 (0x1000000269D0450C);//ML01
        // 0x00D81374: CBNZ x19, #0xd8137c        | if ( != null) goto label_3;             
        if(null != null)
        {
            goto label_3;
        }
        // 0x00D81378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000269D0450C, ????);
        label_3:
        // 0x00D8137C: CBZ x20, #0xd813a0         | if (val_1.ticks._ticks == 0) goto label_5;
        if(val_1.ticks._ticks == 0)
        {
            goto label_5;
        }
        // 0x00D81380: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D81384: MOV x0, x20                | X0 = 1152921514972038412 (0x1000000269D0450C);//ML01
        // 0x00D81388: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D8138C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000269D0450C, ????);
        // 0x00D81390: CBNZ x0, #0xd813a0         | if (val_1.ticks._ticks != 0) goto label_5;
        if(val_1.ticks._ticks != 0)
        {
            goto label_5;
        }
        // 0x00D81394: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000269D0450C, ????);
        // 0x00D81398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8139C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D0450C, ????);
        label_5:
        // 0x00D813A0: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D813A4: CBNZ w8, #0xd813b4         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_6;
        // 0x00D813A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000269D0450C, ????);
        // 0x00D813AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D813B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D0450C, ????);
        label_6:
        // 0x00D813B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D813B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D813BC: STR x20, [x19, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = 0x1000000269D0450C;  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = ;
        // 0x00D813C0: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_2 = System.DateTime.Now;
        // 0x00D813C4: STP x0, x1, [x29, #-0x38]  | stack[1152921514972038392] = val_2.ticks._ticks;  stack[1152921514972038400] = val_2.kind;  //  dest_result_addr=1152921514972038392 |  dest_result_addr=1152921514972038400
        // 0x00D813C8: SUB x0, x29, #0x38         | X0 = (1152921514972038448 - 56) = 1152921514972038392 (0x1000000269D044F8);
        // 0x00D813CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D813D0: BL #0x1baf944              | X0 = val_2.ticks._ticks.get_Month();    
        int val_3 = val_2.ticks._ticks.Month;
        // 0x00D813D4: STUR w0, [x29, #-0x3c]     | stack[1152921514972038388] = val_3;      //  dest_result_addr=1152921514972038388
        // 0x00D813D8: SUB x0, x29, #0x3c         | X0 = (1152921514972038448 - 60) = 1152921514972038388 (0x1000000269D044F4);
        // 0x00D813DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D813E0: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00D813E4: MOV x20, x0                | X20 = 1152921514972038388 (0x1000000269D044F4);//ML01
        // 0x00D813E8: CBZ x20, #0xd8140c         | if (val_3 == 0) goto label_8;           
        if(val_3 == 0)
        {
            goto label_8;
        }
        // 0x00D813EC: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D813F0: MOV x0, x20                | X0 = 1152921514972038388 (0x1000000269D044F4);//ML01
        // 0x00D813F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D813F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000269D044F4, ????);
        // 0x00D813FC: CBNZ x0, #0xd8140c         | if (val_3 != 0) goto label_8;           
        if(val_3 != 0)
        {
            goto label_8;
        }
        // 0x00D81400: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000269D044F4, ????);
        // 0x00D81404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81408: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044F4, ????);
        label_8:
        // 0x00D8140C: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D81410: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00D81414: B.HI #0xd81424             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_9;
        // 0x00D81418: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000269D044F4, ????);
        // 0x00D8141C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81420: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044F4, ????);
        label_9:
        // 0x00D81424: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D81428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8142C: STR x20, [x19, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = 0x1000000269D044F4;  //  dest_result_addr=1152921504948897208
        typeof(System.String[]).__il2cppRuntimeField_28 = ;
        // 0x00D81430: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_4 = System.DateTime.Now;
        // 0x00D81434: STP x0, x1, [sp, #0x50]    | stack[1152921514972038368] = val_4.ticks._ticks;  stack[1152921514972038376] = val_4.kind;  //  dest_result_addr=1152921514972038368 |  dest_result_addr=1152921514972038376
        // 0x00D81438: ADD x0, sp, #0x50          | X0 = (1152921514972038288 + 80) = 1152921514972038368 (0x1000000269D044E0);
        // 0x00D8143C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81440: BL #0x1baf94c              | X0 = label_System_DateTime_FromTicks_GL01BAF94C();
        // 0x00D81444: STR w0, [sp, #0x4c]        | stack[1152921514972038364] = val_4.ticks._ticks;  //  dest_result_addr=1152921514972038364
        // 0x00D81448: ADD x0, sp, #0x4c          | X0 = (1152921514972038288 + 76) = 1152921514972038364 (0x1000000269D044DC);
        // 0x00D8144C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81450: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00D81454: MOV x20, x0                | X20 = 1152921514972038364 (0x1000000269D044DC);//ML01
        // 0x00D81458: CBZ x20, #0xd8147c         | if (val_4.ticks._ticks == 0) goto label_11;
        if(val_4.ticks._ticks == 0)
        {
            goto label_11;
        }
        // 0x00D8145C: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D81460: MOV x0, x20                | X0 = 1152921514972038364 (0x1000000269D044DC);//ML01
        // 0x00D81464: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D81468: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000269D044DC, ????);
        // 0x00D8146C: CBNZ x0, #0xd8147c         | if (val_4.ticks._ticks != 0) goto label_11;
        if(val_4.ticks._ticks != 0)
        {
            goto label_11;
        }
        // 0x00D81470: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000269D044DC, ????);
        // 0x00D81474: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81478: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044DC, ????);
        label_11:
        // 0x00D8147C: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D81480: CMP w8, #2                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00D81484: B.HI #0xd81494             | if (System.String[].__il2cppRuntimeField_namespaze > 0x2) goto label_12;
        // 0x00D81488: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000269D044DC, ????);
        // 0x00D8148C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81490: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044DC, ????);
        label_12:
        // 0x00D81494: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D81498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8149C: STR x20, [x19, #0x30]      | typeof(System.String[]).__il2cppRuntimeField_30 = 0x1000000269D044DC;  //  dest_result_addr=1152921504948897216
        typeof(System.String[]).__il2cppRuntimeField_30 = ;
        // 0x00D814A0: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_5 = System.DateTime.Now;
        // 0x00D814A4: STP x0, x1, [sp, #0x38]    | stack[1152921514972038344] = val_5.ticks._ticks;  stack[1152921514972038352] = val_5.kind;  //  dest_result_addr=1152921514972038344 |  dest_result_addr=1152921514972038352
        // 0x00D814A8: ADD x0, sp, #0x38          | X0 = (1152921514972038288 + 56) = 1152921514972038344 (0x1000000269D044C8);
        // 0x00D814AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D814B0: BL #0x1bafae8              | X0 = label_System_DateTime_get_TimeOfDay_GL01BAFAE8();
        // 0x00D814B4: STR w0, [sp, #0x34]        | stack[1152921514972038340] = val_5.ticks._ticks;  //  dest_result_addr=1152921514972038340
        // 0x00D814B8: ADD x0, sp, #0x34          | X0 = (1152921514972038288 + 52) = 1152921514972038340 (0x1000000269D044C4);
        // 0x00D814BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D814C0: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00D814C4: MOV x20, x0                | X20 = 1152921514972038340 (0x1000000269D044C4);//ML01
        // 0x00D814C8: CBZ x20, #0xd814ec         | if (val_5.ticks._ticks == 0) goto label_14;
        if(val_5.ticks._ticks == 0)
        {
            goto label_14;
        }
        // 0x00D814CC: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D814D0: MOV x0, x20                | X0 = 1152921514972038340 (0x1000000269D044C4);//ML01
        // 0x00D814D4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D814D8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000269D044C4, ????);
        // 0x00D814DC: CBNZ x0, #0xd814ec         | if (val_5.ticks._ticks != 0) goto label_14;
        if(val_5.ticks._ticks != 0)
        {
            goto label_14;
        }
        // 0x00D814E0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000269D044C4, ????);
        // 0x00D814E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D814E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044C4, ????);
        label_14:
        // 0x00D814EC: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D814F0: CMP w8, #3                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00D814F4: B.HI #0xd81504             | if (System.String[].__il2cppRuntimeField_namespaze > 0x3) goto label_15;
        // 0x00D814F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000269D044C4, ????);
        // 0x00D814FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81500: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044C4, ????);
        label_15:
        // 0x00D81504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D81508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8150C: STR x20, [x19, #0x38]      | typeof(System.String[]).__il2cppRuntimeField_38 = 0x1000000269D044C4;  //  dest_result_addr=1152921504948897224
        typeof(System.String[]).__il2cppRuntimeField_38 = ;
        // 0x00D81510: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_6 = System.DateTime.Now;
        // 0x00D81514: STP x0, x1, [sp, #0x20]    | stack[1152921514972038320] = val_6.ticks._ticks;  stack[1152921514972038328] = val_6.kind;  //  dest_result_addr=1152921514972038320 |  dest_result_addr=1152921514972038328
        // 0x00D81518: ADD x0, sp, #0x20          | X0 = (1152921514972038288 + 32) = 1152921514972038320 (0x1000000269D044B0);
        // 0x00D8151C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81520: BL #0x1bafafc              | X0 = label_System_DateTime_get_Hour_GL01BAFAFC();
        // 0x00D81524: STR w0, [sp, #0x1c]        | stack[1152921514972038316] = val_6.ticks._ticks;  //  dest_result_addr=1152921514972038316
        // 0x00D81528: ADD x0, sp, #0x1c          | X0 = (1152921514972038288 + 28) = 1152921514972038316 (0x1000000269D044AC);
        // 0x00D8152C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81530: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00D81534: MOV x20, x0                | X20 = 1152921514972038316 (0x1000000269D044AC);//ML01
        // 0x00D81538: CBZ x20, #0xd8155c         | if (val_6.ticks._ticks == 0) goto label_17;
        if(val_6.ticks._ticks == 0)
        {
            goto label_17;
        }
        // 0x00D8153C: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D81540: MOV x0, x20                | X0 = 1152921514972038316 (0x1000000269D044AC);//ML01
        // 0x00D81544: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D81548: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000269D044AC, ????);
        // 0x00D8154C: CBNZ x0, #0xd8155c         | if (val_6.ticks._ticks != 0) goto label_17;
        if(val_6.ticks._ticks != 0)
        {
            goto label_17;
        }
        // 0x00D81550: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000269D044AC, ????);
        // 0x00D81554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81558: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044AC, ????);
        label_17:
        // 0x00D8155C: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D81560: CMP w8, #4                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00D81564: B.HI #0xd81574             | if (System.String[].__il2cppRuntimeField_namespaze > 0x4) goto label_18;
        // 0x00D81568: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000269D044AC, ????);
        // 0x00D8156C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81570: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D044AC, ????);
        label_18:
        // 0x00D81574: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D81578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8157C: STR x20, [x19, #0x40]      | typeof(System.String[]).__il2cppRuntimeField_40 = 0x1000000269D044AC;  //  dest_result_addr=1152921504948897232
        typeof(System.String[]).__il2cppRuntimeField_40 = ;
        // 0x00D81580: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_7 = System.DateTime.Now;
        // 0x00D81584: STP x0, x1, [sp, #8]       | stack[1152921514972038296] = val_7.ticks._ticks;  stack[1152921514972038304] = val_7.kind;  //  dest_result_addr=1152921514972038296 |  dest_result_addr=1152921514972038304
        // 0x00D81588: ADD x0, sp, #8             | X0 = (1152921514972038288 + 8) = 1152921514972038296 (0x1000000269D04498);
        // 0x00D8158C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81590: BL #0x1bafb10              | X0 = label_System_DateTime_get_Minute_GL01BAFB10();
        // 0x00D81594: STR w0, [sp, #4]           | stack[1152921514972038292] = val_7.ticks._ticks;  //  dest_result_addr=1152921514972038292
        // 0x00D81598: ADD x0, sp, #4             | X0 = (1152921514972038288 + 4) = 1152921514972038292 (0x1000000269D04494);
        // 0x00D8159C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D815A0: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
        // 0x00D815A4: MOV x20, x0                | X20 = 1152921514972038292 (0x1000000269D04494);//ML01
        // 0x00D815A8: CBZ x20, #0xd815cc         | if (val_7.ticks._ticks == 0) goto label_20;
        if(val_7.ticks._ticks == 0)
        {
            goto label_20;
        }
        // 0x00D815AC: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D815B0: MOV x0, x20                | X0 = 1152921514972038292 (0x1000000269D04494);//ML01
        // 0x00D815B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D815B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x1000000269D04494, ????);
        // 0x00D815BC: CBNZ x0, #0xd815cc         | if (val_7.ticks._ticks != 0) goto label_20;
        if(val_7.ticks._ticks != 0)
        {
            goto label_20;
        }
        // 0x00D815C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x1000000269D04494, ????);
        // 0x00D815C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D815C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D04494, ????);
        label_20:
        // 0x00D815CC: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D815D0: CMP w8, #5                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00D815D4: B.HI #0xd815e4             | if (System.String[].__il2cppRuntimeField_namespaze > 0x5) goto label_21;
        // 0x00D815D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000269D04494, ????);
        // 0x00D815DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D815E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000269D04494, ????);
        label_21:
        // 0x00D815E4: STR x20, [x19, #0x48]      | typeof(System.String[]).__il2cppRuntimeField_48 = 0x1000000269D04494;  //  dest_result_addr=1152921504948897240
        typeof(System.String[]).__il2cppRuntimeField_48 = ;
        // 0x00D815E8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00D815EC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00D815F0: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00D815F4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00D815F8: TBZ w8, #0, #0xd81608      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x00D815FC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D81600: CBNZ w8, #0xd81608         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x00D81604: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_23:
        // 0x00D81608: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D8160C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D81610: MOV x1, x19                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D81614: BL #0x18b0b80              | X0 = System.String.Concat(values:  0);  
        string val_8 = System.String.Concat(values:  0);
        // 0x00D81618: SUB sp, x29, #0x10         | SP = (1152921514972038448 - 16) = 1152921514972038432 (0x1000000269D04520);
        // 0x00D8161C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D81620: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D81624: RET                        |  return (System.String)val_8;           
        return val_8;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D816BC (14161596), len: 1032  VirtAddr: 0x00D816BC RVA: 0x00D816BC token: 100693328 methodIndex: 25941 delegateWrapperIndex: 0 methodInvoker: 0
    public void ScanFile(string path)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        //  | 
        var val_20;
        // 0x00D816BC: STP x26, x25, [sp, #-0x50]! | stack[1152921514972162912] = ???;  stack[1152921514972162920] = ???;  //  dest_result_addr=1152921514972162912 |  dest_result_addr=1152921514972162920
        // 0x00D816C0: STP x24, x23, [sp, #0x10]  | stack[1152921514972162928] = ???;  stack[1152921514972162936] = ???;  //  dest_result_addr=1152921514972162928 |  dest_result_addr=1152921514972162936
        // 0x00D816C4: STP x22, x21, [sp, #0x20]  | stack[1152921514972162944] = ???;  stack[1152921514972162952] = ???;  //  dest_result_addr=1152921514972162944 |  dest_result_addr=1152921514972162952
        // 0x00D816C8: STP x20, x19, [sp, #0x30]  | stack[1152921514972162960] = ???;  stack[1152921514972162968] = ???;  //  dest_result_addr=1152921514972162960 |  dest_result_addr=1152921514972162968
        // 0x00D816CC: STP x29, x30, [sp, #0x40]  | stack[1152921514972162976] = ???;  stack[1152921514972162984] = ???;  //  dest_result_addr=1152921514972162976 |  dest_result_addr=1152921514972162984
        // 0x00D816D0: ADD x29, sp, #0x40         | X29 = (1152921514972162912 + 64) = 1152921514972162976 (0x1000000269D22BA0);
        // 0x00D816D4: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
        // 0x00D816D8: LDRB w8, [x19, #0x420]     | W8 = (bool)static_value_03734420;       
        // 0x00D816DC: MOV x22, x1                | X22 = path;//m1                         
        // 0x00D816E0: TBNZ w8, #0, #0xd816fc     | if (static_value_03734420 == true) goto label_0;
        // 0x00D816E4: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D816E8: LDR x8, [x8, #0x528]       | X8 = 0x2B90454;                         
        // 0x00D816EC: LDR w0, [x8]               | W0 = 0x17D9;                            
        // 0x00D816F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x17D9, ????);     
        // 0x00D816F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D816F8: STRB w8, [x19, #0x420]     | static_value_03734420 = true;            //  dest_result_addr=57885728
        label_0:
        // 0x00D816FC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00D81700: LDR x8, [x8, #0xa30]       | X8 = 1152921504690233344;               
        // 0x00D81704: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00D81708: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00D8170C: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00D81710: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921514474312160)("com.unity3d.player.UnityPlayer");
        // 0x00D81714: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D81718: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_14 = val_1;
        // 0x00D8171C: LDR x1, [x8]               | X1 = "com.unity3d.player.UnityPlayer";  
        // 0x00D81720: BL #0x20b9834              | .ctor(className:  "com.unity3d.player.UnityPlayer");
        val_1 = new UnityEngine.AndroidJavaClass(className:  "com.unity3d.player.UnityPlayer");
        // 0x00D81724: CBNZ x19, #0xd81730        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00D81728: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D8172C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "com.unity3d.player.UnityPlayer"), ????);
        label_1:
        // 0x00D81730: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D81734: LDR x8, [x8, #0xb8]        | X8 = (string**)(1152921514474312288)("currentActivity");
        // 0x00D81738: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
        // 0x00D8173C: LDR x9, [x9, #0x458]       | X9 = 1152921514474312400;               
        // 0x00D81740: LDR x1, [x8]               | X1 = "currentActivity";                 
        // 0x00D81744: LDR x2, [x9]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00D81748: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00D8174C: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D81750: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  "currentActivity");
        // 0x00D81754: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00D81758: ADRP x24, #0x3630000       | X24 = 56819712 (0x3630000);             
        // 0x00D8175C: LDR x24, [x24, #0x3d0]     | X24 = 1152921504954501264;              
        // 0x00D81760: LDR x20, [x24]             | X20 = typeof(System.Object[]);          
        // 0x00D81764: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81768: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D8176C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D81770: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D81774: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81778: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D8177C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D81780: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81784: CBNZ x23, #0xd81790        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00D81788: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D8178C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_2:
        // 0x00D81790: CBZ x21, #0xd817c0         | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00D81794: LDR x8, [x23]              | X8 = ;                                  
        // 0x00D81798: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D8179C: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00D817A0: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D817A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00D817A8: CBNZ x0, #0xd817c0         | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00D817AC: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D817B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00D817B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D817B8: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D817BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_4:
        // 0x00D817C0: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D817C4: CBNZ w8, #0xd817dc         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00D817C8: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D817CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00D817D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D817D4: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D817D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_5:
        // 0x00D817DC: STR x21, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00D817E0: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
        // 0x00D817E4: LDR x8, [x8, #0xff0]       | X8 = 1152921504690180096;               
        // 0x00D817E8: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00D817EC: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D817F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaObject), ????);
        // 0x00D817F4: MOV x20, x0                | X20 = 1152921504690180096 (0x1000000004F79000);//ML01
        // 0x00D817F8: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00D817FC: LDR x8, [x8, #0xfd0]       | X8 = (string**)(1152921514972150752)("android.media.MediaScannerConnection");
        // 0x00D81800: LDR x1, [x8]               | X1 = "android.media.MediaScannerConnection";
        // 0x00D81804: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D81808: MOV x0, x20                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
        UnityEngine.AndroidJavaObject val_3 = null;
        // 0x00D8180C: MOV x2, x23                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81810: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        // 0x00D81814: BL #0x20bad84              | .ctor(className:  "android.media.MediaScannerConnection", args:  null);
        val_3 = new UnityEngine.AndroidJavaObject(className:  "android.media.MediaScannerConnection", args:  null);
        // 0x00D81818: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00D8181C: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
        // 0x00D81820: LDR x23, [x8]              | X23 = typeof(System.String[]);          
        // 0x00D81824: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D81828: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
        // 0x00D8182C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D81830: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D81834: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
        // 0x00D81838: MOV x23, x0                | X23 = 1152921504948897168 (0x1000000014634590);//ML01
        val_15 = null;
        // 0x00D8183C: CBNZ x23, #0xd81844        | if ( != null) goto label_6;             
        if(null != null)
        {
            goto label_6;
        }
        // 0x00D81840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_6:
        // 0x00D81844: CBZ x22, #0xd81868         | if (path == null) goto label_8;         
        if(path == null)
        {
            goto label_8;
        }
        // 0x00D81848: LDR x8, [x23]              | X8 = ;                                  
        // 0x00D8184C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D81850: MOV x0, x22                | X0 = path;//m1                          
        // 0x00D81854: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? path, ????);       
        // 0x00D81858: CBNZ x0, #0xd81868         | if (path != null) goto label_8;         
        if(path != null)
        {
            goto label_8;
        }
        // 0x00D8185C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? path, ????);       
        // 0x00D81860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81864: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? path, ????);       
        label_8:
        // 0x00D81868: LDR w8, [x23, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
        // 0x00D8186C: CBNZ w8, #0xd8187c         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_9;
        // 0x00D81870: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? path, ????);       
        // 0x00D81874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81878: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? path, ????);       
        label_9:
        // 0x00D8187C: STR x22, [x23, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = path;  //  dest_result_addr=1152921504948897200
        typeof(System.String[]).__il2cppRuntimeField_20 = path;
        // 0x00D81880: LDR x22, [x24]             | X22 = typeof(System.Object[]);          
        // 0x00D81884: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81888: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D8188C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00D81890: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81894: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D81898: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D8189C: CBNZ x22, #0xd818a4        | if ( != null) goto label_10;            
        if(null != null)
        {
            goto label_10;
        }
        // 0x00D818A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_10:
        // 0x00D818A4: CBZ x21, #0xd818c8         | if (val_2 == null) goto label_12;       
        if(val_2 == null)
        {
            goto label_12;
        }
        // 0x00D818A8: LDR x8, [x22]              | X8 = ;                                  
        // 0x00D818AC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D818B0: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00D818B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00D818B8: CBNZ x0, #0xd818c8         | if (val_2 != null) goto label_12;       
        if(val_2 != null)
        {
            goto label_12;
        }
        // 0x00D818BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
        // 0x00D818C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D818C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_12:
        // 0x00D818C8: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D818CC: CBNZ w8, #0xd818dc         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_13;
        // 0x00D818D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00D818D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D818D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_13:
        // 0x00D818DC: STR x21, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
        // 0x00D818E0: CBZ x23, #0xd81904         | if ( == null) goto label_15;            
        if(null == null)
        {
            goto label_15;
        }
        // 0x00D818E4: LDR x8, [x22]              | X8 = ;                                  
        // 0x00D818E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D818EC: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
        // 0x00D818F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.String[]), ????);
        // 0x00D818F4: CBNZ x0, #0xd81904         | if ( != null) goto label_15;            
        if(null != null)
        {
            goto label_15;
        }
        // 0x00D818F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(System.String[]), ????);
        // 0x00D818FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81900: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.String[]), ????);
        label_15:
        // 0x00D81904: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D81908: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00D8190C: B.HI #0xd8191c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_16;
        // 0x00D81910: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.String[]), ????);
        // 0x00D81914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81918: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.String[]), ????);
        label_16:
        // 0x00D8191C: STR x23, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = typeof(System.String[]);  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_15;
        // 0x00D81920: CBNZ x20, #0xd81928        | if ( != 0) goto label_17;               
        if(null != 0)
        {
            goto label_17;
        }
        // 0x00D81924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
        label_17:
        // 0x00D81928: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x00D8192C: LDR x8, [x8, #0xae8]       | X8 = (string**)(1152921514972150896)("scanFile");
        // 0x00D81930: LDR x1, [x8]               | X1 = "scanFile";                        
        // 0x00D81934: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D81938: MOV x0, x20                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
        // 0x00D8193C: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D81940: BL #0x20bdcfc              | CallStatic(methodName:  "scanFile", args:  null);
        CallStatic(methodName:  "scanFile", args:  null);
        // 0x00D81944: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_16 = 0;
        // 0x00D81948: MOVZ w25, #0x62            | W25 = 98 (0x62);//ML01                  
        val_17 = 98;
        label_33:
        // 0x00D8194C: CBZ x20, #0xd819b8         | if ( == 0) goto label_18;               
        if(null == 0)
        {
            goto label_18;
        }
        // 0x00D81950: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00D81954: LDR x8, [x20]              | X8 = ;                                  
        UnityEngine.AndroidJavaObject val_16 = null;
        // 0x00D81958: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00D8195C: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00D81960: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00D81964: CBZ x9, #0xd81990          | if (mem[null + 258] == 0) goto label_19;
        if((mem[null + 258]) == 0)
        {
            goto label_19;
        }
        // 0x00D81968: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_14 = mem[null + 152];
        // 0x00D8196C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_15 = 0;
        // 0x00D81970: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_14 = val_14 + 8;
        label_21:
        // 0x00D81974: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00D81978: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00D8197C: B.EQ #0xd819a0             | if ((mem[null + 152] + 8) + -8 == null) goto label_20;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_20;
        }
        // 0x00D81980: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_15 = val_15 + 1;
        // 0x00D81984: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_14 = val_14 + 16;
        // 0x00D81988: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00D8198C: B.LO #0xd81974             | if (0 < mem[null + 258]) goto label_21; 
        if(val_15 < (mem[null + 258]))
        {
            goto label_21;
        }
        label_19:
        // 0x00D81990: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00D81994: MOV x0, x20                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
        val_18 = null;
        // 0x00D81998: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaObject), ????);
        // 0x00D8199C: B #0xd819ac                |  goto label_22;                         
        goto label_22;
        label_20:
        // 0x00D819A0: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00D819A4: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_16 = val_16 + (((mem[null + 152] + 8)) << 4);
        // 0x00D819A8: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_22:
        // 0x00D819AC: LDP x8, x1, [x0]           | X8 = ; X1 = UnityEngine.AndroidJavaObject.__il2cppRuntimeField_gc_desc; //  | 
        // 0x00D819B0: MOV x0, x20                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
        // 0x00D819B4: BLR x8                     | X0 = x8();                              
        label_18:
        // 0x00D819B8: MOVZ w20, #0x74            | W20 = 116 (0x74);//ML01                 
        val_19 = 116;
        // 0x00D819BC: CMP w25, #0x62             | STATE = COMPARE(0x62, 0x62)             
        // 0x00D819C0: B.EQ #0xd819dc             | if (0x62 == 0x62) goto label_35;        
        if(98 == 98)
        {
            goto label_35;
        }
        // 0x00D819C4: CBZ x21, #0xd819dc         | if (0x0 == 0) goto label_35;            
        if(val_16 == 0)
        {
            goto label_35;
        }
        // 0x00D819C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D819CC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00D819D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00D819D4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_16 = 0;
        // 0x00D819D8: MOVZ w20, #0x74            | W20 = 116 (0x74);//ML01                 
        val_19 = 116;
        label_35:
        // 0x00D819DC: CBZ x19, #0xd81a48         | if ( == 0) goto label_25;               
        if(null == 0)
        {
            goto label_25;
        }
        // 0x00D819E0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
        // 0x00D819E4: LDR x8, [x19]              | X8 = ;                                  
        UnityEngine.AndroidJavaClass val_19 = null;
        // 0x00D819E8: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
        // 0x00D819EC: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
        // 0x00D819F0: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
        // 0x00D819F4: CBZ x9, #0xd81a20          | if (mem[null + 258] == 0) goto label_26;
        if((mem[null + 258]) == 0)
        {
            goto label_26;
        }
        // 0x00D819F8: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
        var val_17 = mem[null + 152];
        // 0x00D819FC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_18 = 0;
        // 0x00D81A00: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
        val_17 = val_17 + 8;
        label_28:
        // 0x00D81A04: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
        // 0x00D81A08: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
        // 0x00D81A0C: B.EQ #0xd81a30             | if ((mem[null + 152] + 8) + -8 == null) goto label_27;
        if(((mem[null + 152] + 8) + -8) == null)
        {
            goto label_27;
        }
        // 0x00D81A10: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_18 = val_18 + 1;
        // 0x00D81A14: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
        val_17 = val_17 + 16;
        // 0x00D81A18: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
        // 0x00D81A1C: B.LO #0xd81a04             | if (0 < mem[null + 258]) goto label_28; 
        if(val_18 < (mem[null + 258]))
        {
            goto label_28;
        }
        label_26:
        // 0x00D81A20: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00D81A24: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        val_20 = val_14;
        // 0x00D81A28: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00D81A2C: B #0xd81a3c                |  goto label_29;                         
        goto label_29;
        label_27:
        // 0x00D81A30: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
        // 0x00D81A34: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
        val_19 = val_19 + (((mem[null + 152] + 8)) << 4);
        // 0x00D81A38: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
        label_29:
        // 0x00D81A3C: LDP x8, x1, [x0]           | X8 = 0x10102464C457F; X1 = 0x0;          //  | 
        // 0x00D81A40: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00D81A44: BLR x8                     | X0 = sub_10102464C457F( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        label_25:
        // 0x00D81A48: CMP w20, #0x74             | STATE = COMPARE(0x74, 0x74)             
        // 0x00D81A4C: B.EQ #0xd81a74             | if (0x74 == 0x74) goto label_31;        
        if(116 == 116)
        {
            goto label_31;
        }
        // 0x00D81A50: CBZ x21, #0xd81a74         | if (0x0 == 0) goto label_31;            
        if(val_16 == 0)
        {
            goto label_31;
        }
        // 0x00D81A54: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00D81A58: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00D81A5C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        val_14 = ???;
        // 0x00D81A60: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        val_16 = ???;
        // 0x00D81A64: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        val_15 = ???;
        // 0x00D81A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D81A6C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        val_17 = ???;
        // 0x00D81A70: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_31:
        // 0x00D81A74: LDP x29, x30, [sp, #0x40]  | X29 = val_4; X30 = val_5;                //  find_add[1152921514972150992] |  find_add[1152921514972150992]
        // 0x00D81A78: LDP x20, x19, [sp, #0x30]  | X20 = val_6; X19 = val_7;                //  find_add[1152921514972150992] |  find_add[1152921514972150992]
        // 0x00D81A7C: LDP x22, x21, [sp, #0x20]  | X22 = val_8; X21 = val_9;                //  find_add[1152921514972150992] |  find_add[1152921514972150992]
        // 0x00D81A80: LDP x24, x23, [sp, #0x10]  | X24 = val_10; X23 = val_11;              //  find_add[1152921514972150992] |  find_add[1152921514972150992]
        // 0x00D81A84: LDP x26, x25, [sp], #0x50  | X26 = val_12; X25 = val_13;              //  find_add[1152921514972150992] |  find_add[1152921514972150992]
        // 0x00D81A88: RET                        |  return;                                
        return;
        // 0x00D81A8C: CMP w1, #1                 | 
        // 0x00D81A90: B.NE #0xd81ab0             | 
        // 0x00D81A94: BL #0x981060               | 
        // 0x00D81A98: LDR x21, [x0]              | 
        // 0x00D81A9C: MOV w25, wzr               | 
        // 0x00D81AA0: BL #0x980920               | 
        // 0x00D81AA4: B #0xd8194c                | 
        // 0x00D81AA8: MOV w20, w25               | 
        // 0x00D81AAC: B #0xd81ab4                | 
        label_32:
        // 0x00D81AB0: MOV w20, wzr               | 
        label_34:
        // 0x00D81AB4: BL #0x981060               | 
        // 0x00D81AB8: LDR x21, [x0]              | 
        // 0x00D81ABC: BL #0x980920               | 
        // 0x00D81AC0: B #0xd819dc                | 
    
    }

}
