using UnityEngine;
public static class ClassAdapter
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D843F4 (14173172), len: 164  VirtAddr: 0x00D843F4 RVA: 0x00D843F4 token: 100680697 methodIndex: 25970 delegateWrapperIndex: 0 methodInvoker: 0
    public static void RegisterClassDelegate(ILRuntime.Runtime.Enviorment.AppDomain appdomain)
    {
        //
        // Disasemble & Code
        // 0x00D843F4: STP x20, x19, [sp, #-0x20]! | stack[1152921512948054048] = ???;  stack[1152921512948054056] = ???;  //  dest_result_addr=1152921512948054048 |  dest_result_addr=1152921512948054056
        // 0x00D843F8: STP x29, x30, [sp, #0x10]  | stack[1152921512948054064] = ???;  stack[1152921512948054072] = ???;  //  dest_result_addr=1152921512948054064 |  dest_result_addr=1152921512948054072
        // 0x00D843FC: ADD x29, sp, #0x10         | X29 = (1152921512948054048 + 16) = 1152921512948054064 (0x10000001F12CB830);
        // 0x00D84400: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D84404: LDRB w8, [x20, #0x42f]     | W8 = (bool)static_value_0373442F;       
        // 0x00D84408: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00D8440C: TBNZ w8, #0, #0xd84428     | if (static_value_0373442F == true) goto label_0;
        // 0x00D84410: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00D84414: LDR x8, [x8, #0x748]       | X8 = 0x2B90B10;                         
        // 0x00D84418: LDR w0, [x8]               | W0 = 0x1988;                            
        // 0x00D8441C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1988, ????);     
        // 0x00D84420: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D84424: STRB w8, [x20, #0x42f]     | static_value_0373442F = true;            //  dest_result_addr=57885743
        label_0:
        // 0x00D84428: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00D8442C: LDR x8, [x8, #0xcc8]       | X8 = 1152921504827719680;               
        // 0x00D84430: LDR x0, [x8]               | X0 = typeof(Mihua.Assets.ILR.MHAdapter.MonoBehaviourAdapter);
        Mihua.Assets.ILR.MHAdapter.MonoBehaviourAdapter val_1 = null;
        // 0x00D84434: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Assets.ILR.MHAdapter.MonoBehaviourAdapter), ????);
        // 0x00D84438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D8443C: MOV x20, x0                | X20 = 1152921504827719680 (0x100000000D2A4000);//ML01
        // 0x00D84440: BL #0xabbf1c               | .ctor();                                
        val_1 = new Mihua.Assets.ILR.MHAdapter.MonoBehaviourAdapter();
        // 0x00D84444: CBNZ x19, #0xd8444c        | if (X1 != 0) goto label_1;              
        if(X1 != 0)
        {
            goto label_1;
        }
        // 0x00D84448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00D8444C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84450: MOV x0, x19                | X0 = X1;//m1                            
        // 0x00D84454: MOV x1, x20                | X1 = 1152921504827719680 (0x100000000D2A4000);//ML01
        // 0x00D84458: BL #0x28e3d74              | X1.RegisterCrossBindingAdaptor(adaptor:  val_1);
        X1.RegisterCrossBindingAdaptor(adaptor:  val_1);
        // 0x00D8445C: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
        // 0x00D84460: LDR x8, [x8, #0xd18]       | X8 = 1152921504827506688;               
        // 0x00D84464: LDR x0, [x8]               | X0 = typeof(Mihua.Assets.ILR.MHAdapter.CoroutineAdapter);
        Mihua.Assets.ILR.MHAdapter.CoroutineAdapter val_2 = null;
        // 0x00D84468: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Assets.ILR.MHAdapter.CoroutineAdapter), ????);
        // 0x00D8446C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84470: MOV x20, x0                | X20 = 1152921504827506688 (0x100000000D270000);//ML01
        // 0x00D84474: BL #0xab8014               | .ctor();                                
        val_2 = new Mihua.Assets.ILR.MHAdapter.CoroutineAdapter();
        // 0x00D84478: CBNZ x19, #0xd84480        | if (X1 != 0) goto label_2;              
        if(X1 != 0)
        {
            goto label_2;
        }
        // 0x00D8447C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00D84480: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D84484: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84488: MOV x0, x19                | X0 = X1;//m1                            
        // 0x00D8448C: MOV x1, x20                | X1 = 1152921504827506688 (0x100000000D270000);//ML01
        // 0x00D84490: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D84494: B #0x28e3d74               | X1.RegisterCrossBindingAdaptor(adaptor:  val_2); return;
        X1.RegisterCrossBindingAdaptor(adaptor:  val_2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D84498 (14173336), len: 368  VirtAddr: 0x00D84498 RVA: 0x00D84498 token: 100680698 methodIndex: 25971 delegateWrapperIndex: 0 methodInvoker: 0
    public static void RegisterValueTypeBinder(ILRuntime.Runtime.Enviorment.AppDomain appdomain)
    {
        //
        // Disasemble & Code
        // 0x00D84498: STP x22, x21, [sp, #-0x30]! | stack[1152921512948186512] = ???;  stack[1152921512948186520] = ???;  //  dest_result_addr=1152921512948186512 |  dest_result_addr=1152921512948186520
        // 0x00D8449C: STP x20, x19, [sp, #0x10]  | stack[1152921512948186528] = ???;  stack[1152921512948186536] = ???;  //  dest_result_addr=1152921512948186528 |  dest_result_addr=1152921512948186536
        // 0x00D844A0: STP x29, x30, [sp, #0x20]  | stack[1152921512948186544] = ???;  stack[1152921512948186552] = ???;  //  dest_result_addr=1152921512948186544 |  dest_result_addr=1152921512948186552
        // 0x00D844A4: ADD x29, sp, #0x20         | X29 = (1152921512948186512 + 32) = 1152921512948186544 (0x10000001F12EBDB0);
        // 0x00D844A8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D844AC: LDRB w8, [x20, #0x430]     | W8 = (bool)static_value_03734430;       
        // 0x00D844B0: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00D844B4: TBNZ w8, #0, #0xd844d0     | if (static_value_03734430 == true) goto label_0;
        // 0x00D844B8: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00D844BC: LDR x8, [x8, #0x730]       | X8 = 0x2B90B14;                         
        // 0x00D844C0: LDR w0, [x8]               | W0 = 0x1989;                            
        // 0x00D844C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1989, ????);     
        // 0x00D844C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D844CC: STRB w8, [x20, #0x430]     | static_value_03734430 = true;            //  dest_result_addr=57885744
        label_0:
        // 0x00D844D0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00D844D4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
        // 0x00D844D8: LDR x0, [x8]               | X0 = typeof(System.Type);               
        // 0x00D844DC: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00D844E0: LDR x8, [x8, #0xef0]       | X8 = 1152921504695078912;               
        // 0x00D844E4: LDR x20, [x8]              | X20 = typeof(UnityEngine.Vector3);      
        // 0x00D844E8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
        // 0x00D844EC: TBZ w8, #0, #0xd844fc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D844F0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
        // 0x00D844F4: CBNZ w8, #0xd844fc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D844F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
        label_2:
        // 0x00D844FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84500: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D84504: MOV x1, x20                | X1 = 1152921504695078912 (0x1000000005425000);//ML01
        // 0x00D84508: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x00D8450C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D84510: LDR x8, [x8, #0xee8]       | X8 = 1152921504827932672;               
        // 0x00D84514: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D84518: LDR x8, [x8]               | X8 = typeof(Vector3Binder);             
        // 0x00D8451C: MOV x0, x8                 | X0 = 1152921504827932672 (0x100000000D2D8000);//ML01
        Vector3Binder val_2 = null;
        // 0x00D84520: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Vector3Binder), ????);
        // 0x00D84524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84528: MOV x21, x0                | X21 = 1152921504827932672 (0x100000000D2D8000);//ML01
        // 0x00D8452C: BL #0xe1e02c               | .ctor();                                
        val_2 = new Vector3Binder();
        // 0x00D84530: CBNZ x19, #0xd84538        | if (X1 != 0) goto label_3;              
        if(X1 != 0)
        {
            goto label_3;
        }
        // 0x00D84534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_3:
        // 0x00D84538: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D8453C: MOV x0, x19                | X0 = X1;//m1                            
        // 0x00D84540: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00D84544: MOV x2, x21                | X2 = 1152921504827932672 (0x100000000D2D8000);//ML01
        // 0x00D84548: BL #0x28e5c88              | X1.RegisterValueTypeBinder(t:  val_1, binder:  val_2);
        X1.RegisterValueTypeBinder(t:  val_1, binder:  val_2);
        // 0x00D8454C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00D84550: LDR x8, [x8, #0xcb0]       | X8 = 1152921504695132160;               
        // 0x00D84554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D84558: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D8455C: LDR x1, [x8]               | X1 = typeof(UnityEngine.Quaternion);    
        // 0x00D84560: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x00D84564: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D84568: LDR x8, [x8, #0x5c0]       | X8 = 1152921504827826176;               
        // 0x00D8456C: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00D84570: LDR x8, [x8]               | X8 = typeof(QuaternionBinder);          
        // 0x00D84574: MOV x0, x8                 | X0 = 1152921504827826176 (0x100000000D2BE000);//ML01
        QuaternionBinder val_4 = null;
        // 0x00D84578: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(QuaternionBinder), ????);
        // 0x00D8457C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D84580: MOV x21, x0                | X21 = 1152921504827826176 (0x100000000D2BE000);//ML01
        // 0x00D84584: BL #0xc8dfe8               | .ctor();                                
        val_4 = new QuaternionBinder();
        // 0x00D84588: CBNZ x19, #0xd84590        | if (X1 != 0) goto label_4;              
        if(X1 != 0)
        {
            goto label_4;
        }
        // 0x00D8458C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_4:
        // 0x00D84590: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D84594: MOV x0, x19                | X0 = X1;//m1                            
        // 0x00D84598: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00D8459C: MOV x2, x21                | X2 = 1152921504827826176 (0x100000000D2BE000);//ML01
        // 0x00D845A0: BL #0x28e5c88              | X1.RegisterValueTypeBinder(t:  val_3, binder:  val_4);
        X1.RegisterValueTypeBinder(t:  val_3, binder:  val_4);
        // 0x00D845A4: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x00D845A8: LDR x8, [x8, #0x318]       | X8 = 1152921504708657152;               
        // 0x00D845AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D845B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D845B4: LDR x1, [x8]               | X1 = typeof(UnityEngine.Vector2);       
        // 0x00D845B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x00D845BC: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00D845C0: LDR x8, [x8, #0xde0]       | X8 = 1152921504827879424;               
        // 0x00D845C4: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00D845C8: LDR x8, [x8]               | X8 = typeof(Vector2Binder);             
        // 0x00D845CC: MOV x0, x8                 | X0 = 1152921504827879424 (0x100000000D2CB000);//ML01
        Vector2Binder val_6 = null;
        // 0x00D845D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Vector2Binder), ????);
        // 0x00D845D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D845D8: MOV x21, x0                | X21 = 1152921504827879424 (0x100000000D2CB000);//ML01
        // 0x00D845DC: BL #0xe1acf8               | .ctor();                                
        val_6 = new Vector2Binder();
        // 0x00D845E0: CBNZ x19, #0xd845e8        | if (X1 != 0) goto label_5;              
        if(X1 != 0)
        {
            goto label_5;
        }
        // 0x00D845E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_5:
        // 0x00D845E8: MOV x0, x19                | X0 = X1;//m1                            
        // 0x00D845EC: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x00D845F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D845F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D845F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D845FC: MOV x2, x21                | X2 = 1152921504827879424 (0x100000000D2CB000);//ML01
        // 0x00D84600: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D84604: B #0x28e5c88               | X1.RegisterValueTypeBinder(t:  val_5, binder:  val_6); return;
        X1.RegisterValueTypeBinder(t:  val_5, binder:  val_6);
        return;
    
    }

}
