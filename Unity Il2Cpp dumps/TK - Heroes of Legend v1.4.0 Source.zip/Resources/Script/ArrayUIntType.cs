using UnityEngine;

namespace wxb
{
    internal class ArrayUIntType : ArraySerialize<uint>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2C80C (14862348), len: 80  VirtAddr: 0x00E2C80C RVA: 0x00E2C80C token: 100681181 methodIndex: 57233 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayUIntType()
        {
            //
            // Disasemble & Code
            // 0x00E2C80C: STP x20, x19, [sp, #-0x20]! | stack[1152921513023528352] = ???;  stack[1152921513023528360] = ???;  //  dest_result_addr=1152921513023528352 |  dest_result_addr=1152921513023528360
            // 0x00E2C810: STP x29, x30, [sp, #0x10]  | stack[1152921513023528368] = ???;  stack[1152921513023528376] = ???;  //  dest_result_addr=1152921513023528368 |  dest_result_addr=1152921513023528376
            // 0x00E2C814: ADD x29, sp, #0x10         | X29 = (1152921513023528352 + 16) = 1152921513023528368 (0x10000001F5AC5DB0);
            // 0x00E2C818: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C81C: LDRB w8, [x20, #0x8f8]     | W8 = (bool)static_value_037348F8;       
            // 0x00E2C820: MOV x19, x0                | X19 = 1152921513023540384 (0x10000001F5AC8CA0);//ML01
            // 0x00E2C824: TBNZ w8, #0, #0xe2c840     | if (static_value_037348F8 == true) goto label_0;
            // 0x00E2C828: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x00E2C82C: LDR x8, [x8, #0xa48]       | X8 = 0x2B8E86C;                         
            // 0x00E2C830: LDR w0, [x8]               | W0 = 0x10D9;                            
            // 0x00E2C834: BL #0x2782188              | X0 = sub_2782188( ?? 0x10D9, ????);     
            // 0x00E2C838: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C83C: STRB w8, [x20, #0x8f8]     | static_value_037348F8 = true;            //  dest_result_addr=57886968
            label_0:
            // 0x00E2C840: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00E2C844: LDR x8, [x8, #0x30]        | X8 = 1152921513023515360;               
            // 0x00E2C848: MOV x0, x19                | X0 = 1152921513023540384 (0x10000001F5AC8CA0);//ML01
            // 0x00E2C84C: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.UInt32>::.ctor();
            // 0x00E2C850: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C854: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C858: B #0x1d8735c               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C85C (14862428), len: 8  VirtAddr: 0x00E2C85C RVA: 0x00E2C85C token: 100681182 methodIndex: 57234 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2C85C: ORR w0, wzr, #4            | W0 = 4(0x4);                            
            // 0x00E2C860: RET                        |  return (System.Int32)4;                
            return (int)4;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C864 (14862436), len: 52  VirtAddr: 0x00E2C864 RVA: 0x00E2C864 token: 100681183 methodIndex: 57235 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, uint value)
        {
            //
            // Disasemble & Code
            // 0x00E2C864: STP x20, x19, [sp, #-0x20]! | stack[1152921513023756448] = ???;  stack[1152921513023756456] = ???;  //  dest_result_addr=1152921513023756448 |  dest_result_addr=1152921513023756456
            // 0x00E2C868: STP x29, x30, [sp, #0x10]  | stack[1152921513023756464] = ???;  stack[1152921513023756472] = ???;  //  dest_result_addr=1152921513023756464 |  dest_result_addr=1152921513023756472
            // 0x00E2C86C: ADD x29, sp, #0x10         | X29 = (1152921513023756448 + 16) = 1152921513023756464 (0x10000001F5AFD8B0);
            // 0x00E2C870: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2C874: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2C878: CBNZ x20, #0xe2c880        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C87C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C880: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C884: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C888: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2C88C: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2C890: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C894: B #0x26a4060               | stream.WriteInt32(value:  value); return;
            stream.WriteInt32(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C898 (14862488), len: 44  VirtAddr: 0x00E2C898 RVA: 0x00E2C898 token: 100681184 methodIndex: 57236 delegateWrapperIndex: 0 methodInvoker: 0
        protected override uint Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2C898: STP x20, x19, [sp, #-0x20]! | stack[1152921513023876640] = ???;  stack[1152921513023876648] = ???;  //  dest_result_addr=1152921513023876640 |  dest_result_addr=1152921513023876648
            // 0x00E2C89C: STP x29, x30, [sp, #0x10]  | stack[1152921513023876656] = ???;  stack[1152921513023876664] = ???;  //  dest_result_addr=1152921513023876656 |  dest_result_addr=1152921513023876664
            // 0x00E2C8A0: ADD x29, sp, #0x10         | X29 = (1152921513023876640 + 16) = 1152921513023876656 (0x10000001F5B1AE30);
            // 0x00E2C8A4: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2C8A8: CBNZ x19, #0xe2c8b0        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C8AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C8B0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C8B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C8B8: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2C8BC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C8C0: B #0x26a41a4               | return stream.ReadUInt32();             
            return stream.ReadUInt32();
        
        }
    
    }

}
