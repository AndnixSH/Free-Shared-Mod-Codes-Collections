using UnityEngine;

namespace ILRuntime.Runtime.Debugger
{
    internal class BreakPointContext
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285740C
        private ILRuntime.Runtime.Intepreter.ILIntepreter <Interpreter>k__BackingField; //  0x00000010
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2857448
        private System.Exception <Exception>k__BackingField; //  0x00000018
        
        // Properties
        public ILRuntime.Runtime.Intepreter.ILIntepreter Interpreter { get; set; }
        public System.Exception Exception { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01113A5C (17906268), len: 8  VirtAddr: 0x01113A5C RVA: 0x01113A5C token: 100679944 methodIndex: 29233 delegateWrapperIndex: 0 methodInvoker: 0
        public BreakPointContext()
        {
            //
            // Disasemble & Code
            // 0x01113A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01113A60: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01113A64 (17906276), len: 8  VirtAddr: 0x01113A64 RVA: 0x01113A64 token: 100679945 methodIndex: 29234 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Runtime.Intepreter.ILIntepreter get_Interpreter()
        {
            //
            // Disasemble & Code
            // 0x01113A64: LDR x0, [x0, #0x10]        | X0 = this.<Interpreter>k__BackingField; //P2 
            // 0x01113A68: RET                        |  return (ILRuntime.Runtime.Intepreter.ILIntepreter)this.<Interpreter>k__BackingField;
            return this.<Interpreter>k__BackingField;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Intepreter.ILIntepreter, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01113A6C (17906284), len: 8  VirtAddr: 0x01113A6C RVA: 0x01113A6C token: 100679946 methodIndex: 29235 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Interpreter(ILRuntime.Runtime.Intepreter.ILIntepreter value)
        {
            //
            // Disasemble & Code
            // 0x01113A6C: STR x1, [x0, #0x10]        | this.<Interpreter>k__BackingField = value;  //  dest_result_addr=1152921512839568704
            this.<Interpreter>k__BackingField = value;
            // 0x01113A70: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01113A74 (17906292), len: 8  VirtAddr: 0x01113A74 RVA: 0x01113A74 token: 100679947 methodIndex: 29236 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Exception get_Exception()
        {
            //
            // Disasemble & Code
            // 0x01113A74: LDR x0, [x0, #0x18]        | X0 = this.<Exception>k__BackingField; //P2 
            // 0x01113A78: RET                        |  return (System.Exception)this.<Exception>k__BackingField;
            return this.<Exception>k__BackingField;
            //  |  // // {name=val_0, type=System.Exception, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01113A7C (17906300), len: 8  VirtAddr: 0x01113A7C RVA: 0x01113A7C token: 100679948 methodIndex: 29237 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Exception(System.Exception value)
        {
            //
            // Disasemble & Code
            // 0x01113A7C: STR x1, [x0, #0x18]        | this.<Exception>k__BackingField = value;  //  dest_result_addr=1152921512839809096
            this.<Exception>k__BackingField = value;
            // 0x01113A80: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01113A84 (17906308), len: 8  VirtAddr: 0x01113A84 RVA: 0x01113A84 token: 100679949 methodIndex: 29238 delegateWrapperIndex: 0 methodInvoker: 0
        public string DumpContext()
        {
            //
            // Disasemble & Code
            // 0x01113A84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01113A88: RET                        |  return (System.String)null;            
            return (string)0;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01113A8C (17906316), len: 372  VirtAddr: 0x01113A8C RVA: 0x01113A8C token: 100679950 methodIndex: 29239 delegateWrapperIndex: 0 methodInvoker: 0
        private string GetStackObjectValue(ILRuntime.Runtime.Stack.StackObject val, System.Collections.Generic.IList<object> mStack)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x01113A8C: STP x22, x21, [sp, #-0x30]! | stack[1152921512840041600] = ???;  stack[1152921512840041608] = ???;  //  dest_result_addr=1152921512840041600 |  dest_result_addr=1152921512840041608
            // 0x01113A90: STP x20, x19, [sp, #0x10]  | stack[1152921512840041616] = ???;  stack[1152921512840041624] = ???;  //  dest_result_addr=1152921512840041616 |  dest_result_addr=1152921512840041624
            // 0x01113A94: STP x29, x30, [sp, #0x20]  | stack[1152921512840041632] = ???;  stack[1152921512840041640] = ???;  //  dest_result_addr=1152921512840041632 |  dest_result_addr=1152921512840041640
            // 0x01113A98: ADD x29, sp, #0x20         | X29 = (1152921512840041600 + 32) = 1152921512840041632 (0x10000001EABC94A0);
            // 0x01113A9C: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x01113AA0: LDRB w8, [x21, #0xba8]     | W8 = (bool)static_value_03735BA8;       
            // 0x01113AA4: MOV x19, x1                | X19 = val;//m1                          
            ILRuntime.Runtime.Stack.StackObject val_4 = val;
            // 0x01113AA8: MOV x20, x0                | X20 = 1152921512840053648 (0x10000001EABCC390);//ML01
            // 0x01113AAC: STR x19, [sp, #-0x10]!     | stack[1152921512840041584] = val;        //  dest_result_addr=1152921512840041584
            // 0x01113AB0: STR w2, [sp, #8]           | stack[1152921512840041592] = mStack;     //  dest_result_addr=1152921512840041592
            // 0x01113AB4: TBNZ w8, #0, #0x1113ad0    | if (static_value_03735BA8 == true) goto label_0;
            // 0x01113AB8: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x01113ABC: LDR x8, [x8, #0xc38]       | X8 = 0x2B8F948;                         
            // 0x01113AC0: LDR w0, [x8]               | W0 = 0x1516;                            
            // 0x01113AC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1516, ????);     
            // 0x01113AC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01113ACC: STRB w8, [x21, #0xba8]     | static_value_03735BA8 = true;            //  dest_result_addr=57891752
            label_0:
            // 0x01113AD0: CMP w19, #9                | STATE = COMPARE(val, 0x9)               
            // 0x01113AD4: B.EQ #0x1113af0            | if (val == 0x9) goto label_1;           
            if(val_4 == 9)
            {
                goto label_1;
            }
            // 0x01113AD8: CMP w19, #1                | STATE = COMPARE(val, 0x1)               
            // 0x01113ADC: B.EQ #0x1113b80            | if (val == 0x1) goto label_2;           
            if(val_4 == 1)
            {
                goto label_2;
            }
            // 0x01113AE0: CBNZ w19, #0x1113b94       | if (val != 0) goto label_3;             
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x01113AE4: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x01113AE8: LDR x8, [x8, #0xf80]       | X8 = (string**)(1152921509424904560)("null");
            val_4 = "null";
            // 0x01113AEC: B #0x1113b9c               |  goto label_4;                          
            goto label_4;
            label_1:
            // 0x01113AF0: LDR x20, [x20, #0x10]      | X20 = this.<Interpreter>k__BackingField; //P2 
            // 0x01113AF4: CBNZ x20, #0x1113afc       | if (this.<Interpreter>k__BackingField != null) goto label_5;
            if((this.<Interpreter>k__BackingField) != null)
            {
                goto label_5;
            }
            // 0x01113AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1516, ????);     
            label_5:
            // 0x01113AFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01113B00: MOV x0, x20                | X0 = this.<Interpreter>k__BackingField;//m1
            // 0x01113B04: BL #0x1f901b8              | X0 = this.<Interpreter>k__BackingField.get_Stack();
            ILRuntime.Runtime.Stack.RuntimeStack val_1 = this.<Interpreter>k__BackingField.Stack;
            // 0x01113B08: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01113B0C: CBNZ x20, #0x1113b14       | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x01113B10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x01113B14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01113B18: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01113B1C: LSR x19, x19, #0x20        | X19 = (val >> 32);                      
            val_4 = val_4 >> 32;
            // 0x01113B20: BL #0x1f9091c              | X0 = val_1.get_ManagedStack();          
            System.Collections.Generic.IList<System.Object> val_2 = val_1.ManagedStack;
            // 0x01113B24: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01113B28: CBNZ x20, #0x1113b30       | if (val_2 != null) goto label_7;        
            if(val_2 != null)
            {
                goto label_7;
            }
            // 0x01113B2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x01113B30: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x01113B34: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IList<System.Object>);
            // 0x01113B38: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x01113B3C: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x01113B40: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x01113B44: CBZ x9, #0x1113b70         | if (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_8;
            // 0x01113B48: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x01113B4C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x01113B50: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IList<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609439752 (0x1000000000279008);
            label_10:
            // 0x01113B54: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x01113B58: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x01113B5C: B.EQ #0x1113bb4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_9;
            // 0x01113B60: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x01113B64: ADD x10, x10, #0x10        | X10 = (1152921504609439752 + 16) = 1152921504609439768 (0x1000000000279018);
            // 0x01113B68: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x01113B6C: B.LO #0x1113b54            | if (0 < System.Collections.Generic.IList<T>.__il2cppRuntimeField_interface_offsets_count) goto label_10;
            label_8:
            // 0x01113B70: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01113B74: MOV x0, x20                | X0 = val_2;//m1                         
            val_5 = val_2;
            // 0x01113B78: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x01113B7C: B #0x1113bc4               |  goto label_11;                         
            goto label_11;
            label_2:
            // 0x01113B80: MOV x8, sp                 | X8 = 1152921512840041584 (0x10000001EABC9470);//ML01
            // 0x01113B84: ORR x0, x8, #4             | X0 = ( | 4) = 1152921512840041588 (0x10000001EABC9474);
            // 0x01113B88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01113B8C: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
            // 0x01113B90: B #0x1113ba0               |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x01113B94: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x01113B98: LDR x8, [x8, #0x880]       | X8 = (string**)(1152921512840029552)("Unknown type");
            val_4 = "Unknown type";
            label_4:
            // 0x01113B9C: LDR x0, [x8]               | X0 = "Unknown type";                    
            label_12:
            // 0x01113BA0: SUB sp, x29, #0x20         | SP = (1152921512840041632 - 32) = 1152921512840041600 (0x10000001EABC9480);
            // 0x01113BA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01113BA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01113BAC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01113BB0: RET                        |  return (System.String)"Unknown type";  
            return (string)val_4;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_9:
            // 0x01113BB4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x01113BB8: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x01113BBC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x01113BC0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609402880 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_11:
            // 0x01113BC4: LDP x8, x2, [x0]           | X8 = typeof(System.Collections.Generic.IList<System.Object>);  //  | 
            // 0x01113BC8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x01113BCC: MOV w1, w19                | W1 = (val >> 32);//m1                   
            // 0x01113BD0: BLR x8                     | X0 = sub_1000000000270000( ?? val_2, ????);
            // 0x01113BD4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x01113BD8: CBNZ x19, #0x1113be0       | if (val_2 != null) goto label_13;       
            if(val_2 != null)
            {
                goto label_13;
            }
            // 0x01113BDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_13:
            // 0x01113BE0: LDR x8, [x19]              | X8 = typeof(System.Collections.Generic.IList<System.Object>);
            // 0x01113BE4: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x01113BE8: LDP x2, x1, [x8, #0x140]   | X2 = typeof(System.Collections.Generic.IList<T>).__il2cppRuntimeField_140; X1 = typeof(System.Collections.Generic.IList<T>).__il2cppRuntimeField_148; //  | 
            // 0x01113BEC: SUB sp, x29, #0x20         | SP = (1152921512840041632 - 32) = 1152921512840041600 (0x10000001EABC9480);
            // 0x01113BF0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01113BF4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01113BF8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01113BFC: BR x2                      | goto typeof(System.Collections.Generic.IList<T>).__il2cppRuntimeField_140;
            goto typeof(System.Collections.Generic.IList<T>).__il2cppRuntimeField_140;
        
        }
    
    }

}
