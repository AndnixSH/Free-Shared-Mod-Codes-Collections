using UnityEngine;
public class AnimationRunner : MonoBehaviour
{
    // Fields
    private static System.Collections.Generic.Dictionary<AnimationRunner.AniType, string> AniTypeDic; // static_offset: 0x00000000
    private UnityEngine.Animation[] ani; //  0x00000018
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x287C214
    private AnimationRunner.AniState <aniState>k__BackingField; //  0x00000020
    private string aniName; //  0x00000028
    public string curAniName; //  0x00000030
    public CombatEntity unit; //  0x00000038
    private System.Collections.Generic.List<string> nameList; //  0x00000040
    private UnityEngine.AnimationState curstate; //  0x00000048
    private float runSpeed; //  0x00000050
    private float _playTime; //  0x00000054
    private bool isHaveAni; //  0x00000058
    public bool isSkillFrozen; //  0x00000059
    
    // Properties
    public AnimationRunner.AniState aniState { get; set; }
    private float PlayTime { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B27CA8 (11697320), len: 224  VirtAddr: 0x00B27CA8 RVA: 0x00B27CA8 token: 100696507 methodIndex: 24827 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimationRunner()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00B27CA8: STP x22, x21, [sp, #-0x30]! | stack[1152921515541075616] = ???;  stack[1152921515541075624] = ???;  //  dest_result_addr=1152921515541075616 |  dest_result_addr=1152921515541075624
        // 0x00B27CAC: STP x20, x19, [sp, #0x10]  | stack[1152921515541075632] = ???;  stack[1152921515541075640] = ???;  //  dest_result_addr=1152921515541075632 |  dest_result_addr=1152921515541075640
        // 0x00B27CB0: STP x29, x30, [sp, #0x20]  | stack[1152921515541075648] = ???;  stack[1152921515541075656] = ???;  //  dest_result_addr=1152921515541075648 |  dest_result_addr=1152921515541075656
        // 0x00B27CB4: ADD x29, sp, #0x20         | X29 = (1152921515541075616 + 32) = 1152921515541075648 (0x100000028BBB16C0);
        // 0x00B27CB8: SUB sp, sp, #0x10          | SP = (1152921515541075616 - 16) = 1152921515541075600 (0x100000028BBB1690);
        // 0x00B27CBC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B27CC0: LDRB w8, [x20, #0x750]     | W8 = (bool)static_value_03733750;       
        // 0x00B27CC4: MOV x19, x0                | X19 = 1152921515541087664 (0x100000028BBB45B0);//ML01
        // 0x00B27CC8: TBNZ w8, #0, #0xb27ce4     | if (static_value_03733750 == true) goto label_0;
        // 0x00B27CCC: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00B27CD0: LDR x8, [x8, #0x40]        | X8 = 0x2B8AE14;                         
        // 0x00B27CD4: LDR w0, [x8]               | W0 = 0x243;                             
        // 0x00B27CD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x243, ????);      
        // 0x00B27CDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27CE0: STRB w8, [x20, #0x750]     | static_value_03733750 = true;            //  dest_result_addr=57882448
        label_0:
        // 0x00B27CE4: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B27CE8: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
        // 0x00B27CEC: ADD x1, sp, #0xc           | X1 = (1152921515541075600 + 12) = 1152921515541075612 (0x100000028BBB169C);
        // 0x00B27CF0: STR wzr, [sp, #0xc]        | stack[1152921515541075612] = 0x0;        //  dest_result_addr=1152921515541075612
        // 0x00B27CF4: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
        // 0x00B27CF8: BL #0x27bc028              | X0 = 1152921515541119664 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), null);
        // 0x00B27CFC: MOV x20, x0                | X20 = 1152921515541119664 (0x100000028BBBC2B0);//ML01
        // 0x00B27D00: CBNZ x20, #0xb27d08        | if (null != 0) goto label_1;            
        if(0 != 0)
        {
            goto label_1;
        }
        // 0x00B27D04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null, ????);       
        label_1:
        // 0x00B27D08: LDR x8, [x20]              | X8 = typeof(AnimationRunner.AniType);   
        // 0x00B27D0C: MOV x0, x20                | X0 = 1152921515541119664 (0x100000028BBBC2B0);//ML01
        // 0x00B27D10: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x00B27D14: BLR x9                     | X0 = null.ToString();                   
        string val_1 = 0.ToString();
        // 0x00B27D18: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B27D1C: CBNZ x20, #0xb27d24        | if (null != 0) goto label_2;            
        if(0 != 0)
        {
            goto label_2;
        }
        // 0x00B27D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B27D24: MOV x0, x20                | X0 = 1152921515541119664 (0x100000028BBBC2B0);//ML01
        // 0x00B27D28: BL #0x27bc4e8              | null.System.IDisposable.Dispose();      
        0.System.IDisposable.Dispose();
        // 0x00B27D2C: LDR w8, [x0]               | W8 = typeof(AnimationRunner.AniType);   
        // 0x00B27D30: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00B27D34: STR w8, [sp, #0xc]         | stack[1152921515541075612] = typeof(AnimationRunner.AniType);  //  dest_result_addr=1152921515541075612
        // 0x00B27D38: STR x21, [x19, #0x28]      | this.aniName = val_1;                    //  dest_result_addr=1152921515541087704
        this.aniName = val_1;
        // 0x00B27D3C: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00B27D40: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_2 = null;
        // 0x00B27D44: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B27D48: TBZ w8, #0, #0xb27d5c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B27D4C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B27D50: CBNZ w8, #0xb27d5c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B27D54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B27D58: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_2 = null;
        label_4:
        // 0x00B27D5C: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B27D60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27D64: MOV x0, x19                | X0 = 1152921515541087664 (0x100000028BBB45B0);//ML01
        // 0x00B27D68: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00B27D6C: STR x8, [x19, #0x30]       | this.curAniName = System.String.Empty;   //  dest_result_addr=1152921515541087712
        this.curAniName = System.String.Empty;
        // 0x00B27D70: BL #0x1b76fd4              | this..ctor();                           
        // 0x00B27D74: SUB sp, x29, #0x20         | SP = (1152921515541075648 - 32) = 1152921515541075616 (0x100000028BBB16A0);
        // 0x00B27D78: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27D7C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B27D80: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B27D84: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27D88 (11697544), len: 8  VirtAddr: 0x00B27D88 RVA: 0x00B27D88 token: 100696508 methodIndex: 24828 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_aniState(AnimationRunner.AniState value)
    {
        //
        // Disasemble & Code
        // 0x00B27D88: STR w1, [x0, #0x20]        | this.<aniState>k__BackingField = value;  //  dest_result_addr=1152921515541211984
        this.<aniState>k__BackingField = value;
        // 0x00B27D8C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27D90 (11697552), len: 8  VirtAddr: 0x00B27D90 RVA: 0x00B27D90 token: 100696509 methodIndex: 24829 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimationRunner.AniState get_aniState()
    {
        //
        // Disasemble & Code
        // 0x00B27D90: LDR w0, [x0, #0x20]        | W0 = this.<aniState>k__BackingField; //P2 
        // 0x00B27D94: RET                        |  return (AniState)this.<aniState>k__BackingField;
        return this.<aniState>k__BackingField;
        //  |  // // {name=val_0, type=AniState, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27D98 (11697560), len: 8  VirtAddr: 0x00B27D98 RVA: 0x00B27D98 token: 100696510 methodIndex: 24830 delegateWrapperIndex: 0 methodInvoker: 0
    private float get_PlayTime()
    {
        //
        // Disasemble & Code
        // 0x00B27D98: LDR s0, [x0, #0x54]        | S0 = this._playTime; //P2               
        // 0x00B27D9C: RET                        |  return (System.Single)this._playTime;  
        return this._playTime;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27DA0 (11697568), len: 8  VirtAddr: 0x00B27DA0 RVA: 0x00B27DA0 token: 100696511 methodIndex: 24831 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_PlayTime(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27DA0: STR s0, [x0, #0x54]        | this._playTime = value;                  //  dest_result_addr=1152921515541560324
        this._playTime = value;
        // 0x00B27DA4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27DA8 (11697576), len: 1464  VirtAddr: 0x00B27DA8 RVA: 0x00B27DA8 token: 100696512 methodIndex: 24832 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_19;
        //  | 
        float val_20;
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        var val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        // 0x00B27DA8: STP x28, x27, [sp, #-0x60]! | stack[1152921515541823056] = ???;  stack[1152921515541823064] = ???;  //  dest_result_addr=1152921515541823056 |  dest_result_addr=1152921515541823064
        // 0x00B27DAC: STP x26, x25, [sp, #0x10]  | stack[1152921515541823072] = ???;  stack[1152921515541823080] = ???;  //  dest_result_addr=1152921515541823072 |  dest_result_addr=1152921515541823080
        // 0x00B27DB0: STP x24, x23, [sp, #0x20]  | stack[1152921515541823088] = ???;  stack[1152921515541823096] = ???;  //  dest_result_addr=1152921515541823088 |  dest_result_addr=1152921515541823096
        // 0x00B27DB4: STP x22, x21, [sp, #0x30]  | stack[1152921515541823104] = ???;  stack[1152921515541823112] = ???;  //  dest_result_addr=1152921515541823104 |  dest_result_addr=1152921515541823112
        // 0x00B27DB8: STP x20, x19, [sp, #0x40]  | stack[1152921515541823120] = ???;  stack[1152921515541823128] = ???;  //  dest_result_addr=1152921515541823120 |  dest_result_addr=1152921515541823128
        // 0x00B27DBC: STP x29, x30, [sp, #0x50]  | stack[1152921515541823136] = ???;  stack[1152921515541823144] = ???;  //  dest_result_addr=1152921515541823136 |  dest_result_addr=1152921515541823144
        // 0x00B27DC0: ADD x29, sp, #0x50         | X29 = (1152921515541823056 + 80) = 1152921515541823136 (0x100000028BC67EA0);
        // 0x00B27DC4: SUB sp, sp, #0x20          | SP = (1152921515541823056 - 32) = 1152921515541823024 (0x100000028BC67E30);
        // 0x00B27DC8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B27DCC: LDRB w8, [x20, #0x751]     | W8 = (bool)static_value_03733751;       
        // 0x00B27DD0: MOV x19, x0                | X19 = 1152921515541835152 (0x100000028BC6AD90);//ML01
        // 0x00B27DD4: TBNZ w8, #0, #0xb27df0     | if (static_value_03733751 == true) goto label_0;
        // 0x00B27DD8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B27DDC: LDR x8, [x8, #0x700]       | X8 = 0x2B8AE18;                         
        // 0x00B27DE0: LDR w0, [x8]               | W0 = 0x244;                             
        // 0x00B27DE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x244, ????);      
        // 0x00B27DE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27DEC: STRB w8, [x20, #0x751]     | static_value_03733751 = true;            //  dest_result_addr=57882449
        label_0:
        // 0x00B27DF0: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B27DF4: LDR x8, [x8, #0x188]       | X8 = 1152921504922288128;               
        // 0x00B27DF8: LDR x8, [x8]               | X8 = typeof(AnimationRunner);           
        // 0x00B27DFC: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B27E00: LDR x8, [x8]               | X8 = AnimationRunner.AniTypeDic;        
        // 0x00B27E04: CBNZ x8, #0xb2800c         | if (AnimationRunner.AniTypeDic != null) goto label_10;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_10;
        }
        // 0x00B27E08: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B27E0C: LDR x8, [x8, #0x9e0]       | X8 = 1152921504615792640;               
        // 0x00B27E10: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<AniType, System.String> val_1 = null;
        // 0x00B27E14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B27E18: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00B27E1C: LDR x8, [x8, #0x198]       | X8 = 1152921515541648240;               
        // 0x00B27E20: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B27E24: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<AniType, System.String>::.ctor();
        // 0x00B27E28: BL #0x21a27bc              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<AniType, System.String>();
        // 0x00B27E2C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B27E30: LDR x8, [x8, #0x188]       | X8 = 1152921504922288128;               
        // 0x00B27E34: LDR x8, [x8]               | X8 = typeof(AnimationRunner);           
        // 0x00B27E38: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B27E3C: STR x20, [x8]              | AnimationRunner.AniTypeDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504922292224
        AnimationRunner.AniTypeDic = val_1;
        // 0x00B27E40: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00B27E44: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
        // 0x00B27E48: LDR x0, [x8]               | X0 = typeof(System.Type);               
        // 0x00B27E4C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B27E50: LDR x8, [x8, #0x1f0]       | X8 = 1152921504922341376;               
        // 0x00B27E54: LDR x20, [x8]              | X20 = typeof(AnimationRunner.AniType);  
        // 0x00B27E58: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
        // 0x00B27E5C: TBZ w8, #0, #0xb27e6c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B27E60: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
        // 0x00B27E64: CBNZ w8, #0xb27e6c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B27E68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
        label_3:
        // 0x00B27E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27E70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B27E74: MOV x1, x20                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
        // 0x00B27E78: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x00B27E7C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00B27E80: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
        // 0x00B27E84: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B27E88: LDR x8, [x8]               | X8 = typeof(System.Enum);               
        // 0x00B27E8C: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
        // 0x00B27E90: TBZ w9, #0, #0xb27ea4      | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B27E94: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
        // 0x00B27E98: CBNZ w9, #0xb27ea4         | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B27E9C: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
        // 0x00B27EA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
        label_5:
        // 0x00B27EA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27EA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B27EAC: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B27EB0: BL #0x1c394e8              | X0 = System.Enum.GetValues(enumType:  0);
        System.Array val_3 = System.Enum.GetValues(enumType:  0);
        // 0x00B27EB4: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B27EB8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_19 = 0;
        // 0x00B27EBC: CBZ x21, #0xb27f10         | if (val_3 == null) goto label_7;        
        if(val_3 == null)
        {
            goto label_7;
        }
        // 0x00B27EC0: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B27EC4: LDR x8, [x8, #0xa88]       | X8 = 1152921510047833568;               
        // 0x00B27EC8: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B27ECC: LDR x22, [x8]              | X22 = typeof(AniType[]);                
        // 0x00B27ED0: MOV x1, x22                | X1 = 1152921510047833568 (0x10000001444EDDE0);//ML01
        // 0x00B27ED4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x00B27ED8: MOV x20, x0                | X20 = val_3;//m1                        
        val_19 = val_3;
        // 0x00B27EDC: CBNZ x20, #0xb27f10        | if (val_3 != null) goto label_7;        
        if(val_19 != null)
        {
            goto label_7;
        }
        // 0x00B27EE0: LDR x8, [x21]              | X8 = typeof(System.Array);              
        // 0x00B27EE4: MOV x1, x22                | X1 = 1152921510047833568 (0x10000001444EDDE0);//ML01
        // 0x00B27EE8: LDR x0, [x8, #0x30]        | X0 = System.Array.__il2cppRuntimeField_element_class;
        // 0x00B27EEC: ADD x8, sp, #8             | X8 = (1152921515541823024 + 8) = 1152921515541823032 (0x100000028BC67E38);
        // 0x00B27EF0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Array.__il2cppRuntimeField_element_class, ????);
        // 0x00B27EF4: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921515541811152]
        // 0x00B27EF8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
        // 0x00B27EFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27F00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        // 0x00B27F04: ADD x0, sp, #8             | X0 = (1152921515541823024 + 8) = 1152921515541823032 (0x100000028BC67E38);
        // 0x00B27F08: BL #0x299a140              | 
        // 0x00B27F0C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_19 = 0;
        label_7:
        // 0x00B27F10: ADRP x28, #0x35db000       | X28 = 56471552 (0x35DB000);             
        // 0x00B27F14: ADRP x26, #0x364f000       | X26 = 56946688 (0x364F000);             
        // 0x00B27F18: LDR x28, [x28, #0x808]     | X28 = 1152921504922341376;              
        // 0x00B27F1C: LDR x26, [x26, #0x490]     | X26 = 1152921515541657456;              
        // 0x00B27F20: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
        val_20 = 0;
        // 0x00B27F24: B #0xb27f40                |  goto label_8;                          
        goto label_8;
        label_17:
        // 0x00B27F28: LDR x3, [x26]              | X3 = public System.Void System.Collections.Generic.Dictionary<AniType, System.String>::Add(AniType key, System.String value);
        // 0x00B27F2C: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B27F30: MOV w1, w22                | W1 = 1152921510047833568 (0x10000001444EDDE0);//ML01
        // 0x00B27F34: MOV x2, x24                | X2 = X24;//m1                           
        // 0x00B27F38: BL #0x21a4b04              | val_3.Add(key:  null, value:  X24);     
        val_3.Add(key:  null, value:  X24);
        // 0x00B27F3C: ADD w27, w27, #1           | W27 = (val_20 + 1) = val_20 (0x00000001);
        val_20 = 1;
        label_8:
        // 0x00B27F40: CBNZ x20, #0xb27f48        | if (0x0 != 0) goto label_9;             
        if(val_19 != 0)
        {
            goto label_9;
        }
        // 0x00B27F44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B27F48: LDR x8, [x20, #0x18]       | X8 = 0x9814C0;                          
        val_21 = 9966784;
        // 0x00B27F4C: CMP w27, w8                | STATE = COMPARE(0x1, 0x9814C0)          
        // 0x00B27F50: B.GE #0xb2800c             | if (val_20 >= val_21) goto label_10;    
        if(val_20 >= val_21)
        {
            goto label_10;
        }
        // 0x00B27F54: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
        // 0x00B27F58: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
        // 0x00B27F5C: SXTW x22, w27              | X22 = 1 (0x00000001);                   
        // 0x00B27F60: CMP w27, w8                | STATE = COMPARE(0x1, 0x9814C0)          
        // 0x00B27F64: LDR x9, [x9]               | X9 = typeof(AnimationRunner);           
        // 0x00B27F68: LDR x9, [x9, #0xa0]        | X9 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B27F6C: LDR x21, [x9]              | X21 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        // 0x00B27F70: B.LO #0xb27f84             | if (val_20 < val_21) goto label_11;     
        if(val_20 < val_21)
        {
            goto label_11;
        }
        // 0x00B27F74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B27F78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27F7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00B27F80: LDR x8, [x20, #0x18]       | X8 = 0x9814C0;                          
        val_21 = 9966784;
        label_11:
        // 0x00B27F84: ADD x23, x20, x22, lsl #2  | X23 = (val_19 + 4);                     
        var val_5 = val_19 + 4;
        // 0x00B27F88: LDR w22, [x23, #0x20]!     | W22 = (val_19 + 4) + 32;                
        // 0x00B27F8C: LDR x24, [x28]             | X24 = typeof(AnimationRunner.AniType);  
        // 0x00B27F90: CMP w27, w8                | STATE = COMPARE(0x1, 0x9814C0)          
        // 0x00B27F94: B.LO #0xb27fa4             | if (val_20 < val_21) goto label_12;     
        if(val_20 < val_21)
        {
            goto label_12;
        }
        // 0x00B27F98: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00B27F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27FA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_12:
        // 0x00B27FA4: MOV x0, x24                | X0 = 1152921504922341376 (0x1000000012CE1000);//ML01
        // 0x00B27FA8: MOV x1, x23                | X1 = (val_19 + 4) + 32;//m1             
        // 0x00B27FAC: BL #0x27bc028              | X0 = 1152921515541875344 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), (val_19 + 4) + 32);
        // 0x00B27FB0: MOV x25, x0                | X25 = 1152921515541875344 (0x100000028BC74A90);//ML01
        // 0x00B27FB4: CBNZ x25, #0xb27fbc        | if ((val_19 + 4) + 32 != 0) goto label_13;
        if(((val_19 + 4) + 32) != 0)
        {
            goto label_13;
        }
        // 0x00B27FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_19 + 4) + 32, ????);
        label_13:
        // 0x00B27FBC: LDR x8, [x25]              | X8 = typeof(AnimationRunner.AniType);   
        // 0x00B27FC0: MOV x0, x25                | X0 = 1152921515541875344 (0x100000028BC74A90);//ML01
        // 0x00B27FC4: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x00B27FC8: BLR x9                     | X0 = (val_19 + 4) + 32.ToString();      
        string val_6 = (val_19 + 4) + 32.ToString();
        // 0x00B27FCC: MOV x24, x0                | X24 = val_6;//m1                        
        // 0x00B27FD0: CBNZ x25, #0xb27fd8        | if ((val_19 + 4) + 32 != 0) goto label_14;
        if(((val_19 + 4) + 32) != 0)
        {
            goto label_14;
        }
        // 0x00B27FD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00B27FD8: MOV x0, x25                | X0 = 1152921515541875344 (0x100000028BC74A90);//ML01
        // 0x00B27FDC: BL #0x27bc4e8              | (val_19 + 4) + 32.System.IDisposable.Dispose();
        (val_19 + 4) + 32.System.IDisposable.Dispose();
        // 0x00B27FE0: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
        // 0x00B27FE4: LDR w25, [x0]              | W25 = typeof(AnimationRunner.AniType);  
        // 0x00B27FE8: CMP w27, w8                | STATE = COMPARE(0x1, 0x9814C0)          
        // 0x00B27FEC: B.LO #0xb27ffc             | if (val_20 < 9966784) goto label_15;    
        if(val_20 < 9966784)
        {
            goto label_15;
        }
        // 0x00B27FF0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (val_19 + 4) + 32, ????);
        // 0x00B27FF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27FF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_19 + 4) + 32, ????);
        label_15:
        // 0x00B27FFC: STR w25, [x23]             | mem2[0] = typeof(AnimationRunner.AniType);  //  dest_result_addr=0
        mem2[0] = null;
        // 0x00B28000: CBNZ x21, #0xb27f28        | if ( != 0) goto label_17;               
        if(null != 0)
        {
            goto label_17;
        }
        // 0x00B28004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_19 + 4) + 32, ????);
        // 0x00B28008: B #0xb27f28                |  goto label_17;                         
        goto label_17;
        label_10:
        // 0x00B2800C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28010: MOV x0, x19                | X0 = 1152921515541835152 (0x100000028BC6AD90);//ML01
        // 0x00B28014: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_7 = this.gameObject;
        // 0x00B28018: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B2801C: CBNZ x20, #0xb28024        | if (val_7 != null) goto label_18;       
        if(val_7 != null)
        {
            goto label_18;
        }
        // 0x00B28020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_18:
        // 0x00B28024: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00B28028: LDR x8, [x8, #0x630]       | X8 = 1152921515541670768;               
        // 0x00B2802C: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00B28030: LDR x1, [x8]               | X1 = public T[] UnityEngine.GameObject::GetComponentsInChildren<UnityEngine.Animation>();
        // 0x00B28034: BL #0x23d8d60              | X0 = val_7.GetComponentsInChildren<UnityEngine.Animation>();
        T[] val_8 = val_7.GetComponentsInChildren<UnityEngine.Animation>();
        // 0x00B28038: STR x0, [x19, #0x18]       | this.ani = val_8;                        //  dest_result_addr=1152921515541835176
        this.ani = val_8;
        // 0x00B2803C: CBZ x0, #0xb28294          | if (val_8 == null) goto label_20;       
        if(val_8 == null)
        {
            goto label_20;
        }
        // 0x00B28040: LDR w8, [x0, #0x18]        | W8 = val_8.Length; //P2                 
        // 0x00B28044: CBZ w8, #0xb28294          | if (val_8.Length == 0) goto label_20;   
        if(val_8.Length == 0)
        {
            goto label_20;
        }
        // 0x00B28048: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2804C: STRB w8, [x19, #0x58]      | this.isHaveAni = true;                   //  dest_result_addr=1152921515541835240
        this.isHaveAni = true;
        // 0x00B28050: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00B28054: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
        // 0x00B28058: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.String> val_9 = null;
        // 0x00B2805C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B28060: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B28064: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
        // 0x00B28068: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B2806C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
        // 0x00B28070: BL #0x25e9474              | .ctor();                                
        val_9 = new System.Collections.Generic.List<System.String>();
        // 0x00B28074: STR x20, [x19, #0x40]      | this.nameList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515541835216
        this.nameList = val_9;
        // 0x00B28078: ADRP x24, #0x361c000       | X24 = 56737792 (0x361C000);             
        // 0x00B2807C: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
        // 0x00B28080: ADRP x26, #0x35e6000       | X26 = 56516608 (0x35E6000);             
        // 0x00B28084: LDR x24, [x24, #0x358]     | X24 = 1152921504608018432;              
        // 0x00B28088: LDR x25, [x25, #0x990]     | X25 = 1152921504723460096;              
        // 0x00B2808C: LDR x26, [x26, #0x500]     | X26 = 1152921510890816336;              
        // 0x00B28090: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_22 = 0;
        // 0x00B28094: ORR w27, wzr, #0x3f800000  | W27 = 1065353216(0x3F800000);           
        val_20 = 1f;
        // 0x00B28098: B #0xb280a4                |  goto label_21;                         
        goto label_21;
        label_33:
        // 0x00B2809C: ADD w23, w23, #1           | W23 = (val_22 + 1) = val_22 (0x00000001);
        val_22 = 1;
        // 0x00B280A0: STR w27, [x19, #0x50]      | this.runSpeed = 1;                       //  dest_result_addr=1152921515541835232
        this.runSpeed = val_20;
        label_21:
        // 0x00B280A4: LDR x20, [x19, #0x18]      | X20 = this.ani; //P2                    
        // 0x00B280A8: CBNZ x20, #0xb280b0        | if (this.ani != null) goto label_22;    
        if(this.ani != null)
        {
            goto label_22;
        }
        // 0x00B280AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_22:
        // 0x00B280B0: LDR w8, [x20, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B280B4: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B280B8: B.GE #0xb28314             | if (val_22 >= this.ani.Length) goto label_23;
        if(val_22 >= this.ani.Length)
        {
            goto label_23;
        }
        // 0x00B280BC: LDR x20, [x19, #0x18]      | X20 = this.ani; //P2                    
        // 0x00B280C0: CBNZ x20, #0xb280c8        | if (this.ani != null) goto label_24;    
        if(this.ani != null)
        {
            goto label_24;
        }
        // 0x00B280C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_24:
        // 0x00B280C8: LDR w8, [x20, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B280CC: SXTW x21, w23              | X21 = 1 (0x00000001);                   
        // 0x00B280D0: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B280D4: B.LO #0xb280e4             | if (val_22 < this.ani.Length) goto label_25;
        if(val_22 < this.ani.Length)
        {
            goto label_25;
        }
        // 0x00B280D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
        // 0x00B280DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B280E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
        label_25:
        // 0x00B280E4: ADD x8, x20, x21, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B280E8: LDR x20, [x8, #0x20]       | X20 = this.ani[0x1][0]                  
        UnityEngine.Animation val_20 = this.ani[1];
        // 0x00B280EC: CBNZ x20, #0xb280f4        | if (this.ani[0x1][0] != null) goto label_26;
        if(val_20 != null)
        {
            goto label_26;
        }
        // 0x00B280F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_26:
        // 0x00B280F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B280F8: MOV x0, x20                | X0 = this.ani[0x1][0];//m1              
        // 0x00B280FC: BL #0x270cb80              | X0 = this.ani[0x1][0].GetEnumerator();  
        System.Collections.IEnumerator val_10 = val_20.GetEnumerator();
        // 0x00B28100: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B28104: B #0xb28118                |  goto label_27;                         
        goto label_27;
        label_44:
        // 0x00B28108: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B2810C: MOV x0, x21                | X0 = 1 (0x1);//ML01                     
        // 0x00B28110: MOV x1, x22                | X1 = X22;//m1                           
        // 0x00B28114: BL #0x25ea480              | 1.Add(item:  X22);                      
        1.Add(item:  X22);
        label_27:
        // 0x00B28118: CBNZ x20, #0xb28120        | if (val_10 != null) goto label_28;      
        if(val_10 != null)
        {
            goto label_28;
        }
        // 0x00B2811C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1, ????);        
        label_28:
        // 0x00B28120: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B28124: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B28128: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B2812C: CBZ x9, #0xb28158          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_29;
        // 0x00B28130: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B28134: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_21 = 0;
        // 0x00B28138: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_31:
        // 0x00B2813C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B28140: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B28144: B.EQ #0xb28168             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_30;
        // 0x00B28148: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_21 = val_21 + 1;
        // 0x00B2814C: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B28150: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B28154: B.LO #0xb2813c             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_31;
        label_29:
        // 0x00B28158: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B2815C: MOV x0, x20                | X0 = val_10;//m1                        
        val_23 = val_10;
        // 0x00B28160: BL #0x2776c24              | X0 = sub_2776C24( ?? val_10, ????);     
        // 0x00B28164: B #0xb28178                |  goto label_32;                         
        goto label_32;
        label_30:
        // 0x00B28168: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B2816C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
        // 0x00B28170: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
        // 0x00B28174: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
        label_32:
        // 0x00B28178: LDP x8, x1, [x0]           | X8 = 0x10102464C45; X1 = 0x300000000000000; //  | 
        // 0x00B2817C: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B28180: BLR x8                     | X0 = sub_10102464C45( ?? val_10, ????); 
        // 0x00B28184: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        System.Collections.IEnumerator val_12 = val_10 & 1;
        // 0x00B28188: TBZ w8, #0, #0xb2809c      | if (((val_10 & 1) & 0x1) == 0) goto label_33;
        if((val_12 & 1) == 0)
        {
            goto label_33;
        }
        // 0x00B2818C: LDR x21, [x19, #0x40]      | X21 = this.nameList; //P2               
        // 0x00B28190: CBNZ x20, #0xb28198        | if (val_10 != null) goto label_34;      
        if(val_10 != null)
        {
            goto label_34;
        }
        // 0x00B28194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_34:
        // 0x00B28198: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B2819C: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B281A0: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B281A4: CBZ x9, #0xb281d0          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_35;
        // 0x00B281A8: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B281AC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_22 = 0;
        // 0x00B281B0: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_37:
        // 0x00B281B4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B281B8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B281BC: B.EQ #0xb281e0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_36;
        // 0x00B281C0: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_22 = val_22 + 1;
        // 0x00B281C4: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B281C8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B281CC: B.LO #0xb281b4             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_37;
        label_35:
        // 0x00B281D0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B281D4: MOV x0, x20                | X0 = val_10;//m1                        
        val_24 = val_10;
        // 0x00B281D8: BL #0x2776c24              | X0 = sub_2776C24( ?? val_10, ????);     
        // 0x00B281DC: B #0xb281ec                |  goto label_38;                         
        goto label_38;
        label_36:
        // 0x00B281E0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B281E4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B281E8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_38:
        // 0x00B281EC: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B281F0: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B281F4: BLR x8                     | X0 = sub_100000000011E000( ?? val_10, ????);
        // 0x00B281F8: MOV x22, x0                | X22 = val_10;//m1                       
        val_25 = val_10;
        // 0x00B281FC: CBZ x22, #0xb28270         | if (val_10 == null) goto label_39;      
        if(val_25 == null)
        {
            goto label_39;
        }
        // 0x00B28200: LDR x1, [x25]              | X1 = typeof(UnityEngine.AnimationState);
        // 0x00B28204: LDR x8, [x22]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B28208: CMP x8, x1                 | STATE = COMPARE(typeof(System.Collections.IEnumerator), typeof(UnityEngine.AnimationState))
        // 0x00B2820C: B.EQ #0xb28238             | if (typeof(System.Collections.IEnumerator) == null) goto label_40;
        if(null == null)
        {
            goto label_40;
        }
        // 0x00B28210: LDR x0, [x8, #0x30]        | X0 = System.Collections.IEnumerator.__il2cppRuntimeField_element_class;
        // 0x00B28214: ADD x8, sp, #0x10          | X8 = (1152921515541823024 + 16) = 1152921515541823040 (0x100000028BC67E40);
        // 0x00B28218: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IEnumerator.__il2cppRuntimeField_element_class, ????);
        // 0x00B2821C: LDR x0, [sp, #0x10]        | X0 = val_14;                             //  find_add[1152921515541811152]
        // 0x00B28220: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
        // 0x00B28224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28228: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
        // 0x00B2822C: ADD x0, sp, #0x10          | X0 = (1152921515541823024 + 16) = 1152921515541823040 (0x100000028BC67E40);
        // 0x00B28230: BL #0x299a140              | 
        // 0x00B28234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000028BC67E40, ????);
        label_40:
        // 0x00B28238: LDR x1, [x25]              | X1 = typeof(UnityEngine.AnimationState);
        // 0x00B2823C: LDR x8, [x22]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B28240: CMP x8, x1                 | STATE = COMPARE(typeof(System.Collections.IEnumerator), typeof(UnityEngine.AnimationState))
        // 0x00B28244: B.EQ #0xb28278             | if (typeof(System.Collections.IEnumerator) == null) goto label_41;
        if(null == null)
        {
            goto label_41;
        }
        // 0x00B28248: LDR x0, [x8, #0x30]        | X0 = System.Collections.IEnumerator.__il2cppRuntimeField_element_class;
        // 0x00B2824C: ADD x8, sp, #0x18          | X8 = (1152921515541823024 + 24) = 1152921515541823048 (0x100000028BC67E48);
        // 0x00B28250: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IEnumerator.__il2cppRuntimeField_element_class, ????);
        // 0x00B28254: LDR x0, [sp, #0x18]        | X0 = val_15;                             //  find_add[1152921515541811152]
        // 0x00B28258: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
        // 0x00B2825C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28260: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        // 0x00B28264: ADD x0, sp, #0x18          | X0 = (1152921515541823024 + 24) = 1152921515541823048 (0x100000028BC67E48);
        // 0x00B28268: BL #0x299a140              | 
        // 0x00B2826C: B #0xb28274                |  goto label_42;                         
        goto label_42;
        label_39:
        // 0x00B28270: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_42:
        // 0x00B28274: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_25 = 0;
        label_41:
        // 0x00B28278: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2827C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
        // 0x00B28280: BL #0x270eda0              | X0 = val_25.get_name();                 
        string val_16 = val_25.name;
        // 0x00B28284: MOV x22, x0                | X22 = val_16;//m1                       
        // 0x00B28288: CBNZ x21, #0xb28108        | if (this.nameList != null) goto label_44;
        if(this.nameList != null)
        {
            goto label_44;
        }
        // 0x00B2828C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        // 0x00B28290: B #0xb28108                |  goto label_44;                         
        goto label_44;
        label_20:
        // 0x00B28294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28298: MOV x0, x19                | X0 = 1152921515541835152 (0x100000028BC6AD90);//ML01
        // 0x00B2829C: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_17 = this.gameObject;
        // 0x00B282A0: MOV x20, x0                | X20 = val_17;//m1                       
        // 0x00B282A4: CBNZ x20, #0xb282ac        | if (val_17 != null) goto label_45;      
        if(val_17 != null)
        {
            goto label_45;
        }
        // 0x00B282A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_45:
        // 0x00B282AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B282B0: MOV x0, x20                | X0 = val_17;//m1                        
        // 0x00B282B4: BL #0x1b759fc              | X0 = val_17.get_name();                 
        string val_18 = val_17.name;
        // 0x00B282B8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B282BC: LDR x8, [x8, #0xde0]       | X8 = (string**)(1152921515541806960)("{0}没有动作组件");
        // 0x00B282C0: MOV x2, x0                 | X2 = val_18;//m1                        
        // 0x00B282C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B282C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B282CC: LDR x1, [x8]               | X1 = "{0}没有动作组件";                       
        // 0x00B282D0: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "{0}没有动作组件");
        string val_19 = EString.EFormat(format:  0, arg0:  "{0}没有动作组件");
        // 0x00B282D4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B282D8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B282DC: MOV x20, x0                | X20 = val_19;//m1                       
        // 0x00B282E0: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B282E4: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B282E8: TBZ w9, #0, #0xb282fc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_47;
        // 0x00B282EC: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B282F0: CBNZ w9, #0xb282fc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
        // 0x00B282F4: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B282F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_47:
        // 0x00B282FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28300: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28304: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B28308: MOV x1, x20                | X1 = val_19;//m1                        
        // 0x00B2830C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_19);
        EDebug.Log(message:  0, isShowStack:  val_19);
        // 0x00B28310: STRB wzr, [x19, #0x58]     | this.isHaveAni = false;                  //  dest_result_addr=1152921515541835240
        this.isHaveAni = false;
        label_23:
        // 0x00B28314: SUB sp, x29, #0x50         | SP = (1152921515541823136 - 80) = 1152921515541823056 (0x100000028BC67E50);
        // 0x00B28318: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2831C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B28320: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B28324: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B28328: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B2832C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B28330: RET                        |  return;                                
        return;
        // 0x00B28334: MOV x19, x0                | 
        // 0x00B28338: ADD x0, sp, #0x10          | 
        // 0x00B2833C: B #0xb28348                | 
        // 0x00B28340: MOV x19, x0                | 
        // 0x00B28344: ADD x0, sp, #0x18          | 
        label_49:
        // 0x00B28348: BL #0x299a140              | 
        // 0x00B2834C: MOV x0, x19                | 
        // 0x00B28350: BL #0x980800               | 
        // 0x00B28354: MOV x19, x0                | 
        // 0x00B28358: ADD x0, sp, #8             | 
        // 0x00B2835C: B #0xb28348                | 
    
    }
    //
    // Offset in libil2cpp.so: 0x00B28360 (11699040), len: 188  VirtAddr: 0x00B28360 RVA: 0x00B28360 token: 100696513 methodIndex: 24833 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        // 0x00B28360: STP x22, x21, [sp, #-0x30]! | stack[1152921515542107136] = ???;  stack[1152921515542107144] = ???;  //  dest_result_addr=1152921515542107136 |  dest_result_addr=1152921515542107144
        // 0x00B28364: STP x20, x19, [sp, #0x10]  | stack[1152921515542107152] = ???;  stack[1152921515542107160] = ???;  //  dest_result_addr=1152921515542107152 |  dest_result_addr=1152921515542107160
        // 0x00B28368: STP x29, x30, [sp, #0x20]  | stack[1152921515542107168] = ???;  stack[1152921515542107176] = ???;  //  dest_result_addr=1152921515542107168 |  dest_result_addr=1152921515542107176
        // 0x00B2836C: ADD x29, sp, #0x20         | X29 = (1152921515542107136 + 32) = 1152921515542107168 (0x100000028BCAD420);
        // 0x00B28370: MOV x19, x0                | X19 = 1152921515542119184 (0x100000028BCB0310);//ML01
        // 0x00B28374: LDRB w8, [x19, #0x58]      | W8 = this.isHaveAni; //P2               
        // 0x00B28378: CBZ w8, #0xb28398          | if (this.isHaveAni == false) goto label_0;
        if(this.isHaveAni == false)
        {
            goto label_0;
        }
        // 0x00B2837C: LDR x1, [x19, #0x48]       | X1 = this.curstate; //P2                
        // 0x00B28380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28388: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B2838C: BL #0x26923b8              | X0 = UnityEngine.TrackedReference.op_Equality(x:  0, y:  this.curstate);
        bool val_1 = UnityEngine.TrackedReference.op_Equality(x:  0, y:  this.curstate);
        // 0x00B28390: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B28394: TBZ w8, #0, #0xb283a8      | if ((val_1 & 1) == false) goto label_1; 
        if(val_2 == false)
        {
            goto label_1;
        }
        label_0:
        // 0x00B28398: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2839C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B283A0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B283A4: RET                        |  return;                                
        return;
        label_1:
        // 0x00B283A8: LDRB w21, [x19, #0x59]     | W21 = this.isSkillFrozen; //P2          
        // 0x00B283AC: LDR x20, [x19, #0x48]      | X20 = this.curstate; //P2               
        // 0x00B283B0: CBNZ x20, #0xb283b8        | if (this.curstate != null) goto label_2;
        if(this.curstate != null)
        {
            goto label_2;
        }
        // 0x00B283B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B283B8: CBZ w21, #0xb283d8         | if (this.isSkillFrozen == false) goto label_3;
        if(this.isSkillFrozen == false)
        {
            goto label_3;
        }
        // 0x00B283BC: MOV x0, x20                | X0 = this.curstate;//m1                 
        // 0x00B283C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B283C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B283C8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B283CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B283D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B283D4: B #0x270e5a0               | this.curstate.set_enabled(value:  false); return;
        this.curstate.enabled = false;
        return;
        label_3:
        // 0x00B283D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B283DC: MOV x0, x20                | X0 = this.curstate;//m1                 
        // 0x00B283E0: BL #0x270e538              | X0 = this.curstate.get_enabled();       
        bool val_3 = this.curstate.enabled;
        // 0x00B283E4: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B283E8: TBNZ w8, #0, #0xb28408     | if ((val_3 & 1) == true) goto label_4;  
        if(val_4 == true)
        {
            goto label_4;
        }
        // 0x00B283EC: LDR x20, [x19, #0x48]      | X20 = this.curstate; //P2               
        // 0x00B283F0: CBNZ x20, #0xb283f8        | if (this.curstate != null) goto label_5;
        if(this.curstate != null)
        {
            goto label_5;
        }
        // 0x00B283F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B283F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B283FC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B28400: MOV x0, x20                | X0 = this.curstate;//m1                 
        // 0x00B28404: BL #0x270e5a0              | this.curstate.set_enabled(value:  true);
        this.curstate.enabled = true;
        label_4:
        // 0x00B28408: MOV x0, x19                | X0 = 1152921515542119184 (0x100000028BCB0310);//ML01
        // 0x00B2840C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28410: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B28414: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B28418: B #0xb2841c                | this.playOver(); return;                
        this.playOver();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B28578 (11699576), len: 8  VirtAddr: 0x00B28578 RVA: 0x00B28578 token: 100696514 methodIndex: 24834 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetRunSpeed(float runSpeed)
    {
        //
        // Disasemble & Code
        // 0x00B28578: STR s0, [x0, #0x50]        | this.runSpeed = runSpeed;                //  dest_result_addr=1152921515542243552
        this.runSpeed = runSpeed;
        // 0x00B2857C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B28580 (11699584), len: 120  VirtAddr: 0x00B28580 RVA: 0x00B28580 token: 100696515 methodIndex: 24835 delegateWrapperIndex: 0 methodInvoker: 0
    public bool HasExistAni(string name)
    {
        //
        // Disasemble & Code
        // 0x00B28580: STP x22, x21, [sp, #-0x30]! | stack[1152921515542351616] = ???;  stack[1152921515542351624] = ???;  //  dest_result_addr=1152921515542351616 |  dest_result_addr=1152921515542351624
        // 0x00B28584: STP x20, x19, [sp, #0x10]  | stack[1152921515542351632] = ???;  stack[1152921515542351640] = ???;  //  dest_result_addr=1152921515542351632 |  dest_result_addr=1152921515542351640
        // 0x00B28588: STP x29, x30, [sp, #0x20]  | stack[1152921515542351648] = ???;  stack[1152921515542351656] = ???;  //  dest_result_addr=1152921515542351648 |  dest_result_addr=1152921515542351656
        // 0x00B2858C: ADD x29, sp, #0x20         | X29 = (1152921515542351616 + 32) = 1152921515542351648 (0x100000028BCE8F20);
        // 0x00B28590: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B28594: LDRB w8, [x21, #0x752]     | W8 = (bool)static_value_03733752;       
        // 0x00B28598: MOV x19, x1                | X19 = name;//m1                         
        // 0x00B2859C: MOV x20, x0                | X20 = 1152921515542363664 (0x100000028BCEBE10);//ML01
        // 0x00B285A0: TBNZ w8, #0, #0xb285bc     | if (static_value_03733752 == true) goto label_0;
        // 0x00B285A4: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00B285A8: LDR x8, [x8, #0x790]       | X8 = 0x2B8AEE8;                         
        // 0x00B285AC: LDR w0, [x8]               | W0 = 0x278;                             
        // 0x00B285B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x278, ????);      
        // 0x00B285B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B285B8: STRB w8, [x21, #0x752]     | static_value_03733752 = true;            //  dest_result_addr=57882450
        label_0:
        // 0x00B285BC: LDR x20, [x20, #0x40]      | X20 = this.nameList; //P2               
        // 0x00B285C0: CBNZ x20, #0xb285c8        | if (this.nameList != null) goto label_1;
        if(this.nameList != null)
        {
            goto label_1;
        }
        // 0x00B285C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x278, ????);      
        label_1:
        // 0x00B285C8: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B285CC: LDR x8, [x8, #0x780]       | X8 = 1152921510892731984;               
        // 0x00B285D0: MOV x0, x20                | X0 = this.nameList;//m1                 
        // 0x00B285D4: MOV x1, x19                | X1 = name;//m1                          
        // 0x00B285D8: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.String>::IndexOf(System.String item);
        // 0x00B285DC: BL #0x25ec03c              | X0 = this.nameList.IndexOf(item:  name);
        int val_1 = this.nameList.IndexOf(item:  name);
        // 0x00B285E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B285E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B285E8: CMP w0, #0                 | STATE = COMPARE(val_1, 0x0)             
        // 0x00B285EC: CSET w0, ge                | W0 = val_1 >= 0 ? 1 : 0;                
        var val_2 = (val_1 >= 0) ? 1 : 0;
        // 0x00B285F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B285F4: RET                        |  return (System.Boolean)val_1 >= 0 ? 1 : 0;
        return (bool)val_2;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B285F8 (11699704), len: 1276  VirtAddr: 0x00B285F8 RVA: 0x00B285F8 token: 100696516 methodIndex: 24836 delegateWrapperIndex: 0 methodInvoker: 0
    public void Play(string aniName, float playTime = 0, bool isSkill = False)
    {
        //
        // Disasemble & Code
        //  | 
        string val_18;
        //  | 
        float val_19;
        //  | 
        System.Object[] val_20;
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        var val_23;
        // 0x00B285F8: STP d9, d8, [sp, #-0x70]!  | stack[1152921515542759488] = ???;  stack[1152921515542759496] = ???;  //  dest_result_addr=1152921515542759488 |  dest_result_addr=1152921515542759496
        // 0x00B285FC: STP x28, x27, [sp, #0x10]  | stack[1152921515542759504] = ???;  stack[1152921515542759512] = ???;  //  dest_result_addr=1152921515542759504 |  dest_result_addr=1152921515542759512
        // 0x00B28600: STP x26, x25, [sp, #0x20]  | stack[1152921515542759520] = ???;  stack[1152921515542759528] = ???;  //  dest_result_addr=1152921515542759520 |  dest_result_addr=1152921515542759528
        // 0x00B28604: STP x24, x23, [sp, #0x30]  | stack[1152921515542759536] = ???;  stack[1152921515542759544] = ???;  //  dest_result_addr=1152921515542759536 |  dest_result_addr=1152921515542759544
        // 0x00B28608: STP x22, x21, [sp, #0x40]  | stack[1152921515542759552] = ???;  stack[1152921515542759560] = ???;  //  dest_result_addr=1152921515542759552 |  dest_result_addr=1152921515542759560
        // 0x00B2860C: STP x20, x19, [sp, #0x50]  | stack[1152921515542759568] = ???;  stack[1152921515542759576] = ???;  //  dest_result_addr=1152921515542759568 |  dest_result_addr=1152921515542759576
        // 0x00B28610: STP x29, x30, [sp, #0x60]  | stack[1152921515542759584] = ???;  stack[1152921515542759592] = ???;  //  dest_result_addr=1152921515542759584 |  dest_result_addr=1152921515542759592
        // 0x00B28614: ADD x29, sp, #0x60         | X29 = (1152921515542759488 + 96) = 1152921515542759584 (0x100000028BD4C8A0);
        // 0x00B28618: SUB sp, sp, #0x10          | SP = (1152921515542759488 - 16) = 1152921515542759472 (0x100000028BD4C830);
        // 0x00B2861C: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B28620: LDRB w8, [x22, #0x753]     | W8 = (bool)static_value_03733753;       
        // 0x00B28624: MOV w21, w2                | W21 = isSkill;//m1                      
        val_18 = isSkill;
        // 0x00B28628: MOV v8.16b, v0.16b         | V8 = playTime;//m1                      
        val_19 = playTime;
        // 0x00B2862C: MOV x19, x1                | X19 = aniName;//m1                      
        // 0x00B28630: MOV x20, x0                | X20 = 1152921515542771600 (0x100000028BD4F790);//ML01
        // 0x00B28634: TBNZ w8, #0, #0xb28650     | if (static_value_03733753 == true) goto label_0;
        // 0x00B28638: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B2863C: LDR x8, [x8, #0xdd0]       | X8 = 0x2B8AEF0;                         
        // 0x00B28640: LDR w0, [x8]               | W0 = 0x27A;                             
        // 0x00B28644: BL #0x2782188              | X0 = sub_2782188( ?? 0x27A, ????);      
        // 0x00B28648: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2864C: STRB w8, [x22, #0x753]     | static_value_03733753 = true;            //  dest_result_addr=57882451
        label_0:
        // 0x00B28650: LDRB w8, [x20, #0x58]      | W8 = this.isHaveAni; //P2               
        // 0x00B28654: CBZ w8, #0xb28ad0          | if (this.isHaveAni == false) goto label_40;
        if(this.isHaveAni == false)
        {
            goto label_40;
        }
        // 0x00B28658: ADRP x23, #0x364f000       | X23 = 56946688 (0x364F000);             
        // 0x00B2865C: LDR x23, [x23, #0x188]     | X23 = 1152921504922288128;              
        val_20 = 1152921504922288128;
        // 0x00B28660: LDR x8, [x23]              | X8 = typeof(AnimationRunner);           
        // 0x00B28664: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B28668: LDR x22, [x8]              | X22 = AnimationRunner.AniTypeDic;       
        // 0x00B2866C: CBNZ x22, #0xb28674        | if (AnimationRunner.AniTypeDic != null) goto label_2;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_2;
        }
        // 0x00B28670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x27A, ????);      
        label_2:
        // 0x00B28674: ADRP x24, #0x35c4000       | X24 = 56377344 (0x35C4000);             
        // 0x00B28678: LDR x24, [x24, #0x150]     | X24 = 1152921515542463952;              
        // 0x00B2867C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B28680: MOV x0, x22                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B28684: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B28688: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  0);
        string val_1 = AnimationRunner.AniTypeDic.Item[0];
        // 0x00B2868C: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00B28690: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        // 0x00B28694: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00B28698: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B2869C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B286A0: TBZ w9, #0, #0xb286b4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B286A4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B286A8: CBNZ w9, #0xb286b4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B286AC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B286B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x00B286B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B286B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B286BC: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B286C0: MOV x2, x22                | X2 = val_1;//m1                         
        // 0x00B286C4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  aniName);
        bool val_2 = System.String.op_Equality(a:  0, b:  aniName);
        // 0x00B286C8: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B286CC: TBNZ w8, #0, #0xb28ad0     | if ((val_2 & 1) == true) goto label_40; 
        if(val_3 == true)
        {
            goto label_40;
        }
        // 0x00B286D0: MOV x0, x20                | X0 = 1152921515542771600 (0x100000028BD4F790);//ML01
        // 0x00B286D4: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B286D8: BL #0xb28580               | X0 = this.HasExistAni(name:  aniName);  
        bool val_4 = this.HasExistAni(name:  aniName);
        // 0x00B286DC: TBZ w0, #0, #0xb28ad0      | if (val_4 == false) goto label_40;      
        if(val_4 == false)
        {
            goto label_40;
        }
        // 0x00B286E0: MOV v0.16b, v8.16b         | V0 = playTime;//m1                      
        // 0x00B286E4: FCMP s8, #0.0              | STATE = COMPARE(playTime, 0)            
        // 0x00B286E8: B.NE #0xb286f8             | if (val_19 != 0) goto label_7;          
        if(val_19 != 0f)
        {
            goto label_7;
        }
        // 0x00B286EC: MOV x0, x20                | X0 = 1152921515542771600 (0x100000028BD4F790);//ML01
        // 0x00B286F0: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B286F4: BL #0xb28af4               | X0 = this.GetActionTime(aniName:  aniName);
        float val_5 = this.GetActionTime(aniName:  aniName);
        label_7:
        // 0x00B286F8: STR s0, [x20, #0x54]       | this._playTime = val_5;                  //  dest_result_addr=1152921515542771684
        this._playTime = val_5;
        // 0x00B286FC: LDR x8, [x23]              | X8 = typeof(AnimationRunner);           
        // 0x00B28700: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B28704: LDR x22, [x8]              | X22 = AnimationRunner.AniTypeDic;       
        // 0x00B28708: CBNZ x22, #0xb28710        | if (AnimationRunner.AniTypeDic != null) goto label_8;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_8;
        }
        // 0x00B2870C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_8:
        // 0x00B28710: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B28714: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B28718: MOV x0, x22                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B2871C: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  3);
        string val_6 = AnimationRunner.AniTypeDic.Item[3];
        // 0x00B28720: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B28724: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B28728: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B2872C: TBZ w9, #0, #0xb28740      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B28730: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28734: CBNZ w9, #0xb28740         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B28738: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B2873C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_10:
        // 0x00B28740: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28744: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28748: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B2874C: MOV x2, x22                | X2 = val_6;//m1                         
        // 0x00B28750: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  aniName);
        bool val_7 = System.String.op_Equality(a:  0, b:  aniName);
        // 0x00B28754: TBZ w0, #0, #0xb287e8      | if (val_7 == false) goto label_11;      
        if(val_7 == false)
        {
            goto label_11;
        }
        // 0x00B28758: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
        val_22 = 0;
        // 0x00B2875C: B #0xb28774                |  goto label_12;                         
        goto label_12;
        label_19:
        // 0x00B28760: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28764: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B28768: MOV v0.16b, v9.16b         | V0 = V9.16B;//m1                        
        // 0x00B2876C: BL #0x270ea00              | val_6.set_speed(value:  V9.16B);        
        val_6.speed = V9.16B;
        // 0x00B28770: ADD w26, w26, #1           | W26 = (val_22 + 1) = val_22 (0x00000001);
        val_22 = 1;
        label_12:
        // 0x00B28774: LDR x22, [x20, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B28778: CBNZ x22, #0xb28780        | if (this.ani != null) goto label_13;    
        if(this.ani != null)
        {
            goto label_13;
        }
        // 0x00B2877C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_13:
        // 0x00B28780: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28784: CMP w26, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28788: B.GE #0xb28818             | if (val_22 >= this.ani.Length) goto label_20;
        if(val_22 >= this.ani.Length)
        {
            goto label_20;
        }
        // 0x00B2878C: LDR x22, [x20, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B28790: CBNZ x22, #0xb28798        | if (this.ani != null) goto label_15;    
        if(this.ani != null)
        {
            goto label_15;
        }
        // 0x00B28794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_15:
        // 0x00B28798: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B2879C: SXTW x27, w26              | X27 = 1 (0x00000001);                   
        // 0x00B287A0: CMP w26, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B287A4: B.LO #0xb287b4             | if (val_22 < this.ani.Length) goto label_16;
        if(val_22 < this.ani.Length)
        {
            goto label_16;
        }
        // 0x00B287A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B287AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B287B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_16:
        // 0x00B287B4: ADD x8, x22, x27, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B287B8: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_18 = this.ani[1];
        // 0x00B287BC: CBNZ x22, #0xb287c4        | if (this.ani[0x1][0] != null) goto label_17;
        if(val_18 != null)
        {
            goto label_17;
        }
        // 0x00B287C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_17:
        // 0x00B287C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B287C8: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B287CC: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B287D0: BL #0x270c494              | X0 = this.ani[0x1][0].get_Item(name:  aniName);
        UnityEngine.AnimationState val_8 = val_18.Item[aniName];
        // 0x00B287D4: LDR s9, [x20, #0x50]       | S9 = this.runSpeed; //P2                
        // 0x00B287D8: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B287DC: CBNZ x22, #0xb28760        | if (val_8 != null) goto label_19;       
        if(val_8 != null)
        {
            goto label_19;
        }
        // 0x00B287E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        // 0x00B287E4: B #0xb28760                |  goto label_19;                         
        goto label_19;
        label_11:
        // 0x00B287E8: FCMP s8, #0.0              | STATE = COMPARE(playTime, 0)            
        // 0x00B287EC: B.LE #0xb28818             | if (val_19 <= 0) goto label_20;         
        if(val_19 <= 0f)
        {
            goto label_20;
        }
        // 0x00B287F0: LDR x22, [x20, #0x38]      | X22 = this.unit; //P2                   
        // 0x00B287F4: CBNZ x22, #0xb287fc        | if (this.unit != null) goto label_21;   
        if(this.unit != null)
        {
            goto label_21;
        }
        // 0x00B287F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_21:
        // 0x00B287FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28800: MOV x0, x22                | X0 = this.unit;//m1                     
        // 0x00B28804: BL #0xd97958               | X0 = this.unit.get_atkSpeed();          
        float val_9 = this.unit.atkSpeed;
        // 0x00B28808: FMUL s0, s0, s8            | S0 = (val_9 * playTime);                
        val_9 = val_9 * val_19;
        // 0x00B2880C: MOV x0, x20                | X0 = 1152921515542771600 (0x100000028BD4F790);//ML01
        // 0x00B28810: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28814: BL #0xb28b7c               | this.SetActionTime(aniName:  aniName, playTime:  val_9 = val_9 * val_19);
        this.SetActionTime(aniName:  aniName, playTime:  val_9);
        label_20:
        // 0x00B28818: AND w8, w21, #1            | W8 = (isSkill & 1);                     
        bool val_10 = val_18;
        // 0x00B2881C: TBNZ w8, #0, #0xb288b8     | if ((isSkill & 1) == true) goto label_25;
        if(val_10 == true)
        {
            goto label_25;
        }
        // 0x00B28820: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B28824: LDR x21, [x20, #0x28]      | X21 = this.aniName; //P2                
        // 0x00B28828: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B2882C: TBZ w8, #0, #0xb2883c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x00B28830: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28834: CBNZ w8, #0xb2883c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x00B28838: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_24:
        // 0x00B2883C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28840: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28844: MOV x1, x21                | X1 = this.aniName;//m1                  
        // 0x00B28848: MOV x2, x19                | X2 = aniName;//m1                       
        // 0x00B2884C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.aniName);
        bool val_11 = System.String.op_Equality(a:  0, b:  this.aniName);
        // 0x00B28850: TBZ w0, #0, #0xb288b8      | if (val_11 == false) goto label_25;     
        if(val_11 == false)
        {
            goto label_25;
        }
        // 0x00B28854: LDR x8, [x23]              | X8 = typeof(AnimationRunner);           
        // 0x00B28858: LDR x21, [x20, #0x28]      | X21 = this.aniName; //P2                
        val_18 = this.aniName;
        // 0x00B2885C: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B28860: LDR x22, [x8]              | X22 = AnimationRunner.AniTypeDic;       
        // 0x00B28864: CBNZ x22, #0xb2886c        | if (AnimationRunner.AniTypeDic != null) goto label_26;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_26;
        }
        // 0x00B28868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_26:
        // 0x00B2886C: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B28870: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00B28874: MOV x0, x22                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B28878: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  4);
        string val_12 = AnimationRunner.AniTypeDic.Item[4];
        // 0x00B2887C: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B28880: MOV x22, x0                | X22 = val_12;//m1                       
        // 0x00B28884: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28888: TBZ w9, #0, #0xb2889c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x00B2888C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28890: CBNZ w9, #0xb2889c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x00B28894: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B28898: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_28:
        // 0x00B2889C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B288A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B288A4: MOV x1, x21                | X1 = this.aniName;//m1                  
        // 0x00B288A8: MOV x2, x22                | X2 = val_12;//m1                        
        // 0x00B288AC: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_18);
        bool val_13 = System.String.op_Inequality(a:  0, b:  val_18);
        // 0x00B288B0: AND w8, w0, #1             | W8 = (val_13 & 1);                      
        bool val_14 = val_13;
        // 0x00B288B4: TBNZ w8, #0, #0xb28ad0     | if ((val_13 & 1) == true) goto label_40;
        if(val_14 == true)
        {
            goto label_40;
        }
        label_25:
        // 0x00B288B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B288BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B288C0: BL #0xc9b08c               | X0 = ReplayMgr.get_Instance();          
        ReplayMgr val_15 = ReplayMgr.Instance;
        // 0x00B288C4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B288C8: LDR x21, [x20, #0x38]      | X21 = this.unit; //P2                   
        // 0x00B288CC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B288D0: MOV x22, x0                | X22 = val_15;//m1                       
        // 0x00B288D4: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x00B288D8: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B288DC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B288E0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B288E4: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B288E8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B288EC: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_20 = null;
        // 0x00B288F0: CBNZ x23, #0xb288f8        | if ( != null) goto label_30;            
        if(null != null)
        {
            goto label_30;
        }
        // 0x00B288F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_30:
        // 0x00B288F8: CBZ x19, #0xb2891c         | if (aniName == null) goto label_32;     
        if(aniName == null)
        {
            goto label_32;
        }
        // 0x00B288FC: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B28900: MOV x0, x19                | X0 = aniName;//m1                       
        // 0x00B28904: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B28908: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? aniName, ????);    
        // 0x00B2890C: CBNZ x0, #0xb2891c         | if (aniName != null) goto label_32;     
        if(aniName != null)
        {
            goto label_32;
        }
        // 0x00B28910: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? aniName, ????);    
        // 0x00B28914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28918: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? aniName, ????);    
        label_32:
        // 0x00B2891C: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B28920: CBNZ w8, #0xb28930         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_33;
        // 0x00B28924: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? aniName, ????);    
        // 0x00B28928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2892C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? aniName, ????);    
        label_33:
        // 0x00B28930: STR x19, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = aniName;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = aniName;
        // 0x00B28934: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B28938: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00B2893C: ADD x1, sp, #0xc           | X1 = (1152921515542759472 + 12) = 1152921515542759484 (0x100000028BD4C83C);
        // 0x00B28940: STR s8, [sp, #0xc]         | stack[1152921515542759484] = playTime;   //  dest_result_addr=1152921515542759484
        // 0x00B28944: LDR x0, [x8]               | X0 = typeof(System.Single);             
        // 0x00B28948: BL #0x27bc028              | X0 = 1152921515542922384 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), playTime);
        // 0x00B2894C: MOV x24, x0                | X24 = 1152921515542922384 (0x100000028BD74490);//ML01
        // 0x00B28950: CBZ x24, #0xb28974         | if (playTime == 0) goto label_35;       
        if(val_19 == 0)
        {
            goto label_35;
        }
        // 0x00B28954: LDR x8, [x23]              | X8 = ;                                  
        // 0x00B28958: MOV x0, x24                | X0 = 1152921515542922384 (0x100000028BD74490);//ML01
        // 0x00B2895C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B28960: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? playTime, ????);   
        // 0x00B28964: CBNZ x0, #0xb28974         | if (playTime != 0) goto label_35;       
        if(val_19 != 0)
        {
            goto label_35;
        }
        // 0x00B28968: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? playTime, ????);   
        // 0x00B2896C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28970: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? playTime, ????);   
        label_35:
        // 0x00B28974: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B28978: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B2897C: B.HI #0xb2898c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_36;
        // 0x00B28980: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? playTime, ????);   
        // 0x00B28984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28988: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? playTime, ????);   
        label_36:
        // 0x00B2898C: STR x24, [x23, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = playTime; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_19;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B28990: CBNZ x22, #0xb28998        | if (val_15 != null) goto label_37;      
        if(val_15 != null)
        {
            goto label_37;
        }
        // 0x00B28994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? playTime, ????);   
        label_37:
        // 0x00B28998: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B2899C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B289A0: MOV x0, x22                | X0 = val_15;//m1                        
        // 0x00B289A4: MOV x2, x21                | X2 = this.unit;//m1                     
        // 0x00B289A8: MOV x3, x23                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B289AC: BL #0xc9c41c               | val_15.AddData(type:  2, entity:  this.unit, datas:  val_20);
        val_15.AddData(type:  2, entity:  this.unit, datas:  val_20);
        // 0x00B289B0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_23 = 0;
        // 0x00B289B4: STP x19, x19, [x20, #0x28] | this.aniName = aniName;  this.curAniName = aniName;  //  dest_result_addr=1152921515542771640 |  dest_result_addr=1152921515542771648
        this.aniName = aniName;
        this.curAniName = aniName;
        // 0x00B289B8: FMOV s8, wzr               | S8 = 0f;                                
        val_19 = 0f;
        // 0x00B289BC: B #0xb289d4                |  goto label_38;                         
        goto label_38;
        label_51:
        // 0x00B289C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B289C4: MOV x0, x21                | X0 = this.unit;//m1                     
        // 0x00B289C8: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B289CC: BL #0x270c614              | X0 = this.unit.Play(animation:  aniName);
        bool val_16 = this.unit.Play(animation:  aniName);
        // 0x00B289D0: ADD w22, w22, #1           | W22 = (val_23 + 1) = val_23 (0x00000001);
        val_23 = 1;
        label_38:
        // 0x00B289D4: LDR x21, [x20, #0x18]      | X21 = this.ani; //P2                    
        val_18 = this.ani;
        // 0x00B289D8: CBNZ x21, #0xb289e0        | if (this.ani != null) goto label_39;    
        if(val_18 != null)
        {
            goto label_39;
        }
        // 0x00B289DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_39:
        // 0x00B289E0: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B289E4: CMP w22, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B289E8: B.GE #0xb28ad0             | if (val_23 >= this.ani.Length) goto label_40;
        if(val_23 >= this.ani.Length)
        {
            goto label_40;
        }
        // 0x00B289EC: LDR x21, [x20, #0x18]      | X21 = this.ani; //P2                    
        // 0x00B289F0: CBNZ x21, #0xb289f8        | if (this.ani != null) goto label_41;    
        if(this.ani != null)
        {
            goto label_41;
        }
        // 0x00B289F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_41:
        // 0x00B289F8: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B289FC: SXTW x23, w22              | X23 = 1 (0x00000001);                   
        // 0x00B28A00: CMP w22, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28A04: B.LO #0xb28a14             | if (val_23 < this.ani.Length) goto label_42;
        if(val_23 < this.ani.Length)
        {
            goto label_42;
        }
        // 0x00B28A08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
        // 0x00B28A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28A10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
        label_42:
        // 0x00B28A14: ADD x8, x21, x23, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B28A18: LDR x21, [x8, #0x20]       | X21 = this.ani[0x1][0]                  
        UnityEngine.Animation val_19 = this.ani[1];
        // 0x00B28A1C: CBNZ x21, #0xb28a24        | if (this.ani[0x1][0] != null) goto label_43;
        if(val_19 != null)
        {
            goto label_43;
        }
        // 0x00B28A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_43:
        // 0x00B28A24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28A28: MOV x0, x21                | X0 = this.ani[0x1][0];//m1              
        // 0x00B28A2C: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28A30: BL #0x270c6b4              | this.ani[0x1][0].CrossFade(animation:  aniName);
        val_19.CrossFade(animation:  aniName);
        // 0x00B28A34: LDR x21, [x20, #0x18]      | X21 = this.ani; //P2                    
        // 0x00B28A38: CBNZ x21, #0xb28a40        | if (this.ani != null) goto label_44;    
        if(this.ani != null)
        {
            goto label_44;
        }
        // 0x00B28A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ani[0x1][0], ????);
        label_44:
        // 0x00B28A40: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28A44: CMP w22, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28A48: B.LO #0xb28a58             | if (val_23 < this.ani.Length) goto label_45;
        if(val_23 < this.ani.Length)
        {
            goto label_45;
        }
        // 0x00B28A4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.ani[0x1][0], ????);
        // 0x00B28A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28A54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.ani[0x1][0], ????);
        label_45:
        // 0x00B28A58: ADD x8, x21, x23, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B28A5C: LDR x21, [x8, #0x20]       | X21 = this.ani[0x1][0]                  
        UnityEngine.Animation val_20 = this.ani[1];
        // 0x00B28A60: CBNZ x21, #0xb28a68        | if (this.ani[0x1][0] != null) goto label_46;
        if(val_20 != null)
        {
            goto label_46;
        }
        // 0x00B28A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ani[0x1][0], ????);
        label_46:
        // 0x00B28A68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28A6C: MOV x0, x21                | X0 = this.ani[0x1][0];//m1              
        // 0x00B28A70: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28A74: BL #0x270c494              | X0 = this.ani[0x1][0].get_Item(name:  aniName);
        UnityEngine.AnimationState val_17 = val_20.Item[aniName];
        // 0x00B28A78: MOV x21, x0                | X21 = val_17;//m1                       
        // 0x00B28A7C: STR x21, [x20, #0x48]      | this.curstate = val_17;                  //  dest_result_addr=1152921515542771672
        this.curstate = val_17;
        // 0x00B28A80: CBNZ x21, #0xb28a88        | if (val_17 != null) goto label_47;      
        if(val_17 != null)
        {
            goto label_47;
        }
        // 0x00B28A84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_47:
        // 0x00B28A88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28A8C: MOV x0, x21                | X0 = val_17;//m1                        
        // 0x00B28A90: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B28A94: BL #0x270e840              | val_17.set_time(value:  val_19);        
        val_17.time = val_19;
        // 0x00B28A98: LDR x21, [x20, #0x18]      | X21 = this.ani; //P2                    
        // 0x00B28A9C: CBNZ x21, #0xb28aa4        | if (this.ani != null) goto label_48;    
        if(this.ani != null)
        {
            goto label_48;
        }
        // 0x00B28AA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_48:
        // 0x00B28AA4: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28AA8: CMP w22, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28AAC: B.LO #0xb28abc             | if (val_23 < this.ani.Length) goto label_49;
        if(val_23 < this.ani.Length)
        {
            goto label_49;
        }
        // 0x00B28AB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
        // 0x00B28AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28AB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
        label_49:
        // 0x00B28ABC: ADD x8, x21, x23, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B28AC0: LDR x21, [x8, #0x20]       | X21 = this.ani[0x1][0]                  
        UnityEngine.Animation val_21 = this.ani[1];
        // 0x00B28AC4: CBNZ x21, #0xb289c0        | if (this.ani[0x1][0] != null) goto label_51;
        if(val_21 != null)
        {
            goto label_51;
        }
        // 0x00B28AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00B28ACC: B #0xb289c0                |  goto label_51;                         
        goto label_51;
        label_40:
        // 0x00B28AD0: SUB sp, x29, #0x60         | SP = (1152921515542759584 - 96) = 1152921515542759488 (0x100000028BD4C840);
        // 0x00B28AD4: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28AD8: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B28ADC: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B28AE0: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B28AE4: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B28AE8: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B28AEC: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B28AF0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B28C84 (11701380), len: 1904  VirtAddr: 0x00B28C84 RVA: 0x00B28C84 token: 100696517 methodIndex: 24837 delegateWrapperIndex: 0 methodInvoker: 0
    public void Play(bool isLoop, string aniName, float playTime = 0)
    {
        //
        // Disasemble & Code
        //  | 
        float val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        //  | 
        var val_26;
        // 0x00B28C84: STP d9, d8, [sp, #-0x70]!  | stack[1152921515543588672] = ???;  stack[1152921515543588680] = ???;  //  dest_result_addr=1152921515543588672 |  dest_result_addr=1152921515543588680
        // 0x00B28C88: STP x28, x27, [sp, #0x10]  | stack[1152921515543588688] = ???;  stack[1152921515543588696] = ???;  //  dest_result_addr=1152921515543588688 |  dest_result_addr=1152921515543588696
        // 0x00B28C8C: STP x26, x25, [sp, #0x20]  | stack[1152921515543588704] = ???;  stack[1152921515543588712] = ???;  //  dest_result_addr=1152921515543588704 |  dest_result_addr=1152921515543588712
        // 0x00B28C90: STP x24, x23, [sp, #0x30]  | stack[1152921515543588720] = ???;  stack[1152921515543588728] = ???;  //  dest_result_addr=1152921515543588720 |  dest_result_addr=1152921515543588728
        // 0x00B28C94: STP x22, x21, [sp, #0x40]  | stack[1152921515543588736] = ???;  stack[1152921515543588744] = ???;  //  dest_result_addr=1152921515543588736 |  dest_result_addr=1152921515543588744
        // 0x00B28C98: STP x20, x19, [sp, #0x50]  | stack[1152921515543588752] = ???;  stack[1152921515543588760] = ???;  //  dest_result_addr=1152921515543588752 |  dest_result_addr=1152921515543588760
        // 0x00B28C9C: STP x29, x30, [sp, #0x60]  | stack[1152921515543588768] = ???;  stack[1152921515543588776] = ???;  //  dest_result_addr=1152921515543588768 |  dest_result_addr=1152921515543588776
        // 0x00B28CA0: ADD x29, sp, #0x60         | X29 = (1152921515543588672 + 96) = 1152921515543588768 (0x100000028BE16FA0);
        // 0x00B28CA4: SUB sp, sp, #0x10          | SP = (1152921515543588672 - 16) = 1152921515543588656 (0x100000028BE16F30);
        // 0x00B28CA8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B28CAC: LDRB w8, [x22, #0x754]     | W8 = (bool)static_value_03733754;       
        // 0x00B28CB0: MOV v8.16b, v0.16b         | V8 = playTime;//m1                      
        val_23 = playTime;
        // 0x00B28CB4: MOV x19, x2                | X19 = aniName;//m1                      
        // 0x00B28CB8: MOV w20, w1                | W20 = isLoop;//m1                       
        // 0x00B28CBC: MOV x21, x0                | X21 = 1152921515543600784 (0x100000028BE19E90);//ML01
        // 0x00B28CC0: TBNZ w8, #0, #0xb28cdc     | if (static_value_03733754 == true) goto label_0;
        // 0x00B28CC4: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B28CC8: LDR x8, [x8, #0x3f0]       | X8 = 0x2B8AEF8;                         
        // 0x00B28CCC: LDR w0, [x8]               | W0 = 0x27C;                             
        // 0x00B28CD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x27C, ????);      
        // 0x00B28CD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B28CD8: STRB w8, [x22, #0x754]     | static_value_03733754 = true;            //  dest_result_addr=57882452
        label_0:
        // 0x00B28CDC: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
        // 0x00B28CE0: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
        // 0x00B28CE4: LDR x0, [x26]              | X0 = typeof(System.String);             
        // 0x00B28CE8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28CEC: TBZ w8, #0, #0xb28cfc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B28CF0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28CF4: CBNZ w8, #0xb28cfc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B28CF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_2:
        // 0x00B28CFC: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B28D00: LDR x8, [x8, #0x4a0]       | X8 = (string**)(1152921515543150416)("Play ");
        // 0x00B28D04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28D08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28D0C: MOV x2, x19                | X2 = aniName;//m1                       
        // 0x00B28D10: LDR x1, [x8]               | X1 = "Play ";                           
        // 0x00B28D14: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Play ");
        string val_1 = System.String.Concat(str0:  0, str1:  "Play ");
        // 0x00B28D18: ADRP x27, #0x35f8000       | X27 = 56590336 (0x35F8000);             
        // 0x00B28D1C: LDR x27, [x27, #0x130]     | X27 = 1152921504692469760;              
        // 0x00B28D20: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00B28D24: LDR x8, [x27]              | X8 = typeof(UnityEngine.Debug);         
        // 0x00B28D28: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B28D2C: TBZ w9, #0, #0xb28d40      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B28D30: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B28D34: CBNZ w9, #0xb28d40         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B28D38: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00B28D3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_4:
        // 0x00B28D40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28D44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28D48: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x00B28D4C: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00B28D50: LDRB w8, [x21, #0x58]      | W8 = this.isHaveAni; //P2               
        // 0x00B28D54: CBZ w8, #0xb293d0          | if (this.isHaveAni == false) goto label_52;
        if(this.isHaveAni == false)
        {
            goto label_52;
        }
        // 0x00B28D58: ADRP x23, #0x364f000       | X23 = 56946688 (0x364F000);             
        // 0x00B28D5C: LDR x23, [x23, #0x188]     | X23 = 1152921504922288128;              
        val_24 = 1152921504922288128;
        // 0x00B28D60: LDR x8, [x23]              | X8 = typeof(AnimationRunner);           
        // 0x00B28D64: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B28D68: LDR x22, [x8]              | X22 = AnimationRunner.AniTypeDic;       
        // 0x00B28D6C: CBNZ x22, #0xb28d74        | if (AnimationRunner.AniTypeDic != null) goto label_6;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_6;
        }
        // 0x00B28D70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00B28D74: ADRP x24, #0x35c4000       | X24 = 56377344 (0x35C4000);             
        // 0x00B28D78: LDR x24, [x24, #0x150]     | X24 = 1152921515542463952;              
        // 0x00B28D7C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B28D80: MOV x0, x22                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B28D84: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B28D88: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  0);
        string val_2 = AnimationRunner.AniTypeDic.Item[0];
        // 0x00B28D8C: LDR x8, [x26]              | X8 = typeof(System.String);             
        // 0x00B28D90: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B28D94: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28D98: TBZ w9, #0, #0xb28dac      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B28D9C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28DA0: CBNZ w9, #0xb28dac         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B28DA4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B28DA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_8:
        // 0x00B28DAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28DB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28DB4: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28DB8: MOV x2, x22                | X2 = val_2;//m1                         
        // 0x00B28DBC: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  aniName);
        bool val_3 = System.String.op_Equality(a:  0, b:  aniName);
        // 0x00B28DC0: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B28DC4: TBNZ w8, #0, #0xb293d0     | if ((val_3 & 1) == true) goto label_52; 
        if(val_4 == true)
        {
            goto label_52;
        }
        // 0x00B28DC8: MOV x0, x21                | X0 = 1152921515543600784 (0x100000028BE19E90);//ML01
        // 0x00B28DCC: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28DD0: BL #0xb28580               | X0 = this.HasExistAni(name:  aniName);  
        bool val_5 = this.HasExistAni(name:  aniName);
        // 0x00B28DD4: TBZ w0, #0, #0xb293d0      | if (val_5 == false) goto label_52;      
        if(val_5 == false)
        {
            goto label_52;
        }
        // 0x00B28DD8: LDR x0, [x26]              | X0 = typeof(System.String);             
        // 0x00B28DDC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28DE0: TBZ w8, #0, #0xb28df0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B28DE4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28DE8: CBNZ w8, #0xb28df0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B28DEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_12:
        // 0x00B28DF0: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00B28DF4: LDR x8, [x8, #0x810]       | X8 = (string**)(1152921515543158688)("aniName ");
        // 0x00B28DF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28DFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28E00: MOV x2, x19                | X2 = aniName;//m1                       
        // 0x00B28E04: LDR x1, [x8]               | X1 = "aniName ";                        
        // 0x00B28E08: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "aniName ");
        string val_6 = System.String.Concat(str0:  0, str1:  "aniName ");
        // 0x00B28E0C: LDR x8, [x27]              | X8 = typeof(UnityEngine.Debug);         
        // 0x00B28E10: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B28E14: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B28E18: TBZ w9, #0, #0xb28e2c      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B28E1C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B28E20: CBNZ w9, #0xb28e2c         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B28E24: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00B28E28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_14:
        // 0x00B28E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28E30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28E34: MOV x1, x22                | X1 = val_6;//m1                         
        // 0x00B28E38: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00B28E3C: MOV v0.16b, v8.16b         | V0 = playTime;//m1                      
        // 0x00B28E40: FCMP s8, #0.0              | STATE = COMPARE(playTime, 0)            
        // 0x00B28E44: B.NE #0xb28e54             | if (val_23 != 0) goto label_15;         
        if(val_23 != 0f)
        {
            goto label_15;
        }
        // 0x00B28E48: MOV x0, x21                | X0 = 1152921515543600784 (0x100000028BE19E90);//ML01
        // 0x00B28E4C: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28E50: BL #0xb28af4               | X0 = this.GetActionTime(aniName:  aniName);
        float val_7 = this.GetActionTime(aniName:  aniName);
        label_15:
        // 0x00B28E54: STR s0, [x21, #0x54]       | this._playTime = val_7;                  //  dest_result_addr=1152921515543600868
        this._playTime = val_7;
        // 0x00B28E58: LDR x8, [x23]              | X8 = typeof(AnimationRunner);           
        // 0x00B28E5C: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B28E60: LDR x22, [x8]              | X22 = AnimationRunner.AniTypeDic;       
        // 0x00B28E64: CBNZ x22, #0xb28e6c        | if (AnimationRunner.AniTypeDic != null) goto label_16;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_16;
        }
        // 0x00B28E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_16:
        // 0x00B28E6C: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B28E70: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B28E74: MOV x0, x22                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B28E78: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  3);
        string val_8 = AnimationRunner.AniTypeDic.Item[3];
        // 0x00B28E7C: LDR x8, [x26]              | X8 = typeof(System.String);             
        // 0x00B28E80: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B28E84: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28E88: TBZ w9, #0, #0xb28e9c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B28E8C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28E90: CBNZ w9, #0xb28e9c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B28E94: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B28E98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_18:
        // 0x00B28E9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28EA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28EA4: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28EA8: MOV x2, x22                | X2 = val_8;//m1                         
        // 0x00B28EAC: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  aniName);
        bool val_9 = System.String.op_Equality(a:  0, b:  aniName);
        // 0x00B28EB0: TBZ w0, #0, #0xb28f44      | if (val_9 == false) goto label_19;      
        if(val_9 == false)
        {
            goto label_19;
        }
        // 0x00B28EB4: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_26 = 0;
        // 0x00B28EB8: B #0xb28ed0                |  goto label_20;                         
        goto label_20;
        label_27:
        // 0x00B28EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28EC0: MOV x0, x22                | X0 = val_8;//m1                         
        // 0x00B28EC4: MOV v0.16b, v9.16b         | V0 = V9.16B;//m1                        
        // 0x00B28EC8: BL #0x270ea00              | val_8.set_speed(value:  V9.16B);        
        val_8.speed = V9.16B;
        // 0x00B28ECC: ADD w25, w25, #1           | W25 = (val_26 + 1) = val_26 (0x00000001);
        val_26 = 1;
        label_20:
        // 0x00B28ED0: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B28ED4: CBNZ x22, #0xb28edc        | if (this.ani != null) goto label_21;    
        if(this.ani != null)
        {
            goto label_21;
        }
        // 0x00B28ED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_21:
        // 0x00B28EDC: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28EE0: CMP w25, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28EE4: B.GE #0xb28f74             | if (val_26 >= this.ani.Length) goto label_28;
        if(val_26 >= this.ani.Length)
        {
            goto label_28;
        }
        // 0x00B28EE8: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B28EEC: CBNZ x22, #0xb28ef4        | if (this.ani != null) goto label_23;    
        if(this.ani != null)
        {
            goto label_23;
        }
        // 0x00B28EF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_23:
        // 0x00B28EF4: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28EF8: SXTW x28, w25              | X28 = 1 (0x00000001);                   
        // 0x00B28EFC: CMP w25, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28F00: B.LO #0xb28f10             | if (val_26 < this.ani.Length) goto label_24;
        if(val_26 < this.ani.Length)
        {
            goto label_24;
        }
        // 0x00B28F04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00B28F08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28F0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_24:
        // 0x00B28F10: ADD x8, x22, x28, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B28F14: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_23 = this.ani[1];
        // 0x00B28F18: CBNZ x22, #0xb28f20        | if (this.ani[0x1][0] != null) goto label_25;
        if(val_23 != null)
        {
            goto label_25;
        }
        // 0x00B28F1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_25:
        // 0x00B28F20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28F24: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B28F28: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28F2C: BL #0x270c494              | X0 = this.ani[0x1][0].get_Item(name:  aniName);
        UnityEngine.AnimationState val_10 = val_23.Item[aniName];
        // 0x00B28F30: LDR s9, [x21, #0x50]       | S9 = this.runSpeed; //P2                
        // 0x00B28F34: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00B28F38: CBNZ x22, #0xb28ebc        | if (val_10 != null) goto label_27;      
        if(val_10 != null)
        {
            goto label_27;
        }
        // 0x00B28F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B28F40: B #0xb28ebc                |  goto label_27;                         
        goto label_27;
        label_19:
        // 0x00B28F44: FCMP s8, #0.0              | STATE = COMPARE(playTime, 0)            
        // 0x00B28F48: B.LE #0xb28f74             | if (val_23 <= 0) goto label_28;         
        if(val_23 <= 0f)
        {
            goto label_28;
        }
        // 0x00B28F4C: LDR x22, [x21, #0x38]      | X22 = this.unit; //P2                   
        // 0x00B28F50: CBNZ x22, #0xb28f58        | if (this.unit != null) goto label_29;   
        if(this.unit != null)
        {
            goto label_29;
        }
        // 0x00B28F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_29:
        // 0x00B28F58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28F5C: MOV x0, x22                | X0 = this.unit;//m1                     
        // 0x00B28F60: BL #0xd97958               | X0 = this.unit.get_atkSpeed();          
        float val_11 = this.unit.atkSpeed;
        // 0x00B28F64: FMUL s0, s0, s8            | S0 = (val_11 * playTime);               
        val_11 = val_11 * val_23;
        // 0x00B28F68: MOV x0, x21                | X0 = 1152921515543600784 (0x100000028BE19E90);//ML01
        // 0x00B28F6C: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28F70: BL #0xb28b7c               | this.SetActionTime(aniName:  aniName, playTime:  val_11 = val_11 * val_23);
        this.SetActionTime(aniName:  aniName, playTime:  val_11);
        label_28:
        // 0x00B28F74: LDR x0, [x26]              | X0 = typeof(System.String);             
        // 0x00B28F78: LDR x22, [x21, #0x28]      | X22 = this.aniName; //P2                
        // 0x00B28F7C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28F80: TBZ w8, #0, #0xb28f90      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_31;
        // 0x00B28F84: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28F88: CBNZ w8, #0xb28f90         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
        // 0x00B28F8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_31:
        // 0x00B28F90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28F94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28F98: MOV x1, x22                | X1 = this.aniName;//m1                  
        // 0x00B28F9C: MOV x2, x19                | X2 = aniName;//m1                       
        // 0x00B28FA0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.aniName);
        bool val_12 = System.String.op_Equality(a:  0, b:  this.aniName);
        // 0x00B28FA4: TBZ w0, #0, #0xb2900c      | if (val_12 == false) goto label_32;     
        if(val_12 == false)
        {
            goto label_32;
        }
        // 0x00B28FA8: LDR x8, [x23]              | X8 = typeof(AnimationRunner);           
        // 0x00B28FAC: LDR x22, [x21, #0x28]      | X22 = this.aniName; //P2                
        // 0x00B28FB0: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B28FB4: LDR x23, [x8]              | X23 = AnimationRunner.AniTypeDic;       
        // 0x00B28FB8: CBNZ x23, #0xb28fc0        | if (AnimationRunner.AniTypeDic != null) goto label_33;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_33;
        }
        // 0x00B28FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_33:
        // 0x00B28FC0: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B28FC4: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00B28FC8: MOV x0, x23                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B28FCC: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  4);
        string val_13 = AnimationRunner.AniTypeDic.Item[4];
        // 0x00B28FD0: LDR x8, [x26]              | X8 = typeof(System.String);             
        // 0x00B28FD4: MOV x23, x0                | X23 = val_13;//m1                       
        val_24 = val_13;
        // 0x00B28FD8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B28FDC: TBZ w9, #0, #0xb28ff0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_35;
        // 0x00B28FE0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B28FE4: CBNZ w9, #0xb28ff0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
        // 0x00B28FE8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B28FEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_35:
        // 0x00B28FF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28FF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28FF8: MOV x1, x22                | X1 = this.aniName;//m1                  
        // 0x00B28FFC: MOV x2, x23                | X2 = val_13;//m1                        
        // 0x00B29000: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  this.aniName);
        bool val_14 = System.String.op_Inequality(a:  0, b:  this.aniName);
        // 0x00B29004: AND w8, w0, #1             | W8 = (val_14 & 1);                      
        bool val_15 = val_14;
        // 0x00B29008: TBNZ w8, #0, #0xb293d0     | if ((val_14 & 1) == true) goto label_52;
        if(val_15 == true)
        {
            goto label_52;
        }
        label_32:
        // 0x00B2900C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B29010: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29014: BL #0xc9b08c               | X0 = ReplayMgr.get_Instance();          
        ReplayMgr val_16 = ReplayMgr.Instance;
        // 0x00B29018: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B2901C: LDR x22, [x21, #0x38]      | X22 = this.unit; //P2                   
        // 0x00B29020: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B29024: MOV x23, x0                | X23 = val_16;//m1                       
        // 0x00B29028: LDR x24, [x8]              | X24 = typeof(System.Object[]);          
        // 0x00B2902C: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B29030: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B29034: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B29038: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B2903C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B29040: MOV x24, x0                | X24 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B29044: CBNZ x24, #0xb2904c        | if ( != null) goto label_37;            
        if(null != null)
        {
            goto label_37;
        }
        // 0x00B29048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_37:
        // 0x00B2904C: CBZ x19, #0xb29070         | if (aniName == null) goto label_39;     
        if(aniName == null)
        {
            goto label_39;
        }
        // 0x00B29050: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B29054: MOV x0, x19                | X0 = aniName;//m1                       
        // 0x00B29058: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B2905C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? aniName, ????);    
        // 0x00B29060: CBNZ x0, #0xb29070         | if (aniName != null) goto label_39;     
        if(aniName != null)
        {
            goto label_39;
        }
        // 0x00B29064: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? aniName, ????);    
        // 0x00B29068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2906C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? aniName, ????);    
        label_39:
        // 0x00B29070: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B29074: CBNZ w8, #0xb29084         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_40;
        // 0x00B29078: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? aniName, ????);    
        // 0x00B2907C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29080: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? aniName, ????);    
        label_40:
        // 0x00B29084: STR x19, [x24, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = aniName;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = aniName;
        // 0x00B29088: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B2908C: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00B29090: ADD x1, sp, #0xc           | X1 = (1152921515543588656 + 12) = 1152921515543588668 (0x100000028BE16F3C);
        // 0x00B29094: STR s8, [sp, #0xc]         | stack[1152921515543588668] = playTime;   //  dest_result_addr=1152921515543588668
        // 0x00B29098: LDR x0, [x8]               | X0 = typeof(System.Single);             
        // 0x00B2909C: BL #0x27bc028              | X0 = 1152921515543759760 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), playTime);
        // 0x00B290A0: MOV x25, x0                | X25 = 1152921515543759760 (0x100000028BE40B90);//ML01
        // 0x00B290A4: CBZ x25, #0xb290c8         | if (playTime == 0) goto label_42;       
        if(val_23 == 0)
        {
            goto label_42;
        }
        // 0x00B290A8: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B290AC: MOV x0, x25                | X0 = 1152921515543759760 (0x100000028BE40B90);//ML01
        // 0x00B290B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B290B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? playTime, ????);   
        // 0x00B290B8: CBNZ x0, #0xb290c8         | if (playTime != 0) goto label_42;       
        if(val_23 != 0)
        {
            goto label_42;
        }
        // 0x00B290BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? playTime, ????);   
        // 0x00B290C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B290C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? playTime, ????);   
        label_42:
        // 0x00B290C8: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B290CC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B290D0: B.HI #0xb290e0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_43;
        // 0x00B290D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? playTime, ????);   
        // 0x00B290D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B290DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? playTime, ????);   
        label_43:
        // 0x00B290E0: STR x25, [x24, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = playTime; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_23;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B290E4: CBNZ x23, #0xb290ec        | if (val_16 != null) goto label_44;      
        if(val_16 != null)
        {
            goto label_44;
        }
        // 0x00B290E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? playTime, ????);   
        label_44:
        // 0x00B290EC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B290F0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B290F4: MOV x0, x23                | X0 = val_16;//m1                        
        // 0x00B290F8: MOV x2, x22                | X2 = this.unit;//m1                     
        // 0x00B290FC: MOV x3, x24                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B29100: BL #0xc9c41c               | val_16.AddData(type:  2, entity:  this.unit, datas:  null);
        val_16.AddData(type:  2, entity:  this.unit, datas:  null);
        // 0x00B29104: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B29108: STR x19, [x21, #0x28]      | this.aniName = aniName;                  //  dest_result_addr=1152921515543600824
        this.aniName = aniName;
        // 0x00B2910C: CBNZ x22, #0xb29114        | if (this.ani != null) goto label_45;    
        if(this.ani != null)
        {
            goto label_45;
        }
        // 0x00B29110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_45:
        // 0x00B29114: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B29118: LDR x8, [x22, #0x18]       | X8 = this.ani.Length; //P2              
        // 0x00B2911C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B29120: ADD x1, sp, #8             | X1 = (1152921515543588656 + 8) = 1152921515543588664 (0x100000028BE16F38);
        // 0x00B29124: STR w8, [sp, #8]           | stack[1152921515543588664] = this.ani.Length;  //  dest_result_addr=1152921515543588664
        // 0x00B29128: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B2912C: BL #0x27bc028              | X0 = 1152921515543800720 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.ani.Length);
        // 0x00B29130: LDR x8, [x26]              | X8 = typeof(System.String);             
        // 0x00B29134: MOV x22, x0                | X22 = 1152921515543800720 (0x100000028BE4AB90);//ML01
        // 0x00B29138: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B2913C: TBZ w9, #0, #0xb29150      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_47;
        // 0x00B29140: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B29144: CBNZ w9, #0xb29150         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
        // 0x00B29148: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B2914C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_47:
        // 0x00B29150: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00B29154: LDR x8, [x8, #0x8c8]       | X8 = (string**)(1152921515543318528)("ani.Length ");
        // 0x00B29158: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2915C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B29160: MOV x2, x22                | X2 = 1152921515543800720 (0x100000028BE4AB90);//ML01
        // 0x00B29164: LDR x1, [x8]               | X1 = "ani.Length ";                     
        // 0x00B29168: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "ani.Length ");
        string val_17 = System.String.Concat(arg0:  0, arg1:  "ani.Length ");
        // 0x00B2916C: LDR x8, [x27]              | X8 = typeof(UnityEngine.Debug);         
        // 0x00B29170: MOV x22, x0                | X22 = val_17;//m1                       
        // 0x00B29174: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B29178: TBZ w9, #0, #0xb2918c      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_49;
        // 0x00B2917C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B29180: CBNZ w9, #0xb2918c         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
        // 0x00B29184: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00B29188: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_49:
        // 0x00B2918C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B29190: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29194: MOV x1, x22                | X1 = val_17;//m1                        
        // 0x00B29198: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00B2919C: ADRP x24, #0x3626000       | X24 = 56778752 (0x3626000);             
        // 0x00B291A0: ADRP x25, #0x360a000       | X25 = 56664064 (0x360A000);             
        // 0x00B291A4: LDR x24, [x24, #0x7d8]     | X24 = 1152921504608604160;              
        // 0x00B291A8: LDR x25, [x25, #0xa48]     | X25 = (string**)(1152921515543322720)(" ani[i].Play(aniName) ");
        val_26 = " ani[i].Play(aniName) ";
        // 0x00B291AC: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_24 = 0;
        // 0x00B291B0: FMOV s8, wzr               | S8 = 0f;                                
        val_23 = 0f;
        // 0x00B291B4: B #0xb291cc                |  goto label_50;                         
        goto label_50;
        label_74:
        // 0x00B291B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B291BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B291C0: MOV x1, x22                | X1 = val_17;//m1                        
        // 0x00B291C4: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00B291C8: ADD w23, w23, #1           | W23 = (val_24 + 1) = val_24 (0x00000001);
        val_24 = 1;
        label_50:
        // 0x00B291CC: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B291D0: CBNZ x22, #0xb291d8        | if (this.ani != null) goto label_51;    
        if(this.ani != null)
        {
            goto label_51;
        }
        // 0x00B291D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_51:
        // 0x00B291D8: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B291DC: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B291E0: B.GE #0xb293d0             | if (val_24 >= this.ani.Length) goto label_52;
        if(val_24 >= this.ani.Length)
        {
            goto label_52;
        }
        // 0x00B291E4: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B291E8: CBNZ x22, #0xb291f0        | if (this.ani != null) goto label_53;    
        if(this.ani != null)
        {
            goto label_53;
        }
        // 0x00B291EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_53:
        // 0x00B291F0: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B291F4: SXTW x28, w23              | X28 = 1 (0x00000001);                   
        // 0x00B291F8: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B291FC: B.LO #0xb2920c             | if (val_24 < this.ani.Length) goto label_54;
        if(val_24 < this.ani.Length)
        {
            goto label_54;
        }
        // 0x00B29200: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B29204: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29208: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_54:
        // 0x00B2920C: ADD x8, x22, x28, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B29210: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_24 = this.ani[1];
        // 0x00B29214: CBNZ x22, #0xb2921c        | if (this.ani[0x1][0] != null) goto label_55;
        if(val_24 != null)
        {
            goto label_55;
        }
        // 0x00B29218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_55:
        // 0x00B2921C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29220: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B29224: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B29228: BL #0x270c6b4              | this.ani[0x1][0].CrossFade(animation:  aniName);
        val_24.CrossFade(animation:  aniName);
        // 0x00B2922C: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B29230: CBNZ x22, #0xb29238        | if (this.ani != null) goto label_56;    
        if(this.ani != null)
        {
            goto label_56;
        }
        // 0x00B29234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ani[0x1][0], ????);
        label_56:
        // 0x00B29238: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B2923C: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B29240: B.LO #0xb29250             | if (val_24 < this.ani.Length) goto label_57;
        if(val_24 < this.ani.Length)
        {
            goto label_57;
        }
        // 0x00B29244: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.ani[0x1][0], ????);
        // 0x00B29248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2924C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.ani[0x1][0], ????);
        label_57:
        // 0x00B29250: ADD x8, x22, x28, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B29254: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_25 = this.ani[1];
        // 0x00B29258: CBNZ x22, #0xb29260        | if (this.ani[0x1][0] != null) goto label_58;
        if(val_25 != null)
        {
            goto label_58;
        }
        // 0x00B2925C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ani[0x1][0], ????);
        label_58:
        // 0x00B29260: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29264: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B29268: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B2926C: BL #0x270c494              | X0 = this.ani[0x1][0].get_Item(name:  aniName);
        UnityEngine.AnimationState val_18 = val_25.Item[aniName];
        // 0x00B29270: MOV x22, x0                | X22 = val_18;//m1                       
        // 0x00B29274: STR x22, [x21, #0x48]      | this.curstate = val_18;                  //  dest_result_addr=1152921515543600856
        this.curstate = val_18;
        // 0x00B29278: CBNZ x22, #0xb29280        | if (val_18 != null) goto label_59;      
        if(val_18 != null)
        {
            goto label_59;
        }
        // 0x00B2927C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_59:
        // 0x00B29280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29284: MOV x0, x22                | X0 = val_18;//m1                        
        // 0x00B29288: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B2928C: BL #0x270e840              | val_18.set_time(value:  val_23);        
        val_18.time = val_23;
        // 0x00B29290: TBZ w20, #0, #0xb292d8     | if (isLoop == false) goto label_60;     
        if(isLoop == false)
        {
            goto label_60;
        }
        // 0x00B29294: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B29298: CBNZ x22, #0xb292a0        | if (this.ani != null) goto label_61;    
        if(this.ani != null)
        {
            goto label_61;
        }
        // 0x00B2929C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_61:
        // 0x00B292A0: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B292A4: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B292A8: B.LO #0xb292b8             | if (val_24 < this.ani.Length) goto label_62;
        if(val_24 < this.ani.Length)
        {
            goto label_62;
        }
        // 0x00B292AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
        // 0x00B292B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B292B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
        label_62:
        // 0x00B292B8: ADD x8, x22, x28, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B292BC: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_26 = this.ani[1];
        // 0x00B292C0: CBNZ x22, #0xb292c8        | if (this.ani[0x1][0] != null) goto label_63;
        if(val_26 != null)
        {
            goto label_63;
        }
        // 0x00B292C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_63:
        // 0x00B292C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B292CC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B292D0: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B292D4: BL #0x270c0f4              | this.ani[0x1][0].set_wrapMode(value:  2);
        val_26.wrapMode = 2;
        label_60:
        // 0x00B292D8: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B292DC: CBNZ x22, #0xb292e4        | if (this.ani != null) goto label_64;    
        if(this.ani != null)
        {
            goto label_64;
        }
        // 0x00B292E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ani[0x1][0], ????);
        label_64:
        // 0x00B292E4: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B292E8: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B292EC: B.LO #0xb292fc             | if (val_24 < this.ani.Length) goto label_65;
        if(val_24 < this.ani.Length)
        {
            goto label_65;
        }
        // 0x00B292F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.ani[0x1][0], ????);
        // 0x00B292F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B292F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.ani[0x1][0], ????);
        label_65:
        // 0x00B292FC: ADD x8, x22, x28, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B29300: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_27 = this.ani[1];
        // 0x00B29304: CBNZ x22, #0xb2930c        | if (this.ani[0x1][0] != null) goto label_66;
        if(val_27 != null)
        {
            goto label_66;
        }
        // 0x00B29308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.ani[0x1][0], ????);
        label_66:
        // 0x00B2930C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29310: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B29314: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B29318: BL #0x270c614              | X0 = this.ani[0x1][0].Play(animation:  aniName);
        bool val_19 = val_27.Play(animation:  aniName);
        // 0x00B2931C: LDR x22, [x21, #0x18]      | X22 = this.ani; //P2                    
        // 0x00B29320: CBNZ x22, #0xb29328        | if (this.ani != null) goto label_67;    
        if(this.ani != null)
        {
            goto label_67;
        }
        // 0x00B29324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_67:
        // 0x00B29328: LDR w8, [x22, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B2932C: CMP w23, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B29330: B.LO #0xb29340             | if (val_24 < this.ani.Length) goto label_68;
        if(val_24 < this.ani.Length)
        {
            goto label_68;
        }
        // 0x00B29334: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
        // 0x00B29338: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2933C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
        label_68:
        // 0x00B29340: ADD x8, x22, x28, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B29344: LDR x22, [x8, #0x20]       | X22 = this.ani[0x1][0]                  
        UnityEngine.Animation val_28 = this.ani[1];
        // 0x00B29348: CBNZ x22, #0xb29350        | if (this.ani[0x1][0] != null) goto label_69;
        if(val_28 != null)
        {
            goto label_69;
        }
        // 0x00B2934C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_69:
        // 0x00B29350: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29354: MOV x0, x22                | X0 = this.ani[0x1][0];//m1              
        // 0x00B29358: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B2935C: BL #0x270c614              | X0 = this.ani[0x1][0].Play(animation:  aniName);
        bool val_20 = val_28.Play(animation:  aniName);
        // 0x00B29360: LDR x8, [x24]              | X8 = typeof(System.Boolean);            
        // 0x00B29364: AND w9, w0, #1             | W9 = (val_20 & 1);                      
        bool val_21 = val_20;
        // 0x00B29368: ADD x1, sp, #7             | X1 = (1152921515543588656 + 7) = 1152921515543588663 (0x100000028BE16F37);
        // 0x00B2936C: STRB w9, [sp, #7]          | stack[1152921515543588663] = (val_20 & 1);  //  dest_result_addr=1152921515543588663
        // 0x00B29370: MOV x0, x8                 | X0 = 1152921504608604160 (0x10000000001AD000);//ML01
        // 0x00B29374: BL #0x27bc028              | X0 = 1152921515544054672 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (val_20 & 1));
        // 0x00B29378: LDR x8, [x26]              | X8 = typeof(System.String);             
        // 0x00B2937C: MOV x22, x0                | X22 = 1152921515544054672 (0x100000028BE88B90);//ML01
        // 0x00B29380: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B29384: TBZ w9, #0, #0xb29398      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_71;
        // 0x00B29388: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B2938C: CBNZ w9, #0xb29398         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_71;
        // 0x00B29390: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B29394: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_71:
        // 0x00B29398: LDR x1, [x25]              | X1 = " ani[i].Play(aniName) ";          
        // 0x00B2939C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B293A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B293A4: MOV x2, x22                | X2 = 1152921515544054672 (0x100000028BE88B90);//ML01
        // 0x00B293A8: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  " ani[i].Play(aniName) ");
        string val_22 = System.String.Concat(arg0:  0, arg1:  " ani[i].Play(aniName) ");
        // 0x00B293AC: LDR x8, [x27]              | X8 = typeof(UnityEngine.Debug);         
        // 0x00B293B0: MOV x22, x0                | X22 = val_22;//m1                       
        // 0x00B293B4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B293B8: TBZ w9, #0, #0xb291b8      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_74;
        // 0x00B293BC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B293C0: CBNZ w9, #0xb291b8         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_74;
        // 0x00B293C4: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00B293C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        // 0x00B293CC: B #0xb291b8                |  goto label_74;                         
        goto label_74;
        label_52:
        // 0x00B293D0: SUB sp, x29, #0x60         | SP = (1152921515543588768 - 96) = 1152921515543588672 (0x100000028BE16F40);
        // 0x00B293D4: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B293D8: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B293DC: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B293E0: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B293E4: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B293E8: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B293EC: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B293F0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B293F4 (11703284), len: 196  VirtAddr: 0x00B293F4 RVA: 0x00B293F4 token: 100696518 methodIndex: 24838 delegateWrapperIndex: 0 methodInvoker: 0
    public void Play(AnimationRunner.AniType aniType, float playTime = 0, bool isskill = False)
    {
        //
        // Disasemble & Code
        // 0x00B293F4: STP d9, d8, [sp, #-0x40]!  | stack[1152921515544143088] = ???;  stack[1152921515544143096] = ???;  //  dest_result_addr=1152921515544143088 |  dest_result_addr=1152921515544143096
        // 0x00B293F8: STP x22, x21, [sp, #0x10]  | stack[1152921515544143104] = ???;  stack[1152921515544143112] = ???;  //  dest_result_addr=1152921515544143104 |  dest_result_addr=1152921515544143112
        // 0x00B293FC: STP x20, x19, [sp, #0x20]  | stack[1152921515544143120] = ???;  stack[1152921515544143128] = ???;  //  dest_result_addr=1152921515544143120 |  dest_result_addr=1152921515544143128
        // 0x00B29400: STP x29, x30, [sp, #0x30]  | stack[1152921515544143136] = ???;  stack[1152921515544143144] = ???;  //  dest_result_addr=1152921515544143136 |  dest_result_addr=1152921515544143144
        // 0x00B29404: ADD x29, sp, #0x30         | X29 = (1152921515544143088 + 48) = 1152921515544143136 (0x100000028BE9E520);
        // 0x00B29408: SUB sp, sp, #0x10          | SP = (1152921515544143088 - 16) = 1152921515544143072 (0x100000028BE9E4E0);
        // 0x00B2940C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B29410: LDRB w8, [x21, #0x755]     | W8 = (bool)static_value_03733755;       
        // 0x00B29414: MOV w19, w2                | W19 = isskill;//m1                      
        // 0x00B29418: MOV v8.16b, v0.16b         | V8 = playTime;//m1                      
        // 0x00B2941C: MOV x20, x0                | X20 = 1152921515544155152 (0x100000028BEA1410);//ML01
        // 0x00B29420: STR w1, [sp, #0xc]         | stack[1152921515544143084] = aniType;    //  dest_result_addr=1152921515544143084
        // 0x00B29424: TBNZ w8, #0, #0xb29440     | if (static_value_03733755 == true) goto label_0;
        // 0x00B29428: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00B2942C: LDR x8, [x8, #0x2e8]       | X8 = 0x2B8AEF4;                         
        // 0x00B29430: LDR w0, [x8]               | W0 = 0x27B;                             
        // 0x00B29434: BL #0x2782188              | X0 = sub_2782188( ?? 0x27B, ????);      
        // 0x00B29438: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2943C: STRB w8, [x21, #0x755]     | static_value_03733755 = true;            //  dest_result_addr=57882453
        label_0:
        // 0x00B29440: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B29444: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
        // 0x00B29448: ADD x1, sp, #0xc           | X1 = (1152921515544143072 + 12) = 1152921515544143084 (0x100000028BE9E4EC);
        // 0x00B2944C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
        // 0x00B29450: BL #0x27bc028              | X0 = 1152921515544191248 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), aniType);
        // 0x00B29454: MOV x21, x0                | X21 = 1152921515544191248 (0x100000028BEAA110);//ML01
        // 0x00B29458: CBNZ x21, #0xb29460        | if (aniType != 0) goto label_1;         
        if(aniType != 0)
        {
            goto label_1;
        }
        // 0x00B2945C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? aniType, ????);    
        label_1:
        // 0x00B29460: LDR x8, [x21]              | X8 = typeof(AnimationRunner.AniType);   
        // 0x00B29464: MOV x0, x21                | X0 = 1152921515544191248 (0x100000028BEAA110);//ML01
        // 0x00B29468: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x00B2946C: BLR x9                     | X0 = aniType.ToString();                
        string val_1 = aniType.ToString();
        // 0x00B29470: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00B29474: CBNZ x21, #0xb2947c        | if (aniType != 0) goto label_2;         
        if(aniType != 0)
        {
            goto label_2;
        }
        // 0x00B29478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B2947C: MOV x0, x21                | X0 = 1152921515544191248 (0x100000028BEAA110);//ML01
        // 0x00B29480: BL #0x27bc4e8              | aniType.System.IDisposable.Dispose();   
        aniType.System.IDisposable.Dispose();
        // 0x00B29484: LDR w8, [x0]               | W8 = typeof(AnimationRunner.AniType);   
        // 0x00B29488: AND w2, w19, #1            | W2 = (isskill & 1);                     
        isskill = isskill;
        // 0x00B2948C: MOV x0, x20                | X0 = 1152921515544155152 (0x100000028BEA1410);//ML01
        // 0x00B29490: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x00B29494: MOV v0.16b, v8.16b         | V0 = playTime;//m1                      
        // 0x00B29498: STR w8, [sp, #0xc]         | stack[1152921515544143084] = typeof(AnimationRunner.AniType);  //  dest_result_addr=1152921515544143084
        // 0x00B2949C: BL #0xb285f8               | this.Play(aniName:  val_1, playTime:  playTime, isSkill:  isskill = isskill);
        this.Play(aniName:  val_1, playTime:  playTime, isSkill:  isskill);
        // 0x00B294A0: SUB sp, x29, #0x30         | SP = (1152921515544143136 - 48) = 1152921515544143088 (0x100000028BE9E4F0);
        // 0x00B294A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B294A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B294AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B294B0: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B294B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B294B8 (11703480), len: 292  VirtAddr: 0x00B294B8 RVA: 0x00B294B8 token: 100696519 methodIndex: 24839 delegateWrapperIndex: 0 methodInvoker: 0
    public bool IsPlay(AnimationRunner.AniType aniType)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x00B294B8: STP x24, x23, [sp, #-0x40]! | stack[1152921515544357488] = ???;  stack[1152921515544357496] = ???;  //  dest_result_addr=1152921515544357488 |  dest_result_addr=1152921515544357496
        // 0x00B294BC: STP x22, x21, [sp, #0x10]  | stack[1152921515544357504] = ???;  stack[1152921515544357512] = ???;  //  dest_result_addr=1152921515544357504 |  dest_result_addr=1152921515544357512
        // 0x00B294C0: STP x20, x19, [sp, #0x20]  | stack[1152921515544357520] = ???;  stack[1152921515544357528] = ???;  //  dest_result_addr=1152921515544357520 |  dest_result_addr=1152921515544357528
        // 0x00B294C4: STP x29, x30, [sp, #0x30]  | stack[1152921515544357536] = ???;  stack[1152921515544357544] = ???;  //  dest_result_addr=1152921515544357536 |  dest_result_addr=1152921515544357544
        // 0x00B294C8: ADD x29, sp, #0x30         | X29 = (1152921515544357488 + 48) = 1152921515544357536 (0x100000028BED2AA0);
        // 0x00B294CC: SUB sp, sp, #0x10          | SP = (1152921515544357488 - 16) = 1152921515544357472 (0x100000028BED2A60);
        // 0x00B294D0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B294D4: LDRB w8, [x20, #0x756]     | W8 = (bool)static_value_03733756;       
        // 0x00B294D8: MOV x19, x0                | X19 = 1152921515544369552 (0x100000028BED5990);//ML01
        // 0x00B294DC: STR w1, [sp, #0xc]         | stack[1152921515544357484] = aniType;    //  dest_result_addr=1152921515544357484
        // 0x00B294E0: TBNZ w8, #0, #0xb294fc     | if (static_value_03733756 == true) goto label_0;
        // 0x00B294E4: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00B294E8: LDR x8, [x8, #0x9b8]       | X8 = 0x2B8AEEC;                         
        // 0x00B294EC: LDR w0, [x8]               | W0 = 0x279;                             
        // 0x00B294F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x279, ????);      
        // 0x00B294F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B294F8: STRB w8, [x20, #0x756]     | static_value_03733756 = true;            //  dest_result_addr=57882454
        label_0:
        // 0x00B294FC: ADRP x24, #0x35db000       | X24 = 56471552 (0x35DB000);             
        // 0x00B29500: LDR x24, [x24, #0x808]     | X24 = 1152921504922341376;              
        // 0x00B29504: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_4 = 0;
        label_8:
        // 0x00B29508: LDR x20, [x19, #0x18]      | X20 = this.ani; //P2                    
        // 0x00B2950C: CBNZ x20, #0xb29514        | if (this.ani != null) goto label_1;     
        if(this.ani != null)
        {
            goto label_1;
        }
        // 0x00B29510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x279, ????);      
        label_1:
        // 0x00B29514: LDR w8, [x20, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B29518: CMP w23, w8                | STATE = COMPARE(0x0, this.ani.Length)   
        // 0x00B2951C: B.GE #0xb295c0             | if (val_4 >= this.ani.Length) goto label_2;
        if(val_4 >= this.ani.Length)
        {
            goto label_2;
        }
        // 0x00B29520: LDR x20, [x19, #0x18]      | X20 = this.ani; //P2                    
        // 0x00B29524: CBNZ x20, #0xb2952c        | if (this.ani != null) goto label_3;     
        if(this.ani != null)
        {
            goto label_3;
        }
        // 0x00B29528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x279, ????);      
        label_3:
        // 0x00B2952C: LDR w8, [x20, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B29530: SXTW x21, w23              | X21 = 0 (0x00000000);                   
        // 0x00B29534: CMP w23, w8                | STATE = COMPARE(0x0, this.ani.Length)   
        // 0x00B29538: B.LO #0xb29548             | if (val_4 < this.ani.Length) goto label_4;
        if(val_4 < this.ani.Length)
        {
            goto label_4;
        }
        // 0x00B2953C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x279, ????);      
        // 0x00B29540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29544: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x279, ????);      
        label_4:
        // 0x00B29548: ADD x8, x20, x21, lsl #3   | X8 = this.ani[0x0]; //PARR1             
        // 0x00B2954C: LDR x0, [x24]              | X0 = typeof(AnimationRunner.AniType);   
        // 0x00B29550: LDR x20, [x8, #0x20]       | X20 = this.ani[0x0][0]                  
        UnityEngine.Animation val_4 = this.ani[0];
        // 0x00B29554: ADD x1, sp, #0xc           | X1 = (1152921515544357472 + 12) = 1152921515544357484 (0x100000028BED2A6C);
        // 0x00B29558: BL #0x27bc028              | X0 = 1152921515544483472 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), aniType);
        // 0x00B2955C: MOV x21, x0                | X21 = 1152921515544483472 (0x100000028BEF1690);//ML01
        // 0x00B29560: CBNZ x21, #0xb29568        | if (aniType != 0) goto label_5;         
        if(aniType != 0)
        {
            goto label_5;
        }
        // 0x00B29564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? aniType, ????);    
        label_5:
        // 0x00B29568: LDR x8, [x21]              | X8 = typeof(AnimationRunner.AniType);   
        // 0x00B2956C: MOV x0, x21                | X0 = 1152921515544483472 (0x100000028BEF1690);//ML01
        // 0x00B29570: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x00B29574: BLR x9                     | X0 = aniType.ToString();                
        string val_1 = aniType.ToString();
        // 0x00B29578: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00B2957C: CBNZ x21, #0xb29584        | if (aniType != 0) goto label_6;         
        if(aniType != 0)
        {
            goto label_6;
        }
        // 0x00B29580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B29584: MOV x0, x21                | X0 = 1152921515544483472 (0x100000028BEF1690);//ML01
        // 0x00B29588: BL #0x27bc4e8              | aniType.System.IDisposable.Dispose();   
        aniType.System.IDisposable.Dispose();
        // 0x00B2958C: LDR w8, [x0]               | W8 = typeof(AnimationRunner.AniType);   
        // 0x00B29590: STR w8, [sp, #0xc]         | stack[1152921515544357484] = typeof(AnimationRunner.AniType);  //  dest_result_addr=1152921515544357484
        // 0x00B29594: CBNZ x20, #0xb2959c        | if (this.ani[0x0][0] != null) goto label_7;
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B29598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? aniType, ????);    
        label_7:
        // 0x00B2959C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B295A0: MOV x0, x20                | X0 = this.ani[0x0][0];//m1              
        // 0x00B295A4: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x00B295A8: BL #0x270c41c              | X0 = this.ani[0x0][0].IsPlaying(name:  val_1);
        bool val_2 = val_4.IsPlaying(name:  val_1);
        // 0x00B295AC: ADD w23, w23, #1           | W23 = (val_4 + 1);                      
        val_4 = val_4 + 1;
        // 0x00B295B0: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B295B4: TBZ w8, #0, #0xb29508      | if ((val_2 & 1) == false) goto label_8; 
        if(val_3 == false)
        {
            goto label_8;
        }
        // 0x00B295B8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_5 = 1;
        // 0x00B295BC: B #0xb295c4                |  goto label_9;                          
        goto label_9;
        label_2:
        // 0x00B295C0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_5 = 0;
        label_9:
        // 0x00B295C4: SUB sp, x29, #0x30         | SP = (1152921515544357536 - 48) = 1152921515544357488 (0x100000028BED2A70);
        // 0x00B295C8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B295CC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B295D0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B295D4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B295D8: RET                        |  return (System.Boolean)false;          
        return (bool)val_5;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B28B7C (11701116), len: 264  VirtAddr: 0x00B28B7C RVA: 0x00B28B7C token: 100696520 methodIndex: 24840 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetActionTime(string aniName, float playTime)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        float val_7;
        // 0x00B28B7C: STP d9, d8, [sp, #-0x50]!  | stack[1152921515544645600] = ???;  stack[1152921515544645608] = ???;  //  dest_result_addr=1152921515544645600 |  dest_result_addr=1152921515544645608
        // 0x00B28B80: STP x24, x23, [sp, #0x10]  | stack[1152921515544645616] = ???;  stack[1152921515544645624] = ???;  //  dest_result_addr=1152921515544645616 |  dest_result_addr=1152921515544645624
        // 0x00B28B84: STP x22, x21, [sp, #0x20]  | stack[1152921515544645632] = ???;  stack[1152921515544645640] = ???;  //  dest_result_addr=1152921515544645632 |  dest_result_addr=1152921515544645640
        // 0x00B28B88: STP x20, x19, [sp, #0x30]  | stack[1152921515544645648] = ???;  stack[1152921515544645656] = ???;  //  dest_result_addr=1152921515544645648 |  dest_result_addr=1152921515544645656
        // 0x00B28B8C: STP x29, x30, [sp, #0x40]  | stack[1152921515544645664] = ???;  stack[1152921515544645672] = ???;  //  dest_result_addr=1152921515544645664 |  dest_result_addr=1152921515544645672
        // 0x00B28B90: ADD x29, sp, #0x40         | X29 = (1152921515544645600 + 64) = 1152921515544645664 (0x100000028BF19020);
        // 0x00B28B94: MOV v8.16b, v0.16b         | V8 = playTime;//m1                      
        // 0x00B28B98: MOV x19, x1                | X19 = aniName;//m1                      
        // 0x00B28B9C: MOV x20, x0                | X20 = 1152921515544657680 (0x100000028BF1BF10);//ML01
        // 0x00B28BA0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B28BA4: B #0xb28bac                |  goto label_0;                          
        goto label_0;
        label_9:
        // 0x00B28BA8: ADD w22, w22, #1           | W22 = (val_5 + 1) = val_5 (0x00000001); 
        val_5 = 1;
        label_0:
        // 0x00B28BAC: LDR x21, [x20, #0x18]      | X21 = this.ani; //P2                    
        // 0x00B28BB0: CBNZ x21, #0xb28bb8        | if (this.ani != null) goto label_1;     
        if(this.ani != null)
        {
            goto label_1;
        }
        // 0x00B28BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x00B28BB8: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28BBC: CMP w22, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28BC0: B.GE #0xb28c6c             | if (val_5 >= this.ani.Length) goto label_2;
        if(val_5 >= this.ani.Length)
        {
            goto label_2;
        }
        // 0x00B28BC4: LDR x21, [x20, #0x18]      | X21 = this.ani; //P2                    
        // 0x00B28BC8: CBNZ x21, #0xb28bd0        | if (this.ani != null) goto label_3;     
        if(this.ani != null)
        {
            goto label_3;
        }
        // 0x00B28BCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_3:
        // 0x00B28BD0: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B28BD4: SXTW x23, w22              | X23 = 1 (0x00000001);                   
        // 0x00B28BD8: CMP w22, w8                | STATE = COMPARE(0x1, this.ani.Length)   
        // 0x00B28BDC: B.LO #0xb28bec             | if (val_5 < this.ani.Length) goto label_4;
        if(val_5 < this.ani.Length)
        {
            goto label_4;
        }
        // 0x00B28BE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x00B28BE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28BE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_4:
        // 0x00B28BEC: ADD x8, x21, x23, lsl #3   | X8 = this.ani[0x1]; //PARR1             
        // 0x00B28BF0: LDR x21, [x8, #0x20]       | X21 = this.ani[0x1][0]                  
        UnityEngine.Animation val_5 = this.ani[1];
        // 0x00B28BF4: CBNZ x21, #0xb28bfc        | if (this.ani[0x1][0] != null) goto label_5;
        if(val_5 != null)
        {
            goto label_5;
        }
        // 0x00B28BF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x00B28BFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28C00: MOV x0, x21                | X0 = this.ani[0x1][0];//m1              
        // 0x00B28C04: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28C08: BL #0x270c494              | X0 = this.ani[0x1][0].get_Item(name:  aniName);
        UnityEngine.AnimationState val_1 = val_5.Item[aniName];
        // 0x00B28C0C: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B28C10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28C14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28C18: MOV x1, x21                | X1 = val_1;//m1                         
        // 0x00B28C1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28C20: BL #0x2692458              | X0 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_1);
        bool val_2 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_1);
        // 0x00B28C24: TBZ w0, #0, #0xb28ba8      | if (val_2 == false) goto label_9;       
        if(val_2 == false)
        {
            goto label_9;
        }
        // 0x00B28C28: CBZ x21, #0xb28c40         | if (val_1 == null) goto label_7;        
        if(val_1 == null)
        {
            goto label_7;
        }
        // 0x00B28C2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28C30: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B28C34: BL #0x270eb58              | X0 = val_1.get_length();                
        float val_3 = val_1.length;
        // 0x00B28C38: MOV v9.16b, v0.16b         | V9 = val_3;//m1                         
        val_7 = val_3;
        // 0x00B28C3C: B #0xb28c58                |  goto label_8;                          
        goto label_8;
        label_7:
        // 0x00B28C40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B28C44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28C4C: BL #0x270eb58              | X0 = 0.get_length();                    
        float val_4 = 0.length;
        // 0x00B28C50: MOV v9.16b, v0.16b         | V9 = val_4;//m1                         
        val_7 = val_4;
        // 0x00B28C54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_8:
        // 0x00B28C58: FDIV s0, s9, s8            | S0 = (val_4 / playTime);                
        val_4 = val_7 / playTime;
        // 0x00B28C5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28C60: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B28C64: BL #0x270ea00              | val_1.set_speed(value:  val_4 = val_7 / playTime);
        val_1.speed = val_4;
        // 0x00B28C68: B #0xb28ba8                |  goto label_9;                          
        goto label_9;
        label_2:
        // 0x00B28C6C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28C70: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B28C74: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B28C78: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B28C7C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B28C80: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B295DC (11703772), len: 92  VirtAddr: 0x00B295DC RVA: 0x00B295DC token: 100696521 methodIndex: 24841 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetWrapModel(UnityEngine.WrapMode wrap)
    {
        //
        // Disasemble & Code
        // 0x00B295DC: STP x20, x19, [sp, #-0x20]! | stack[1152921515544855952] = ???;  stack[1152921515544855960] = ???;  //  dest_result_addr=1152921515544855952 |  dest_result_addr=1152921515544855960
        // 0x00B295E0: STP x29, x30, [sp, #0x10]  | stack[1152921515544855968] = ???;  stack[1152921515544855976] = ???;  //  dest_result_addr=1152921515544855968 |  dest_result_addr=1152921515544855976
        // 0x00B295E4: ADD x29, sp, #0x10         | X29 = (1152921515544855952 + 16) = 1152921515544855968 (0x100000028BF4C5A0);
        // 0x00B295E8: MOV x20, x0                | X20 = 1152921515544867984 (0x100000028BF4F490);//ML01
        // 0x00B295EC: LDR x2, [x20, #0x48]       | X2 = this.curstate; //P2                
        // 0x00B295F0: MOV w19, w1                | W19 = wrap;//m1                         
        // 0x00B295F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B295F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B295FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B29600: BL #0x2692458              | X0 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  0);
        bool val_1 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  0);
        // 0x00B29604: TBZ w0, #0, #0xb2962c      | if (val_1 == false) goto label_0;       
        if(val_1 == false)
        {
            goto label_0;
        }
        // 0x00B29608: LDR x20, [x20, #0x48]      | X20 = this.curstate; //P2               
        // 0x00B2960C: CBNZ x20, #0xb29614        | if (this.curstate != null) goto label_1;
        if(this.curstate != null)
        {
            goto label_1;
        }
        // 0x00B29610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B29614: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2961C: MOV x0, x20                | X0 = this.curstate;//m1                 
        // 0x00B29620: MOV w1, w19                | W1 = wrap;//m1                          
        // 0x00B29624: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B29628: B #0x270e760               | this.curstate.set_wrapMode(value:  wrap); return;
        this.curstate.wrapMode = wrap;
        return;
        label_0:
        // 0x00B2962C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29630: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B29634: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29638 (11703864), len: 336  VirtAddr: 0x00B29638 RVA: 0x00B29638 token: 100696522 methodIndex: 24842 delegateWrapperIndex: 0 methodInvoker: 0
    public float GetActionTime(AnimationRunner.AniType aniType)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Animation val_5;
        //  | 
        AniType val_6;
        // 0x00B29638: STP x22, x21, [sp, #-0x30]! | stack[1152921515545074432] = ???;  stack[1152921515545074440] = ???;  //  dest_result_addr=1152921515545074432 |  dest_result_addr=1152921515545074440
        // 0x00B2963C: STP x20, x19, [sp, #0x10]  | stack[1152921515545074448] = ???;  stack[1152921515545074456] = ???;  //  dest_result_addr=1152921515545074448 |  dest_result_addr=1152921515545074456
        // 0x00B29640: STP x29, x30, [sp, #0x20]  | stack[1152921515545074464] = ???;  stack[1152921515545074472] = ???;  //  dest_result_addr=1152921515545074464 |  dest_result_addr=1152921515545074472
        // 0x00B29644: ADD x29, sp, #0x20         | X29 = (1152921515545074432 + 32) = 1152921515545074464 (0x100000028BF81B20);
        // 0x00B29648: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B2964C: LDRB w8, [x21, #0x757]     | W8 = (bool)static_value_03733757;       
        // 0x00B29650: MOV w19, w1                | W19 = aniType;//m1                      
        val_6 = aniType;
        // 0x00B29654: MOV x20, x0                | X20 = 1152921515545086480 (0x100000028BF84A10);//ML01
        // 0x00B29658: TBNZ w8, #0, #0xb29674     | if (static_value_03733757 == true) goto label_0;
        // 0x00B2965C: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
        // 0x00B29660: LDR x8, [x8, #0x4c8]       | X8 = 0x2B8AEE4;                         
        // 0x00B29664: LDR w0, [x8]               | W0 = 0x277;                             
        // 0x00B29668: BL #0x2782188              | X0 = sub_2782188( ?? 0x277, ????);      
        // 0x00B2966C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B29670: STRB w8, [x21, #0x757]     | static_value_03733757 = true;            //  dest_result_addr=57882455
        label_0:
        // 0x00B29674: LDR x8, [x20, #0x18]       | X8 = this.ani; //P2                     
        // 0x00B29678: CBZ x8, #0xb29774          | if (this.ani == null) goto label_10;    
        if(this.ani == null)
        {
            goto label_10;
        }
        // 0x00B2967C: LDR w9, [x8, #0x18]        | W9 = this.ani.Length; //P2              
        // 0x00B29680: CMP w9, #1                 | STATE = COMPARE(this.ani.Length, 0x1)   
        // 0x00B29684: B.LT #0xb29774             | if (this.ani.Length < 1) goto label_10; 
        if(this.ani.Length < 1)
        {
            goto label_10;
        }
        // 0x00B29688: ADRP x9, #0x35fe000        | X9 = 56614912 (0x35FE000);              
        // 0x00B2968C: LDR x9, [x9, #0x810]       | X9 = 1152921504697475072;               
        // 0x00B29690: LDR x21, [x8, #0x20]       | X21 = this.ani[0]                       
        val_5 = this.ani[0];
        // 0x00B29694: LDR x0, [x9]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B29698: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B2969C: TBZ w8, #0, #0xb296ac      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B296A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B296A4: CBNZ w8, #0xb296ac         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B296A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x00B296AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B296B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B296B4: MOV x1, x21                | X1 = this.ani[0];//m1                   
        // 0x00B296B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B296BC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_5);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  val_5);
        // 0x00B296C0: TBZ w0, #0, #0xb29774      | if (val_1 == false) goto label_10;      
        if(val_1 == false)
        {
            goto label_10;
        }
        // 0x00B296C4: LDR x20, [x20, #0x18]      | X20 = this.ani; //P2                    
        // 0x00B296C8: CBNZ x20, #0xb296d0        | if (this.ani != null) goto label_6;     
        if(this.ani != null)
        {
            goto label_6;
        }
        // 0x00B296CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B296D0: LDR w8, [x20, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B296D4: CBNZ w8, #0xb296e4         | if (this.ani.Length != 0) goto label_7; 
        if(this.ani.Length != 0)
        {
            goto label_7;
        }
        // 0x00B296D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B296DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B296E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_7:
        // 0x00B296E4: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B296E8: LDR x8, [x8, #0x188]       | X8 = 1152921504922288128;               
        // 0x00B296EC: LDR x20, [x20, #0x20]      | X20 = this.ani[0]                       
        UnityEngine.Animation val_5 = this.ani[0];
        // 0x00B296F0: LDR x8, [x8]               | X8 = typeof(AnimationRunner);           
        // 0x00B296F4: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B296F8: LDR x21, [x8]              | X21 = AnimationRunner.AniTypeDic;       
        val_5 = AnimationRunner.AniTypeDic;
        // 0x00B296FC: CBNZ x21, #0xb29704        | if (AnimationRunner.AniTypeDic != null) goto label_8;
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00B29700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_8:
        // 0x00B29704: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00B29708: LDR x8, [x8, #0x150]       | X8 = 1152921515542463952;               
        // 0x00B2970C: MOV x0, x21                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B29710: MOV w1, w19                | W1 = aniType;//m1                       
        // 0x00B29714: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B29718: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  val_6);
        string val_2 = val_5.Item[val_6];
        // 0x00B2971C: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B29720: CBNZ x20, #0xb29728        | if (this.ani[0] != null) goto label_9;  
        if(val_5 != null)
        {
            goto label_9;
        }
        // 0x00B29724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_9:
        // 0x00B29728: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2972C: MOV x0, x20                | X0 = this.ani[0];//m1                   
        // 0x00B29730: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00B29734: BL #0x270c494              | X0 = this.ani[0].get_Item(name:  val_2);
        UnityEngine.AnimationState val_3 = val_5.Item[val_2];
        // 0x00B29738: MOV x19, x0                | X19 = val_3;//m1                        
        val_6 = val_3;
        // 0x00B2973C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B29740: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29744: MOV x1, x19                | X1 = val_3;//m1                         
        // 0x00B29748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B2974C: BL #0x2692458              | X0 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_6);
        bool val_4 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_6);
        // 0x00B29750: TBZ w0, #0, #0xb29774      | if (val_4 == false) goto label_10;      
        if(val_4 == false)
        {
            goto label_10;
        }
        // 0x00B29754: CBNZ x19, #0xb2975c        | if (val_3 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B29758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_11:
        // 0x00B2975C: MOV x0, x19                | X0 = val_3;//m1                         
        // 0x00B29760: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29764: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29768: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2976C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B29770: B #0x270eb58               | return val_3.get_length();              
        return val_6.length;
        label_10:
        // 0x00B29774: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29778: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2977C: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B29780: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B29784: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29788 (11704200), len: 8  VirtAddr: 0x00B29788 RVA: 0x00B29788 token: 100696523 methodIndex: 24843 delegateWrapperIndex: 0 methodInvoker: 0
    public float GetActionTime()
    {
        //
        // Disasemble & Code
        // 0x00B29788: LDR x1, [x0, #0x28]        | X1 = this.aniName; //P2                 
        // 0x00B2978C: B #0xb28af4                | return this.GetActionTime(aniName:  this.aniName);
        return this.GetActionTime(aniName:  this.aniName);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B28AF4 (11700980), len: 136  VirtAddr: 0x00B28AF4 RVA: 0x00B28AF4 token: 100696524 methodIndex: 24844 delegateWrapperIndex: 0 methodInvoker: 0
    public float GetActionTime(string aniName)
    {
        //
        // Disasemble & Code
        //  | 
        string val_3;
        // 0x00B28AF4: STP x20, x19, [sp, #-0x20]! | stack[1152921515545450000] = ???;  stack[1152921515545450008] = ???;  //  dest_result_addr=1152921515545450000 |  dest_result_addr=1152921515545450008
        // 0x00B28AF8: STP x29, x30, [sp, #0x10]  | stack[1152921515545450016] = ???;  stack[1152921515545450024] = ???;  //  dest_result_addr=1152921515545450016 |  dest_result_addr=1152921515545450024
        // 0x00B28AFC: ADD x29, sp, #0x10         | X29 = (1152921515545450000 + 16) = 1152921515545450016 (0x100000028BFDD620);
        // 0x00B28B00: LDR x8, [x0, #0x18]        | X8 = this.ani; //P2                     
        // 0x00B28B04: MOV x19, x1                | X19 = aniName;//m1                      
        val_3 = aniName;
        // 0x00B28B08: CBZ x8, #0xb28b6c          | if (this.ani == null) goto label_3;     
        if(this.ani == null)
        {
            goto label_3;
        }
        // 0x00B28B0C: LDR w9, [x8, #0x18]        | W9 = this.ani.Length; //P2              
        // 0x00B28B10: CMP w9, #1                 | STATE = COMPARE(this.ani.Length, 0x1)   
        // 0x00B28B14: B.LT #0xb28b6c             | if (this.ani.Length < 1) goto label_3;  
        if(this.ani.Length < 1)
        {
            goto label_3;
        }
        // 0x00B28B18: LDR x20, [x8, #0x20]       | X20 = this.ani[0]                       
        UnityEngine.Animation val_3 = this.ani[0];
        // 0x00B28B1C: CBNZ x20, #0xb28b24        | if (this.ani[0] != null) goto label_2;  
        if(val_3 != null)
        {
            goto label_2;
        }
        // 0x00B28B20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_2:
        // 0x00B28B24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28B28: MOV x0, x20                | X0 = this.ani[0];//m1                   
        // 0x00B28B2C: MOV x1, x19                | X1 = aniName;//m1                       
        // 0x00B28B30: BL #0x270c494              | X0 = this.ani[0].get_Item(name:  val_3);
        UnityEngine.AnimationState val_1 = val_3.Item[val_3];
        // 0x00B28B34: MOV x19, x0                | X19 = val_1;//m1                        
        val_3 = val_1;
        // 0x00B28B38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28B3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B28B40: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B28B44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28B48: BL #0x2692458              | X0 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_3);
        bool val_2 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_3);
        // 0x00B28B4C: TBZ w0, #0, #0xb28b6c      | if (val_2 == false) goto label_3;       
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B28B50: CBNZ x19, #0xb28b58        | if (val_1 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00B28B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B28B58: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28B5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28B60: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B28B64: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B28B68: B #0x270eb58               | return val_1.get_length();              
        return val_3.length;
        label_3:
        // 0x00B28B6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28B70: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B28B74: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B28B78: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29790 (11704208), len: 388  VirtAddr: 0x00B29790 RVA: 0x00B29790 token: 100696525 methodIndex: 24845 delegateWrapperIndex: 0 methodInvoker: 0
    public float GetActionNormalizedTime(AnimationRunner.AniType aniType)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Animation val_7;
        //  | 
        UnityEngine.Animation val_8;
        //  | 
        float val_9;
        // 0x00B29790: STP d9, d8, [sp, #-0x40]!  | stack[1152921515545713520] = ???;  stack[1152921515545713528] = ???;  //  dest_result_addr=1152921515545713520 |  dest_result_addr=1152921515545713528
        // 0x00B29794: STP x22, x21, [sp, #0x10]  | stack[1152921515545713536] = ???;  stack[1152921515545713544] = ???;  //  dest_result_addr=1152921515545713536 |  dest_result_addr=1152921515545713544
        // 0x00B29798: STP x20, x19, [sp, #0x20]  | stack[1152921515545713552] = ???;  stack[1152921515545713560] = ???;  //  dest_result_addr=1152921515545713552 |  dest_result_addr=1152921515545713560
        // 0x00B2979C: STP x29, x30, [sp, #0x30]  | stack[1152921515545713568] = ???;  stack[1152921515545713576] = ???;  //  dest_result_addr=1152921515545713568 |  dest_result_addr=1152921515545713576
        // 0x00B297A0: ADD x29, sp, #0x30         | X29 = (1152921515545713520 + 48) = 1152921515545713568 (0x100000028C01DBA0);
        // 0x00B297A4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B297A8: LDRB w8, [x21, #0x758]     | W8 = (bool)static_value_03733758;       
        // 0x00B297AC: MOV w20, w1                | W20 = aniType;//m1                      
        // 0x00B297B0: MOV x19, x0                | X19 = 1152921515545725584 (0x100000028C020A90);//ML01
        val_7 = this;
        // 0x00B297B4: TBNZ w8, #0, #0xb297d0     | if (static_value_03733758 == true) goto label_0;
        // 0x00B297B8: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00B297BC: LDR x8, [x8, #0x2c8]       | X8 = 0x2B8AEE0;                         
        // 0x00B297C0: LDR w0, [x8]               | W0 = 0x276;                             
        // 0x00B297C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x276, ????);      
        // 0x00B297C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B297CC: STRB w8, [x21, #0x758]     | static_value_03733758 = true;            //  dest_result_addr=57882456
        label_0:
        // 0x00B297D0: LDR x21, [x19, #0x18]      | X21 = this.ani; //P2                    
        // 0x00B297D4: CBNZ x21, #0xb297dc        | if (this.ani != null) goto label_1;     
        if(this.ani != null)
        {
            goto label_1;
        }
        // 0x00B297D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x276, ????);      
        label_1:
        // 0x00B297DC: LDR w8, [x21, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B297E0: CBNZ w8, #0xb297f0         | if (this.ani.Length != 0) goto label_2; 
        if(this.ani.Length != 0)
        {
            goto label_2;
        }
        // 0x00B297E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x276, ????);      
        // 0x00B297E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B297EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x276, ????);      
        label_2:
        // 0x00B297F0: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B297F4: LDR x8, [x8, #0x188]       | X8 = 1152921504922288128;               
        // 0x00B297F8: LDR x21, [x21, #0x20]      | X21 = this.ani[0]                       
        val_8 = this.ani[0];
        // 0x00B297FC: LDR x8, [x8]               | X8 = typeof(AnimationRunner);           
        // 0x00B29800: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B29804: LDR x22, [x8]              | X22 = AnimationRunner.AniTypeDic;       
        // 0x00B29808: CBNZ x22, #0xb29810        | if (AnimationRunner.AniTypeDic != null) goto label_3;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_3;
        }
        // 0x00B2980C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x276, ????);      
        label_3:
        // 0x00B29810: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00B29814: LDR x8, [x8, #0x150]       | X8 = 1152921515542463952;               
        // 0x00B29818: MOV x0, x22                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B2981C: MOV w1, w20                | W1 = aniType;//m1                       
        // 0x00B29820: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B29824: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  aniType);
        string val_1 = AnimationRunner.AniTypeDic.Item[aniType];
        // 0x00B29828: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B2982C: CBNZ x21, #0xb29834        | if (this.ani[0] != null) goto label_4;  
        if(val_8 != null)
        {
            goto label_4;
        }
        // 0x00B29830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B29834: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29838: MOV x0, x21                | X0 = this.ani[0];//m1                   
        // 0x00B2983C: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B29840: BL #0x270c494              | X0 = this.ani[0].get_Item(name:  val_1);
        UnityEngine.AnimationState val_2 = val_8.Item[val_1];
        // 0x00B29844: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B29848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2984C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B29850: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B29854: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B29858: BL #0x2692458              | X0 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_2);
        bool val_3 = UnityEngine.TrackedReference.op_Inequality(x:  0, y:  val_2);
        // 0x00B2985C: FMOV s8, wzr               | S8 = 0f;                                
        val_9 = 0f;
        // 0x00B29860: TBZ w0, #0, #0xb298fc      | if (val_3 == false) goto label_6;       
        if(val_3 == false)
        {
            goto label_6;
        }
        // 0x00B29864: LDR x1, [x19, #0x48]       | X1 = this.curstate; //P2                
        // 0x00B29868: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2986C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B29870: MOV x2, x20                | X2 = val_2;//m1                         
        // 0x00B29874: BL #0x26923b8              | X0 = UnityEngine.TrackedReference.op_Equality(x:  0, y:  this.curstate);
        bool val_4 = UnityEngine.TrackedReference.op_Equality(x:  0, y:  this.curstate);
        // 0x00B29878: TBZ w0, #0, #0xb298fc      | if (val_4 == false) goto label_6;       
        if(val_4 == false)
        {
            goto label_6;
        }
        // 0x00B2987C: LDR x19, [x19, #0x18]      | X19 = this.ani; //P2                    
        // 0x00B29880: CBNZ x19, #0xb29888        | if (this.ani != null) goto label_7;     
        if(this.ani != null)
        {
            goto label_7;
        }
        // 0x00B29884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B29888: LDR w8, [x19, #0x18]       | W8 = this.ani.Length; //P2              
        // 0x00B2988C: CBNZ w8, #0xb2989c         | if (this.ani.Length != 0) goto label_8; 
        if(this.ani.Length != 0)
        {
            goto label_8;
        }
        // 0x00B29890: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B29894: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29898: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_8:
        // 0x00B2989C: LDR x19, [x19, #0x20]      | X19 = this.ani[0]                       
        val_7 = this.ani[0];
        // 0x00B298A0: CBNZ x20, #0xb298a8        | if (val_2 != null) goto label_9;        
        if(val_2 != null)
        {
            goto label_9;
        }
        // 0x00B298A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00B298A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B298AC: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B298B0: BL #0x270eda0              | X0 = val_2.get_name();                  
        string val_5 = val_2.name;
        // 0x00B298B4: MOV x21, x0                | X21 = val_5;//m1                        
        val_8 = val_5;
        // 0x00B298B8: CBNZ x19, #0xb298c0        | if (this.ani[0] != null) goto label_10; 
        if(val_7 != null)
        {
            goto label_10;
        }
        // 0x00B298BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B298C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B298C4: MOV x0, x19                | X0 = this.ani[0];//m1                   
        // 0x00B298C8: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B298CC: BL #0x270c41c              | X0 = this.ani[0].IsPlaying(name:  val_8);
        bool val_6 = val_7.IsPlaying(name:  val_8);
        // 0x00B298D0: TBZ w0, #0, #0xb298f8      | if (val_6 == false) goto label_11;      
        if(val_6 == false)
        {
            goto label_11;
        }
        // 0x00B298D4: CBNZ x20, #0xb298dc        | if (val_2 != null) goto label_12;       
        if(val_2 != null)
        {
            goto label_12;
        }
        // 0x00B298D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00B298DC: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B298E0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B298E4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B298E8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B298EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B298F0: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B298F4: B #0x270e8b8               | return val_2.get_normalizedTime();      
        return val_2.normalizedTime;
        label_11:
        // 0x00B298F8: FMOV s8, #1.00000000       | S8 = 1;                                 
        val_9 = 1f;
        label_6:
        // 0x00B298FC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29900: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29904: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B29908: MOV v0.16b, v8.16b         | V0 = 1;//m1                             
        // 0x00B2990C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B29910: RET                        |  return (System.Single)1;               
        return (float)val_9;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2841C (11699228), len: 348  VirtAddr: 0x00B2841C RVA: 0x00B2841C token: 100696526 methodIndex: 24846 delegateWrapperIndex: 0 methodInvoker: 0
    public void playOver()
    {
        //
        // Disasemble & Code
        //  | 
        float val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x00B2841C: STP d9, d8, [sp, #-0x40]!  | stack[1152921515545948400] = ???;  stack[1152921515545948408] = ???;  //  dest_result_addr=1152921515545948400 |  dest_result_addr=1152921515545948408
        // 0x00B28420: STP x22, x21, [sp, #0x10]  | stack[1152921515545948416] = ???;  stack[1152921515545948424] = ???;  //  dest_result_addr=1152921515545948416 |  dest_result_addr=1152921515545948424
        // 0x00B28424: STP x20, x19, [sp, #0x20]  | stack[1152921515545948432] = ???;  stack[1152921515545948440] = ???;  //  dest_result_addr=1152921515545948432 |  dest_result_addr=1152921515545948440
        // 0x00B28428: STP x29, x30, [sp, #0x30]  | stack[1152921515545948448] = ???;  stack[1152921515545948456] = ???;  //  dest_result_addr=1152921515545948448 |  dest_result_addr=1152921515545948456
        // 0x00B2842C: ADD x29, sp, #0x30         | X29 = (1152921515545948400 + 48) = 1152921515545948448 (0x100000028C057120);
        // 0x00B28430: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B28434: LDRB w8, [x20, #0x759]     | W8 = (bool)static_value_03733759;       
        // 0x00B28438: MOV x19, x0                | X19 = 1152921515545960464 (0x100000028C05A010);//ML01
        // 0x00B2843C: TBNZ w8, #0, #0xb28458     | if (static_value_03733759 == true) goto label_0;
        // 0x00B28440: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B28444: LDR x8, [x8, #0x770]       | X8 = 0x2B8AEFC;                         
        // 0x00B28448: LDR w0, [x8]               | W0 = 0x27D;                             
        // 0x00B2844C: BL #0x2782188              | X0 = sub_2782188( ?? 0x27D, ????);      
        // 0x00B28450: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B28454: STRB w8, [x20, #0x759]     | static_value_03733759 = true;            //  dest_result_addr=57882457
        label_0:
        // 0x00B28458: LDRB w8, [x19, #0x58]      | W8 = this.isHaveAni; //P2               
        // 0x00B2845C: CBZ w8, #0xb28540          | if (this.isHaveAni == false) goto label_11;
        if(this.isHaveAni == false)
        {
            goto label_11;
        }
        // 0x00B28460: LDR x20, [x19, #0x48]      | X20 = this.curstate; //P2               
        // 0x00B28464: CBNZ x20, #0xb2846c        | if (this.curstate != null) goto label_2;
        if(this.curstate != null)
        {
            goto label_2;
        }
        // 0x00B28468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x27D, ????);      
        label_2:
        // 0x00B2846C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28470: MOV x0, x20                | X0 = this.curstate;//m1                 
        // 0x00B28474: BL #0x270e6f8              | X0 = this.curstate.get_wrapMode();      
        UnityEngine.WrapMode val_1 = this.curstate.wrapMode;
        // 0x00B28478: CMP w0, #2                 | STATE = COMPARE(val_1, 0x2)             
        // 0x00B2847C: B.EQ #0xb28540             | if (val_1 == 0x2) goto label_11;        
        if(val_1 == 2)
        {
            goto label_11;
        }
        // 0x00B28480: LDR s8, [x19, #0x54]       | S8 = this._playTime; //P2               
        val_5 = this._playTime;
        // 0x00B28484: FCMP s8, #0.0              | STATE = COMPARE(this._playTime, 0)      
        // 0x00B28488: B.LE #0xb284a0             | if (val_5 <= 0) goto label_4;           
        if(val_5 <= 0f)
        {
            goto label_4;
        }
        // 0x00B2848C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B28490: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B28494: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_2 = UnityEngine.Time.deltaTime;
        // 0x00B28498: FSUB s8, s8, s0            | S8 = (this._playTime - val_2);          
        val_5 = val_5 - val_2;
        // 0x00B2849C: STR s8, [x19, #0x54]       | this._playTime = (this._playTime - val_2);  //  dest_result_addr=1152921515545960548
        this._playTime = val_5;
        label_4:
        // 0x00B284A0: FCMP s8, #0.0              | STATE = COMPARE((this._playTime - val_2), 0)
        // 0x00B284A4: B.HI #0xb28540             | if (val_5 > 0) goto label_11;           
        if(val_5 > 0f)
        {
            goto label_11;
        }
        // 0x00B284A8: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B284AC: LDR x8, [x8, #0x188]       | X8 = 1152921504922288128;               
        // 0x00B284B0: LDR x20, [x19, #0x28]      | X20 = this.aniName; //P2                
        // 0x00B284B4: LDR x8, [x8]               | X8 = typeof(AnimationRunner);           
        // 0x00B284B8: LDR x8, [x8, #0xa0]        | X8 = AnimationRunner.__il2cppRuntimeField_static_fields;
        // 0x00B284BC: LDR x21, [x8]              | X21 = AnimationRunner.AniTypeDic;       
        // 0x00B284C0: CBNZ x21, #0xb284c8        | if (AnimationRunner.AniTypeDic != null) goto label_6;
        if(AnimationRunner.AniTypeDic != null)
        {
            goto label_6;
        }
        // 0x00B284C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00B284C8: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00B284CC: LDR x8, [x8, #0x150]       | X8 = 1152921515542463952;               
        // 0x00B284D0: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00B284D4: MOV x0, x21                | X0 = AnimationRunner.AniTypeDic;//m1    
        // 0x00B284D8: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.Dictionary<AniType, System.String>::get_Item(AniType key);
        // 0x00B284DC: BL #0x21a398c              | X0 = AnimationRunner.AniTypeDic.get_Item(key:  6);
        string val_3 = AnimationRunner.AniTypeDic.Item[6];
        // 0x00B284E0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B284E4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B284E8: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B284EC: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B284F0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B284F4: TBZ w9, #0, #0xb28508      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B284F8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B284FC: CBNZ w9, #0xb28508         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B28500: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B28504: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_8:
        // 0x00B28508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2850C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B28510: MOV x1, x20                | X1 = this.aniName;//m1                  
        // 0x00B28514: MOV x2, x21                | X2 = val_3;//m1                         
        // 0x00B28518: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  this.aniName);
        bool val_4 = System.String.op_Inequality(a:  0, b:  this.aniName);
        // 0x00B2851C: TBZ w0, #0, #0xb28540      | if (val_4 == false) goto label_11;      
        if(val_4 == false)
        {
            goto label_11;
        }
        // 0x00B28520: LDR w8, [x19, #0x20]       | W8 = this.<aniState>k__BackingField; //P2 
        // 0x00B28524: CMP w8, #1                 | STATE = COMPARE(this.<aniState>k__BackingField, 0x1)
        // 0x00B28528: B.EQ #0xb28554             | if (this.<aniState>k__BackingField == 0x1) goto label_10;
        if((this.<aniState>k__BackingField) == 1)
        {
            goto label_10;
        }
        // 0x00B2852C: CBNZ w8, #0xb28540         | if (this.<aniState>k__BackingField != 0) goto label_11;
        if((this.<aniState>k__BackingField) != 0)
        {
            goto label_11;
        }
        // 0x00B28530: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        val_6 = 0;
        // 0x00B28534: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B28538: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        val_7 = 2;
        // 0x00B2853C: B #0xb28560                |  goto label_12;                         
        goto label_12;
        label_11:
        // 0x00B28540: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28544: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B28548: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2854C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B28550: RET                        |  return;                                
        return;
        label_10:
        // 0x00B28554: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        val_6 = 0;
        // 0x00B28558: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B2855C: MOVZ w1, #0x13             | W1 = 19 (0x13);//ML01                   
        val_7 = 19;
        label_12:
        // 0x00B28560: MOV x0, x19                | X0 = 1152921515545960464 (0x100000028C05A010);//ML01
        // 0x00B28564: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B28568: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2856C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B28570: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B28574: B #0xb293f4                | this.Play(aniType:  19, playTime:  0f, isskill:  false); return;
        this.Play(aniType:  19, playTime:  0f, isskill:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29914 (11704596), len: 156  VirtAddr: 0x00B29914 RVA: 0x00B29914 token: 100696527 methodIndex: 24847 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B29914: STP x22, x21, [sp, #-0x30]! | stack[1152921515546089088] = ???;  stack[1152921515546089096] = ???;  //  dest_result_addr=1152921515546089088 |  dest_result_addr=1152921515546089096
        // 0x00B29918: STP x20, x19, [sp, #0x10]  | stack[1152921515546089104] = ???;  stack[1152921515546089112] = ???;  //  dest_result_addr=1152921515546089104 |  dest_result_addr=1152921515546089112
        // 0x00B2991C: STP x29, x30, [sp, #0x20]  | stack[1152921515546089120] = ???;  stack[1152921515546089128] = ???;  //  dest_result_addr=1152921515546089120 |  dest_result_addr=1152921515546089128
        // 0x00B29920: ADD x29, sp, #0x20         | X29 = (1152921515546089088 + 32) = 1152921515546089120 (0x100000028C0796A0);
        // 0x00B29924: SUB sp, sp, #0x10          | SP = (1152921515546089088 - 16) = 1152921515546089072 (0x100000028C079670);
        // 0x00B29928: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2992C: LDRB w8, [x20, #0x75a]     | W8 = (bool)static_value_0373375A;       
        // 0x00B29930: MOV x19, x0                | X19 = 1152921515546101136 (0x100000028C07C590);//ML01
        // 0x00B29934: TBNZ w8, #0, #0xb29950     | if (static_value_0373375A == true) goto label_0;
        // 0x00B29938: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00B2993C: LDR x8, [x8, #0xa90]       | X8 = 0x2B8AEDC;                         
        // 0x00B29940: LDR w0, [x8]               | W0 = 0x275;                             
        // 0x00B29944: BL #0x2782188              | X0 = sub_2782188( ?? 0x275, ????);      
        // 0x00B29948: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2994C: STRB w8, [x20, #0x75a]     | static_value_0373375A = true;            //  dest_result_addr=57882458
        label_0:
        // 0x00B29950: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B29954: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
        // 0x00B29958: ADD x1, sp, #0xc           | X1 = (1152921515546089072 + 12) = 1152921515546089084 (0x100000028C07967C);
        // 0x00B2995C: STR wzr, [sp, #0xc]        | stack[1152921515546089084] = 0x0;        //  dest_result_addr=1152921515546089084
        // 0x00B29960: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
        // 0x00B29964: BL #0x27bc028              | X0 = 1152921515546133136 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), null);
        // 0x00B29968: MOV x20, x0                | X20 = 1152921515546133136 (0x100000028C084290);//ML01
        // 0x00B2996C: CBNZ x20, #0xb29974        | if (null != 0) goto label_1;            
        if(0 != 0)
        {
            goto label_1;
        }
        // 0x00B29970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null, ????);       
        label_1:
        // 0x00B29974: LDR x8, [x20]              | X8 = typeof(AnimationRunner.AniType);   
        // 0x00B29978: MOV x0, x20                | X0 = 1152921515546133136 (0x100000028C084290);//ML01
        // 0x00B2997C: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
        // 0x00B29980: BLR x9                     | X0 = null.ToString();                   
        string val_1 = 0.ToString();
        // 0x00B29984: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B29988: CBNZ x20, #0xb29990        | if (null != 0) goto label_2;            
        if(0 != 0)
        {
            goto label_2;
        }
        // 0x00B2998C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B29990: MOV x0, x20                | X0 = 1152921515546133136 (0x100000028C084290);//ML01
        // 0x00B29994: BL #0x27bc4e8              | null.System.IDisposable.Dispose();      
        0.System.IDisposable.Dispose();
        // 0x00B29998: STR x21, [x19, #0x28]      | this.aniName = val_1;                    //  dest_result_addr=1152921515546101176
        this.aniName = val_1;
        // 0x00B2999C: SUB sp, x29, #0x20         | SP = (1152921515546089120 - 32) = 1152921515546089088 (0x100000028C079680);
        // 0x00B299A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B299A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B299A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B299AC: RET                        |  return;                                
        return;
    
    }

}
