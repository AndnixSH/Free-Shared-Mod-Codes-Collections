using UnityEngine;
public class CameraMouseMove_PVP : MonoBehaviour
{
    // Fields
    private UnityEngine.Camera mCamera; //  0x00000018
    private UnityEngine.Animator animator; //  0x00000020
    public int cameraMoveSpeed; //  0x00000028
    public string camera_limit; //  0x00000030
    private bool CanMoveY; //  0x00000038
    private bool CanMoveZ; //  0x00000039
    public bool CanMoveCamera; //  0x0000003A
    private float originalPositionX_min; //  0x0000003C
    private float originalPositionX_max; //  0x00000040
    private float originalPositionY_min; //  0x00000044
    private float originalPositionY_max; //  0x00000048
    private float originalPositionZ_min; //  0x0000004C
    private float originalPositionZ_max; //  0x00000050
    private UnityEngine.Vector3 cameraScreenPoint; //  0x00000054
    private UnityEngine.Vector3 beginMouseWorld; //  0x00000060
    private UnityEngine.Vector3 currentMouseWorldPoint; //  0x0000006C
    private UnityEngine.Vector3 offsetPosition; //  0x00000078
    private UnityEngine.Vector3 targetPosition; //  0x00000084
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BAC90C (12241164), len: 96  VirtAddr: 0x00BAC90C RVA: 0x00BAC90C token: 100690238 methodIndex: 25700 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraMouseMove_PVP()
    {
        //
        // Disasemble & Code
        // 0x00BAC90C: STP x20, x19, [sp, #-0x20]! | stack[1152921514492395952] = ???;  stack[1152921514492395960] = ???;  //  dest_result_addr=1152921514492395952 |  dest_result_addr=1152921514492395960
        // 0x00BAC910: STP x29, x30, [sp, #0x10]  | stack[1152921514492395968] = ???;  stack[1152921514492395976] = ???;  //  dest_result_addr=1152921514492395968 |  dest_result_addr=1152921514492395976
        // 0x00BAC914: ADD x29, sp, #0x10         | X29 = (1152921514492395952 + 16) = 1152921514492395968 (0x100000024D3981C0);
        // 0x00BAC918: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BAC91C: LDRB w8, [x20, #0xb02]     | W8 = (bool)static_value_03733B02;       
        // 0x00BAC920: MOV x19, x0                | X19 = 1152921514492407984 (0x100000024D39B0B0);//ML01
        // 0x00BAC924: TBNZ w8, #0, #0xbac940     | if (static_value_03733B02 == true) goto label_0;
        // 0x00BAC928: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00BAC92C: LDR x8, [x8, #0x768]       | X8 = 0x2B90248;                         
        // 0x00BAC930: LDR w0, [x8]               | W0 = 0x1756;                            
        // 0x00BAC934: BL #0x2782188              | X0 = sub_2782188( ?? 0x1756, ????);     
        // 0x00BAC938: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAC93C: STRB w8, [x20, #0xb02]     | static_value_03733B02 = true;            //  dest_result_addr=57883394
        label_0:
        // 0x00BAC940: ORR w8, wzr, #8            | W8 = 8(0x8);                            
        // 0x00BAC944: STR w8, [x19, #0x28]       | this.cameraMoveSpeed = 8;                //  dest_result_addr=1152921514492408024
        this.cameraMoveSpeed = 8;
        // 0x00BAC948: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00BAC94C: LDR x8, [x8, #0x498]       | X8 = (string**)(1152921514492383872)("8_32,52_10,17_42,67");
        // 0x00BAC950: MOV x0, x19                | X0 = 1152921514492407984 (0x100000024D39B0B0);//ML01
        // 0x00BAC954: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC958: LDR x8, [x8]               | X8 = "8_32,52_10,17_42,67";             
        // 0x00BAC95C: STR x8, [x19, #0x30]       | this.camera_limit = "8_32,52_10,17_42,67";  //  dest_result_addr=1152921514492408032
        this.camera_limit = "8_32,52_10,17_42,67";
        // 0x00BAC960: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAC964: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BAC968: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAC96C (12241260), len: 1028  VirtAddr: 0x00BAC96C RVA: 0x00BAC96C token: 100690239 methodIndex: 25701 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init(string camera_limit)
    {
        //
        // Disasemble & Code
        //  | 
        System.Char[] val_15;
        // 0x00BAC96C: STP x24, x23, [sp, #-0x40]! | stack[1152921514492712720] = ???;  stack[1152921514492712728] = ???;  //  dest_result_addr=1152921514492712720 |  dest_result_addr=1152921514492712728
        // 0x00BAC970: STP x22, x21, [sp, #0x10]  | stack[1152921514492712736] = ???;  stack[1152921514492712744] = ???;  //  dest_result_addr=1152921514492712736 |  dest_result_addr=1152921514492712744
        // 0x00BAC974: STP x20, x19, [sp, #0x20]  | stack[1152921514492712752] = ???;  stack[1152921514492712760] = ???;  //  dest_result_addr=1152921514492712752 |  dest_result_addr=1152921514492712760
        // 0x00BAC978: STP x29, x30, [sp, #0x30]  | stack[1152921514492712768] = ???;  stack[1152921514492712776] = ???;  //  dest_result_addr=1152921514492712768 |  dest_result_addr=1152921514492712776
        // 0x00BAC97C: ADD x29, sp, #0x30         | X29 = (1152921514492712720 + 48) = 1152921514492712768 (0x100000024D3E5740);
        // 0x00BAC980: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BAC984: LDRB w8, [x21, #0xb03]     | W8 = (bool)static_value_03733B03;       
        // 0x00BAC988: MOV x20, x1                | X20 = camera_limit;//m1                 
        // 0x00BAC98C: MOV x19, x0                | X19 = 1152921514492724784 (0x100000024D3E8630);//ML01
        // 0x00BAC990: TBNZ w8, #0, #0xbac9ac     | if (static_value_03733B03 == true) goto label_0;
        // 0x00BAC994: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00BAC998: LDR x8, [x8, #0xed0]       | X8 = 0x2B9024C;                         
        // 0x00BAC99C: LDR w0, [x8]               | W0 = 0x1757;                            
        // 0x00BAC9A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1757, ????);     
        // 0x00BAC9A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAC9A8: STRB w8, [x21, #0xb03]     | static_value_03733B03 = true;            //  dest_result_addr=57883395
        label_0:
        // 0x00BAC9AC: ADRP x23, #0x3627000       | X23 = 56782848 (0x3627000);             
        // 0x00BAC9B0: LDR x23, [x23, #0xd58]     | X23 = 1152921504947213072;              
        // 0x00BAC9B4: LDR x21, [x23]             | X21 = typeof(System.Char[]);            
        // 0x00BAC9B8: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BAC9BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00BAC9C0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BAC9C4: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BAC9C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00BAC9CC: MOV x21, x0                | X21 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BAC9D0: CBNZ x21, #0xbac9d8        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00BAC9D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_1:
        // 0x00BAC9D8: LDR w8, [x21, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00BAC9DC: CBNZ w8, #0xbac9ec         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_2;
        // 0x00BAC9E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00BAC9E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAC9E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_2:
        // 0x00BAC9EC: MOVZ w8, #0x5f             | W8 = 95 (0x5F);//ML01                   
        // 0x00BAC9F0: STRH w8, [x21, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x5F;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 95;
        // 0x00BAC9F4: CBNZ x20, #0xbac9fc        | if (camera_limit != null) goto label_3; 
        if(camera_limit != null)
        {
            goto label_3;
        }
        // 0x00BAC9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_3:
        // 0x00BAC9FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACA00: MOV x0, x20                | X0 = camera_limit;//m1                  
        // 0x00BACA04: MOV x1, x21                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACA08: BL #0x18a881c              | X0 = camera_limit.Split(separator:  null);
        System.String[] val_1 = camera_limit.Split(separator:  null);
        // 0x00BACA0C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BACA10: CBNZ x20, #0xbaca18        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00BACA14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00BACA18: LDR w8, [x20, #0x18]       | W8 = val_1.Length; //P2                 
        // 0x00BACA1C: CBNZ w8, #0xbaca2c         | if (val_1.Length != 0) goto label_5;    
        if(val_1.Length != 0)
        {
            goto label_5;
        }
        // 0x00BACA20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00BACA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACA28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_5:
        // 0x00BACA2C: LDR x1, [x20, #0x20]       | X1 = val_1[0]                           
        string val_15 = val_1[0];
        // 0x00BACA30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACA34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACA38: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00BACA3C: STR w0, [x19, #0x28]       | this.cameraMoveSpeed = val_2;            //  dest_result_addr=1152921514492724824
        this.cameraMoveSpeed = val_2;
        // 0x00BACA40: LDR w8, [x20, #0x18]       | W8 = val_1.Length; //P2                 
        // 0x00BACA44: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
        // 0x00BACA48: B.HI #0xbaca58             | if (val_1.Length > 1) goto label_6;     
        if(val_1.Length > 1)
        {
            goto label_6;
        }
        // 0x00BACA4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
        // 0x00BACA50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACA54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        label_6:
        // 0x00BACA58: LDR x22, [x23]             | X22 = typeof(System.Char[]);            
        // 0x00BACA5C: LDR x21, [x20, #0x28]      | X21 = val_1[1]                          
        string val_16 = val_1[1];
        // 0x00BACA60: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACA64: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00BACA68: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BACA6C: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACA70: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00BACA74: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACA78: CBNZ x22, #0xbaca80        | if ( != null) goto label_7;             
        if(null != null)
        {
            goto label_7;
        }
        // 0x00BACA7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_7:
        // 0x00BACA80: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00BACA84: CBNZ w8, #0xbaca94         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_8;
        // 0x00BACA88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00BACA8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACA90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_8:
        // 0x00BACA94: MOVZ w8, #0x2c             | W8 = 44 (0x2C);//ML01                   
        // 0x00BACA98: STRH w8, [x22, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2C;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 44;
        // 0x00BACA9C: CBNZ x21, #0xbacaa4        | if (val_1[1] != null) goto label_9;     
        if(val_16 != null)
        {
            goto label_9;
        }
        // 0x00BACAA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_9:
        // 0x00BACAA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACAA8: MOV x0, x21                | X0 = val_1[1];//m1                      
        // 0x00BACAAC: MOV x1, x22                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACAB0: BL #0x18a881c              | X0 = val_1[1].Split(separator:  null);  
        System.String[] val_3 = val_16.Split(separator:  null);
        // 0x00BACAB4: MOV x21, x0                | X21 = val_3;//m1                        
        val_15 = val_3;
        // 0x00BACAB8: CBNZ x21, #0xbacac0        | if (val_3 != null) goto label_10;       
        if(val_15 != null)
        {
            goto label_10;
        }
        // 0x00BACABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x00BACAC0: LDR w8, [x21, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00BACAC4: CBNZ w8, #0xbacad4         | if (val_3.Length != 0) goto label_11;   
        if(val_3.Length != 0)
        {
            goto label_11;
        }
        // 0x00BACAC8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00BACACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACAD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_11:
        // 0x00BACAD4: LDR x1, [x21, #0x20]       | X1 = val_3[0]                           
        string val_17 = val_15[0];
        // 0x00BACAD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACAE0: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_4 = System.Single.Parse(s:  0);
        // 0x00BACAE4: STR s0, [x19, #0x3c]       | this.originalPositionX_min = val_4;      //  dest_result_addr=1152921514492724844
        this.originalPositionX_min = val_4;
        // 0x00BACAE8: LDR w8, [x21, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00BACAEC: CMP w8, #1                 | STATE = COMPARE(val_3.Length, 0x1)      
        // 0x00BACAF0: B.HI #0xbacb00             | if (val_3.Length > 1) goto label_12;    
        if(val_3.Length > 1)
        {
            goto label_12;
        }
        // 0x00BACAF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00BACAF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACAFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_12:
        // 0x00BACB00: LDR x1, [x21, #0x28]       | X1 = val_3[1]                           
        string val_18 = val_15[1];
        // 0x00BACB04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACB08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACB0C: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_5 = System.Single.Parse(s:  0);
        // 0x00BACB10: STR s0, [x19, #0x40]       | this.originalPositionX_max = val_5;      //  dest_result_addr=1152921514492724848
        this.originalPositionX_max = val_5;
        // 0x00BACB14: STRB wzr, [x19, #0x38]     | this.CanMoveY = false;                   //  dest_result_addr=1152921514492724840
        this.CanMoveY = false;
        // 0x00BACB18: CBNZ x20, #0xbacb20        | if (val_1 != null) goto label_13;       
        if(val_1 != null)
        {
            goto label_13;
        }
        // 0x00BACB1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_13:
        // 0x00BACB20: LDR w8, [x20, #0x18]       | W8 = val_1.Length; //P2                 
        // 0x00BACB24: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
        // 0x00BACB28: B.LT #0xbacbf0             | if (val_1.Length < 3) goto label_14;    
        if(val_1.Length < 3)
        {
            goto label_14;
        }
        // 0x00BACB2C: LDR x22, [x23]             | X22 = typeof(System.Char[]);            
        // 0x00BACB30: LDR x21, [x20, #0x30]      | X21 = val_1[2]                          
        string val_19 = val_1[2];
        // 0x00BACB34: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACB38: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00BACB3C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BACB40: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACB44: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00BACB48: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACB4C: CBNZ x22, #0xbacb54        | if ( != null) goto label_15;            
        if(null != null)
        {
            goto label_15;
        }
        // 0x00BACB50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_15:
        // 0x00BACB54: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00BACB58: CBNZ w8, #0xbacb68         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_16;
        // 0x00BACB5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00BACB60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACB64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_16:
        // 0x00BACB68: MOVZ w8, #0x2c             | W8 = 44 (0x2C);//ML01                   
        // 0x00BACB6C: STRH w8, [x22, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2C;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 44;
        // 0x00BACB70: CBNZ x21, #0xbacb78        | if (val_1[2] != null) goto label_17;    
        if(val_19 != null)
        {
            goto label_17;
        }
        // 0x00BACB74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_17:
        // 0x00BACB78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACB7C: MOV x0, x21                | X0 = val_1[2];//m1                      
        // 0x00BACB80: MOV x1, x22                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACB84: BL #0x18a881c              | X0 = val_1[2].Split(separator:  null);  
        System.String[] val_6 = val_19.Split(separator:  null);
        // 0x00BACB88: MOV x21, x0                | X21 = val_6;//m1                        
        val_15 = val_6;
        // 0x00BACB8C: CBNZ x21, #0xbacb94        | if (val_6 != null) goto label_18;       
        if(val_15 != null)
        {
            goto label_18;
        }
        // 0x00BACB90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_18:
        // 0x00BACB94: LDR w8, [x21, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x00BACB98: CBNZ w8, #0xbacba8         | if (val_6.Length != 0) goto label_19;   
        if(val_6.Length != 0)
        {
            goto label_19;
        }
        // 0x00BACB9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00BACBA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACBA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_19:
        // 0x00BACBA8: LDR x1, [x21, #0x20]       | X1 = val_6[0]                           
        string val_20 = val_15[0];
        // 0x00BACBAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACBB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACBB4: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_7 = System.Single.Parse(s:  0);
        // 0x00BACBB8: STR s0, [x19, #0x44]       | this.originalPositionY_min = val_7;      //  dest_result_addr=1152921514492724852
        this.originalPositionY_min = val_7;
        // 0x00BACBBC: LDR w8, [x21, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x00BACBC0: CMP w8, #1                 | STATE = COMPARE(val_6.Length, 0x1)      
        // 0x00BACBC4: B.HI #0xbacbd4             | if (val_6.Length > 1) goto label_20;    
        if(val_6.Length > 1)
        {
            goto label_20;
        }
        // 0x00BACBC8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00BACBCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACBD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_20:
        // 0x00BACBD4: LDR x1, [x21, #0x28]       | X1 = val_6[1]                           
        string val_21 = val_15[1];
        // 0x00BACBD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACBDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACBE0: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_8 = System.Single.Parse(s:  0);
        // 0x00BACBE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BACBE8: STR s0, [x19, #0x48]       | this.originalPositionY_max = val_8;      //  dest_result_addr=1152921514492724856
        this.originalPositionY_max = val_8;
        // 0x00BACBEC: STRB w8, [x19, #0x38]      | this.CanMoveY = true;                    //  dest_result_addr=1152921514492724840
        this.CanMoveY = true;
        label_14:
        // 0x00BACBF0: STRB wzr, [x19, #0x39]     | this.CanMoveZ = false;                   //  dest_result_addr=1152921514492724841
        this.CanMoveZ = false;
        // 0x00BACBF4: CBNZ x20, #0xbacbfc        | if (val_1 != null) goto label_21;       
        if(val_1 != null)
        {
            goto label_21;
        }
        // 0x00BACBF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_21:
        // 0x00BACBFC: LDR w8, [x20, #0x18]       | W8 = val_1.Length; //P2                 
        // 0x00BACC00: CMP w8, #4                 | STATE = COMPARE(val_1.Length, 0x4)      
        // 0x00BACC04: B.LT #0xbacccc             | if (val_1.Length < 4) goto label_22;    
        if(val_1.Length < 4)
        {
            goto label_22;
        }
        // 0x00BACC08: LDR x21, [x23]             | X21 = typeof(System.Char[]);            
        // 0x00BACC0C: LDR x20, [x20, #0x38]      | X20 = val_1[3]                          
        string val_22 = val_1[3];
        // 0x00BACC10: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACC14: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00BACC18: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BACC1C: MOV x0, x21                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACC20: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00BACC24: MOV x21, x0                | X21 = 1152921504947213072 (0x1000000014499310);//ML01
        val_15 = null;
        // 0x00BACC28: CBNZ x21, #0xbacc30        | if ( != null) goto label_23;            
        if(null != null)
        {
            goto label_23;
        }
        // 0x00BACC2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_23:
        // 0x00BACC30: LDR w8, [x21, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
        // 0x00BACC34: CBNZ w8, #0xbacc44         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_24;
        // 0x00BACC38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
        // 0x00BACC3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACC40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
        label_24:
        // 0x00BACC44: MOVZ w8, #0x2c             | W8 = 44 (0x2C);//ML01                   
        // 0x00BACC48: STRH w8, [x21, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x2C;  //  dest_result_addr=1152921504947213104
        typeof(System.Char[]).__il2cppRuntimeField_20 = 44;
        // 0x00BACC4C: CBNZ x20, #0xbacc54        | if (val_1[3] != null) goto label_25;    
        if(val_22 != null)
        {
            goto label_25;
        }
        // 0x00BACC50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
        label_25:
        // 0x00BACC54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACC58: MOV x0, x20                | X0 = val_1[3];//m1                      
        // 0x00BACC5C: MOV x1, x21                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BACC60: BL #0x18a881c              | X0 = val_1[3].Split(separator:  val_15);
        System.String[] val_9 = val_22.Split(separator:  val_15);
        // 0x00BACC64: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00BACC68: CBNZ x20, #0xbacc70        | if (val_9 != null) goto label_26;       
        if(val_9 != null)
        {
            goto label_26;
        }
        // 0x00BACC6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_26:
        // 0x00BACC70: LDR w8, [x20, #0x18]       | W8 = val_9.Length; //P2                 
        // 0x00BACC74: CBNZ w8, #0xbacc84         | if (val_9.Length != 0) goto label_27;   
        if(val_9.Length != 0)
        {
            goto label_27;
        }
        // 0x00BACC78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
        // 0x00BACC7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACC80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_27:
        // 0x00BACC84: LDR x1, [x20, #0x20]       | X1 = val_9[0]                           
        string val_23 = val_9[0];
        // 0x00BACC88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACC8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACC90: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_10 = System.Single.Parse(s:  0);
        // 0x00BACC94: STR s0, [x19, #0x4c]       | this.originalPositionZ_min = val_10;     //  dest_result_addr=1152921514492724860
        this.originalPositionZ_min = val_10;
        // 0x00BACC98: LDR w8, [x20, #0x18]       | W8 = val_9.Length; //P2                 
        // 0x00BACC9C: CMP w8, #1                 | STATE = COMPARE(val_9.Length, 0x1)      
        // 0x00BACCA0: B.HI #0xbaccb0             | if (val_9.Length > 1) goto label_28;    
        if(val_9.Length > 1)
        {
            goto label_28;
        }
        // 0x00BACCA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00BACCA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACCAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_28:
        // 0x00BACCB0: LDR x1, [x20, #0x28]       | X1 = val_9[1]                           
        string val_24 = val_9[1];
        // 0x00BACCB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACCB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACCBC: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_11 = System.Single.Parse(s:  0);
        // 0x00BACCC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BACCC4: STR s0, [x19, #0x50]       | this.originalPositionZ_max = val_11;     //  dest_result_addr=1152921514492724864
        this.originalPositionZ_max = val_11;
        // 0x00BACCC8: STRB w8, [x19, #0x39]      | this.CanMoveZ = true;                    //  dest_result_addr=1152921514492724841
        this.CanMoveZ = true;
        label_22:
        // 0x00BACCCC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BACCD0: STRB w8, [x19, #0x3a]      | this.CanMoveCamera = true;               //  dest_result_addr=1152921514492724842
        this.CanMoveCamera = true;
        // 0x00BACCD4: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x00BACCD8: LDR x8, [x8, #0x980]       | X8 = 1152921511727430992;               
        // 0x00BACCDC: MOV x0, x19                | X0 = 1152921514492724784 (0x100000024D3E8630);//ML01
        // 0x00BACCE0: LDR x1, [x8]               | X1 = public UnityEngine.Animator UnityEngine.Component::GetComponent<UnityEngine.Animator>();
        // 0x00BACCE4: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Animator>();
        UnityEngine.Animator val_12 = this.GetComponent<UnityEngine.Animator>();
        // 0x00BACCE8: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00BACCEC: STR x20, [x19, #0x20]      | this.animator = val_12;                  //  dest_result_addr=1152921514492724816
        this.animator = val_12;
        // 0x00BACCF0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00BACCF4: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00BACCF8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00BACCFC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00BACD00: TBZ w8, #0, #0xbacd10      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00BACD04: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00BACD08: CBNZ w8, #0xbacd10         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00BACD0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_30:
        // 0x00BACD10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACD14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACD18: MOV x1, x20                | X1 = val_12;//m1                        
        // 0x00BACD1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BACD20: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_12);
        bool val_13 = UnityEngine.Object.op_Inequality(x:  0, y:  val_12);
        // 0x00BACD24: TBZ w0, #0, #0xbacd44      | if (val_13 == false) goto label_31;     
        if(val_13 == false)
        {
            goto label_31;
        }
        // 0x00BACD28: LDR x20, [x19, #0x20]      | X20 = this.animator; //P2               
        // 0x00BACD2C: CBNZ x20, #0xbacd34        | if (this.animator != null) goto label_32;
        if(this.animator != null)
        {
            goto label_32;
        }
        // 0x00BACD30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_32:
        // 0x00BACD34: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BACD38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACD3C: MOV x0, x20                | X0 = this.animator;//m1                 
        // 0x00BACD40: BL #0x20cb458              | this.animator.set_enabled(value:  false);
        this.animator.enabled = false;
        label_31:
        // 0x00BACD44: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BACD48: LDR x8, [x8, #0x338]       | X8 = 1152921509941328016;               
        // 0x00BACD4C: MOV x0, x19                | X0 = 1152921514492724784 (0x100000024D3E8630);//ML01
        // 0x00BACD50: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x00BACD54: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_14 = this.GetComponent<UnityEngine.Camera>();
        // 0x00BACD58: STR x0, [x19, #0x18]       | this.mCamera = val_14;                   //  dest_result_addr=1152921514492724808
        this.mCamera = val_14;
        // 0x00BACD5C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BACD60: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BACD64: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BACD68: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BACD6C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BACD70 (12242288), len: 4  VirtAddr: 0x00BACD70 RVA: 0x00BACD70 token: 100690240 methodIndex: 25702 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        // 0x00BACD70: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BACD74 (12242292), len: 1092  VirtAddr: 0x00BACD74 RVA: 0x00BACD74 token: 100690241 methodIndex: 25703 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        float val_30;
        //  | 
        var val_31;
        // 0x00BACD74: STP d13, d12, [sp, #-0x60]! | stack[1152921514493178352] = ???;  stack[1152921514493178360] = ???;  //  dest_result_addr=1152921514493178352 |  dest_result_addr=1152921514493178360
        // 0x00BACD78: STP d11, d10, [sp, #0x10]  | stack[1152921514493178368] = ???;  stack[1152921514493178376] = ???;  //  dest_result_addr=1152921514493178368 |  dest_result_addr=1152921514493178376
        // 0x00BACD7C: STP d9, d8, [sp, #0x20]    | stack[1152921514493178384] = ???;  stack[1152921514493178392] = ???;  //  dest_result_addr=1152921514493178384 |  dest_result_addr=1152921514493178392
        // 0x00BACD80: STP x22, x21, [sp, #0x30]  | stack[1152921514493178400] = ???;  stack[1152921514493178408] = ???;  //  dest_result_addr=1152921514493178400 |  dest_result_addr=1152921514493178408
        // 0x00BACD84: STP x20, x19, [sp, #0x40]  | stack[1152921514493178416] = ???;  stack[1152921514493178424] = ???;  //  dest_result_addr=1152921514493178416 |  dest_result_addr=1152921514493178424
        // 0x00BACD88: STP x29, x30, [sp, #0x50]  | stack[1152921514493178432] = ???;  stack[1152921514493178440] = ???;  //  dest_result_addr=1152921514493178432 |  dest_result_addr=1152921514493178440
        // 0x00BACD8C: ADD x29, sp, #0x50         | X29 = (1152921514493178352 + 80) = 1152921514493178432 (0x100000024D457240);
        // 0x00BACD90: SUB sp, sp, #0x20          | SP = (1152921514493178352 - 32) = 1152921514493178320 (0x100000024D4571D0);
        // 0x00BACD94: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BACD98: LDRB w8, [x20, #0xb04]     | W8 = (bool)static_value_03733B04;       
        // 0x00BACD9C: MOV x19, x0                | X19 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BACDA0: TBNZ w8, #0, #0xbacdbc     | if (static_value_03733B04 == true) goto label_0;
        // 0x00BACDA4: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00BACDA8: LDR x8, [x8, #0xd10]       | X8 = 0x2B90250;                         
        // 0x00BACDAC: LDR w0, [x8]               | W0 = 0x1758;                            
        // 0x00BACDB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1758, ????);     
        // 0x00BACDB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BACDB8: STRB w8, [x20, #0xb04]     | static_value_03733B04 = true;            //  dest_result_addr=57883396
        label_0:
        // 0x00BACDBC: LDRB w8, [x19, #0x3a]      | W8 = this.CanMoveCamera; //P2           
        // 0x00BACDC0: CBZ w8, #0xbad198          | if (this.CanMoveCamera == false) goto label_19;
        if(this.CanMoveCamera == false)
        {
            goto label_19;
        }
        // 0x00BACDC4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00BACDC8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00BACDCC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00BACDD0: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00BACDD4: TBZ w8, #0, #0xbacde4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BACDD8: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00BACDDC: CBNZ w8, #0xbacde4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BACDE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_3:
        // 0x00BACDE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACDE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACDEC: BL #0x26a8370              | X0 = ZMG.get_TeamSkillMgr();            
        TeamSkillMgr val_1 = ZMG.TeamSkillMgr;
        // 0x00BACDF0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00BACDF4: CBNZ x20, #0xbacdfc        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00BACDF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00BACDFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACE00: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00BACE04: BL #0xdee29c               | X0 = val_1.get_isUseingSkill();         
        bool val_2 = val_1.isUseingSkill;
        // 0x00BACE08: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00BACE0C: TBNZ w8, #0, #0xbad198     | if ((val_2 & 1) == true) goto label_19; 
        if(val_3 == true)
        {
            goto label_19;
        }
        // 0x00BACE10: ADRP x22, #0x3660000       | X22 = 57016320 (0x3660000);             
        // 0x00BACE14: LDR x22, [x22, #0x570]     | X22 = 1152921504694706176;              
        // 0x00BACE18: LDR x0, [x22]              | X0 = typeof(UnityEngine.Input);         
        // 0x00BACE1C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Input.__il2cppRuntimeField_10A;
        // 0x00BACE20: TBZ w8, #0, #0xbace30      | if (UnityEngine.Input.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00BACE24: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Input.__il2cppRuntimeField_cctor_finished;
        // 0x00BACE28: CBNZ w8, #0xbace30         | if (UnityEngine.Input.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00BACE2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Input), ????);
        label_7:
        // 0x00BACE30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACE34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACE38: BL #0x1a70740              | X0 = UnityEngine.Input.get_touchCount();
        int val_4 = UnityEngine.Input.touchCount;
        // 0x00BACE3C: CMP w0, #1                 | STATE = COMPARE(val_4, 0x1)             
        // 0x00BACE40: B.GT #0xbad198             | if (val_4 > 1) goto label_19;           
        if(val_4 > 1)
        {
            goto label_19;
        }
        // 0x00BACE44: LDR x0, [x22]              | X0 = typeof(UnityEngine.Input);         
        // 0x00BACE48: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Input.__il2cppRuntimeField_10A;
        // 0x00BACE4C: TBZ w8, #0, #0xbace5c      | if (UnityEngine.Input.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00BACE50: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Input.__il2cppRuntimeField_cctor_finished;
        // 0x00BACE54: CBNZ w8, #0xbace5c         | if (UnityEngine.Input.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00BACE58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Input), ????);
        label_10:
        // 0x00BACE5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACE60: MOVZ w1, #0x143            | W1 = 323 (0x143);//ML01                 
        // 0x00BACE64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACE68: BL #0x1a6fbb4              | X0 = UnityEngine.Input.GetKeyDown(key:  0);
        bool val_5 = UnityEngine.Input.GetKeyDown(key:  0);
        // 0x00BACE6C: TBZ w0, #0, #0xbacf3c      | if (val_5 == false) goto label_11;      
        if(val_5 == false)
        {
            goto label_11;
        }
        // 0x00BACE70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACE74: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BACE78: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_6 = this.transform;
        // 0x00BACE7C: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00BACE80: CBNZ x20, #0xbace88        | if (val_6 != null) goto label_12;       
        if(val_6 != null)
        {
            goto label_12;
        }
        // 0x00BACE84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00BACE88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACE8C: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00BACE90: BL #0x2693510              | X0 = val_6.get_position();              
        UnityEngine.Vector3 val_7 = val_6.position;
        // 0x00BACE94: STP s0, s1, [x19, #0x54]   | this.cameraScreenPoint = val_7;  mem[1152921514493190536] = val_7.y;  //  dest_result_addr=1152921514493190532 |  dest_result_addr=1152921514493190536
        this.cameraScreenPoint = val_7;
        mem[1152921514493190536] = val_7.y;
        // 0x00BACE98: STR s2, [x19, #0x5c]       | mem[1152921514493190540] = val_7.z;      //  dest_result_addr=1152921514493190540
        mem[1152921514493190540] = val_7.z;
        // 0x00BACE9C: LDR x0, [x22]              | X0 = typeof(UnityEngine.Input);         
        // 0x00BACEA0: LDR x20, [x19, #0x18]      | X20 = this.mCamera; //P2                
        // 0x00BACEA4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Input.__il2cppRuntimeField_10A;
        // 0x00BACEA8: TBZ w8, #0, #0xbaceb8      | if (UnityEngine.Input.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00BACEAC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Input.__il2cppRuntimeField_cctor_finished;
        // 0x00BACEB0: CBNZ w8, #0xbaceb8         | if (UnityEngine.Input.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00BACEB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Input), ????);
        label_14:
        // 0x00BACEB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACEBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACEC0: BL #0x1a6fed0              | X0 = UnityEngine.Input.get_mousePosition();
        UnityEngine.Vector3 val_8 = UnityEngine.Input.mousePosition;
        // 0x00BACEC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACEC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACECC: MOV v8.16b, v0.16b         | V8 = val_8.x;//m1                       
        val_30 = val_8.x;
        // 0x00BACED0: BL #0x1a6fed0              | X0 = UnityEngine.Input.get_mousePosition();
        UnityEngine.Vector3 val_9 = UnityEngine.Input.mousePosition;
        // 0x00BACED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACED8: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BACEDC: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        // 0x00BACEE0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_10 = this.transform;
        // 0x00BACEE4: MOV x21, x0                | X21 = val_10;//m1                       
        val_31 = val_10;
        // 0x00BACEE8: CBNZ x21, #0xbacef0        | if (val_10 != null) goto label_15;      
        if(val_31 != null)
        {
            goto label_15;
        }
        // 0x00BACEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_15:
        // 0x00BACEF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACEF4: MOV x0, x21                | X0 = val_10;//m1                        
        // 0x00BACEF8: BL #0x2693510              | X0 = val_10.get_position();             
        UnityEngine.Vector3 val_11 = val_31.position;
        // 0x00BACEFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACF00: ADD x0, sp, #0x10          | X0 = (1152921514493178320 + 16) = 1152921514493178336 (0x100000024D4571E0);
        // 0x00BACF04: MOV v0.16b, v8.16b         | V0 = val_8.x;//m1                       
        // 0x00BACF08: MOV v1.16b, v9.16b         | V1 = val_9.y;//m1                       
        // 0x00BACF0C: STR wzr, [sp, #0x18]       | stack[1152921514493178344] = 0x0;        //  dest_result_addr=1152921514493178344
        // 0x00BACF10: STR xzr, [sp, #0x10]       | stack[1152921514493178336] = 0x0;        //  dest_result_addr=1152921514493178336
        // 0x00BACF14: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00BACF18: CBNZ x20, #0xbacf20        | if (this.mCamera != null) goto label_16;
        if(this.mCamera != null)
        {
            goto label_16;
        }
        // 0x00BACF1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000024D4571E0, ????);
        label_16:
        // 0x00BACF20: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00BACF24: LDR s2, [sp, #0x18]        | S2 = 0;                                 
        // 0x00BACF28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACF2C: MOV x0, x20                | X0 = this.mCamera;//m1                  
        // 0x00BACF30: BL #0x20d17ec              | X0 = this.mCamera.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_12 = this.mCamera.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00BACF34: STP s0, s1, [x19, #0x60]   | this.beginMouseWorld = val_12;  mem[1152921514493190548] = val_12.y;  //  dest_result_addr=1152921514493190544 |  dest_result_addr=1152921514493190548
        this.beginMouseWorld = val_12;
        mem[1152921514493190548] = val_12.y;
        // 0x00BACF38: STR s2, [x19, #0x68]       | mem[1152921514493190552] = val_12.z;     //  dest_result_addr=1152921514493190552
        mem[1152921514493190552] = val_12.z;
        label_11:
        // 0x00BACF3C: LDR x0, [x22]              | X0 = typeof(UnityEngine.Input);         
        // 0x00BACF40: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Input.__il2cppRuntimeField_10A;
        // 0x00BACF44: TBZ w8, #0, #0xbacf54      | if (UnityEngine.Input.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00BACF48: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Input.__il2cppRuntimeField_cctor_finished;
        // 0x00BACF4C: CBNZ w8, #0xbacf54         | if (UnityEngine.Input.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00BACF50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Input), ????);
        label_18:
        // 0x00BACF54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACF58: MOVZ w1, #0x143            | W1 = 323 (0x143);//ML01                 
        // 0x00BACF5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BACF60: BL #0x1a6faec              | X0 = UnityEngine.Input.GetKey(key:  0); 
        bool val_13 = UnityEngine.Input.GetKey(key:  0);
        // 0x00BACF64: TBZ w0, #0, #0xbad198      | if (val_13 == false) goto label_19;     
        if(val_13 == false)
        {
            goto label_19;
        }
        // 0x00BACF68: LDR x0, [x22]              | X0 = typeof(UnityEngine.Input);         
        // 0x00BACF6C: LDR x20, [x19, #0x18]      | X20 = this.mCamera; //P2                
        // 0x00BACF70: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Input.__il2cppRuntimeField_10A;
        // 0x00BACF74: TBZ w8, #0, #0xbacf84      | if (UnityEngine.Input.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00BACF78: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Input.__il2cppRuntimeField_cctor_finished;
        // 0x00BACF7C: CBNZ w8, #0xbacf84         | if (UnityEngine.Input.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00BACF80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Input), ????);
        label_21:
        // 0x00BACF84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACF88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACF8C: BL #0x1a6fed0              | X0 = UnityEngine.Input.get_mousePosition();
        UnityEngine.Vector3 val_14 = UnityEngine.Input.mousePosition;
        // 0x00BACF90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BACF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACF98: MOV v8.16b, v0.16b         | V8 = val_14.x;//m1                      
        // 0x00BACF9C: BL #0x1a6fed0              | X0 = UnityEngine.Input.get_mousePosition();
        UnityEngine.Vector3 val_15 = UnityEngine.Input.mousePosition;
        // 0x00BACFA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACFA4: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BACFA8: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
        // 0x00BACFAC: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_16 = this.transform;
        // 0x00BACFB0: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00BACFB4: CBNZ x21, #0xbacfbc        | if (val_16 != null) goto label_22;      
        if(val_16 != null)
        {
            goto label_22;
        }
        // 0x00BACFB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_22:
        // 0x00BACFBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACFC0: MOV x0, x21                | X0 = val_16;//m1                        
        // 0x00BACFC4: BL #0x2693510              | X0 = val_16.get_position();             
        UnityEngine.Vector3 val_17 = val_16.position;
        // 0x00BACFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACFCC: ADD x0, sp, #0x10          | X0 = (1152921514493178320 + 16) = 1152921514493178336 (0x100000024D4571E0);
        // 0x00BACFD0: MOV v0.16b, v8.16b         | V0 = val_14.x;//m1                      
        // 0x00BACFD4: MOV v1.16b, v9.16b         | V1 = val_15.y;//m1                      
        // 0x00BACFD8: STR wzr, [sp, #0x18]       | stack[1152921514493178344] = 0x0;        //  dest_result_addr=1152921514493178344
        // 0x00BACFDC: STR xzr, [sp, #0x10]       | stack[1152921514493178336] = 0x0;        //  dest_result_addr=1152921514493178336
        // 0x00BACFE0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00BACFE4: CBNZ x20, #0xbacfec        | if (this.mCamera != null) goto label_23;
        if(this.mCamera != null)
        {
            goto label_23;
        }
        // 0x00BACFE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000024D4571E0, ????);
        label_23:
        // 0x00BACFEC: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00BACFF0: LDR s2, [sp, #0x18]        | S2 = 0;                                 
        // 0x00BACFF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BACFF8: MOV x0, x20                | X0 = this.mCamera;//m1                  
        // 0x00BACFFC: BL #0x20d17ec              | X0 = this.mCamera.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_18 = this.mCamera.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00BAD000: MOV v8.16b, v0.16b         | V8 = val_18.x;//m1                      
        // 0x00BAD004: MOV v9.16b, v1.16b         | V9 = val_18.y;//m1                      
        // 0x00BAD008: MOV v10.16b, v2.16b        | V10 = val_18.z;//m1                     
        // 0x00BAD00C: STP s8, s9, [x19, #0x6c]   | this.currentMouseWorldPoint = val_18;  mem[1152921514493190560] = val_18.y;  //  dest_result_addr=1152921514493190556 |  dest_result_addr=1152921514493190560
        this.currentMouseWorldPoint = val_18;
        mem[1152921514493190560] = val_18.y;
        // 0x00BAD010: STR s10, [x19, #0x74]      | mem[1152921514493190564] = val_18.z;     //  dest_result_addr=1152921514493190564
        mem[1152921514493190564] = val_18.z;
        // 0x00BAD014: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BAD018: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00BAD01C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00BAD020: LDP s13, s12, [x19, #0x60] | S13 = this.beginMouseWorld; //P2         //  | 
        // 0x00BAD024: LDR s11, [x19, #0x68]      | 
        // 0x00BAD028: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00BAD02C: TBZ w8, #0, #0xbad03c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00BAD030: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00BAD034: CBNZ w8, #0xbad03c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00BAD038: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_25:
        // 0x00BAD03C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD040: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD044: MOV v0.16b, v8.16b         | V0 = val_18.x;//m1                      
        // 0x00BAD048: MOV v1.16b, v9.16b         | V1 = val_18.y;//m1                      
        // 0x00BAD04C: MOV v2.16b, v10.16b        | V2 = val_18.z;//m1                      
        // 0x00BAD050: MOV v3.16b, v13.16b        | V3 = this.beginMouseWorld;//m1          
        // 0x00BAD054: MOV v4.16b, v12.16b        | V4 = V12.16B;//m1                       
        // 0x00BAD058: MOV v5.16b, v11.16b        | V5 = V11.16B;//m1                       
        // 0x00BAD05C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = this.beginMouseWorld, y = V12.16B, z = V11.16B});
        UnityEngine.Vector3 val_19 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = this.beginMouseWorld, y = V12.16B, z = V11.16B});
        // 0x00BAD060: MOV v3.16b, v0.16b         | V3 = val_19.x;//m1                      
        // 0x00BAD064: MOV v4.16b, v1.16b         | V4 = val_19.y;//m1                      
        // 0x00BAD068: STP s3, s4, [x19, #0x78]   | this.offsetPosition = val_19;  mem[1152921514493190572] = val_19.y;  //  dest_result_addr=1152921514493190568 |  dest_result_addr=1152921514493190572
        this.offsetPosition = val_19;
        mem[1152921514493190572] = val_19.y;
        // 0x00BAD06C: MOV v5.16b, v2.16b         | V5 = val_19.z;//m1                      
        // 0x00BAD070: LDP s0, s1, [x19, #0x54]   | S0 = this.cameraScreenPoint; //P2        //  | 
        // 0x00BAD074: LDR s2, [x19, #0x5c]       | 
        // 0x00BAD078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD07C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD080: STR s5, [x19, #0x80]       | mem[1152921514493190576] = val_19.z;     //  dest_result_addr=1152921514493190576
        mem[1152921514493190576] = val_19.z;
        // 0x00BAD084: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.cameraScreenPoint, y = val_19.y, z = val_19.z}, b:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        UnityEngine.Vector3 val_20 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.cameraScreenPoint, y = val_19.y, z = val_19.z}, b:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        // 0x00BAD088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD08C: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BAD090: STP s0, s1, [x19, #0x84]   | this.targetPosition = val_20;  mem[1152921514493190584] = val_20.y;  //  dest_result_addr=1152921514493190580 |  dest_result_addr=1152921514493190584
        this.targetPosition = val_20;
        mem[1152921514493190584] = val_20.y;
        // 0x00BAD094: STR s2, [x19, #0x8c]       | mem[1152921514493190588] = val_20.z;     //  dest_result_addr=1152921514493190588
        mem[1152921514493190588] = val_20.z;
        // 0x00BAD098: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_21 = this.transform;
        // 0x00BAD09C: MOV x20, x0                | X20 = val_21;//m1                       
        // 0x00BAD0A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD0A4: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BAD0A8: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_22 = this.transform;
        // 0x00BAD0AC: MOV x21, x0                | X21 = val_22;//m1                       
        // 0x00BAD0B0: CBNZ x21, #0xbad0b8        | if (val_22 != null) goto label_26;      
        if(val_22 != null)
        {
            goto label_26;
        }
        // 0x00BAD0B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_26:
        // 0x00BAD0B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD0BC: MOV x0, x21                | X0 = val_22;//m1                        
        // 0x00BAD0C0: BL #0x2693510              | X0 = val_22.get_position();             
        UnityEngine.Vector3 val_23 = val_22.position;
        // 0x00BAD0C4: LDR s11, [x19, #0x84]      | S11 = this.targetPosition; //P2         
        // 0x00BAD0C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD0CC: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BAD0D0: MOV v8.16b, v0.16b         | V8 = val_23.x;//m1                      
        // 0x00BAD0D4: MOV v9.16b, v1.16b         | V9 = val_23.y;//m1                      
        // 0x00BAD0D8: MOV v10.16b, v2.16b        | V10 = val_23.z;//m1                     
        // 0x00BAD0DC: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_24 = this.transform;
        // 0x00BAD0E0: MOV x21, x0                | X21 = val_24;//m1                       
        val_31 = val_24;
        // 0x00BAD0E4: CBNZ x21, #0xbad0ec        | if (val_24 != null) goto label_27;      
        if(val_31 != null)
        {
            goto label_27;
        }
        // 0x00BAD0E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_27:
        // 0x00BAD0EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD0F0: MOV x0, x21                | X0 = val_24;//m1                        
        // 0x00BAD0F4: BL #0x2693510              | X0 = val_24.get_position();             
        UnityEngine.Vector3 val_25 = val_31.position;
        // 0x00BAD0F8: LDR s2, [x19, #0x8c]       | 
        // 0x00BAD0FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD100: MOV x0, sp                 | X0 = 1152921514493178320 (0x100000024D4571D0);//ML01
        // 0x00BAD104: MOV v0.16b, v11.16b        | V0 = this.targetPosition;//m1           
        // 0x00BAD108: STR wzr, [sp, #8]          | stack[1152921514493178328] = 0x0;        //  dest_result_addr=1152921514493178328
        // 0x00BAD10C: STR xzr, [sp]              | stack[1152921514493178320] = 0x0;        //  dest_result_addr=1152921514493178320
        // 0x00BAD110: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00BAD114: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00BAD118: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00BAD11C: MOV x0, x19                | X0 = 1152921514493190448 (0x100000024D45A130);//ML01
        // 0x00BAD120: BL #0xbad1b8               | X0 = this.LimitPosition(pos:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_26 = this.LimitPosition(pos:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00BAD124: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD128: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD12C: MOV v11.16b, v0.16b        | V11 = val_26.x;//m1                     
        // 0x00BAD130: MOV v12.16b, v1.16b        | V12 = val_26.y;//m1                     
        // 0x00BAD134: MOV v13.16b, v2.16b        | V13 = val_26.z;//m1                     
        // 0x00BAD138: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_27 = UnityEngine.Time.deltaTime;
        // 0x00BAD13C: LDR s1, [x19, #0x28]       | S1 = this.cameraMoveSpeed; //P2         
        // 0x00BAD140: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD148: MOV v2.16b, v10.16b        | V2 = val_23.z;//m1                      
        // 0x00BAD14C: SCVTF s1, s1               | S1 = (float)(this.cameraMoveSpeed);     
        // 0x00BAD150: FMUL s6, s0, s1            | S6 = (val_27 * this.cameraMoveSpeed);   
        float val_28 = val_27 * (float)this.cameraMoveSpeed;
        // 0x00BAD154: MOV v0.16b, v8.16b         | V0 = val_23.x;//m1                      
        // 0x00BAD158: MOV v1.16b, v9.16b         | V1 = val_23.y;//m1                      
        // 0x00BAD15C: MOV v3.16b, v11.16b        | V3 = val_26.x;//m1                      
        // 0x00BAD160: MOV v4.16b, v12.16b        | V4 = val_26.y;//m1                      
        // 0x00BAD164: MOV v5.16b, v13.16b        | V5 = val_26.z;//m1                      
        // 0x00BAD168: BL #0x26987d0              | X0 = UnityEngine.Vector3.Slerp(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, b:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, t:  float val_28 = val_27 * (float)this.cameraMoveSpeed);
        UnityEngine.Vector3 val_29 = UnityEngine.Vector3.Slerp(a:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z}, b:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, t:  val_28);
        // 0x00BAD16C: MOV v8.16b, v0.16b         | V8 = val_29.x;//m1                      
        val_30 = val_29.x;
        // 0x00BAD170: MOV v9.16b, v1.16b         | V9 = val_29.y;//m1                      
        // 0x00BAD174: MOV v10.16b, v2.16b        | V10 = val_29.z;//m1                     
        // 0x00BAD178: CBNZ x20, #0xbad180        | if (val_21 != null) goto label_28;      
        if(val_21 != null)
        {
            goto label_28;
        }
        // 0x00BAD17C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_28:
        // 0x00BAD180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD184: MOV x0, x20                | X0 = val_21;//m1                        
        // 0x00BAD188: MOV v0.16b, v8.16b         | V0 = val_29.x;//m1                      
        // 0x00BAD18C: MOV v1.16b, v9.16b         | V1 = val_29.y;//m1                      
        // 0x00BAD190: MOV v2.16b, v10.16b        | V2 = val_29.z;//m1                      
        // 0x00BAD194: BL #0x26935b8              | val_21.set_position(value:  new UnityEngine.Vector3() {x = val_30, y = val_29.y, z = val_29.z});
        val_21.position = new UnityEngine.Vector3() {x = val_30, y = val_29.y, z = val_29.z};
        label_19:
        // 0x00BAD198: SUB sp, x29, #0x50         | SP = (1152921514493178432 - 80) = 1152921514493178352 (0x100000024D4571F0);
        // 0x00BAD19C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BAD1A0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BAD1A4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BAD1A8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00BAD1AC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00BAD1B0: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00BAD1B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD1B8 (12243384), len: 116  VirtAddr: 0x00BAD1B8 RVA: 0x00BAD1B8 token: 100690242 methodIndex: 25704 delegateWrapperIndex: 0 methodInvoker: 0
    private UnityEngine.Vector3 LimitPosition(UnityEngine.Vector3 pos)
    {
        //
        // Disasemble & Code
        //  | 
        float val_5;
        //  | 
        float val_6;
        // 0x00BAD1B8: LDR s3, [x0, #0x3c]        | S3 = this.originalPositionX_min; //P2   
        val_5 = this.originalPositionX_min;
        // 0x00BAD1BC: MOV v4.16b, v1.16b         | V4 = pos.y;//m1                         
        // 0x00BAD1C0: FCMP s0, s3                | STATE = COMPARE(pos.x, this.originalPositionX_min)
        // 0x00BAD1C4: B.MI #0xbad1d4             | if (pos.x < 0) goto label_0;            
        if(pos.x < 0)
        {
            goto label_0;
        }
        // 0x00BAD1C8: LDR s1, [x0, #0x40]        | S1 = this.originalPositionX_max; //P2   
        // 0x00BAD1CC: FCMP s0, s1                | STATE = COMPARE(pos.x, this.originalPositionX_max)
        // 0x00BAD1D0: FCSEL s3, s1, s0, gt       | S3 = pos.x > this.originalPositionX_max ? this.originalPositionX_max : pos.x;
        float val_1 = (pos.x > this.originalPositionX_max) ? (this.originalPositionX_max) : pos.x;
        label_0:
        // 0x00BAD1D4: LDRH w8, [x0, #0x38]       | W8 = this.CanMoveY; //P2                
        // 0x00BAD1D8: MOV v1.16b, v4.16b         | V1 = pos.y;//m1                         
        // 0x00BAD1DC: AND w9, w8, #0xff          | W9 = (this.CanMoveY & 255);             
        bool val_2 = this.CanMoveY & 255;
        // 0x00BAD1E0: CBZ w9, #0xbad1fc          | if ((this.CanMoveY & 255) == false) goto label_2;
        if(val_2 == false)
        {
            goto label_2;
        }
        // 0x00BAD1E4: LDR s1, [x0, #0x44]        | S1 = this.originalPositionY_min; //P2   
        // 0x00BAD1E8: FCMP s4, s1                | STATE = COMPARE(pos.y, this.originalPositionY_min)
        // 0x00BAD1EC: B.MI #0xbad1fc             | if (pos.y < 0) goto label_2;            
        if(pos.y < 0)
        {
            goto label_2;
        }
        // 0x00BAD1F0: LDR s0, [x0, #0x48]        | S0 = this.originalPositionY_max; //P2   
        // 0x00BAD1F4: FCMP s4, s0                | STATE = COMPARE(pos.y, this.originalPositionY_max)
        // 0x00BAD1F8: FCSEL s1, s0, s4, gt       | S1 = pos.y > this.originalPositionY_max ? this.originalPositionY_max : pos.y;
        float val_3 = (pos.y > this.originalPositionY_max) ? (this.originalPositionY_max) : (pos.y);
        label_2:
        // 0x00BAD1FC: MOV v4.16b, v2.16b         | V4 = pos.z;//m1                         
        val_6 = pos.z;
        // 0x00BAD200: CMP w8, #0x100             | STATE = COMPARE(this.CanMoveY, 0x100)   
        // 0x00BAD204: B.LO #0xbad220             | if (this.CanMoveY < true) goto label_4; 
        if(this.CanMoveY < true)
        {
            goto label_4;
        }
        // 0x00BAD208: LDR s4, [x0, #0x4c]        | S4 = this.originalPositionZ_min; //P2   
        val_6 = this.originalPositionZ_min;
        // 0x00BAD20C: FCMP s2, s4                | STATE = COMPARE(pos.z, this.originalPositionZ_min)
        // 0x00BAD210: B.MI #0xbad220             | if (pos.z < 0) goto label_4;            
        if(pos.z < 0)
        {
            goto label_4;
        }
        // 0x00BAD214: LDR s0, [x0, #0x50]        | S0 = this.originalPositionZ_max; //P2   
        // 0x00BAD218: FCMP s2, s0                | STATE = COMPARE(pos.z, this.originalPositionZ_max)
        // 0x00BAD21C: FCSEL s4, s0, s2, gt       | S4 = pos.z > this.originalPositionZ_max ? this.originalPositionZ_max : pos.z;
        float val_4 = (pos.z > this.originalPositionZ_max) ? (this.originalPositionZ_max) : pos.z;
        label_4:
        // 0x00BAD220: MOV v0.16b, v3.16b         | V0 = pos.x > this.originalPositionX_max ? this.originalPositionX_max : pos.x;//m1
        // 0x00BAD224: MOV v2.16b, v4.16b         | V2 = pos.z > this.originalPositionZ_max ? this.originalPositionZ_max : pos.z;//m1
        // 0x00BAD228: RET                        |  return new UnityEngine.Vector3() {x = val_1, y = val_3, z = val_4};
        return new UnityEngine.Vector3() {x = val_1, y = val_3, z = val_4};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }

}
