using UnityEngine;
[Serializable]
public class BMFont
{
    // Fields
    [UnityEngine.HideInInspector] // 0x28660E8
    [UnityEngine.SerializeField] // 0x28660E8
    private int mSize; //  0x00000010
    [UnityEngine.HideInInspector] // 0x2866120
    [UnityEngine.SerializeField] // 0x2866120
    private int mBase; //  0x00000014
    [UnityEngine.HideInInspector] // 0x2866158
    [UnityEngine.SerializeField] // 0x2866158
    private int mWidth; //  0x00000018
    [UnityEngine.HideInInspector] // 0x2866190
    [UnityEngine.SerializeField] // 0x2866190
    private int mHeight; //  0x0000001C
    [UnityEngine.HideInInspector] // 0x28661C8
    [UnityEngine.SerializeField] // 0x28661C8
    private string mSpriteName; //  0x00000020
    [UnityEngine.HideInInspector] // 0x2866200
    [UnityEngine.SerializeField] // 0x2866200
    private System.Collections.Generic.List<BMGlyph> mSaved; //  0x00000028
    private System.Collections.Generic.Dictionary<int, BMGlyph> mDict; //  0x00000030
    
    // Properties
    public bool isValid { get; }
    public int charSize { get; set; }
    public int baseOffset { get; set; }
    public int texWidth { get; set; }
    public int texHeight { get; set; }
    public int glyphCount { get; }
    public string spriteName { get; set; }
    public System.Collections.Generic.List<BMGlyph> glyphs { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B921CC (12132812), len: 160  VirtAddr: 0x00B921CC RVA: 0x00B921CC token: 100687868 methodIndex: 25168 delegateWrapperIndex: 0 methodInvoker: 0
    public BMFont()
    {
        //
        // Disasemble & Code
        // 0x00B921CC: STP x20, x19, [sp, #-0x20]! | stack[1152921514155562288] = ???;  stack[1152921514155562296] = ???;  //  dest_result_addr=1152921514155562288 |  dest_result_addr=1152921514155562296
        // 0x00B921D0: STP x29, x30, [sp, #0x10]  | stack[1152921514155562304] = ???;  stack[1152921514155562312] = ???;  //  dest_result_addr=1152921514155562304 |  dest_result_addr=1152921514155562312
        // 0x00B921D4: ADD x29, sp, #0x10         | X29 = (1152921514155562288 + 16) = 1152921514155562304 (0x100000023925D540);
        // 0x00B921D8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B921DC: LDRB w8, [x20, #0xa46]     | W8 = (bool)static_value_03733A46;       
        // 0x00B921E0: MOV x19, x0                | X19 = 1152921514155574320 (0x1000000239260430);//ML01
        // 0x00B921E4: TBNZ w8, #0, #0xb92200     | if (static_value_03733A46 == true) goto label_0;
        // 0x00B921E8: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B921EC: LDR x8, [x8, #0x818]       | X8 = 0x2B8F6F0;                         
        // 0x00B921F0: LDR w0, [x8]               | W0 = 0x1480;                            
        // 0x00B921F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1480, ????);     
        // 0x00B921F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B921FC: STRB w8, [x20, #0xa46]     | static_value_03733A46 = true;            //  dest_result_addr=57883206
        label_0:
        // 0x00B92200: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
        // 0x00B92204: STR w8, [x19, #0x10]       | this.mSize = 16;                         //  dest_result_addr=1152921514155574336
        this.mSize = 16;
        // 0x00B92208: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x00B9220C: LDR x8, [x8, #0x6a8]       | X8 = 1152921504616644608;               
        // 0x00B92210: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<BMGlyph> val_1 = null;
        // 0x00B92214: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B92218: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
        // 0x00B9221C: LDR x8, [x8, #0x140]       | X8 = 1152921514155548272;               
        // 0x00B92220: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B92224: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<BMGlyph>::.ctor();
        // 0x00B92228: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<BMGlyph>();
        // 0x00B9222C: STR x20, [x19, #0x28]      | this.mSaved = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514155574360
        this.mSaved = val_1;
        // 0x00B92230: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00B92234: LDR x8, [x8, #0x9c8]       | X8 = 1152921504615792640;               
        // 0x00B92238: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.Int32, BMGlyph> val_2 = null;
        // 0x00B9223C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B92240: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B92244: LDR x8, [x8, #0xc28]       | X8 = 1152921514155549296;               
        // 0x00B92248: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B9224C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, BMGlyph>::.ctor();
        // 0x00B92250: BL #0x2413320              | .ctor();                                
        val_2 = new System.Collections.Generic.Dictionary<System.Int32, BMGlyph>();
        // 0x00B92254: STR x20, [x19, #0x30]      | this.mDict = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921514155574368
        this.mDict = val_2;
        // 0x00B92258: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9225C: MOV x0, x19                | X0 = 1152921514155574320 (0x1000000239260430);//ML01
        // 0x00B92260: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92264: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B92268: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9226C (12132972), len: 104  VirtAddr: 0x00B9226C RVA: 0x00B9226C token: 100687869 methodIndex: 25169 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isValid()
    {
        //
        // Disasemble & Code
        // 0x00B9226C: STP x20, x19, [sp, #-0x20]! | stack[1152921514155679408] = ???;  stack[1152921514155679416] = ???;  //  dest_result_addr=1152921514155679408 |  dest_result_addr=1152921514155679416
        // 0x00B92270: STP x29, x30, [sp, #0x10]  | stack[1152921514155679424] = ???;  stack[1152921514155679432] = ???;  //  dest_result_addr=1152921514155679424 |  dest_result_addr=1152921514155679432
        // 0x00B92274: ADD x29, sp, #0x10         | X29 = (1152921514155679408 + 16) = 1152921514155679424 (0x1000000239279EC0);
        // 0x00B92278: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B9227C: LDRB w8, [x20, #0xa47]     | W8 = (bool)static_value_03733A47;       
        // 0x00B92280: MOV x19, x0                | X19 = 1152921514155691440 (0x100000023927CDB0);//ML01
        // 0x00B92284: TBNZ w8, #0, #0xb922a0     | if (static_value_03733A47 == true) goto label_0;
        // 0x00B92288: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B9228C: LDR x8, [x8, #0x130]       | X8 = 0x2B8F750;                         
        // 0x00B92290: LDR w0, [x8]               | W0 = 0x1498;                            
        // 0x00B92294: BL #0x2782188              | X0 = sub_2782188( ?? 0x1498, ????);     
        // 0x00B92298: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9229C: STRB w8, [x20, #0xa47]     | static_value_03733A47 = true;            //  dest_result_addr=57883207
        label_0:
        // 0x00B922A0: LDR x19, [x19, #0x28]      | X19 = this.mSaved; //P2                 
        // 0x00B922A4: CBNZ x19, #0xb922ac        | if (this.mSaved != null) goto label_1;  
        if(this.mSaved != null)
        {
            goto label_1;
        }
        // 0x00B922A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1498, ????);     
        label_1:
        // 0x00B922AC: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B922B0: LDR x8, [x8, #0x8f8]       | X8 = 1152921514155666416;               
        // 0x00B922B4: MOV x0, x19                | X0 = this.mSaved;//m1                   
        // 0x00B922B8: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<BMGlyph>::get_Count();
        // 0x00B922BC: BL #0x25ed72c              | X0 = this.mSaved.get_Count();           
        int val_1 = this.mSaved.Count;
        // 0x00B922C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B922C4: CMP w0, #0                 | STATE = COMPARE(val_1, 0x0)             
        // 0x00B922C8: CSET w0, gt                | W0 = val_1 > 0 ? 1 : 0;                 
        var val_2 = (val_1 > 0) ? 1 : 0;
        // 0x00B922CC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B922D0: RET                        |  return (System.Boolean)val_1 > 0 ? 1 : 0;
        return (bool)val_2;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B922D4 (12133076), len: 8  VirtAddr: 0x00B922D4 RVA: 0x00B922D4 token: 100687870 methodIndex: 25170 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_charSize()
    {
        //
        // Disasemble & Code
        // 0x00B922D4: LDR w0, [x0, #0x10]        | W0 = this.mSize; //P2                   
        // 0x00B922D8: RET                        |  return (System.Int32)this.mSize;       
        return this.mSize;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B922DC (12133084), len: 8  VirtAddr: 0x00B922DC RVA: 0x00B922DC token: 100687871 methodIndex: 25171 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_charSize(int value)
    {
        //
        // Disasemble & Code
        // 0x00B922DC: STR w1, [x0, #0x10]        | this.mSize = value;                      //  dest_result_addr=1152921514155919552
        this.mSize = value;
        // 0x00B922E0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B922E4 (12133092), len: 8  VirtAddr: 0x00B922E4 RVA: 0x00B922E4 token: 100687872 methodIndex: 25172 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_baseOffset()
    {
        //
        // Disasemble & Code
        // 0x00B922E4: LDR w0, [x0, #0x14]        | W0 = this.mBase; //P2                   
        // 0x00B922E8: RET                        |  return (System.Int32)this.mBase;       
        return this.mBase;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B922EC (12133100), len: 8  VirtAddr: 0x00B922EC RVA: 0x00B922EC token: 100687873 methodIndex: 25173 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_baseOffset(int value)
    {
        //
        // Disasemble & Code
        // 0x00B922EC: STR w1, [x0, #0x14]        | this.mBase = value;                      //  dest_result_addr=1152921514156143556
        this.mBase = value;
        // 0x00B922F0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B922F4 (12133108), len: 8  VirtAddr: 0x00B922F4 RVA: 0x00B922F4 token: 100687874 methodIndex: 25174 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_texWidth()
    {
        //
        // Disasemble & Code
        // 0x00B922F4: LDR w0, [x0, #0x18]        | W0 = this.mWidth; //P2                  
        // 0x00B922F8: RET                        |  return (System.Int32)this.mWidth;      
        return this.mWidth;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B922FC (12133116), len: 8  VirtAddr: 0x00B922FC RVA: 0x00B922FC token: 100687875 methodIndex: 25175 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_texWidth(int value)
    {
        //
        // Disasemble & Code
        // 0x00B922FC: STR w1, [x0, #0x18]        | this.mWidth = value;                     //  dest_result_addr=1152921514156367560
        this.mWidth = value;
        // 0x00B92300: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92304 (12133124), len: 8  VirtAddr: 0x00B92304 RVA: 0x00B92304 token: 100687876 methodIndex: 25176 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_texHeight()
    {
        //
        // Disasemble & Code
        // 0x00B92304: LDR w0, [x0, #0x1c]        | W0 = this.mHeight; //P2                 
        // 0x00B92308: RET                        |  return (System.Int32)this.mHeight;     
        return this.mHeight;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9230C (12133132), len: 8  VirtAddr: 0x00B9230C RVA: 0x00B9230C token: 100687877 methodIndex: 25177 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_texHeight(int value)
    {
        //
        // Disasemble & Code
        // 0x00B9230C: STR w1, [x0, #0x1c]        | this.mHeight = value;                    //  dest_result_addr=1152921514156591564
        this.mHeight = value;
        // 0x00B92310: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92314 (12133140), len: 120  VirtAddr: 0x00B92314 RVA: 0x00B92314 token: 100687878 methodIndex: 25178 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_glyphCount()
    {
        //
        // Disasemble & Code
        // 0x00B92314: STP x20, x19, [sp, #-0x20]! | stack[1152921514156695600] = ???;  stack[1152921514156695608] = ???;  //  dest_result_addr=1152921514156695600 |  dest_result_addr=1152921514156695608
        // 0x00B92318: STP x29, x30, [sp, #0x10]  | stack[1152921514156695616] = ???;  stack[1152921514156695624] = ???;  //  dest_result_addr=1152921514156695616 |  dest_result_addr=1152921514156695624
        // 0x00B9231C: ADD x29, sp, #0x10         | X29 = (1152921514156695600 + 16) = 1152921514156695616 (0x1000000239372040);
        // 0x00B92320: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B92324: LDRB w8, [x20, #0xa48]     | W8 = (bool)static_value_03733A48;       
        // 0x00B92328: MOV x19, x0                | X19 = 1152921514156707632 (0x1000000239374F30);//ML01
        // 0x00B9232C: TBNZ w8, #0, #0xb92348     | if (static_value_03733A48 == true) goto label_0;
        // 0x00B92330: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00B92334: LDR x8, [x8, #0xf28]       | X8 = 0x2B8F74C;                         
        // 0x00B92338: LDR w0, [x8]               | W0 = 0x1497;                            
        // 0x00B9233C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1497, ????);     
        // 0x00B92340: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B92344: STRB w8, [x20, #0xa48]     | static_value_03733A48 = true;            //  dest_result_addr=57883208
        label_0:
        // 0x00B92348: MOV x0, x19                | X0 = 1152921514156707632 (0x1000000239374F30);//ML01
        // 0x00B9234C: BL #0xb9226c               | X0 = this.get_isValid();                
        bool val_1 = this.isValid;
        // 0x00B92350: TBZ w0, #0, #0xb9237c      | if (val_1 == false) goto label_1;       
        if(val_1 == false)
        {
            goto label_1;
        }
        // 0x00B92354: LDR x19, [x19, #0x28]      | X19 = this.mSaved; //P2                 
        // 0x00B92358: CBNZ x19, #0xb92360        | if (this.mSaved != null) goto label_2;  
        if(this.mSaved != null)
        {
            goto label_2;
        }
        // 0x00B9235C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B92360: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B92364: LDR x8, [x8, #0x8f8]       | X8 = 1152921514155666416;               
        // 0x00B92368: MOV x0, x19                | X0 = this.mSaved;//m1                   
        // 0x00B9236C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<BMGlyph>::get_Count();
        // 0x00B92370: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92374: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B92378: B #0x25ed72c               | return this.mSaved.get_Count();         
        return this.mSaved.Count;
        label_1:
        // 0x00B9237C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92380: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00B92384: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B92388: RET                        |  return (System.Int32)0;                
        return (int)0;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9238C (12133260), len: 8  VirtAddr: 0x00B9238C RVA: 0x00B9238C token: 100687879 methodIndex: 25179 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_spriteName()
    {
        //
        // Disasemble & Code
        // 0x00B9238C: LDR x0, [x0, #0x20]        | X0 = this.mSpriteName; //P2             
        // 0x00B92390: RET                        |  return (System.String)this.mSpriteName;
        return this.mSpriteName;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92394 (12133268), len: 8  VirtAddr: 0x00B92394 RVA: 0x00B92394 token: 100687880 methodIndex: 25180 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_spriteName(string value)
    {
        //
        // Disasemble & Code
        // 0x00B92394: STR x1, [x0, #0x20]        | this.mSpriteName = value;                //  dest_result_addr=1152921514156948048
        this.mSpriteName = value;
        // 0x00B92398: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9239C (12133276), len: 8  VirtAddr: 0x00B9239C RVA: 0x00B9239C token: 100687881 methodIndex: 25181 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<BMGlyph> get_glyphs()
    {
        //
        // Disasemble & Code
        // 0x00B9239C: LDR x0, [x0, #0x28]        | X0 = this.mSaved; //P2                  
        // 0x00B923A0: RET                        |  return (System.Collections.Generic.List<BMGlyph>)this.mSaved;
        return this.mSaved;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<BMGlyph>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B923A4 (12133284), len: 496  VirtAddr: 0x00B923A4 RVA: 0x00B923A4 token: 100687882 methodIndex: 25182 delegateWrapperIndex: 0 methodInvoker: 0
    public BMGlyph GetGlyph(int index, bool createIfMissing)
    {
        //
        // Disasemble & Code
        //  | 
        BMGlyph val_10;
        // 0x00B923A4: STP x28, x27, [sp, #-0x60]! | stack[1152921514157210096] = ???;  stack[1152921514157210104] = ???;  //  dest_result_addr=1152921514157210096 |  dest_result_addr=1152921514157210104
        // 0x00B923A8: STP x26, x25, [sp, #0x10]  | stack[1152921514157210112] = ???;  stack[1152921514157210120] = ???;  //  dest_result_addr=1152921514157210112 |  dest_result_addr=1152921514157210120
        // 0x00B923AC: STP x24, x23, [sp, #0x20]  | stack[1152921514157210128] = ???;  stack[1152921514157210136] = ???;  //  dest_result_addr=1152921514157210128 |  dest_result_addr=1152921514157210136
        // 0x00B923B0: STP x22, x21, [sp, #0x30]  | stack[1152921514157210144] = ???;  stack[1152921514157210152] = ???;  //  dest_result_addr=1152921514157210144 |  dest_result_addr=1152921514157210152
        // 0x00B923B4: STP x20, x19, [sp, #0x40]  | stack[1152921514157210160] = ???;  stack[1152921514157210168] = ???;  //  dest_result_addr=1152921514157210160 |  dest_result_addr=1152921514157210168
        // 0x00B923B8: STP x29, x30, [sp, #0x50]  | stack[1152921514157210176] = ???;  stack[1152921514157210184] = ???;  //  dest_result_addr=1152921514157210176 |  dest_result_addr=1152921514157210184
        // 0x00B923BC: ADD x29, sp, #0x50         | X29 = (1152921514157210096 + 80) = 1152921514157210176 (0x10000002393EFA40);
        // 0x00B923C0: SUB sp, sp, #0x10          | SP = (1152921514157210096 - 16) = 1152921514157210080 (0x10000002393EF9E0);
        // 0x00B923C4: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B923C8: LDRB w8, [x22, #0xa49]     | W8 = (bool)static_value_03733A49;       
        // 0x00B923CC: MOV w21, w2                | W21 = createIfMissing;//m1              
        val_10 = createIfMissing;
        // 0x00B923D0: MOV w19, w1                | W19 = index;//m1                        
        // 0x00B923D4: MOV x20, x0                | X20 = 1152921514157222192 (0x10000002393F2930);//ML01
        // 0x00B923D8: TBNZ w8, #0, #0xb923f4     | if (static_value_03733A49 == true) goto label_0;
        // 0x00B923DC: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00B923E0: LDR x8, [x8, #0x890]       | X8 = 0x2B8F754;                         
        // 0x00B923E4: LDR w0, [x8]               | W0 = 0x1499;                            
        // 0x00B923E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1499, ????);     
        // 0x00B923EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B923F0: STRB w8, [x22, #0xa49]     | static_value_03733A49 = true;            //  dest_result_addr=57883209
        label_0:
        // 0x00B923F4: STR xzr, [sp, #8]          | stack[1152921514157210088] = 0x0;        //  dest_result_addr=1152921514157210088
        BMGlyph val_4 = 0;
        // 0x00B923F8: LDR x22, [x20, #0x30]      | X22 = this.mDict; //P2                  
        // 0x00B923FC: CBNZ x22, #0xb92404        | if (this.mDict != null) goto label_1;   
        if(this.mDict != null)
        {
            goto label_1;
        }
        // 0x00B92400: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1499, ????);     
        label_1:
        // 0x00B92404: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B92408: LDR x8, [x8, #0x610]       | X8 = 1152921514157164400;               
        // 0x00B9240C: MOV x0, x22                | X0 = this.mDict;//m1                    
        // 0x00B92410: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.Dictionary<System.Int32, BMGlyph>::get_Count();
        // 0x00B92414: BL #0x24144e8              | X0 = this.mDict.get_Count();            
        int val_1 = this.mDict.Count;
        // 0x00B92418: CBNZ w0, #0xb924b4         | if (val_1 != 0) goto label_4;           
        if(val_1 != 0)
        {
            goto label_4;
        }
        // 0x00B9241C: LDR x22, [x20, #0x28]      | X22 = this.mSaved; //P2                 
        // 0x00B92420: CBNZ x22, #0xb92428        | if (this.mSaved != null) goto label_3;  
        if(this.mSaved != null)
        {
            goto label_3;
        }
        // 0x00B92424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B92428: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B9242C: LDR x8, [x8, #0x8f8]       | X8 = 1152921514155666416;               
        // 0x00B92430: MOV x0, x22                | X0 = this.mSaved;//m1                   
        // 0x00B92434: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<BMGlyph>::get_Count();
        // 0x00B92438: BL #0x25ed72c              | X0 = this.mSaved.get_Count();           
        int val_2 = this.mSaved.Count;
        // 0x00B9243C: MOV w22, w0                | W22 = val_2;//m1                        
        // 0x00B92440: CMP w22, #1                | STATE = COMPARE(val_2, 0x1)             
        // 0x00B92444: B.LT #0xb924b4             | if (val_2 < 1) goto label_4;            
        if(val_2 < 1)
        {
            goto label_4;
        }
        // 0x00B92448: ADRP x27, #0x360d000       | X27 = 56676352 (0x360D000);             
        // 0x00B9244C: ADRP x28, #0x3628000       | X28 = 56786944 (0x3628000);             
        // 0x00B92450: LDR x27, [x27, #0x418]     | X27 = 1152921514157169520;              
        // 0x00B92454: LDR x28, [x28, #0x368]     | X28 = 1152921514157170544;              
        // 0x00B92458: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        var val_10 = 0;
        label_8:
        // 0x00B9245C: LDR x24, [x20, #0x28]      | X24 = this.mSaved; //P2                 
        // 0x00B92460: CBNZ x24, #0xb92468        | if (this.mSaved != null) goto label_5;  
        if(this.mSaved != null)
        {
            goto label_5;
        }
        // 0x00B92464: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B92468: LDR x2, [x27]              | X2 = public BMGlyph System.Collections.Generic.List<BMGlyph>::get_Item(int index);
        // 0x00B9246C: MOV x0, x24                | X0 = this.mSaved;//m1                   
        // 0x00B92470: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B92474: BL #0x25ed734              | X0 = this.mSaved.get_Item(index:  0);   
        BMGlyph val_3 = this.mSaved.Item[0];
        // 0x00B92478: LDR x25, [x20, #0x30]      | X25 = this.mDict; //P2                  
        // 0x00B9247C: MOV x24, x0                | X24 = val_3;//m1                        
        // 0x00B92480: CBNZ x24, #0xb92488        | if (val_3 != null) goto label_6;        
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00B92484: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B92488: LDR w26, [x24, #0x10]      | W26 = val_3.index; //P2                 
        // 0x00B9248C: CBNZ x25, #0xb92494        | if (this.mDict != null) goto label_7;   
        if(this.mDict != null)
        {
            goto label_7;
        }
        // 0x00B92490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B92494: LDR x3, [x28]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, BMGlyph>::Add(System.Int32 key, BMGlyph value);
        // 0x00B92498: MOV x0, x25                | X0 = this.mDict;//m1                    
        // 0x00B9249C: MOV w1, w26                | W1 = val_3.index;//m1                   
        // 0x00B924A0: MOV x2, x24                | X2 = val_3;//m1                         
        // 0x00B924A4: BL #0x2415668              | this.mDict.Add(key:  val_3.index, value:  val_3);
        this.mDict.Add(key:  val_3.index, value:  val_3);
        // 0x00B924A8: ADD w23, w23, #1           | W23 = (0 + 1);                          
        val_10 = val_10 + 1;
        // 0x00B924AC: CMP w22, w23               | STATE = COMPARE(val_2, (0 + 1))         
        // 0x00B924B0: B.NE #0xb9245c             | if (val_2 != 0) goto label_8;           
        if(val_2 != val_10)
        {
            goto label_8;
        }
        label_4:
        // 0x00B924B4: LDR x22, [x20, #0x30]      | X22 = this.mDict; //P2                  
        // 0x00B924B8: CBNZ x22, #0xb924c0        | if (this.mDict != null) goto label_9;   
        if(this.mDict != null)
        {
            goto label_9;
        }
        // 0x00B924BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mDict, ????); 
        label_9:
        // 0x00B924C0: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B924C4: LDR x8, [x8, #0x818]       | X8 = 1152921514157187952;               
        // 0x00B924C8: ADD x2, sp, #8             | X2 = (1152921514157210080 + 8) = 1152921514157210088 (0x10000002393EF9E8);
        // 0x00B924CC: MOV x0, x22                | X0 = this.mDict;//m1                    
        // 0x00B924D0: MOV w1, w19                | W1 = index;//m1                         
        // 0x00B924D4: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, BMGlyph>::TryGetValue(System.Int32 key, out BMGlyph value);
        // 0x00B924D8: BL #0x2416950              | X0 = this.mDict.TryGetValue(key:  index, value: out  BMGlyph val_4 = 0);
        bool val_5 = this.mDict.TryGetValue(key:  index, value: out  val_4);
        // 0x00B924DC: AND w8, w0, #1             | W8 = (val_5 & 1);                       
        bool val_6 = val_5;
        // 0x00B924E0: TBNZ w8, #0, #0xb92570     | if ((val_5 & 1) == true) goto label_11; 
        if(val_6 == true)
        {
            goto label_11;
        }
        // 0x00B924E4: EOR w8, w21, #1            | W8 = (createIfMissing ^ 1);             
        bool val_7 = val_10 ^ 1;
        // 0x00B924E8: AND w8, w8, #1             | W8 = ((createIfMissing ^ 1) & 1);       
        bool val_8 = val_7;
        // 0x00B924EC: TBNZ w8, #0, #0xb92570     | if (((createIfMissing ^ 1) & 1) == true) goto label_11;
        if(val_8 == true)
        {
            goto label_11;
        }
        // 0x00B924F0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B924F4: LDR x8, [x8, #0x698]       | X8 = 1152921504875962368;               
        // 0x00B924F8: LDR x0, [x8]               | X0 = typeof(BMGlyph);                   
        object val_9 = null;
        // 0x00B924FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BMGlyph), ????);
        // 0x00B92500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92504: MOV x21, x0                | X21 = 1152921504875962368 (0x10000000100A6000);//ML01
        // 0x00B92508: BL #0x16f59f0              | .ctor();                                
        val_9 = new System.Object();
        // 0x00B9250C: STR x21, [sp, #8]          | stack[1152921514157210088] = typeof(BMGlyph);  //  dest_result_addr=1152921514157210088
        // 0x00B92510: CBNZ x21, #0xb92518        | if ( != 0) goto label_12;               
        if(null != 0)
        {
            goto label_12;
        }
        // 0x00B92514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_12:
        // 0x00B92518: STR w19, [x21, #0x10]      | typeof(BMGlyph).__il2cppRuntimeField_10 = index;  //  dest_result_addr=1152921504875962384
        typeof(BMGlyph).__il2cppRuntimeField_10 = index;
        // 0x00B9251C: LDR x21, [x20, #0x28]      | X21 = this.mSaved; //P2                 
        // 0x00B92520: LDR x22, [sp, #8]          | X22 = typeof(BMGlyph);                  
        // 0x00B92524: CBNZ x21, #0xb9252c        | if (this.mSaved != null) goto label_13; 
        if(this.mSaved != null)
        {
            goto label_13;
        }
        // 0x00B92528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_13:
        // 0x00B9252C: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B92530: LDR x8, [x8, #0x6a0]       | X8 = 1152921514157193072;               
        // 0x00B92534: MOV x0, x21                | X0 = this.mSaved;//m1                   
        // 0x00B92538: MOV x1, x22                | X1 = 1152921504875962368 (0x10000000100A6000);//ML01
        // 0x00B9253C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<BMGlyph>::Add(BMGlyph item);
        // 0x00B92540: BL #0x25ea480              | this.mSaved.Add(item:  val_9);          
        this.mSaved.Add(item:  val_9);
        // 0x00B92544: LDR x20, [x20, #0x30]      | X20 = this.mDict; //P2                  
        // 0x00B92548: LDR x21, [sp, #8]          | X21 = typeof(BMGlyph);                  
        val_10 = val_9;
        // 0x00B9254C: CBNZ x20, #0xb92554        | if (this.mDict != null) goto label_14;  
        if(this.mDict != null)
        {
            goto label_14;
        }
        // 0x00B92550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mSaved, ????);
        label_14:
        // 0x00B92554: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B92558: LDR x8, [x8, #0x368]       | X8 = 1152921514157170544;               
        // 0x00B9255C: MOV x0, x20                | X0 = this.mDict;//m1                    
        // 0x00B92560: MOV w1, w19                | W1 = index;//m1                         
        // 0x00B92564: MOV x2, x21                | X2 = 1152921504875962368 (0x10000000100A6000);//ML01
        // 0x00B92568: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, BMGlyph>::Add(System.Int32 key, BMGlyph value);
        // 0x00B9256C: BL #0x2415668              | this.mDict.Add(key:  index, value:  val_10);
        this.mDict.Add(key:  index, value:  val_10);
        label_11:
        // 0x00B92570: LDR x0, [sp, #8]           | X0 = typeof(BMGlyph);                   
        // 0x00B92574: SUB sp, x29, #0x50         | SP = (1152921514157210176 - 80) = 1152921514157210096 (0x10000002393EF9F0);
        // 0x00B92578: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9257C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92580: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B92584: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B92588: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B9258C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B92590: RET                        |  return (BMGlyph)typeof(BMGlyph);       
        return (BMGlyph)val_9;
        //  |  // // {name=val_0, type=BMGlyph, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9259C (12133788), len: 8  VirtAddr: 0x00B9259C RVA: 0x00B9259C token: 100687883 methodIndex: 25183 delegateWrapperIndex: 0 methodInvoker: 0
    public BMGlyph GetGlyph(int index)
    {
        //
        // Disasemble & Code
        // 0x00B9259C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B925A0: B #0xb923a4                | return this.GetGlyph(index:  index, createIfMissing:  false);
        return this.GetGlyph(index:  index, createIfMissing:  false);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B925A4 (12133796), len: 124  VirtAddr: 0x00B925A4 RVA: 0x00B925A4 token: 100687884 methodIndex: 25184 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B925A4: STP x20, x19, [sp, #-0x20]! | stack[1152921514157477168] = ???;  stack[1152921514157477176] = ???;  //  dest_result_addr=1152921514157477168 |  dest_result_addr=1152921514157477176
        // 0x00B925A8: STP x29, x30, [sp, #0x10]  | stack[1152921514157477184] = ???;  stack[1152921514157477192] = ???;  //  dest_result_addr=1152921514157477184 |  dest_result_addr=1152921514157477192
        // 0x00B925AC: ADD x29, sp, #0x10         | X29 = (1152921514157477168 + 16) = 1152921514157477184 (0x1000000239430D40);
        // 0x00B925B0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B925B4: LDRB w8, [x20, #0xa4a]     | W8 = (bool)static_value_03733A4A;       
        // 0x00B925B8: MOV x19, x0                | X19 = 1152921514157489200 (0x1000000239433C30);//ML01
        // 0x00B925BC: TBNZ w8, #0, #0xb925d8     | if (static_value_03733A4A == true) goto label_0;
        // 0x00B925C0: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B925C4: LDR x8, [x8, #0xbe8]       | X8 = 0x2B8F748;                         
        // 0x00B925C8: LDR w0, [x8]               | W0 = 0x1496;                            
        // 0x00B925CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1496, ????);     
        // 0x00B925D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B925D4: STRB w8, [x20, #0xa4a]     | static_value_03733A4A = true;            //  dest_result_addr=57883210
        label_0:
        // 0x00B925D8: LDR x20, [x19, #0x30]      | X20 = this.mDict; //P2                  
        // 0x00B925DC: CBNZ x20, #0xb925e4        | if (this.mDict != null) goto label_1;   
        if(this.mDict != null)
        {
            goto label_1;
        }
        // 0x00B925E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1496, ????);     
        label_1:
        // 0x00B925E4: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x00B925E8: LDR x8, [x8, #0xf08]       | X8 = 1152921514157459056;               
        // 0x00B925EC: MOV x0, x20                | X0 = this.mDict;//m1                    
        // 0x00B925F0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, BMGlyph>::Clear();
        // 0x00B925F4: BL #0x2415b18              | this.mDict.Clear();                     
        this.mDict.Clear();
        // 0x00B925F8: LDR x19, [x19, #0x28]      | X19 = this.mSaved; //P2                 
        // 0x00B925FC: CBNZ x19, #0xb92604        | if (this.mSaved != null) goto label_2;  
        if(this.mSaved != null)
        {
            goto label_2;
        }
        // 0x00B92600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mDict, ????); 
        label_2:
        // 0x00B92604: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B92608: LDR x8, [x8, #0x140]       | X8 = 1152921514157464176;               
        // 0x00B9260C: MOV x0, x19                | X0 = this.mSaved;//m1                   
        // 0x00B92610: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<BMGlyph>::Clear();
        // 0x00B92614: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92618: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B9261C: B #0x25ead28               | this.mSaved.Clear(); return;            
        this.mSaved.Clear();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92620 (12133920), len: 244  VirtAddr: 0x00B92620 RVA: 0x00B92620 token: 100687885 methodIndex: 25185 delegateWrapperIndex: 0 methodInvoker: 0
    public void Trim(int xMin, int yMin, int xMax, int yMax)
    {
        //
        // Disasemble & Code
        // 0x00B92620: STP x28, x27, [sp, #-0x60]! | stack[1152921514157609584] = ???;  stack[1152921514157609592] = ???;  //  dest_result_addr=1152921514157609584 |  dest_result_addr=1152921514157609592
        // 0x00B92624: STP x26, x25, [sp, #0x10]  | stack[1152921514157609600] = ???;  stack[1152921514157609608] = ???;  //  dest_result_addr=1152921514157609600 |  dest_result_addr=1152921514157609608
        // 0x00B92628: STP x24, x23, [sp, #0x20]  | stack[1152921514157609616] = ???;  stack[1152921514157609624] = ???;  //  dest_result_addr=1152921514157609616 |  dest_result_addr=1152921514157609624
        // 0x00B9262C: STP x22, x21, [sp, #0x30]  | stack[1152921514157609632] = ???;  stack[1152921514157609640] = ???;  //  dest_result_addr=1152921514157609632 |  dest_result_addr=1152921514157609640
        // 0x00B92630: STP x20, x19, [sp, #0x40]  | stack[1152921514157609648] = ???;  stack[1152921514157609656] = ???;  //  dest_result_addr=1152921514157609648 |  dest_result_addr=1152921514157609656
        // 0x00B92634: STP x29, x30, [sp, #0x50]  | stack[1152921514157609664] = ???;  stack[1152921514157609672] = ???;  //  dest_result_addr=1152921514157609664 |  dest_result_addr=1152921514157609672
        // 0x00B92638: ADD x29, sp, #0x50         | X29 = (1152921514157609584 + 80) = 1152921514157609664 (0x10000002394512C0);
        // 0x00B9263C: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00B92640: LDRB w8, [x24, #0xa4b]     | W8 = (bool)static_value_03733A4B;       
        // 0x00B92644: MOV w19, w4                | W19 = yMax;//m1                         
        // 0x00B92648: MOV w20, w3                | W20 = xMax;//m1                         
        // 0x00B9264C: MOV w21, w2                | W21 = yMin;//m1                         
        // 0x00B92650: MOV w22, w1                | W22 = xMin;//m1                         
        // 0x00B92654: MOV x23, x0                | X23 = 1152921514157621680 (0x10000002394541B0);//ML01
        // 0x00B92658: TBNZ w8, #0, #0xb92674     | if (static_value_03733A4B == true) goto label_0;
        // 0x00B9265C: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
        // 0x00B92660: LDR x8, [x8, #0x7c8]       | X8 = 0x2B8F758;                         
        // 0x00B92664: LDR w0, [x8]               | W0 = 0x149A;                            
        // 0x00B92668: BL #0x2782188              | X0 = sub_2782188( ?? 0x149A, ????);     
        // 0x00B9266C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B92670: STRB w8, [x24, #0xa4b]     | static_value_03733A4B = true;            //  dest_result_addr=57883211
        label_0:
        // 0x00B92674: MOV x0, x23                | X0 = 1152921514157621680 (0x10000002394541B0);//ML01
        // 0x00B92678: BL #0xb9226c               | X0 = this.get_isValid();                
        bool val_1 = this.isValid;
        // 0x00B9267C: TBZ w0, #0, #0xb926f8      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B92680: LDR x24, [x23, #0x28]      | X24 = this.mSaved; //P2                 
        // 0x00B92684: CBNZ x24, #0xb9268c        | if (this.mSaved != null) goto label_2;  
        if(this.mSaved != null)
        {
            goto label_2;
        }
        // 0x00B92688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B9268C: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B92690: LDR x8, [x8, #0x8f8]       | X8 = 1152921514155666416;               
        // 0x00B92694: MOV x0, x24                | X0 = this.mSaved;//m1                   
        // 0x00B92698: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<BMGlyph>::get_Count();
        // 0x00B9269C: BL #0x25ed72c              | X0 = this.mSaved.get_Count();           
        int val_2 = this.mSaved.Count;
        // 0x00B926A0: MOV w24, w0                | W24 = val_2;//m1                        
        // 0x00B926A4: CMP w24, #1                | STATE = COMPARE(val_2, 0x1)             
        // 0x00B926A8: B.LT #0xb926f8             | if (val_2 < 1) goto label_3;            
        if(val_2 < 1)
        {
            goto label_3;
        }
        // 0x00B926AC: ADRP x27, #0x360d000       | X27 = 56676352 (0x360D000);             
        // 0x00B926B0: LDR x27, [x27, #0x418]     | X27 = 1152921514157169520;              
        // 0x00B926B4: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        var val_4 = 0;
        label_6:
        // 0x00B926B8: LDR x26, [x23, #0x28]      | X26 = this.mSaved; //P2                 
        // 0x00B926BC: CBNZ x26, #0xb926c4        | if (this.mSaved != null) goto label_4;  
        if(this.mSaved != null)
        {
            goto label_4;
        }
        // 0x00B926C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B926C4: LDR x2, [x27]              | X2 = public BMGlyph System.Collections.Generic.List<BMGlyph>::get_Item(int index);
        // 0x00B926C8: MOV x0, x26                | X0 = this.mSaved;//m1                   
        // 0x00B926CC: MOV w1, w25                | W1 = 0 (0x0);//ML01                     
        // 0x00B926D0: BL #0x25ed734              | X0 = this.mSaved.get_Item(index:  0);   
        BMGlyph val_3 = this.mSaved.Item[0];
        // 0x00B926D4: CBZ x0, #0xb926ec          | if (val_3 == null) goto label_5;        
        if(val_3 == null)
        {
            goto label_5;
        }
        // 0x00B926D8: MOV w1, w22                | W1 = xMin;//m1                          
        // 0x00B926DC: MOV w2, w21                | W2 = yMin;//m1                          
        // 0x00B926E0: MOV w3, w20                | W3 = xMax;//m1                          
        // 0x00B926E4: MOV w4, w19                | W4 = yMax;//m1                          
        // 0x00B926E8: BL #0xb92714               | val_3.Trim(xMin:  xMin, yMin:  yMin, xMax:  xMax, yMax:  yMax);
        val_3.Trim(xMin:  xMin, yMin:  yMin, xMax:  xMax, yMax:  yMax);
        label_5:
        // 0x00B926EC: ADD w25, w25, #1           | W25 = (0 + 1);                          
        val_4 = val_4 + 1;
        // 0x00B926F0: CMP w24, w25               | STATE = COMPARE(val_2, (0 + 1))         
        // 0x00B926F4: B.NE #0xb926b8             | if (val_2 != 0) goto label_6;           
        if(val_2 != val_4)
        {
            goto label_6;
        }
        label_3:
        // 0x00B926F8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B926FC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92700: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B92704: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B92708: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B9270C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B92710: RET                        |  return;                                
        return;
    
    }

}
