using UnityEngine;
[Serializable]
public class BMGlyph
{
    // Fields
    public int index; //  0x00000010
    public int x; //  0x00000014
    public int y; //  0x00000018
    public int width; //  0x0000001C
    public int height; //  0x00000020
    public int offsetX; //  0x00000024
    public int offsetY; //  0x00000028
    public int advance; //  0x0000002C
    public int channel; //  0x00000030
    public System.Collections.Generic.List<int> kerning; //  0x00000038
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B92594 (12133780), len: 8  VirtAddr: 0x00B92594 RVA: 0x00B92594 token: 100687886 methodIndex: 25186 delegateWrapperIndex: 0 methodInvoker: 0
    public BMGlyph()
    {
        //
        // Disasemble & Code
        // 0x00B92594: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92598: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B927A4 (12134308), len: 232  VirtAddr: 0x00B927A4 RVA: 0x00B927A4 token: 100687887 methodIndex: 25187 delegateWrapperIndex: 0 methodInvoker: 0
    public int GetKerning(int previousChar)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B927A4: STP x24, x23, [sp, #-0x40]! | stack[1152921514157858192] = ???;  stack[1152921514157858200] = ???;  //  dest_result_addr=1152921514157858192 |  dest_result_addr=1152921514157858200
        // 0x00B927A8: STP x22, x21, [sp, #0x10]  | stack[1152921514157858208] = ???;  stack[1152921514157858216] = ???;  //  dest_result_addr=1152921514157858208 |  dest_result_addr=1152921514157858216
        // 0x00B927AC: STP x20, x19, [sp, #0x20]  | stack[1152921514157858224] = ???;  stack[1152921514157858232] = ???;  //  dest_result_addr=1152921514157858224 |  dest_result_addr=1152921514157858232
        // 0x00B927B0: STP x29, x30, [sp, #0x30]  | stack[1152921514157858240] = ???;  stack[1152921514157858248] = ???;  //  dest_result_addr=1152921514157858240 |  dest_result_addr=1152921514157858248
        // 0x00B927B4: ADD x29, sp, #0x30         | X29 = (1152921514157858192 + 48) = 1152921514157858240 (0x100000023948DDC0);
        // 0x00B927B8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B927BC: LDRB w8, [x21, #0xa4c]     | W8 = (bool)static_value_03733A4C;       
        // 0x00B927C0: MOV w19, w1                | W19 = previousChar;//m1                 
        // 0x00B927C4: MOV x20, x0                | X20 = 1152921514157870256 (0x1000000239490CB0);//ML01
        // 0x00B927C8: TBNZ w8, #0, #0xb927e4     | if (static_value_03733A4C == true) goto label_0;
        // 0x00B927CC: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00B927D0: LDR x8, [x8, #0xa50]       | X8 = 0x2B8F7C8;                         
        // 0x00B927D4: LDR w0, [x8]               | W0 = 0x14B6;                            
        // 0x00B927D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B6, ????);     
        // 0x00B927DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B927E0: STRB w8, [x21, #0xa4c]     | static_value_03733A4C = true;            //  dest_result_addr=57883212
        label_0:
        // 0x00B927E4: CBZ w19, #0xb92848         | if (previousChar == 0) goto label_3;    
        if(previousChar == 0)
        {
            goto label_3;
        }
        // 0x00B927E8: LDR x0, [x20, #0x38]       | X0 = this.kerning; //P2                 
        // 0x00B927EC: CBZ x0, #0xb92848          | if (this.kerning == null) goto label_3; 
        if(this.kerning == null)
        {
            goto label_3;
        }
        // 0x00B927F0: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B927F4: LDR x8, [x8, #0x598]       | X8 = 1152921510876601136;               
        // 0x00B927F8: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Count();
        // 0x00B927FC: BL #0x25e4ddc              | X0 = this.kerning.get_Count();          
        int val_1 = this.kerning.Count;
        // 0x00B92800: MOV w22, w0                | W22 = val_1;//m1                        
        // 0x00B92804: CMP w22, #1                | STATE = COMPARE(val_1, 0x1)             
        // 0x00B92808: B.LT #0xb92848             | if (val_1 < 1) goto label_3;            
        if(val_1 < 1)
        {
            goto label_3;
        }
        // 0x00B9280C: ADRP x24, #0x3653000       | X24 = 56963072 (0x3653000);             
        // 0x00B92810: LDR x24, [x24, #0x408]     | X24 = 1152921510876430768;              
        // 0x00B92814: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        label_6:
        // 0x00B92818: LDR x23, [x20, #0x38]      | X23 = this.kerning; //P2                
        // 0x00B9281C: CBNZ x23, #0xb92824        | if (this.kerning != null) goto label_4; 
        if(this.kerning != null)
        {
            goto label_4;
        }
        // 0x00B92820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B92824: LDR x2, [x24]              | X2 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Item(int index);
        // 0x00B92828: MOV x0, x23                | X0 = this.kerning;//m1                  
        // 0x00B9282C: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00B92830: BL #0x25e4de4              | X0 = this.kerning.get_Item(index:  0);  
        int val_2 = this.kerning.Item[0];
        // 0x00B92834: CMP w0, w19                | STATE = COMPARE(val_2, previousChar)    
        // 0x00B92838: B.EQ #0xb92860             | if (val_2 == previousChar) goto label_5;
        if(val_2 == previousChar)
        {
            goto label_5;
        }
        // 0x00B9283C: ADD w21, w21, #2           | W21 = (0 + 2);                          
        val_3 = 0 + 2;
        // 0x00B92840: CMP w21, w22               | STATE = COMPARE((0 + 2), val_1)         
        // 0x00B92844: B.LT #0xb92818             | if (val_3 < val_1) goto label_6;        
        if(val_3 < val_1)
        {
            goto label_6;
        }
        label_3:
        // 0x00B92848: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9284C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92850: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B92854: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        // 0x00B92858: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B9285C: RET                        |  return (System.Int32)0;                
        return (int)0;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        label_5:
        // 0x00B92860: LDR x19, [x20, #0x38]      | X19 = this.kerning; //P2                
        // 0x00B92864: CBNZ x19, #0xb9286c        | if (this.kerning != null) goto label_7; 
        if(this.kerning != null)
        {
            goto label_7;
        }
        // 0x00B92868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B9286C: LDR x2, [x24]              | X2 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Item(int index);
        // 0x00B92870: ADD w1, w21, #1            | W1 = (0 + 1);                           
        int val_3 = 0 + 1;
        // 0x00B92874: MOV x0, x19                | X0 = this.kerning;//m1                  
        // 0x00B92878: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9287C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92880: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B92884: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B92888: B #0x25e4de4               | return this.kerning.get_Item(index:  int val_3 = 0 + 1);
        return this.kerning.Item[val_3];
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9288C (12134540), len: 348  VirtAddr: 0x00B9288C RVA: 0x00B9288C token: 100687888 methodIndex: 25188 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetKerning(int previousChar, int amount)
    {
        //
        // Disasemble & Code
        //  | 
        System.Collections.Generic.List<System.Int32> val_4;
        //  | 
        var val_5;
        // 0x00B9288C: STP x24, x23, [sp, #-0x40]! | stack[1152921514158002960] = ???;  stack[1152921514158002968] = ???;  //  dest_result_addr=1152921514158002960 |  dest_result_addr=1152921514158002968
        // 0x00B92890: STP x22, x21, [sp, #0x10]  | stack[1152921514158002976] = ???;  stack[1152921514158002984] = ???;  //  dest_result_addr=1152921514158002976 |  dest_result_addr=1152921514158002984
        // 0x00B92894: STP x20, x19, [sp, #0x20]  | stack[1152921514158002992] = ???;  stack[1152921514158003000] = ???;  //  dest_result_addr=1152921514158002992 |  dest_result_addr=1152921514158003000
        // 0x00B92898: STP x29, x30, [sp, #0x30]  | stack[1152921514158003008] = ???;  stack[1152921514158003016] = ???;  //  dest_result_addr=1152921514158003008 |  dest_result_addr=1152921514158003016
        // 0x00B9289C: ADD x29, sp, #0x30         | X29 = (1152921514158002960 + 48) = 1152921514158003008 (0x10000002394B1340);
        // 0x00B928A0: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B928A4: LDRB w8, [x22, #0xa4d]     | W8 = (bool)static_value_03733A4D;       
        // 0x00B928A8: MOV w19, w2                | W19 = amount;//m1                       
        // 0x00B928AC: MOV w21, w1                | W21 = previousChar;//m1                 
        // 0x00B928B0: MOV x20, x0                | X20 = 1152921514158015024 (0x10000002394B4230);//ML01
        // 0x00B928B4: TBNZ w8, #0, #0xb928d0     | if (static_value_03733A4D == true) goto label_0;
        // 0x00B928B8: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x00B928BC: LDR x8, [x8, #0x500]       | X8 = 0x2B8F7CC;                         
        // 0x00B928C0: LDR w0, [x8]               | W0 = 0x14B7;                            
        // 0x00B928C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14B7, ????);     
        // 0x00B928C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B928CC: STRB w8, [x22, #0xa4d]     | static_value_03733A4D = true;            //  dest_result_addr=57883213
        label_0:
        // 0x00B928D0: LDR x23, [x20, #0x38]      | X23 = this.kerning; //P2                
        val_4 = this.kerning;
        // 0x00B928D4: CBZ x23, #0xb928e0         | if (this.kerning == null) goto label_1; 
        if(val_4 == null)
        {
            goto label_1;
        }
        // 0x00B928D8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B928DC: B #0xb92918                |  goto label_3;                          
        goto label_3;
        label_1:
        // 0x00B928E0: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B928E4: LDR x8, [x8, #0x1c0]       | X8 = 1152921504616644608;               
        // 0x00B928E8: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.Int32> val_1 = null;
        // 0x00B928EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B928F0: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B928F4: LDR x8, [x8, #0x268]       | X8 = 1152921510015557168;               
        // 0x00B928F8: MOV x23, x0                | X23 = 1152921504616644608 (0x1000000000958000);//ML01
        val_4 = val_1;
        // 0x00B928FC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Int32>::.ctor();
        // 0x00B92900: BL #0x25e0ae0              | .ctor();                                
        val_1 = new System.Collections.Generic.List<System.Int32>();
        // 0x00B92904: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B92908: STR x23, [x20, #0x38]      | this.kerning = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514158015080
        this.kerning = val_4;
        // 0x00B9290C: B #0xb92918                |  goto label_3;                          
        goto label_3;
        label_7:
        // 0x00B92910: LDR x23, [x20, #0x38]      | X23 = this.kerning; //P2                
        val_4 = this.kerning;
        // 0x00B92914: ADD w22, w22, #2           | W22 = (val_5 + 2) = val_5 (0x00000002); 
        val_5 = 2;
        label_3:
        // 0x00B92918: CBNZ x23, #0xb92920        | if (this.kerning != null) goto label_4; 
        if(val_4 != null)
        {
            goto label_4;
        }
        // 0x00B9291C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_4:
        // 0x00B92920: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B92924: LDR x8, [x8, #0x598]       | X8 = 1152921510876601136;               
        // 0x00B92928: MOV x0, x23                | X0 = this.kerning;//m1                  
        // 0x00B9292C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Count();
        // 0x00B92930: BL #0x25e4ddc              | X0 = this.kerning.get_Count();          
        int val_2 = val_4.Count;
        // 0x00B92934: LDR x23, [x20, #0x38]      | X23 = this.kerning; //P2                
        // 0x00B92938: MOV w24, w0                | W24 = val_2;//m1                        
        // 0x00B9293C: CBNZ x23, #0xb92944        | if (this.kerning != null) goto label_5; 
        if(this.kerning != null)
        {
            goto label_5;
        }
        // 0x00B92940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B92944: CMP w22, w24               | STATE = COMPARE(0x2, val_2)             
        // 0x00B92948: B.GE #0xb929a4             | if (val_5 >= val_2) goto label_6;       
        if(val_5 >= val_2)
        {
            goto label_6;
        }
        // 0x00B9294C: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00B92950: LDR x8, [x8, #0x408]       | X8 = 1152921510876430768;               
        // 0x00B92954: MOV x0, x23                | X0 = this.kerning;//m1                  
        // 0x00B92958: MOV w1, w22                | W1 = 2 (0x2);//ML01                     
        // 0x00B9295C: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.Int32>::get_Item(int index);
        // 0x00B92960: BL #0x25e4de4              | X0 = this.kerning.get_Item(index:  2);  
        int val_3 = this.kerning.Item[2];
        // 0x00B92964: CMP w0, w21                | STATE = COMPARE(val_3, previousChar)    
        // 0x00B92968: B.NE #0xb92910             | if (val_3 != previousChar) goto label_7;
        if(val_3 != previousChar)
        {
            goto label_7;
        }
        // 0x00B9296C: LDR x20, [x20, #0x38]      | X20 = this.kerning; //P2                
        // 0x00B92970: CBNZ x20, #0xb92978        | if (this.kerning != null) goto label_8; 
        if(this.kerning != null)
        {
            goto label_8;
        }
        // 0x00B92974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B92978: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x00B9297C: LDR x8, [x8, #0x620]       | X8 = 1152921510878335536;               
        // 0x00B92980: ADD w1, w22, #1            | W1 = (val_5 + 1);                       
        int val_4 = val_5 + 1;
        // 0x00B92984: MOV x0, x20                | X0 = this.kerning;//m1                  
        // 0x00B92988: MOV w2, w19                | W2 = amount;//m1                        
        // 0x00B9298C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.List<System.Int32>::set_Item(int index, System.Int32 value);
        // 0x00B92990: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92994: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92998: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B9299C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B929A0: B #0x25e4eac               | this.kerning.set_Item(index:  int val_4 = val_5 + 1, value:  amount); return;
        this.kerning.set_Item(index:  val_4, value:  amount);
        return;
        label_6:
        // 0x00B929A4: ADRP x22, #0x3651000       | X22 = 56954880 (0x3651000);             
        // 0x00B929A8: LDR x22, [x22, #0x390]     | X22 = 1152921510015558192;              
        // 0x00B929AC: MOV x0, x23                | X0 = this.kerning;//m1                  
        // 0x00B929B0: MOV w1, w21                | W1 = previousChar;//m1                  
        // 0x00B929B4: LDR x2, [x22]              | X2 = public System.Void System.Collections.Generic.List<System.Int32>::Add(System.Int32 item);
        // 0x00B929B8: BL #0x25e1b34              | this.kerning.Add(item:  previousChar);  
        this.kerning.Add(item:  previousChar);
        // 0x00B929BC: LDR x20, [x20, #0x38]      | X20 = this.kerning; //P2                
        // 0x00B929C0: CBNZ x20, #0xb929c8        | if (this.kerning != null) goto label_9; 
        if(this.kerning != null)
        {
            goto label_9;
        }
        // 0x00B929C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.kerning, ????);
        label_9:
        // 0x00B929C8: LDR x2, [x22]              | X2 = public System.Void System.Collections.Generic.List<System.Int32>::Add(System.Int32 item);
        // 0x00B929CC: MOV x0, x20                | X0 = this.kerning;//m1                  
        // 0x00B929D0: MOV w1, w19                | W1 = amount;//m1                        
        // 0x00B929D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B929D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B929DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B929E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B929E4: B #0x25e1b34               | this.kerning.Add(item:  amount); return;
        this.kerning.Add(item:  amount);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92714 (12134164), len: 144  VirtAddr: 0x00B92714 RVA: 0x00B92714 token: 100687889 methodIndex: 25189 delegateWrapperIndex: 0 methodInvoker: 0
    public void Trim(int xMin, int yMin, int xMax, int yMax)
    {
        //
        // Disasemble & Code
        //  | 
        int val_7;
        //  | 
        int val_8;
        // 0x00B92714: LDP w8, w11, [x0, #0x18]   | W8 = this.y; //P2  W11 = this.width; //P2  //  | 
        int val_6 = this.y;
        int val_5 = this.width;
        // 0x00B92718: LDR w12, [x0, #0x14]       | W12 = this.x; //P2                      
        // 0x00B9271C: LDR x9, [x0, #0x20]        | X9 = this.height; //P2                  
        // 0x00B92720: CMP w12, w1                | STATE = COMPARE(this.x, xMin)           
        // 0x00B92724: MOV w10, w11               | W10 = this.width;//m1                   
        val_7 = val_5;
        // 0x00B92728: B.GE #0xb92748             | if (this.x >= xMin) goto label_0;       
        if(this.x >= xMin)
        {
            goto label_0;
        }
        // 0x00B9272C: LSR x13, x9, #0x20         | X13 = (this.height >> 32);              
        int val_1 = this.height >> 32;
        // 0x00B92730: SUB w14, w1, w12           | W14 = (xMin - this.x);                  
        int val_2 = xMin - this.x;
        // 0x00B92734: SUB w10, w11, w14          | W10 = (this.width - (xMin - this.x));   
        val_7 = val_5 - val_2;
        // 0x00B92738: ADD w13, w13, w14          | W13 = ((this.height >> 32) + (xMin - this.x));
        val_1 = val_1 + val_2;
        // 0x00B9273C: STR w1, [x0, #0x14]        | this.x = xMin;                           //  dest_result_addr=1152921514158147524
        this.x = xMin;
        // 0x00B92740: STR w10, [x0, #0x1c]       | this.width = (this.width - (xMin - this.x));  //  dest_result_addr=1152921514158147532
        this.width = val_7;
        // 0x00B92744: STR w13, [x0, #0x24]       | this.offsetX = ((this.height >> 32) + (xMin - this.x));  //  dest_result_addr=1152921514158147540
        this.offsetX = val_1;
        label_0:
        // 0x00B92748: CMP w8, w2                 | STATE = COMPARE(this.y, yMin)           
        // 0x00B9274C: ADD w11, w11, w12          | W11 = (this.width + this.x);            
        val_5 = val_5 + this.x;
        // 0x00B92750: MOV w12, w9                | W12 = this.height;//m1                  
        val_8 = this.height;
        // 0x00B92754: B.GE #0xb92774             | if (this.y >= yMin) goto label_1;       
        if(val_6 >= yMin)
        {
            goto label_1;
        }
        // 0x00B92758: LDR w14, [x0, #0x28]       | W14 = this.offsetY; //P2                
        // 0x00B9275C: SUB w13, w2, w8            | W13 = (yMin - this.y);                  
        int val_3 = yMin - val_6;
        // 0x00B92760: SUB w12, w9, w13           | W12 = (this.height - (yMin - this.y));  
        val_8 = this.height - val_3;
        // 0x00B92764: STR w2, [x0, #0x18]        | this.y = yMin;                           //  dest_result_addr=1152921514158147528
        this.y = yMin;
        // 0x00B92768: ADD w13, w14, w13          | W13 = (this.offsetY + (yMin - this.y)); 
        val_3 = this.offsetY + val_3;
        // 0x00B9276C: STR w12, [x0, #0x20]       | this.height = (this.height - (yMin - this.y));  //  dest_result_addr=1152921514158147536
        this.height = val_8;
        // 0x00B92770: STR w13, [x0, #0x28]       | this.offsetY = (this.offsetY + (yMin - this.y));  //  dest_result_addr=1152921514158147544
        this.offsetY = val_3;
        label_1:
        // 0x00B92774: ADD w8, w9, w8             | W8 = (this.height + this.y);            
        val_6 = this.height + val_6;
        // 0x00B92778: CMP w11, w3                | STATE = COMPARE((this.width + this.x), xMax)
        // 0x00B9277C: B.LE #0xb9278c             | if (this.width <= xMax) goto label_2;   
        if(val_5 <= xMax)
        {
            goto label_2;
        }
        // 0x00B92780: SUB w9, w3, w11            | W9 = (xMax - (this.width + this.x));    
        int val_4 = xMax - val_5;
        // 0x00B92784: ADD w9, w9, w10            | W9 = ((xMax - (this.width + this.x)) + (this.width - (xMin - this.x)));
        val_4 = val_4 + val_7;
        // 0x00B92788: STR w9, [x0, #0x1c]        | this.width = ((xMax - (this.width + this.x)) + (this.width - (xMin - this.x)));  //  dest_result_addr=1152921514158147532
        this.width = val_4;
        label_2:
        // 0x00B9278C: CMP w8, w4                 | STATE = COMPARE((this.height + this.y), yMax)
        // 0x00B92790: B.LE #0xb927a0             | if (this.y <= yMax) goto label_3;       
        if(val_6 <= yMax)
        {
            goto label_3;
        }
        // 0x00B92794: SUB w8, w4, w8             | W8 = (yMax - (this.height + this.y));   
        val_6 = yMax - val_6;
        // 0x00B92798: ADD w8, w8, w12            | W8 = ((yMax - (this.height + this.y)) + (this.height - (yMin - this.y)));
        val_6 = val_6 + val_8;
        // 0x00B9279C: STR w8, [x0, #0x20]        | this.height = ((yMax - (this.height + this.y)) + (this.height - (yMin - this.y)));  //  dest_result_addr=1152921514158147536
        this.height = val_6;
        label_3:
        // 0x00B927A0: RET                        |  return;                                
        return;
    
    }

}
