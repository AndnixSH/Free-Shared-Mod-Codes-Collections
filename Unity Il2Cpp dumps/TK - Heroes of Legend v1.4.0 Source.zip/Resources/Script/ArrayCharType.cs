using UnityEngine;

namespace wxb
{
    internal class ArrayCharType : ArraySerialize<char>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2BA50 (14858832), len: 80  VirtAddr: 0x00E2BA50 RVA: 0x00E2BA50 token: 100681193 methodIndex: 57197 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayCharType()
        {
            //
            // Disasemble & Code
            // 0x00E2BA50: STP x20, x19, [sp, #-0x20]! | stack[1152921513024924576] = ???;  stack[1152921513024924584] = ???;  //  dest_result_addr=1152921513024924576 |  dest_result_addr=1152921513024924584
            // 0x00E2BA54: STP x29, x30, [sp, #0x10]  | stack[1152921513024924592] = ???;  stack[1152921513024924600] = ???;  //  dest_result_addr=1152921513024924592 |  dest_result_addr=1152921513024924600
            // 0x00E2BA58: ADD x29, sp, #0x10         | X29 = (1152921513024924576 + 16) = 1152921513024924592 (0x10000001F5C1ABB0);
            // 0x00E2BA5C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BA60: LDRB w8, [x20, #0x8eb]     | W8 = (bool)static_value_037348EB;       
            // 0x00E2BA64: MOV x19, x0                | X19 = 1152921513024936608 (0x10000001F5C1DAA0);//ML01
            // 0x00E2BA68: TBNZ w8, #0, #0xe2ba84     | if (static_value_037348EB == true) goto label_0;
            // 0x00E2BA6C: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00E2BA70: LDR x8, [x8, #0x9c0]       | X8 = 0x2B8E714;                         
            // 0x00E2BA74: LDR w0, [x8]               | W0 = 0x1083;                            
            // 0x00E2BA78: BL #0x2782188              | X0 = sub_2782188( ?? 0x1083, ????);     
            // 0x00E2BA7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BA80: STRB w8, [x20, #0x8eb]     | static_value_037348EB = true;            //  dest_result_addr=57886955
            label_0:
            // 0x00E2BA84: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00E2BA88: LDR x8, [x8, #0xe10]       | X8 = 1152921513024911584;               
            // 0x00E2BA8C: MOV x0, x19                | X0 = 1152921513024936608 (0x10000001F5C1DAA0);//ML01
            // 0x00E2BA90: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Char>::.ctor();
            // 0x00E2BA94: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BA98: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BA9C: B #0x1d86f00               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BAA0 (14858912), len: 8  VirtAddr: 0x00E2BAA0 RVA: 0x00E2BAA0 token: 100681194 methodIndex: 57198 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2BAA0: ORR w0, wzr, #2            | W0 = 2(0x2);                            
            // 0x00E2BAA4: RET                        |  return (System.Int32)2;                
            return (int)2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BAA8 (14858920), len: 52  VirtAddr: 0x00E2BAA8 RVA: 0x00E2BAA8 token: 100681195 methodIndex: 57199 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, char value)
        {
            //
            // Disasemble & Code
            // 0x00E2BAA8: STP x20, x19, [sp, #-0x20]! | stack[1152921513025152672] = ???;  stack[1152921513025152680] = ???;  //  dest_result_addr=1152921513025152672 |  dest_result_addr=1152921513025152680
            // 0x00E2BAAC: STP x29, x30, [sp, #0x10]  | stack[1152921513025152688] = ???;  stack[1152921513025152696] = ???;  //  dest_result_addr=1152921513025152688 |  dest_result_addr=1152921513025152696
            // 0x00E2BAB0: ADD x29, sp, #0x10         | X29 = (1152921513025152672 + 16) = 1152921513025152688 (0x10000001F5C526B0);
            // 0x00E2BAB4: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2BAB8: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2BABC: CBNZ x20, #0xe2bac4        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BAC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BAC4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BAC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BACC: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2BAD0: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2BAD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BAD8: B #0x26a478c               | stream.WriteInt16(value:  value); return;
            stream.WriteInt16(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BADC (14858972), len: 44  VirtAddr: 0x00E2BADC RVA: 0x00E2BADC token: 100681196 methodIndex: 57200 delegateWrapperIndex: 0 methodInvoker: 0
        protected override char Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2BADC: STP x20, x19, [sp, #-0x20]! | stack[1152921513025272864] = ???;  stack[1152921513025272872] = ???;  //  dest_result_addr=1152921513025272864 |  dest_result_addr=1152921513025272872
            // 0x00E2BAE0: STP x29, x30, [sp, #0x10]  | stack[1152921513025272880] = ???;  stack[1152921513025272888] = ???;  //  dest_result_addr=1152921513025272880 |  dest_result_addr=1152921513025272888
            // 0x00E2BAE4: ADD x29, sp, #0x10         | X29 = (1152921513025272864 + 16) = 1152921513025272880 (0x10000001F5C6FC30);
            // 0x00E2BAE8: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BAEC: CBNZ x19, #0xe2baf4        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BAF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BAF4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BAF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BAFC: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BB00: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BB04: B #0x269ff60               | return stream.ReadInt16();              
            return stream.ReadInt16();
        
        }
    
    }

}
