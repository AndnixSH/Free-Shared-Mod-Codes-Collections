using UnityEngine;
public class Boss : Monster
{
    // Fields
    private static float CheckDamageTime; // static_offset: 0x00000000
    private float baseTime; //  0x00000634
    public bool IsShowHp; //  0x00000638
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B93854 (12138580), len: 8  VirtAddr: 0x00B93854 RVA: 0x00B93854 token: 100691633 methodIndex: 25205 delegateWrapperIndex: 0 methodInvoker: 0
    public Boss()
    {
        //
        // Disasemble & Code
        // 0x00B93854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93858: B #0xac4934                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9385C (12138588), len: 220  VirtAddr: 0x00B9385C RVA: 0x00B9385C token: 100691634 methodIndex: 25206 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void AfterAttack()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B9385C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514686163776] = ???;  stack[1152921514686163784] = ???;  //  dest_result_addr=1152921514686163776 |  dest_result_addr=1152921514686163784
        // 0x00B93860: STP x20, x19, [sp, #0x10]  | stack[1152921514686163792] = ???;  stack[1152921514686163800] = ???;  //  dest_result_addr=1152921514686163792 |  dest_result_addr=1152921514686163800
        // 0x00B93864: STP x29, x30, [sp, #0x20]  | stack[1152921514686163808] = ???;  stack[1152921514686163816] = ???;  //  dest_result_addr=1152921514686163808 |  dest_result_addr=1152921514686163816
        // 0x00B93868: ADD x29, sp, #0x20         | X29 = (1152921514686163776 + 32) = 1152921514686163808 (0x1000000258C62B60);
        // 0x00B9386C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B93870: LDRB w8, [x20, #0xa61]     | W8 = (bool)static_value_03733A61;       
        // 0x00B93874: MOV x19, x0                | X19 = 1152921514686175824 (0x1000000258C65A50);//ML01
        // 0x00B93878: TBNZ w8, #0, #0xb93894     | if (static_value_03733A61 == true) goto label_0;
        // 0x00B9387C: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
        // 0x00B93880: LDR x8, [x8, #0xcf8]       | X8 = 0x2B8F890;                         
        // 0x00B93884: LDR w0, [x8]               | W0 = 0x14E8;                            
        // 0x00B93888: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E8, ????);     
        // 0x00B9388C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93890: STRB w8, [x20, #0xa61]     | static_value_03733A61 = true;            //  dest_result_addr=57883233
        label_0:
        // 0x00B93894: ADRP x20, #0x3641000       | X20 = 56889344 (0x3641000);             
        // 0x00B93898: LDR x20, [x20, #0xe8]      | X20 = 1152921504893960192;              
        // 0x00B9389C: LDR s8, [x19, #0x634]      | S8 = this.baseTime; //P2                
        // 0x00B938A0: LDR x0, [x20]              | X0 = typeof(Boss);                      
        val_3 = null;
        // 0x00B938A4: LDRB w8, [x0, #0x10a]      | W8 = Boss.__il2cppRuntimeField_10A;     
        // 0x00B938A8: TBZ w8, #0, #0xb938bc      | if (Boss.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B938AC: LDR w8, [x0, #0xbc]        | W8 = Boss.__il2cppRuntimeField_cctor_finished;
        // 0x00B938B0: CBNZ w8, #0xb938bc         | if (Boss.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B938B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Boss), ????);
        // 0x00B938B8: LDR x0, [x20]              | X0 = typeof(Boss);                      
        val_3 = null;
        label_2:
        // 0x00B938BC: LDR x8, [x0, #0xa0]        | X8 = Boss.__il2cppRuntimeField_static_fields;
        // 0x00B938C0: LDR s0, [x8]               | S0 = Boss.CheckDamageTime;              
        // 0x00B938C4: FCMP s8, s0                | STATE = COMPARE(this.baseTime, Boss.CheckDamageTime)
        // 0x00B938C8: B.GE #0xb938e4             | if (this.baseTime >= Boss.CheckDamageTime) goto label_3;
        if(this.baseTime >= Boss.CheckDamageTime)
        {
            goto label_3;
        }
        // 0x00B938CC: MOV x0, x19                | X0 = 1152921514686175824 (0x1000000258C65A50);//ML01
        // 0x00B938D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B938D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B938D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B938DC: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B938E0: B #0xd8f964                | this.AfterAttack(); return;             
        this.AfterAttack();
        return;
        label_3:
        // 0x00B938E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B938E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B938EC: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_1 = HeroMgr.instance;
        // 0x00B938F0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B938F4: CBNZ x20, #0xb938fc        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00B938F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B938FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93900: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B93904: BL #0x289b09c              | X0 = val_1.GetTotalDamageHero();        
        CombatEntity val_2 = val_1.GetTotalDamageHero();
        // 0x00B93908: LDR x8, [x19]              | X8 = typeof(Boss);                      
        // 0x00B9390C: MOV x1, x0                 | X1 = val_2;//m1                         
        // 0x00B93910: MOV x0, x19                | X0 = 1152921514686175824 (0x1000000258C65A50);//ML01
        // 0x00B93914: LDR x9, [x8, #0x230]       | X9 = public System.Void CombatEntity::set_atkTarget(CombatEntity value);
        // 0x00B93918: LDR x2, [x8, #0x238]       | X2 = public System.Void CombatEntity::set_atkTarget(CombatEntity value);
        // 0x00B9391C: BLR x9                     | val_2.set_atkTarget(value:  val_2);     
        val_2.atkTarget = val_2;
        // 0x00B93920: STR wzr, [x19, #0x634]     | this.baseTime = 0;                       //  dest_result_addr=1152921514686177412
        this.baseTime = 0f;
        // 0x00B93924: STRB wzr, [x19, #0x268]    | mem[1152921514686176440] = 0x0;          //  dest_result_addr=1152921514686176440
        mem[1152921514686176440] = 0;
        // 0x00B93928: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9392C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B93930: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B93934: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93938 (12138808), len: 148  VirtAddr: 0x00B93938 RVA: 0x00B93938 token: 100691635 methodIndex: 25207 delegateWrapperIndex: 0 methodInvoker: 0
    protected override void Dead()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00B93938: STP x22, x21, [sp, #-0x30]! | stack[1152921514686283968] = ???;  stack[1152921514686283976] = ???;  //  dest_result_addr=1152921514686283968 |  dest_result_addr=1152921514686283976
        // 0x00B9393C: STP x20, x19, [sp, #0x10]  | stack[1152921514686283984] = ???;  stack[1152921514686283992] = ???;  //  dest_result_addr=1152921514686283984 |  dest_result_addr=1152921514686283992
        // 0x00B93940: STP x29, x30, [sp, #0x20]  | stack[1152921514686284000] = ???;  stack[1152921514686284008] = ???;  //  dest_result_addr=1152921514686284000 |  dest_result_addr=1152921514686284008
        // 0x00B93944: ADD x29, sp, #0x20         | X29 = (1152921514686283968 + 32) = 1152921514686284000 (0x1000000258C800E0);
        // 0x00B93948: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B9394C: LDRB w8, [x20, #0xa62]     | W8 = (bool)static_value_03733A62;       
        // 0x00B93950: MOV x19, x0                | X19 = 1152921514686296016 (0x1000000258C82FD0);//ML01
        // 0x00B93954: TBNZ w8, #0, #0xb93970     | if (static_value_03733A62 == true) goto label_0;
        // 0x00B93958: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
        // 0x00B9395C: LDR x8, [x8, #0xb18]       | X8 = 0x2B8F8AC;                         
        // 0x00B93960: LDR w0, [x8]               | W0 = 0x14EF;                            
        // 0x00B93964: BL #0x2782188              | X0 = sub_2782188( ?? 0x14EF, ????);     
        // 0x00B93968: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9396C: STRB w8, [x20, #0xa62]     | static_value_03733A62 = true;            //  dest_result_addr=57883234
        label_0:
        // 0x00B93970: ADRP x20, #0x3611000       | X20 = 56692736 (0x3611000);             
        // 0x00B93974: LDR x20, [x20, #0x430]     | X20 = 1152921504887730176;              
        // 0x00B93978: LDR x0, [x20]              | X0 = typeof(CameraHelper);              
        val_1 = null;
        // 0x00B9397C: LDRB w8, [x0, #0x10a]      | W8 = CameraHelper.__il2cppRuntimeField_10A;
        // 0x00B93980: TBZ w8, #0, #0xb93994      | if (CameraHelper.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B93984: LDR w8, [x0, #0xbc]        | W8 = CameraHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00B93988: CBNZ w8, #0xb93994         | if (CameraHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B9398C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraHelper), ????);
        // 0x00B93990: LDR x0, [x20]              | X0 = typeof(CameraHelper);              
        val_1 = null;
        label_2:
        // 0x00B93994: LDR x8, [x0, #0xa0]        | X8 = CameraHelper.__il2cppRuntimeField_static_fields;
        // 0x00B93998: LDR x21, [x19, #0x58]      | 
        // 0x00B9399C: LDR x20, [x8]              | X20 = CameraHelper.instance;            
        // 0x00B939A0: CBNZ x20, #0xb939a8        | if (CameraHelper.instance != null) goto label_3;
        if(CameraHelper.instance != null)
        {
            goto label_3;
        }
        // 0x00B939A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraHelper), ????);
        label_3:
        // 0x00B939A8: MOV x0, x20                | X0 = CameraHelper.instance;//m1         
        // 0x00B939AC: MOV x1, x21                | X1 = X21;//m1                           
        // 0x00B939B0: BL #0xbab070               | CameraHelper.instance.MotionBlur(target:  X21, distance:  null);
        CameraHelper.instance.MotionBlur(target:  X21, distance:  null);
        // 0x00B939B4: MOV x0, x19                | X0 = 1152921514686296016 (0x1000000258C82FD0);//ML01
        // 0x00B939B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B939BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B939C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B939C4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B939C8: B #0xac871c                | this.Dead(); return;                    
        this.Dead();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B939D0 (12138960), len: 84  VirtAddr: 0x00B939D0 RVA: 0x00B939D0 token: 100691636 methodIndex: 25208 delegateWrapperIndex: 0 methodInvoker: 0
    private static Boss()
    {
        //
        // Disasemble & Code
        // 0x00B939D0: STP x20, x19, [sp, #-0x20]! | stack[1152921514686395984] = ???;  stack[1152921514686395992] = ???;  //  dest_result_addr=1152921514686395984 |  dest_result_addr=1152921514686395992
        // 0x00B939D4: STP x29, x30, [sp, #0x10]  | stack[1152921514686396000] = ???;  stack[1152921514686396008] = ???;  //  dest_result_addr=1152921514686396000 |  dest_result_addr=1152921514686396008
        // 0x00B939D8: ADD x29, sp, #0x10         | X29 = (1152921514686395984 + 16) = 1152921514686396000 (0x1000000258C9B660);
        // 0x00B939DC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B939E0: LDRB w8, [x19, #0xa63]     | W8 = (bool)static_value_03733A63;       
        // 0x00B939E4: TBNZ w8, #0, #0xb93a00     | if (static_value_03733A63 == true) goto label_0;
        // 0x00B939E8: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00B939EC: LDR x8, [x8, #0xdd0]       | X8 = 0x2B8F88C;                         
        // 0x00B939F0: LDR w0, [x8]               | W0 = 0x14E7;                            
        // 0x00B939F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E7, ????);     
        // 0x00B939F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B939FC: STRB w8, [x19, #0xa63]     | static_value_03733A63 = true;            //  dest_result_addr=57883235
        label_0:
        // 0x00B93A00: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B93A04: LDR x8, [x8, #0xe8]        | X8 = 1152921504893960192;               
        // 0x00B93A08: MOVZ w9, #0x4120, lsl #16  | W9 = 1092616192 (0x41200000);//ML01     
        // 0x00B93A0C: LDR x8, [x8]               | X8 = typeof(Boss);                      
        // 0x00B93A10: LDR x8, [x8, #0xa0]        | X8 = Boss.__il2cppRuntimeField_static_fields;
        // 0x00B93A14: STR w9, [x8]               | Boss.CheckDamageTime = 10;               //  dest_result_addr=1152921504893964288
        Boss.CheckDamageTime = 10f;
        // 0x00B93A18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93A1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B93A20: RET                        |  return;                                
        return;
    
    }

}
