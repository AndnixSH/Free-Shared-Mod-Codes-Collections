using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AnimationRunner_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache15; // static_offset: 0x000000A8
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BB9544 (12293444), len: 8  VirtAddr: 0x00BB9544 RVA: 0x00BB9544 token: 100663758 methodIndex: 29803 delegateWrapperIndex: 0 methodInvoker: 0
        public AnimationRunner_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BB9544: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9548: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB954C (12293452), len: 6336  VirtAddr: 0x00BB954C RVA: 0x00BB954C token: 100663759 methodIndex: 29804 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            var val_59;
            //  | 
            System.Type[] val_60;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_61;
            //  | 
            var val_62;
            //  | 
            var val_63;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_64;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_65;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_66;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_67;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_68;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_69;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_70;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_71;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_72;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_73;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_74;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_75;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_76;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_77;
            // 0x00BB954C: STP x28, x27, [sp, #-0x60]! | stack[1152921510043482208] = ???;  stack[1152921510043482216] = ???;  //  dest_result_addr=1152921510043482208 |  dest_result_addr=1152921510043482216
            // 0x00BB9550: STP x26, x25, [sp, #0x10]  | stack[1152921510043482224] = ???;  stack[1152921510043482232] = ???;  //  dest_result_addr=1152921510043482224 |  dest_result_addr=1152921510043482232
            // 0x00BB9554: STP x24, x23, [sp, #0x20]  | stack[1152921510043482240] = ???;  stack[1152921510043482248] = ???;  //  dest_result_addr=1152921510043482240 |  dest_result_addr=1152921510043482248
            // 0x00BB9558: STP x22, x21, [sp, #0x30]  | stack[1152921510043482256] = ???;  stack[1152921510043482264] = ???;  //  dest_result_addr=1152921510043482256 |  dest_result_addr=1152921510043482264
            // 0x00BB955C: STP x20, x19, [sp, #0x40]  | stack[1152921510043482272] = ???;  stack[1152921510043482280] = ???;  //  dest_result_addr=1152921510043482272 |  dest_result_addr=1152921510043482280
            // 0x00BB9560: STP x29, x30, [sp, #0x50]  | stack[1152921510043482288] = ???;  stack[1152921510043482296] = ???;  //  dest_result_addr=1152921510043482288 |  dest_result_addr=1152921510043482296
            // 0x00BB9564: ADD x29, sp, #0x50         | X29 = (1152921510043482208 + 80) = 1152921510043482288 (0x10000001440C78B0);
            // 0x00BB9568: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB956C: LDRB w8, [x20, #0xb5b]     | W8 = (bool)static_value_03733B5B;       
            // 0x00BB9570: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB9574: TBNZ w8, #0, #0xbb9590     | if (static_value_03733B5B == true) goto label_0;
            // 0x00BB9578: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x00BB957C: LDR x8, [x8, #0x308]       | X8 = 0x2B8AEBC;                         
            // 0x00BB9580: LDR w0, [x8]               | W0 = 0x26D;                             
            // 0x00BB9584: BL #0x2782188              | X0 = sub_2782188( ?? 0x26D, ????);      
            // 0x00BB9588: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB958C: STRB w8, [x20, #0xb5b]     | static_value_03733B5B = true;            //  dest_result_addr=57883483
            label_0:
            // 0x00BB9590: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00BB9594: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            val_59 = 1152921504609562624;
            // 0x00BB9598: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BB959C: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00BB95A0: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BB95A4: LDR x20, [x8]              | X20 = typeof(AnimationRunner);          
            // 0x00BB95A8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB95AC: TBZ w8, #0, #0xbb95bc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BB95B0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB95B4: CBNZ w8, #0xbb95bc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BB95B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BB95BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB95C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB95C4: MOV x1, x20                | X1 = 1152921504922288128 (0x1000000012CD4000);//ML01
            // 0x00BB95C8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB95CC: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x00BB95D0: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            val_60 = 1152921504987155056;
            // 0x00BB95D4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB95D8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB95DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB95E0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB95E4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB95E8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB95EC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB95F0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB95F4: LDR x8, [x8, #0x2c8]       | X8 = 1152921504922394624;               
            // 0x00BB95F8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB95FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9600: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9604: LDR x1, [x8]               | X1 = typeof(AnimationRunner.AniState);  
            // 0x00BB9608: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB960C: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00BB9610: CBNZ x21, #0xbb9618        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00BB9614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00BB9618: CBZ x22, #0xbb963c         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x00BB961C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9620: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x00BB9624: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9628: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00BB962C: CBNZ x0, #0xbb963c         | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00BB9630: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00BB9634: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9638: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x00BB963C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9640: CBNZ w8, #0xbb9650         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00BB9644: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00BB9648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB964C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x00BB9650: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x00BB9654: CBNZ x20, #0xbb965c        | if (val_1 != null) goto label_7;        
            if(val_1 != null)
            {
                goto label_7;
            }
            // 0x00BB9658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x00BB965C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BB9660: LDR x8, [x8, #0xfd8]       | X8 = (string**)(1152921510043307184)("set_aniState");
            // 0x00BB9664: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9668: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB966C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB9670: LDR x1, [x8]               | X1 = "set_aniState";                    
            // 0x00BB9674: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB9678: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB967C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB9680: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_aniState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "set_aniState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB9684: ADRP x24, #0x35df000       | X24 = 56487936 (0x35DF000);             
            // 0x00BB9688: LDR x24, [x24, #0xc0]      | X24 = 1152921504782831616;              
            // 0x00BB968C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB9690: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9694: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9698: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0;
            // 0x00BB969C: CBNZ x22, #0xbb96e8        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0 != null) goto label_8;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0) != null)
            {
                goto label_8;
            }
            // 0x00BB96A0: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00BB96A4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB96A8: LDR x8, [x8, #0x5c0]       | X8 = 1152921510043311376;               
            // 0x00BB96AC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB96B0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_aniState_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB96B4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_4 = null;
            // 0x00BB96B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB96BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB96C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB96C4: MOV x2, x22                | X2 = 1152921510043311376 (0x100000014409DD10);//ML01
            // 0x00BB96C8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB96CC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_aniState_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_aniState_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB96D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB96D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB96D8: STR x23, [x8]              | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835712
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0 = val_4;
            // 0x00BB96DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB96E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB96E4: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_8:
            // 0x00BB96E8: CBNZ x19, #0xbb96f0        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00BB96EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_aniState_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_9:
            // 0x00BB96F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB96F4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB96F8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB96FC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9700: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache0);
            // 0x00BB9704: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB9708: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB970C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB9710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9714: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9718: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB971C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9720: CBNZ x20, #0xbb9728        | if (val_1 != null) goto label_10;       
            if(val_1 != null)
            {
                goto label_10;
            }
            // 0x00BB9724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_10:
            // 0x00BB9728: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00BB972C: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921510043312400)("get_aniState");
            // 0x00BB9730: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9734: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB9738: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB973C: LDR x1, [x8]               | X1 = "get_aniState";                    
            // 0x00BB9740: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB9744: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9748: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB974C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_aniState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_5 = val_1.GetMethod(name:  "get_aniState", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB9750: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9754: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x00BB9758: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB975C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1;
            // 0x00BB9760: CBNZ x22, #0xbb97ac        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1 != null) goto label_11;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1) != null)
            {
                goto label_11;
            }
            // 0x00BB9764: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00BB9768: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB976C: LDR x8, [x8, #0x2a8]       | X8 = 1152921510043316592;               
            // 0x00BB9770: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB9774: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_aniState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB9778: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_6 = null;
            // 0x00BB977C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB9780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9784: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9788: MOV x2, x22                | X2 = 1152921510043316592 (0x100000014409F170);//ML01
            // 0x00BB978C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9790: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_aniState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_aniState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB9794: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9798: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB979C: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835720
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1 = val_6;
            // 0x00BB97A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB97A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB97A8: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_11:
            // 0x00BB97AC: CBNZ x19, #0xbb97b4        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BB97B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_aniState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_12:
            // 0x00BB97B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB97B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB97BC: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x00BB97C0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB97C4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_5, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_5, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache1);
            // 0x00BB97C8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB97CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB97D0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB97D4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB97D8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB97DC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB97E0: ADRP x23, #0x3683000       | X23 = 57159680 (0x3683000);             
            // 0x00BB97E4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB97E8: LDR x23, [x23, #0xc48]     | X23 = 1152921504608444416;              
            val_61 = 1152921504608444416;
            // 0x00BB97EC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB97F0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB97F4: LDR x22, [x23]             | X22 = typeof(System.Single);            
            // 0x00BB97F8: TBZ w9, #0, #0xbb980c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00BB97FC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB9800: CBNZ w9, #0xbb980c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00BB9804: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB9808: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_14:
            // 0x00BB980C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9814: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x00BB9818: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB981C: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BB9820: CBNZ x21, #0xbb9828        | if ( != null) goto label_15;            
            if(null != null)
            {
                goto label_15;
            }
            // 0x00BB9824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_15:
            // 0x00BB9828: CBZ x22, #0xbb984c         | if (val_7 == null) goto label_17;       
            if(val_7 == null)
            {
                goto label_17;
            }
            // 0x00BB982C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9830: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x00BB9834: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9838: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x00BB983C: CBNZ x0, #0xbb984c         | if (val_7 != null) goto label_17;       
            if(val_7 != null)
            {
                goto label_17;
            }
            // 0x00BB9840: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x00BB9844: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9848: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_17:
            // 0x00BB984C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9850: CBNZ w8, #0xbb9860         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_18;
            // 0x00BB9854: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x00BB9858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB985C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_18:
            // 0x00BB9860: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_7;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_7;
            // 0x00BB9864: CBNZ x20, #0xbb986c        | if (val_1 != null) goto label_19;       
            if(val_1 != null)
            {
                goto label_19;
            }
            // 0x00BB9868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_19:
            // 0x00BB986C: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00BB9870: LDR x8, [x8, #0xc8]        | X8 = (string**)(1152921510043321712)("SetRunSpeed");
            // 0x00BB9874: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9878: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB987C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB9880: LDR x1, [x8]               | X1 = "SetRunSpeed";                     
            // 0x00BB9884: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB9888: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB988C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB9890: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetRunSpeed", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_8 = val_1.GetMethod(name:  "SetRunSpeed", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB9894: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9898: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x00BB989C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB98A0: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2;
            // 0x00BB98A4: CBNZ x22, #0xbb98f8        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2 != null) goto label_20;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2) != null)
            {
                goto label_20;
            }
            // 0x00BB98A8: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00BB98AC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB98B0: LDR x8, [x8, #0xa0]        | X8 = 1152921510043325904;               
            // 0x00BB98B4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB98B8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetRunSpeed_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB98BC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_9 = null;
            // 0x00BB98C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB98C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB98C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB98CC: MOV x2, x22                | X2 = 1152921510043325904 (0x10000001440A15D0);//ML01
            // 0x00BB98D0: MOV x27, x23               | X27 = 57965472 (0x3747BA0);//ML01       
            // 0x00BB98D4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB98D8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetRunSpeed_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetRunSpeed_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB98DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB98E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB98E4: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835728
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2 = val_9;
            // 0x00BB98E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB98EC: MOV x23, x27               | X23 = 57965472 (0x3747BA0);//ML01       
            val_61 = val_61;
            // 0x00BB98F0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB98F4: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_20:
            // 0x00BB98F8: CBNZ x19, #0xbb9900        | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x00BB98FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetRunSpeed_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_21:
            // 0x00BB9900: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9904: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB9908: MOV x1, x21                | X1 = val_8;//m1                         
            // 0x00BB990C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9910: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_8, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2);
            X1.RegisterCLRMethodRedirection(mi:  val_8, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache2);
            // 0x00BB9914: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB9918: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB991C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB9920: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB9924: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9928: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB992C: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x00BB9930: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB9934: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            // 0x00BB9938: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB993C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB9940: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00BB9944: TBZ w9, #0, #0xbb9958      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00BB9948: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB994C: CBNZ w9, #0xbb9958         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00BB9950: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB9954: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_23:
            // 0x00BB9958: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB995C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9960: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BB9964: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9968: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00BB996C: CBNZ x21, #0xbb9974        | if ( != null) goto label_24;            
            if(null != null)
            {
                goto label_24;
            }
            // 0x00BB9970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_24:
            // 0x00BB9974: CBZ x22, #0xbb9998         | if (val_10 == null) goto label_26;      
            if(val_10 == null)
            {
                goto label_26;
            }
            // 0x00BB9978: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB997C: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x00BB9980: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9984: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x00BB9988: CBNZ x0, #0xbb9998         | if (val_10 != null) goto label_26;      
            if(val_10 != null)
            {
                goto label_26;
            }
            // 0x00BB998C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x00BB9990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9994: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_26:
            // 0x00BB9998: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB999C: CBNZ w8, #0xbb99ac         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_27;
            // 0x00BB99A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x00BB99A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB99A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_27:
            // 0x00BB99AC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;
            // 0x00BB99B0: CBNZ x20, #0xbb99b8        | if (val_1 != null) goto label_28;       
            if(val_1 != null)
            {
                goto label_28;
            }
            // 0x00BB99B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_28:
            // 0x00BB99B8: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x00BB99BC: LDR x8, [x8, #0x98]        | X8 = (string**)(1152921510043331024)("HasExistAni");
            // 0x00BB99C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB99C4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB99C8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB99CC: LDR x1, [x8]               | X1 = "HasExistAni";                     
            // 0x00BB99D0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB99D4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB99D8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB99DC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "HasExistAni", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_11 = val_1.GetMethod(name:  "HasExistAni", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB99E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB99E4: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x00BB99E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB99EC: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3;
            // 0x00BB99F0: CBNZ x22, #0xbb9a44        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3 != null) goto label_29;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3) != null)
            {
                goto label_29;
            }
            // 0x00BB99F4: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00BB99F8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB99FC: LDR x8, [x8, #0x748]       | X8 = 1152921510043335216;               
            // 0x00BB9A00: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB9A04: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::HasExistAni_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB9A08: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12 = null;
            // 0x00BB9A0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB9A10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9A14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9A18: MOV x2, x22                | X2 = 1152921510043335216 (0x10000001440A3A30);//ML01
            // 0x00BB9A1C: MOV x28, x23               | X28 = 57965472 (0x3747BA0);//ML01       
            // 0x00BB9A20: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9A24: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::HasExistAni_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::HasExistAni_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB9A28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9A2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9A30: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835736
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3 = val_12;
            // 0x00BB9A34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9A38: MOV x23, x28               | X23 = 57965472 (0x3747BA0);//ML01       
            val_61 = val_61;
            // 0x00BB9A3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9A40: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_29:
            // 0x00BB9A44: CBNZ x19, #0xbb9a4c        | if (X1 != 0) goto label_30;             
            if(X1 != 0)
            {
                goto label_30;
            }
            // 0x00BB9A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::HasExistAni_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_30:
            // 0x00BB9A4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9A50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB9A54: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x00BB9A58: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9A5C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_11, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3);
            X1.RegisterCLRMethodRedirection(mi:  val_11, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache3);
            // 0x00BB9A60: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB9A64: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9A68: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB9A6C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BB9A70: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9A74: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB9A78: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB9A7C: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x00BB9A80: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9A84: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB9A88: TBZ w9, #0, #0xbb9a9c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x00BB9A8C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB9A90: CBNZ w9, #0xbb9a9c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x00BB9A94: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB9A98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_32:
            // 0x00BB9A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9AA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9AA4: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BB9AA8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9AAC: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00BB9AB0: CBNZ x21, #0xbb9ab8        | if ( != null) goto label_33;            
            if(null != null)
            {
                goto label_33;
            }
            // 0x00BB9AB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_33:
            // 0x00BB9AB8: CBZ x22, #0xbb9adc         | if (val_13 == null) goto label_35;      
            if(val_13 == null)
            {
                goto label_35;
            }
            // 0x00BB9ABC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9AC0: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x00BB9AC4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9AC8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x00BB9ACC: CBNZ x0, #0xbb9adc         | if (val_13 != null) goto label_35;      
            if(val_13 != null)
            {
                goto label_35;
            }
            // 0x00BB9AD0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x00BB9AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9AD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_35:
            // 0x00BB9ADC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9AE0: CBNZ w8, #0xbb9af0         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_36;
            // 0x00BB9AE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x00BB9AE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9AEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_36:
            // 0x00BB9AF0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;
            // 0x00BB9AF4: LDR x1, [x23]              | X1 = typeof(System.Single);             
            // 0x00BB9AF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9AFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9B00: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9B04: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00BB9B08: CBZ x22, #0xbb9b2c         | if (val_14 == null) goto label_38;      
            if(val_14 == null)
            {
                goto label_38;
            }
            // 0x00BB9B0C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9B10: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x00BB9B14: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9B18: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x00BB9B1C: CBNZ x0, #0xbb9b2c         | if (val_14 != null) goto label_38;      
            if(val_14 != null)
            {
                goto label_38;
            }
            // 0x00BB9B20: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x00BB9B24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9B28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_38:
            // 0x00BB9B2C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9B30: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BB9B34: B.HI #0xbb9b44             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_39;
            // 0x00BB9B38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x00BB9B3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9B40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_39:
            // 0x00BB9B44: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_14;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_14;
            // 0x00BB9B48: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BB9B4C: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x00BB9B50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9B54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9B58: LDR x1, [x8]               | X1 = typeof(System.Boolean);            
            // 0x00BB9B5C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9B60: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x00BB9B64: CBZ x22, #0xbb9b88         | if (val_15 == null) goto label_41;      
            if(val_15 == null)
            {
                goto label_41;
            }
            // 0x00BB9B68: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9B6C: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x00BB9B70: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9B74: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x00BB9B78: CBNZ x0, #0xbb9b88         | if (val_15 != null) goto label_41;      
            if(val_15 != null)
            {
                goto label_41;
            }
            // 0x00BB9B7C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x00BB9B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9B84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_41:
            // 0x00BB9B88: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9B8C: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BB9B90: B.HI #0xbb9ba0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_42;
            // 0x00BB9B94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x00BB9B98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9B9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_42:
            // 0x00BB9BA0: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_15;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_15;
            // 0x00BB9BA4: CBNZ x20, #0xbb9bac        | if (val_1 != null) goto label_43;       
            if(val_1 != null)
            {
                goto label_43;
            }
            // 0x00BB9BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_43:
            // 0x00BB9BAC: ADRP x28, #0x3653000       | X28 = 56963072 (0x3653000);             
            // 0x00BB9BB0: LDR x28, [x28, #0x930]     | X28 = (string**)(1152921510030013552)("Play");
            // 0x00BB9BB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9BB8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB9BBC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB9BC0: LDR x1, [x28]              | X1 = "Play";                            
            // 0x00BB9BC4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB9BC8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9BCC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB9BD0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_16 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB9BD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9BD8: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x00BB9BDC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9BE0: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4;
            // 0x00BB9BE4: CBNZ x22, #0xbb9c48        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4 != null) goto label_44;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4) != null)
            {
                goto label_44;
            }
            // 0x00BB9BE8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00BB9BEC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB9BF0: LDR x8, [x8, #0x360]       | X8 = 1152921510043352624;               
            // 0x00BB9BF4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB9BF8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB9BFC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_17 = null;
            // 0x00BB9C00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB9C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9C08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9C0C: MOV x2, x22                | X2 = 1152921510043352624 (0x10000001440A7E30);//ML01
            // 0x00BB9C10: MOV x27, x25               | X27 = 57978136 (0x374AD18);//ML01       
            // 0x00BB9C14: MOV x25, x26               | X25 = 57977376 (0x374AA20);//ML01       
            // 0x00BB9C18: MOV x26, x23               | X26 = 57965472 (0x3747BA0);//ML01       
            // 0x00BB9C1C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9C20: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB9C24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9C28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9C2C: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835744
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4 = val_17;
            // 0x00BB9C30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9C34: MOV x23, x26               | X23 = 57965472 (0x3747BA0);//ML01       
            val_61 = val_61;
            // 0x00BB9C38: MOV x26, x25               | X26 = 57977376 (0x374AA20);//ML01       
            val_59 = val_59;
            // 0x00BB9C3C: MOV x25, x27               | X25 = 57978136 (0x374AD18);//ML01       
            val_60 = val_60;
            // 0x00BB9C40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9C44: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_44:
            // 0x00BB9C48: CBNZ x19, #0xbb9c50        | if (X1 != 0) goto label_45;             
            if(X1 != 0)
            {
                goto label_45;
            }
            // 0x00BB9C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_45:
            // 0x00BB9C50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9C54: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB9C58: MOV x1, x21                | X1 = val_16;//m1                        
            // 0x00BB9C5C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9C60: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_16, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4);
            X1.RegisterCLRMethodRedirection(mi:  val_16, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache4);
            // 0x00BB9C64: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB9C68: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9C6C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB9C70: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BB9C74: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9C78: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB9C7C: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x00BB9C80: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB9C84: LDR x9, [x9, #0xcb8]       | X9 = 1152921504608604160;               
            // 0x00BB9C88: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9C8C: LDR x22, [x9]              | X22 = typeof(System.Boolean);           
            // 0x00BB9C90: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB9C94: TBZ w9, #0, #0xbb9ca8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x00BB9C98: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB9C9C: CBNZ w9, #0xbb9ca8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x00BB9CA0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB9CA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_47:
            // 0x00BB9CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9CB0: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x00BB9CB4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_18 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9CB8: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x00BB9CBC: CBNZ x21, #0xbb9cc4        | if ( != null) goto label_48;            
            if(null != null)
            {
                goto label_48;
            }
            // 0x00BB9CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_48:
            // 0x00BB9CC4: CBZ x22, #0xbb9ce8         | if (val_18 == null) goto label_50;      
            if(val_18 == null)
            {
                goto label_50;
            }
            // 0x00BB9CC8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9CCC: MOV x0, x22                | X0 = val_18;//m1                        
            // 0x00BB9CD0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9CD4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_18, ????);     
            // 0x00BB9CD8: CBNZ x0, #0xbb9ce8         | if (val_18 != null) goto label_50;      
            if(val_18 != null)
            {
                goto label_50;
            }
            // 0x00BB9CDC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_18, ????);     
            // 0x00BB9CE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9CE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_50:
            // 0x00BB9CE8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9CEC: CBNZ w8, #0xbb9cfc         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_51;
            // 0x00BB9CF0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x00BB9CF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9CF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_51:
            // 0x00BB9CFC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;
            // 0x00BB9D00: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00BB9D04: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00BB9D08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9D0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9D10: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BB9D14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9D18: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x00BB9D1C: CBZ x22, #0xbb9d40         | if (val_19 == null) goto label_53;      
            if(val_19 == null)
            {
                goto label_53;
            }
            // 0x00BB9D20: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9D24: MOV x0, x22                | X0 = val_19;//m1                        
            // 0x00BB9D28: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9D2C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x00BB9D30: CBNZ x0, #0xbb9d40         | if (val_19 != null) goto label_53;      
            if(val_19 != null)
            {
                goto label_53;
            }
            // 0x00BB9D34: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x00BB9D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9D3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_53:
            // 0x00BB9D40: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9D44: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BB9D48: B.HI #0xbb9d58             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_54;
            // 0x00BB9D4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x00BB9D50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9D54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_54:
            // 0x00BB9D58: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_19;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_19;
            // 0x00BB9D5C: LDR x1, [x23]              | X1 = typeof(System.Single);             
            // 0x00BB9D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9D68: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_20 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9D6C: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x00BB9D70: CBZ x22, #0xbb9d94         | if (val_20 == null) goto label_56;      
            if(val_20 == null)
            {
                goto label_56;
            }
            // 0x00BB9D74: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9D78: MOV x0, x22                | X0 = val_20;//m1                        
            // 0x00BB9D7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9D80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
            // 0x00BB9D84: CBNZ x0, #0xbb9d94         | if (val_20 != null) goto label_56;      
            if(val_20 != null)
            {
                goto label_56;
            }
            // 0x00BB9D88: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
            // 0x00BB9D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9D90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_56:
            // 0x00BB9D94: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9D98: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BB9D9C: B.HI #0xbb9dac             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_57;
            // 0x00BB9DA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
            // 0x00BB9DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9DA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_57:
            // 0x00BB9DAC: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_20;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_20;
            // 0x00BB9DB0: CBNZ x20, #0xbb9db8        | if (val_1 != null) goto label_58;       
            if(val_1 != null)
            {
                goto label_58;
            }
            // 0x00BB9DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_58:
            // 0x00BB9DB8: LDR x1, [x28]              | X1 = "Play";                            
            // 0x00BB9DBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9DC0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB9DC4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB9DC8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB9DCC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9DD0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB9DD4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_21 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB9DD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9DDC: MOV x21, x0                | X21 = val_21;//m1                       
            // 0x00BB9DE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9DE4: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5;
            // 0x00BB9DE8: CBNZ x22, #0xbb9e4c        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5 != null) goto label_59;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5) != null)
            {
                goto label_59;
            }
            // 0x00BB9DEC: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00BB9DF0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB9DF4: LDR x8, [x8, #0xf20]       | X8 = 1152921510043370032;               
            // 0x00BB9DF8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB9DFC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB9E00: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_22 = null;
            // 0x00BB9E04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB9E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9E0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9E10: MOV x2, x22                | X2 = 1152921510043370032 (0x10000001440AC230);//ML01
            // 0x00BB9E14: MOV x27, x25               | X27 = 57978136 (0x374AD18);//ML01       
            // 0x00BB9E18: MOV x25, x26               | X25 = 57977376 (0x374AA20);//ML01       
            // 0x00BB9E1C: MOV x26, x23               | X26 = 57965472 (0x3747BA0);//ML01       
            // 0x00BB9E20: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9E24: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_22 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB9E28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9E2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9E30: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835752
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5 = val_22;
            // 0x00BB9E34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9E38: MOV x23, x26               | X23 = 57965472 (0x3747BA0);//ML01       
            val_61 = val_61;
            // 0x00BB9E3C: MOV x26, x25               | X26 = 57977376 (0x374AA20);//ML01       
            val_59 = val_59;
            // 0x00BB9E40: MOV x25, x27               | X25 = 57978136 (0x374AD18);//ML01       
            val_60 = val_60;
            // 0x00BB9E44: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9E48: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_59:
            // 0x00BB9E4C: CBNZ x19, #0xbb9e54        | if (X1 != 0) goto label_60;             
            if(X1 != 0)
            {
                goto label_60;
            }
            // 0x00BB9E50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_60:
            // 0x00BB9E54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9E58: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB9E5C: MOV x1, x21                | X1 = val_21;//m1                        
            // 0x00BB9E60: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB9E64: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_21, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5);
            X1.RegisterCLRMethodRedirection(mi:  val_21, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache5);
            // 0x00BB9E68: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB9E6C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9E70: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB9E74: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BB9E78: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9E7C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB9E80: ADRP x27, #0x3624000       | X27 = 56770560 (0x3624000);             
            // 0x00BB9E84: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB9E88: LDR x27, [x27, #0x1f0]     | X27 = 1152921504922341376;              
            val_62 = 1152921504922341376;
            // 0x00BB9E8C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9E90: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB9E94: LDR x22, [x27]             | X22 = typeof(AnimationRunner.AniType);  
            // 0x00BB9E98: TBZ w9, #0, #0xbb9eac      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_62;
            // 0x00BB9E9C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB9EA0: CBNZ w9, #0xbb9eac         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
            // 0x00BB9EA4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB9EA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_62:
            // 0x00BB9EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9EB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9EB4: MOV x1, x22                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BB9EB8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_23 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9EBC: MOV x22, x0                | X22 = val_23;//m1                       
            // 0x00BB9EC0: CBNZ x21, #0xbb9ec8        | if ( != null) goto label_63;            
            if(null != null)
            {
                goto label_63;
            }
            // 0x00BB9EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_63:
            // 0x00BB9EC8: CBZ x22, #0xbb9eec         | if (val_23 == null) goto label_65;      
            if(val_23 == null)
            {
                goto label_65;
            }
            // 0x00BB9ECC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9ED0: MOV x0, x22                | X0 = val_23;//m1                        
            // 0x00BB9ED4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9ED8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_23, ????);     
            // 0x00BB9EDC: CBNZ x0, #0xbb9eec         | if (val_23 != null) goto label_65;      
            if(val_23 != null)
            {
                goto label_65;
            }
            // 0x00BB9EE0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_23, ????);     
            // 0x00BB9EE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9EE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_65:
            // 0x00BB9EEC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9EF0: CBNZ w8, #0xbb9f00         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_66;
            // 0x00BB9EF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00BB9EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9EFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_66:
            // 0x00BB9F00: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_23;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_23;
            // 0x00BB9F04: LDR x1, [x23]              | X1 = typeof(System.Single);             
            // 0x00BB9F08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9F0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9F10: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_24 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9F14: MOV x22, x0                | X22 = val_24;//m1                       
            // 0x00BB9F18: CBZ x22, #0xbb9f3c         | if (val_24 == null) goto label_68;      
            if(val_24 == null)
            {
                goto label_68;
            }
            // 0x00BB9F1C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9F20: MOV x0, x22                | X0 = val_24;//m1                        
            // 0x00BB9F24: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9F28: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_24, ????);     
            // 0x00BB9F2C: CBNZ x0, #0xbb9f3c         | if (val_24 != null) goto label_68;      
            if(val_24 != null)
            {
                goto label_68;
            }
            // 0x00BB9F30: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_24, ????);     
            // 0x00BB9F34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9F38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            label_68:
            // 0x00BB9F3C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9F40: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BB9F44: B.HI #0xbb9f54             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_69;
            // 0x00BB9F48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_24, ????);     
            // 0x00BB9F4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9F50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            label_69:
            // 0x00BB9F54: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_24;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_24;
            // 0x00BB9F58: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BB9F5C: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x00BB9F60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9F64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB9F68: LDR x1, [x8]               | X1 = typeof(System.Boolean);            
            // 0x00BB9F6C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_25 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB9F70: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x00BB9F74: CBZ x22, #0xbb9f98         | if (val_25 == null) goto label_71;      
            if(val_25 == null)
            {
                goto label_71;
            }
            // 0x00BB9F78: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9F7C: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x00BB9F80: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9F84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x00BB9F88: CBNZ x0, #0xbb9f98         | if (val_25 != null) goto label_71;      
            if(val_25 != null)
            {
                goto label_71;
            }
            // 0x00BB9F8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_25, ????);     
            // 0x00BB9F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9F94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_71:
            // 0x00BB9F98: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB9F9C: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BB9FA0: B.HI #0xbb9fb0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_72;
            // 0x00BB9FA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_25, ????);     
            // 0x00BB9FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9FAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            label_72:
            // 0x00BB9FB0: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_25;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_25;
            // 0x00BB9FB4: CBNZ x20, #0xbb9fbc        | if (val_1 != null) goto label_73;       
            if(val_1 != null)
            {
                goto label_73;
            }
            // 0x00BB9FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_73:
            // 0x00BB9FBC: LDR x1, [x28]              | X1 = "Play";                            
            // 0x00BB9FC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB9FC4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB9FC8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB9FCC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB9FD0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB9FD4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB9FD8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_26 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB9FDC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BB9FE0: MOV x21, x0                | X21 = val_26;//m1                       
            // 0x00BB9FE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB9FE8: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6;
            // 0x00BB9FEC: CBNZ x22, #0xbba058        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6 != null) goto label_74;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6) != null)
            {
                goto label_74;
            }
            // 0x00BB9FF0: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00BB9FF4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB9FF8: LDR x8, [x8, #0x4e0]       | X8 = 1152921510043387440;               
            // 0x00BB9FFC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA000: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA004: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27 = null;
            // 0x00BBA008: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA00C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA010: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA014: MOV x2, x22                | X2 = 1152921510043387440 (0x10000001440B0630);//ML01
            // 0x00BBA018: MOV x28, x27               | X28 = 57967200 (0x3748260);//ML01       
            // 0x00BBA01C: MOV x27, x25               | X27 = 57978136 (0x374AD18);//ML01       
            // 0x00BBA020: MOV x25, x26               | X25 = 57977376 (0x374AA20);//ML01       
            // 0x00BBA024: MOV x26, x23               | X26 = 57965472 (0x3747BA0);//ML01       
            // 0x00BBA028: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA02C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA030: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA034: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA038: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835760
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6 = val_27;
            // 0x00BBA03C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA040: MOV x23, x26               | X23 = 57965472 (0x3747BA0);//ML01       
            val_61 = val_61;
            // 0x00BBA044: MOV x26, x25               | X26 = 57977376 (0x374AA20);//ML01       
            val_59 = val_59;
            // 0x00BBA048: MOV x25, x27               | X25 = 57978136 (0x374AD18);//ML01       
            val_60 = val_60;
            // 0x00BBA04C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA050: MOV x27, x28               | X27 = 57967200 (0x3748260);//ML01       
            val_62 = val_62;
            // 0x00BBA054: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_74:
            // 0x00BBA058: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00BBA05C: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            val_63 = 1152921504608284672;
            // 0x00BBA060: CBNZ x19, #0xbba068        | if (X1 != 0) goto label_75;             
            if(X1 != 0)
            {
                goto label_75;
            }
            // 0x00BBA064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_75:
            // 0x00BBA068: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA06C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA070: MOV x1, x21                | X1 = val_26;//m1                        
            // 0x00BBA074: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA078: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_26, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6);
            X1.RegisterCLRMethodRedirection(mi:  val_26, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache6);
            // 0x00BBA07C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA080: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA084: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA088: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BBA08C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA090: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA094: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BBA098: LDR x22, [x27]             | X22 = typeof(AnimationRunner.AniType);  
            // 0x00BBA09C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA0A0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBA0A4: TBZ w9, #0, #0xbba0b8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_77;
            // 0x00BBA0A8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBA0AC: CBNZ w9, #0xbba0b8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_77;
            // 0x00BBA0B0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBA0B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_77:
            // 0x00BBA0B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA0BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA0C0: MOV x1, x22                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBA0C4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA0C8: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x00BBA0CC: CBNZ x21, #0xbba0d4        | if ( != null) goto label_78;            
            if(null != null)
            {
                goto label_78;
            }
            // 0x00BBA0D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_78:
            // 0x00BBA0D4: CBZ x22, #0xbba0f8         | if (val_28 == null) goto label_80;      
            if(val_28 == null)
            {
                goto label_80;
            }
            // 0x00BBA0D8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA0DC: MOV x0, x22                | X0 = val_28;//m1                        
            // 0x00BBA0E0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA0E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x00BBA0E8: CBNZ x0, #0xbba0f8         | if (val_28 != null) goto label_80;      
            if(val_28 != null)
            {
                goto label_80;
            }
            // 0x00BBA0EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x00BBA0F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA0F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_80:
            // 0x00BBA0F8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA0FC: CBNZ w8, #0xbba10c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_81;
            // 0x00BBA100: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x00BBA104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA108: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_81:
            // 0x00BBA10C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_28;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_28;
            // 0x00BBA110: CBNZ x20, #0xbba118        | if (val_1 != null) goto label_82;       
            if(val_1 != null)
            {
                goto label_82;
            }
            // 0x00BBA114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_82:
            // 0x00BBA118: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00BBA11C: LDR x8, [x8, #0x1d0]       | X8 = (string**)(1152921510043392560)("IsPlay");
            // 0x00BBA120: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA124: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA128: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA12C: LDR x1, [x8]               | X1 = "IsPlay";                          
            // 0x00BBA130: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA134: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA138: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA13C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "IsPlay", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_29 = val_1.GetMethod(name:  "IsPlay", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA140: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA144: MOV x21, x0                | X21 = val_29;//m1                       
            // 0x00BBA148: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA14C: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7;
            // 0x00BBA150: CBNZ x22, #0xbba1c4        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7 != null) goto label_83;
            if((ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7) != null)
            {
                goto label_83;
            }
            // 0x00BBA154: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BBA158: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA15C: LDR x8, [x8, #0xae0]       | X8 = 1152921510043396736;               
            // 0x00BBA160: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA164: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::IsPlay_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA168: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_30 = null;
            // 0x00BBA16C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA174: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA178: MOV x2, x22                | X2 = 1152921510043396736 (0x10000001440B2A80);//ML01
            // 0x00BBA17C: MOV x28, x27               | X28 = 57967200 (0x3748260);//ML01       
            // 0x00BBA180: MOV x27, x25               | X27 = 57978136 (0x374AD18);//ML01       
            // 0x00BBA184: MOV x25, x26               | X25 = 57977376 (0x374AA20);//ML01       
            // 0x00BBA188: MOV x26, x23               | X26 = 57965472 (0x3747BA0);//ML01       
            // 0x00BBA18C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA190: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::IsPlay_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_30 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::IsPlay_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA194: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA198: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA19C: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835768
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7 = val_30;
            // 0x00BBA1A0: MOV x23, x26               | X23 = 57965472 (0x3747BA0);//ML01       
            val_61 = val_61;
            // 0x00BBA1A4: MOV x26, x25               | X26 = 57977376 (0x374AA20);//ML01       
            val_59 = val_59;
            // 0x00BBA1A8: MOV x25, x27               | X25 = 57978136 (0x374AD18);//ML01       
            val_60 = val_60;
            // 0x00BBA1AC: MOV x27, x28               | X27 = 57967200 (0x3748260);//ML01       
            val_62 = val_62;
            // 0x00BBA1B0: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00BBA1B4: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            val_63 = 1152921504608284672;
            // 0x00BBA1B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA1BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA1C0: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_83:
            // 0x00BBA1C4: CBNZ x19, #0xbba1cc        | if (X1 != 0) goto label_84;             
            if(X1 != 0)
            {
                goto label_84;
            }
            // 0x00BBA1C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::IsPlay_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_84:
            // 0x00BBA1CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA1D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA1D4: MOV x1, x21                | X1 = val_29;//m1                        
            // 0x00BBA1D8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA1DC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_29, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7);
            X1.RegisterCLRMethodRedirection(mi:  val_29, func:  ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache7);
            // 0x00BBA1E0: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA1E4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA1E8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA1EC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BBA1F0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA1F4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA1F8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BBA1FC: LDR x22, [x28]             | X22 = typeof(System.String);            
            // 0x00BBA200: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA204: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBA208: TBZ w9, #0, #0xbba21c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_86;
            // 0x00BBA20C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBA210: CBNZ w9, #0xbba21c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
            // 0x00BBA214: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBA218: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_86:
            // 0x00BBA21C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA220: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA224: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBA228: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_31 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA22C: MOV x22, x0                | X22 = val_31;//m1                       
            // 0x00BBA230: CBNZ x21, #0xbba238        | if ( != null) goto label_87;            
            if(null != null)
            {
                goto label_87;
            }
            // 0x00BBA234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_87:
            // 0x00BBA238: CBZ x22, #0xbba25c         | if (val_31 == null) goto label_89;      
            if(val_31 == null)
            {
                goto label_89;
            }
            // 0x00BBA23C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA240: MOV x0, x22                | X0 = val_31;//m1                        
            // 0x00BBA244: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA248: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_31, ????);     
            // 0x00BBA24C: CBNZ x0, #0xbba25c         | if (val_31 != null) goto label_89;      
            if(val_31 != null)
            {
                goto label_89;
            }
            // 0x00BBA250: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_31, ????);     
            // 0x00BBA254: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA258: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            label_89:
            // 0x00BBA25C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA260: CBNZ w8, #0xbba270         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_90;
            // 0x00BBA264: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_31, ????);     
            // 0x00BBA268: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA26C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            label_90:
            // 0x00BBA270: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_31;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_31;
            // 0x00BBA274: LDR x1, [x23]              | X1 = typeof(System.Single);             
            // 0x00BBA278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA27C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA280: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_32 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA284: MOV x22, x0                | X22 = val_32;//m1                       
            // 0x00BBA288: CBZ x22, #0xbba2ac         | if (val_32 == null) goto label_92;      
            if(val_32 == null)
            {
                goto label_92;
            }
            // 0x00BBA28C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA290: MOV x0, x22                | X0 = val_32;//m1                        
            // 0x00BBA294: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA298: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_32, ????);     
            // 0x00BBA29C: CBNZ x0, #0xbba2ac         | if (val_32 != null) goto label_92;      
            if(val_32 != null)
            {
                goto label_92;
            }
            // 0x00BBA2A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_32, ????);     
            // 0x00BBA2A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA2A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_92:
            // 0x00BBA2AC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA2B0: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BBA2B4: B.HI #0xbba2c4             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_93;
            // 0x00BBA2B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_32, ????);     
            // 0x00BBA2BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA2C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_93:
            // 0x00BBA2C4: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_32;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_32;
            // 0x00BBA2C8: CBNZ x20, #0xbba2d0        | if (val_1 != null) goto label_94;       
            if(val_1 != null)
            {
                goto label_94;
            }
            // 0x00BBA2CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_94:
            // 0x00BBA2D0: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00BBA2D4: LDR x8, [x8, #0x470]       | X8 = (string**)(1152921510043405952)("SetActionTime");
            // 0x00BBA2D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA2DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA2E0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA2E4: LDR x1, [x8]               | X1 = "SetActionTime";                   
            // 0x00BBA2E8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA2EC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA2F0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA2F4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_33 = val_1.GetMethod(name:  "SetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA2F8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA2FC: MOV x21, x0                | X21 = val_33;//m1                       
            // 0x00BBA300: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA304: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache8;
            val_64 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache8;
            // 0x00BBA308: CBNZ x22, #0xbba354        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache8 != null) goto label_95;
            if(val_64 != null)
            {
                goto label_95;
            }
            // 0x00BBA30C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00BBA310: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA314: LDR x8, [x8, #0xb80]       | X8 = 1152921510043410144;               
            // 0x00BBA318: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA31C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetActionTime_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA320: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_34 = null;
            // 0x00BBA324: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA32C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA330: MOV x2, x22                | X2 = 1152921510043410144 (0x10000001440B5EE0);//ML01
            // 0x00BBA334: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_34;
            // 0x00BBA338: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetActionTime_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_34 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetActionTime_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA33C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA340: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA344: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835776
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache8 = val_61;
            // 0x00BBA348: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA34C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA350: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_64 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache8;
            label_95:
            // 0x00BBA354: CBNZ x19, #0xbba35c        | if (X1 != 0) goto label_96;             
            if(X1 != 0)
            {
                goto label_96;
            }
            // 0x00BBA358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetActionTime_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_96:
            // 0x00BBA35C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA360: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA364: MOV x1, x21                | X1 = val_33;//m1                        
            // 0x00BBA368: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA36C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_33, func:  val_64);
            X1.RegisterCLRMethodRedirection(mi:  val_33, func:  val_64);
            // 0x00BBA370: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA374: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA378: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA37C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BBA380: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA384: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA388: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBA38C: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BBA390: LDR x9, [x9, #0xdb0]       | X9 = 1152921504695451648;               
            // 0x00BBA394: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA398: LDR x22, [x9]              | X22 = typeof(UnityEngine.WrapMode);     
            // 0x00BBA39C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBA3A0: TBZ w9, #0, #0xbba3b4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_98;
            // 0x00BBA3A4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBA3A8: CBNZ w9, #0xbba3b4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_98;
            // 0x00BBA3AC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBA3B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_98:
            // 0x00BBA3B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA3B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA3BC: MOV x1, x22                | X1 = 1152921504695451648 (0x1000000005480000);//ML01
            // 0x00BBA3C0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_35 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA3C4: MOV x22, x0                | X22 = val_35;//m1                       
            // 0x00BBA3C8: CBNZ x21, #0xbba3d0        | if ( != null) goto label_99;            
            if(null != null)
            {
                goto label_99;
            }
            // 0x00BBA3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_99:
            // 0x00BBA3D0: CBZ x22, #0xbba3f4         | if (val_35 == null) goto label_101;     
            if(val_35 == null)
            {
                goto label_101;
            }
            // 0x00BBA3D4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA3D8: MOV x0, x22                | X0 = val_35;//m1                        
            // 0x00BBA3DC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA3E0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_35, ????);     
            // 0x00BBA3E4: CBNZ x0, #0xbba3f4         | if (val_35 != null) goto label_101;     
            if(val_35 != null)
            {
                goto label_101;
            }
            // 0x00BBA3E8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_35, ????);     
            // 0x00BBA3EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA3F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_101:
            // 0x00BBA3F4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA3F8: CBNZ w8, #0xbba408         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_102;
            // 0x00BBA3FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_35, ????);     
            // 0x00BBA400: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA404: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_102:
            // 0x00BBA408: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_35;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_35;
            // 0x00BBA40C: CBNZ x20, #0xbba414        | if (val_1 != null) goto label_103;      
            if(val_1 != null)
            {
                goto label_103;
            }
            // 0x00BBA410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_103:
            // 0x00BBA414: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00BBA418: LDR x8, [x8, #0xbf0]       | X8 = (string**)(1152921510043415264)("SetWrapModel");
            // 0x00BBA41C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA420: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA424: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA428: LDR x1, [x8]               | X1 = "SetWrapModel";                    
            // 0x00BBA42C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA430: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA434: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA438: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetWrapModel", bindingAttr:  30, binder:  0, types:  val_60, modifiers:  0);
            System.Reflection.MethodInfo val_36 = val_1.GetMethod(name:  "SetWrapModel", bindingAttr:  30, binder:  0, types:  val_60, modifiers:  0);
            // 0x00BBA43C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA440: MOV x21, x0                | X21 = val_36;//m1                       
            // 0x00BBA444: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA448: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache9;
            val_65 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache9;
            // 0x00BBA44C: CBNZ x22, #0xbba498        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache9 != null) goto label_104;
            if(val_65 != null)
            {
                goto label_104;
            }
            // 0x00BBA450: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x00BBA454: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA458: LDR x8, [x8, #0xf68]       | X8 = 1152921510043419456;               
            // 0x00BBA45C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA460: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetWrapModel_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA464: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_37 = null;
            // 0x00BBA468: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA46C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA470: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA474: MOV x2, x22                | X2 = 1152921510043419456 (0x10000001440B8340);//ML01
            // 0x00BBA478: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_37;
            // 0x00BBA47C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetWrapModel_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_37 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetWrapModel_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA480: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA484: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA488: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835784
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache9 = val_61;
            // 0x00BBA48C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA490: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA494: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_65 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache9;
            label_104:
            // 0x00BBA498: CBNZ x19, #0xbba4a0        | if (X1 != 0) goto label_105;            
            if(X1 != 0)
            {
                goto label_105;
            }
            // 0x00BBA49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::SetWrapModel_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_105:
            // 0x00BBA4A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA4A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA4A8: MOV x1, x21                | X1 = val_36;//m1                        
            // 0x00BBA4AC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA4B0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_36, func:  val_65);
            X1.RegisterCLRMethodRedirection(mi:  val_36, func:  val_65);
            // 0x00BBA4B4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA4B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA4BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA4C0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BBA4C4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA4C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA4CC: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BBA4D0: LDR x22, [x27]             | X22 = typeof(AnimationRunner.AniType);  
            // 0x00BBA4D4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA4D8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBA4DC: TBZ w9, #0, #0xbba4f0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_107;
            // 0x00BBA4E0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBA4E4: CBNZ w9, #0xbba4f0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_107;
            // 0x00BBA4E8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBA4EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_107:
            // 0x00BBA4F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA4F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA4F8: MOV x1, x22                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBA4FC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_38 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA500: MOV x22, x0                | X22 = val_38;//m1                       
            // 0x00BBA504: CBNZ x21, #0xbba50c        | if ( != null) goto label_108;           
            if(null != null)
            {
                goto label_108;
            }
            // 0x00BBA508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_108:
            // 0x00BBA50C: CBZ x22, #0xbba530         | if (val_38 == null) goto label_110;     
            if(val_38 == null)
            {
                goto label_110;
            }
            // 0x00BBA510: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA514: MOV x0, x22                | X0 = val_38;//m1                        
            // 0x00BBA518: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA51C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_38, ????);     
            // 0x00BBA520: CBNZ x0, #0xbba530         | if (val_38 != null) goto label_110;     
            if(val_38 != null)
            {
                goto label_110;
            }
            // 0x00BBA524: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_38, ????);     
            // 0x00BBA528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA52C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            label_110:
            // 0x00BBA530: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA534: CBNZ w8, #0xbba544         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_111;
            // 0x00BBA538: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_38, ????);     
            // 0x00BBA53C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA540: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            label_111:
            // 0x00BBA544: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_38;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_38;
            // 0x00BBA548: CBNZ x20, #0xbba550        | if (val_1 != null) goto label_112;      
            if(val_1 != null)
            {
                goto label_112;
            }
            // 0x00BBA54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_112:
            // 0x00BBA550: ADRP x27, #0x3675000       | X27 = 57102336 (0x3675000);             
            // 0x00BBA554: LDR x27, [x27, #0xc58]     | X27 = (string**)(1152921510043424576)("GetActionTime");
            // 0x00BBA558: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA55C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA560: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA564: LDR x1, [x27]              | X1 = "GetActionTime";                   
            // 0x00BBA568: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA56C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA570: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA574: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_39 = val_1.GetMethod(name:  "GetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA578: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA57C: MOV x21, x0                | X21 = val_39;//m1                       
            // 0x00BBA580: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA584: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheA;
            val_66 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheA;
            // 0x00BBA588: CBNZ x22, #0xbba5d4        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheA != null) goto label_113;
            if(val_66 != null)
            {
                goto label_113;
            }
            // 0x00BBA58C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00BBA590: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA594: LDR x8, [x8, #0xd58]       | X8 = 1152921510043428768;               
            // 0x00BBA598: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA59C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA5A0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_40 = null;
            // 0x00BBA5A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA5A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA5AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA5B0: MOV x2, x22                | X2 = 1152921510043428768 (0x10000001440BA7A0);//ML01
            // 0x00BBA5B4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_40;
            // 0x00BBA5B8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_40 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA5BC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA5C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA5C4: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835792
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheA = val_61;
            // 0x00BBA5C8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA5CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA5D0: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_66 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheA;
            label_113:
            // 0x00BBA5D4: CBNZ x19, #0xbba5dc        | if (X1 != 0) goto label_114;            
            if(X1 != 0)
            {
                goto label_114;
            }
            // 0x00BBA5D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_114:
            // 0x00BBA5DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA5E0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA5E4: MOV x1, x21                | X1 = val_39;//m1                        
            // 0x00BBA5E8: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA5EC: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_39, func:  val_66);
            X1.RegisterCLRMethodRedirection(mi:  val_39, func:  val_66);
            // 0x00BBA5F0: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA5F4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA5F8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA5FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA600: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA604: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA608: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA60C: CBNZ x20, #0xbba614        | if (val_1 != null) goto label_115;      
            if(val_1 != null)
            {
                goto label_115;
            }
            // 0x00BBA610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_115:
            // 0x00BBA614: LDR x1, [x27]              | X1 = "GetActionTime";                   
            // 0x00BBA618: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA61C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA620: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA624: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA628: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA62C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA630: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_41 = val_1.GetMethod(name:  "GetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA634: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA638: MOV x21, x0                | X21 = val_41;//m1                       
            // 0x00BBA63C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA640: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheB;
            val_67 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheB;
            // 0x00BBA644: CBNZ x22, #0xbba690        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheB != null) goto label_116;
            if(val_67 != null)
            {
                goto label_116;
            }
            // 0x00BBA648: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x00BBA64C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA650: LDR x8, [x8, #0xd80]       | X8 = 1152921510043433888;               
            // 0x00BBA654: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA658: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA65C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_42 = null;
            // 0x00BBA660: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA668: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA66C: MOV x2, x22                | X2 = 1152921510043433888 (0x10000001440BBBA0);//ML01
            // 0x00BBA670: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_42;
            // 0x00BBA674: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_42 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA678: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA67C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA680: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835800
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheB = val_61;
            // 0x00BBA684: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA688: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA68C: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_67 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheB;
            label_116:
            // 0x00BBA690: CBNZ x19, #0xbba698        | if (X1 != 0) goto label_117;            
            if(X1 != 0)
            {
                goto label_117;
            }
            // 0x00BBA694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_117:
            // 0x00BBA698: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA69C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA6A0: MOV x1, x21                | X1 = val_41;//m1                        
            // 0x00BBA6A4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA6A8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_41, func:  val_67);
            X1.RegisterCLRMethodRedirection(mi:  val_41, func:  val_67);
            // 0x00BBA6AC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA6B0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA6B4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA6B8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BBA6BC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA6C0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA6C4: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BBA6C8: LDR x22, [x28]             | X22 = typeof(System.String);            
            // 0x00BBA6CC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA6D0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBA6D4: TBZ w9, #0, #0xbba6e8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_119;
            // 0x00BBA6D8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBA6DC: CBNZ w9, #0xbba6e8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_119;
            // 0x00BBA6E0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBA6E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_119:
            // 0x00BBA6E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA6EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA6F0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBA6F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_43 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA6F8: MOV x22, x0                | X22 = val_43;//m1                       
            // 0x00BBA6FC: CBNZ x21, #0xbba704        | if ( != null) goto label_120;           
            if(null != null)
            {
                goto label_120;
            }
            // 0x00BBA700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
            label_120:
            // 0x00BBA704: CBZ x22, #0xbba728         | if (val_43 == null) goto label_122;     
            if(val_43 == null)
            {
                goto label_122;
            }
            // 0x00BBA708: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA70C: MOV x0, x22                | X0 = val_43;//m1                        
            // 0x00BBA710: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA714: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_43, ????);     
            // 0x00BBA718: CBNZ x0, #0xbba728         | if (val_43 != null) goto label_122;     
            if(val_43 != null)
            {
                goto label_122;
            }
            // 0x00BBA71C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_43, ????);     
            // 0x00BBA720: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA724: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            label_122:
            // 0x00BBA728: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA72C: CBNZ w8, #0xbba73c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_123;
            // 0x00BBA730: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_43, ????);     
            // 0x00BBA734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA738: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_43, ????);     
            label_123:
            // 0x00BBA73C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_43;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_43;
            // 0x00BBA740: CBNZ x20, #0xbba748        | if (val_1 != null) goto label_124;      
            if(val_1 != null)
            {
                goto label_124;
            }
            // 0x00BBA744: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
            label_124:
            // 0x00BBA748: LDR x1, [x27]              | X1 = "GetActionTime";                   
            // 0x00BBA74C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA750: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA754: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA758: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA75C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA760: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA764: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_44 = val_1.GetMethod(name:  "GetActionTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA768: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA76C: MOV x21, x0                | X21 = val_44;//m1                       
            // 0x00BBA770: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA774: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheC;
            val_68 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheC;
            // 0x00BBA778: CBNZ x22, #0xbba7c4        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheC != null) goto label_125;
            if(val_68 != null)
            {
                goto label_125;
            }
            // 0x00BBA77C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00BBA780: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA784: LDR x8, [x8, #0xdd8]       | X8 = 1152921510043443104;               
            // 0x00BBA788: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA78C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA790: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45 = null;
            // 0x00BBA794: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA79C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA7A0: MOV x2, x22                | X2 = 1152921510043443104 (0x10000001440BDFA0);//ML01
            // 0x00BBA7A4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_45;
            // 0x00BBA7A8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_45 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA7AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA7B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA7B4: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835808
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheC = val_61;
            // 0x00BBA7B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA7BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA7C0: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_68 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheC;
            label_125:
            // 0x00BBA7C4: ADRP x28, #0x3624000       | X28 = 56770560 (0x3624000);             
            // 0x00BBA7C8: LDR x28, [x28, #0x1f0]     | X28 = 1152921504922341376;              
            // 0x00BBA7CC: CBNZ x19, #0xbba7d4        | if (X1 != 0) goto label_126;            
            if(X1 != 0)
            {
                goto label_126;
            }
            // 0x00BBA7D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionTime_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_126:
            // 0x00BBA7D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA7D8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA7DC: MOV x1, x21                | X1 = val_44;//m1                        
            // 0x00BBA7E0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA7E4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_44, func:  val_68);
            X1.RegisterCLRMethodRedirection(mi:  val_44, func:  val_68);
            // 0x00BBA7E8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA7EC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA7F0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA7F4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BBA7F8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA7FC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA800: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BBA804: LDR x22, [x28]             | X22 = typeof(AnimationRunner.AniType);  
            // 0x00BBA808: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA80C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBA810: TBZ w9, #0, #0xbba824      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_128;
            // 0x00BBA814: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBA818: CBNZ w9, #0xbba824         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_128;
            // 0x00BBA81C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBA820: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_128:
            // 0x00BBA824: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBA828: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBA82C: MOV x1, x22                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBA830: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_46 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBA834: MOV x22, x0                | X22 = val_46;//m1                       
            // 0x00BBA838: CBNZ x21, #0xbba840        | if ( != null) goto label_129;           
            if(null != null)
            {
                goto label_129;
            }
            // 0x00BBA83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_129:
            // 0x00BBA840: CBZ x22, #0xbba864         | if (val_46 == null) goto label_131;     
            if(val_46 == null)
            {
                goto label_131;
            }
            // 0x00BBA844: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBA848: MOV x0, x22                | X0 = val_46;//m1                        
            // 0x00BBA84C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBA850: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_46, ????);     
            // 0x00BBA854: CBNZ x0, #0xbba864         | if (val_46 != null) goto label_131;     
            if(val_46 != null)
            {
                goto label_131;
            }
            // 0x00BBA858: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_46, ????);     
            // 0x00BBA85C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA860: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_46, ????);     
            label_131:
            // 0x00BBA864: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BBA868: CBNZ w8, #0xbba878         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_132;
            // 0x00BBA86C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_46, ????);     
            // 0x00BBA870: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA874: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_46, ????);     
            label_132:
            // 0x00BBA878: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_46;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_46;
            // 0x00BBA87C: CBNZ x20, #0xbba884        | if (val_1 != null) goto label_133;      
            if(val_1 != null)
            {
                goto label_133;
            }
            // 0x00BBA880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_133:
            // 0x00BBA884: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00BBA888: LDR x8, [x8, #0xbe0]       | X8 = (string**)(1152921510043448224)("GetActionNormalizedTime");
            // 0x00BBA88C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA890: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA894: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA898: LDR x1, [x8]               | X1 = "GetActionNormalizedTime";         
            // 0x00BBA89C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA8A0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA8A4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA8A8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetActionNormalizedTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_47 = val_1.GetMethod(name:  "GetActionNormalizedTime", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA8AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA8B0: MOV x21, x0                | X21 = val_47;//m1                       
            // 0x00BBA8B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA8B8: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheD;
            val_69 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheD;
            // 0x00BBA8BC: CBNZ x22, #0xbba908        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheD != null) goto label_134;
            if(val_69 != null)
            {
                goto label_134;
            }
            // 0x00BBA8C0: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x00BBA8C4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA8C8: LDR x8, [x8, #0x5f8]       | X8 = 1152921510043452448;               
            // 0x00BBA8CC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA8D0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionNormalizedTime_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA8D4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_48 = null;
            // 0x00BBA8D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA8DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA8E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA8E4: MOV x2, x22                | X2 = 1152921510043452448 (0x10000001440C0420);//ML01
            // 0x00BBA8E8: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_48;
            // 0x00BBA8EC: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionNormalizedTime_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_48 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionNormalizedTime_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA8F0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA8F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA8F8: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835816
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheD = val_61;
            // 0x00BBA8FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA900: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA904: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_69 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheD;
            label_134:
            // 0x00BBA908: CBNZ x19, #0xbba910        | if (X1 != 0) goto label_135;            
            if(X1 != 0)
            {
                goto label_135;
            }
            // 0x00BBA90C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::GetActionNormalizedTime_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_135:
            // 0x00BBA910: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA914: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA918: MOV x1, x21                | X1 = val_47;//m1                        
            // 0x00BBA91C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA920: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_47, func:  val_69);
            X1.RegisterCLRMethodRedirection(mi:  val_47, func:  val_69);
            // 0x00BBA924: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA928: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA92C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA934: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA938: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBA93C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA940: CBNZ x20, #0xbba948        | if (val_1 != null) goto label_136;      
            if(val_1 != null)
            {
                goto label_136;
            }
            // 0x00BBA944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_136:
            // 0x00BBA948: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BBA94C: LDR x8, [x8, #0xac0]       | X8 = (string**)(1152921510043453472)("playOver");
            // 0x00BBA950: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA954: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBA958: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBA95C: LDR x1, [x8]               | X1 = "playOver";                        
            // 0x00BBA960: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBA964: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA968: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBA96C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "playOver", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_49 = val_1.GetMethod(name:  "playOver", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBA970: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA974: MOV x21, x0                | X21 = val_49;//m1                       
            // 0x00BBA978: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA97C: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheE;
            val_70 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheE;
            // 0x00BBA980: CBNZ x22, #0xbba9cc        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheE != null) goto label_137;
            if(val_70 != null)
            {
                goto label_137;
            }
            // 0x00BBA984: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x00BBA988: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBA98C: LDR x8, [x8, #0xda0]       | X8 = 1152921510043457664;               
            // 0x00BBA990: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBA994: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::playOver_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBA998: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_50 = null;
            // 0x00BBA99C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBA9A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA9A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA9A8: MOV x2, x22                | X2 = 1152921510043457664 (0x10000001440C1880);//ML01
            // 0x00BBA9AC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_50;
            // 0x00BBA9B0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::playOver_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_50 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::playOver_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBA9B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA9B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA9BC: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835824
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheE = val_61;
            // 0x00BBA9C0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBA9C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBA9C8: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_70 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheE;
            label_137:
            // 0x00BBA9CC: CBNZ x19, #0xbba9d4        | if (X1 != 0) goto label_138;            
            if(X1 != 0)
            {
                goto label_138;
            }
            // 0x00BBA9D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::playOver_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_138:
            // 0x00BBA9D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBA9D8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBA9DC: MOV x1, x21                | X1 = val_49;//m1                        
            // 0x00BBA9E0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBA9E4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_49, func:  val_70);
            X1.RegisterCLRMethodRedirection(mi:  val_49, func:  val_70);
            // 0x00BBA9E8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BBA9EC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA9F0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BBA9F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBA9F8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBA9FC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BBAA00: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBAA04: CBNZ x20, #0xbbaa0c        | if (val_1 != null) goto label_139;      
            if(val_1 != null)
            {
                goto label_139;
            }
            // 0x00BBAA08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_139:
            // 0x00BBAA0C: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BBAA10: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921510043458688)("Clear");
            // 0x00BBAA14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAA18: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBAA1C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBAA20: LDR x1, [x8]               | X1 = "Clear";                           
            // 0x00BBAA24: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBAA28: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BBAA2C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BBAA30: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_51 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BBAA34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAA38: MOV x21, x0                | X21 = val_51;//m1                       
            // 0x00BBAA3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAA40: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheF;
            val_71 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheF;
            // 0x00BBAA44: CBNZ x22, #0xbbaa90        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheF != null) goto label_140;
            if(val_71 != null)
            {
                goto label_140;
            }
            // 0x00BBAA48: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x00BBAA4C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BBAA50: LDR x8, [x8, #0x40]        | X8 = 1152921510043462864;               
            // 0x00BBAA54: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BBAA58: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BBAA5C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_52 = null;
            // 0x00BBAA60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BBAA64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAA68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAA6C: MOV x2, x22                | X2 = 1152921510043462864 (0x10000001440C2CD0);//ML01
            // 0x00BBAA70: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_61 = val_52;
            // 0x00BBAA74: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_52 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BBAA78: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAA7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAA80: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782835832
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheF = val_61;
            // 0x00BBAA84: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAA88: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAA8C: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_71 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cacheF;
            label_140:
            // 0x00BBAA90: CBNZ x19, #0xbbaa98        | if (X1 != 0) goto label_141;            
            if(X1 != 0)
            {
                goto label_141;
            }
            // 0x00BBAA94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimationRunner_Binding::Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_141:
            // 0x00BBAA98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAA9C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBAAA0: MOV x1, x21                | X1 = val_51;//m1                        
            // 0x00BBAAA4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BBAAA8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_51, func:  val_71);
            X1.RegisterCLRMethodRedirection(mi:  val_51, func:  val_71);
            // 0x00BBAAAC: CBNZ x20, #0xbbaab4        | if (val_1 != null) goto label_142;      
            if(val_1 != null)
            {
                goto label_142;
            }
            // 0x00BBAAB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_142:
            // 0x00BBAAB4: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x00BBAAB8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBAABC: LDR x9, [x9, #0x910]       | X9 = (string**)(1152921510043463888)("curAniName");
            // 0x00BBAAC0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBAAC4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBAAC8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBAACC: LDR x1, [x9]               | X1 = "curAniName";                      
            // 0x00BBAAD0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBAAD4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBAAD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAADC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBAAE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAAE4: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache10;
            val_72 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache10;
            // 0x00BBAAE8: CBNZ x22, #0xbbab34        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache10 != null) goto label_143;
            if(val_72 != null)
            {
                goto label_143;
            }
            // 0x00BBAAEC: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00BBAAF0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBAAF4: LDR x8, [x8, #0x640]       | X8 = 1152921510043463984;               
            // 0x00BBAAF8: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBAAFC: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_curAniName_0(ref object o);
            // 0x00BBAB00: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_53 = null;
            // 0x00BBAB04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBAB08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAB0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAB10: MOV x2, x22                | X2 = 1152921510043463984 (0x10000001440C3130);//ML01
            // 0x00BBAB14: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_61 = val_53;
            // 0x00BBAB18: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_curAniName_0(ref object o));
            val_53 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_curAniName_0(ref object o));
            // 0x00BBAB1C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAB20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAB24: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782835840
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache10 = val_61;
            // 0x00BBAB28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAB2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAB30: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_72 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache10;
            label_143:
            // 0x00BBAB34: CBNZ x19, #0xbbab3c        | if (X1 != 0) goto label_144;            
            if(X1 != 0)
            {
                goto label_144;
            }
            // 0x00BBAB38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_curAniName_0(ref object o)), ????);
            label_144:
            // 0x00BBAB3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAB40: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBAB44: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBAB48: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBAB4C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_72);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_72);
            // 0x00BBAB50: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAB54: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAB58: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache11;
            val_73 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache11;
            // 0x00BBAB5C: CBNZ x22, #0xbbaba8        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache11 != null) goto label_145;
            if(val_73 != null)
            {
                goto label_145;
            }
            // 0x00BBAB60: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00BBAB64: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BBAB68: LDR x8, [x8, #0xd00]       | X8 = 1152921510043465008;               
            // 0x00BBAB6C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BBAB70: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_curAniName_0(ref object o, object v);
            // 0x00BBAB74: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_54 = null;
            // 0x00BBAB78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BBAB7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAB80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAB84: MOV x2, x22                | X2 = 1152921510043465008 (0x10000001440C3530);//ML01
            // 0x00BBAB88: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_61 = val_54;
            // 0x00BBAB8C: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_curAniName_0(ref object o, object v));
            val_54 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_curAniName_0(ref object o, object v));
            // 0x00BBAB90: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAB94: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAB98: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782835848
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache11 = val_61;
            // 0x00BBAB9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBABA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBABA4: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_73 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache11;
            label_145:
            // 0x00BBABA8: CBNZ x19, #0xbbabb0        | if (X1 != 0) goto label_146;            
            if(X1 != 0)
            {
                goto label_146;
            }
            // 0x00BBABAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_curAniName_0(ref object o, object v)), ????);
            label_146:
            // 0x00BBABB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBABB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBABB8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBABBC: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BBABC0: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_73);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_73);
            // 0x00BBABC4: CBNZ x20, #0xbbabcc        | if (val_1 != null) goto label_147;      
            if(val_1 != null)
            {
                goto label_147;
            }
            // 0x00BBABC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_147:
            // 0x00BBABCC: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
            // 0x00BBABD0: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBABD4: LDR x9, [x9, #0xdc8]       | X9 = (string**)(1152921510043466032)("unit");
            // 0x00BBABD8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBABDC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBABE0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBABE4: LDR x1, [x9]               | X1 = "unit";                            
            // 0x00BBABE8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBABEC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBABF0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBABF4: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBABF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBABFC: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache12;
            val_74 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache12;
            // 0x00BBAC00: CBNZ x22, #0xbbac4c        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache12 != null) goto label_148;
            if(val_74 != null)
            {
                goto label_148;
            }
            // 0x00BBAC04: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BBAC08: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBAC0C: LDR x8, [x8, #0x568]       | X8 = 1152921510043466112;               
            // 0x00BBAC10: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBAC14: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_unit_1(ref object o);
            // 0x00BBAC18: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_55 = null;
            // 0x00BBAC1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBAC20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAC24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAC28: MOV x2, x22                | X2 = 1152921510043466112 (0x10000001440C3980);//ML01
            // 0x00BBAC2C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_61 = val_55;
            // 0x00BBAC30: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_unit_1(ref object o));
            val_55 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_unit_1(ref object o));
            // 0x00BBAC34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAC38: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAC3C: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782835856
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache12 = val_61;
            // 0x00BBAC40: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAC44: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAC48: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_74 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache12;
            label_148:
            // 0x00BBAC4C: CBNZ x19, #0xbbac54        | if (X1 != 0) goto label_149;            
            if(X1 != 0)
            {
                goto label_149;
            }
            // 0x00BBAC50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_unit_1(ref object o)), ????);
            label_149:
            // 0x00BBAC54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAC58: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBAC5C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBAC60: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBAC64: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_74);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_74);
            // 0x00BBAC68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAC6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAC70: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache13;
            val_75 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache13;
            // 0x00BBAC74: CBNZ x22, #0xbbacc0        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache13 != null) goto label_150;
            if(val_75 != null)
            {
                goto label_150;
            }
            // 0x00BBAC78: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00BBAC7C: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BBAC80: LDR x8, [x8, #0xb50]       | X8 = 1152921510043467136;               
            // 0x00BBAC84: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BBAC88: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_unit_1(ref object o, object v);
            // 0x00BBAC8C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_56 = null;
            // 0x00BBAC90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BBAC94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAC98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAC9C: MOV x2, x22                | X2 = 1152921510043467136 (0x10000001440C3D80);//ML01
            // 0x00BBACA0: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_61 = val_56;
            // 0x00BBACA4: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_unit_1(ref object o, object v));
            val_56 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_unit_1(ref object o, object v));
            // 0x00BBACA8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBACAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBACB0: STR x23, [x8, #0x98]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782835864
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache13 = val_61;
            // 0x00BBACB4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBACB8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBACBC: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_75 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache13;
            label_150:
            // 0x00BBACC0: CBNZ x19, #0xbbacc8        | if (X1 != 0) goto label_151;            
            if(X1 != 0)
            {
                goto label_151;
            }
            // 0x00BBACC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_unit_1(ref object o, object v)), ????);
            label_151:
            // 0x00BBACC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBACCC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBACD0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBACD4: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BBACD8: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_75);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_75);
            // 0x00BBACDC: CBNZ x20, #0xbbace4        | if (val_1 != null) goto label_152;      
            if(val_1 != null)
            {
                goto label_152;
            }
            // 0x00BBACE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_152:
            // 0x00BBACE4: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BBACE8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBACEC: LDR x9, [x9, #0x368]       | X9 = (string**)(1152921510043468160)("isSkillFrozen");
            // 0x00BBACF0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBACF4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBACF8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBACFC: LDR x1, [x9]               | X1 = "isSkillFrozen";                   
            // 0x00BBAD00: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBAD04: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBAD08: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAD0C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BBAD10: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAD14: LDR x21, [x8, #0xa0]       | X21 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache14;
            val_76 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache14;
            // 0x00BBAD18: CBNZ x21, #0xbbad64        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache14 != null) goto label_153;
            if(val_76 != null)
            {
                goto label_153;
            }
            // 0x00BBAD1C: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00BBAD20: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBAD24: LDR x8, [x8, #0xe28]       | X8 = 1152921510043468256;               
            // 0x00BBAD28: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBAD2C: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_isSkillFrozen_2(ref object o);
            // 0x00BBAD30: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_57 = null;
            // 0x00BBAD34: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBAD38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAD3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAD40: MOV x2, x21                | X2 = 1152921510043468256 (0x10000001440C41E0);//ML01
            // 0x00BBAD44: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBAD48: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_isSkillFrozen_2(ref object o));
            val_57 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_isSkillFrozen_2(ref object o));
            // 0x00BBAD4C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAD50: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAD54: STR x22, [x8, #0xa0]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782835872
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache14 = val_57;
            // 0x00BBAD58: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAD5C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAD60: LDR x21, [x8, #0xa0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_76 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache14;
            label_153:
            // 0x00BBAD64: CBNZ x19, #0xbbad6c        | if (X1 != 0) goto label_154;            
            if(X1 != 0)
            {
                goto label_154;
            }
            // 0x00BBAD68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding::get_isSkillFrozen_2(ref object o)), ????);
            label_154:
            // 0x00BBAD6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAD70: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBAD74: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BBAD78: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBAD7C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_76);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_76);
            // 0x00BBAD80: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBAD84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBAD88: LDR x21, [x8, #0xa8]       | X21 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache15;
            val_77 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache15;
            // 0x00BBAD8C: CBNZ x21, #0xbbadd8        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache15 != null) goto label_155;
            if(val_77 != null)
            {
                goto label_155;
            }
            // 0x00BBAD90: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00BBAD94: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BBAD98: LDR x8, [x8, #0xda8]       | X8 = 1152921510043469280;               
            // 0x00BBAD9C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BBADA0: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_isSkillFrozen_2(ref object o, object v);
            // 0x00BBADA4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_58 = null;
            // 0x00BBADA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BBADAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBADB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBADB4: MOV x2, x21                | X2 = 1152921510043469280 (0x10000001440C45E0);//ML01
            // 0x00BBADB8: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BBADBC: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_isSkillFrozen_2(ref object o, object v));
            val_58 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_isSkillFrozen_2(ref object o, object v));
            // 0x00BBADC0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBADC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBADC8: STR x22, [x8, #0xa8]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache15 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782835880
            ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache15 = val_58;
            // 0x00BBADCC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding);
            // 0x00BBADD0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBADD4: LDR x21, [x8, #0xa8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_77 = ILRuntime.Runtime.Generated.AnimationRunner_Binding.<>f__mg$cache15;
            label_155:
            // 0x00BBADD8: CBNZ x19, #0xbbade0        | if (X1 != 0) goto label_156;            
            if(X1 != 0)
            {
                goto label_156;
            }
            // 0x00BBADDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimationRunner_Binding::set_isSkillFrozen_2(ref object o, object v)), ????);
            label_156:
            // 0x00BBADE0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBADE4: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BBADE8: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BBADEC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBADF0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBADF4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBADF8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBADFC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBAE00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAE04: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BBAE08: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_77); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_77);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBAE0C (12299788), len: 764  VirtAddr: 0x00BBAE0C RVA: 0x00BBAE0C token: 100663760 methodIndex: 29805 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_aniState_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00BBAE0C: STP x26, x25, [sp, #-0x50]! | stack[1152921510043790832] = ???;  stack[1152921510043790840] = ???;  //  dest_result_addr=1152921510043790832 |  dest_result_addr=1152921510043790840
            // 0x00BBAE10: STP x24, x23, [sp, #0x10]  | stack[1152921510043790848] = ???;  stack[1152921510043790856] = ???;  //  dest_result_addr=1152921510043790848 |  dest_result_addr=1152921510043790856
            // 0x00BBAE14: STP x22, x21, [sp, #0x20]  | stack[1152921510043790864] = ???;  stack[1152921510043790872] = ???;  //  dest_result_addr=1152921510043790864 |  dest_result_addr=1152921510043790872
            // 0x00BBAE18: STP x20, x19, [sp, #0x30]  | stack[1152921510043790880] = ???;  stack[1152921510043790888] = ???;  //  dest_result_addr=1152921510043790880 |  dest_result_addr=1152921510043790888
            // 0x00BBAE1C: STP x29, x30, [sp, #0x40]  | stack[1152921510043790896] = ???;  stack[1152921510043790904] = ???;  //  dest_result_addr=1152921510043790896 |  dest_result_addr=1152921510043790904
            // 0x00BBAE20: ADD x29, sp, #0x40         | X29 = (1152921510043790832 + 64) = 1152921510043790896 (0x1000000144112E30);
            // 0x00BBAE24: SUB sp, sp, #0x10          | SP = (1152921510043790832 - 16) = 1152921510043790816 (0x1000000144112DE0);
            // 0x00BBAE28: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBAE2C: LDRB w8, [x20, #0xb5c]     | W8 = (bool)static_value_03733B5C;       
            // 0x00BBAE30: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBAE34: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBAE38: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBAE3C: TBNZ w8, #0, #0xbbae58     | if (static_value_03733B5C == true) goto label_0;
            // 0x00BBAE40: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00BBAE44: LDR x8, [x8, #0x470]       | X8 = 0x2B8AEC0;                         
            // 0x00BBAE48: LDR w0, [x8]               | W0 = 0x26E;                             
            // 0x00BBAE4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x26E, ????);      
            // 0x00BBAE50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBAE54: STRB w8, [x20, #0xb5c]     | static_value_03733B5C = true;            //  dest_result_addr=57883484
            label_0:
            // 0x00BBAE58: CBNZ x19, #0xbbae60        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBAE5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x26E, ????);      
            label_1:
            // 0x00BBAE60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBAE64: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBAE68: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBAE6C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBAE70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAE74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAE78: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBAE7C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBAE80: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBAE84: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBAE88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAE8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAE90: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBAE94: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBAE98: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBAE9C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBAEA0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBAEA4: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
            // 0x00BBAEA8: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBAEAC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBAEB0: LDR x9, [x9, #0x2c8]       | X9 = 1152921504922394624;               
            // 0x00BBAEB4: LDR x24, [x9]              | X24 = typeof(AnimationRunner.AniState); 
            // 0x00BBAEB8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBAEBC: TBZ w9, #0, #0xbbaed0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBAEC0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBAEC4: CBNZ w9, #0xbbaed0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBAEC8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBAECC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBAED0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBAED8: MOV x1, x24                | X1 = 1152921504922394624 (0x1000000012CEE000);//ML01
            // 0x00BBAEDC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBAEE0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBAEE4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBAEE8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBAEEC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBAEF0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBAEF4: TBZ w9, #0, #0xbbaf08      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBAEF8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBAEFC: CBNZ w9, #0xbbaf08         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBAF00: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBAF04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBAF08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAF0C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBAF10: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBAF14: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBAF18: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBAF1C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBAF20: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBAF24: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBAF28: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBAF2C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBAF30: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBAF34: TBZ w9, #0, #0xbbaf48      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBAF38: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBAF3C: CBNZ w9, #0xbbaf48         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBAF40: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBAF44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBAF48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAF4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAF50: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBAF54: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBAF58: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBAF5C: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00BBAF60: LDR x8, [x8, #0x1e8]       | X8 = 1152921504922394624;               
            // 0x00BBAF64: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBAF68: LDR x24, [x8]              | X24 = typeof(AnimationRunner.AniState); 
            // 0x00BBAF6C: CBNZ x26, #0xbbaf74        | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x00BBAF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00BBAF74: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BBAF78: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBAF7C: LDR x8, [x24, #0x30]       | X8 = AnimationRunner.AniState.__il2cppRuntimeField_element_class;
            // 0x00BBAF80: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationRunner.AniState.__il2cppRuntimeField_element_class)
            // 0x00BBAF84: B.NE #0xbbb0d8             | if (System.Object.__il2cppRuntimeField_element_class != AnimationRunner.AniState.__il2cppRuntimeField_element_class) goto label_9;
            // 0x00BBAF88: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x00BBAF8C: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x00BBAF90: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x00BBAF94: CBNZ x19, #0xbbaf9c        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBAF98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x00BBAF9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBAFA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBAFA4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBAFA8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBAFAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAFB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBAFB4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBAFB8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBAFBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBAFC0: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBAFC4: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBAFC8: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BBAFCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAFD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBAFD4: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBAFD8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBAFDC: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BBAFE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBAFE4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBAFE8: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBAFEC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBAFF0: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBAFF4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBAFF8: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00BBAFFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB000: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB004: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BBB008: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BBB00C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BBB010: CBZ x0, #0xbbb074          | if (val_10 == null) goto label_13;      
            if(val_10 == null)
            {
                goto label_13;
            }
            // 0x00BBB014: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBB018: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBB01C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBB020: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBB024: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB028: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB02C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBB030: B.LO #0xbbb04c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBB034: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBB038: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBB03C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBB040: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBB044: MOV x21, x0                | X21 = val_10;//m1                       
            val_13 = val_10;
            // 0x00BBB048: B.EQ #0xbbb074             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBB04C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBB050: ADD x8, sp, #8             | X8 = (1152921510043790816 + 8) = 1152921510043790824 (0x1000000144112DE8);
            // 0x00BBB054: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBB058: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510043778912]
            // 0x00BBB05C: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BBB060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB064: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BBB068: ADD x0, sp, #8             | X0 = (1152921510043790816 + 8) = 1152921510043790824 (0x1000000144112DE8);
            // 0x00BBB06C: BL #0x299a140              | 
            // 0x00BBB070: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_13:
            // 0x00BBB074: CBNZ x19, #0xbbb07c        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBB078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144112DE8, ????);
            label_14:
            // 0x00BBB07C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB080: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBB084: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBB088: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBB08C: CBNZ x21, #0xbbb094        | if (0x0 != 0) goto label_15;            
            if(val_13 != 0)
            {
                goto label_15;
            }
            // 0x00BBB090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBB094: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB098: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB09C: MOV w1, w24                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BBB0A0: BL #0xb27d88               | val_13.set_aniState(value:  1152921504606900224);
            val_13.aniState = 1152921504606900224;
            // 0x00BBB0A4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBB0A8: SUB sp, x29, #0x40         | SP = (1152921510043790896 - 64) = 1152921510043790832 (0x1000000144112DF0);
            // 0x00BBB0AC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBB0B0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBB0B4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBB0B8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBB0BC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BBB0C0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBB0C4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBB0C8: ADD x0, sp, #8             | X0 = (1152921510043790912 + 8) = 1152921510043790920 (0x1000000144112E48);
            label_16:
            // 0x00BBB0CC: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000144112E48); //ERROR_TYPE
            // 0x00BBB0D0: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BBB0D4: BL #0x980800               | X0 = sub_980800( ?? val_2, ????);       
            label_9:
            // 0x00BBB0D8: MOV x8, sp                 | X8 = 1152921510043790912 (0x1000000144112E40);//ML01
            // 0x00BBB0DC: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00BBB0E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_2, ????);      
            // 0x00BBB0E4: LDR x0, [sp]               | X0 = __esp;                             
            // 0x00BBB0E8: BL #0x27af090              | X0 = sub_27AF090( ?? __esp, ????);      
            // 0x00BBB0EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB0F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __esp, ????);      
            // 0x00BBB0F4: MOV x0, sp                 | X0 = 1152921510043790912 (0x1000000144112E40);//ML01
            // 0x00BBB0F8: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(ILRuntime.Runtime.Stack.StackObject*));
            // 0x00BBB0FC: MOV x19, x0                | X19 = 1152921510043875872 (0x1000000144127A20);//ML01
            // 0x00BBB100: MOV x0, sp                 | X0 = 1152921510043790912 (0x1000000144112E40);//ML01
            // 0x00BBB104: B #0xbbb0cc                |  goto label_16;                         
            goto label_16;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBB108 (12300552), len: 580  VirtAddr: 0x00BBB108 RVA: 0x00BBB108 token: 100663761 methodIndex: 29806 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_aniState_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            // 0x00BBB108: STP x24, x23, [sp, #-0x40]! | stack[1152921510043984768] = ???;  stack[1152921510043984776] = ???;  //  dest_result_addr=1152921510043984768 |  dest_result_addr=1152921510043984776
            // 0x00BBB10C: STP x22, x21, [sp, #0x10]  | stack[1152921510043984784] = ???;  stack[1152921510043984792] = ???;  //  dest_result_addr=1152921510043984784 |  dest_result_addr=1152921510043984792
            // 0x00BBB110: STP x20, x19, [sp, #0x20]  | stack[1152921510043984800] = ???;  stack[1152921510043984808] = ???;  //  dest_result_addr=1152921510043984800 |  dest_result_addr=1152921510043984808
            // 0x00BBB114: STP x29, x30, [sp, #0x30]  | stack[1152921510043984816] = ???;  stack[1152921510043984824] = ???;  //  dest_result_addr=1152921510043984816 |  dest_result_addr=1152921510043984824
            // 0x00BBB118: ADD x29, sp, #0x30         | X29 = (1152921510043984768 + 48) = 1152921510043984816 (0x10000001441423B0);
            // 0x00BBB11C: SUB sp, sp, #0x10          | SP = (1152921510043984768 - 16) = 1152921510043984752 (0x1000000144142370);
            // 0x00BBB120: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BBB124: LDRB w8, [x21, #0xb5d]     | W8 = (bool)static_value_03733B5D;       
            // 0x00BBB128: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BBB12C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBB130: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBB134: TBNZ w8, #0, #0xbbb150     | if (static_value_03733B5D == true) goto label_0;
            // 0x00BBB138: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x00BBB13C: LDR x8, [x8, #0x3b8]       | X8 = 0x2B8AE84;                         
            // 0x00BBB140: LDR w0, [x8]               | W0 = 0x25F;                             
            // 0x00BBB144: BL #0x2782188              | X0 = sub_2782188( ?? 0x25F, ????);      
            // 0x00BBB148: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBB14C: STRB w8, [x21, #0xb5d]     | static_value_03733B5D = true;            //  dest_result_addr=57883485
            label_0:
            // 0x00BBB150: CBNZ x20, #0xbbb158        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBB154: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x25F, ????);      
            label_1:
            // 0x00BBB158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB15C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBB160: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBB164: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBB168: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB16C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB170: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBB174: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB178: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB17C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BBB180: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB188: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBB18C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB190: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB194: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBB198: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBB19C: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBB1A0: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BBB1A4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBB1A8: LDR x9, [x9, #0xd80]       | X9 = 1152921504922288128;               
            // 0x00BBB1AC: LDR x24, [x9]              | X24 = typeof(AnimationRunner);          
            // 0x00BBB1B0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBB1B4: TBZ w9, #0, #0xbbb1c8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBB1B8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB1BC: CBNZ w9, #0xbbb1c8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBB1C0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBB1C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBB1C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB1CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB1D0: MOV x1, x24                | X1 = 1152921504922288128 (0x1000000012CD4000);//ML01
            // 0x00BBB1D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBB1D8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBB1DC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBB1E0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBB1E4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBB1E8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBB1EC: TBZ w9, #0, #0xbbb200      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBB1F0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB1F4: CBNZ w9, #0xbbb200         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBB1F8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBB1FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBB200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB204: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBB208: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BBB20C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBB210: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BBB214: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBB218: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBB21C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBB220: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BBB224: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBB228: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBB22C: TBZ w9, #0, #0xbbb240      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBB230: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB234: CBNZ w9, #0xbbb240         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBB238: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBB23C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBB240: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB248: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBB24C: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BBB250: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBB254: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BBB258: CBZ x0, #0xbbb2bc          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BBB25C: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBB260: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBB264: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBB268: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBB26C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB270: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB274: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBB278: B.LO #0xbbb294             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BBB27C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBB280: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBB284: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBB288: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBB28C: MOV x23, x0                | X23 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BBB290: B.EQ #0xbbb2bc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BBB294: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBB298: ADD x8, sp, #8             | X8 = (1152921510043984752 + 8) = 1152921510043984760 (0x1000000144142378);
            // 0x00BBB29C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBB2A0: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510043972832]
            // 0x00BBB2A4: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BBB2A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB2AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BBB2B0: ADD x0, sp, #8             | X0 = (1152921510043984752 + 8) = 1152921510043984760 (0x1000000144142378);
            // 0x00BBB2B4: BL #0x299a140              | 
            // 0x00BBB2B8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BBB2BC: CBNZ x20, #0xbbb2c4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBB2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144142378, ????);
            label_11:
            // 0x00BBB2C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB2C8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBB2CC: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BBB2D0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBB2D4: CBNZ x23, #0xbbb2dc        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BBB2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BBB2DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB2E0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB2E4: BL #0xb27d90               | X0 = val_11.get_aniState();             
            AniState val_9 = val_11.aniState;
            // 0x00BBB2E8: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00BBB2EC: LDR x8, [x8, #0x1e8]       | X8 = 1152921504922394624;               
            // 0x00BBB2F0: STR w0, [sp, #4]           | stack[1152921510043984756] = val_9;      //  dest_result_addr=1152921510043984756
            // 0x00BBB2F4: ADD x1, sp, #4             | X1 = (1152921510043984752 + 4) = 1152921510043984756 (0x1000000144142374);
            // 0x00BBB2F8: LDR x8, [x8]               | X8 = typeof(AnimationRunner.AniState);  
            // 0x00BBB2FC: MOV x0, x8                 | X0 = 1152921504922394624 (0x1000000012CEE000);//ML01
            // 0x00BBB300: BL #0x27bc028              | X0 = 1152921510044061600 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniState), val_9);
            // 0x00BBB304: MOV x3, x0                 | X3 = 1152921510044061600 (0x1000000144154FA0);//ML01
            // 0x00BBB308: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB30C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BBB310: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BBB314: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BBB318: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BBB31C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BBB320: SUB sp, x29, #0x30         | SP = (1152921510043984816 - 48) = 1152921510043984768 (0x1000000144142380);
            // 0x00BBB324: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBB328: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBB32C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBB330: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BBB334: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBB338: MOV x19, x0                | 
            // 0x00BBB33C: ADD x0, sp, #8             | 
            // 0x00BBB340: BL #0x299a140              | 
            // 0x00BBB344: MOV x0, x19                | 
            // 0x00BBB348: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBB34C (12301132), len: 576  VirtAddr: 0x00BBB34C RVA: 0x00BBB34C token: 100663762 methodIndex: 29807 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetRunSpeed_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00BBB34C: STP d9, d8, [sp, #-0x50]!  | stack[1152921510044162288] = ???;  stack[1152921510044162296] = ???;  //  dest_result_addr=1152921510044162288 |  dest_result_addr=1152921510044162296
            // 0x00BBB350: STP x24, x23, [sp, #0x10]  | stack[1152921510044162304] = ???;  stack[1152921510044162312] = ???;  //  dest_result_addr=1152921510044162304 |  dest_result_addr=1152921510044162312
            // 0x00BBB354: STP x22, x21, [sp, #0x20]  | stack[1152921510044162320] = ???;  stack[1152921510044162328] = ???;  //  dest_result_addr=1152921510044162320 |  dest_result_addr=1152921510044162328
            // 0x00BBB358: STP x20, x19, [sp, #0x30]  | stack[1152921510044162336] = ???;  stack[1152921510044162344] = ???;  //  dest_result_addr=1152921510044162336 |  dest_result_addr=1152921510044162344
            // 0x00BBB35C: STP x29, x30, [sp, #0x40]  | stack[1152921510044162352] = ???;  stack[1152921510044162360] = ???;  //  dest_result_addr=1152921510044162352 |  dest_result_addr=1152921510044162360
            // 0x00BBB360: ADD x29, sp, #0x40         | X29 = (1152921510044162288 + 64) = 1152921510044162352 (0x100000014416D930);
            // 0x00BBB364: SUB sp, sp, #0x10          | SP = (1152921510044162288 - 16) = 1152921510044162272 (0x100000014416D8E0);
            // 0x00BBB368: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBB36C: LDRB w8, [x20, #0xb5e]     | W8 = (bool)static_value_03733B5E;       
            // 0x00BBB370: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BBB374: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BBB378: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBB37C: TBNZ w8, #0, #0xbbb398     | if (static_value_03733B5E == true) goto label_0;
            // 0x00BBB380: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00BBB384: LDR x8, [x8, #0x6f0]       | X8 = 0x2B8AED4;                         
            // 0x00BBB388: LDR w0, [x8]               | W0 = 0x273;                             
            // 0x00BBB38C: BL #0x2782188              | X0 = sub_2782188( ?? 0x273, ????);      
            // 0x00BBB390: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBB394: STRB w8, [x20, #0xb5e]     | static_value_03733B5E = true;            //  dest_result_addr=57883486
            label_0:
            // 0x00BBB398: CBNZ x19, #0xbbb3a0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBB39C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x273, ????);      
            label_1:
            // 0x00BBB3A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB3A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBB3A8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBB3AC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBB3B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB3B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB3B8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBB3BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBB3C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB3C4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBB3C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB3CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB3D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBB3D4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBB3D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB3DC: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BBB3E0: CBNZ x24, #0xbbb3e8        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BBB3E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BBB3E8: LDR s8, [x24, #4]          | S8 = val_3 + 4;                         
            // 0x00BBB3EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB3F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB3F4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBB3F8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBB3FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB400: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBB404: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBB408: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBB40C: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00BBB410: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBB414: LDR x9, [x9, #0xd80]       | X9 = 1152921504922288128;               
            // 0x00BBB418: LDR x24, [x9]              | X24 = typeof(AnimationRunner);          
            // 0x00BBB41C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBB420: TBZ w9, #0, #0xbbb434      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BBB424: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB428: CBNZ w9, #0xbbb434         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BBB42C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBB430: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BBB434: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB43C: MOV x1, x24                | X1 = 1152921504922288128 (0x1000000012CD4000);//ML01
            // 0x00BBB440: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBB444: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBB448: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBB44C: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x00BBB450: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBB454: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBB458: TBZ w9, #0, #0xbbb46c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BBB45C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB460: CBNZ w9, #0xbbb46c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BBB464: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBB468: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BBB46C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB470: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBB474: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00BBB478: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBB47C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BBB480: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBB484: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBB488: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBB48C: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00BBB490: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBB494: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBB498: TBZ w9, #0, #0xbbb4ac      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BBB49C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB4A0: CBNZ w9, #0xbbb4ac         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BBB4A4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBB4A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BBB4AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB4B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB4B4: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x00BBB4B8: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x00BBB4BC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BBB4C0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BBB4C4: CBZ x0, #0xbbb528          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BBB4C8: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBB4CC: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBB4D0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBB4D4: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBB4D8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB4DC: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB4E0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBB4E4: B.LO #0xbbb500             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BBB4E8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBB4EC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBB4F0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBB4F4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBB4F8: MOV x22, x0                | X22 = val_7;//m1                        
            val_10 = val_7;
            // 0x00BBB4FC: B.EQ #0xbbb528             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BBB500: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBB504: ADD x8, sp, #8             | X8 = (1152921510044162272 + 8) = 1152921510044162280 (0x100000014416D8E8);
            // 0x00BBB508: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBB50C: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510044150368]
            // 0x00BBB510: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BBB514: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB518: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BBB51C: ADD x0, sp, #8             | X0 = (1152921510044162272 + 8) = 1152921510044162280 (0x100000014416D8E8);
            // 0x00BBB520: BL #0x299a140              | 
            // 0x00BBB524: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x00BBB528: CBNZ x19, #0xbbb530        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BBB52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014416D8E8, ????);
            label_12:
            // 0x00BBB530: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB534: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBB538: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00BBB53C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBB540: CBNZ x22, #0xbbb548        | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x00BBB544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BBB548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB54C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB550: MOV v0.16b, v8.16b         | V0 = val_3 + 4;//m1                     
            // 0x00BBB554: BL #0xb28578               | val_10.SetRunSpeed(runSpeed:  val_3 + 4);
            val_10.SetRunSpeed(runSpeed:  val_3 + 4);
            // 0x00BBB558: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBB55C: SUB sp, x29, #0x40         | SP = (1152921510044162352 - 64) = 1152921510044162288 (0x100000014416D8F0);
            // 0x00BBB560: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBB564: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBB568: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBB56C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBB570: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
            // 0x00BBB574: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBB578: MOV x19, x0                | 
            // 0x00BBB57C: ADD x0, sp, #8             | 
            // 0x00BBB580: BL #0x299a140              | 
            // 0x00BBB584: MOV x0, x19                | 
            // 0x00BBB588: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBB58C (12301708), len: 832  VirtAddr: 0x00BBB58C RVA: 0x00BBB58C token: 100663763 methodIndex: 29808 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* HasExistAni_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_18;
            //  | 
            var val_19;
            //  | 
            bool val_20;
            //  | 
            var val_21;
            // 0x00BBB58C: STP x28, x27, [sp, #-0x60]! | stack[1152921510044343904] = ???;  stack[1152921510044343912] = ???;  //  dest_result_addr=1152921510044343904 |  dest_result_addr=1152921510044343912
            // 0x00BBB590: STP x26, x25, [sp, #0x10]  | stack[1152921510044343920] = ???;  stack[1152921510044343928] = ???;  //  dest_result_addr=1152921510044343920 |  dest_result_addr=1152921510044343928
            // 0x00BBB594: STP x24, x23, [sp, #0x20]  | stack[1152921510044343936] = ???;  stack[1152921510044343944] = ???;  //  dest_result_addr=1152921510044343936 |  dest_result_addr=1152921510044343944
            // 0x00BBB598: STP x22, x21, [sp, #0x30]  | stack[1152921510044343952] = ???;  stack[1152921510044343960] = ???;  //  dest_result_addr=1152921510044343952 |  dest_result_addr=1152921510044343960
            // 0x00BBB59C: STP x20, x19, [sp, #0x40]  | stack[1152921510044343968] = ???;  stack[1152921510044343976] = ???;  //  dest_result_addr=1152921510044343968 |  dest_result_addr=1152921510044343976
            // 0x00BBB5A0: STP x29, x30, [sp, #0x50]  | stack[1152921510044343984] = ???;  stack[1152921510044343992] = ???;  //  dest_result_addr=1152921510044343984 |  dest_result_addr=1152921510044343992
            // 0x00BBB5A4: ADD x29, sp, #0x50         | X29 = (1152921510044343904 + 80) = 1152921510044343984 (0x1000000144199EB0);
            // 0x00BBB5A8: SUB sp, sp, #0x10          | SP = (1152921510044343904 - 16) = 1152921510044343888 (0x1000000144199E50);
            // 0x00BBB5AC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBB5B0: LDRB w8, [x19, #0xb5f]     | W8 = (bool)static_value_03733B5F;       
            // 0x00BBB5B4: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBB5B8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBB5BC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBB5C0: TBNZ w8, #0, #0xbbb5dc     | if (static_value_03733B5F == true) goto label_0;
            // 0x00BBB5C4: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00BBB5C8: LDR x8, [x8, #0xbc0]       | X8 = 0x2B8AEA4;                         
            // 0x00BBB5CC: LDR w0, [x8]               | W0 = 0x267;                             
            // 0x00BBB5D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x267, ????);      
            // 0x00BBB5D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBB5D8: STRB w8, [x19, #0xb5f]     | static_value_03733B5F = true;            //  dest_result_addr=57883487
            label_0:
            // 0x00BBB5DC: CBNZ x20, #0xbbb5e4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBB5E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x267, ????);      
            label_1:
            // 0x00BBB5E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB5E8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBB5EC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBB5F0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBB5F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB5F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB5FC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBB600: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB604: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB608: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBB60C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB610: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB614: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBB618: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB61C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB620: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBB624: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBB628: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BBB62C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBB630: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBB634: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BBB638: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BBB63C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBB640: TBZ w9, #0, #0xbbb654      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBB644: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB648: CBNZ w9, #0xbbb654         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBB64C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBB650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBB654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB65C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBB660: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBB664: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BBB668: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BBB66C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBB670: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBB674: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBB678: TBZ w9, #0, #0xbbb68c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBB67C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB680: CBNZ w9, #0xbbb68c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBB684: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBB688: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBB68C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB690: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBB694: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBB698: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBB69C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBB6A0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBB6A4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBB6A8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBB6AC: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBB6B0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBB6B4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBB6B8: TBZ w9, #0, #0xbbb6cc      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBB6BC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB6C0: CBNZ w9, #0xbbb6cc         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBB6C4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBB6C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBB6CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB6D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB6D4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBB6D8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBB6DC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBB6E0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00BBB6E4: CBZ x0, #0xbbb72c          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BBB6E8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBB6EC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BBB6F0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BBB6F4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBB6F8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BBB6FC: MOV x24, x0                | X24 = val_6;//m1                        
            val_18 = val_6;
            // 0x00BBB700: B.EQ #0xbbb72c             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BBB704: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBB708: MOV x8, sp                 | X8 = 1152921510044343888 (0x1000000144199E50);//ML01
            // 0x00BBB70C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBB710: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510044332000]
            // 0x00BBB714: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BBB718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB71C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BBB720: MOV x0, sp                 | X0 = 1152921510044343888 (0x1000000144199E50);//ML01
            // 0x00BBB724: BL #0x299a140              | 
            // 0x00BBB728: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_9:
            // 0x00BBB72C: CBNZ x20, #0xbbb734        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBB730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144199E50, ????);
            label_10:
            // 0x00BBB734: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB738: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBB73C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBB740: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBB744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB74C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBB750: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB754: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB758: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBB75C: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBB760: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BBB764: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB768: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB76C: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBB770: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBB774: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BBB778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB77C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBB780: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BBB784: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBB788: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBB78C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBB790: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BBB794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB798: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB79C: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BBB7A0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BBB7A4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x00BBB7A8: CBZ x0, #0xbbb80c          | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x00BBB7AC: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBB7B0: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBB7B4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBB7B8: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBB7BC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB7C0: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBB7C4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBB7C8: B.LO #0xbbb7e4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBB7CC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBB7D0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBB7D4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBB7D8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBB7DC: MOV x21, x0                | X21 = val_11;//m1                       
            val_19 = val_11;
            // 0x00BBB7E0: B.EQ #0xbbb80c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBB7E4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBB7E8: ADD x8, sp, #8             | X8 = (1152921510044343888 + 8) = 1152921510044343896 (0x1000000144199E58);
            // 0x00BBB7EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBB7F0: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510044332000]
            // 0x00BBB7F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BBB7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB7FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BBB800: ADD x0, sp, #8             | X0 = (1152921510044343888 + 8) = 1152921510044343896 (0x1000000144199E58);
            // 0x00BBB804: BL #0x299a140              | 
            // 0x00BBB808: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_13:
            // 0x00BBB80C: CBNZ x20, #0xbbb814        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBB810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144199E58, ????);
            label_14:
            // 0x00BBB814: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB818: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBB81C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BBB820: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBB824: CBNZ x21, #0xbbb82c        | if (0x0 != 0) goto label_15;            
            if(val_19 != 0)
            {
                goto label_15;
            }
            // 0x00BBB828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBB82C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB830: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB834: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB838: BL #0xb28580               | X0 = val_19.HasExistAni(name:  val_18); 
            bool val_14 = val_19.HasExistAni(name:  val_18);
            // 0x00BBB83C: MOV w20, w0                | W20 = val_14;//m1                       
            // 0x00BBB840: CBZ x19, #0xbbb854         | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x00BBB844: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBB848: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BBB84C: AND w20, w20, #1           | W20 = (val_14 & 1);                     
            val_20 = val_14;
            // 0x00BBB850: B #0xbbb868                |  goto label_17;                         
            goto label_17;
            label_16:
            // 0x00BBB854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x00BBB858: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBB85C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BBB860: AND w20, w20, #1           | W20 = (val_14 & 1);                     
            val_20 = val_14;
            // 0x00BBB864: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_17:
            // 0x00BBB868: STR w20, [x19, #4]         | mem2[0] = (val_14 & 1);                  //  dest_result_addr=0
            mem2[0] = val_20;
            // 0x00BBB86C: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBB870: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_21 = 8;
            // 0x00BBB874: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BBB878: TBZ w9, #0, #0xbbb888      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x00BBB87C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BBB880: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BBB884: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_21 = 219381744;
            label_18:
            // 0x00BBB888: ADD x0, x8, x19            | X0 = (val_21 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_15 = val_21 + val_2;
            // 0x00BBB88C: SUB sp, x29, #0x50         | SP = (1152921510044343984 - 80) = 1152921510044343904 (0x1000000144199E60);
            // 0x00BBB890: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBB894: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBB898: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBB89C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBB8A0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBB8A4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BBB8A8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_21 + val_2);
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBB8AC: MOV x19, x0                | 
            // 0x00BBB8B0: ADD x0, sp, #8             | 
            // 0x00BBB8B4: B #0xbbb8c0                | 
            // 0x00BBB8B8: MOV x19, x0                | 
            // 0x00BBB8BC: MOV x0, sp                 | 
            label_19:
            // 0x00BBB8C0: BL #0x299a140              | 
            // 0x00BBB8C4: MOV x0, x19                | 
            // 0x00BBB8C8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBB8CC (12302540), len: 848  VirtAddr: 0x00BBB8CC RVA: 0x00BBB8CC token: 100663764 methodIndex: 29809 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_15;
            //  | 
            string val_17;
            //  | 
            var val_18;
            // 0x00BBB8CC: STP d9, d8, [sp, #-0x70]!  | stack[1152921510044537808] = ???;  stack[1152921510044537816] = ???;  //  dest_result_addr=1152921510044537808 |  dest_result_addr=1152921510044537816
            // 0x00BBB8D0: STP x28, x27, [sp, #0x10]  | stack[1152921510044537824] = ???;  stack[1152921510044537832] = ???;  //  dest_result_addr=1152921510044537824 |  dest_result_addr=1152921510044537832
            // 0x00BBB8D4: STP x26, x25, [sp, #0x20]  | stack[1152921510044537840] = ???;  stack[1152921510044537848] = ???;  //  dest_result_addr=1152921510044537840 |  dest_result_addr=1152921510044537848
            // 0x00BBB8D8: STP x24, x23, [sp, #0x30]  | stack[1152921510044537856] = ???;  stack[1152921510044537864] = ???;  //  dest_result_addr=1152921510044537856 |  dest_result_addr=1152921510044537864
            // 0x00BBB8DC: STP x22, x21, [sp, #0x40]  | stack[1152921510044537872] = ???;  stack[1152921510044537880] = ???;  //  dest_result_addr=1152921510044537872 |  dest_result_addr=1152921510044537880
            // 0x00BBB8E0: STP x20, x19, [sp, #0x50]  | stack[1152921510044537888] = ???;  stack[1152921510044537896] = ???;  //  dest_result_addr=1152921510044537888 |  dest_result_addr=1152921510044537896
            // 0x00BBB8E4: STP x29, x30, [sp, #0x60]  | stack[1152921510044537904] = ???;  stack[1152921510044537912] = ???;  //  dest_result_addr=1152921510044537904 |  dest_result_addr=1152921510044537912
            // 0x00BBB8E8: ADD x29, sp, #0x60         | X29 = (1152921510044537808 + 96) = 1152921510044537904 (0x10000001441C9430);
            // 0x00BBB8EC: SUB sp, sp, #0x10          | SP = (1152921510044537808 - 16) = 1152921510044537792 (0x10000001441C93C0);
            // 0x00BBB8F0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBB8F4: LDRB w8, [x20, #0xb60]     | W8 = (bool)static_value_03733B60;       
            // 0x00BBB8F8: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBB8FC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBB900: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBB904: TBNZ w8, #0, #0xbbb920     | if (static_value_03733B60 == true) goto label_0;
            // 0x00BBB908: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00BBB90C: LDR x8, [x8, #0x460]       | X8 = 0x2B8AEAC;                         
            // 0x00BBB910: LDR w0, [x8]               | W0 = 0x269;                             
            // 0x00BBB914: BL #0x2782188              | X0 = sub_2782188( ?? 0x269, ????);      
            // 0x00BBB918: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBB91C: STRB w8, [x20, #0xb60]     | static_value_03733B60 = true;            //  dest_result_addr=57883488
            label_0:
            // 0x00BBB920: CBNZ x19, #0xbbb928        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBB924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x269, ????);      
            label_1:
            // 0x00BBB928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBB92C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBB930: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBB934: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBB938: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB93C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB940: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBB944: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB948: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB94C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBB950: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB954: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB958: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBB95C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB960: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB964: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BBB968: CBNZ x24, #0xbbb970        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BBB96C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BBB970: LDR w27, [x24, #4]         | W27 = val_3 + 4;                        
            // 0x00BBB974: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB978: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB97C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBB980: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB984: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB988: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBB98C: CBNZ x24, #0xbbb994        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BBB990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BBB994: LDR s8, [x24, #4]          | S8 = val_4 + 4;                         
            // 0x00BBB998: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB99C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBB9A0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBB9A4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBB9A8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBB9AC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBB9B0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBB9B4: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BBB9B8: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BBB9BC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBB9C0: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BBB9C4: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BBB9C8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBB9CC: TBZ w9, #0, #0xbbb9e0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBB9D0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBB9D4: CBNZ w9, #0xbbb9e0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBB9D8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBB9DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00BBB9E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBB9E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBB9E8: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBB9EC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBB9F0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBB9F4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBB9F8: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BBB9FC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBBA00: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBBA04: TBZ w9, #0, #0xbbba18      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBBA08: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBBA0C: CBNZ w9, #0xbbba18         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBBA10: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBBA14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x00BBBA18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBA1C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBBA20: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BBBA24: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBBA28: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBBA2C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBBA30: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBBA34: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBBA38: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x00BBBA3C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBBA40: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBBA44: TBZ w9, #0, #0xbbba58      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BBBA48: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBBA4C: CBNZ w9, #0xbbba58         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BBBA50: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBBA54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x00BBBA58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBA5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBA60: MOV x1, x24                | X1 = val_6;//m1                         
            // 0x00BBBA64: MOV x2, x26                | X2 = val_7;//m1                         
            // 0x00BBBA68: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x00BBBA6C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BBBA70: CBZ x0, #0xbbbab8          | if (val_8 == null) goto label_11;       
            if(val_8 == null)
            {
                goto label_11;
            }
            // 0x00BBBA74: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBBA78: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BBBA7C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BBBA80: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBBA84: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BBBA88: MOV x24, x0                | X24 = val_8;//m1                        
            val_17 = val_8;
            // 0x00BBBA8C: B.EQ #0xbbbab8             | if (typeof(System.Object) == null) goto label_11;
            if(null == null)
            {
                goto label_11;
            }
            // 0x00BBBA90: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBBA94: MOV x8, sp                 | X8 = 1152921510044537792 (0x10000001441C93C0);//ML01
            // 0x00BBBA98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBBA9C: LDR x0, [sp]               | X0 = val_9;                              //  find_add[1152921510044525920]
            // 0x00BBBAA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BBBAA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBAA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BBBAAC: MOV x0, sp                 | X0 = 1152921510044537792 (0x10000001441C93C0);//ML01
            // 0x00BBBAB0: BL #0x299a140              | 
            // 0x00BBBAB4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_11:
            // 0x00BBBAB8: CBNZ x19, #0xbbbac0        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BBBABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001441C93C0, ????);
            label_12:
            // 0x00BBBAC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBAC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBBAC8: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BBBACC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBBAD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBAD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBAD8: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBBADC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBAE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBAE4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBBAE8: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBBAEC: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00BBBAF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBAF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBAF8: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBBAFC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBBB00: MOV x25, x0                | X25 = val_11;//m1                       
            // 0x00BBBB04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBB08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBBB0C: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00BBBB10: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBBB14: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBBB18: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBBB1C: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x00BBBB20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBB24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBB28: MOV x1, x25                | X1 = val_11;//m1                        
            // 0x00BBBB2C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x00BBBB30: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00BBBB34: CBZ x0, #0xbbbb98          | if (val_13 == null) goto label_15;      
            if(val_13 == null)
            {
                goto label_15;
            }
            // 0x00BBBB38: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBBB3C: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBBB40: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBBB44: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBBB48: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBBB4C: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBBB50: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBBB54: B.LO #0xbbbb70             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x00BBBB58: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBBB5C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBBB60: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBBB64: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBBB68: MOV x21, x0                | X21 = val_13;//m1                       
            val_18 = val_13;
            // 0x00BBBB6C: B.EQ #0xbbbb98             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x00BBBB70: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBBB74: ADD x8, sp, #8             | X8 = (1152921510044537792 + 8) = 1152921510044537800 (0x10000001441C93C8);
            // 0x00BBBB78: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBBB7C: LDR x0, [sp, #8]           | X0 = val_15;                             //  find_add[1152921510044525920]
            // 0x00BBBB80: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x00BBBB84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBB88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x00BBBB8C: ADD x0, sp, #8             | X0 = (1152921510044537792 + 8) = 1152921510044537800 (0x10000001441C93C8);
            // 0x00BBBB90: BL #0x299a140              | 
            // 0x00BBBB94: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_15:
            // 0x00BBBB98: CBNZ x19, #0xbbbba0        | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x00BBBB9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001441C93C8, ????);
            label_16:
            // 0x00BBBBA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBBA4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBBBA8: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00BBBBAC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBBBB0: CBNZ x21, #0xbbbbb8        | if (0x0 != 0) goto label_17;            
            if(val_18 != 0)
            {
                goto label_17;
            }
            // 0x00BBBBB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_17:
            // 0x00BBBBB8: CMP w27, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x00BBBBBC: CSET w2, eq                | W2 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_16 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x00BBBBC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBBC4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBBC8: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBBCC: MOV v0.16b, v8.16b         | V0 = val_4 + 4;//m1                     
            // 0x00BBBBD0: BL #0xb285f8               | val_18.Play(aniName:  val_17, playTime:  val_4 + 4, isSkill:  bool val_16 = ((val_3 + 4) == 1) ? 1 : 0);
            val_18.Play(aniName:  val_17, playTime:  val_4 + 4, isSkill:  val_16);
            // 0x00BBBBD4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBBBD8: SUB sp, x29, #0x60         | SP = (1152921510044537904 - 96) = 1152921510044537808 (0x10000001441C93D0);
            // 0x00BBBBDC: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBBBE0: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBBBE4: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBBBE8: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBBBEC: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBBBF0: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BBBBF4: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BBBBF8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBBBFC: MOV x19, x0                | 
            // 0x00BBBC00: ADD x0, sp, #8             | 
            // 0x00BBBC04: B #0xbbbc10                | 
            // 0x00BBBC08: MOV x19, x0                | 
            // 0x00BBBC0C: MOV x0, sp                 | 
            label_18:
            // 0x00BBBC10: BL #0x299a140              | 
            // 0x00BBBC14: MOV x0, x19                | 
            // 0x00BBBC18: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBBC1C (12303388), len: 840  VirtAddr: 0x00BBBC1C RVA: 0x00BBBC1C token: 100663765 methodIndex: 29810 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_15;
            //  | 
            string val_17;
            //  | 
            var val_18;
            // 0x00BBBC1C: STP d9, d8, [sp, #-0x60]!  | stack[1152921510044731744] = ???;  stack[1152921510044731752] = ???;  //  dest_result_addr=1152921510044731744 |  dest_result_addr=1152921510044731752
            // 0x00BBBC20: STP x26, x25, [sp, #0x10]  | stack[1152921510044731760] = ???;  stack[1152921510044731768] = ???;  //  dest_result_addr=1152921510044731760 |  dest_result_addr=1152921510044731768
            // 0x00BBBC24: STP x24, x23, [sp, #0x20]  | stack[1152921510044731776] = ???;  stack[1152921510044731784] = ???;  //  dest_result_addr=1152921510044731776 |  dest_result_addr=1152921510044731784
            // 0x00BBBC28: STP x22, x21, [sp, #0x30]  | stack[1152921510044731792] = ???;  stack[1152921510044731800] = ???;  //  dest_result_addr=1152921510044731792 |  dest_result_addr=1152921510044731800
            // 0x00BBBC2C: STP x20, x19, [sp, #0x40]  | stack[1152921510044731808] = ???;  stack[1152921510044731816] = ???;  //  dest_result_addr=1152921510044731808 |  dest_result_addr=1152921510044731816
            // 0x00BBBC30: STP x29, x30, [sp, #0x50]  | stack[1152921510044731824] = ???;  stack[1152921510044731832] = ???;  //  dest_result_addr=1152921510044731824 |  dest_result_addr=1152921510044731832
            // 0x00BBBC34: ADD x29, sp, #0x50         | X29 = (1152921510044731744 + 80) = 1152921510044731824 (0x10000001441F89B0);
            // 0x00BBBC38: SUB sp, sp, #0x10          | SP = (1152921510044731744 - 16) = 1152921510044731728 (0x10000001441F8950);
            // 0x00BBBC3C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBBC40: LDRB w8, [x20, #0xb61]     | W8 = (bool)static_value_03733B61;       
            // 0x00BBBC44: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBBC48: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBBC4C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBBC50: TBNZ w8, #0, #0xbbbc6c     | if (static_value_03733B61 == true) goto label_0;
            // 0x00BBBC54: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00BBBC58: LDR x8, [x8, #0x300]       | X8 = 0x2B8AEB0;                         
            // 0x00BBBC5C: LDR w0, [x8]               | W0 = 0x26A;                             
            // 0x00BBBC60: BL #0x2782188              | X0 = sub_2782188( ?? 0x26A, ????);      
            // 0x00BBBC64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBBC68: STRB w8, [x20, #0xb61]     | static_value_03733B61 = true;            //  dest_result_addr=57883489
            label_0:
            // 0x00BBBC6C: CBNZ x19, #0xbbbc74        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBBC70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x26A, ????);      
            label_1:
            // 0x00BBBC74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBC78: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBBC7C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBBC80: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBBC84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBC88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBC8C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBBC90: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBC94: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBC98: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBBC9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBCA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBCA4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBBCA8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBCAC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBCB0: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BBBCB4: CBNZ x24, #0xbbbcbc        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BBBCB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BBBCBC: LDR s8, [x24, #4]          | S8 = val_3 + 4;                         
            // 0x00BBBCC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBCC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBCC8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBBCCC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBCD0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBCD4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBBCD8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBBCDC: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BBBCE0: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BBBCE4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBBCE8: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BBBCEC: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BBBCF0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBBCF4: TBZ w9, #0, #0xbbbd08      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BBBCF8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBBCFC: CBNZ w9, #0xbbbd08         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BBBD00: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBBD04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BBBD08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBD0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBD10: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBBD14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBBD18: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBBD1C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBBD20: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x00BBBD24: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBBD28: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBBD2C: TBZ w9, #0, #0xbbbd40      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BBBD30: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBBD34: CBNZ w9, #0xbbbd40         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BBBD38: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBBD3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BBBD40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBD44: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBBD48: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BBBD4C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBBD50: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBBD54: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBBD58: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBBD5C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBBD60: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBBD64: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBBD68: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBBD6C: TBZ w9, #0, #0xbbbd80      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BBBD70: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBBD74: CBNZ w9, #0xbbbd80         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BBBD78: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBBD7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BBBD80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBD84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBD88: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x00BBBD8C: MOV x2, x26                | X2 = val_6;//m1                         
            // 0x00BBBD90: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BBBD94: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BBBD98: CBZ x0, #0xbbbde0          | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BBBD9C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBBDA0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BBBDA4: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BBBDA8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBBDAC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BBBDB0: MOV x24, x0                | X24 = val_7;//m1                        
            val_17 = val_7;
            // 0x00BBBDB4: B.EQ #0xbbbde0             | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x00BBBDB8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBBDBC: MOV x8, sp                 | X8 = 1152921510044731728 (0x10000001441F8950);//ML01
            // 0x00BBBDC0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBBDC4: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510044719840]
            // 0x00BBBDC8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BBBDCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBDD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BBBDD4: MOV x0, sp                 | X0 = 1152921510044731728 (0x10000001441F8950);//ML01
            // 0x00BBBDD8: BL #0x299a140              | 
            // 0x00BBBDDC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_10:
            // 0x00BBBDE0: CBNZ x19, #0xbbbde8        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBBDE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001441F8950, ????);
            label_11:
            // 0x00BBBDE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBDEC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBBDF0: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BBBDF4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBBDF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBDFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBE00: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBBE04: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBE08: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBE0C: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BBBE10: CBNZ x25, #0xbbbe18        | if (val_9 != 0) goto label_12;          
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BBBE14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_12:
            // 0x00BBBE18: LDR w26, [x25, #4]         | W26 = val_9 + 4;                        
            // 0x00BBBE1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBE20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBE24: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBBE28: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBE2C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBE30: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBBE34: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBBE38: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00BBBE3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBE40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBE44: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBBE48: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBBE4C: MOV x25, x0                | X25 = val_11;//m1                       
            // 0x00BBBE50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBE54: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBBE58: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00BBBE5C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBBE60: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBBE64: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBBE68: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x00BBBE6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBE70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBE74: MOV x1, x25                | X1 = val_11;//m1                        
            // 0x00BBBE78: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x00BBBE7C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00BBBE80: CBZ x0, #0xbbbee4          | if (val_13 == null) goto label_15;      
            if(val_13 == null)
            {
                goto label_15;
            }
            // 0x00BBBE84: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBBE88: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBBE8C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBBE90: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBBE94: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBBE98: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBBE9C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBBEA0: B.LO #0xbbbebc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x00BBBEA4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBBEA8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBBEAC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBBEB0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBBEB4: MOV x21, x0                | X21 = val_13;//m1                       
            val_18 = val_13;
            // 0x00BBBEB8: B.EQ #0xbbbee4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x00BBBEBC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBBEC0: ADD x8, sp, #8             | X8 = (1152921510044731728 + 8) = 1152921510044731736 (0x10000001441F8958);
            // 0x00BBBEC4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBBEC8: LDR x0, [sp, #8]           | X0 = val_15;                             //  find_add[1152921510044719840]
            // 0x00BBBECC: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x00BBBED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBED4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x00BBBED8: ADD x0, sp, #8             | X0 = (1152921510044731728 + 8) = 1152921510044731736 (0x10000001441F8958);
            // 0x00BBBEDC: BL #0x299a140              | 
            // 0x00BBBEE0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_15:
            // 0x00BBBEE4: CBNZ x19, #0xbbbeec        | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x00BBBEE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001441F8958, ????);
            label_16:
            // 0x00BBBEEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBEF0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBBEF4: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00BBBEF8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBBEFC: CBNZ x21, #0xbbbf04        | if (0x0 != 0) goto label_17;            
            if(val_18 != 0)
            {
                goto label_17;
            }
            // 0x00BBBF00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_17:
            // 0x00BBBF04: CMP w26, #1                | STATE = COMPARE(val_9 + 4, 0x1)         
            // 0x00BBBF08: CSET w1, eq                | W1 = val_9 + 4 == 0x1 ? 1 : 0;          
            bool val_16 = ((val_9 + 4) == 1) ? 1 : 0;
            // 0x00BBBF0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBF10: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBF14: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BBBF18: MOV v0.16b, v8.16b         | V0 = val_3 + 4;//m1                     
            // 0x00BBBF1C: BL #0xb28c84               | val_18.Play(isLoop:  bool val_16 = ((val_9 + 4) == 1) ? 1 : 0, aniName:  val_17, playTime:  val_3 + 4);
            val_18.Play(isLoop:  val_16, aniName:  val_17, playTime:  val_3 + 4);
            // 0x00BBBF20: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBBF24: SUB sp, x29, #0x50         | SP = (1152921510044731824 - 80) = 1152921510044731744 (0x10000001441F8960);
            // 0x00BBBF28: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBBF2C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBBF30: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBBF34: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBBF38: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBBF3C: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
            // 0x00BBBF40: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBBF44: MOV x19, x0                | 
            // 0x00BBBF48: ADD x0, sp, #8             | 
            // 0x00BBBF4C: B #0xbbbf58                | 
            // 0x00BBBF50: MOV x19, x0                | 
            // 0x00BBBF54: MOV x0, sp                 | 
            label_18:
            // 0x00BBBF58: BL #0x299a140              | 
            // 0x00BBBF5C: MOV x0, x19                | 
            // 0x00BBBF60: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBBF64 (12304228), len: 864  VirtAddr: 0x00BBBF64 RVA: 0x00BBBF64 token: 100663766 methodIndex: 29811 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_14;
            //  | 
            var val_16;
            // 0x00BBBF64: STP d9, d8, [sp, #-0x70]!  | stack[1152921510044929744] = ???;  stack[1152921510044929752] = ???;  //  dest_result_addr=1152921510044929744 |  dest_result_addr=1152921510044929752
            // 0x00BBBF68: STP x28, x27, [sp, #0x10]  | stack[1152921510044929760] = ???;  stack[1152921510044929768] = ???;  //  dest_result_addr=1152921510044929760 |  dest_result_addr=1152921510044929768
            // 0x00BBBF6C: STP x26, x25, [sp, #0x20]  | stack[1152921510044929776] = ???;  stack[1152921510044929784] = ???;  //  dest_result_addr=1152921510044929776 |  dest_result_addr=1152921510044929784
            // 0x00BBBF70: STP x24, x23, [sp, #0x30]  | stack[1152921510044929792] = ???;  stack[1152921510044929800] = ???;  //  dest_result_addr=1152921510044929792 |  dest_result_addr=1152921510044929800
            // 0x00BBBF74: STP x22, x21, [sp, #0x40]  | stack[1152921510044929808] = ???;  stack[1152921510044929816] = ???;  //  dest_result_addr=1152921510044929808 |  dest_result_addr=1152921510044929816
            // 0x00BBBF78: STP x20, x19, [sp, #0x50]  | stack[1152921510044929824] = ???;  stack[1152921510044929832] = ???;  //  dest_result_addr=1152921510044929824 |  dest_result_addr=1152921510044929832
            // 0x00BBBF7C: STP x29, x30, [sp, #0x60]  | stack[1152921510044929840] = ???;  stack[1152921510044929848] = ???;  //  dest_result_addr=1152921510044929840 |  dest_result_addr=1152921510044929848
            // 0x00BBBF80: ADD x29, sp, #0x60         | X29 = (1152921510044929744 + 96) = 1152921510044929840 (0x1000000144228F30);
            // 0x00BBBF84: SUB sp, sp, #0x10          | SP = (1152921510044929744 - 16) = 1152921510044929728 (0x1000000144228EC0);
            // 0x00BBBF88: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBBF8C: LDRB w8, [x20, #0xb62]     | W8 = (bool)static_value_03733B62;       
            // 0x00BBBF90: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBBF94: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBBF98: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBBF9C: TBNZ w8, #0, #0xbbbfb8     | if (static_value_03733B62 == true) goto label_0;
            // 0x00BBBFA0: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00BBBFA4: LDR x8, [x8, #0x7c0]       | X8 = 0x2B8AEB4;                         
            // 0x00BBBFA8: LDR w0, [x8]               | W0 = 0x26B;                             
            // 0x00BBBFAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x26B, ????);      
            // 0x00BBBFB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBBFB4: STRB w8, [x20, #0xb62]     | static_value_03733B62 = true;            //  dest_result_addr=57883490
            label_0:
            // 0x00BBBFB8: CBNZ x19, #0xbbbfc0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBBFBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x26B, ????);      
            label_1:
            // 0x00BBBFC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBBFC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBBFC8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBBFCC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBBFD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBFD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBFD8: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBBFDC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBFE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBFE4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBBFE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBBFEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBBFF0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBBFF4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBBFF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBBFFC: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BBC000: CBNZ x24, #0xbbc008        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BBC004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BBC008: LDR w27, [x24, #4]         | W27 = val_3 + 4;                        
            // 0x00BBC00C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC010: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC014: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBC018: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC01C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC020: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBC024: CBNZ x24, #0xbbc02c        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BBC028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BBC02C: LDR s8, [x24, #4]          | S8 = val_4 + 4;                         
            // 0x00BBC030: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC034: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC038: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBC03C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC040: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC044: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBC048: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBC04C: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BBC050: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BBC054: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBC058: LDR x9, [x9, #0x1f0]       | X9 = 1152921504922341376;               
            // 0x00BBC05C: LDR x24, [x9]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBC060: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBC064: TBZ w9, #0, #0xbbc078      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBC068: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC06C: CBNZ w9, #0xbbc078         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBC070: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBC074: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00BBC078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC07C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC080: MOV x1, x24                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBC084: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBC088: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBC08C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBC090: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x00BBC094: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBC098: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBC09C: TBZ w9, #0, #0xbbc0b0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBC0A0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC0A4: CBNZ w9, #0xbbc0b0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBC0A8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBC0AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x00BBC0B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC0B4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBC0B8: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BBC0BC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBC0C0: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBC0C4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBC0C8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBC0CC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBC0D0: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x00BBC0D4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBC0D8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBC0DC: TBZ w9, #0, #0xbbc0f0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BBC0E0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC0E4: CBNZ w9, #0xbbc0f0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BBC0E8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBC0EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x00BBC0F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC0F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC0F8: MOV x1, x24                | X1 = val_6;//m1                         
            // 0x00BBC0FC: MOV x2, x26                | X2 = val_7;//m1                         
            // 0x00BBC100: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x00BBC104: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBC108: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBC10C: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00BBC110: LDR x24, [x8]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBC114: CBNZ x26, #0xbbc11c        | if (val_8 != null) goto label_10;       
            if(val_8 != null)
            {
                goto label_10;
            }
            // 0x00BBC118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_10:
            // 0x00BBC11C: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BBC120: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBC124: LDR x8, [x24, #0x30]       | X8 = AnimationRunner.AniType.__il2cppRuntimeField_element_class;
            // 0x00BBC128: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationRunner.AniType.__il2cppRuntimeField_element_class)
            // 0x00BBC12C: B.NE #0xbbc294             | if (System.Object.__il2cppRuntimeField_element_class != AnimationRunner.AniType.__il2cppRuntimeField_element_class) goto label_11;
            // 0x00BBC130: MOV x0, x26                | X0 = val_8;//m1                         
            // 0x00BBC134: BL #0x27bc4e8              | val_8.System.IDisposable.Dispose();     
            val_8.System.IDisposable.Dispose();
            // 0x00BBC138: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x00BBC13C: CBNZ x19, #0xbbc144        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BBC140: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_12:
            // 0x00BBC144: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC148: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBC14C: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BBC150: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBC154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC158: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC15C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBC160: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC164: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC168: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBC16C: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBC170: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BBC174: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC178: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC17C: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBC180: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBC184: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00BBC188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC18C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBC190: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BBC194: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBC198: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBC19C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBC1A0: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BBC1A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC1A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC1AC: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x00BBC1B0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BBC1B4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BBC1B8: CBZ x0, #0xbbc21c          | if (val_12 == null) goto label_15;      
            if(val_12 == null)
            {
                goto label_15;
            }
            // 0x00BBC1BC: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBC1C0: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBC1C4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBC1C8: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBC1CC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBC1D0: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBC1D4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBC1D8: B.LO #0xbbc1f4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x00BBC1DC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBC1E0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBC1E4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBC1E8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBC1EC: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x00BBC1F0: B.EQ #0xbbc21c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x00BBC1F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBC1F8: ADD x8, sp, #8             | X8 = (1152921510044929728 + 8) = 1152921510044929736 (0x1000000144228EC8);
            // 0x00BBC1FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBC200: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510044917856]
            // 0x00BBC204: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BBC208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC20C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BBC210: ADD x0, sp, #8             | X0 = (1152921510044929728 + 8) = 1152921510044929736 (0x1000000144228EC8);
            // 0x00BBC214: BL #0x299a140              | 
            // 0x00BBC218: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_15:
            // 0x00BBC21C: CBNZ x19, #0xbbc224        | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x00BBC220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144228EC8, ????);
            label_16:
            // 0x00BBC224: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC228: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBC22C: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BBC230: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBC234: CBNZ x21, #0xbbc23c        | if (0x0 != 0) goto label_17;            
            if(val_16 != 0)
            {
                goto label_17;
            }
            // 0x00BBC238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_17:
            // 0x00BBC23C: CMP w27, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x00BBC240: CSET w2, eq                | W2 = val_3 + 4 == 0x1 ? 1 : 0;          
            bool val_15 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x00BBC244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC248: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC24C: MOV w1, w24                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BBC250: MOV v0.16b, v8.16b         | V0 = val_4 + 4;//m1                     
            // 0x00BBC254: BL #0xb293f4               | val_16.Play(aniType:  1152921504606900224, playTime:  val_4 + 4, isskill:  bool val_15 = ((val_3 + 4) == 1) ? 1 : 0);
            val_16.Play(aniType:  1152921504606900224, playTime:  val_4 + 4, isskill:  val_15);
            // 0x00BBC258: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBC25C: SUB sp, x29, #0x60         | SP = (1152921510044929840 - 96) = 1152921510044929744 (0x1000000144228ED0);
            // 0x00BBC260: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBC264: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBC268: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBC26C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBC270: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBC274: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00BBC278: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00BBC27C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBC280: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBC284: ADD x0, sp, #8             | X0 = (1152921510044929856 + 8) = 1152921510044929864 (0x1000000144228F48);
            label_18:
            // 0x00BBC288: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000144228F48); //ERROR_TYPE
            // 0x00BBC28C: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BBC290: BL #0x980800               | X0 = sub_980800( ?? val_2, ????);       
            label_11:
            // 0x00BBC294: MOV x8, sp                 | X8 = 1152921510044929856 (0x1000000144228F40);//ML01
            // 0x00BBC298: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00BBC29C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_2, ????);      
            // 0x00BBC2A0: LDR x0, [sp]               | X0 = __esp;                             
            // 0x00BBC2A4: BL #0x27af090              | X0 = sub_27AF090( ?? __esp, ????);      
            // 0x00BBC2A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC2AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __esp, ????);      
            // 0x00BBC2B0: MOV x0, sp                 | X0 = 1152921510044929856 (0x1000000144228F40);//ML01
            // 0x00BBC2B4: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(ILRuntime.Runtime.Stack.StackObject*));
            // 0x00BBC2B8: MOV x19, x0                | X19 = 1152921510045014816 (0x100000014423DB20);//ML01
            // 0x00BBC2BC: MOV x0, sp                 | X0 = 1152921510044929856 (0x1000000144228F40);//ML01
            // 0x00BBC2C0: B #0xbbc288                |  goto label_18;                         
            goto label_18;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBC2C4 (12305092), len: 848  VirtAddr: 0x00BBC2C4 RVA: 0x00BBC2C4 token: 100663767 methodIndex: 29812 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* IsPlay_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_17;
            //  | 
            bool val_18;
            //  | 
            var val_19;
            // 0x00BBC2C4: STP x28, x27, [sp, #-0x60]! | stack[1152921510045131872] = ???;  stack[1152921510045131880] = ???;  //  dest_result_addr=1152921510045131872 |  dest_result_addr=1152921510045131880
            // 0x00BBC2C8: STP x26, x25, [sp, #0x10]  | stack[1152921510045131888] = ???;  stack[1152921510045131896] = ???;  //  dest_result_addr=1152921510045131888 |  dest_result_addr=1152921510045131896
            // 0x00BBC2CC: STP x24, x23, [sp, #0x20]  | stack[1152921510045131904] = ???;  stack[1152921510045131912] = ???;  //  dest_result_addr=1152921510045131904 |  dest_result_addr=1152921510045131912
            // 0x00BBC2D0: STP x22, x21, [sp, #0x30]  | stack[1152921510045131920] = ???;  stack[1152921510045131928] = ???;  //  dest_result_addr=1152921510045131920 |  dest_result_addr=1152921510045131928
            // 0x00BBC2D4: STP x20, x19, [sp, #0x40]  | stack[1152921510045131936] = ???;  stack[1152921510045131944] = ???;  //  dest_result_addr=1152921510045131936 |  dest_result_addr=1152921510045131944
            // 0x00BBC2D8: STP x29, x30, [sp, #0x50]  | stack[1152921510045131952] = ???;  stack[1152921510045131960] = ???;  //  dest_result_addr=1152921510045131952 |  dest_result_addr=1152921510045131960
            // 0x00BBC2DC: ADD x29, sp, #0x50         | X29 = (1152921510045131872 + 80) = 1152921510045131952 (0x100000014425A4B0);
            // 0x00BBC2E0: SUB sp, sp, #0x10          | SP = (1152921510045131872 - 16) = 1152921510045131856 (0x100000014425A450);
            // 0x00BBC2E4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBC2E8: LDRB w8, [x19, #0xb63]     | W8 = (bool)static_value_03733B63;       
            // 0x00BBC2EC: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBC2F0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBC2F4: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBC2F8: TBNZ w8, #0, #0xbbc314     | if (static_value_03733B63 == true) goto label_0;
            // 0x00BBC2FC: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00BBC300: LDR x8, [x8, #0x780]       | X8 = 0x2B8AEA8;                         
            // 0x00BBC304: LDR w0, [x8]               | W0 = 0x268;                             
            // 0x00BBC308: BL #0x2782188              | X0 = sub_2782188( ?? 0x268, ????);      
            // 0x00BBC30C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBC310: STRB w8, [x19, #0xb63]     | static_value_03733B63 = true;            //  dest_result_addr=57883491
            label_0:
            // 0x00BBC314: CBNZ x20, #0xbbc31c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBC318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x268, ????);      
            label_1:
            // 0x00BBC31C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC320: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBC324: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBC328: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBC32C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC330: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC334: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBC338: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC33C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC340: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBC344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC348: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC34C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBC350: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC354: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC358: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBC35C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBC360: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BBC364: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBC368: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBC36C: LDR x9, [x9, #0x1f0]       | X9 = 1152921504922341376;               
            // 0x00BBC370: LDR x24, [x9]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBC374: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBC378: TBZ w9, #0, #0xbbc38c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBC37C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC380: CBNZ w9, #0xbbc38c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBC384: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBC388: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBC38C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC390: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC394: MOV x1, x24                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBC398: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBC39C: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BBC3A0: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BBC3A4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBC3A8: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBC3AC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBC3B0: TBZ w9, #0, #0xbbc3c4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBC3B4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC3B8: CBNZ w9, #0xbbc3c4         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBC3BC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBC3C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBC3C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC3C8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBC3CC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBC3D0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBC3D4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBC3D8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBC3DC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBC3E0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBC3E4: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBC3E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBC3EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBC3F0: TBZ w9, #0, #0xbbc404      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBC3F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC3F8: CBNZ w9, #0xbbc404         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBC3FC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBC400: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBC404: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC408: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC40C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBC410: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBC414: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBC418: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBC41C: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBC420: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBC424: LDR x24, [x8]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBC428: CBNZ x26, #0xbbc430        | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x00BBC42C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00BBC430: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BBC434: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBC438: LDR x8, [x24, #0x30]       | X8 = AnimationRunner.AniType.__il2cppRuntimeField_element_class;
            // 0x00BBC43C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationRunner.AniType.__il2cppRuntimeField_element_class)
            // 0x00BBC440: B.NE #0xbbc5e4             | if (System.Object.__il2cppRuntimeField_element_class != AnimationRunner.AniType.__il2cppRuntimeField_element_class) goto label_9;
            // 0x00BBC444: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x00BBC448: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x00BBC44C: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x00BBC450: CBNZ x20, #0xbbc458        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBC454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x00BBC458: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC45C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBC460: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBC464: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBC468: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC46C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC470: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBC474: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC478: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC47C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBC480: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBC484: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BBC488: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC48C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC490: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBC494: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBC498: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BBC49C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC4A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBC4A4: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBC4A8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBC4AC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBC4B0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBC4B4: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00BBC4B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC4BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC4C0: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BBC4C4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BBC4C8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BBC4CC: CBZ x0, #0xbbc530          | if (val_10 == null) goto label_13;      
            if(val_10 == null)
            {
                goto label_13;
            }
            // 0x00BBC4D0: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBC4D4: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBC4D8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBC4DC: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBC4E0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBC4E4: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBC4E8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBC4EC: B.LO #0xbbc508             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBC4F0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBC4F4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBC4F8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBC4FC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBC500: MOV x21, x0                | X21 = val_10;//m1                       
            val_17 = val_10;
            // 0x00BBC504: B.EQ #0xbbc530             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBC508: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBC50C: ADD x8, sp, #8             | X8 = (1152921510045131856 + 8) = 1152921510045131864 (0x100000014425A458);
            // 0x00BBC510: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBC514: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510045119968]
            // 0x00BBC518: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BBC51C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC520: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BBC524: ADD x0, sp, #8             | X0 = (1152921510045131856 + 8) = 1152921510045131864 (0x100000014425A458);
            // 0x00BBC528: BL #0x299a140              | 
            // 0x00BBC52C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x00BBC530: CBNZ x20, #0xbbc538        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBC534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014425A458, ????);
            label_14:
            // 0x00BBC538: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC53C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBC540: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBC544: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBC548: CBNZ x21, #0xbbc550        | if (0x0 != 0) goto label_15;            
            if(val_17 != 0)
            {
                goto label_15;
            }
            // 0x00BBC54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBC550: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC554: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC558: MOV w1, w24                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BBC55C: BL #0xb294b8               | X0 = val_17.IsPlay(aniType:  1152921504606900224);
            bool val_13 = val_17.IsPlay(aniType:  1152921504606900224);
            // 0x00BBC560: MOV w20, w0                | W20 = val_13;//m1                       
            // 0x00BBC564: CBZ x19, #0xbbc578         | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x00BBC568: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBC56C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BBC570: AND w20, w20, #1           | W20 = (val_13 & 1);                     
            val_18 = val_13;
            // 0x00BBC574: B #0xbbc58c                |  goto label_17;                         
            goto label_17;
            label_16:
            // 0x00BBC578: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x00BBC57C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBC580: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BBC584: AND w20, w20, #1           | W20 = (val_13 & 1);                     
            val_18 = val_13;
            // 0x00BBC588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_17:
            // 0x00BBC58C: STR w20, [x19, #4]         | mem2[0] = (val_13 & 1);                  //  dest_result_addr=0
            mem2[0] = val_18;
            // 0x00BBC590: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBC594: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_19 = 8;
            // 0x00BBC598: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BBC59C: TBZ w9, #0, #0xbbc5ac      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_18;
            // 0x00BBC5A0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BBC5A4: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BBC5A8: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_19 = 219381744;
            label_18:
            // 0x00BBC5AC: ADD x0, x8, x19            | X0 = (val_19 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_14 = val_19 + val_2;
            // 0x00BBC5B0: SUB sp, x29, #0x50         | SP = (1152921510045131952 - 80) = 1152921510045131872 (0x100000014425A460);
            // 0x00BBC5B4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBC5B8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBC5BC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBC5C0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBC5C4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBC5C8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BBC5CC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_19 + val_2);
            return val_14;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBC5D0: MOV x19, x0                | X19 = (val_19 + val_2);//m1             
            // 0x00BBC5D4: ADD x0, sp, #8             | X0 = (1152921510045131968 + 8) = 1152921510045131976 (0x100000014425A4C8);
            label_19:
            // 0x00BBC5D8: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x100000014425A4C8); //ERROR_TYPE
            // 0x00BBC5DC: MOV x0, x19                | X0 = (val_19 + val_2);//m1              
            // 0x00BBC5E0: BL #0x980800               | X0 = sub_980800( ?? (val_19 + val_2), ????);
            label_9:
            // 0x00BBC5E4: MOV x8, sp                 | X8 = 1152921510045131968 (0x100000014425A4C0);//ML01
            // 0x00BBC5E8: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00BBC5EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (val_19 + val_2), ????);
            // 0x00BBC5F0: LDR x0, [sp]               | X0 = __esp;                             
            // 0x00BBC5F4: BL #0x27af090              | X0 = sub_27AF090( ?? __esp, ????);      
            // 0x00BBC5F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC5FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __esp, ????);      
            // 0x00BBC600: MOV x0, sp                 | X0 = 1152921510045131968 (0x100000014425A4C0);//ML01
            // 0x00BBC604: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(ILRuntime.Runtime.Stack.StackObject*));
            // 0x00BBC608: MOV x19, x0                | X19 = 1152921510045216928 (0x100000014426F0A0);//ML01
            // 0x00BBC60C: MOV x0, sp                 | X0 = 1152921510045131968 (0x100000014425A4C0);//ML01
            // 0x00BBC610: B #0xbbc5d8                |  goto label_19;                         
            goto label_19;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBC614 (12305940), len: 796  VirtAddr: 0x00BBC614 RVA: 0x00BBC614 token: 100663768 methodIndex: 29813 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetActionTime_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            string val_15;
            //  | 
            var val_16;
            // 0x00BBC614: STP d9, d8, [sp, #-0x60]!  | stack[1152921510045329888] = ???;  stack[1152921510045329896] = ???;  //  dest_result_addr=1152921510045329888 |  dest_result_addr=1152921510045329896
            // 0x00BBC618: STP x26, x25, [sp, #0x10]  | stack[1152921510045329904] = ???;  stack[1152921510045329912] = ???;  //  dest_result_addr=1152921510045329904 |  dest_result_addr=1152921510045329912
            // 0x00BBC61C: STP x24, x23, [sp, #0x20]  | stack[1152921510045329920] = ???;  stack[1152921510045329928] = ???;  //  dest_result_addr=1152921510045329920 |  dest_result_addr=1152921510045329928
            // 0x00BBC620: STP x22, x21, [sp, #0x30]  | stack[1152921510045329936] = ???;  stack[1152921510045329944] = ???;  //  dest_result_addr=1152921510045329936 |  dest_result_addr=1152921510045329944
            // 0x00BBC624: STP x20, x19, [sp, #0x40]  | stack[1152921510045329952] = ???;  stack[1152921510045329960] = ???;  //  dest_result_addr=1152921510045329952 |  dest_result_addr=1152921510045329960
            // 0x00BBC628: STP x29, x30, [sp, #0x50]  | stack[1152921510045329968] = ???;  stack[1152921510045329976] = ???;  //  dest_result_addr=1152921510045329968 |  dest_result_addr=1152921510045329976
            // 0x00BBC62C: ADD x29, sp, #0x50         | X29 = (1152921510045329888 + 80) = 1152921510045329968 (0x100000014428AA30);
            // 0x00BBC630: SUB sp, sp, #0x10          | SP = (1152921510045329888 - 16) = 1152921510045329872 (0x100000014428A9D0);
            // 0x00BBC634: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBC638: LDRB w8, [x20, #0xb64]     | W8 = (bool)static_value_03733B64;       
            // 0x00BBC63C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBC640: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBC644: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBC648: TBNZ w8, #0, #0xbbc664     | if (static_value_03733B64 == true) goto label_0;
            // 0x00BBC64C: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00BBC650: LDR x8, [x8, #0xd18]       | X8 = 0x2B8AED0;                         
            // 0x00BBC654: LDR w0, [x8]               | W0 = 0x272;                             
            // 0x00BBC658: BL #0x2782188              | X0 = sub_2782188( ?? 0x272, ????);      
            // 0x00BBC65C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBC660: STRB w8, [x20, #0xb64]     | static_value_03733B64 = true;            //  dest_result_addr=57883492
            label_0:
            // 0x00BBC664: CBNZ x19, #0xbbc66c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBC668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x272, ????);      
            label_1:
            // 0x00BBC66C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC670: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBC674: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBC678: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBC67C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC680: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC684: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBC688: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC68C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC690: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBC694: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC698: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC69C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBC6A0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC6A4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC6A8: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BBC6AC: CBNZ x24, #0xbbc6b4        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BBC6B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BBC6B4: LDR s8, [x24, #4]          | S8 = val_3 + 4;                         
            // 0x00BBC6B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC6BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC6C0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBC6C4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC6C8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC6CC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBC6D0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBC6D4: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BBC6D8: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BBC6DC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBC6E0: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BBC6E4: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BBC6E8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBC6EC: TBZ w9, #0, #0xbbc700      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BBC6F0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC6F4: CBNZ w9, #0xbbc700         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BBC6F8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBC6FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BBC700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC704: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC708: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBC70C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBC710: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBC714: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBC718: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x00BBC71C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBC720: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBC724: TBZ w9, #0, #0xbbc738      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BBC728: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC72C: CBNZ w9, #0xbbc738         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BBC730: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBC734: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BBC738: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC73C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBC740: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BBC744: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBC748: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBC74C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBC750: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBC754: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBC758: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBC75C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBC760: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBC764: TBZ w9, #0, #0xbbc778      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BBC768: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC76C: CBNZ w9, #0xbbc778         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BBC770: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBC774: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BBC778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC77C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC780: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x00BBC784: MOV x2, x26                | X2 = val_6;//m1                         
            // 0x00BBC788: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BBC78C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BBC790: CBZ x0, #0xbbc7d8          | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BBC794: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBC798: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BBC79C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BBC7A0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBC7A4: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BBC7A8: MOV x24, x0                | X24 = val_7;//m1                        
            val_15 = val_7;
            // 0x00BBC7AC: B.EQ #0xbbc7d8             | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x00BBC7B0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBC7B4: MOV x8, sp                 | X8 = 1152921510045329872 (0x100000014428A9D0);//ML01
            // 0x00BBC7B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBC7BC: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510045317984]
            // 0x00BBC7C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BBC7C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC7C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BBC7CC: MOV x0, sp                 | X0 = 1152921510045329872 (0x100000014428A9D0);//ML01
            // 0x00BBC7D0: BL #0x299a140              | 
            // 0x00BBC7D4: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x00BBC7D8: CBNZ x19, #0xbbc7e0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBC7DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014428A9D0, ????);
            label_11:
            // 0x00BBC7E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC7E4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBC7E8: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BBC7EC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBC7F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC7F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC7F8: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBC7FC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC800: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC804: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBC808: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBC80C: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BBC810: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC814: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC818: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBC81C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBC820: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00BBC824: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC828: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBC82C: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BBC830: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBC834: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBC838: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBC83C: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BBC840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC844: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC848: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x00BBC84C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BBC850: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BBC854: CBZ x0, #0xbbc8b8          | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x00BBC858: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBC85C: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBC860: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBC864: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBC868: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBC86C: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBC870: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBC874: B.LO #0xbbc890             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BBC878: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBC87C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBC880: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBC884: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBC888: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x00BBC88C: B.EQ #0xbbc8b8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BBC890: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBC894: ADD x8, sp, #8             | X8 = (1152921510045329872 + 8) = 1152921510045329880 (0x100000014428A9D8);
            // 0x00BBC898: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBC89C: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510045317984]
            // 0x00BBC8A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BBC8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC8A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BBC8AC: ADD x0, sp, #8             | X0 = (1152921510045329872 + 8) = 1152921510045329880 (0x100000014428A9D8);
            // 0x00BBC8B0: BL #0x299a140              | 
            // 0x00BBC8B4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x00BBC8B8: CBNZ x19, #0xbbc8c0        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BBC8BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014428A9D8, ????);
            label_15:
            // 0x00BBC8C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC8C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBC8C8: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BBC8CC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBC8D0: CBNZ x21, #0xbbc8d8        | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x00BBC8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BBC8D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC8DC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC8E0: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC8E4: MOV v0.16b, v8.16b         | V0 = val_3 + 4;//m1                     
            // 0x00BBC8E8: BL #0xb28b7c               | val_16.SetActionTime(aniName:  val_15, playTime:  val_3 + 4);
            val_16.SetActionTime(aniName:  val_15, playTime:  val_3 + 4);
            // 0x00BBC8EC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBC8F0: SUB sp, x29, #0x50         | SP = (1152921510045329968 - 80) = 1152921510045329888 (0x100000014428A9E0);
            // 0x00BBC8F4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBC8F8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBC8FC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBC900: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBC904: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBC908: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
            // 0x00BBC90C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBC910: MOV x19, x0                | 
            // 0x00BBC914: ADD x0, sp, #8             | 
            // 0x00BBC918: B #0xbbc924                | 
            // 0x00BBC91C: MOV x19, x0                | 
            // 0x00BBC920: MOV x0, sp                 | 
            label_17:
            // 0x00BBC924: BL #0x299a140              | 
            // 0x00BBC928: MOV x0, x19                | 
            // 0x00BBC92C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBC930 (12306736), len: 764  VirtAddr: 0x00BBC930 RVA: 0x00BBC930 token: 100663769 methodIndex: 29814 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetWrapModel_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00BBC930: STP x26, x25, [sp, #-0x50]! | stack[1152921510045527920] = ???;  stack[1152921510045527928] = ???;  //  dest_result_addr=1152921510045527920 |  dest_result_addr=1152921510045527928
            // 0x00BBC934: STP x24, x23, [sp, #0x10]  | stack[1152921510045527936] = ???;  stack[1152921510045527944] = ???;  //  dest_result_addr=1152921510045527936 |  dest_result_addr=1152921510045527944
            // 0x00BBC938: STP x22, x21, [sp, #0x20]  | stack[1152921510045527952] = ???;  stack[1152921510045527960] = ???;  //  dest_result_addr=1152921510045527952 |  dest_result_addr=1152921510045527960
            // 0x00BBC93C: STP x20, x19, [sp, #0x30]  | stack[1152921510045527968] = ???;  stack[1152921510045527976] = ???;  //  dest_result_addr=1152921510045527968 |  dest_result_addr=1152921510045527976
            // 0x00BBC940: STP x29, x30, [sp, #0x40]  | stack[1152921510045527984] = ???;  stack[1152921510045527992] = ???;  //  dest_result_addr=1152921510045527984 |  dest_result_addr=1152921510045527992
            // 0x00BBC944: ADD x29, sp, #0x40         | X29 = (1152921510045527920 + 64) = 1152921510045527984 (0x10000001442BAFB0);
            // 0x00BBC948: SUB sp, sp, #0x10          | SP = (1152921510045527920 - 16) = 1152921510045527904 (0x10000001442BAF60);
            // 0x00BBC94C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBC950: LDRB w8, [x20, #0xb65]     | W8 = (bool)static_value_03733B65;       
            // 0x00BBC954: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBC958: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBC95C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBC960: TBNZ w8, #0, #0xbbc97c     | if (static_value_03733B65 == true) goto label_0;
            // 0x00BBC964: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00BBC968: LDR x8, [x8, #0xff8]       | X8 = 0x2B8AED8;                         
            // 0x00BBC96C: LDR w0, [x8]               | W0 = 0x274;                             
            // 0x00BBC970: BL #0x2782188              | X0 = sub_2782188( ?? 0x274, ????);      
            // 0x00BBC974: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBC978: STRB w8, [x20, #0xb65]     | static_value_03733B65 = true;            //  dest_result_addr=57883493
            label_0:
            // 0x00BBC97C: CBNZ x19, #0xbbc984        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBC980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x274, ????);      
            label_1:
            // 0x00BBC984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBC988: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBC98C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBC990: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBC994: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC998: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC99C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBC9A0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC9A4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC9A8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBC9AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC9B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBC9B4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBC9B8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBC9BC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBC9C0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBC9C4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBC9C8: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBC9CC: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBC9D0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBC9D4: LDR x9, [x9, #0xdb0]       | X9 = 1152921504695451648;               
            // 0x00BBC9D8: LDR x24, [x9]              | X24 = typeof(UnityEngine.WrapMode);     
            // 0x00BBC9DC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBC9E0: TBZ w9, #0, #0xbbc9f4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBC9E4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBC9E8: CBNZ w9, #0xbbc9f4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBC9EC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBC9F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBC9F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBC9F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBC9FC: MOV x1, x24                | X1 = 1152921504695451648 (0x1000000005480000);//ML01
            // 0x00BBCA00: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBCA04: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBCA08: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBCA0C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBCA10: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBCA14: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBCA18: TBZ w9, #0, #0xbbca2c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBCA1C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBCA20: CBNZ w9, #0xbbca2c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBCA24: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBCA28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBCA2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCA30: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBCA34: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBCA38: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBCA3C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBCA40: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBCA44: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBCA48: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBCA4C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBCA50: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBCA54: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBCA58: TBZ w9, #0, #0xbbca6c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBCA5C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBCA60: CBNZ w9, #0xbbca6c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBCA64: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBCA68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBCA6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCA70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCA74: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBCA78: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBCA7C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBCA80: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x00BBCA84: LDR x8, [x8, #0xbf0]       | X8 = 1152921504695451648;               
            // 0x00BBCA88: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBCA8C: LDR x24, [x8]              | X24 = typeof(UnityEngine.WrapMode);     
            // 0x00BBCA90: CBNZ x26, #0xbbca98        | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x00BBCA94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00BBCA98: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BBCA9C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBCAA0: LDR x8, [x24, #0x30]       | X8 = UnityEngine.WrapMode.__il2cppRuntimeField_element_class;
            // 0x00BBCAA4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, UnityEngine.WrapMode.__il2cppRuntimeField_element_class)
            // 0x00BBCAA8: B.NE #0xbbcbfc             | if (System.Object.__il2cppRuntimeField_element_class != UnityEngine.WrapMode.__il2cppRuntimeField_element_class) goto label_9;
            // 0x00BBCAAC: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x00BBCAB0: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x00BBCAB4: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x00BBCAB8: CBNZ x19, #0xbbcac0        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBCABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x00BBCAC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCAC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBCAC8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBCACC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBCAD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCAD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCAD8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBCADC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBCAE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBCAE4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBCAE8: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBCAEC: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BBCAF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCAF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCAF8: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBCAFC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBCB00: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BBCB04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCB08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBCB0C: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBCB10: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBCB14: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBCB18: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBCB1C: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00BBCB20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCB24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCB28: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BBCB2C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BBCB30: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BBCB34: CBZ x0, #0xbbcb98          | if (val_10 == null) goto label_13;      
            if(val_10 == null)
            {
                goto label_13;
            }
            // 0x00BBCB38: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBCB3C: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBCB40: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBCB44: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBCB48: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBCB4C: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBCB50: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBCB54: B.LO #0xbbcb70             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBCB58: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBCB5C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBCB60: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBCB64: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBCB68: MOV x21, x0                | X21 = val_10;//m1                       
            val_13 = val_10;
            // 0x00BBCB6C: B.EQ #0xbbcb98             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBCB70: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBCB74: ADD x8, sp, #8             | X8 = (1152921510045527904 + 8) = 1152921510045527912 (0x10000001442BAF68);
            // 0x00BBCB78: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBCB7C: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510045516000]
            // 0x00BBCB80: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BBCB84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBCB88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BBCB8C: ADD x0, sp, #8             | X0 = (1152921510045527904 + 8) = 1152921510045527912 (0x10000001442BAF68);
            // 0x00BBCB90: BL #0x299a140              | 
            // 0x00BBCB94: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_13:
            // 0x00BBCB98: CBNZ x19, #0xbbcba0        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBCB9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001442BAF68, ????);
            label_14:
            // 0x00BBCBA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCBA4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBCBA8: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBCBAC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBCBB0: CBNZ x21, #0xbbcbb8        | if (0x0 != 0) goto label_15;            
            if(val_13 != 0)
            {
                goto label_15;
            }
            // 0x00BBCBB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBCBB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCBBC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCBC0: MOV w1, w24                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BBCBC4: BL #0xb295dc               | val_13.SetWrapModel(wrap:  1152921504606900224);
            val_13.SetWrapModel(wrap:  1152921504606900224);
            // 0x00BBCBC8: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBCBCC: SUB sp, x29, #0x40         | SP = (1152921510045527984 - 64) = 1152921510045527920 (0x10000001442BAF70);
            // 0x00BBCBD0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBCBD4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBCBD8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBCBDC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBCBE0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BBCBE4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBCBE8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBCBEC: ADD x0, sp, #8             | X0 = (1152921510045528000 + 8) = 1152921510045528008 (0x10000001442BAFC8);
            label_16:
            // 0x00BBCBF0: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001442BAFC8); //ERROR_TYPE
            // 0x00BBCBF4: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00BBCBF8: BL #0x980800               | X0 = sub_980800( ?? val_2, ????);       
            label_9:
            // 0x00BBCBFC: MOV x8, sp                 | X8 = 1152921510045528000 (0x10000001442BAFC0);//ML01
            // 0x00BBCC00: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00BBCC04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_2, ????);      
            // 0x00BBCC08: LDR x0, [sp]               | X0 = __esp;                             
            // 0x00BBCC0C: BL #0x27af090              | X0 = sub_27AF090( ?? __esp, ????);      
            // 0x00BBCC10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBCC14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __esp, ????);      
            // 0x00BBCC18: MOV x0, sp                 | X0 = 1152921510045528000 (0x10000001442BAFC0);//ML01
            // 0x00BBCC1C: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(ILRuntime.Runtime.Stack.StackObject*));
            // 0x00BBCC20: MOV x19, x0                | X19 = 1152921510045612960 (0x10000001442CFBA0);//ML01
            // 0x00BBCC24: MOV x0, sp                 | X0 = 1152921510045528000 (0x10000001442BAFC0);//ML01
            // 0x00BBCC28: B #0xbbcbf0                |  goto label_16;                         
            goto label_16;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBCC2C (12307500), len: 824  VirtAddr: 0x00BBCC2C RVA: 0x00BBCC2C token: 100663770 methodIndex: 29815 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetActionTime_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00BBCC2C: STP x28, x27, [sp, #-0x60]! | stack[1152921510045730016] = ???;  stack[1152921510045730024] = ???;  //  dest_result_addr=1152921510045730016 |  dest_result_addr=1152921510045730024
            // 0x00BBCC30: STP x26, x25, [sp, #0x10]  | stack[1152921510045730032] = ???;  stack[1152921510045730040] = ???;  //  dest_result_addr=1152921510045730032 |  dest_result_addr=1152921510045730040
            // 0x00BBCC34: STP x24, x23, [sp, #0x20]  | stack[1152921510045730048] = ???;  stack[1152921510045730056] = ???;  //  dest_result_addr=1152921510045730048 |  dest_result_addr=1152921510045730056
            // 0x00BBCC38: STP x22, x21, [sp, #0x30]  | stack[1152921510045730064] = ???;  stack[1152921510045730072] = ???;  //  dest_result_addr=1152921510045730064 |  dest_result_addr=1152921510045730072
            // 0x00BBCC3C: STP x20, x19, [sp, #0x40]  | stack[1152921510045730080] = ???;  stack[1152921510045730088] = ???;  //  dest_result_addr=1152921510045730080 |  dest_result_addr=1152921510045730088
            // 0x00BBCC40: STP x29, x30, [sp, #0x50]  | stack[1152921510045730096] = ???;  stack[1152921510045730104] = ???;  //  dest_result_addr=1152921510045730096 |  dest_result_addr=1152921510045730104
            // 0x00BBCC44: ADD x29, sp, #0x50         | X29 = (1152921510045730016 + 80) = 1152921510045730096 (0x10000001442EC530);
            // 0x00BBCC48: SUB sp, sp, #0x10          | SP = (1152921510045730016 - 16) = 1152921510045730000 (0x10000001442EC4D0);
            // 0x00BBCC4C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBCC50: LDRB w8, [x19, #0xb66]     | W8 = (bool)static_value_03733B66;       
            // 0x00BBCC54: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBCC58: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBCC5C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBCC60: TBNZ w8, #0, #0xbbcc7c     | if (static_value_03733B66 == true) goto label_0;
            // 0x00BBCC64: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00BBCC68: LDR x8, [x8, #0x300]       | X8 = 0x2B8AE98;                         
            // 0x00BBCC6C: LDR w0, [x8]               | W0 = 0x264;                             
            // 0x00BBCC70: BL #0x2782188              | X0 = sub_2782188( ?? 0x264, ????);      
            // 0x00BBCC74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBCC78: STRB w8, [x19, #0xb66]     | static_value_03733B66 = true;            //  dest_result_addr=57883494
            label_0:
            // 0x00BBCC7C: CBNZ x20, #0xbbcc84        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBCC80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x264, ????);      
            label_1:
            // 0x00BBCC84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBCC88: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBCC8C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBCC90: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBCC94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCC98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCC9C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBCCA0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBCCA4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBCCA8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBCCAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCCB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCCB4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBCCB8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBCCBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBCCC0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBCCC4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBCCC8: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BBCCCC: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBCCD0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBCCD4: LDR x9, [x9, #0x1f0]       | X9 = 1152921504922341376;               
            // 0x00BBCCD8: LDR x24, [x9]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBCCDC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBCCE0: TBZ w9, #0, #0xbbccf4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBCCE4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBCCE8: CBNZ w9, #0xbbccf4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBCCEC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBCCF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBCCF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCCF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCCFC: MOV x1, x24                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBCD00: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBCD04: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BBCD08: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BBCD0C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBCD10: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBCD14: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBCD18: TBZ w9, #0, #0xbbcd2c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBCD1C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBCD20: CBNZ w9, #0xbbcd2c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBCD24: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBCD28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBCD2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCD30: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBCD34: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBCD38: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBCD3C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBCD40: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBCD44: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBCD48: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBCD4C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBCD50: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBCD54: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBCD58: TBZ w9, #0, #0xbbcd6c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBCD5C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBCD60: CBNZ w9, #0xbbcd6c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBCD64: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBCD68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBCD6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCD70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCD74: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBCD78: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBCD7C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBCD80: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBCD84: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBCD88: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBCD8C: LDR x24, [x8]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBCD90: CBNZ x26, #0xbbcd98        | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x00BBCD94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00BBCD98: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BBCD9C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBCDA0: LDR x8, [x24, #0x30]       | X8 = AnimationRunner.AniType.__il2cppRuntimeField_element_class;
            // 0x00BBCDA4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationRunner.AniType.__il2cppRuntimeField_element_class)
            // 0x00BBCDA8: B.NE #0xbbcf2c             | if (System.Object.__il2cppRuntimeField_element_class != AnimationRunner.AniType.__il2cppRuntimeField_element_class) goto label_9;
            // 0x00BBCDAC: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x00BBCDB0: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x00BBCDB4: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x00BBCDB8: CBNZ x20, #0xbbcdc0        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBCDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x00BBCDC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCDC4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBCDC8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBCDCC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBCDD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCDD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCDD8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBCDDC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBCDE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBCDE4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBCDE8: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBCDEC: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BBCDF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCDF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCDF8: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBCDFC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBCE00: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BBCE04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCE08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBCE0C: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBCE10: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBCE14: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBCE18: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBCE1C: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00BBCE20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCE24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCE28: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BBCE2C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BBCE30: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BBCE34: CBZ x0, #0xbbce98          | if (val_10 == null) goto label_13;      
            if(val_10 == null)
            {
                goto label_13;
            }
            // 0x00BBCE38: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBCE3C: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBCE40: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBCE44: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBCE48: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBCE4C: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBCE50: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBCE54: B.LO #0xbbce70             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBCE58: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBCE5C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBCE60: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBCE64: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBCE68: MOV x21, x0                | X21 = val_10;//m1                       
            val_15 = val_10;
            // 0x00BBCE6C: B.EQ #0xbbce98             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBCE70: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBCE74: ADD x8, sp, #8             | X8 = (1152921510045730000 + 8) = 1152921510045730008 (0x10000001442EC4D8);
            // 0x00BBCE78: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBCE7C: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510045718112]
            // 0x00BBCE80: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BBCE84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBCE88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BBCE8C: ADD x0, sp, #8             | X0 = (1152921510045730000 + 8) = 1152921510045730008 (0x10000001442EC4D8);
            // 0x00BBCE90: BL #0x299a140              | 
            // 0x00BBCE94: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_13:
            // 0x00BBCE98: CBNZ x20, #0xbbcea0        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBCE9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001442EC4D8, ????);
            label_14:
            // 0x00BBCEA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCEA4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBCEA8: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBCEAC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBCEB0: CBNZ x21, #0xbbceb8        | if (0x0 != 0) goto label_15;            
            if(val_15 != 0)
            {
                goto label_15;
            }
            // 0x00BBCEB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBCEB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBCEBC: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            val_16 = val_15;
            // 0x00BBCEC0: MOV w1, w24                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BBCEC4: BL #0xb29638               | X0 = val_16.GetActionTime(aniType:  1152921504606900224);
            float val_13 = val_16.GetActionTime(aniType:  1152921504606900224);
            // 0x00BBCEC8: CBZ x19, #0xbbcf50         | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x00BBCECC: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BBCED0: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00BBCED4: STR s0, [x19, #4]          | mem2[0] = val_13;                        //  dest_result_addr=0
            mem2[0] = val_13;
            // 0x00BBCED8: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBCEDC: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_17 = 8;
            // 0x00BBCEE0: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BBCEE4: TBZ w9, #0, #0xbbcef4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_17;
            // 0x00BBCEE8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BBCEEC: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BBCEF0: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_17 = 219381744;
            label_17:
            // 0x00BBCEF4: ADD x0, x8, x19            | X0 = (val_17 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_14 = val_17 + val_2;
            // 0x00BBCEF8: SUB sp, x29, #0x50         | SP = (1152921510045730096 - 80) = 1152921510045730016 (0x10000001442EC4E0);
            // 0x00BBCEFC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBCF00: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBCF04: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBCF08: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBCF0C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBCF10: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BBCF14: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_17 + val_2);
            return val_14;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBCF18: MOV x19, x0                | X19 = (val_17 + val_2);//m1             
            // 0x00BBCF1C: ADD x0, sp, #8             | X0 = (1152921510045730112 + 8) = 1152921510045730120 (0x10000001442EC548);
            label_18:
            // 0x00BBCF20: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001442EC548); //ERROR_TYPE
            // 0x00BBCF24: MOV x0, x19                | X0 = (val_17 + val_2);//m1              
            // 0x00BBCF28: BL #0x980800               | X0 = sub_980800( ?? (val_17 + val_2), ????);
            label_9:
            // 0x00BBCF2C: MOV x8, sp                 | X8 = 1152921510045730112 (0x10000001442EC540);//ML01
            // 0x00BBCF30: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00BBCF34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (val_17 + val_2), ????);
            // 0x00BBCF38: LDR x0, [sp]               | X0 = __esp;                             
            // 0x00BBCF3C: BL #0x27af090              | X0 = sub_27AF090( ?? __esp, ????);      
            // 0x00BBCF40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBCF44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __esp, ????);      
            // 0x00BBCF48: MOV x0, sp                 | X0 = 1152921510045730112 (0x10000001442EC540);//ML01
            // 0x00BBCF4C: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(ILRuntime.Runtime.Stack.StackObject*));
            label_16:
            // 0x00BBCF50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (ILRuntime.Runtime.Stack.StackObject*)[1152921510045815072], ????);
            // 0x00BBCF54: BRK #0x1                   | 
            // 0x00BBCF58: MOV x19, x0                | X19 = 1152921510045815072 (0x1000000144301120);//ML01
            // 0x00BBCF5C: MOV x0, sp                 | X0 = 1152921510045730112 (0x10000001442EC540);//ML01
            // 0x00BBCF60: B #0xbbcf20                |  goto label_18;                         
            goto label_18;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBCF64 (12308324), len: 588  VirtAddr: 0x00BBCF64 RVA: 0x00BBCF64 token: 100663771 methodIndex: 29816 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetActionTime_11(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BBCF64: STP x26, x25, [sp, #-0x50]! | stack[1152921510045915760] = ???;  stack[1152921510045915768] = ???;  //  dest_result_addr=1152921510045915760 |  dest_result_addr=1152921510045915768
            // 0x00BBCF68: STP x24, x23, [sp, #0x10]  | stack[1152921510045915776] = ???;  stack[1152921510045915784] = ???;  //  dest_result_addr=1152921510045915776 |  dest_result_addr=1152921510045915784
            // 0x00BBCF6C: STP x22, x21, [sp, #0x20]  | stack[1152921510045915792] = ???;  stack[1152921510045915800] = ???;  //  dest_result_addr=1152921510045915792 |  dest_result_addr=1152921510045915800
            // 0x00BBCF70: STP x20, x19, [sp, #0x30]  | stack[1152921510045915808] = ???;  stack[1152921510045915816] = ???;  //  dest_result_addr=1152921510045915808 |  dest_result_addr=1152921510045915816
            // 0x00BBCF74: STP x29, x30, [sp, #0x40]  | stack[1152921510045915824] = ???;  stack[1152921510045915832] = ???;  //  dest_result_addr=1152921510045915824 |  dest_result_addr=1152921510045915832
            // 0x00BBCF78: ADD x29, sp, #0x40         | X29 = (1152921510045915760 + 64) = 1152921510045915824 (0x1000000144319AB0);
            // 0x00BBCF7C: SUB sp, sp, #0x10          | SP = (1152921510045915760 - 16) = 1152921510045915744 (0x1000000144319A60);
            // 0x00BBCF80: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBCF84: LDRB w8, [x19, #0xb67]     | W8 = (bool)static_value_03733B67;       
            // 0x00BBCF88: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BBCF8C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BBCF90: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBCF94: TBNZ w8, #0, #0xbbcfb0     | if (static_value_03733B67 == true) goto label_0;
            // 0x00BBCF98: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x00BBCF9C: LDR x8, [x8, #0xa0]        | X8 = 0x2B8AE9C;                         
            // 0x00BBCFA0: LDR w0, [x8]               | W0 = 0x265;                             
            // 0x00BBCFA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x265, ????);      
            // 0x00BBCFA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBCFAC: STRB w8, [x19, #0xb67]     | static_value_03733B67 = true;            //  dest_result_addr=57883495
            label_0:
            // 0x00BBCFB0: CBNZ x20, #0xbbcfb8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBCFB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x265, ????);      
            label_1:
            // 0x00BBCFB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBCFBC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBCFC0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBCFC4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBCFC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCFCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCFD0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBCFD4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBCFD8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBCFDC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBCFE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBCFE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBCFE8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBCFEC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBCFF0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBCFF4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBCFF8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBCFFC: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBD000: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BBD004: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBD008: LDR x9, [x9, #0xd80]       | X9 = 1152921504922288128;               
            // 0x00BBD00C: LDR x24, [x9]              | X24 = typeof(AnimationRunner);          
            // 0x00BBD010: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBD014: TBZ w9, #0, #0xbbd028      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBD018: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD01C: CBNZ w9, #0xbbd028         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBD020: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBD024: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBD028: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD02C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD030: MOV x1, x24                | X1 = 1152921504922288128 (0x1000000012CD4000);//ML01
            // 0x00BBD034: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBD038: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BBD03C: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BBD040: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBD044: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD048: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBD04C: TBZ w9, #0, #0xbbd060      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBD050: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD054: CBNZ w9, #0xbbd060         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBD058: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBD05C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBD060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD064: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBD068: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BBD06C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBD070: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BBD074: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBD078: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBD07C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBD080: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BBD084: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBD088: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBD08C: TBZ w9, #0, #0xbbd0a0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBD090: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD094: CBNZ w9, #0xbbd0a0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBD098: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBD09C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBD0A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD0A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD0A8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBD0AC: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BBD0B0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBD0B4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BBD0B8: CBZ x0, #0xbbd11c          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BBD0BC: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBD0C0: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBD0C4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBD0C8: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBD0CC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD0D0: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD0D4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBD0D8: B.LO #0xbbd0f4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BBD0DC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBD0E0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBD0E4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBD0E8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBD0EC: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BBD0F0: B.EQ #0xbbd11c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BBD0F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBD0F8: ADD x8, sp, #8             | X8 = (1152921510045915744 + 8) = 1152921510045915752 (0x1000000144319A68);
            // 0x00BBD0FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBD100: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510045903840]
            // 0x00BBD104: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BBD108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD10C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BBD110: ADD x0, sp, #8             | X0 = (1152921510045915744 + 8) = 1152921510045915752 (0x1000000144319A68);
            // 0x00BBD114: BL #0x299a140              | 
            // 0x00BBD118: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BBD11C: CBNZ x20, #0xbbd124        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBD120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144319A68, ????);
            label_11:
            // 0x00BBD124: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD128: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD12C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BBD130: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBD134: CBNZ x22, #0xbbd13c        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BBD138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BBD13C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD140: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD144: BL #0xb29788               | X0 = val_11.GetActionTime();            
            float val_9 = val_11.GetActionTime();
            // 0x00BBD148: CBZ x19, #0xbbd1a8         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BBD14C: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BBD150: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00BBD154: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x00BBD158: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD15C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BBD160: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BBD164: TBZ w9, #0, #0xbbd174      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BBD168: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BBD16C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BBD170: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BBD174: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BBD178: SUB sp, x29, #0x40         | SP = (1152921510045915824 - 64) = 1152921510045915760 (0x1000000144319A70);
            // 0x00BBD17C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBD180: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBD184: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBD188: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBD18C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BBD190: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBD194: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BBD198: ADD x0, sp, #8             | X0 = (1152921510045915840 + 8) = 1152921510045915848 (0x1000000144319AC8);
            // 0x00BBD19C: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000144319AC8); //ERROR_TYPE
            // 0x00BBD1A0: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BBD1A4: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BBD1A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BBD1AC: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBD1B0 (12308912), len: 808  VirtAddr: 0x00BBD1B0 RVA: 0x00BBD1B0 token: 100663772 methodIndex: 29817 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetActionTime_12(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x00BBD1B0: STP x28, x27, [sp, #-0x60]! | stack[1152921510046097376] = ???;  stack[1152921510046097384] = ???;  //  dest_result_addr=1152921510046097376 |  dest_result_addr=1152921510046097384
            // 0x00BBD1B4: STP x26, x25, [sp, #0x10]  | stack[1152921510046097392] = ???;  stack[1152921510046097400] = ???;  //  dest_result_addr=1152921510046097392 |  dest_result_addr=1152921510046097400
            // 0x00BBD1B8: STP x24, x23, [sp, #0x20]  | stack[1152921510046097408] = ???;  stack[1152921510046097416] = ???;  //  dest_result_addr=1152921510046097408 |  dest_result_addr=1152921510046097416
            // 0x00BBD1BC: STP x22, x21, [sp, #0x30]  | stack[1152921510046097424] = ???;  stack[1152921510046097432] = ???;  //  dest_result_addr=1152921510046097424 |  dest_result_addr=1152921510046097432
            // 0x00BBD1C0: STP x20, x19, [sp, #0x40]  | stack[1152921510046097440] = ???;  stack[1152921510046097448] = ???;  //  dest_result_addr=1152921510046097440 |  dest_result_addr=1152921510046097448
            // 0x00BBD1C4: STP x29, x30, [sp, #0x50]  | stack[1152921510046097456] = ???;  stack[1152921510046097464] = ???;  //  dest_result_addr=1152921510046097456 |  dest_result_addr=1152921510046097464
            // 0x00BBD1C8: ADD x29, sp, #0x50         | X29 = (1152921510046097376 + 80) = 1152921510046097456 (0x1000000144346030);
            // 0x00BBD1CC: SUB sp, sp, #0x10          | SP = (1152921510046097376 - 16) = 1152921510046097360 (0x1000000144345FD0);
            // 0x00BBD1D0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBD1D4: LDRB w8, [x19, #0xb68]     | W8 = (bool)static_value_03733B68;       
            // 0x00BBD1D8: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBD1DC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBD1E0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBD1E4: TBNZ w8, #0, #0xbbd200     | if (static_value_03733B68 == true) goto label_0;
            // 0x00BBD1E8: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00BBD1EC: LDR x8, [x8, #0x9f0]       | X8 = 0x2B8AEA0;                         
            // 0x00BBD1F0: LDR w0, [x8]               | W0 = 0x266;                             
            // 0x00BBD1F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x266, ????);      
            // 0x00BBD1F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBD1FC: STRB w8, [x19, #0xb68]     | static_value_03733B68 = true;            //  dest_result_addr=57883496
            label_0:
            // 0x00BBD200: CBNZ x20, #0xbbd208        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBD204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x266, ????);      
            label_1:
            // 0x00BBD208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD20C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD210: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBD214: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBD218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD21C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD220: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBD224: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBD228: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD22C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBD230: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD234: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD238: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBD23C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBD240: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD244: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBD248: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBD24C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BBD250: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBD254: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBD258: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BBD25C: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BBD260: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBD264: TBZ w9, #0, #0xbbd278      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBD268: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD26C: CBNZ w9, #0xbbd278         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBD270: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBD274: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBD278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD27C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD280: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BBD284: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBD288: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BBD28C: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BBD290: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBD294: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD298: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBD29C: TBZ w9, #0, #0xbbd2b0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBD2A0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD2A4: CBNZ w9, #0xbbd2b0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBD2A8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBD2AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBD2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD2B4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBD2B8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBD2BC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBD2C0: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBD2C4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBD2C8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBD2CC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBD2D0: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBD2D4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBD2D8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBD2DC: TBZ w9, #0, #0xbbd2f0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBD2E0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD2E4: CBNZ w9, #0xbbd2f0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBD2E8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBD2EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBD2F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD2F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD2F8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBD2FC: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBD300: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBD304: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BBD308: CBZ x0, #0xbbd350          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BBD30C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBD310: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BBD314: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BBD318: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBD31C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BBD320: MOV x24, x0                | X24 = val_6;//m1                        
            val_16 = val_6;
            // 0x00BBD324: B.EQ #0xbbd350             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BBD328: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBD32C: MOV x8, sp                 | X8 = 1152921510046097360 (0x1000000144345FD0);//ML01
            // 0x00BBD330: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBD334: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510046085472]
            // 0x00BBD338: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BBD33C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD340: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BBD344: MOV x0, sp                 | X0 = 1152921510046097360 (0x1000000144345FD0);//ML01
            // 0x00BBD348: BL #0x299a140              | 
            // 0x00BBD34C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_9:
            // 0x00BBD350: CBNZ x20, #0xbbd358        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBD354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144345FD0, ????);
            label_10:
            // 0x00BBD358: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD35C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD360: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBD364: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBD368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD36C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD370: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBD374: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBD378: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD37C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBD380: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBD384: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BBD388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD38C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD390: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBD394: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBD398: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BBD39C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD3A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBD3A4: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BBD3A8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBD3AC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBD3B0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBD3B4: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BBD3B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD3BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD3C0: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BBD3C4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BBD3C8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00BBD3CC: CBZ x0, #0xbbd430          | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x00BBD3D0: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBD3D4: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBD3D8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBD3DC: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBD3E0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD3E4: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD3E8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBD3EC: B.LO #0xbbd408             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBD3F0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBD3F4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBD3F8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBD3FC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBD400: MOV x21, x0                | X21 = val_11;//m1                       
            val_17 = val_11;
            // 0x00BBD404: B.EQ #0xbbd430             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBD408: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBD40C: ADD x8, sp, #8             | X8 = (1152921510046097360 + 8) = 1152921510046097368 (0x1000000144345FD8);
            // 0x00BBD410: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBD414: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510046085472]
            // 0x00BBD418: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BBD41C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD420: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BBD424: ADD x0, sp, #8             | X0 = (1152921510046097360 + 8) = 1152921510046097368 (0x1000000144345FD8);
            // 0x00BBD428: BL #0x299a140              | 
            // 0x00BBD42C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_13:
            // 0x00BBD430: CBNZ x20, #0xbbd438        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBD434: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144345FD8, ????);
            label_14:
            // 0x00BBD438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD43C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD440: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BBD444: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBD448: CBNZ x21, #0xbbd450        | if (0x0 != 0) goto label_15;            
            if(val_17 != 0)
            {
                goto label_15;
            }
            // 0x00BBD44C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBD450: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD454: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD458: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD45C: BL #0xb28af4               | X0 = val_17.GetActionTime(aniName:  val_16);
            float val_14 = val_17.GetActionTime(aniName:  val_16);
            // 0x00BBD460: CBZ x19, #0xbbd4bc         | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x00BBD464: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BBD468: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00BBD46C: STR s0, [x19, #4]          | mem2[0] = val_14;                        //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x00BBD470: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD474: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_18 = 8;
            // 0x00BBD478: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BBD47C: TBZ w9, #0, #0xbbd48c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_17;
            // 0x00BBD480: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BBD484: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BBD488: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_18 = 219381744;
            label_17:
            // 0x00BBD48C: ADD x0, x8, x19            | X0 = (val_18 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_15 = val_18 + val_2;
            // 0x00BBD490: SUB sp, x29, #0x50         | SP = (1152921510046097456 - 80) = 1152921510046097376 (0x1000000144345FE0);
            // 0x00BBD494: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBD498: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBD49C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBD4A0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBD4A4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBD4A8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BBD4AC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_18 + val_2);
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBD4B0: MOV x19, x0                | X19 = (val_18 + val_2);//m1             
            val_19 = val_15;
            // 0x00BBD4B4: ADD x0, sp, #8             | X0 = (1152921510046097472 + 8) = 1152921510046097480 (0x1000000144346048);
            // 0x00BBD4B8: B #0xbbd4cc                |  goto label_18;                         
            goto label_18;
            label_16:
            // 0x00BBD4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x00BBD4C0: BRK #0x1                   | 
            // 0x00BBD4C4: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            val_19 = val_17;
            // 0x00BBD4C8: MOV x0, sp                 | X0 = 1152921510046097360 (0x1000000144345FD0);//ML01
            val_20;
            label_18:
            // 0x00BBD4CC: BL #0x299a140              | 
            // 0x00BBD4D0: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD4D4: BL #0x980800               | X0 = sub_980800( ?? 0x0, ????);         
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBD4D8 (12309720), len: 824  VirtAddr: 0x00BBD4D8 RVA: 0x00BBD4D8 token: 100663773 methodIndex: 29818 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetActionNormalizedTime_13(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00BBD4D8: STP x28, x27, [sp, #-0x60]! | stack[1152921510046295392] = ???;  stack[1152921510046295400] = ???;  //  dest_result_addr=1152921510046295392 |  dest_result_addr=1152921510046295400
            // 0x00BBD4DC: STP x26, x25, [sp, #0x10]  | stack[1152921510046295408] = ???;  stack[1152921510046295416] = ???;  //  dest_result_addr=1152921510046295408 |  dest_result_addr=1152921510046295416
            // 0x00BBD4E0: STP x24, x23, [sp, #0x20]  | stack[1152921510046295424] = ???;  stack[1152921510046295432] = ???;  //  dest_result_addr=1152921510046295424 |  dest_result_addr=1152921510046295432
            // 0x00BBD4E4: STP x22, x21, [sp, #0x30]  | stack[1152921510046295440] = ???;  stack[1152921510046295448] = ???;  //  dest_result_addr=1152921510046295440 |  dest_result_addr=1152921510046295448
            // 0x00BBD4E8: STP x20, x19, [sp, #0x40]  | stack[1152921510046295456] = ???;  stack[1152921510046295464] = ???;  //  dest_result_addr=1152921510046295456 |  dest_result_addr=1152921510046295464
            // 0x00BBD4EC: STP x29, x30, [sp, #0x50]  | stack[1152921510046295472] = ???;  stack[1152921510046295480] = ???;  //  dest_result_addr=1152921510046295472 |  dest_result_addr=1152921510046295480
            // 0x00BBD4F0: ADD x29, sp, #0x50         | X29 = (1152921510046295392 + 80) = 1152921510046295472 (0x10000001443765B0);
            // 0x00BBD4F4: SUB sp, sp, #0x10          | SP = (1152921510046295392 - 16) = 1152921510046295376 (0x1000000144376550);
            // 0x00BBD4F8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBD4FC: LDRB w8, [x19, #0xb69]     | W8 = (bool)static_value_03733B69;       
            // 0x00BBD500: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BBD504: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BBD508: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BBD50C: TBNZ w8, #0, #0xbbd528     | if (static_value_03733B69 == true) goto label_0;
            // 0x00BBD510: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBD514: LDR x8, [x8, #0x970]       | X8 = 0x2B8AE94;                         
            // 0x00BBD518: LDR w0, [x8]               | W0 = 0x263;                             
            // 0x00BBD51C: BL #0x2782188              | X0 = sub_2782188( ?? 0x263, ????);      
            // 0x00BBD520: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBD524: STRB w8, [x19, #0xb69]     | static_value_03733B69 = true;            //  dest_result_addr=57883497
            label_0:
            // 0x00BBD528: CBNZ x20, #0xbbd530        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBD52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x263, ????);      
            label_1:
            // 0x00BBD530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD534: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD538: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBD53C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBD540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD544: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD548: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBD54C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBD550: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD554: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BBD558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD55C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD560: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBD564: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBD568: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD56C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBD570: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBD574: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BBD578: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BBD57C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBD580: LDR x9, [x9, #0x1f0]       | X9 = 1152921504922341376;               
            // 0x00BBD584: LDR x24, [x9]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBD588: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBD58C: TBZ w9, #0, #0xbbd5a0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBD590: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD594: CBNZ w9, #0xbbd5a0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBD598: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBD59C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBD5A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD5A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD5A8: MOV x1, x24                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBD5AC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBD5B0: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x00BBD5B4: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x00BBD5B8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBD5BC: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD5C0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBD5C4: TBZ w9, #0, #0xbbd5d8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBD5C8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD5CC: CBNZ w9, #0xbbd5d8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBD5D0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBD5D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBD5D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD5DC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBD5E0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBD5E4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBD5E8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBD5EC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBD5F0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBD5F4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBD5F8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BBD5FC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBD600: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBD604: TBZ w9, #0, #0xbbd618      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBD608: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD60C: CBNZ w9, #0xbbd618         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBD610: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBD614: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBD618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD61C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD620: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBD624: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BBD628: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBD62C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBD630: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBD634: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BBD638: LDR x24, [x8]              | X24 = typeof(AnimationRunner.AniType);  
            // 0x00BBD63C: CBNZ x26, #0xbbd644        | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x00BBD640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00BBD644: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x00BBD648: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBD64C: LDR x8, [x24, #0x30]       | X8 = AnimationRunner.AniType.__il2cppRuntimeField_element_class;
            // 0x00BBD650: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationRunner.AniType.__il2cppRuntimeField_element_class)
            // 0x00BBD654: B.NE #0xbbd7d8             | if (System.Object.__il2cppRuntimeField_element_class != AnimationRunner.AniType.__il2cppRuntimeField_element_class) goto label_9;
            // 0x00BBD658: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x00BBD65C: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x00BBD660: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x00BBD664: CBNZ x20, #0xbbd66c        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BBD668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x00BBD66C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD670: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD674: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BBD678: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBD67C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD680: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD684: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BBD688: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BBD68C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD690: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00BBD694: LDR x8, [x8, #0xd80]       | X8 = 1152921504922288128;               
            // 0x00BBD698: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BBD69C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD6A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD6A4: LDR x1, [x8]               | X1 = typeof(AnimationRunner);           
            // 0x00BBD6A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBD6AC: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00BBD6B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD6B4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBD6B8: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBD6BC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBD6C0: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BBD6C4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBD6C8: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00BBD6CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD6D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD6D4: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00BBD6D8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x00BBD6DC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BBD6E0: CBZ x0, #0xbbd744          | if (val_10 == null) goto label_13;      
            if(val_10 == null)
            {
                goto label_13;
            }
            // 0x00BBD6E4: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBD6E8: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBD6EC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBD6F0: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBD6F4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD6F8: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD6FC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBD700: B.LO #0xbbd71c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBD704: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBD708: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBD70C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBD710: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBD714: MOV x21, x0                | X21 = val_10;//m1                       
            val_15 = val_10;
            // 0x00BBD718: B.EQ #0xbbd744             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBD71C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBD720: ADD x8, sp, #8             | X8 = (1152921510046295376 + 8) = 1152921510046295384 (0x1000000144376558);
            // 0x00BBD724: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBD728: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510046283488]
            // 0x00BBD72C: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BBD730: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD734: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BBD738: ADD x0, sp, #8             | X0 = (1152921510046295376 + 8) = 1152921510046295384 (0x1000000144376558);
            // 0x00BBD73C: BL #0x299a140              | 
            // 0x00BBD740: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_13:
            // 0x00BBD744: CBNZ x20, #0xbbd74c        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBD748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144376558, ????);
            label_14:
            // 0x00BBD74C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD750: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BBD754: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x00BBD758: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBD75C: CBNZ x21, #0xbbd764        | if (0x0 != 0) goto label_15;            
            if(val_15 != 0)
            {
                goto label_15;
            }
            // 0x00BBD760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBD764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD768: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            val_16 = val_15;
            // 0x00BBD76C: MOV w1, w24                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00BBD770: BL #0xb29790               | X0 = val_16.GetActionNormalizedTime(aniType:  1152921504606900224);
            float val_13 = val_16.GetActionNormalizedTime(aniType:  1152921504606900224);
            // 0x00BBD774: CBZ x19, #0xbbd7fc         | if (val_2 == 0) goto label_16;          
            if(val_2 == 0)
            {
                goto label_16;
            }
            // 0x00BBD778: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BBD77C: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00BBD780: STR s0, [x19, #4]          | mem2[0] = val_13;                        //  dest_result_addr=0
            mem2[0] = val_13;
            // 0x00BBD784: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD788: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_17 = 8;
            // 0x00BBD78C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BBD790: TBZ w9, #0, #0xbbd7a0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_17;
            // 0x00BBD794: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BBD798: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BBD79C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_17 = 219381744;
            label_17:
            // 0x00BBD7A0: ADD x0, x8, x19            | X0 = (val_17 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_14 = val_17 + val_2;
            // 0x00BBD7A4: SUB sp, x29, #0x50         | SP = (1152921510046295472 - 80) = 1152921510046295392 (0x1000000144376560);
            // 0x00BBD7A8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBD7AC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBD7B0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBD7B4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BBD7B8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BBD7BC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BBD7C0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_17 + val_2);
            return val_14;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBD7C4: MOV x19, x0                | X19 = (val_17 + val_2);//m1             
            // 0x00BBD7C8: ADD x0, sp, #8             | X0 = (1152921510046295488 + 8) = 1152921510046295496 (0x10000001443765C8);
            label_18:
            // 0x00BBD7CC: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001443765C8); //ERROR_TYPE
            // 0x00BBD7D0: MOV x0, x19                | X0 = (val_17 + val_2);//m1              
            // 0x00BBD7D4: BL #0x980800               | X0 = sub_980800( ?? (val_17 + val_2), ????);
            label_9:
            // 0x00BBD7D8: MOV x8, sp                 | X8 = 1152921510046295488 (0x10000001443765C0);//ML01
            // 0x00BBD7DC: MOV x1, x24                | X1 = X24;//m1                           
            // 0x00BBD7E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (val_17 + val_2), ????);
            // 0x00BBD7E4: LDR x0, [sp]               | X0 = __esp;                             
            // 0x00BBD7E8: BL #0x27af090              | X0 = sub_27AF090( ?? __esp, ????);      
            // 0x00BBD7EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD7F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __esp, ????);      
            // 0x00BBD7F4: MOV x0, sp                 | X0 = 1152921510046295488 (0x10000001443765C0);//ML01
            // 0x00BBD7F8: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)typeof(ILRuntime.Runtime.Stack.StackObject*));
            label_16:
            // 0x00BBD7FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (ILRuntime.Runtime.Stack.StackObject*)[1152921510046380448], ????);
            // 0x00BBD800: BRK #0x1                   | 
            // 0x00BBD804: MOV x19, x0                | X19 = 1152921510046380448 (0x100000014438B1A0);//ML01
            // 0x00BBD808: MOV x0, sp                 | X0 = 1152921510046295488 (0x10000001443765C0);//ML01
            // 0x00BBD80C: B #0xbbd7cc                |  goto label_18;                         
            goto label_18;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBD810 (12310544), len: 528  VirtAddr: 0x00BBD810 RVA: 0x00BBD810 token: 100663774 methodIndex: 29819 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* playOver_14(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BBD810: STP x24, x23, [sp, #-0x40]! | stack[1152921510046481152] = ???;  stack[1152921510046481160] = ???;  //  dest_result_addr=1152921510046481152 |  dest_result_addr=1152921510046481160
            // 0x00BBD814: STP x22, x21, [sp, #0x10]  | stack[1152921510046481168] = ???;  stack[1152921510046481176] = ???;  //  dest_result_addr=1152921510046481168 |  dest_result_addr=1152921510046481176
            // 0x00BBD818: STP x20, x19, [sp, #0x20]  | stack[1152921510046481184] = ???;  stack[1152921510046481192] = ???;  //  dest_result_addr=1152921510046481184 |  dest_result_addr=1152921510046481192
            // 0x00BBD81C: STP x29, x30, [sp, #0x30]  | stack[1152921510046481200] = ???;  stack[1152921510046481208] = ???;  //  dest_result_addr=1152921510046481200 |  dest_result_addr=1152921510046481208
            // 0x00BBD820: ADD x29, sp, #0x30         | X29 = (1152921510046481152 + 48) = 1152921510046481200 (0x10000001443A3B30);
            // 0x00BBD824: SUB sp, sp, #0x10          | SP = (1152921510046481152 - 16) = 1152921510046481136 (0x10000001443A3AF0);
            // 0x00BBD828: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBD82C: LDRB w8, [x20, #0xb6a]     | W8 = (bool)static_value_03733B6A;       
            // 0x00BBD830: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BBD834: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BBD838: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBD83C: TBNZ w8, #0, #0xbbd858     | if (static_value_03733B6A == true) goto label_0;
            // 0x00BBD840: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BBD844: LDR x8, [x8, #0x870]       | X8 = 0x2B8AEB8;                         
            // 0x00BBD848: LDR w0, [x8]               | W0 = 0x26C;                             
            // 0x00BBD84C: BL #0x2782188              | X0 = sub_2782188( ?? 0x26C, ????);      
            // 0x00BBD850: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBD854: STRB w8, [x20, #0xb6a]     | static_value_03733B6A = true;            //  dest_result_addr=57883498
            label_0:
            // 0x00BBD858: CBNZ x19, #0xbbd860        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBD85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x26C, ????);      
            label_1:
            // 0x00BBD860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD864: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBD868: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBD86C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBD870: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD874: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD878: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBD87C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBD880: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD884: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBD888: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD88C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD890: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBD894: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBD898: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBD89C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBD8A0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBD8A4: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBD8A8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BBD8AC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBD8B0: LDR x9, [x9, #0xd80]       | X9 = 1152921504922288128;               
            // 0x00BBD8B4: LDR x24, [x9]              | X24 = typeof(AnimationRunner);          
            // 0x00BBD8B8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBD8BC: TBZ w9, #0, #0xbbd8d0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBD8C0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD8C4: CBNZ w9, #0xbbd8d0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBD8C8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBD8CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBD8D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD8D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD8D8: MOV x1, x24                | X1 = 1152921504922288128 (0x1000000012CD4000);//ML01
            // 0x00BBD8DC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBD8E0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBD8E4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBD8E8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBD8EC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBD8F0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBD8F4: TBZ w9, #0, #0xbbd908      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBD8F8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD8FC: CBNZ w9, #0xbbd908         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBD900: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBD904: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBD908: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD90C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBD910: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BBD914: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBD918: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BBD91C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBD920: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBD924: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBD928: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BBD92C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBD930: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBD934: TBZ w9, #0, #0xbbd948      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBD938: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBD93C: CBNZ w9, #0xbbd948         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBD940: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBD944: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBD948: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD94C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBD950: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBD954: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BBD958: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBD95C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BBD960: CBZ x0, #0xbbd9c4          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BBD964: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBD968: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBD96C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBD970: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBD974: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD978: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBD97C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBD980: B.LO #0xbbd99c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BBD984: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBD988: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBD98C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBD990: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBD994: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BBD998: B.EQ #0xbbd9c4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BBD99C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBD9A0: ADD x8, sp, #8             | X8 = (1152921510046481136 + 8) = 1152921510046481144 (0x10000001443A3AF8);
            // 0x00BBD9A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBD9A8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510046469216]
            // 0x00BBD9AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BBD9B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD9B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BBD9B8: ADD x0, sp, #8             | X0 = (1152921510046481136 + 8) = 1152921510046481144 (0x10000001443A3AF8);
            // 0x00BBD9BC: BL #0x299a140              | 
            // 0x00BBD9C0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BBD9C4: CBNZ x19, #0xbbd9cc        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBD9C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001443A3AF8, ????);
            label_11:
            // 0x00BBD9CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBD9D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBD9D4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BBD9D8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBD9DC: CBNZ x22, #0xbbd9e4        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BBD9E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BBD9E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBD9E8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BBD9EC: BL #0xb2841c               | val_9.playOver();                       
            val_9.playOver();
            // 0x00BBD9F0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBD9F4: SUB sp, x29, #0x30         | SP = (1152921510046481200 - 48) = 1152921510046481152 (0x10000001443A3B00);
            // 0x00BBD9F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBD9FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBDA00: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBDA04: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BBDA08: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBDA0C: MOV x19, x0                | 
            // 0x00BBDA10: ADD x0, sp, #8             | 
            // 0x00BBDA14: BL #0x299a140              | 
            // 0x00BBDA18: MOV x0, x19                | 
            // 0x00BBDA1C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBDA20 (12311072), len: 528  VirtAddr: 0x00BBDA20 RVA: 0x00BBDA20 token: 100663775 methodIndex: 29820 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Clear_15(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BBDA20: STP x24, x23, [sp, #-0x40]! | stack[1152921510046650496] = ???;  stack[1152921510046650504] = ???;  //  dest_result_addr=1152921510046650496 |  dest_result_addr=1152921510046650504
            // 0x00BBDA24: STP x22, x21, [sp, #0x10]  | stack[1152921510046650512] = ???;  stack[1152921510046650520] = ???;  //  dest_result_addr=1152921510046650512 |  dest_result_addr=1152921510046650520
            // 0x00BBDA28: STP x20, x19, [sp, #0x20]  | stack[1152921510046650528] = ???;  stack[1152921510046650536] = ???;  //  dest_result_addr=1152921510046650528 |  dest_result_addr=1152921510046650536
            // 0x00BBDA2C: STP x29, x30, [sp, #0x30]  | stack[1152921510046650544] = ???;  stack[1152921510046650552] = ???;  //  dest_result_addr=1152921510046650544 |  dest_result_addr=1152921510046650552
            // 0x00BBDA30: ADD x29, sp, #0x30         | X29 = (1152921510046650496 + 48) = 1152921510046650544 (0x10000001443CD0B0);
            // 0x00BBDA34: SUB sp, sp, #0x10          | SP = (1152921510046650496 - 16) = 1152921510046650480 (0x10000001443CD070);
            // 0x00BBDA38: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBDA3C: LDRB w8, [x20, #0xb6b]     | W8 = (bool)static_value_03733B6B;       
            // 0x00BBDA40: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BBDA44: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BBDA48: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBDA4C: TBNZ w8, #0, #0xbbda68     | if (static_value_03733B6B == true) goto label_0;
            // 0x00BBDA50: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00BBDA54: LDR x8, [x8, #0xe8]        | X8 = 0x2B8AE80;                         
            // 0x00BBDA58: LDR w0, [x8]               | W0 = 0x25E;                             
            // 0x00BBDA5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x25E, ????);      
            // 0x00BBDA60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBDA64: STRB w8, [x20, #0xb6b]     | static_value_03733B6B = true;            //  dest_result_addr=57883499
            label_0:
            // 0x00BBDA68: CBNZ x19, #0xbbda70        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BBDA6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x25E, ????);      
            label_1:
            // 0x00BBDA70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDA74: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBDA78: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BBDA7C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BBDA80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBDA84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBDA88: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBDA8C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBDA90: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBDA94: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BBDA98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBDA9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBDAA0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BBDAA4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BBDAA8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BBDAAC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBDAB0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBDAB4: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x00BBDAB8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BBDABC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BBDAC0: LDR x9, [x9, #0xd80]       | X9 = 1152921504922288128;               
            // 0x00BBDAC4: LDR x24, [x9]              | X24 = typeof(AnimationRunner);          
            // 0x00BBDAC8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBDACC: TBZ w9, #0, #0xbbdae0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BBDAD0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBDAD4: CBNZ w9, #0xbbdae0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BBDAD8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BBDADC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BBDAE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBDAE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBDAE8: MOV x1, x24                | X1 = 1152921504922288128 (0x1000000012CD4000);//ML01
            // 0x00BBDAEC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBDAF0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BBDAF4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BBDAF8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BBDAFC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BBDB00: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BBDB04: TBZ w9, #0, #0xbbdb18      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BBDB08: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BBDB0C: CBNZ w9, #0xbbdb18         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BBDB10: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BBDB14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BBDB18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBDB1C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBDB20: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BBDB24: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BBDB28: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BBDB2C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BBDB30: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BBDB34: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BBDB38: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BBDB3C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BBDB40: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BBDB44: TBZ w9, #0, #0xbbdb58      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BBDB48: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BBDB4C: CBNZ w9, #0xbbdb58         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BBDB50: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BBDB54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BBDB58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBDB5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBDB60: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BBDB64: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BBDB68: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BBDB6C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BBDB70: CBZ x0, #0xbbdbd4          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BBDB74: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BBDB78: LDR x9, [x9, #0x188]       | X9 = 1152921504922288128;               
            // 0x00BBDB7C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BBDB80: LDR x1, [x9]               | X1 = typeof(AnimationRunner);           
            // 0x00BBDB84: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDB88: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDB8C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDB90: B.LO #0xbbdbac             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BBDB94: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBDB98: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeH
            // 0x00BBDB9C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDBA0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDBA4: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BBDBA8: B.EQ #0xbbdbd4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BBDBAC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BBDBB0: ADD x8, sp, #8             | X8 = (1152921510046650480 + 8) = 1152921510046650488 (0x10000001443CD078);
            // 0x00BBDBB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BBDBB8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510046638560]
            // 0x00BBDBBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BBDBC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDBC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BBDBC8: ADD x0, sp, #8             | X0 = (1152921510046650480 + 8) = 1152921510046650488 (0x10000001443CD078);
            // 0x00BBDBCC: BL #0x299a140              | 
            // 0x00BBDBD0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BBDBD4: CBNZ x19, #0xbbdbdc        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBDBD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001443CD078, ????);
            label_11:
            // 0x00BBDBDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBDBE0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBDBE4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BBDBE8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BBDBEC: CBNZ x22, #0xbbdbf4        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BBDBF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BBDBF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDBF8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BBDBFC: BL #0xb29914               | val_9.Clear();                          
            val_9.Clear();
            // 0x00BBDC00: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BBDC04: SUB sp, x29, #0x30         | SP = (1152921510046650544 - 48) = 1152921510046650496 (0x10000001443CD080);
            // 0x00BBDC08: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBDC0C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBDC10: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBDC14: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BBDC18: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BBDC1C: MOV x19, x0                | 
            // 0x00BBDC20: ADD x0, sp, #8             | 
            // 0x00BBDC24: BL #0x299a140              | 
            // 0x00BBDC28: MOV x0, x19                | 
            // 0x00BBDC2C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBDC30 (12311600), len: 288  VirtAddr: 0x00BBDC30 RVA: 0x00BBDC30 token: 100663776 methodIndex: 29821 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_curAniName_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BBDC30: STP x20, x19, [sp, #-0x20]! | stack[1152921510046795216] = ???;  stack[1152921510046795224] = ???;  //  dest_result_addr=1152921510046795216 |  dest_result_addr=1152921510046795224
            // 0x00BBDC34: STP x29, x30, [sp, #0x10]  | stack[1152921510046795232] = ???;  stack[1152921510046795240] = ???;  //  dest_result_addr=1152921510046795232 |  dest_result_addr=1152921510046795240
            // 0x00BBDC38: ADD x29, sp, #0x10         | X29 = (1152921510046795216 + 16) = 1152921510046795232 (0x10000001443F05E0);
            // 0x00BBDC3C: SUB sp, sp, #0x10          | SP = (1152921510046795216 - 16) = 1152921510046795200 (0x10000001443F05C0);
            // 0x00BBDC40: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBDC44: LDRB w8, [x20, #0xb6c]     | W8 = (bool)static_value_03733B6C;       
            // 0x00BBDC48: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBDC4C: TBNZ w8, #0, #0xbbdc68     | if (static_value_03733B6C == true) goto label_0;
            // 0x00BBDC50: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x00BBDC54: LDR x8, [x8, #0xe90]       | X8 = 0x2B8AE88;                         
            // 0x00BBDC58: LDR w0, [x8]               | W0 = 0x260;                             
            // 0x00BBDC5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x260, ????);      
            // 0x00BBDC60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBDC64: STRB w8, [x20, #0xb6c]     | static_value_03733B6C = true;            //  dest_result_addr=57883500
            label_0:
            // 0x00BBDC68: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BBDC6C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BBDC70: LDR x20, [x20, #0x188]     | X20 = 1152921504922288128;              
            // 0x00BBDC74: CBZ x19, #0xbbdcc8         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BBDC78: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BBDC7C: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBDC80: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BBDC84: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDC88: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDC8C: B.LO #0xbbdca4             | if (X1 + 260 < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BBDC90: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BBDC94: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBDC98: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDC9C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDCA0: B.EQ #0xbbdccc             | if ((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BBDCA4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BBDCA8: MOV x8, sp                 | X8 = 1152921510046795200 (0x10000001443F05C0);//ML01
            // 0x00BBDCAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BBDCB0: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510046783248]
            // 0x00BBDCB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BBDCB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDCBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BBDCC0: MOV x0, sp                 | X0 = 1152921510046795200 (0x10000001443F05C0);//ML01
            // 0x00BBDCC4: BL #0x299a140              | 
            label_1:
            // 0x00BBDCC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001443F05C0, ????);
            label_3:
            // 0x00BBDCCC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BBDCD0: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBDCD4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BBDCD8: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDCDC: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDCE0: B.LO #0xbbdd0c             | if (X1 + 260 < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BBDCE4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BBDCE8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBDCEC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDCF0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDCF4: B.NE #0xbbdd0c             | if ((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BBDCF8: LDR x0, [x19, #0x30]       | X0 = X1 + 48;                           
            // 0x00BBDCFC: SUB sp, x29, #0x10         | SP = (1152921510046795232 - 16) = 1152921510046795216 (0x10000001443F05D0);
            // 0x00BBDD00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBDD04: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBDD08: RET                        |  return (System.Object)X1 + 48;         
            return (object)X1 + 48;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BBDD0C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BBDD10: ADD x8, sp, #8             | X8 = (1152921510046795200 + 8) = 1152921510046795208 (0x10000001443F05C8);
            // 0x00BBDD14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BBDD18: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510046783248]
            // 0x00BBDD1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBDD20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDD24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBDD28: ADD x0, sp, #8             | X0 = (1152921510046795200 + 8) = 1152921510046795208 (0x10000001443F05C8);
            // 0x00BBDD2C: BL #0x299a140              | 
            // 0x00BBDD30: MOV x19, x0                | X19 = 1152921510046795208 (0x10000001443F05C8);//ML01
            // 0x00BBDD34: MOV x0, sp                 | X0 = 1152921510046795200 (0x10000001443F05C0);//ML01
            label_6:
            // 0x00BBDD38: BL #0x299a140              | 
            // 0x00BBDD3C: MOV x0, x19                | X0 = 1152921510046795208 (0x10000001443F05C8);//ML01
            // 0x00BBDD40: BL #0x980800               | X0 = sub_980800( ?? 0x10000001443F05C8, ????);
            // 0x00BBDD44: MOV x19, x0                | X19 = 1152921510046795208 (0x10000001443F05C8);//ML01
            // 0x00BBDD48: ADD x0, sp, #8             | X0 = (1152921510046795200 + 8) = 1152921510046795208 (0x10000001443F05C8);
            // 0x00BBDD4C: B #0xbbdd38                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBDD50 (12311888), len: 392  VirtAddr: 0x00BBDD50 RVA: 0x00BBDD50 token: 100663777 methodIndex: 29822 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_curAniName_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BBDD50: STP x22, x21, [sp, #-0x30]! | stack[1152921510046919328] = ???;  stack[1152921510046919336] = ???;  //  dest_result_addr=1152921510046919328 |  dest_result_addr=1152921510046919336
            // 0x00BBDD54: STP x20, x19, [sp, #0x10]  | stack[1152921510046919344] = ???;  stack[1152921510046919352] = ???;  //  dest_result_addr=1152921510046919344 |  dest_result_addr=1152921510046919352
            // 0x00BBDD58: STP x29, x30, [sp, #0x20]  | stack[1152921510046919360] = ???;  stack[1152921510046919368] = ???;  //  dest_result_addr=1152921510046919360 |  dest_result_addr=1152921510046919368
            // 0x00BBDD5C: ADD x29, sp, #0x20         | X29 = (1152921510046919328 + 32) = 1152921510046919360 (0x100000014440EAC0);
            // 0x00BBDD60: SUB sp, sp, #0x20          | SP = (1152921510046919328 - 32) = 1152921510046919296 (0x100000014440EA80);
            // 0x00BBDD64: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BBDD68: LDRB w8, [x21, #0xb6d]     | W8 = (bool)static_value_03733B6D;       
            // 0x00BBDD6C: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BBDD70: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BBDD74: TBNZ w8, #0, #0xbbdd90     | if (static_value_03733B6D == true) goto label_0;
            // 0x00BBDD78: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00BBDD7C: LDR x8, [x8, #0xa0]        | X8 = 0x2B8AEC4;                         
            // 0x00BBDD80: LDR w0, [x8]               | W0 = 0x26F;                             
            // 0x00BBDD84: BL #0x2782188              | X0 = sub_2782188( ?? 0x26F, ????);      
            // 0x00BBDD88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBDD8C: STRB w8, [x21, #0xb6d]     | static_value_03733B6D = true;            //  dest_result_addr=57883501
            label_0:
            // 0x00BBDD90: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BBDD94: CBZ x20, #0xbbde48         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BBDD98: ADRP x21, #0x364f000       | X21 = 56946688 (0x364F000);             
            // 0x00BBDD9C: LDR x21, [x21, #0x188]     | X21 = 1152921504922288128;              
            val_6 = 1152921504922288128;
            // 0x00BBDDA0: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BBDDA4: LDR x1, [x21]              | X1 = typeof(AnimationRunner);           
            // 0x00BBDDA8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BBDDAC: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDDB0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDDB4: B.LO #0xbbddcc             | if (mem[null + 260] < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BBDDB8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BBDDBC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBDDC0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDDC4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDDC8: B.EQ #0xbbddf4             | if ((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BBDDCC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBDDD0: ADD x8, sp, #8             | X8 = (1152921510046919296 + 8) = 1152921510046919304 (0x100000014440EA88);
            // 0x00BBDDD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BBDDD8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510046907376]
            // 0x00BBDDDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BBDDE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDDE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BBDDE8: ADD x0, sp, #8             | X0 = (1152921510046919296 + 8) = 1152921510046919304 (0x100000014440EA88);
            // 0x00BBDDEC: BL #0x299a140              | 
            // 0x00BBDDF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014440EA88, ????);
            label_3:
            // 0x00BBDDF4: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BBDDF8: LDR x1, [x21]              | X1 = typeof(AnimationRunner);           
            // 0x00BBDDFC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BBDE00: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDE04: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDE08: B.LO #0xbbde20             | if (mem[null + 260] < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BBDE0C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BBDE10: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBDE14: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDE18: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDE1C: B.EQ #0xbbde50             | if ((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BBDE20: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBDE24: ADD x8, sp, #0x10          | X8 = (1152921510046919296 + 16) = 1152921510046919312 (0x100000014440EA90);
            // 0x00BBDE28: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BBDE2C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510046907376]
            // 0x00BBDE30: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBDE34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDE38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBDE3C: ADD x0, sp, #0x10          | X0 = (1152921510046919296 + 16) = 1152921510046919312 (0x100000014440EA90);
            // 0x00BBDE40: BL #0x299a140              | 
            // 0x00BBDE44: B #0xbbde4c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BBDE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x26F, ????);      
            label_6:
            // 0x00BBDE4C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x00BBDE50: CBZ x19, #0xbbde90         | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x00BBDE54: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BBDE58: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BBDE5C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BBDE60: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BBDE64: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x00BBDE68: B.EQ #0xbbde94             | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x00BBDE6C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BBDE70: ADD x8, sp, #0x18          | X8 = (1152921510046919296 + 24) = 1152921510046919320 (0x100000014440EA98);
            // 0x00BBDE74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BBDE78: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510046907376]
            // 0x00BBDE7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BBDE80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDE84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BBDE88: ADD x0, sp, #0x18          | X0 = (1152921510046919296 + 24) = 1152921510046919320 (0x100000014440EA98);
            // 0x00BBDE8C: BL #0x299a140              | 
            label_7:
            // 0x00BBDE90: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x00BBDE94: STR x19, [x20, #0x30]      | mem[48] = 0x0;                           //  dest_result_addr=48
            mem[48] = val_7;
            // 0x00BBDE98: SUB sp, x29, #0x20         | SP = (1152921510046919360 - 32) = 1152921510046919328 (0x100000014440EAA0);
            // 0x00BBDE9C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBDEA0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBDEA4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BBDEA8: RET                        |  return;                                
            return;
            // 0x00BBDEAC: MOV x19, x0                | 
            // 0x00BBDEB0: ADD x0, sp, #8             | 
            // 0x00BBDEB4: B #0xbbdecc                | 
            // 0x00BBDEB8: MOV x19, x0                | 
            // 0x00BBDEBC: ADD x0, sp, #0x10          | 
            // 0x00BBDEC0: B #0xbbdecc                | 
            // 0x00BBDEC4: MOV x19, x0                | 
            // 0x00BBDEC8: ADD x0, sp, #0x18          | 
            label_10:
            // 0x00BBDECC: BL #0x299a140              | 
            // 0x00BBDED0: MOV x0, x19                | 
            // 0x00BBDED4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBDED8 (12312280), len: 288  VirtAddr: 0x00BBDED8 RVA: 0x00BBDED8 token: 100663778 methodIndex: 29823 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_unit_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BBDED8: STP x20, x19, [sp, #-0x20]! | stack[1152921510047043472] = ???;  stack[1152921510047043480] = ???;  //  dest_result_addr=1152921510047043472 |  dest_result_addr=1152921510047043480
            // 0x00BBDEDC: STP x29, x30, [sp, #0x10]  | stack[1152921510047043488] = ???;  stack[1152921510047043496] = ???;  //  dest_result_addr=1152921510047043488 |  dest_result_addr=1152921510047043496
            // 0x00BBDEE0: ADD x29, sp, #0x10         | X29 = (1152921510047043472 + 16) = 1152921510047043488 (0x100000014442CFA0);
            // 0x00BBDEE4: SUB sp, sp, #0x10          | SP = (1152921510047043472 - 16) = 1152921510047043456 (0x100000014442CF80);
            // 0x00BBDEE8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBDEEC: LDRB w8, [x20, #0xb6e]     | W8 = (bool)static_value_03733B6E;       
            // 0x00BBDEF0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBDEF4: TBNZ w8, #0, #0xbbdf10     | if (static_value_03733B6E == true) goto label_0;
            // 0x00BBDEF8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00BBDEFC: LDR x8, [x8, #0x238]       | X8 = 0x2B8AE90;                         
            // 0x00BBDF00: LDR w0, [x8]               | W0 = 0x262;                             
            // 0x00BBDF04: BL #0x2782188              | X0 = sub_2782188( ?? 0x262, ????);      
            // 0x00BBDF08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBDF0C: STRB w8, [x20, #0xb6e]     | static_value_03733B6E = true;            //  dest_result_addr=57883502
            label_0:
            // 0x00BBDF10: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BBDF14: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BBDF18: LDR x20, [x20, #0x188]     | X20 = 1152921504922288128;              
            // 0x00BBDF1C: CBZ x19, #0xbbdf70         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BBDF20: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BBDF24: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBDF28: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BBDF2C: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDF30: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDF34: B.LO #0xbbdf4c             | if (X1 + 260 < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BBDF38: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BBDF3C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBDF40: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDF44: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDF48: B.EQ #0xbbdf74             | if ((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BBDF4C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BBDF50: MOV x8, sp                 | X8 = 1152921510047043456 (0x100000014442CF80);//ML01
            // 0x00BBDF54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BBDF58: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510047031504]
            // 0x00BBDF5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BBDF60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDF64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BBDF68: MOV x0, sp                 | X0 = 1152921510047043456 (0x100000014442CF80);//ML01
            // 0x00BBDF6C: BL #0x299a140              | 
            label_1:
            // 0x00BBDF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014442CF80, ????);
            label_3:
            // 0x00BBDF74: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BBDF78: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBDF7C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BBDF80: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBDF84: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBDF88: B.LO #0xbbdfb4             | if (X1 + 260 < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BBDF8C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BBDF90: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBDF94: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBDF98: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBDF9C: B.NE #0xbbdfb4             | if ((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BBDFA0: LDR x0, [x19, #0x38]       | X0 = X1 + 56;                           
            // 0x00BBDFA4: SUB sp, x29, #0x10         | SP = (1152921510047043488 - 16) = 1152921510047043472 (0x100000014442CF90);
            // 0x00BBDFA8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBDFAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBDFB0: RET                        |  return (System.Object)X1 + 56;         
            return (object)X1 + 56;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BBDFB4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BBDFB8: ADD x8, sp, #8             | X8 = (1152921510047043456 + 8) = 1152921510047043464 (0x100000014442CF88);
            // 0x00BBDFBC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BBDFC0: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510047031504]
            // 0x00BBDFC4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBDFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBDFCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBDFD0: ADD x0, sp, #8             | X0 = (1152921510047043456 + 8) = 1152921510047043464 (0x100000014442CF88);
            // 0x00BBDFD4: BL #0x299a140              | 
            // 0x00BBDFD8: MOV x19, x0                | X19 = 1152921510047043464 (0x100000014442CF88);//ML01
            // 0x00BBDFDC: MOV x0, sp                 | X0 = 1152921510047043456 (0x100000014442CF80);//ML01
            label_6:
            // 0x00BBDFE0: BL #0x299a140              | 
            // 0x00BBDFE4: MOV x0, x19                | X0 = 1152921510047043464 (0x100000014442CF88);//ML01
            // 0x00BBDFE8: BL #0x980800               | X0 = sub_980800( ?? 0x100000014442CF88, ????);
            // 0x00BBDFEC: MOV x19, x0                | X19 = 1152921510047043464 (0x100000014442CF88);//ML01
            // 0x00BBDFF0: ADD x0, sp, #8             | X0 = (1152921510047043456 + 8) = 1152921510047043464 (0x100000014442CF88);
            // 0x00BBDFF4: B #0xbbdfe0                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBDFF8 (12312568), len: 420  VirtAddr: 0x00BBDFF8 RVA: 0x00BBDFF8 token: 100663779 methodIndex: 29824 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_unit_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BBDFF8: STP x22, x21, [sp, #-0x30]! | stack[1152921510047167584] = ???;  stack[1152921510047167592] = ???;  //  dest_result_addr=1152921510047167584 |  dest_result_addr=1152921510047167592
            // 0x00BBDFFC: STP x20, x19, [sp, #0x10]  | stack[1152921510047167600] = ???;  stack[1152921510047167608] = ???;  //  dest_result_addr=1152921510047167600 |  dest_result_addr=1152921510047167608
            // 0x00BBE000: STP x29, x30, [sp, #0x20]  | stack[1152921510047167616] = ???;  stack[1152921510047167624] = ???;  //  dest_result_addr=1152921510047167616 |  dest_result_addr=1152921510047167624
            // 0x00BBE004: ADD x29, sp, #0x20         | X29 = (1152921510047167584 + 32) = 1152921510047167616 (0x100000014444B480);
            // 0x00BBE008: SUB sp, sp, #0x20          | SP = (1152921510047167584 - 32) = 1152921510047167552 (0x100000014444B440);
            // 0x00BBE00C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BBE010: LDRB w8, [x21, #0xb6f]     | W8 = (bool)static_value_03733B6F;       
            // 0x00BBE014: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00BBE018: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BBE01C: TBNZ w8, #0, #0xbbe038     | if (static_value_03733B6F == true) goto label_0;
            // 0x00BBE020: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00BBE024: LDR x8, [x8, #0x520]       | X8 = 0x2B8AECC;                         
            // 0x00BBE028: LDR w0, [x8]               | W0 = 0x271;                             
            // 0x00BBE02C: BL #0x2782188              | X0 = sub_2782188( ?? 0x271, ????);      
            // 0x00BBE030: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBE034: STRB w8, [x21, #0xb6f]     | static_value_03733B6F = true;            //  dest_result_addr=57883503
            label_0:
            // 0x00BBE038: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BBE03C: CBZ x20, #0xbbe0f0         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BBE040: ADRP x21, #0x364f000       | X21 = 56946688 (0x364F000);             
            // 0x00BBE044: LDR x21, [x21, #0x188]     | X21 = 1152921504922288128;              
            val_7 = 1152921504922288128;
            // 0x00BBE048: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BBE04C: LDR x1, [x21]              | X1 = typeof(AnimationRunner);           
            // 0x00BBE050: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BBE054: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE058: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE05C: B.LO #0xbbe074             | if (mem[null + 260] < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BBE060: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BBE064: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE068: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE06C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBE070: B.EQ #0xbbe09c             | if ((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BBE074: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBE078: ADD x8, sp, #8             | X8 = (1152921510047167552 + 8) = 1152921510047167560 (0x100000014444B448);
            // 0x00BBE07C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BBE080: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510047155632]
            // 0x00BBE084: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BBE088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE08C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BBE090: ADD x0, sp, #8             | X0 = (1152921510047167552 + 8) = 1152921510047167560 (0x100000014444B448);
            // 0x00BBE094: BL #0x299a140              | 
            // 0x00BBE098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014444B448, ????);
            label_3:
            // 0x00BBE09C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BBE0A0: LDR x1, [x21]              | X1 = typeof(AnimationRunner);           
            // 0x00BBE0A4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BBE0A8: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE0AC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE0B0: B.LO #0xbbe0c8             | if (mem[null + 260] < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BBE0B4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BBE0B8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE0BC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE0C0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBE0C4: B.EQ #0xbbe0f8             | if ((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BBE0C8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBE0CC: ADD x8, sp, #0x10          | X8 = (1152921510047167552 + 16) = 1152921510047167568 (0x100000014444B450);
            // 0x00BBE0D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BBE0D4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510047155632]
            // 0x00BBE0D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBE0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE0E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBE0E4: ADD x0, sp, #0x10          | X0 = (1152921510047167552 + 16) = 1152921510047167568 (0x100000014444B450);
            // 0x00BBE0E8: BL #0x299a140              | 
            // 0x00BBE0EC: B #0xbbe0f4                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BBE0F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x271, ????);      
            label_6:
            // 0x00BBE0F4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x00BBE0F8: CBZ x19, #0xbbe154         | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00BBE0FC: ADRP x9, #0x35d2000        | X9 = 56434688 (0x35D2000);              
            // 0x00BBE100: LDR x9, [x9, #0x298]       | X9 = 1152921504891883520;               
            // 0x00BBE104: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BBE108: LDR x1, [x9]               | X1 = typeof(CombatEntity);              
            // 0x00BBE10C: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x00BBE110: LDRB w9, [x1, #0x104]      | W9 = CombatEntity.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE114: CMP w10, w9                | STATE = COMPARE(X2 + 260, CombatEntity.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE118: B.LO #0xbbe130             | if (X2 + 260 < CombatEntity.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00BBE11C: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x00BBE120: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (CombatEntity.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE124: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (CombatEntity.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE128: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (CombatEntity.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CombatEntity))
            // 0x00BBE12C: B.EQ #0xbbe158             | if ((X2 + 176 + (CombatEntity.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00BBE130: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BBE134: ADD x8, sp, #0x18          | X8 = (1152921510047167552 + 24) = 1152921510047167576 (0x100000014444B458);
            // 0x00BBE138: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BBE13C: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510047155632]
            // 0x00BBE140: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BBE144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE148: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BBE14C: ADD x0, sp, #0x18          | X0 = (1152921510047167552 + 24) = 1152921510047167576 (0x100000014444B458);
            // 0x00BBE150: BL #0x299a140              | 
            label_7:
            // 0x00BBE154: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BBE158: STR x19, [x20, #0x38]      | mem[56] = 0x0;                           //  dest_result_addr=56
            mem[56] = val_8;
            // 0x00BBE15C: SUB sp, x29, #0x20         | SP = (1152921510047167616 - 32) = 1152921510047167584 (0x100000014444B460);
            // 0x00BBE160: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBE164: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBE168: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BBE16C: RET                        |  return;                                
            return;
            // 0x00BBE170: MOV x19, x0                | 
            // 0x00BBE174: ADD x0, sp, #8             | 
            // 0x00BBE178: B #0xbbe190                | 
            // 0x00BBE17C: MOV x19, x0                | 
            // 0x00BBE180: ADD x0, sp, #0x10          | 
            // 0x00BBE184: B #0xbbe190                | 
            // 0x00BBE188: MOV x19, x0                | 
            // 0x00BBE18C: ADD x0, sp, #0x18          | 
            label_11:
            // 0x00BBE190: BL #0x299a140              | 
            // 0x00BBE194: MOV x0, x19                | 
            // 0x00BBE198: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBE19C (12312988), len: 312  VirtAddr: 0x00BBE19C RVA: 0x00BBE19C token: 100663780 methodIndex: 29825 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_isSkillFrozen_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BBE19C: STP x20, x19, [sp, #-0x20]! | stack[1152921510047295824] = ???;  stack[1152921510047295832] = ???;  //  dest_result_addr=1152921510047295824 |  dest_result_addr=1152921510047295832
            // 0x00BBE1A0: STP x29, x30, [sp, #0x10]  | stack[1152921510047295840] = ???;  stack[1152921510047295848] = ???;  //  dest_result_addr=1152921510047295840 |  dest_result_addr=1152921510047295848
            // 0x00BBE1A4: ADD x29, sp, #0x10         | X29 = (1152921510047295824 + 16) = 1152921510047295840 (0x100000014446A960);
            // 0x00BBE1A8: SUB sp, sp, #0x20          | SP = (1152921510047295824 - 32) = 1152921510047295792 (0x100000014446A930);
            // 0x00BBE1AC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBE1B0: LDRB w8, [x20, #0xb70]     | W8 = (bool)static_value_03733B70;       
            // 0x00BBE1B4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBE1B8: TBNZ w8, #0, #0xbbe1d4     | if (static_value_03733B70 == true) goto label_0;
            // 0x00BBE1BC: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BBE1C0: LDR x8, [x8, #0x5e8]       | X8 = 0x2B8AE8C;                         
            // 0x00BBE1C4: LDR w0, [x8]               | W0 = 0x261;                             
            // 0x00BBE1C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x261, ????);      
            // 0x00BBE1CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBE1D0: STRB w8, [x20, #0xb70]     | static_value_03733B70 = true;            //  dest_result_addr=57883504
            label_0:
            // 0x00BBE1D4: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BBE1D8: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BBE1DC: LDR x20, [x20, #0x188]     | X20 = 1152921504922288128;              
            // 0x00BBE1E0: CBZ x19, #0xbbe234         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BBE1E4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BBE1E8: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBE1EC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BBE1F0: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE1F4: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE1F8: B.LO #0xbbe210             | if (X1 + 260 < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BBE1FC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BBE200: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE204: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE208: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBE20C: B.EQ #0xbbe238             | if ((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BBE210: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BBE214: ADD x8, sp, #0x10          | X8 = (1152921510047295792 + 16) = 1152921510047295808 (0x100000014446A940);
            // 0x00BBE218: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BBE21C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510047283856]
            // 0x00BBE220: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BBE224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE228: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BBE22C: ADD x0, sp, #0x10          | X0 = (1152921510047295792 + 16) = 1152921510047295808 (0x100000014446A940);
            // 0x00BBE230: BL #0x299a140              | 
            label_1:
            // 0x00BBE234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014446A940, ????);
            label_3:
            // 0x00BBE238: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BBE23C: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBE240: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BBE244: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE248: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE24C: B.LO #0xbbe290             | if (X1 + 260 < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BBE250: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BBE254: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE258: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE25C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBE260: B.NE #0xbbe290             | if ((X1 + 176 + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BBE264: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x00BBE268: LDRB w8, [x19, #0x59]      | W8 = X1 + 89;                           
            // 0x00BBE26C: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x00BBE270: ADD x1, sp, #0xf           | X1 = (1152921510047295792 + 15) = 1152921510047295807 (0x100000014446A93F);
            // 0x00BBE274: STRB w8, [sp, #0xf]        | stack[1152921510047295807] = X1 + 89;    //  dest_result_addr=1152921510047295807
            // 0x00BBE278: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x00BBE27C: BL #0x27bc028              | X0 = 1152921510047343872 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 89);
            // 0x00BBE280: SUB sp, x29, #0x10         | SP = (1152921510047295840 - 16) = 1152921510047295824 (0x100000014446A950);
            // 0x00BBE284: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBE288: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBE28C: RET                        |  return (System.Object)X1 + 89;         
            return (object)X1 + 89;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BBE290: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BBE294: ADD x8, sp, #0x18          | X8 = (1152921510047295792 + 24) = 1152921510047295816 (0x100000014446A948);
            // 0x00BBE298: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BBE29C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510047283856]
            // 0x00BBE2A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBE2A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE2A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBE2AC: ADD x0, sp, #0x18          | X0 = (1152921510047295792 + 24) = 1152921510047295816 (0x100000014446A948);
            // 0x00BBE2B0: BL #0x299a140              | 
            // 0x00BBE2B4: MOV x19, x0                | X19 = 1152921510047295816 (0x100000014446A948);//ML01
            // 0x00BBE2B8: ADD x0, sp, #0x10          | X0 = (1152921510047295792 + 16) = 1152921510047295808 (0x100000014446A940);
            label_6:
            // 0x00BBE2BC: BL #0x299a140              | 
            // 0x00BBE2C0: MOV x0, x19                | X0 = 1152921510047295816 (0x100000014446A948);//ML01
            // 0x00BBE2C4: BL #0x980800               | X0 = sub_980800( ?? 0x100000014446A948, ????);
            // 0x00BBE2C8: MOV x19, x0                | X19 = 1152921510047295816 (0x100000014446A948);//ML01
            // 0x00BBE2CC: ADD x0, sp, #0x18          | X0 = (1152921510047295792 + 24) = 1152921510047295816 (0x100000014446A948);
            // 0x00BBE2D0: B #0xbbe2bc                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBE2D4 (12313300), len: 412  VirtAddr: 0x00BBE2D4 RVA: 0x00BBE2D4 token: 100663781 methodIndex: 29826 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_isSkillFrozen_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BBE2D4: STP x22, x21, [sp, #-0x30]! | stack[1152921510047424032] = ???;  stack[1152921510047424040] = ???;  //  dest_result_addr=1152921510047424032 |  dest_result_addr=1152921510047424040
            // 0x00BBE2D8: STP x20, x19, [sp, #0x10]  | stack[1152921510047424048] = ???;  stack[1152921510047424056] = ???;  //  dest_result_addr=1152921510047424048 |  dest_result_addr=1152921510047424056
            // 0x00BBE2DC: STP x29, x30, [sp, #0x20]  | stack[1152921510047424064] = ???;  stack[1152921510047424072] = ???;  //  dest_result_addr=1152921510047424064 |  dest_result_addr=1152921510047424072
            // 0x00BBE2E0: ADD x29, sp, #0x20         | X29 = (1152921510047424032 + 32) = 1152921510047424064 (0x1000000144489E40);
            // 0x00BBE2E4: SUB sp, sp, #0x20          | SP = (1152921510047424032 - 32) = 1152921510047424000 (0x1000000144489E00);
            // 0x00BBE2E8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BBE2EC: LDRB w8, [x21, #0xb71]     | W8 = (bool)static_value_03733B71;       
            // 0x00BBE2F0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BBE2F4: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BBE2F8: TBNZ w8, #0, #0xbbe314     | if (static_value_03733B71 == true) goto label_0;
            // 0x00BBE2FC: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x00BBE300: LDR x8, [x8, #0xb00]       | X8 = 0x2B8AEC8;                         
            // 0x00BBE304: LDR w0, [x8]               | W0 = 0x270;                             
            // 0x00BBE308: BL #0x2782188              | X0 = sub_2782188( ?? 0x270, ????);      
            // 0x00BBE30C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBE310: STRB w8, [x21, #0xb71]     | static_value_03733B71 = true;            //  dest_result_addr=57883505
            label_0:
            // 0x00BBE314: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BBE318: CBZ x21, #0xbbe3cc         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BBE31C: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BBE320: LDR x20, [x20, #0x188]     | X20 = 1152921504922288128;              
            // 0x00BBE324: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBE328: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBE32C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BBE330: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE334: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE338: B.LO #0xbbe350             | if (mem[null + 260] < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BBE33C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BBE340: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE344: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE348: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBE34C: B.EQ #0xbbe378             | if ((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BBE350: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBE354: ADD x8, sp, #8             | X8 = (1152921510047424000 + 8) = 1152921510047424008 (0x1000000144489E08);
            // 0x00BBE358: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BBE35C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510047412080]
            // 0x00BBE360: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BBE364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE368: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BBE36C: ADD x0, sp, #8             | X0 = (1152921510047424000 + 8) = 1152921510047424008 (0x1000000144489E08);
            // 0x00BBE370: BL #0x299a140              | 
            // 0x00BBE374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144489E08, ????);
            label_3:
            // 0x00BBE378: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BBE37C: LDR x1, [x20]              | X1 = typeof(AnimationRunner);           
            // 0x00BBE380: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BBE384: LDRB w9, [x1, #0x104]      | W9 = AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBE388: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBE38C: B.LO #0xbbe3a4             | if (mem[null + 260] < AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BBE390: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BBE394: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BBE398: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBE39C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimationRunner))
            // 0x00BBE3A0: B.EQ #0xbbe3d4             | if ((mem[null + 176] + (AnimationRunner.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BBE3A4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BBE3A8: ADD x8, sp, #0x10          | X8 = (1152921510047424000 + 16) = 1152921510047424016 (0x1000000144489E10);
            // 0x00BBE3AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BBE3B0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510047412080]
            // 0x00BBE3B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBE3B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE3BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBE3C0: ADD x0, sp, #0x10          | X0 = (1152921510047424000 + 16) = 1152921510047424016 (0x1000000144489E10);
            // 0x00BBE3C4: BL #0x299a140              | 
            // 0x00BBE3C8: B #0xbbe3d0                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BBE3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x270, ????);      
            label_6:
            // 0x00BBE3D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BBE3D4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BBE3D8: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00BBE3DC: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x00BBE3E0: CBNZ x19, #0xbbe3e8        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BBE3E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x270, ????);      
            label_7:
            // 0x00BBE3E8: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BBE3EC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BBE3F0: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00BBE3F4: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00BBE3F8: B.NE #0xbbe440             | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BBE3FC: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BBE400: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BBE404: LDRB w8, [x0]              | W8 = X2;                                
            // 0x00BBE408: STRB w8, [x21, #0x59]      | mem[89] = X2;                            //  dest_result_addr=89
            mem[89] = X2;
            // 0x00BBE40C: SUB sp, x29, #0x20         | SP = (1152921510047424064 - 32) = 1152921510047424032 (0x1000000144489E20);
            // 0x00BBE410: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBE414: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBE418: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BBE41C: RET                        |  return;                                
            return;
            // 0x00BBE420: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BBE424: ADD x0, sp, #8             | X0 = (1152921510047424080 + 8) = 1152921510047424088 (0x1000000144489E58);
            // 0x00BBE428: B #0xbbe434                |  goto label_10;                         
            goto label_10;
            // 0x00BBE42C: MOV x19, x0                | X19 = 1152921510047424088 (0x1000000144489E58);//ML01
            val_7;
            // 0x00BBE430: ADD x0, sp, #0x10          | X0 = (1152921510047424080 + 16) = 1152921510047424096 (0x1000000144489E60);
            label_10:
            // 0x00BBE434: BL #0x299a140              | 
            // 0x00BBE438: MOV x0, x19                | X0 = 1152921510047424088 (0x1000000144489E58);//ML01
            // 0x00BBE43C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144489E58, ????);
            label_8:
            // 0x00BBE440: ADD x8, sp, #0x18          | X8 = (1152921510047424080 + 24) = 1152921510047424104 (0x1000000144489E68);
            // 0x00BBE444: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BBE448: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000144489E58, ????);
            // 0x00BBE44C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510047412080]
            // 0x00BBE450: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BBE454: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE458: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BBE45C: ADD x0, sp, #0x18          | X0 = (1152921510047424080 + 24) = 1152921510047424104 (0x1000000144489E68);
            // 0x00BBE460: BL #0x299a140              | 
            // 0x00BBE464: MOV x19, x0                | X19 = 1152921510047424104 (0x1000000144489E68);//ML01
            // 0x00BBE468: ADD x0, sp, #0x18          | X0 = (1152921510047424080 + 24) = 1152921510047424104 (0x1000000144489E68);
            // 0x00BBE46C: B #0xbbe434                |  goto label_10;                         
            goto label_10;
        
        }
    
    }

}
