using UnityEngine;
private class BsonReader.ContainerContext
{
    // Fields
    public readonly Newtonsoft.Json.Bson.BsonType Type; //  0x00000010
    public int Length; //  0x00000014
    public int Position; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00AD353C (11351356), len: 44  VirtAddr: 0x00AD353C RVA: 0x00AD353C token: 100684759 methodIndex: 47419 delegateWrapperIndex: 0 methodInvoker: 0
    public BsonReader.ContainerContext(Newtonsoft.Json.Bson.BsonType type)
    {
        //
        // Disasemble & Code
        // 0x00AD353C: STP x20, x19, [sp, #-0x20]! | stack[1152921513721739568] = ???;  stack[1152921513721739576] = ???;  //  dest_result_addr=1152921513721739568 |  dest_result_addr=1152921513721739576
        // 0x00AD3540: STP x29, x30, [sp, #0x10]  | stack[1152921513721739584] = ???;  stack[1152921513721739592] = ???;  //  dest_result_addr=1152921513721739584 |  dest_result_addr=1152921513721739592
        // 0x00AD3544: ADD x29, sp, #0x10         | X29 = (1152921513721739568 + 16) = 1152921513721739584 (0x100000021F4A3940);
        // 0x00AD3548: MOV w19, w1                | W19 = type;//m1                         
        // 0x00AD354C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00AD3550: MOV x20, x0                | X20 = 1152921513721751600 (0x100000021F4A6830);//ML01
        // 0x00AD3554: BL #0x16f59f0              | this..ctor();                           
        // 0x00AD3558: STRB w19, [x20, #0x10]     | this.Type = type;                        //  dest_result_addr=1152921513721751616
        this.Type = type;
        // 0x00AD355C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00AD3560: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00AD3564: RET                        |  return;                                
        return;
    
    }

}
