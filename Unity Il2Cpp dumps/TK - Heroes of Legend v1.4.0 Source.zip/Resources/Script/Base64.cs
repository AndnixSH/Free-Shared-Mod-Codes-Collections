using UnityEngine;

namespace Common
{
    public sealed class Base64
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00B41C38 (11803704), len: 8  VirtAddr: 0x00B41C38 RVA: 0x00B41C38 token: 100696284 methodIndex: 26636 delegateWrapperIndex: 0 methodInvoker: 0
        public Base64()
        {
            //
            // Disasemble & Code
            // 0x00B41C38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B41C3C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B41C40 (11803712), len: 312  VirtAddr: 0x00B41C40 RVA: 0x00B41C40 token: 100696285 methodIndex: 26637 delegateWrapperIndex: 0 methodInvoker: 0
        public static string EncodeBase64(System.Text.Encoding encode, string source)
        {
            //
            // Disasemble & Code
            // 0x00B41C40: STP x22, x21, [sp, #-0x30]! | stack[1152921515508368864] = ???;  stack[1152921515508368872] = ???;  //  dest_result_addr=1152921515508368864 |  dest_result_addr=1152921515508368872
            // 0x00B41C44: STP x20, x19, [sp, #0x10]  | stack[1152921515508368880] = ???;  stack[1152921515508368888] = ???;  //  dest_result_addr=1152921515508368880 |  dest_result_addr=1152921515508368888
            // 0x00B41C48: STP x29, x30, [sp, #0x20]  | stack[1152921515508368896] = ???;  stack[1152921515508368904] = ???;  //  dest_result_addr=1152921515508368896 |  dest_result_addr=1152921515508368904
            // 0x00B41C4C: ADD x29, sp, #0x20         | X29 = (1152921515508368864 + 32) = 1152921515508368896 (0x1000000289C80600);
            // 0x00B41C50: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B41C54: LDRB w8, [x21, #0x7eb]     | W8 = (bool)static_value_037337EB;       
            // 0x00B41C58: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00B41C5C: MOV x20, x1                | X20 = source;//m1                       
            // 0x00B41C60: TBNZ w8, #0, #0xb41c7c     | if (static_value_037337EB == true) goto label_0;
            // 0x00B41C64: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00B41C68: LDR x8, [x8, #0x710]       | X8 = 0x2B8EFD0;                         
            // 0x00B41C6C: LDR w0, [x8]               | W0 = 0x12B6;                            
            // 0x00B41C70: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B6, ????);     
            // 0x00B41C74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B41C78: STRB w8, [x21, #0x7eb]     | static_value_037337EB = true;            //  dest_result_addr=57882603
            label_0:
            // 0x00B41C7C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00B41C80: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00B41C84: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00B41C88: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00B41C8C: TBZ w8, #0, #0xb41c9c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00B41C90: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00B41C94: CBNZ w8, #0xb41c9c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00B41C98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00B41C9C: CBNZ x20, #0xb41ca4        | if (source != null) goto label_3;       
            if(source != null)
            {
                goto label_3;
            }
            // 0x00B41CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_3:
            // 0x00B41CA4: LDR x8, [x20]              | X8 = typeof(System.String);             
            // 0x00B41CA8: MOV x0, x20                | X0 = source;//m1                        
            // 0x00B41CAC: MOV x1, x19                | X1 = X2;//m1                            
            // 0x00B41CB0: LDP x9, x2, [x8, #0x1c0]   | X9 = typeof(System.String).__il2cppRuntimeField_1C0; X2 = typeof(System.String).__il2cppRuntimeField_1C8; //  | 
            // 0x00B41CB4: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_1C0();
            // 0x00B41CB8: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00B41CBC: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00B41CC0: MOV x20, x0                | X20 = source;//m1                       
            // 0x00B41CC4: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x00B41CC8: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00B41CCC: TBZ w9, #0, #0xb41ce0      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00B41CD0: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00B41CD4: CBNZ w9, #0xb41ce0         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00B41CD8: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x00B41CDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_5:
            // 0x00B41CE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B41CE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B41CE8: MOV x1, x20                | X1 = source;//m1                        
            // 0x00B41CEC: BL #0x1ba2238              | X0 = System.Convert.ToBase64String(inArray:  0);
            string val_1 = System.Convert.ToBase64String(inArray:  0);
            // 0x00B41CF0: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00B41CF4: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00B41CF8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B41CFC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B41D00: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B41D04: RET                        |  return (System.String)val_1;           
            return (string)val_1;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00B41D78 (11804024), len: 116  VirtAddr: 0x00B41D78 RVA: 0x00B41D78 token: 100696286 methodIndex: 26638 delegateWrapperIndex: 0 methodInvoker: 0
        public static string EncodeBase64(string source)
        {
            //
            // Disasemble & Code
            // 0x00B41D78: STP x20, x19, [sp, #-0x20]! | stack[1152921515508501360] = ???;  stack[1152921515508501368] = ???;  //  dest_result_addr=1152921515508501360 |  dest_result_addr=1152921515508501368
            // 0x00B41D7C: STP x29, x30, [sp, #0x10]  | stack[1152921515508501376] = ???;  stack[1152921515508501384] = ???;  //  dest_result_addr=1152921515508501376 |  dest_result_addr=1152921515508501384
            // 0x00B41D80: ADD x29, sp, #0x10         | X29 = (1152921515508501360 + 16) = 1152921515508501376 (0x1000000289CA0B80);
            // 0x00B41D84: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B41D88: LDRB w8, [x20, #0x7ec]     | W8 = (bool)static_value_037337EC;       
            // 0x00B41D8C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00B41D90: TBNZ w8, #0, #0xb41dac     | if (static_value_037337EC == true) goto label_0;
            // 0x00B41D94: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00B41D98: LDR x8, [x8, #0x838]       | X8 = 0x2B8EFD4;                         
            // 0x00B41D9C: LDR w0, [x8]               | W0 = 0x12B7;                            
            // 0x00B41DA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B7, ????);     
            // 0x00B41DA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B41DA8: STRB w8, [x20, #0x7ec]     | static_value_037337EC = true;            //  dest_result_addr=57882604
            label_0:
            // 0x00B41DAC: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00B41DB0: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00B41DB4: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00B41DB8: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00B41DBC: TBZ w8, #0, #0xb41dcc      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00B41DC0: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00B41DC4: CBNZ w8, #0xb41dcc         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00B41DC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_2:
            // 0x00B41DCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B41DD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B41DD4: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
            // 0x00B41DD8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B41DDC: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00B41DE0: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00B41DE4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00B41DE8: B #0xb41c40                | return Common.Base64.EncodeBase64(encode:  System.Text.Encoding val_1 = System.Text.Encoding.UTF8, source:  val_1);
            return Common.Base64.EncodeBase64(encode:  val_1, source:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00B41DEC (11804140), len: 312  VirtAddr: 0x00B41DEC RVA: 0x00B41DEC token: 100696287 methodIndex: 26639 delegateWrapperIndex: 0 methodInvoker: 0
        public static string DecodeBase64(System.Text.Encoding encode, string result)
        {
            //
            // Disasemble & Code
            // 0x00B41DEC: STP x22, x21, [sp, #-0x30]! | stack[1152921515508666592] = ???;  stack[1152921515508666600] = ???;  //  dest_result_addr=1152921515508666592 |  dest_result_addr=1152921515508666600
            // 0x00B41DF0: STP x20, x19, [sp, #0x10]  | stack[1152921515508666608] = ???;  stack[1152921515508666616] = ???;  //  dest_result_addr=1152921515508666608 |  dest_result_addr=1152921515508666616
            // 0x00B41DF4: STP x29, x30, [sp, #0x20]  | stack[1152921515508666624] = ???;  stack[1152921515508666632] = ???;  //  dest_result_addr=1152921515508666624 |  dest_result_addr=1152921515508666632
            // 0x00B41DF8: ADD x29, sp, #0x20         | X29 = (1152921515508666592 + 32) = 1152921515508666624 (0x1000000289CC9100);
            // 0x00B41DFC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B41E00: LDRB w8, [x21, #0x7ed]     | W8 = (bool)static_value_037337ED;       
            // 0x00B41E04: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00B41E08: MOV x20, x1                | X20 = result;//m1                       
            // 0x00B41E0C: TBNZ w8, #0, #0xb41e28     | if (static_value_037337ED == true) goto label_0;
            // 0x00B41E10: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x00B41E14: LDR x8, [x8, #0xd78]       | X8 = 0x2B8EFC8;                         
            // 0x00B41E18: LDR w0, [x8]               | W0 = 0x12B4;                            
            // 0x00B41E1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B4, ????);     
            // 0x00B41E20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B41E24: STRB w8, [x21, #0x7ed]     | static_value_037337ED = true;            //  dest_result_addr=57882605
            label_0:
            // 0x00B41E28: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00B41E2C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00B41E30: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00B41E34: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00B41E38: TBZ w8, #0, #0xb41e48      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00B41E3C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00B41E40: CBNZ w8, #0xb41e48         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00B41E44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00B41E48: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00B41E4C: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00B41E50: LDR x0, [x8]               | X0 = typeof(System.Convert);            
            // 0x00B41E54: LDRB w8, [x0, #0x10a]      | W8 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00B41E58: TBZ w8, #0, #0xb41e68      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00B41E5C: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00B41E60: CBNZ w8, #0xb41e68         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00B41E64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_4:
            // 0x00B41E68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B41E6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B41E70: MOV x1, x19                | X1 = X2;//m1                            
            // 0x00B41E74: BL #0x1ba1ee0              | X0 = System.Convert.FromBase64String(s:  0);
            System.Byte[] val_1 = System.Convert.FromBase64String(s:  0);
            // 0x00B41E78: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00B41E7C: CBNZ x20, #0xb41e84        | if (result != null) goto label_5;       
            if(result != null)
            {
                goto label_5;
            }
            // 0x00B41E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00B41E84: LDR x8, [x20]              | X8 = typeof(System.String);             
            // 0x00B41E88: LDR x9, [x8, #0x2c0]       | X9 = typeof(System.String).__il2cppRuntimeField_2C0;
            // 0x00B41E8C: LDR x2, [x8, #0x2c8]       | X2 = typeof(System.String).__il2cppRuntimeField_2C8;
            // 0x00B41E90: MOV x0, x20                | X0 = result;//m1                        
            // 0x00B41E94: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00B41E98: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_2C0();
            // 0x00B41E9C: MOV x19, x0                | X19 = result;//m1                       
            // 0x00B41EA0: MOV x0, x19                | X0 = result;//m1                        
            // 0x00B41EA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00B41EA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00B41EAC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00B41EB0: RET                        |  return (System.String)result;          
            return (string)result;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00B41F24 (11804452), len: 116  VirtAddr: 0x00B41F24 RVA: 0x00B41F24 token: 100696288 methodIndex: 26640 delegateWrapperIndex: 0 methodInvoker: 0
        public static string DecodeBase64(string result)
        {
            //
            // Disasemble & Code
            // 0x00B41F24: STP x20, x19, [sp, #-0x20]! | stack[1152921515508831856] = ???;  stack[1152921515508831864] = ???;  //  dest_result_addr=1152921515508831856 |  dest_result_addr=1152921515508831864
            // 0x00B41F28: STP x29, x30, [sp, #0x10]  | stack[1152921515508831872] = ???;  stack[1152921515508831880] = ???;  //  dest_result_addr=1152921515508831872 |  dest_result_addr=1152921515508831880
            // 0x00B41F2C: ADD x29, sp, #0x10         | X29 = (1152921515508831856 + 16) = 1152921515508831872 (0x1000000289CF1680);
            // 0x00B41F30: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B41F34: LDRB w8, [x20, #0x7ee]     | W8 = (bool)static_value_037337EE;       
            // 0x00B41F38: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00B41F3C: TBNZ w8, #0, #0xb41f58     | if (static_value_037337EE == true) goto label_0;
            // 0x00B41F40: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00B41F44: LDR x8, [x8, #0x998]       | X8 = 0x2B8EFCC;                         
            // 0x00B41F48: LDR w0, [x8]               | W0 = 0x12B5;                            
            // 0x00B41F4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B5, ????);     
            // 0x00B41F50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B41F54: STRB w8, [x20, #0x7ee]     | static_value_037337EE = true;            //  dest_result_addr=57882606
            label_0:
            // 0x00B41F58: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00B41F5C: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00B41F60: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00B41F64: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00B41F68: TBZ w8, #0, #0xb41f78      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00B41F6C: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00B41F70: CBNZ w8, #0xb41f78         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00B41F74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_2:
            // 0x00B41F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B41F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B41F80: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
            // 0x00B41F84: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B41F88: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00B41F8C: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00B41F90: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00B41F94: B #0xb41dec                | return Common.Base64.DecodeBase64(encode:  System.Text.Encoding val_1 = System.Text.Encoding.UTF8, result:  val_1);
            return Common.Base64.DecodeBase64(encode:  val_1, result:  val_1);
        
        }
    
    }

}
