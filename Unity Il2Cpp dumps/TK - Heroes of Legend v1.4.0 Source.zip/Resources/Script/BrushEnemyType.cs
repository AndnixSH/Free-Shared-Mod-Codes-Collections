using UnityEngine;
public enum Portal.BrushEnemyType
{
    // Fields
    BET_single = 1
    ,BET_group = 2
    

}
