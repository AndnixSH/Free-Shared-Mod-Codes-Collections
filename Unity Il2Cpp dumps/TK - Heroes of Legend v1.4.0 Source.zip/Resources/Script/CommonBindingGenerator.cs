using UnityEngine;

namespace ILRuntime.Runtime.CLRBinding
{
    [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857280
    internal static class CommonBindingGenerator
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x0110A4F0 (17868016), len: 880  VirtAddr: 0x0110A4F0 RVA: 0x0110A4F0 token: 100679929 methodIndex: 29214 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857290
        internal static string GenerateMiscRegisterCode(System.Type type, string typeClsName, bool defaultCtor, bool newArr)
        {
            //
            // Disasemble & Code
            //  | 
            System.Type[] val_24;
            //  | 
            object val_25;
            //  | 
            string val_26;
            //  | 
            string val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            string val_31;
            // 0x0110A4F0: STP x24, x23, [sp, #-0x40]! | stack[1152921512832187168] = ???;  stack[1152921512832187176] = ???;  //  dest_result_addr=1152921512832187168 |  dest_result_addr=1152921512832187176
            // 0x0110A4F4: STP x22, x21, [sp, #0x10]  | stack[1152921512832187184] = ???;  stack[1152921512832187192] = ???;  //  dest_result_addr=1152921512832187184 |  dest_result_addr=1152921512832187192
            // 0x0110A4F8: STP x20, x19, [sp, #0x20]  | stack[1152921512832187200] = ???;  stack[1152921512832187208] = ???;  //  dest_result_addr=1152921512832187200 |  dest_result_addr=1152921512832187208
            // 0x0110A4FC: STP x29, x30, [sp, #0x30]  | stack[1152921512832187216] = ???;  stack[1152921512832187224] = ???;  //  dest_result_addr=1152921512832187216 |  dest_result_addr=1152921512832187224
            // 0x0110A500: ADD x29, sp, #0x30         | X29 = (1152921512832187168 + 48) = 1152921512832187216 (0x10000001EA44BB50);
            // 0x0110A504: SUB sp, sp, #0x20          | SP = (1152921512832187168 - 32) = 1152921512832187136 (0x10000001EA44BB00);
            // 0x0110A508: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x0110A50C: LDRB w8, [x19, #0xb9c]     | W8 = (bool)static_value_03735B9C;       
            // 0x0110A510: MOV w22, w4                | W22 = W4;//m1                           
            // 0x0110A514: MOV w23, w3                | W23 = newArr;//m1                       
            val_24 = newArr;
            // 0x0110A518: MOV x21, x2                | X21 = defaultCtor;//m1                  
            val_25 = defaultCtor;
            // 0x0110A51C: MOV x20, x1                | X20 = typeClsName;//m1                  
            val_26 = typeClsName;
            // 0x0110A520: TBNZ w8, #0, #0x110a53c    | if (static_value_03735B9C == true) goto label_0;
            // 0x0110A524: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x0110A528: LDR x8, [x8, #0x8a0]       | X8 = 0x2B92368;                         
            // 0x0110A52C: LDR w0, [x8]               | W0 = 0x1F9F;                            
            // 0x0110A530: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F9F, ????);     
            // 0x0110A534: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0110A538: STRB w8, [x19, #0xb9c]     | static_value_03735B9C = true;            //  dest_result_addr=57891740
            label_0:
            // 0x0110A53C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110A540: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x0110A544: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x0110A548: STP xzr, xzr, [sp, #0x10]  | stack[1152921512832187152] = 0x0;  stack[1152921512832187160] = 0x0;  //  dest_result_addr=1152921512832187152 |  dest_result_addr=1152921512832187160
            string val_19 = 0;
            bool val_20 = false;
            // 0x0110A54C: STRB wzr, [sp, #0xf]       | stack[1152921512832187151] = 0x0;        //  dest_result_addr=1152921512832187151
            // 0x0110A550: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x0110A554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A558: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A55C: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x0110A560: TBZ w23, #0, #0x110a654    | if (newArr == false) goto label_9;      
            if(val_24 == false)
            {
                goto label_9;
            }
            // 0x0110A564: CBNZ x20, #0x110a56c       | if (typeClsName != null) goto label_2;  
            if(val_26 != null)
            {
                goto label_2;
            }
            // 0x0110A568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x0110A56C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A570: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A574: BL #0x1b6d41c              | X0 = typeClsName.get_IsPrimitive();     
            bool val_2 = val_26.IsPrimitive;
            // 0x0110A578: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x0110A57C: TBNZ w8, #0, #0x110a654    | if ((val_2 & 1) == true) goto label_9;  
            if(val_3 == true)
            {
                goto label_9;
            }
            // 0x0110A580: CBNZ x20, #0x110a588       | if (typeClsName != null) goto label_4;  
            if(val_26 != null)
            {
                goto label_4;
            }
            // 0x0110A584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x0110A588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A58C: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A590: BL #0x1b6d1a8              | X0 = typeClsName.get_IsAbstract();      
            bool val_4 = val_26.IsAbstract;
            // 0x0110A594: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x0110A598: TBNZ w8, #0, #0x110a654    | if ((val_4 & 1) == true) goto label_9;  
            if(val_5 == true)
            {
                goto label_9;
            }
            // 0x0110A59C: CBNZ x20, #0x110a5a4       | if (typeClsName != null) goto label_6;  
            if(val_26 != null)
            {
                goto label_6;
            }
            // 0x0110A5A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x0110A5A4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0110A5A8: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x0110A5AC: LDR x23, [x8]              | X23 = typeof(System.Type[]);            
            val_24 = null;
            // 0x0110A5B0: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0110A5B4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0110A5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A5BC: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0110A5C0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0110A5C4: MOV x3, x0                 | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0110A5C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A5CC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110A5D0: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x0110A5D4: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A5D8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0110A5DC: BL #0x1b6ea10              | X0 = typeClsName.GetConstructor(bindingAttr:  30, binder:  0, types:  val_24, modifiers:  0);
            System.Reflection.ConstructorInfo val_6 = val_26.GetConstructor(bindingAttr:  30, binder:  0, types:  val_24, modifiers:  0);
            // 0x0110A5E0: CBNZ x0, #0x110a5fc        | if (val_6 != null) goto label_7;        
            if(val_6 != null)
            {
                goto label_7;
            }
            // 0x0110A5E4: CBNZ x20, #0x110a5ec       | if (typeClsName != null) goto label_8;  
            if(val_26 != null)
            {
                goto label_8;
            }
            // 0x0110A5E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x0110A5EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A5F0: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A5F4: BL #0x1b6d264              | X0 = typeClsName.get_IsValueType();     
            bool val_7 = val_26.IsValueType;
            // 0x0110A5F8: TBZ w0, #0, #0x110a654     | if (val_7 == false) goto label_9;       
            if(val_7 == false)
            {
                goto label_9;
            }
            label_7:
            // 0x0110A5FC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0110A600: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110A604: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110A608: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A60C: TBZ w8, #0, #0x110a61c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x0110A610: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A614: CBNZ w8, #0x110a61c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x0110A618: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_11:
            // 0x0110A61C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0110A620: LDR x8, [x8, #0x3c0]       | X8 = (string**)(1152921512832150000)("            app.RegisterCLRCreateDefaultInstance(type, () => new {0}());");
            // 0x0110A624: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A628: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110A62C: MOV x2, x21                | X2 = defaultCtor;//m1                   
            // 0x0110A630: LDR x1, [x8]               | X1 = "            app.RegisterCLRCreateDefaultInstance(type, () => new {0}());";
            // 0x0110A634: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRCreateDefaultInstance(type, () => new {0}());");
            string val_8 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRCreateDefaultInstance(type, () => new {0}());");
            // 0x0110A638: MOV x23, x0                | X23 = val_8;//m1                        
            val_24 = val_8;
            // 0x0110A63C: CBNZ x19, #0x110a644       | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x0110A640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_12:
            // 0x0110A644: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A648: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A64C: MOV x1, x23                | X1 = val_8;//m1                         
            val_27 = val_24;
            // 0x0110A650: BL #0x1b5c068              | X0 = AppendLine(value:  val_27 = val_24);
            System.Text.StringBuilder val_9 = AppendLine(value:  val_27);
            label_9:
            // 0x0110A654: TBZ w22, #0, #0x110a830    | if ((W4 & 0x1) == 0) goto label_17;     
            if((W4 & 1) == 0)
            {
                goto label_17;
            }
            // 0x0110A658: CBNZ x20, #0x110a660       | if (typeClsName != null) goto label_14; 
            if(val_26 != null)
            {
                goto label_14;
            }
            // 0x0110A65C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x0110A660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A664: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A668: BL #0x1b6d1a8              | X0 = typeClsName.get_IsAbstract();      
            bool val_10 = val_26.IsAbstract;
            // 0x0110A66C: TBZ w0, #0, #0x110a68c     | if (val_10 == false) goto label_15;     
            if(val_10 == false)
            {
                goto label_15;
            }
            // 0x0110A670: CBNZ x20, #0x110a678       | if (typeClsName != null) goto label_16; 
            if(val_26 != null)
            {
                goto label_16;
            }
            // 0x0110A674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_16:
            // 0x0110A678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x0110A67C: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A680: BL #0x1b6d42c              | X0 = typeClsName.get_IsSealed();        
            bool val_11 = val_26.IsSealed;
            // 0x0110A684: AND w8, w0, #1             | W8 = (val_11 & 1);                      
            bool val_12 = val_11;
            // 0x0110A688: TBNZ w8, #0, #0x110a830    | if ((val_11 & 1) == true) goto label_17;
            if(val_12 == true)
            {
                goto label_17;
            }
            label_15:
            // 0x0110A68C: CBNZ x20, #0x110a694       | if (typeClsName != null) goto label_18; 
            if(val_26 != null)
            {
                goto label_18;
            }
            // 0x0110A690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_18:
            // 0x0110A694: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A698: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A69C: BL #0x1b6d1cc              | X0 = typeClsName.get_IsArray();         
            bool val_13 = val_26.IsArray;
            // 0x0110A6A0: AND w8, w0, #1             | W8 = (val_13 & 1);                      
            bool val_14 = val_13;
            // 0x0110A6A4: TBZ w8, #0, #0x110a6f4     | if ((val_13 & 1) == false) goto label_19;
            if(val_14 == false)
            {
                goto label_19;
            }
            // 0x0110A6A8: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x0110A6AC: B #0x110a6cc               |  goto label_20;                         
            goto label_20;
            label_24:
            // 0x0110A6B0: LDR x8, [x20]              | X8 = typeof(System.String);             
            // 0x0110A6B4: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A6B8: LDR x9, [x8, #0x410]       | X9 = typeof(System.String).__il2cppRuntimeField_410;
            // 0x0110A6BC: LDR x1, [x8, #0x418]       | X1 = typeof(System.String).__il2cppRuntimeField_418;
            // 0x0110A6C0: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_410();
            // 0x0110A6C4: MOV x20, x0                | X20 = typeClsName;//m1                  
            val_26 = val_26;
            // 0x0110A6C8: ADD w21, w21, #1           | W21 = (val_28 + 1) = val_28 (0x00000001);
            val_28 = 1;
            label_20:
            // 0x0110A6CC: CBNZ x20, #0x110a6d4       | if (typeClsName != null) goto label_21; 
            if(val_26 != null)
            {
                goto label_21;
            }
            // 0x0110A6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeClsName, ????);
            label_21:
            // 0x0110A6D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A6D8: MOV x0, x20                | X0 = typeClsName;//m1                   
            // 0x0110A6DC: BL #0x1b6d1cc              | X0 = typeClsName.get_IsArray();         
            bool val_15 = val_26.IsArray;
            // 0x0110A6E0: AND w8, w0, #1             | W8 = (val_15 & 1);                      
            bool val_16 = val_15;
            // 0x0110A6E4: TBZ w8, #0, #0x110a734     | if ((val_15 & 1) == false) goto label_22;
            if(val_16 == false)
            {
                goto label_22;
            }
            // 0x0110A6E8: CBNZ x20, #0x110a6b0       | if (typeClsName != null) goto label_24; 
            if(val_26 != null)
            {
                goto label_24;
            }
            // 0x0110A6EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            // 0x0110A6F0: B #0x110a6b0               |  goto label_24;                         
            goto label_24;
            label_19:
            // 0x0110A6F4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0110A6F8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110A6FC: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110A700: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A704: TBZ w8, #0, #0x110a714     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x0110A708: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A70C: CBNZ w8, #0x110a714        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x0110A710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_26:
            // 0x0110A714: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x0110A718: LDR x8, [x8, #0x778]       | X8 = (string**)(1152921512832158416)("            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]);");
            // 0x0110A71C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A720: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110A724: MOV x2, x21                | X2 = defaultCtor;//m1                   
            // 0x0110A728: LDR x1, [x8]               | X1 = "            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]);";
            // 0x0110A72C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]);");
            string val_17 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]);");
            // 0x0110A730: B #0x110a814               |  goto label_27;                         
            goto label_27;
            label_22:
            // 0x0110A734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A738: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110A73C: ADD x2, sp, #0x10          | X2 = (1152921512832187136 + 16) = 1152921512832187152 (0x10000001EA44BB10);
            // 0x0110A740: ADD x3, sp, #0x18          | X3 = (1152921512832187136 + 24) = 1152921512832187160 (0x10000001EA44BB18);
            // 0x0110A744: ADD x4, sp, #0xf           | X4 = (1152921512832187136 + 15) = 1152921512832187151 (0x10000001EA44BB0F);
            // 0x0110A748: MOV x1, x20                | X1 = typeClsName;//m1                   
            string val_18 = val_26;
            // 0x0110A74C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110A750: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  string val_18 = val_26, realClsName: out  string val_19 = 0, isByRef: out  bool val_20 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_18, realClsName: out  val_19, isByRef: out  val_20, simpleClassName:  true);
            // 0x0110A754: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
            // 0x0110A758: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
            // 0x0110A75C: LDR x8, [x22]              | X8 = typeof(System.String);             
            val_30 = null;
            // 0x0110A760: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A764: TBZ w9, #0, #0x110a77c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x0110A768: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A76C: CBNZ w9, #0x110a77c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x0110A770: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110A774: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x0110A778: LDR x8, [x22]              | X8 = typeof(System.String);             
            val_30 = null;
            label_29:
            // 0x0110A77C: LDR x9, [x8, #0xa0]        | X9 = System.String.__il2cppRuntimeField_static_fields;
            // 0x0110A780: CMP w21, #1                | STATE = COMPARE(0x1, 0x1)               
            // 0x0110A784: LDR x20, [x9]              | X20 = System.String.Empty;              
            val_31 = System.String.Empty;
            // 0x0110A788: B.LT #0x110a7d8            | if (val_28 < 0x1) goto label_30;        
            if(val_28 < 1)
            {
                goto label_30;
            }
            // 0x0110A78C: ADRP x24, #0x35fe000       | X24 = 56614912 (0x35FE000);             
            // 0x0110A790: LDR x24, [x24, #0x3f8]     | X24 = (string**)(1152921509419241040)("[]");
            // 0x0110A794: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            label_33:
            // 0x0110A798: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A79C: TBZ w9, #0, #0x110a7b0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x0110A7A0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A7A4: CBNZ w9, #0x110a7b0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x0110A7A8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110A7AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_32:
            // 0x0110A7B0: LDR x2, [x24]              | X2 = "[]";                              
            // 0x0110A7B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A7B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110A7BC: MOV x1, x20                | X1 = System.String.Empty;//m1           
            // 0x0110A7C0: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_31);
            string val_21 = System.String.Concat(str0:  0, str1:  val_31);
            // 0x0110A7C4: LDR x8, [x22]              | X8 = typeof(System.String);             
            val_30 = null;
            // 0x0110A7C8: MOV x20, x0                | X20 = val_21;//m1                       
            val_31 = val_21;
            // 0x0110A7CC: ADD w23, w23, #1           | W23 = (0 + 1);                          
            val_24 = 0 + 1;
            // 0x0110A7D0: CMP w23, w21               | STATE = COMPARE((0 + 1), 0x1)           
            // 0x0110A7D4: B.NE #0x110a798            | if (val_24 != val_28) goto label_33;    
            if(val_24 != val_28)
            {
                goto label_33;
            }
            label_30:
            // 0x0110A7D8: LDR x21, [sp, #0x18]       | X21 = 0x0;                              
            val_25 = val_20;
            // 0x0110A7DC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A7E0: TBZ w9, #0, #0x110a7f4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_35;
            // 0x0110A7E4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A7E8: CBNZ w9, #0x110a7f4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
            // 0x0110A7EC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110A7F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_35:
            // 0x0110A7F4: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x0110A7F8: LDR x8, [x8, #0xa38]       | X8 = (string**)(1152921512832166816)("            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]{1});");
            // 0x0110A7FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A800: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110A804: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x0110A808: LDR x1, [x8]               | X1 = "            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]{1});";
            // 0x0110A80C: MOV x3, x20                | X3 = val_21;//m1                        
            // 0x0110A810: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]{1});", arg1:  val_25);
            string val_22 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRCreateArrayInstance(type, s => new {0}[s]{1});", arg1:  val_25);
            label_27:
            // 0x0110A814: MOV x20, x0                | X20 = val_22;//m1                       
            // 0x0110A818: CBNZ x19, #0x110a820       | if ( != 0) goto label_36;               
            if(null != 0)
            {
                goto label_36;
            }
            // 0x0110A81C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_36:
            // 0x0110A820: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A824: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A828: MOV x1, x20                | X1 = val_22;//m1                        
            val_27 = val_22;
            // 0x0110A82C: BL #0x1b5c068              | X0 = AppendLine(value:  val_27 = val_22);
            System.Text.StringBuilder val_23 = AppendLine(value:  val_27);
            label_17:
            // 0x0110A830: CBNZ x19, #0x110a838       | if ( != 0) goto label_37;               
            if(null != 0)
            {
                goto label_37;
            }
            // 0x0110A834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_37:
            // 0x0110A838: LDR x8, [x19]              | X8 = ;                                  
            // 0x0110A83C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A840: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x0110A844: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x0110A848: SUB sp, x29, #0x30         | SP = (1152921512832187216 - 48) = 1152921512832187168 (0x10000001EA44BB20);
            // 0x0110A84C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0110A850: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0110A854: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0110A858: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0110A85C: RET                        |  return (System.String)typeof(System.Text.StringBuilder);
            return (string)val_1;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0110A860 (17868896), len: 2252  VirtAddr: 0x0110A860 RVA: 0x0110A860 token: 100679930 methodIndex: 29215 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28572A0
        internal static string GenerateCommonCode(System.Type type, string typeClsName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_88;
            //  | 
            var val_89;
            //  | 
            var val_90;
            //  | 
            string val_91;
            // 0x0110A860: STP x24, x23, [sp, #-0x40]! | stack[1152921512832666512] = ???;  stack[1152921512832666520] = ???;  //  dest_result_addr=1152921512832666512 |  dest_result_addr=1152921512832666520
            // 0x0110A864: STP x22, x21, [sp, #0x10]  | stack[1152921512832666528] = ???;  stack[1152921512832666536] = ???;  //  dest_result_addr=1152921512832666528 |  dest_result_addr=1152921512832666536
            // 0x0110A868: STP x20, x19, [sp, #0x20]  | stack[1152921512832666544] = ???;  stack[1152921512832666552] = ???;  //  dest_result_addr=1152921512832666544 |  dest_result_addr=1152921512832666552
            // 0x0110A86C: STP x29, x30, [sp, #0x30]  | stack[1152921512832666560] = ???;  stack[1152921512832666568] = ???;  //  dest_result_addr=1152921512832666560 |  dest_result_addr=1152921512832666568
            // 0x0110A870: ADD x29, sp, #0x30         | X29 = (1152921512832666512 + 48) = 1152921512832666560 (0x10000001EA4C0BC0);
            // 0x0110A874: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x0110A878: LDRB w8, [x19, #0xb9d]     | W8 = (bool)static_value_03735B9D;       
            // 0x0110A87C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x0110A880: MOV x21, x1                | X21 = typeClsName;//m1                  
            val_88 = typeClsName;
            // 0x0110A884: TBNZ w8, #0, #0x110a8a0    | if (static_value_03735B9D == true) goto label_0;
            // 0x0110A888: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x0110A88C: LDR x8, [x8, #0x458]       | X8 = 0x2B92364;                         
            // 0x0110A890: LDR w0, [x8]               | W0 = 0x1F9E;                            
            // 0x0110A894: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F9E, ????);     
            // 0x0110A898: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0110A89C: STRB w8, [x19, #0xb9d]     | static_value_03735B9D = true;            //  dest_result_addr=57891741
            label_0:
            // 0x0110A8A0: CBNZ x21, #0x110a8a8       | if (typeClsName != null) goto label_1;  
            if(val_88 != null)
            {
                goto label_1;
            }
            // 0x0110A8A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1F9E, ????);     
            label_1:
            // 0x0110A8A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A8AC: MOV x0, x21                | X0 = typeClsName;//m1                   
            // 0x0110A8B0: BL #0x1b6d264              | X0 = typeClsName.get_IsValueType();     
            bool val_1 = val_88.IsValueType;
            // 0x0110A8B4: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x0110A8B8: TBZ w8, #0, #0x110a948     | if ((val_1 & 1) == false) goto label_2; 
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x0110A8BC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110A8C0: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x0110A8C4: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_3 = null;
            // 0x0110A8C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x0110A8CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A8D0: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A8D4: BL #0x1b5a30c              | .ctor();                                
            val_3 = new System.Text.StringBuilder();
            // 0x0110A8D8: CBNZ x21, #0x110a8e0       | if (typeClsName != null) goto label_3;  
            if(val_88 != null)
            {
                goto label_3;
            }
            // 0x0110A8DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x0110A8E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A8E4: MOV x0, x21                | X0 = typeClsName;//m1                   
            // 0x0110A8E8: BL #0x1b6d41c              | X0 = typeClsName.get_IsPrimitive();     
            bool val_4 = val_88.IsPrimitive;
            // 0x0110A8EC: TBZ w0, #0, #0x110ae80     | if (val_4 == false) goto label_4;       
            if(val_4 == false)
            {
                goto label_4;
            }
            // 0x0110A8F0: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
            // 0x0110A8F4: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
            // 0x0110A8F8: LDR x0, [x23]              | X0 = typeof(System.String);             
            // 0x0110A8FC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A900: TBZ w8, #0, #0x110a910     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0110A904: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A908: CBNZ w8, #0x110a910        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0110A90C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_6:
            // 0x0110A910: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x0110A914: LDR x8, [x8, #0x768]       | X8 = (string**)(1152921512832332288)("        static {0} GetInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack)");
            // 0x0110A918: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A91C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110A920: MOV x2, x20                | X2 = X2;//m1                            
            // 0x0110A924: LDR x1, [x8]               | X1 = "        static {0} GetInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack)";
            // 0x0110A928: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "        static {0} GetInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack)");
            string val_5 = System.String.Format(format:  0, arg0:  "        static {0} GetInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack)");
            // 0x0110A92C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x0110A930: CBZ x19, #0x110a988        | if ( == 0) goto label_7;                
            if(null == 0)
            {
                goto label_7;
            }
            // 0x0110A934: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A938: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A93C: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x0110A940: BL #0x1b5c068              | X0 = AppendLine(value:  val_5);         
            System.Text.StringBuilder val_6 = AppendLine(value:  val_5);
            // 0x0110A944: B #0x110a9a0               |  goto label_8;                          
            goto label_8;
            label_2:
            // 0x0110A948: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
            // 0x0110A94C: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
            // 0x0110A950: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_89 = null;
            // 0x0110A954: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A958: TBZ w8, #0, #0x110a96c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x0110A95C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A960: CBNZ w8, #0x110a96c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x0110A964: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x0110A968: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_89 = null;
            label_10:
            // 0x0110A96C: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x0110A970: LDR x0, [x8]               | X0 = System.String.Empty;               
            // 0x0110A974: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0110A978: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0110A97C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0110A980: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0110A984: RET                        |  return (System.String)System.String.Empty;
            return System.String.Empty;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_7:
            // 0x0110A988: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x0110A98C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A990: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A994: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x0110A998: BL #0x1b5c068              | X0 = AppendLine(value:  val_5);         
            System.Text.StringBuilder val_7 = AppendLine(value:  val_5);
            // 0x0110A99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_8:
            // 0x0110A9A0: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x0110A9A4: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921512832344928)("        {");
            // 0x0110A9A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A9AC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110A9B0: LDR x1, [x8]               | X1 = "        {";                       
            // 0x0110A9B4: BL #0x1b5c068              | X0 = AppendLine(value:  "        {");   
            System.Text.StringBuilder val_8 = AppendLine(value:  "        {");
            // 0x0110A9B8: CBNZ x21, #0x110a9c0       | if (typeClsName != null) goto label_11; 
            if(val_88 != null)
            {
                goto label_11;
            }
            // 0x0110A9BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_11:
            // 0x0110A9C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A9C4: MOV x0, x21                | X0 = typeClsName;//m1                   
            // 0x0110A9C8: BL #0x1b6d41c              | X0 = typeClsName.get_IsPrimitive();     
            bool val_9 = val_88.IsPrimitive;
            // 0x0110A9CC: AND w8, w0, #1             | W8 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x0110A9D0: TBNZ w8, #0, #0x110a9ec    | if ((val_9 & 1) == true) goto label_12; 
            if(val_10 == true)
            {
                goto label_12;
            }
            // 0x0110A9D4: CBNZ x21, #0x110a9dc       | if (typeClsName != null) goto label_13; 
            if(val_88 != null)
            {
                goto label_13;
            }
            // 0x0110A9D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_13:
            // 0x0110A9DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A9E0: MOV x0, x21                | X0 = typeClsName;//m1                   
            // 0x0110A9E4: BL #0x1b6d264              | X0 = typeClsName.get_IsValueType();     
            bool val_11 = val_88.IsValueType;
            // 0x0110A9E8: TBZ w0, #0, #0x110aa0c     | if (val_11 == false) goto label_14;     
            if(val_11 == false)
            {
                goto label_14;
            }
            label_12:
            // 0x0110A9EC: CBNZ x19, #0x110a9f4       | if ( != 0) goto label_15;               
            if(null != 0)
            {
                goto label_15;
            }
            // 0x0110A9F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_15:
            // 0x0110A9F4: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x0110A9F8: LDR x8, [x8, #0x8a0]       | X8 = (string**)(1152921512832349120)("            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);");
            // 0x0110A9FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AA00: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AA04: LDR x1, [x8]               | X1 = "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);";
            // 0x0110AA08: BL #0x1b5c068              | X0 = AppendLine(value:  "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);");
            System.Text.StringBuilder val_12 = AppendLine(value:  "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);");
            label_14:
            // 0x0110AA0C: LDR x0, [x23]              | X0 = typeof(System.String);             
            // 0x0110AA10: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110AA14: TBZ w8, #0, #0x110aa24     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x0110AA18: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110AA1C: CBNZ w8, #0x110aa24        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x0110AA20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_17:
            // 0x0110AA24: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x0110AA28: LDR x8, [x8, #0x638]       | X8 = (string**)(1152921512832353488)("            {0} instance_of_this_method;");
            // 0x0110AA2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110AA30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110AA34: MOV x2, x20                | X2 = X2;//m1                            
            // 0x0110AA38: LDR x1, [x8]               | X1 = "            {0} instance_of_this_method;";
            // 0x0110AA3C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            {0} instance_of_this_method;");
            string val_13 = System.String.Format(format:  0, arg0:  "            {0} instance_of_this_method;");
            // 0x0110AA40: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x0110AA44: CBZ x19, #0x110abdc        | if ( == 0) goto label_18;               
            if(null == 0)
            {
                goto label_18;
            }
            // 0x0110AA48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AA4C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AA50: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x0110AA54: BL #0x1b5c068              | X0 = AppendLine(value:  val_13);        
            System.Text.StringBuilder val_14 = AppendLine(value:  val_13);
            // 0x0110AA58: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0110AA5C: LDR x8, [x8, #0xeb0]       | X8 = (string**)(1152921512832361840)("            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (");
            // 0x0110AA60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AA64: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AA68: LDR x1, [x8]               | X1 = "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (";
            // 0x0110AA6C: BL #0x1b5b818              | X0 = Append(value:  "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_15 = Append(value:  "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (");
            // 0x0110AA70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AA74: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AA78: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AA7C: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_16 = Append(value:  X2);
            // 0x0110AA80: ADRP x22, #0x367a000       | X22 = 57122816 (0x367A000);             
            // 0x0110AA84: LDR x22, [x22, #0x3a8]     | X22 = (string**)(1152921512832370896)(")typeof(");
            // 0x0110AA88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AA8C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AA90: LDR x1, [x22]              | X1 = ")typeof(";                        
            // 0x0110AA94: BL #0x1b5b818              | X0 = Append(value:  ")typeof(");        
            System.Text.StringBuilder val_17 = Append(value:  ")typeof(");
            // 0x0110AA98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AA9C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AAA0: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AAA4: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_18 = Append(value:  X2);
            // 0x0110AAA8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x0110AAAC: LDR x8, [x8, #0x9f8]       | X8 = (string**)(1152921512832379184)(").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])");
            // 0x0110AAB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AAB4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AAB8: LDR x1, [x8]               | X1 = ").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])";
            // 0x0110AABC: BL #0x1b5b818              | X0 = Append(value:  ").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])");
            System.Text.StringBuilder val_19 = Append(value:  ").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])");
            // 0x0110AAC0: ADRP x23, #0x3640000       | X23 = 56885248 (0x3640000);             
            // 0x0110AAC4: LDR x23, [x23, #0x608]     | X23 = (string**)(1152921512830809120)(";");
            val_90 = ";";
            // 0x0110AAC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AACC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AAD0: LDR x1, [x23]              | X1 = ";";                               
            // 0x0110AAD4: BL #0x1b5b818              | X0 = Append(value:  ";");               
            System.Text.StringBuilder val_20 = Append(value:  ";");
            // 0x0110AAD8: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x0110AADC: LDR x8, [x8, #0x3e0]       | X8 = (string**)(1152921512832387632)("\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (");
            // 0x0110AAE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AAE4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AAE8: LDR x1, [x8]               | X1 = "\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (";
            // 0x0110AAEC: BL #0x1b5b818              | X0 = Append(value:  "\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_21 = Append(value:  "\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (");
            // 0x0110AAF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AAF4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AAF8: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AAFC: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_22 = Append(value:  X2);
            // 0x0110AB00: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0110AB04: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921512832396384)(")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);");
            // 0x0110AB08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB0C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB10: LDR x1, [x8]               | X1 = ")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);";
            // 0x0110AB14: BL #0x1b5b818              | X0 = Append(value:  ")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);");
            System.Text.StringBuilder val_23 = Append(value:  ")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);");
            // 0x0110AB18: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x0110AB1C: LDR x8, [x8, #0xb50]       | X8 = (string**)(1152921512832400704)("\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (");
            // 0x0110AB20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB24: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB28: LDR x1, [x8]               | X1 = "\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (";
            // 0x0110AB2C: BL #0x1b5b818              | X0 = Append(value:  "\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_24 = Append(value:  "\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (");
            // 0x0110AB30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB34: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB38: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AB3C: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_25 = Append(value:  X2);
            // 0x0110AB40: LDR x1, [x22]              | X1 = ")typeof(";                        
            // 0x0110AB44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB48: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB4C: BL #0x1b5b818              | X0 = Append(value:  ")typeof(");        
            System.Text.StringBuilder val_26 = Append(value:  ")typeof(");
            // 0x0110AB50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB54: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB58: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AB5C: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_27 = Append(value:  X2);
            // 0x0110AB60: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x0110AB64: LDR x8, [x8, #0x160]       | X8 = (string**)(1152921512832417888)(").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])");
            // 0x0110AB68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB6C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB70: LDR x1, [x8]               | X1 = ").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])";
            // 0x0110AB74: BL #0x1b5b818              | X0 = Append(value:  ").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])");
            System.Text.StringBuilder val_28 = Append(value:  ").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])");
            // 0x0110AB78: LDR x1, [x23]              | X1 = ";";                               
            // 0x0110AB7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB80: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB84: BL #0x1b5b818              | X0 = Append(value:  ";");               
            System.Text.StringBuilder val_29 = Append(value:  ";");
            // 0x0110AB88: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x0110AB8C: LDR x8, [x8, #0xf00]       | X8 = (string**)(1152921512832426304)("\n                        }\n                        else\n                        {\n                            instance_of_this_method = (");
            // 0x0110AB90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AB94: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AB98: LDR x1, [x8]               | X1 = "\n                        }\n                        else\n                        {\n                            instance_of_this_method = (";
            // 0x0110AB9C: BL #0x1b5b818              | X0 = Append(value:  "\n                        }\n                        else\n                        {\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_30 = Append(value:  "\n                        }\n                        else\n                        {\n                            instance_of_this_method = (");
            // 0x0110ABA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ABA4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ABA8: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110ABAC: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_31 = Append(value:  X2);
            // 0x0110ABB0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x0110ABB4: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921512832434848)(")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110ABB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ABBC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ABC0: LDR x1, [x8]               | X1 = ")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ";
            // 0x0110ABC4: BL #0x1b5b818              | X0 = Append(value:  ")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            System.Text.StringBuilder val_32 = Append(value:  ")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110ABC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ABCC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ABD0: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110ABD4: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_33 = Append(value:  X2);
            // 0x0110ABD8: B #0x110adc0               |  goto label_19;                         
            goto label_19;
            label_18:
            // 0x0110ABDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x0110ABE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ABE4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ABE8: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x0110ABEC: BL #0x1b5c068              | X0 = AppendLine(value:  val_13);        
            System.Text.StringBuilder val_34 = AppendLine(value:  val_13);
            // 0x0110ABF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            // 0x0110ABF4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0110ABF8: LDR x8, [x8, #0xeb0]       | X8 = (string**)(1152921512832361840)("            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (");
            // 0x0110ABFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC00: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC04: LDR x1, [x8]               | X1 = "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (";
            // 0x0110AC08: BL #0x1b5b818              | X0 = Append(value:  "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_35 = Append(value:  "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.FieldReference:\n                    {\n                        var instance_of_fieldReference = __mStack[ptr_of_this_method->Value];\n                        if(instance_of_fieldReference is ILTypeInstance)\n                        {\n                            instance_of_this_method = (");
            // 0x0110AC0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            // 0x0110AC10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC14: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC18: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AC1C: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_36 = Append(value:  X2);
            // 0x0110AC20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            // 0x0110AC24: ADRP x22, #0x367a000       | X22 = 57122816 (0x367A000);             
            // 0x0110AC28: LDR x22, [x22, #0x3a8]     | X22 = (string**)(1152921512832370896)(")typeof(");
            // 0x0110AC2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC30: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC34: LDR x1, [x22]              | X1 = ")typeof(";                        
            // 0x0110AC38: BL #0x1b5b818              | X0 = Append(value:  ")typeof(");        
            System.Text.StringBuilder val_37 = Append(value:  ")typeof(");
            // 0x0110AC3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            // 0x0110AC40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC44: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC48: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AC4C: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_38 = Append(value:  X2);
            // 0x0110AC50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            // 0x0110AC54: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x0110AC58: LDR x8, [x8, #0x9f8]       | X8 = (string**)(1152921512832379184)(").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])");
            // 0x0110AC5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC60: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC64: LDR x1, [x8]               | X1 = ").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])";
            // 0x0110AC68: BL #0x1b5b818              | X0 = Append(value:  ").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])");
            System.Text.StringBuilder val_39 = Append(value:  ").CheckCLRTypes(((ILTypeInstance)instance_of_fieldReference)[ptr_of_this_method->ValueLow])");
            // 0x0110AC6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            // 0x0110AC70: ADRP x23, #0x3640000       | X23 = 56885248 (0x3640000);             
            // 0x0110AC74: LDR x23, [x23, #0x608]     | X23 = (string**)(1152921512830809120)(";");
            val_90 = ";";
            // 0x0110AC78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC7C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC80: LDR x1, [x23]              | X1 = ";";                               
            // 0x0110AC84: BL #0x1b5b818              | X0 = Append(value:  ";");               
            System.Text.StringBuilder val_40 = Append(value:  ";");
            // 0x0110AC88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            // 0x0110AC8C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x0110AC90: LDR x8, [x8, #0x3e0]       | X8 = (string**)(1152921512832387632)("\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (");
            // 0x0110AC94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AC98: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AC9C: LDR x1, [x8]               | X1 = "\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (";
            // 0x0110ACA0: BL #0x1b5b818              | X0 = Append(value:  "\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_41 = Append(value:  "\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(instance_of_fieldReference.GetType()) as CLRType;\n                            instance_of_this_method = (");
            // 0x0110ACA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
            // 0x0110ACA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ACAC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ACB0: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110ACB4: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_42 = Append(value:  X2);
            // 0x0110ACB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            // 0x0110ACBC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0110ACC0: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921512832396384)(")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);");
            // 0x0110ACC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ACC8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ACCC: LDR x1, [x8]               | X1 = ")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);";
            // 0x0110ACD0: BL #0x1b5b818              | X0 = Append(value:  ")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);");
            System.Text.StringBuilder val_43 = Append(value:  ")t.GetFieldValue(ptr_of_this_method->ValueLow, instance_of_fieldReference);");
            // 0x0110ACD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
            // 0x0110ACD8: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x0110ACDC: LDR x8, [x8, #0xb50]       | X8 = (string**)(1152921512832400704)("\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (");
            // 0x0110ACE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ACE4: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ACE8: LDR x1, [x8]               | X1 = "\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (";
            // 0x0110ACEC: BL #0x1b5b818              | X0 = Append(value:  "\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_44 = Append(value:  "\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            instance_of_this_method = (");
            // 0x0110ACF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
            // 0x0110ACF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ACF8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ACFC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AD00: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_45 = Append(value:  X2);
            // 0x0110AD04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
            // 0x0110AD08: LDR x1, [x22]              | X1 = ")typeof(";                        
            // 0x0110AD0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD10: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AD14: BL #0x1b5b818              | X0 = Append(value:  ")typeof(");        
            System.Text.StringBuilder val_46 = Append(value:  ")typeof(");
            // 0x0110AD18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            // 0x0110AD1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD20: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AD24: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AD28: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_47 = Append(value:  X2);
            // 0x0110AD2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
            // 0x0110AD30: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x0110AD34: LDR x8, [x8, #0x160]       | X8 = (string**)(1152921512832417888)(").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])");
            // 0x0110AD38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD3C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AD40: LDR x1, [x8]               | X1 = ").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])";
            // 0x0110AD44: BL #0x1b5b818              | X0 = Append(value:  ").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])");
            System.Text.StringBuilder val_48 = Append(value:  ").CheckCLRTypes(((ILType)t).StaticInstance[ptr_of_this_method->ValueLow])");
            // 0x0110AD48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
            // 0x0110AD4C: LDR x1, [x23]              | X1 = ";";                               
            // 0x0110AD50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD54: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AD58: BL #0x1b5b818              | X0 = Append(value:  ";");               
            System.Text.StringBuilder val_49 = Append(value:  ";");
            // 0x0110AD5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
            // 0x0110AD60: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x0110AD64: LDR x8, [x8, #0xf00]       | X8 = (string**)(1152921512832426304)("\n                        }\n                        else\n                        {\n                            instance_of_this_method = (");
            // 0x0110AD68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD6C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AD70: LDR x1, [x8]               | X1 = "\n                        }\n                        else\n                        {\n                            instance_of_this_method = (";
            // 0x0110AD74: BL #0x1b5b818              | X0 = Append(value:  "\n                        }\n                        else\n                        {\n                            instance_of_this_method = (");
            System.Text.StringBuilder val_50 = Append(value:  "\n                        }\n                        else\n                        {\n                            instance_of_this_method = (");
            // 0x0110AD78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
            // 0x0110AD7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD80: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AD84: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AD88: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_51 = Append(value:  X2);
            // 0x0110AD8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            // 0x0110AD90: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x0110AD94: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921512832434848)(")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110AD98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AD9C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ADA0: LDR x1, [x8]               | X1 = ")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ";
            // 0x0110ADA4: BL #0x1b5b818              | X0 = Append(value:  ")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            System.Text.StringBuilder val_52 = Append(value:  ")((CLRType)t).GetFieldValue(ptr_of_this_method->ValueLow, null);\n                        }\n                    }\n                    break;\n                case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110ADA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
            // 0x0110ADAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ADB0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ADB4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110ADB8: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_53 = Append(value:  X2);
            // 0x0110ADBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_53, ????);     
            label_19:
            // 0x0110ADC0: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x0110ADC4: LDR x8, [x8, #0xb70]       | X8 = (string**)(1152921512832525664)("[];\n                        instance_of_this_method = instance_of_arrayReference[ptr_of_this_method->ValueLow];                        \n                    }\n                    break;\n                default:");
            // 0x0110ADC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110ADCC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110ADD0: LDR x1, [x8]               | X1 = "[];\n                        instance_of_this_method = instance_of_arrayReference[ptr_of_this_method->ValueLow];                        \n                    }\n                    break;\n                default:";
            // 0x0110ADD4: BL #0x1b5c068              | X0 = AppendLine(value:  "[];\n                        instance_of_this_method = instance_of_arrayReference[ptr_of_this_method->ValueLow];                        \n                    }\n                    break;\n                default:");
            System.Text.StringBuilder val_54 = AppendLine(value:  "[];\n                        instance_of_this_method = instance_of_arrayReference[ptr_of_this_method->ValueLow];                        \n                    }\n                    break;\n                default:");
            // 0x0110ADD8: MOV x1, x21                | X1 = typeClsName;//m1                   
            // 0x0110ADDC: MOV x2, x20                | X2 = X2;//m1                            
            // 0x0110ADE0: BL #0x1108f2c              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  System.Text.StringBuilder val_54 = AppendLine(value:  "[];\n                        instance_of_this_method = instance_of_arrayReference[ptr_of_this_method->ValueLow];                        \n                    }\n                    break;\n                default:"), realClsName:  val_88);
            string val_55 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  val_54, realClsName:  val_88);
            // 0x0110ADE4: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0110ADE8: LDR x8, [x8, #0x460]       | X8 = (string**)(1152921512832534352)("                    instance_of_this_method = {0};");
            // 0x0110ADEC: MOV x2, x0                 | X2 = val_55;//m1                        
            // 0x0110ADF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110ADF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110ADF8: LDR x1, [x8]               | X1 = "                    instance_of_this_method = {0};";
            // 0x0110ADFC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "                    instance_of_this_method = {0};");
            string val_56 = System.String.Format(format:  0, arg0:  "                    instance_of_this_method = {0};");
            // 0x0110AE00: MOV x22, x0                | X22 = val_56;//m1                       
            // 0x0110AE04: CBZ x19, #0x110ae34        | if ( == 0) goto label_20;               
            if(null == 0)
            {
                goto label_20;
            }
            // 0x0110AE08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AE0C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AE10: MOV x1, x22                | X1 = val_56;//m1                        
            // 0x0110AE14: BL #0x1b5c068              | X0 = AppendLine(value:  val_56);        
            System.Text.StringBuilder val_57 = AppendLine(value:  val_56);
            // 0x0110AE18: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0110AE1C: LDR x8, [x8, #0x7a0]       | X8 = (string**)(1152921512832542720)("                    break;\n            }\n            return instance_of_this_method;");
            // 0x0110AE20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AE24: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AE28: LDR x1, [x8]               | X1 = "                    break;\n            }\n            return instance_of_this_method;";
            // 0x0110AE2C: BL #0x1b5c068              | X0 = AppendLine(value:  "                    break;\n            }\n            return instance_of_this_method;");
            System.Text.StringBuilder val_58 = AppendLine(value:  "                    break;\n            }\n            return instance_of_this_method;");
            // 0x0110AE30: B #0x110ae68               |  goto label_21;                         
            goto label_21;
            label_20:
            // 0x0110AE34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
            // 0x0110AE38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AE3C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AE40: MOV x1, x22                | X1 = val_56;//m1                        
            // 0x0110AE44: BL #0x1b5c068              | X0 = AppendLine(value:  val_56);        
            System.Text.StringBuilder val_59 = AppendLine(value:  val_56);
            // 0x0110AE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
            // 0x0110AE4C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0110AE50: LDR x8, [x8, #0x7a0]       | X8 = (string**)(1152921512832542720)("                    break;\n            }\n            return instance_of_this_method;");
            // 0x0110AE54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AE58: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AE5C: LDR x1, [x8]               | X1 = "                    break;\n            }\n            return instance_of_this_method;";
            // 0x0110AE60: BL #0x1b5c068              | X0 = AppendLine(value:  "                    break;\n            }\n            return instance_of_this_method;");
            System.Text.StringBuilder val_60 = AppendLine(value:  "                    break;\n            }\n            return instance_of_this_method;");
            // 0x0110AE64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_60, ????);     
            label_21:
            // 0x0110AE68: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x0110AE6C: LDR x8, [x8, #0x20]        | X8 = (string**)(1152921512832555248)("        }");
            // 0x0110AE70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AE74: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AE78: LDR x1, [x8]               | X1 = "        }";                       
            // 0x0110AE7C: BL #0x1b5c068              | X0 = AppendLine(value:  "        }");   
            System.Text.StringBuilder val_61 = AppendLine(value:  "        }");
            label_4:
            // 0x0110AE80: CBNZ x21, #0x110ae88       | if (typeClsName != null) goto label_22; 
            if(val_88 != null)
            {
                goto label_22;
            }
            // 0x0110AE84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
            label_22:
            // 0x0110AE88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_91 = 0;
            // 0x0110AE8C: MOV x0, x21                | X0 = typeClsName;//m1                   
            // 0x0110AE90: BL #0x1b6d41c              | X0 = typeClsName.get_IsPrimitive();     
            bool val_62 = val_88.IsPrimitive;
            // 0x0110AE94: AND w8, w0, #1             | W8 = (val_62 & 1);                      
            bool val_63 = val_62;
            // 0x0110AE98: TBNZ w8, #0, #0x110b104    | if ((val_62 & 1) == true) goto label_25;
            if(val_63 == true)
            {
                goto label_25;
            }
            // 0x0110AE9C: CBNZ x21, #0x110aea4       | if (typeClsName != null) goto label_24; 
            if(val_88 != null)
            {
                goto label_24;
            }
            // 0x0110AEA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
            label_24:
            // 0x0110AEA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_91 = 0;
            // 0x0110AEA8: MOV x0, x21                | X0 = typeClsName;//m1                   
            // 0x0110AEAC: BL #0x1b6d1a8              | X0 = typeClsName.get_IsAbstract();      
            bool val_64 = val_88.IsAbstract;
            // 0x0110AEB0: AND w8, w0, #1             | W8 = (val_64 & 1);                      
            bool val_65 = val_64;
            // 0x0110AEB4: TBNZ w8, #0, #0x110b104    | if ((val_64 & 1) == true) goto label_25;
            if(val_65 == true)
            {
                goto label_25;
            }
            // 0x0110AEB8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0110AEBC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110AEC0: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110AEC4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110AEC8: TBZ w8, #0, #0x110aed8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x0110AECC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110AED0: CBNZ w8, #0x110aed8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x0110AED4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_27:
            // 0x0110AED8: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x0110AEDC: LDR x8, [x8, #0x6d8]       | X8 = (string**)(1152921512832559440)("        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref {0} instance_of_this_method)");
            // 0x0110AEE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110AEE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110AEE8: MOV x2, x20                | X2 = X2;//m1                            
            // 0x0110AEEC: LDR x1, [x8]               | X1 = "        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref {0} instance_of_this_method)";
            // 0x0110AEF0: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref {0} instance_of_this_method)");
            string val_66 = System.String.Format(format:  0, arg0:  "        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref {0} instance_of_this_method)");
            // 0x0110AEF4: MOV x21, x0                | X21 = val_66;//m1                       
            val_88 = val_66;
            // 0x0110AEF8: CBZ x19, #0x110afe0        | if ( == 0) goto label_28;               
            if(null == 0)
            {
                goto label_28;
            }
            // 0x0110AEFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF00: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF04: MOV x1, x21                | X1 = val_66;//m1                        
            // 0x0110AF08: BL #0x1b5c068              | X0 = AppendLine(value:  val_88);        
            System.Text.StringBuilder val_67 = AppendLine(value:  val_88);
            // 0x0110AF0C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x0110AF10: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921512832344928)("        {");
            // 0x0110AF14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF18: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF1C: LDR x1, [x8]               | X1 = "        {";                       
            // 0x0110AF20: BL #0x1b5c068              | X0 = AppendLine(value:  "        {");   
            System.Text.StringBuilder val_68 = AppendLine(value:  "        {");
            // 0x0110AF24: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x0110AF28: LDR x8, [x8, #0x180]       | X8 = (string**)(1152921512832572160)("            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;");
            // 0x0110AF2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF30: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF34: LDR x1, [x8]               | X1 = "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;";
            // 0x0110AF38: BL #0x1b5c068              | X0 = AppendLine(value:  "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;");
            System.Text.StringBuilder val_69 = AppendLine(value:  "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;");
            // 0x0110AF3C: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x0110AF40: LDR x8, [x8, #0xb28]       | X8 = (string**)(1152921512832576960)("                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110AF44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF48: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF4C: LDR x1, [x8]               | X1 = "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method";
            // 0x0110AF50: BL #0x1b5b818              | X0 = Append(value:  "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method");
            System.Text.StringBuilder val_70 = Append(value:  "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110AF54: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110AF58: LDR x8, [x8, #0x148]       | X8 = (string**)(1152921512832581904)(";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method");
            // 0x0110AF5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF60: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF64: LDR x1, [x8]               | X1 = ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method";
            // 0x0110AF68: BL #0x1b5b818              | X0 = Append(value:  ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method");
            System.Text.StringBuilder val_71 = Append(value:  ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method");
            // 0x0110AF6C: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x0110AF70: LDR x8, [x8, #0x760]       | X8 = (string**)(1152921512832586640)(");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110AF74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF78: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF7C: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method";
            // 0x0110AF80: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method");
            System.Text.StringBuilder val_72 = Append(value:  ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110AF84: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0110AF88: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921512832591648)(";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method");
            // 0x0110AF8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AF90: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AF94: LDR x1, [x8]               | X1 = ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method";
            // 0x0110AF98: BL #0x1b5b818              | X0 = Append(value:  ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method");
            System.Text.StringBuilder val_73 = Append(value:  ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method");
            // 0x0110AF9C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0110AFA0: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921512832596224)(");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110AFA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AFA8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AFAC: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ";
            // 0x0110AFB0: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            System.Text.StringBuilder val_74 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110AFB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AFB8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AFBC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110AFC0: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_75 = Append(value:  X2);
            // 0x0110AFC4: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x0110AFC8: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921512832604992)("[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }");
            // 0x0110AFCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AFD0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AFD4: LDR x1, [x8]               | X1 = "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }";
            // 0x0110AFD8: BL #0x1b5c068              | X0 = AppendLine(value:  "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }");
            System.Text.StringBuilder val_76 = AppendLine(value:  "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }");
            // 0x0110AFDC: B #0x110b0ec               |  goto label_29;                         
            goto label_29;
            label_28:
            // 0x0110AFE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
            // 0x0110AFE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110AFE8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110AFEC: MOV x1, x21                | X1 = val_66;//m1                        
            // 0x0110AFF0: BL #0x1b5c068              | X0 = AppendLine(value:  val_88);        
            System.Text.StringBuilder val_77 = AppendLine(value:  val_88);
            // 0x0110AFF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
            // 0x0110AFF8: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x0110AFFC: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921512832344928)("        {");
            // 0x0110B000: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B004: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B008: LDR x1, [x8]               | X1 = "        {";                       
            // 0x0110B00C: BL #0x1b5c068              | X0 = AppendLine(value:  "        {");   
            System.Text.StringBuilder val_78 = AppendLine(value:  "        {");
            // 0x0110B010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
            // 0x0110B014: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x0110B018: LDR x8, [x8, #0x180]       | X8 = (string**)(1152921512832572160)("            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;");
            // 0x0110B01C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B020: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B024: LDR x1, [x8]               | X1 = "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;";
            // 0x0110B028: BL #0x1b5c068              | X0 = AppendLine(value:  "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;");
            System.Text.StringBuilder val_79 = AppendLine(value:  "            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);\n            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.Object:\n                    {\n                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;");
            // 0x0110B02C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_79, ????);     
            // 0x0110B030: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x0110B034: LDR x8, [x8, #0xb28]       | X8 = (string**)(1152921512832576960)("                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110B038: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B03C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B040: LDR x1, [x8]               | X1 = "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method";
            // 0x0110B044: BL #0x1b5b818              | X0 = Append(value:  "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method");
            System.Text.StringBuilder val_80 = Append(value:  "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110B048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
            // 0x0110B04C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110B050: LDR x8, [x8, #0x148]       | X8 = (string**)(1152921512832581904)(";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method");
            // 0x0110B054: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B058: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B05C: LDR x1, [x8]               | X1 = ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method";
            // 0x0110B060: BL #0x1b5b818              | X0 = Append(value:  ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method");
            System.Text.StringBuilder val_81 = Append(value:  ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method");
            // 0x0110B064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_81, ????);     
            // 0x0110B068: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x0110B06C: LDR x8, [x8, #0x760]       | X8 = (string**)(1152921512832586640)(");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110B070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B074: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B078: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method";
            // 0x0110B07C: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method");
            System.Text.StringBuilder val_82 = Append(value:  ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method");
            // 0x0110B080: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
            // 0x0110B084: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0110B088: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921512832591648)(";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method");
            // 0x0110B08C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B090: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B094: LDR x1, [x8]               | X1 = ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method";
            // 0x0110B098: BL #0x1b5b818              | X0 = Append(value:  ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method");
            System.Text.StringBuilder val_83 = Append(value:  ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method");
            // 0x0110B09C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_83, ????);     
            // 0x0110B0A0: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0110B0A4: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921512832596224)(");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110B0A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B0AC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B0B0: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ";
            // 0x0110B0B4: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            System.Text.StringBuilder val_84 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110B0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_84, ????);     
            // 0x0110B0BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B0C0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B0C4: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110B0C8: BL #0x1b5b818              | X0 = Append(value:  X2);                
            System.Text.StringBuilder val_85 = Append(value:  X2);
            // 0x0110B0CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
            // 0x0110B0D0: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x0110B0D4: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921512832604992)("[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }");
            // 0x0110B0D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B0DC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B0E0: LDR x1, [x8]               | X1 = "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }";
            // 0x0110B0E4: BL #0x1b5c068              | X0 = AppendLine(value:  "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }");
            System.Text.StringBuilder val_86 = AppendLine(value:  "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;\n                    }\n                    break;\n            }");
            // 0x0110B0E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_86, ????);     
            label_29:
            // 0x0110B0EC: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x0110B0F0: LDR x8, [x8, #0x20]        | X8 = (string**)(1152921512832555248)("        }");
            // 0x0110B0F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B0F8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B0FC: LDR x1, [x8]               | X1 = "        }";                       
            val_91 = "        }";
            // 0x0110B100: BL #0x1b5c068              | X0 = AppendLine(value:  val_91 = "        }");
            System.Text.StringBuilder val_87 = AppendLine(value:  val_91);
            label_25:
            // 0x0110B104: CBNZ x19, #0x110b10c       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x0110B108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_87, ????);     
            label_30:
            // 0x0110B10C: LDR x8, [x19]              | X8 = ;                                  
            // 0x0110B110: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B114: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x0110B118: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0110B11C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0110B120: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0110B124: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0110B128: BR x2                      | goto mem[null + 320];                   
            goto mem[null + 320];
        
        }
    
    }

}
