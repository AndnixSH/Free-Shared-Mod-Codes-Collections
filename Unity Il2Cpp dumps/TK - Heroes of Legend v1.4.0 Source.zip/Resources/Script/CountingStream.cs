using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    public class CountingStream : Stream
    {
        // Fields
        private System.IO.Stream _s; //  0x00000010
        private long _bytesWritten; //  0x00000018
        private long _bytesRead; //  0x00000020
        private long _initialOffset; //  0x00000028
        
        // Properties
        public System.IO.Stream WrappedStream { get; }
        public long BytesWritten { get; }
        public long BytesRead { get; }
        public override bool CanRead { get; }
        public override bool CanSeek { get; }
        public override bool CanWrite { get; }
        public override long Length { get; }
        public long ComputedPosition { get; }
        public override long Position { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x019707B0 (26675120), len: 292  VirtAddr: 0x019707B0 RVA: 0x019707B0 token: 100663385 methodIndex: 20863 delegateWrapperIndex: 0 methodInvoker: 0
        public CountingStream(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            // 0x019707B0: STP x22, x21, [sp, #-0x30]! | stack[1152921509635088672] = ???;  stack[1152921509635088680] = ???;  //  dest_result_addr=1152921509635088672 |  dest_result_addr=1152921509635088680
            // 0x019707B4: STP x20, x19, [sp, #0x10]  | stack[1152921509635088688] = ???;  stack[1152921509635088696] = ???;  //  dest_result_addr=1152921509635088688 |  dest_result_addr=1152921509635088696
            // 0x019707B8: STP x29, x30, [sp, #0x20]  | stack[1152921509635088704] = ???;  stack[1152921509635088712] = ???;  //  dest_result_addr=1152921509635088704 |  dest_result_addr=1152921509635088712
            // 0x019707BC: ADD x29, sp, #0x20         | X29 = (1152921509635088672 + 32) = 1152921509635088704 (0x100000012BB4E140);
            // 0x019707C0: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x019707C4: LDRB w8, [x21, #0x3e2]     | W8 = (bool)static_value_037393E2;       
            // 0x019707C8: MOV x20, x1                | X20 = stream;//m1                       
            // 0x019707CC: MOV x19, x0                | X19 = 1152921509635100720 (0x100000012BB51030);//ML01
            // 0x019707D0: TBNZ w8, #0, #0x19707ec    | if (static_value_037393E2 == true) goto label_0;
            // 0x019707D4: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x019707D8: LDR x8, [x8, #0xd48]       | X8 = 0x2B92D54;                         
            // 0x019707DC: LDR w0, [x8]               | W0 = 0x221A;                            
            // 0x019707E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x221A, ????);     
            // 0x019707E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x019707E8: STRB w8, [x21, #0x3e2]     | static_value_037393E2 = true;            //  dest_result_addr=57906146
            label_0:
            // 0x019707EC: ADRP x21, #0x3654000       | X21 = 56967168 (0x3654000);             
            // 0x019707F0: LDR x21, [x21, #0x898]     | X21 = 1152921504622342144;              
            // 0x019707F4: LDR x0, [x21]              | X0 = typeof(System.IO.Stream);          
            // 0x019707F8: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Stream.__il2cppRuntimeField_10A;
            // 0x019707FC: TBZ w8, #0, #0x197080c     | if (System.IO.Stream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01970800: LDR w8, [x0, #0xbc]        | W8 = System.IO.Stream.__il2cppRuntimeField_cctor_finished;
            // 0x01970804: CBNZ w8, #0x197080c        | if (System.IO.Stream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01970808: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Stream), ????);
            label_2:
            // 0x0197080C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01970810: MOV x0, x19                | X0 = 1152921509635100720 (0x100000012BB51030);//ML01
            // 0x01970814: BL #0x1e73764              | this..ctor();                           
            // 0x01970818: STR x20, [x19, #0x10]      | this._s = stream;                        //  dest_result_addr=1152921509635100736
            this._s = stream;
            // 0x0197081C: CBNZ x20, #0x1970824       | if (stream != null) goto label_3;       
            if(stream != null)
            {
                goto label_3;
            }
            // 0x01970820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x01970824: LDR x0, [x21]              | X0 = typeof(System.IO.Stream);          
            // 0x01970828: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Stream.__il2cppRuntimeField_10A;
            // 0x0197082C: TBZ w8, #0, #0x197083c     | if (System.IO.Stream.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01970830: LDR w8, [x0, #0xbc]        | W8 = System.IO.Stream.__il2cppRuntimeField_cctor_finished;
            // 0x01970834: CBNZ w8, #0x197083c        | if (System.IO.Stream.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01970838: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Stream), ????);
            label_5:
            // 0x0197083C: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x01970840: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_1A0; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_1A8; //  | 
            // 0x01970844: MOV x0, x20                | X0 = stream;//m1                        
            // 0x01970848: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_1A0();
            // 0x0197084C: STR x0, [x19, #0x28]       | this._initialOffset = stream;            //  dest_result_addr=1152921509635100760
            this._initialOffset = stream;
            // 0x01970850: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01970854: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01970858: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0197085C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x019708D4 (26675412), len: 8  VirtAddr: 0x019708D4 RVA: 0x019708D4 token: 100663386 methodIndex: 20864 delegateWrapperIndex: 0 methodInvoker: 0
        public System.IO.Stream get_WrappedStream()
        {
            //
            // Disasemble & Code
            // 0x019708D4: LDR x0, [x0, #0x10]        | X0 = this._s; //P2                      
            // 0x019708D8: RET                        |  return (System.IO.Stream)this._s;      
            return this._s;
            //  |  // // {name=val_0, type=System.IO.Stream, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x019708DC (26675420), len: 8  VirtAddr: 0x019708DC RVA: 0x019708DC token: 100663387 methodIndex: 20865 delegateWrapperIndex: 0 methodInvoker: 0
        public long get_BytesWritten()
        {
            //
            // Disasemble & Code
            // 0x019708DC: LDR x0, [x0, #0x18]        | X0 = this._bytesWritten; //P2           
            // 0x019708E0: RET                        |  return (System.Int64)this._bytesWritten;
            return this._bytesWritten;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x019708E4 (26675428), len: 8  VirtAddr: 0x019708E4 RVA: 0x019708E4 token: 100663388 methodIndex: 20866 delegateWrapperIndex: 0 methodInvoker: 0
        public long get_BytesRead()
        {
            //
            // Disasemble & Code
            // 0x019708E4: LDR x0, [x0, #0x20]        | X0 = this._bytesRead; //P2              
            // 0x019708E8: RET                        |  return (System.Int64)this._bytesRead;  
            return this._bytesRead;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x019708EC (26675436), len: 320  VirtAddr: 0x019708EC RVA: 0x019708EC token: 100663389 methodIndex: 20867 delegateWrapperIndex: 0 methodInvoker: 0
        public void Adjust(long delta)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            label_7:
            // 0x019708EC: STP x22, x21, [sp, #-0x30]! | stack[1152921509635554080] = ???;  stack[1152921509635554088] = ???;  //  dest_result_addr=1152921509635554080 |  dest_result_addr=1152921509635554088
            // 0x019708F0: STP x20, x19, [sp, #0x10]  | stack[1152921509635554096] = ???;  stack[1152921509635554104] = ???;  //  dest_result_addr=1152921509635554096 |  dest_result_addr=1152921509635554104
            // 0x019708F4: STP x29, x30, [sp, #0x20]  | stack[1152921509635554112] = ???;  stack[1152921509635554120] = ???;  //  dest_result_addr=1152921509635554112 |  dest_result_addr=1152921509635554120
            // 0x019708F8: ADD x29, sp, #0x20         | X29 = (1152921509635554080 + 32) = 1152921509635554112 (0x100000012BBBFB40);
            // 0x019708FC: SUB sp, sp, #0x10          | SP = (1152921509635554080 - 16) = 1152921509635554064 (0x100000012BBBFB10);
            // 0x01970900: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
            // 0x01970904: LDRB w8, [x21, #0x3e3]     | W8 = (bool)static_value_037393E3;       
            // 0x01970908: MOV x19, x1                | X19 = delta;//m1                        
            // 0x0197090C: MOV x20, x0                | X20 = 1152921509635566128 (0x100000012BBC2A30);//ML01
            // 0x01970910: TBNZ w8, #0, #0x197092c    | if (static_value_037393E3 == true) goto label_0;
            // 0x01970914: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x01970918: LDR x8, [x8, #0x150]       | X8 = 0x2B92D58;                         
            // 0x0197091C: LDR w0, [x8]               | W0 = 0x221B;                            
            // 0x01970920: BL #0x2782188              | X0 = sub_2782188( ?? 0x221B, ????);     
            // 0x01970924: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01970928: STRB w8, [x21, #0x3e3]     | static_value_037393E3 = true;            //  dest_result_addr=57906147
            label_0:
            // 0x0197092C: LDR x8, [x20, #0x18]       | X8 = this._bytesWritten; //P2           
            long val_4 = this._bytesWritten;
            // 0x01970930: SUB x8, x8, x19            | X8 = (this._bytesWritten - delta);      
            val_4 = val_4 - delta;
            // 0x01970934: STR x8, [x20, #0x18]       | this._bytesWritten = (this._bytesWritten - delta);  //  dest_result_addr=1152921509635566152
            this._bytesWritten = val_4;
            // 0x01970938: TBNZ x8, #0x3f, #0x19709e4 | if (((this._bytesWritten - delta) & 0x8000000000000000) != 0) goto label_1;
            if((val_4 & 9223372036854775808) != 0)
            {
                goto label_1;
            }
            // 0x0197093C: LDR x0, [x20, #0x10]       | X0 = this._s; //P2                      
            // 0x01970940: CBZ x0, #0x19709d0         | if (this._s == null) goto label_4;      
            if(this._s == null)
            {
                goto label_4;
            }
            // 0x01970944: ADRP x9, #0x3647000        | X9 = 56913920 (0x3647000);              
            // 0x01970948: LDR x9, [x9, #0x4e8]       | X9 = 1152921504751255552;               
            // 0x0197094C: LDR x8, [x0]               | X8 = typeof(System.IO.Stream);          
            // 0x01970950: LDR x1, [x9]               | X1 = typeof(Pathfinding.Ionic.Zip.CountingStream);
            // 0x01970954: LDRB w10, [x8, #0x104]     | W10 = System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01970958: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0197095C: CMP w10, w9                | STATE = COMPARE(System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01970960: B.LO #0x19709d0            | if (System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x01970964: LDR x8, [x8, #0xb0]        | X8 = System.IO.Stream.__il2cppRuntimeField_typeHierarchy;
            // 0x01970968: ADD x8, x8, x9, lsl #3     | X8 = (System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__
            // 0x0197096C: LDUR x8, [x8, #-8]         | X8 = (System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01970970: CMP x8, x1                 | STATE = COMPARE((System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.Ionic.Zip.CountingStream))
            // 0x01970974: B.NE #0x19709d0            | if ((System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_4;
            // 0x01970978: LDR x8, [x0]               | X8 = typeof(System.IO.Stream);          
            // 0x0197097C: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01970980: LDRB w10, [x8, #0x104]     | W10 = System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01970984: CMP w10, w9                | STATE = COMPARE(System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01970988: B.LO #0x19709a0            | if (System.IO.Stream.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x0197098C: LDR x10, [x8, #0xb0]       | X10 = System.IO.Stream.__il2cppRuntimeField_typeHierarchy;
            // 0x01970990: ADD x9, x10, x9, lsl #3    | X9 = (System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__
            // 0x01970994: LDUR x9, [x9, #-8]         | X9 = (System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01970998: CMP x9, x1                 | STATE = COMPARE((System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.Ionic.Zip.CountingStream))
            // 0x0197099C: B.EQ #0x19709c8            | if ((System.IO.Stream.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Ionic.Zip.CountingStream.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_6;
            label_5:
            // 0x019709A0: LDR x0, [x8, #0x30]        | X0 = System.IO.Stream.__il2cppRuntimeField_element_class;
            // 0x019709A4: ADD x8, sp, #8             | X8 = (1152921509635554064 + 8) = 1152921509635554072 (0x100000012BBBFB18);
            // 0x019709A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.IO.Stream.__il2cppRuntimeField_element_class, ????);
            // 0x019709AC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921509635542128]
            // 0x019709B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x019709B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019709B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x019709BC: ADD x0, sp, #8             | X0 = (1152921509635554064 + 8) = 1152921509635554072 (0x100000012BBBFB18);
            // 0x019709C0: BL #0x299a140              | 
            // 0x019709C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_6:
            // 0x019709C8: MOV x1, x19                | X1 = delta;//m1                         
            // 0x019709CC: BL #0x19708ec              |  R0 = label_7();                        
            label_4:
            // 0x019709D0: SUB sp, x29, #0x20         | SP = (1152921509635554112 - 32) = 1152921509635554080 (0x100000012BBBFB20);
            // 0x019709D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x019709D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x019709DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x019709E0: RET                        |  return;                                
            return;
            label_1:
            // 0x019709E4: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x019709E8: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x019709EC: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_3 = null;
            // 0x019709F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x019709F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x019709F8: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x019709FC: BL #0x1e66414              | .ctor();                                
            val_3 = new System.InvalidOperationException();
            // 0x01970A00: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x01970A04: LDR x8, [x8, #0xd40]       | X8 = 1152921509635541104;               
            // 0x01970A08: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x01970A0C: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Ionic.Zip.CountingStream::Adjust(long delta);
            // 0x01970A10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x01970A14: BL #0x196f408              | SlurpBlock(block:  public System.Void Pathfinding.Ionic.Zip.CountingStream::Adjust(long delta), offset:  0, count:  0);
            SlurpBlock(block:  public System.Void Pathfinding.Ionic.Zip.CountingStream::Adjust(long delta), offset:  0, count:  0);
            // 0x01970A18: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x01970A1C: ADD x0, sp, #8             | X0 = (1152921509635554064 + 8) = 1152921509635554072 (0x100000012BBBFB18);
            // 0x01970A20: BL #0x299a140              | 
            // 0x01970A24: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x01970A28: BL #0x980800               | X0 = sub_980800( ?? typeof(System.InvalidOperationException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x01970A2C (26675756), len: 112  VirtAddr: 0x01970A2C RVA: 0x01970A2C token: 100663390 methodIndex: 20868 delegateWrapperIndex: 0 methodInvoker: 0
        public override int Read(byte[] buffer, int offset, int count)
        {
            //
            // Disasemble & Code
            // 0x01970A2C: STP x24, x23, [sp, #-0x40]! | stack[1152921509635711120] = ???;  stack[1152921509635711128] = ???;  //  dest_result_addr=1152921509635711120 |  dest_result_addr=1152921509635711128
            // 0x01970A30: STP x22, x21, [sp, #0x10]  | stack[1152921509635711136] = ???;  stack[1152921509635711144] = ???;  //  dest_result_addr=1152921509635711136 |  dest_result_addr=1152921509635711144
            // 0x01970A34: STP x20, x19, [sp, #0x20]  | stack[1152921509635711152] = ???;  stack[1152921509635711160] = ???;  //  dest_result_addr=1152921509635711152 |  dest_result_addr=1152921509635711160
            // 0x01970A38: STP x29, x30, [sp, #0x30]  | stack[1152921509635711168] = ???;  stack[1152921509635711176] = ???;  //  dest_result_addr=1152921509635711168 |  dest_result_addr=1152921509635711176
            // 0x01970A3C: ADD x29, sp, #0x30         | X29 = (1152921509635711120 + 48) = 1152921509635711168 (0x100000012BBE60C0);
            // 0x01970A40: MOV x19, x0                | X19 = 1152921509635723184 (0x100000012BBE8FB0);//ML01
            // 0x01970A44: LDR x22, [x19, #0x10]      | X22 = this._s; //P2                     
            // 0x01970A48: MOV w20, w3                | W20 = count;//m1                        
            // 0x01970A4C: MOV w21, w2                | W21 = offset;//m1                       
            // 0x01970A50: MOV x23, x1                | X23 = buffer;//m1                       
            // 0x01970A54: CBNZ x22, #0x1970a5c       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970A58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970A5C: LDR x8, [x22]              | X8 = typeof(System.IO.Stream);          
            // 0x01970A60: MOV x0, x22                | X0 = this._s;//m1                       
            // 0x01970A64: MOV x1, x23                | X1 = buffer;//m1                        
            // 0x01970A68: MOV w2, w21                | W2 = offset;//m1                        
            // 0x01970A6C: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x01970A70: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x01970A74: MOV w3, w20                | W3 = count;//m1                         
            // 0x01970A78: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x01970A7C: LDR x8, [x19, #0x20]       | X8 = this._bytesRead; //P2              
            long val_1 = this._bytesRead;
            // 0x01970A80: ADD x8, x8, w0, sxtw       | X8 = (this._bytesRead + (this._s) << ); 
            val_1 = val_1 + (this._s << );
            // 0x01970A84: STR x8, [x19, #0x20]       | this._bytesRead = (this._bytesRead + (this._s) << );  //  dest_result_addr=1152921509635723216
            this._bytesRead = val_1;
            // 0x01970A88: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01970A8C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01970A90: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01970A94: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01970A98: RET                        |  return (System.Int32)this._s;          
            return (int)this._s;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01970A9C (26675868), len: 116  VirtAddr: 0x01970A9C RVA: 0x01970A9C token: 100663391 methodIndex: 20869 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Write(byte[] buffer, int offset, int count)
        {
            //
            // Disasemble & Code
            // 0x01970A9C: STP x24, x23, [sp, #-0x40]! | stack[1152921509635905040] = ???;  stack[1152921509635905048] = ???;  //  dest_result_addr=1152921509635905040 |  dest_result_addr=1152921509635905048
            // 0x01970AA0: STP x22, x21, [sp, #0x10]  | stack[1152921509635905056] = ???;  stack[1152921509635905064] = ???;  //  dest_result_addr=1152921509635905056 |  dest_result_addr=1152921509635905064
            // 0x01970AA4: STP x20, x19, [sp, #0x20]  | stack[1152921509635905072] = ???;  stack[1152921509635905080] = ???;  //  dest_result_addr=1152921509635905072 |  dest_result_addr=1152921509635905080
            // 0x01970AA8: STP x29, x30, [sp, #0x30]  | stack[1152921509635905088] = ???;  stack[1152921509635905096] = ???;  //  dest_result_addr=1152921509635905088 |  dest_result_addr=1152921509635905096
            // 0x01970AAC: ADD x29, sp, #0x30         | X29 = (1152921509635905040 + 48) = 1152921509635905088 (0x100000012BC15640);
            // 0x01970AB0: MOV w19, w3                | W19 = count;//m1                        
            // 0x01970AB4: MOV w21, w2                | W21 = offset;//m1                       
            // 0x01970AB8: MOV x22, x1                | X22 = buffer;//m1                       
            // 0x01970ABC: MOV x20, x0                | X20 = 1152921509635917104 (0x100000012BC18530);//ML01
            // 0x01970AC0: CBZ w19, #0x1970afc        | if (count == 0) goto label_0;           
            if(count == 0)
            {
                goto label_0;
            }
            // 0x01970AC4: LDR x23, [x20, #0x10]      | X23 = this._s; //P2                     
            // 0x01970AC8: CBNZ x23, #0x1970ad0       | if (this._s != null) goto label_1;      
            if(this._s != null)
            {
                goto label_1;
            }
            // 0x01970ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x01970AD0: LDR x8, [x23]              | X8 = typeof(System.IO.Stream);          
            // 0x01970AD4: MOV x0, x23                | X0 = this._s;//m1                       
            // 0x01970AD8: MOV x1, x22                | X1 = buffer;//m1                        
            // 0x01970ADC: MOV w2, w21                | W2 = offset;//m1                        
            // 0x01970AE0: LDR x9, [x8, #0x260]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_260;
            // 0x01970AE4: LDR x4, [x8, #0x268]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_268;
            // 0x01970AE8: MOV w3, w19                | W3 = count;//m1                         
            // 0x01970AEC: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_260();
            // 0x01970AF0: LDR x8, [x20, #0x18]       | X8 = this._bytesWritten; //P2           
            long val_1 = this._bytesWritten;
            // 0x01970AF4: ADD x8, x8, w19, sxtw      | X8 = (this._bytesWritten + (count) << );
            val_1 = val_1 + (count << );
            // 0x01970AF8: STR x8, [x20, #0x18]       | this._bytesWritten = (this._bytesWritten + (count) << );  //  dest_result_addr=1152921509635917128
            this._bytesWritten = val_1;
            label_0:
            // 0x01970AFC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01970B00: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01970B04: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01970B08: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01970B0C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970B10 (26675984), len: 48  VirtAddr: 0x01970B10 RVA: 0x01970B10 token: 100663392 methodIndex: 20870 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanRead()
        {
            //
            // Disasemble & Code
            // 0x01970B10: STP x20, x19, [sp, #-0x20]! | stack[1152921509636062128] = ???;  stack[1152921509636062136] = ???;  //  dest_result_addr=1152921509636062128 |  dest_result_addr=1152921509636062136
            // 0x01970B14: STP x29, x30, [sp, #0x10]  | stack[1152921509636062144] = ???;  stack[1152921509636062152] = ???;  //  dest_result_addr=1152921509636062144 |  dest_result_addr=1152921509636062152
            // 0x01970B18: ADD x29, sp, #0x10         | X29 = (1152921509636062128 + 16) = 1152921509636062144 (0x100000012BC3BBC0);
            // 0x01970B1C: LDR x19, [x0, #0x10]       | X19 = this._s; //P2                     
            // 0x01970B20: CBNZ x19, #0x1970b28       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970B28: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970B2C: MOV x0, x19                | X0 = this._s;//m1                       
            // 0x01970B30: LDP x2, x1, [x8, #0x160]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_160; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_168; //  | 
            // 0x01970B34: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970B38: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970B3C: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_160;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_160;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970B40 (26676032), len: 48  VirtAddr: 0x01970B40 RVA: 0x01970B40 token: 100663393 methodIndex: 20871 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanSeek()
        {
            //
            // Disasemble & Code
            // 0x01970B40: STP x20, x19, [sp, #-0x20]! | stack[1152921509636182320] = ???;  stack[1152921509636182328] = ???;  //  dest_result_addr=1152921509636182320 |  dest_result_addr=1152921509636182328
            // 0x01970B44: STP x29, x30, [sp, #0x10]  | stack[1152921509636182336] = ???;  stack[1152921509636182344] = ???;  //  dest_result_addr=1152921509636182336 |  dest_result_addr=1152921509636182344
            // 0x01970B48: ADD x29, sp, #0x10         | X29 = (1152921509636182320 + 16) = 1152921509636182336 (0x100000012BC59140);
            // 0x01970B4C: LDR x19, [x0, #0x10]       | X19 = this._s; //P2                     
            // 0x01970B50: CBNZ x19, #0x1970b58       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970B58: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970B5C: MOV x0, x19                | X0 = this._s;//m1                       
            // 0x01970B60: LDP x2, x1, [x8, #0x170]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_170; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_178; //  | 
            // 0x01970B64: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970B68: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970B6C: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_170;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_170;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970B70 (26676080), len: 48  VirtAddr: 0x01970B70 RVA: 0x01970B70 token: 100663394 methodIndex: 20872 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanWrite()
        {
            //
            // Disasemble & Code
            // 0x01970B70: STP x20, x19, [sp, #-0x20]! | stack[1152921509636302512] = ???;  stack[1152921509636302520] = ???;  //  dest_result_addr=1152921509636302512 |  dest_result_addr=1152921509636302520
            // 0x01970B74: STP x29, x30, [sp, #0x10]  | stack[1152921509636302528] = ???;  stack[1152921509636302536] = ???;  //  dest_result_addr=1152921509636302528 |  dest_result_addr=1152921509636302536
            // 0x01970B78: ADD x29, sp, #0x10         | X29 = (1152921509636302512 + 16) = 1152921509636302528 (0x100000012BC766C0);
            // 0x01970B7C: LDR x19, [x0, #0x10]       | X19 = this._s; //P2                     
            // 0x01970B80: CBNZ x19, #0x1970b88       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970B84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970B88: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970B8C: MOV x0, x19                | X0 = this._s;//m1                       
            // 0x01970B90: LDP x2, x1, [x8, #0x180]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_180; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_188; //  | 
            // 0x01970B94: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970B98: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970B9C: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_180;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970BA0 (26676128), len: 52  VirtAddr: 0x01970BA0 RVA: 0x01970BA0 token: 100663395 methodIndex: 20873 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Flush()
        {
            //
            // Disasemble & Code
            // 0x01970BA0: STP x20, x19, [sp, #-0x20]! | stack[1152921509636422704] = ???;  stack[1152921509636422712] = ???;  //  dest_result_addr=1152921509636422704 |  dest_result_addr=1152921509636422712
            // 0x01970BA4: STP x29, x30, [sp, #0x10]  | stack[1152921509636422720] = ???;  stack[1152921509636422728] = ???;  //  dest_result_addr=1152921509636422720 |  dest_result_addr=1152921509636422728
            // 0x01970BA8: ADD x29, sp, #0x10         | X29 = (1152921509636422704 + 16) = 1152921509636422720 (0x100000012BC93C40);
            // 0x01970BAC: LDR x19, [x0, #0x10]       | X19 = this._s; //P2                     
            // 0x01970BB0: CBNZ x19, #0x1970bb8       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970BB8: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970BBC: MOV x0, x19                | X0 = this._s;//m1                       
            // 0x01970BC0: LDR x2, [x8, #0x210]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_210;
            // 0x01970BC4: LDR x1, [x8, #0x218]       | X1 = typeof(System.IO.Stream).__il2cppRuntimeField_218;
            // 0x01970BC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970BCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970BD0: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_210;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_210;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970BD4 (26676180), len: 48  VirtAddr: 0x01970BD4 RVA: 0x01970BD4 token: 100663396 methodIndex: 20874 delegateWrapperIndex: 0 methodInvoker: 0
        public override long get_Length()
        {
            //
            // Disasemble & Code
            // 0x01970BD4: STP x20, x19, [sp, #-0x20]! | stack[1152921509636542896] = ???;  stack[1152921509636542904] = ???;  //  dest_result_addr=1152921509636542896 |  dest_result_addr=1152921509636542904
            // 0x01970BD8: STP x29, x30, [sp, #0x10]  | stack[1152921509636542912] = ???;  stack[1152921509636542920] = ???;  //  dest_result_addr=1152921509636542912 |  dest_result_addr=1152921509636542920
            // 0x01970BDC: ADD x29, sp, #0x10         | X29 = (1152921509636542896 + 16) = 1152921509636542912 (0x100000012BCB11C0);
            // 0x01970BE0: LDR x19, [x0, #0x10]       | X19 = this._s; //P2                     
            // 0x01970BE4: CBNZ x19, #0x1970bec       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970BE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970BEC: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970BF0: MOV x0, x19                | X0 = this._s;//m1                       
            // 0x01970BF4: LDP x2, x1, [x8, #0x190]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_190; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_198; //  | 
            // 0x01970BF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970BFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970C00: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_190;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_190;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970C04 (26676228), len: 16  VirtAddr: 0x01970C04 RVA: 0x01970C04 token: 100663397 methodIndex: 20875 delegateWrapperIndex: 0 methodInvoker: 0
        public long get_ComputedPosition()
        {
            //
            // Disasemble & Code
            // 0x01970C04: LDR x8, [x0, #0x28]        | X8 = this._initialOffset; //P2          
            // 0x01970C08: LDR x9, [x0, #0x18]        | X9 = this._bytesWritten; //P2           
            // 0x01970C0C: ADD x0, x9, x8             | X0 = (this._bytesWritten + this._initialOffset);
            long val_1 = this._bytesWritten + this._initialOffset;
            // 0x01970C10: RET                        |  return (System.Int64)(this._bytesWritten + this._initialOffset);
            return val_1;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01970C14 (26676244), len: 48  VirtAddr: 0x01970C14 RVA: 0x01970C14 token: 100663398 methodIndex: 20876 delegateWrapperIndex: 0 methodInvoker: 0
        public override long get_Position()
        {
            //
            // Disasemble & Code
            // 0x01970C14: STP x20, x19, [sp, #-0x20]! | stack[1152921509636775088] = ???;  stack[1152921509636775096] = ???;  //  dest_result_addr=1152921509636775088 |  dest_result_addr=1152921509636775096
            // 0x01970C18: STP x29, x30, [sp, #0x10]  | stack[1152921509636775104] = ???;  stack[1152921509636775112] = ???;  //  dest_result_addr=1152921509636775104 |  dest_result_addr=1152921509636775112
            // 0x01970C1C: ADD x29, sp, #0x10         | X29 = (1152921509636775088 + 16) = 1152921509636775104 (0x100000012BCE9CC0);
            // 0x01970C20: LDR x19, [x0, #0x10]       | X19 = this._s; //P2                     
            // 0x01970C24: CBNZ x19, #0x1970c2c       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970C2C: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x01970C30: MOV x0, x19                | X0 = this._s;//m1                       
            // 0x01970C34: LDP x2, x1, [x8, #0x1a0]   | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_1A0; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_1A8; //  | 
            // 0x01970C38: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970C3C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970C40: BR x2                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_1A0;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_1A0;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970C44 (26676292), len: 64  VirtAddr: 0x01970C44 RVA: 0x01970C44 token: 100663399 methodIndex: 20877 delegateWrapperIndex: 0 methodInvoker: 0
        public override void set_Position(long value)
        {
            //
            // Disasemble & Code
            // 0x01970C44: STP x20, x19, [sp, #-0x20]! | stack[1152921509636895280] = ???;  stack[1152921509636895288] = ???;  //  dest_result_addr=1152921509636895280 |  dest_result_addr=1152921509636895288
            // 0x01970C48: STP x29, x30, [sp, #0x10]  | stack[1152921509636895296] = ???;  stack[1152921509636895304] = ???;  //  dest_result_addr=1152921509636895296 |  dest_result_addr=1152921509636895304
            // 0x01970C4C: ADD x29, sp, #0x10         | X29 = (1152921509636895280 + 16) = 1152921509636895296 (0x100000012BD07240);
            // 0x01970C50: LDR x20, [x0, #0x10]       | X20 = this._s; //P2                     
            // 0x01970C54: MOV x19, x1                | X19 = value;//m1                        
            // 0x01970C58: CBNZ x20, #0x1970c60       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970C5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970C60: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x01970C64: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01970C68: MOV x0, x20                | X0 = this._s;//m1                       
            // 0x01970C6C: MOV x1, x19                | X1 = value;//m1                         
            // 0x01970C70: LDR x4, [x8, #0x240]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_240;
            // 0x01970C74: LDR x3, [x8, #0x248]       | X3 = typeof(System.IO.Stream).__il2cppRuntimeField_248;
            // 0x01970C78: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970C7C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970C80: BR x4                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970C84 (26676356), len: 76  VirtAddr: 0x01970C84 RVA: 0x01970C84 token: 100663400 methodIndex: 20878 delegateWrapperIndex: 0 methodInvoker: 0
        public override long Seek(long offset, System.IO.SeekOrigin origin)
        {
            //
            // Disasemble & Code
            // 0x01970C84: STP x22, x21, [sp, #-0x30]! | stack[1152921509637019552] = ???;  stack[1152921509637019560] = ???;  //  dest_result_addr=1152921509637019552 |  dest_result_addr=1152921509637019560
            // 0x01970C88: STP x20, x19, [sp, #0x10]  | stack[1152921509637019568] = ???;  stack[1152921509637019576] = ???;  //  dest_result_addr=1152921509637019568 |  dest_result_addr=1152921509637019576
            // 0x01970C8C: STP x29, x30, [sp, #0x20]  | stack[1152921509637019584] = ???;  stack[1152921509637019592] = ???;  //  dest_result_addr=1152921509637019584 |  dest_result_addr=1152921509637019592
            // 0x01970C90: ADD x29, sp, #0x20         | X29 = (1152921509637019552 + 32) = 1152921509637019584 (0x100000012BD257C0);
            // 0x01970C94: LDR x21, [x0, #0x10]       | X21 = this._s; //P2                     
            // 0x01970C98: MOV w19, w2                | W19 = origin;//m1                       
            // 0x01970C9C: MOV x20, x1                | X20 = offset;//m1                       
            // 0x01970CA0: CBNZ x21, #0x1970ca8       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970CA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970CA8: LDR x8, [x21]              | X8 = typeof(System.IO.Stream);          
            // 0x01970CAC: MOV x1, x20                | X1 = offset;//m1                        
            // 0x01970CB0: MOV w2, w19                | W2 = origin;//m1                        
            // 0x01970CB4: MOV x0, x21                | X0 = this._s;//m1                       
            // 0x01970CB8: LDR x4, [x8, #0x240]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_240;
            // 0x01970CBC: LDR x3, [x8, #0x248]       | X3 = typeof(System.IO.Stream).__il2cppRuntimeField_248;
            // 0x01970CC0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01970CC4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01970CC8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01970CCC: BR x4                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_240;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970CD0 (26676432), len: 60  VirtAddr: 0x01970CD0 RVA: 0x01970CD0 token: 100663401 methodIndex: 20879 delegateWrapperIndex: 0 methodInvoker: 0
        public override void SetLength(long value)
        {
            //
            // Disasemble & Code
            // 0x01970CD0: STP x20, x19, [sp, #-0x20]! | stack[1152921509637143856] = ???;  stack[1152921509637143864] = ???;  //  dest_result_addr=1152921509637143856 |  dest_result_addr=1152921509637143864
            // 0x01970CD4: STP x29, x30, [sp, #0x10]  | stack[1152921509637143872] = ???;  stack[1152921509637143880] = ???;  //  dest_result_addr=1152921509637143872 |  dest_result_addr=1152921509637143880
            // 0x01970CD8: ADD x29, sp, #0x10         | X29 = (1152921509637143856 + 16) = 1152921509637143872 (0x100000012BD43D40);
            // 0x01970CDC: LDR x20, [x0, #0x10]       | X20 = this._s; //P2                     
            // 0x01970CE0: MOV x19, x1                | X19 = value;//m1                        
            // 0x01970CE4: CBNZ x20, #0x1970cec       | if (this._s != null) goto label_0;      
            if(this._s != null)
            {
                goto label_0;
            }
            // 0x01970CE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01970CEC: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x01970CF0: MOV x0, x20                | X0 = this._s;//m1                       
            // 0x01970CF4: MOV x1, x19                | X1 = value;//m1                         
            // 0x01970CF8: LDR x3, [x8, #0x250]       | X3 = typeof(System.IO.Stream).__il2cppRuntimeField_250;
            // 0x01970CFC: LDR x2, [x8, #0x258]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_258;
            // 0x01970D00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01970D04: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01970D08: BR x3                      | goto typeof(System.IO.Stream).__il2cppRuntimeField_250;
            goto typeof(System.IO.Stream).__il2cppRuntimeField_250;
        
        }
    
    }

}
