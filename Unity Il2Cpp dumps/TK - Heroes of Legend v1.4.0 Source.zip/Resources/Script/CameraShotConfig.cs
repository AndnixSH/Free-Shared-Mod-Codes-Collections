using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286BDF4
[Serializable]
public class CameraShotConfig : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private readonly System.Collections.Generic.List<CameraShotsCfg> _cameraShots; //  0x00000018
    private ProtoBuf.IExtension extensionObject; //  0x00000020
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286BE38
    [System.ComponentModel.DefaultValueAttribute] // 0x286BE38
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286BEB8
    public System.Collections.Generic.List<CameraShotsCfg> cameraShots { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BADC14 (12246036), len: 112  VirtAddr: 0x00BADC14 RVA: 0x00BADC14 token: 100690322 methodIndex: 25747 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotConfig()
    {
        //
        // Disasemble & Code
        // 0x00BADC14: STP x20, x19, [sp, #-0x20]! | stack[1152921514508052384] = ???;  stack[1152921514508052392] = ???;  //  dest_result_addr=1152921514508052384 |  dest_result_addr=1152921514508052392
        // 0x00BADC18: STP x29, x30, [sp, #0x10]  | stack[1152921514508052400] = ???;  stack[1152921514508052408] = ???;  //  dest_result_addr=1152921514508052400 |  dest_result_addr=1152921514508052408
        // 0x00BADC1C: ADD x29, sp, #0x10         | X29 = (1152921514508052384 + 16) = 1152921514508052400 (0x100000024E2867B0);
        // 0x00BADC20: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BADC24: LDRB w8, [x20, #0xb0a]     | W8 = (bool)static_value_03733B0A;       
        // 0x00BADC28: MOV x19, x0                | X19 = 1152921514508064416 (0x100000024E2896A0);//ML01
        // 0x00BADC2C: TBNZ w8, #0, #0xbadc48     | if (static_value_03733B0A == true) goto label_0;
        // 0x00BADC30: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00BADC34: LDR x8, [x8, #0xce8]       | X8 = 0x2B90268;                         
        // 0x00BADC38: LDR w0, [x8]               | W0 = 0x175E;                            
        // 0x00BADC3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x175E, ????);     
        // 0x00BADC40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BADC44: STRB w8, [x20, #0xb0a]     | static_value_03733B0A = true;            //  dest_result_addr=57883402
        label_0:
        // 0x00BADC48: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BADC4C: LDR x8, [x8, #0x8a8]       | X8 = 1152921504616644608;               
        // 0x00BADC50: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraShotsCfg> val_1 = null;
        // 0x00BADC54: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BADC58: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00BADC5C: LDR x8, [x8, #0x2d8]       | X8 = 1152921514508039392;               
        // 0x00BADC60: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BADC64: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CameraShotsCfg>::.ctor();
        // 0x00BADC68: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<CameraShotsCfg>();
        // 0x00BADC6C: STR x20, [x19, #0x18]      | this._cameraShots = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514508064440
        this._cameraShots = val_1;
        // 0x00BADC70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BADC74: MOV x0, x19                | X0 = 1152921514508064416 (0x100000024E2896A0);//ML01
        // 0x00BADC78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADC7C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BADC80: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADC84 (12246148), len: 8  VirtAddr: 0x00BADC84 RVA: 0x00BADC84 token: 100690323 methodIndex: 25748 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00BADC84: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00BADC88: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADC8C (12246156), len: 8  VirtAddr: 0x00BADC8C RVA: 0x00BADC8C token: 100690324 methodIndex: 25749 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADC8C: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514508288432
        this._id = value;
        // 0x00BADC90: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADC94 (12246164), len: 8  VirtAddr: 0x00BADC94 RVA: 0x00BADC94 token: 100690325 methodIndex: 25750 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<CameraShotsCfg> get_cameraShots()
    {
        //
        // Disasemble & Code
        // 0x00BADC94: LDR x0, [x0, #0x18]        | X0 = this._cameraShots; //P2            
        // 0x00BADC98: RET                        |  return (System.Collections.Generic.List<CameraShotsCfg>)this._cameraShots;
        return this._cameraShots;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<CameraShotsCfg>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADC9C (12246172), len: 24  VirtAddr: 0x00BADC9C RVA: 0x00BADC9C token: 100690326 methodIndex: 25751 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BADC9C: ADD x8, x0, #0x20          | X8 = this.extensionObject;//AP2 res_addr=1152921514508520640
        // 0x00BADCA0: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BADCA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BADCA8: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BADCAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BADCB0: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
