using UnityEngine;
public class BossAnimationMgr : MonoBehaviour
{
    // Fields
    public const string NAME = "Misc/BossAnimationTriger.prefab";
    private const float TrigerDistance = 5;
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x286B6E0
    private bool <IsPlaying>k__BackingField; //  0x00000018
    private bool _isEditorPattern; //  0x00000019
    public UnityEngine.GameObject BossUIAsset; //  0x00000020
    public UnityEngine.GameObject Targer; //  0x00000028
    public UnityEngine.Camera BossCamera; //  0x00000030
    public int BossAniId; //  0x00000038
    private bool _isTriger; //  0x0000003C
    private CombatEntity _boss; //  0x00000040
    private UnityEngine.Vector3 _bossPos; //  0x00000048
    private UnityEngine.Quaternion _bossRot; //  0x00000054
    private System.Collections.Generic.List<BAMCameras> cameraList; //  0x00000068
    private ShaderBossShow _shaderShow; //  0x00000070
    private BossInofShow _bossInfoShow; //  0x00000078
    private BossAnimationInfo _aniJsc; //  0x00000080
    private int _camPointIndex; //  0x00000088
    private int _bosPointIndex; //  0x0000008C
    private bool _isCamPlaying; //  0x00000090
    private bool _isBosPlaying; //  0x00000091
    private AnimationPointJSC _curCamAni; //  0x00000098
    private AnimationPointJSC _curBosAni; //  0x000000A0
    
    // Properties
    [UnityEngine.HideInInspector] // 0x286B784
    public bool IsPlaying { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B93F3C (12140348), len: 120  VirtAddr: 0x00B93F3C RVA: 0x00B93F3C token: 100690182 methodIndex: 25237 delegateWrapperIndex: 0 methodInvoker: 0
    public BossAnimationMgr()
    {
        //
        // Disasemble & Code
        // 0x00B93F3C: STP x20, x19, [sp, #-0x20]! | stack[1152921514482396096] = ???;  stack[1152921514482396104] = ???;  //  dest_result_addr=1152921514482396096 |  dest_result_addr=1152921514482396104
        // 0x00B93F40: STP x29, x30, [sp, #0x10]  | stack[1152921514482396112] = ???;  stack[1152921514482396120] = ???;  //  dest_result_addr=1152921514482396112 |  dest_result_addr=1152921514482396120
        // 0x00B93F44: ADD x29, sp, #0x10         | X29 = (1152921514482396096 + 16) = 1152921514482396112 (0x100000024CA0EBD0);
        // 0x00B93F48: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B93F4C: LDRB w8, [x20, #0xa69]     | W8 = (bool)static_value_03733A69;       
        // 0x00B93F50: MOV x19, x0                | X19 = 1152921514482408128 (0x100000024CA11AC0);//ML01
        // 0x00B93F54: TBNZ w8, #0, #0xb93f70     | if (static_value_03733A69 == true) goto label_0;
        // 0x00B93F58: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00B93F5C: LDR x8, [x8, #0x8d8]       | X8 = 0x2B8F8C4;                         
        // 0x00B93F60: LDR w0, [x8]               | W0 = 0x14F5;                            
        // 0x00B93F64: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F5, ????);     
        // 0x00B93F68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93F6C: STRB w8, [x20, #0xa69]     | static_value_03733A69 = true;            //  dest_result_addr=57883241
        label_0:
        // 0x00B93F70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93F74: STRB w8, [x19, #0x19]      | this._isEditorPattern = true;            //  dest_result_addr=1152921514482408153
        this._isEditorPattern = true;
        // 0x00B93F78: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B93F7C: LDR x8, [x8, #0x318]       | X8 = 1152921504616644608;               
        // 0x00B93F80: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<BAMCameras> val_1 = null;
        // 0x00B93F84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B93F88: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B93F8C: LDR x8, [x8, #0x5f8]       | X8 = 1152921514482383104;               
        // 0x00B93F90: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B93F94: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<BAMCameras>::.ctor();
        // 0x00B93F98: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<BAMCameras>();
        // 0x00B93F9C: STR x20, [x19, #0x68]      | this.cameraList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514482408232
        this.cameraList = val_1;
        // 0x00B93FA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93FA4: MOV x0, x19                | X0 = 1152921514482408128 (0x100000024CA11AC0);//ML01
        // 0x00B93FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93FAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B93FB0: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93FB4 (12140468), len: 12  VirtAddr: 0x00B93FB4 RVA: 0x00B93FB4 token: 100690183 methodIndex: 25238 delegateWrapperIndex: 0 methodInvoker: 0
    private void set_IsPlaying(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B93FB4: AND w8, w1, #1             | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B93FB8: STRB w8, [x0, #0x18]       | this.<IsPlaying>k__BackingField = (value & 1);  //  dest_result_addr=1152921514482520152
        this.<IsPlaying>k__BackingField = val_1;
        // 0x00B93FBC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93FC0 (12140480), len: 8  VirtAddr: 0x00B93FC0 RVA: 0x00B93FC0 token: 100690184 methodIndex: 25239 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_IsPlaying()
    {
        //
        // Disasemble & Code
        // 0x00B93FC0: LDRB w0, [x0, #0x18]       | W0 = this.<IsPlaying>k__BackingField; //P2 
        // 0x00B93FC4: RET                        |  return (System.Boolean)this.<IsPlaying>k__BackingField;
        return this.<IsPlaying>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93FC8 (12140488), len: 240  VirtAddr: 0x00B93FC8 RVA: 0x00B93FC8 token: 100690185 methodIndex: 25240 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00B93FC8: STP x22, x21, [sp, #-0x30]! | stack[1152921514482748464] = ???;  stack[1152921514482748472] = ???;  //  dest_result_addr=1152921514482748464 |  dest_result_addr=1152921514482748472
        // 0x00B93FCC: STP x20, x19, [sp, #0x10]  | stack[1152921514482748480] = ???;  stack[1152921514482748488] = ???;  //  dest_result_addr=1152921514482748480 |  dest_result_addr=1152921514482748488
        // 0x00B93FD0: STP x29, x30, [sp, #0x20]  | stack[1152921514482748496] = ???;  stack[1152921514482748504] = ???;  //  dest_result_addr=1152921514482748496 |  dest_result_addr=1152921514482748504
        // 0x00B93FD4: ADD x29, sp, #0x20         | X29 = (1152921514482748464 + 32) = 1152921514482748496 (0x100000024CA64C50);
        // 0x00B93FD8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B93FDC: LDRB w8, [x20, #0xa6a]     | W8 = (bool)static_value_03733A6A;       
        // 0x00B93FE0: MOV x19, x0                | X19 = 1152921514482760512 (0x100000024CA67B40);//ML01
        // 0x00B93FE4: TBNZ w8, #0, #0xb94000     | if (static_value_03733A6A == true) goto label_0;
        // 0x00B93FE8: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00B93FEC: LDR x8, [x8, #0x890]       | X8 = 0x2B8F8C8;                         
        // 0x00B93FF0: LDR w0, [x8]               | W0 = 0x14F6;                            
        // 0x00B93FF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F6, ????);     
        // 0x00B93FF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93FFC: STRB w8, [x20, #0xa6a]     | static_value_03733A6A = true;            //  dest_result_addr=57883242
        label_0:
        // 0x00B94000: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B94004: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        val_5 = 1152921504697475072;
        // 0x00B94008: LDR x20, [x19, #0x28]      | X20 = this.Targer; //P2                 
        // 0x00B9400C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B94010: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B94014: TBZ w8, #0, #0xb94024      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B94018: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B9401C: CBNZ w8, #0xb94024         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B94020: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B94024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9402C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94030: MOV x2, x20                | X2 = this.Targer;//m1                   
        // 0x00B94034: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00B94038: TBZ w0, #0, #0xb940a8      | if (val_1 == false) goto label_7;       
        if(val_1 == false)
        {
            goto label_7;
        }
        // 0x00B9403C: LDR w8, [x19, #0x38]       | W8 = this.BossAniId; //P2               
        // 0x00B94040: CMP w8, #1                 | STATE = COMPARE(this.BossAniId, 0x1)    
        // 0x00B94044: B.LT #0xb940a8             | if (this.BossAniId < 1) goto label_7;   
        if(this.BossAniId < 1)
        {
            goto label_7;
        }
        // 0x00B94048: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B9404C: LDR x20, [x19, #0x30]      | X20 = this.BossCamera; //P2             
        // 0x00B94050: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B94054: TBZ w8, #0, #0xb94064      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B94058: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B9405C: CBNZ w8, #0xb94064         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B94060: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_6:
        // 0x00B94064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9406C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94070: MOV x2, x20                | X2 = this.BossCamera;//m1               
        // 0x00B94074: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00B94078: TBZ w0, #0, #0xb940a8      | if (val_2 == false) goto label_7;       
        if(val_2 == false)
        {
            goto label_7;
        }
        // 0x00B9407C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B94080: STRB w8, [x19, #0x19]      | this._isEditorPattern = true;            //  dest_result_addr=1152921514482760537
        this._isEditorPattern = true;
        // 0x00B94084: BL #0xb93be8               | X0 = BossAnimationConfig.get_Instance();
        BossAnimationConfig val_3 = BossAnimationConfig.Instance;
        // 0x00B94088: LDR w20, [x19, #0x38]      | W20 = this.BossAniId; //P2              
        // 0x00B9408C: MOV x21, x0                | X21 = val_3;//m1                        
        val_5 = val_3;
        // 0x00B94090: CBNZ x21, #0xb94098        | if (val_3 != null) goto label_8;        
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00B94094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B94098: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B9409C: MOV w1, w20                | W1 = this.BossAniId;//m1                
        // 0x00B940A0: BL #0xb93c6c               | X0 = val_3.GetBossCfg(id:  this.BossAniId);
        BossAnimationInfo val_4 = val_5.GetBossCfg(id:  this.BossAniId);
        // 0x00B940A4: STR x0, [x19, #0x80]       | this._aniJsc = val_4;                    //  dest_result_addr=1152921514482760640
        this._aniJsc = val_4;
        label_7:
        // 0x00B940A8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B940AC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B940B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B940B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B940B8 (12140728), len: 884  VirtAddr: 0x00B940B8 RVA: 0x00B940B8 token: 100690186 methodIndex: 25241 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init(int aniId)
    {
        //
        // Disasemble & Code
        //  | 
        var val_16;
        // 0x00B940B8: STP d11, d10, [sp, #-0x70]! | stack[1152921514482992576] = ???;  stack[1152921514482992584] = ???;  //  dest_result_addr=1152921514482992576 |  dest_result_addr=1152921514482992584
        // 0x00B940BC: STP d9, d8, [sp, #0x10]    | stack[1152921514482992592] = ???;  stack[1152921514482992600] = ???;  //  dest_result_addr=1152921514482992592 |  dest_result_addr=1152921514482992600
        // 0x00B940C0: STP x26, x25, [sp, #0x20]  | stack[1152921514482992608] = ???;  stack[1152921514482992616] = ???;  //  dest_result_addr=1152921514482992608 |  dest_result_addr=1152921514482992616
        // 0x00B940C4: STP x24, x23, [sp, #0x30]  | stack[1152921514482992624] = ???;  stack[1152921514482992632] = ???;  //  dest_result_addr=1152921514482992624 |  dest_result_addr=1152921514482992632
        // 0x00B940C8: STP x22, x21, [sp, #0x40]  | stack[1152921514482992640] = ???;  stack[1152921514482992648] = ???;  //  dest_result_addr=1152921514482992640 |  dest_result_addr=1152921514482992648
        // 0x00B940CC: STP x20, x19, [sp, #0x50]  | stack[1152921514482992656] = ???;  stack[1152921514482992664] = ???;  //  dest_result_addr=1152921514482992656 |  dest_result_addr=1152921514482992664
        // 0x00B940D0: STP x29, x30, [sp, #0x60]  | stack[1152921514482992672] = ???;  stack[1152921514482992680] = ???;  //  dest_result_addr=1152921514482992672 |  dest_result_addr=1152921514482992680
        // 0x00B940D4: ADD x29, sp, #0x60         | X29 = (1152921514482992576 + 96) = 1152921514482992672 (0x100000024CAA0620);
        // 0x00B940D8: SUB sp, sp, #0x10          | SP = (1152921514482992576 - 16) = 1152921514482992560 (0x100000024CAA05B0);
        // 0x00B940DC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B940E0: LDRB w8, [x21, #0xa6b]     | W8 = (bool)static_value_03733A6B;       
        // 0x00B940E4: MOV w20, w1                | W20 = aniId;//m1                        
        // 0x00B940E8: MOV x19, x0                | X19 = 1152921514483004688 (0x100000024CAA3510);//ML01
        // 0x00B940EC: TBNZ w8, #0, #0xb94108     | if (static_value_03733A6B == true) goto label_0;
        // 0x00B940F0: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B940F4: LDR x8, [x8, #0x5c0]       | X8 = 0x2B8F8D8;                         
        // 0x00B940F8: LDR w0, [x8]               | W0 = 0x14FA;                            
        // 0x00B940FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14FA, ????);     
        // 0x00B94100: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B94104: STRB w8, [x21, #0xa6b]     | static_value_03733A6B = true;            //  dest_result_addr=57883243
        label_0:
        // 0x00B94108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9410C: MOV x0, x19                | X0 = 1152921514483004688 (0x100000024CAA3510);//ML01
        // 0x00B94110: STRB wzr, [x19, #0x19]     | this._isEditorPattern = false;           //  dest_result_addr=1152921514483004713
        this._isEditorPattern = false;
        // 0x00B94114: STR w20, [x19, #0x38]      | this.BossAniId = aniId;                  //  dest_result_addr=1152921514483004744
        this.BossAniId = aniId;
        // 0x00B94118: STRB wzr, [x19, #0x18]     | this.<IsPlaying>k__BackingField = false;  //  dest_result_addr=1152921514483004712
        this.<IsPlaying>k__BackingField = false;
        // 0x00B9411C: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00B94120: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B94124: CBNZ x20, #0xb9412c        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B94128: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B9412C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B94130: LDR x8, [x8, #0x158]       | X8 = 1152921514482868992;               
        // 0x00B94134: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B94138: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponentInChildren<UnityEngine.Camera>();
        // 0x00B9413C: BL #0x23d54dc              | X0 = val_1.GetComponentInChildren<UnityEngine.Camera>();
        UnityEngine.Camera val_2 = val_1.GetComponentInChildren<UnityEngine.Camera>();
        // 0x00B94140: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B94144: STR x20, [x19, #0x30]      | this.BossCamera = val_2;                 //  dest_result_addr=1152921514483004736
        this.BossCamera = val_2;
        // 0x00B94148: CBNZ x20, #0xb94150        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00B9414C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B94150: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B94154: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94158: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B9415C: BL #0x20cb458              | val_2.set_enabled(value:  false);       
        val_2.enabled = false;
        // 0x00B94160: LDR x20, [x19, #0x30]      | X20 = this.BossCamera; //P2             
        // 0x00B94164: CBNZ x20, #0xb9416c        | if (this.BossCamera != null) goto label_3;
        if(this.BossCamera != null)
        {
            goto label_3;
        }
        // 0x00B94168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B9416C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94170: MOV x0, x20                | X0 = this.BossCamera;//m1               
        // 0x00B94174: BL #0x20d5094              | X0 = this.BossCamera.get_transform();   
        UnityEngine.Transform val_3 = this.BossCamera.transform;
        // 0x00B94178: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B9417C: CBNZ x20, #0xb94184        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00B94180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00B94184: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
        // 0x00B94188: LDR x8, [x8, #0xf50]       | X8 = 1152921514482882304;               
        // 0x00B9418C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B94190: LDR x1, [x8]               | X1 = public ShaderBossShow UnityEngine.Component::GetComponent<ShaderBossShow>();
        // 0x00B94194: BL #0x23d5410              | X0 = val_3.GetComponent<ShaderBossShow>();
        ShaderBossShow val_4 = val_3.GetComponent<ShaderBossShow>();
        // 0x00B94198: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B9419C: STR x20, [x19, #0x70]      | this._shaderShow = val_4;                //  dest_result_addr=1152921514483004800
        this._shaderShow = val_4;
        // 0x00B941A0: CBNZ x20, #0xb941a8        | if (val_4 != null) goto label_5;        
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x00B941A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x00B941A8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B941AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B941B0: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B941B4: BL #0x20cb458              | val_4.set_enabled(value:  false);       
        val_4.enabled = false;
        // 0x00B941B8: BL #0xb93be8               | X0 = BossAnimationConfig.get_Instance();
        BossAnimationConfig val_5 = BossAnimationConfig.Instance;
        // 0x00B941BC: LDR w20, [x19, #0x38]      | W20 = this.BossAniId; //P2              
        // 0x00B941C0: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00B941C4: CBNZ x21, #0xb941cc        | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x00B941C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00B941CC: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B941D0: MOV w1, w20                | W1 = this.BossAniId;//m1                
        // 0x00B941D4: BL #0xb93c6c               | X0 = val_5.GetBossCfg(id:  this.BossAniId);
        BossAnimationInfo val_6 = val_5.GetBossCfg(id:  this.BossAniId);
        // 0x00B941D8: STR x0, [x19, #0x80]       | this._aniJsc = val_6;                    //  dest_result_addr=1152921514483004816
        this._aniJsc = val_6;
        // 0x00B941DC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B941E0: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B941E4: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B941E8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B941EC: TBZ w8, #0, #0xb941fc      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B941F0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B941F4: CBNZ w8, #0xb941fc         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B941F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_8:
        // 0x00B941FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94204: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_7 = ZMG.GlobalGOMgr;
        // 0x00B94208: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B9420C: CBNZ x20, #0xb94214        | if (val_7 != null) goto label_9;        
        if(val_7 != null)
        {
            goto label_9;
        }
        // 0x00B94210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00B94214: LDR x20, [x20, #0x18]      | X20 = val_7.uiroot; //P2                
        // 0x00B94218: CBNZ x20, #0xb94220        | if (val_7.uiroot != null) goto label_10;
        if(val_7.uiroot != null)
        {
            goto label_10;
        }
        // 0x00B9421C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_10:
        // 0x00B94220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94224: MOV x0, x20                | X0 = val_7.uiroot;//m1                  
        // 0x00B94228: BL #0x20d50fc              | X0 = val_7.uiroot.get_gameObject();     
        UnityEngine.GameObject val_8 = val_7.uiroot.gameObject;
        // 0x00B9422C: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B94230: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00B94234: LDR x20, [x19, #0x20]      | X20 = this.BossUIAsset; //P2            
        // 0x00B94238: MOV x21, x0                | X21 = val_8;//m1                        
        // 0x00B9423C: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00B94240: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B94244: TBZ w9, #0, #0xb94258      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B94248: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B9424C: CBNZ w9, #0xb94258         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B94250: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B94254: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_12:
        // 0x00B94258: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9425C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94260: MOV x1, x21                | X1 = val_8;//m1                         
        // 0x00B94264: MOV x2, x20                | X2 = this.BossUIAsset;//m1              
        // 0x00B94268: BL #0xd084dc               | X0 = NGUITools.AddChild(parent:  0, prefab:  val_8);
        UnityEngine.GameObject val_9 = NGUITools.AddChild(parent:  0, prefab:  val_8);
        // 0x00B9426C: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B94270: CBNZ x20, #0xb94278        | if (val_9 != null) goto label_13;       
        if(val_9 != null)
        {
            goto label_13;
        }
        // 0x00B94274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_13:
        // 0x00B94278: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00B9427C: LDR x8, [x8, #0x5e0]       | X8 = 1152921514482916096;               
        // 0x00B94280: MOV x0, x20                | X0 = val_9;//m1                         
        // 0x00B94284: LDR x1, [x8]               | X1 = public BossInofShow UnityEngine.GameObject::GetComponent<BossInofShow>();
        // 0x00B94288: BL #0x23d5abc              | X0 = val_9.GetComponent<BossInofShow>();
        BossInofShow val_10 = val_9.GetComponent<BossInofShow>();
        // 0x00B9428C: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B94290: STR x20, [x19, #0x78]      | this._bossInfoShow = val_10;             //  dest_result_addr=1152921514483004808
        this._bossInfoShow = val_10;
        // 0x00B94294: CBNZ x20, #0xb9429c        | if (val_10 != null) goto label_14;      
        if(val_10 != null)
        {
            goto label_14;
        }
        // 0x00B94298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_14:
        // 0x00B9429C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B942A0: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B942A4: BL #0x20d50fc              | X0 = val_10.get_gameObject();           
        UnityEngine.GameObject val_11 = val_10.gameObject;
        // 0x00B942A8: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B942AC: LDR x8, [x8, #0x190]       | X8 = (string**)(1152921514482925312)("BossUI");
        // 0x00B942B0: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00B942B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B942B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B942BC: LDR x1, [x8]               | X1 = "BossUI";                          
        // 0x00B942C0: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_12 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00B942C4: MOV w2, w0                 | W2 = val_12;//m1                        
        // 0x00B942C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B942CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B942D0: MOV x1, x20                | X1 = val_11;//m1                        
        // 0x00B942D4: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_11);
        NGUITools.SetLayer(go:  0, layer:  val_11);
        // 0x00B942D8: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B942DC: CBNZ x20, #0xb942e4        | if (this._bossInfoShow != null) goto label_15;
        if(this._bossInfoShow != null)
        {
            goto label_15;
        }
        // 0x00B942E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_15:
        // 0x00B942E4: MOV x0, x20                | X0 = this._bossInfoShow;//m1            
        // 0x00B942E8: BL #0xb9442c               | this._bossInfoShow.Hide();              
        this._bossInfoShow.Hide();
        // 0x00B942EC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B942F0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B942F4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B942F8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B942FC: TBZ w8, #0, #0xb9430c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B94300: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B94304: CBNZ w8, #0xb9430c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B94308: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_17:
        // 0x00B9430C: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00B94310: LDR x8, [x8, #0x2a0]       | X8 = 1152921514482929488;               
        // 0x00B94314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94318: LDR x1, [x8]               | X1 = public static T[] UnityEngine.Object::FindObjectsOfType<UnityEngine.Camera>();
        // 0x00B9431C: BL #0x23d99ec              | X0 = UnityEngine.Object.FindObjectsOfType<UnityEngine.Camera>();
        T[] val_13 = UnityEngine.Object.FindObjectsOfType<UnityEngine.Camera>();
        // 0x00B94320: ADRP x25, #0x3661000       | X25 = 57020416 (0x3661000);             
        // 0x00B94324: ADRP x26, #0x360a000       | X26 = 56664064 (0x360A000);             
        // 0x00B94328: LDR x25, [x25, #0x8f0]     | X25 = 1152921504887570432;              
        // 0x00B9432C: LDR x26, [x26, #0xf60]     | X26 = 1152921514482967376;              
        // 0x00B94330: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00B94334: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        val_16 = 0;
        // 0x00B94338: B #0xb94350                |  goto label_18;                         
        goto label_18;
        label_23:
        // 0x00B9433C: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<BAMCameras>::Add(BAMCameras item);
        // 0x00B94340: MOV x0, x21                | X0 = val_8;//m1                         
        // 0x00B94344: MOV x1, x22                | X1 = X22;//m1                           
        // 0x00B94348: BL #0x25ea480              | val_8.Add(item:  X22);                  
        val_8.Add(item:  X22);
        // 0x00B9434C: ADD w24, w24, #1           | W24 = (val_16 + 1) = val_16 (0x00000001);
        val_16 = 1;
        label_18:
        // 0x00B94350: CBNZ x20, #0xb94358        | if (val_13 != null) goto label_19;      
        if(val_13 != null)
        {
            goto label_19;
        }
        // 0x00B94354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_19:
        // 0x00B94358: LDR w8, [x20, #0x18]       | W8 = val_13.Length; //P2                
        // 0x00B9435C: CMP w24, w8                | STATE = COMPARE(0x1, val_13.Length)     
        // 0x00B94360: B.GE #0xb943a8             | if (val_16 >= val_13.Length) goto label_20;
        if(val_16 >= val_13.Length)
        {
            goto label_20;
        }
        // 0x00B94364: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B94368: SXTW x22, w24              | X22 = 1 (0x00000001);                   
        // 0x00B9436C: CMP w24, w8                | STATE = COMPARE(0x1, val_13.Length)     
        // 0x00B94370: B.LO #0xb94380             | if (val_16 < val_13.Length) goto label_21;
        if(val_16 < val_13.Length)
        {
            goto label_21;
        }
        // 0x00B94374: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00B94378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9437C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_21:
        // 0x00B94380: ADD x8, x20, x22, lsl #3   | X8 = val_13[0x1]; //PARR1               
        // 0x00B94384: LDR x0, [x25]              | X0 = typeof(BAMCameras);                
        BAMCameras val_14 = null;
        // 0x00B94388: LDR x23, [x8, #0x20]       | X23 = val_13[0x1][0]                    
        T val_16 = val_13[1];
        // 0x00B9438C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BAMCameras), ????);
        // 0x00B94390: MOV x1, x23                | X1 = val_13[0x1][0];//m1                
        // 0x00B94394: MOV x22, x0                | X22 = 1152921504887570432 (0x1000000010BB8000);//ML01
        // 0x00B94398: BL #0xb8cb34               | .ctor(camera:  val_13[1]);              
        val_14 = new BAMCameras(camera:  val_16);
        // 0x00B9439C: CBNZ x21, #0xb9433c        | if (this.cameraList != null) goto label_23;
        if(this.cameraList != null)
        {
            goto label_23;
        }
        // 0x00B943A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(camera:  val_13[1]), ????);
        // 0x00B943A4: B #0xb9433c                |  goto label_23;                         
        goto label_23;
        label_20:
        // 0x00B943A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B943AC: MOV x0, x19                | X0 = 1152921514483004688 (0x100000024CAA3510);//ML01
        // 0x00B943B0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_15 = this.transform;
        // 0x00B943B4: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B943B8: MOV x19, x0                | X19 = val_15;//m1                       
        // 0x00B943BC: CBNZ x20, #0xb943c4        | if (this._aniJsc != null) goto label_24;
        if(this._aniJsc != null)
        {
            goto label_24;
        }
        // 0x00B943C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_24:
        // 0x00B943C4: LDP s0, s1, [x20, #0x14]   | S0 = this._aniJsc._trigerPos_x; //P2  S1 = this._aniJsc._trigerPos_y; //P2  //  | 
        // 0x00B943C8: LDR s2, [x20, #0x1c]       | S2 = this._aniJsc._trigerPos_z; //P2    
        // 0x00B943CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B943D0: MOV x0, sp                 | X0 = 1152921514482992560 (0x100000024CAA05B0);//ML01
        // 0x00B943D4: STR wzr, [sp, #8]          | stack[1152921514482992568] = 0x0;        //  dest_result_addr=1152921514482992568
        // 0x00B943D8: STR xzr, [sp]              | stack[1152921514482992560] = 0x0;        //  dest_result_addr=1152921514482992560
        // 0x00B943DC: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B943E0: LDP s8, s9, [sp]           | S8 = 0; S9 = 0;                          //  | 
        // 0x00B943E4: LDR s10, [sp, #8]          | S10 = 0;                                
        // 0x00B943E8: CBNZ x19, #0xb943f0        | if (val_15 != null) goto label_25;      
        if(val_15 != null)
        {
            goto label_25;
        }
        // 0x00B943EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000024CAA05B0, ????);
        label_25:
        // 0x00B943F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B943F4: MOV x0, x19                | X0 = val_15;//m1                        
        // 0x00B943F8: MOV v0.16b, v8.16b         | V0 = 0 (0x0);//ML01                     
        // 0x00B943FC: MOV v1.16b, v9.16b         | V1 = 0 (0x0);//ML01                     
        // 0x00B94400: MOV v2.16b, v10.16b        | V2 = 0 (0x0);//ML01                     
        // 0x00B94404: BL #0x26935b8              | val_15.set_position(value:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        val_15.position = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        // 0x00B94408: SUB sp, x29, #0x60         | SP = (1152921514482992672 - 96) = 1152921514482992576 (0x100000024CAA05C0);
        // 0x00B9440C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B94410: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B94414: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B94418: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B9441C: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B94420: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B94424: LDP d11, d10, [sp], #0x70  | D11 = ; D10 = ;                          //  | 
        // 0x00B94428: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B94464 (12141668), len: 528  VirtAddr: 0x00B94464 RVA: 0x00B94464 token: 100690187 methodIndex: 25242 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnDestroy()
    {
        //
        // Disasemble & Code
        // 0x00B94464: STP x22, x21, [sp, #-0x30]! | stack[1152921514483249024] = ???;  stack[1152921514483249032] = ???;  //  dest_result_addr=1152921514483249024 |  dest_result_addr=1152921514483249032
        // 0x00B94468: STP x20, x19, [sp, #0x10]  | stack[1152921514483249040] = ???;  stack[1152921514483249048] = ???;  //  dest_result_addr=1152921514483249040 |  dest_result_addr=1152921514483249048
        // 0x00B9446C: STP x29, x30, [sp, #0x20]  | stack[1152921514483249056] = ???;  stack[1152921514483249064] = ???;  //  dest_result_addr=1152921514483249056 |  dest_result_addr=1152921514483249064
        // 0x00B94470: ADD x29, sp, #0x20         | X29 = (1152921514483249024 + 32) = 1152921514483249056 (0x100000024CADEFA0);
        // 0x00B94474: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B94478: LDRB w8, [x20, #0xa6c]     | W8 = (bool)static_value_03733A6C;       
        // 0x00B9447C: MOV x19, x0                | X19 = 1152921514483261072 (0x100000024CAE1E90);//ML01
        // 0x00B94480: TBNZ w8, #0, #0xb9449c     | if (static_value_03733A6C == true) goto label_0;
        // 0x00B94484: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B94488: LDR x8, [x8, #0x120]       | X8 = 0x2B8F8DC;                         
        // 0x00B9448C: LDR w0, [x8]               | W0 = 0x14FB;                            
        // 0x00B94490: BL #0x2782188              | X0 = sub_2782188( ?? 0x14FB, ????);     
        // 0x00B94494: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B94498: STRB w8, [x20, #0xa6c]     | static_value_03733A6C = true;            //  dest_result_addr=57883244
        label_0:
        // 0x00B9449C: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B944A0: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00B944A4: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B944A8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B944AC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B944B0: TBZ w8, #0, #0xb944c0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B944B4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B944B8: CBNZ w8, #0xb944c0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B944BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B944C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B944C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B944C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B944CC: MOV x2, x20                | X2 = this._bossInfoShow;//m1            
        // 0x00B944D0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00B944D4: TBZ w0, #0, #0xb94524      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B944D8: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B944DC: CBNZ x20, #0xb944e4        | if (this._bossInfoShow != null) goto label_4;
        if(this._bossInfoShow != null)
        {
            goto label_4;
        }
        // 0x00B944E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B944E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B944E8: MOV x0, x20                | X0 = this._bossInfoShow;//m1            
        // 0x00B944EC: BL #0x20d50fc              | X0 = this._bossInfoShow.get_gameObject();
        UnityEngine.GameObject val_2 = this._bossInfoShow.gameObject;
        // 0x00B944F0: LDR x8, [x21]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B944F4: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B944F8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B944FC: TBZ w9, #0, #0xb94510      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B94500: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B94504: CBNZ w9, #0xb94510         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B94508: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B9450C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_6:
        // 0x00B94510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94514: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94518: MOV x1, x20                | X1 = val_2;//m1                         
        // 0x00B9451C: BL #0x1b78acc              | UnityEngine.Object.Destroy(obj:  0);    
        UnityEngine.Object.Destroy(obj:  0);
        // 0x00B94520: STR xzr, [x19, #0x78]      | this._bossInfoShow = null;               //  dest_result_addr=1152921514483261192
        this._bossInfoShow = 0;
        label_3:
        // 0x00B94524: STR xzr, [x19, #0x20]      | this.BossUIAsset = null;                 //  dest_result_addr=1152921514483261104
        this.BossUIAsset = 0;
        // 0x00B94528: MOV x22, x19               | X22 = 1152921514483261072 (0x100000024CAE1E90);//ML01
        // 0x00B9452C: LDR x20, [x22, #0x28]!     | X20 = this.Targer; //P2                 
        // 0x00B94530: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B94534: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B94538: TBZ w8, #0, #0xb94548      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B9453C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B94540: CBNZ w8, #0xb94548         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B94544: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x00B94548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9454C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94550: MOV x1, x20                | X1 = this.Targer;//m1                   
        // 0x00B94554: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94558: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.Targer);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  this.Targer);
        // 0x00B9455C: TBZ w0, #0, #0xb9458c      | if (val_3 == false) goto label_9;       
        if(val_3 == false)
        {
            goto label_9;
        }
        // 0x00B94560: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B94564: LDR x20, [x22]             | X20 = this.Targer;                      
        // 0x00B94568: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B9456C: TBZ w8, #0, #0xb9457c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B94570: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B94574: CBNZ w8, #0xb9457c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B94578: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_11:
        // 0x00B9457C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94580: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94584: MOV x1, x20                | X1 = this.Targer;//m1                   
        // 0x00B94588: BL #0x1b78acc              | UnityEngine.Object.Destroy(obj:  0);    
        UnityEngine.Object.Destroy(obj:  0);
        label_9:
        // 0x00B9458C: STP xzr, xzr, [x22]        | this.Targer = null;  mem[1152921514483261120] = 0x0;  //  dest_result_addr=1152921514483261112 |  dest_result_addr=1152921514483261120
        this.Targer = 0;
        mem[1152921514483261120] = 0;
        // 0x00B94590: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B94594: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B94598: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B9459C: TBZ w8, #0, #0xb945ac      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B945A0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B945A4: CBNZ w8, #0xb945ac         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B945A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_13:
        // 0x00B945AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B945B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B945B4: MOV x1, x20                | X1 = this._boss;//m1                    
        // 0x00B945B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B945BC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this._boss);
        bool val_4 = UnityEngine.Object.op_Inequality(x:  0, y:  this._boss);
        // 0x00B945C0: TBZ w0, #0, #0xb945e4      | if (val_4 == false) goto label_14;      
        if(val_4 == false)
        {
            goto label_14;
        }
        // 0x00B945C4: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B945C8: CBNZ x20, #0xb945d0        | if (this._boss != null) goto label_15;  
        if(this._boss != null)
        {
            goto label_15;
        }
        // 0x00B945CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_15:
        // 0x00B945D0: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
        // 0x00B945D4: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B945D8: LDR x9, [x8, #0x3e0]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_3E0;
        // 0x00B945DC: LDR x1, [x8, #0x3e8]       | X1 = typeof(CombatEntity).__il2cppRuntimeField_3E8;
        // 0x00B945E0: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_3E0();
        label_14:
        // 0x00B945E4: LDR x20, [x19, #0x68]      | X20 = this.cameraList; //P2             
        // 0x00B945E8: STR xzr, [x19, #0x40]      | this._boss = null;                       //  dest_result_addr=1152921514483261136
        this._boss = 0;
        // 0x00B945EC: CBNZ x20, #0xb945f4        | if (this.cameraList != null) goto label_16;
        if(this.cameraList != null)
        {
            goto label_16;
        }
        // 0x00B945F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._boss, ????); 
        label_16:
        // 0x00B945F4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B945F8: LDR x8, [x8, #0x3f8]       | X8 = 1152921514483231952;               
        // 0x00B945FC: MOV x0, x20                | X0 = this.cameraList;//m1               
        // 0x00B94600: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<BAMCameras>::Clear();
        // 0x00B94604: BL #0x25ead28              | this.cameraList.Clear();                
        this.cameraList.Clear();
        // 0x00B94608: MOV x22, x19               | X22 = 1152921514483261072 (0x100000024CAE1E90);//ML01
        // 0x00B9460C: LDR x20, [x22, #0x70]!     | X20 = this._shaderShow; //P2            
        // 0x00B94610: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B94614: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B94618: TBZ w8, #0, #0xb94628      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B9461C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B94620: CBNZ w8, #0xb94628         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B94624: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_18:
        // 0x00B94628: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9462C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94630: MOV x1, x20                | X1 = this._shaderShow;//m1              
        // 0x00B94634: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94638: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this._shaderShow);
        bool val_5 = UnityEngine.Object.op_Inequality(x:  0, y:  this._shaderShow);
        // 0x00B9463C: TBZ w0, #0, #0xb94658      | if (val_5 == false) goto label_19;      
        if(val_5 == false)
        {
            goto label_19;
        }
        // 0x00B94640: LDR x20, [x22]             | X20 = this._shaderShow;                 
        // 0x00B94644: CBNZ x20, #0xb9464c        | if (this._shaderShow != null) goto label_20;
        if(this._shaderShow != null)
        {
            goto label_20;
        }
        // 0x00B94648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_20:
        // 0x00B9464C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94650: MOV x0, x20                | X0 = this._shaderShow;//m1              
        // 0x00B94654: BL #0xadcae0               | this._shaderShow.OnDestroy();           
        this._shaderShow.OnDestroy();
        label_19:
        // 0x00B94658: STP xzr, xzr, [x22, #8]    | this._bossInfoShow = null;  mem[1152921514483261200] = 0x0;  //  dest_result_addr=1152921514483261192 |  dest_result_addr=1152921514483261200
        this._bossInfoShow = 0;
        mem[1152921514483261200] = 0;
        // 0x00B9465C: STR xzr, [x22]             | this._shaderShow = null;                 //  dest_result_addr=1152921514483261184
        this._shaderShow = 0;
        // 0x00B94660: STP xzr, xzr, [x19, #0x98] | this._curCamAni = null;  this._curBosAni = null;  //  dest_result_addr=1152921514483261224 |  dest_result_addr=1152921514483261232
        this._curCamAni = 0;
        this._curBosAni = 0;
        // 0x00B94664: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B94668: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B9466C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B94670: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B94674 (12142196), len: 604  VirtAddr: 0x00B94674 RVA: 0x00B94674 token: 100690188 methodIndex: 25243 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        int val_17;
        // 0x00B94674: STP d13, d12, [sp, #-0x60]! | stack[1152921514483426512] = ???;  stack[1152921514483426520] = ???;  //  dest_result_addr=1152921514483426512 |  dest_result_addr=1152921514483426520
        // 0x00B94678: STP d11, d10, [sp, #0x10]  | stack[1152921514483426528] = ???;  stack[1152921514483426536] = ???;  //  dest_result_addr=1152921514483426528 |  dest_result_addr=1152921514483426536
        // 0x00B9467C: STP d9, d8, [sp, #0x20]    | stack[1152921514483426544] = ???;  stack[1152921514483426552] = ???;  //  dest_result_addr=1152921514483426544 |  dest_result_addr=1152921514483426552
        // 0x00B94680: STP x22, x21, [sp, #0x30]  | stack[1152921514483426560] = ???;  stack[1152921514483426568] = ???;  //  dest_result_addr=1152921514483426560 |  dest_result_addr=1152921514483426568
        // 0x00B94684: STP x20, x19, [sp, #0x40]  | stack[1152921514483426576] = ???;  stack[1152921514483426584] = ???;  //  dest_result_addr=1152921514483426576 |  dest_result_addr=1152921514483426584
        // 0x00B94688: STP x29, x30, [sp, #0x50]  | stack[1152921514483426592] = ???;  stack[1152921514483426600] = ???;  //  dest_result_addr=1152921514483426592 |  dest_result_addr=1152921514483426600
        // 0x00B9468C: ADD x29, sp, #0x50         | X29 = (1152921514483426512 + 80) = 1152921514483426592 (0x100000024CB0A520);
        // 0x00B94690: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B94694: LDRB w8, [x20, #0xa6d]     | W8 = (bool)static_value_03733A6D;       
        // 0x00B94698: MOV x19, x0                | X19 = 1152921514483438608 (0x100000024CB0D410);//ML01
        // 0x00B9469C: TBNZ w8, #0, #0xb946b8     | if (static_value_03733A6D == true) goto label_0;
        // 0x00B946A0: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x00B946A4: LDR x8, [x8, #0xb68]       | X8 = 0x2B8F8EC;                         
        // 0x00B946A8: LDR w0, [x8]               | W0 = 0x14FF;                            
        // 0x00B946AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14FF, ????);     
        // 0x00B946B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B946B4: STRB w8, [x20, #0xa6d]     | static_value_03733A6D = true;            //  dest_result_addr=57883245
        label_0:
        // 0x00B946B8: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
        // 0x00B946BC: LDR x8, [x8, #0x50]        | X8 = 1152921504891510784;               
        // 0x00B946C0: LDR x0, [x8]               | X0 = typeof(LevelConfigManager);        
        // 0x00B946C4: LDRB w8, [x0, #0x10a]      | W8 = LevelConfigManager.__il2cppRuntimeField_10A;
        // 0x00B946C8: TBZ w8, #0, #0xb946d8      | if (LevelConfigManager.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B946CC: LDR w8, [x0, #0xbc]        | W8 = LevelConfigManager.__il2cppRuntimeField_cctor_finished;
        // 0x00B946D0: CBNZ w8, #0xb946d8         | if (LevelConfigManager.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B946D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(LevelConfigManager), ????);
        label_2:
        // 0x00B946D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B946DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B946E0: BL #0xda0c5c               | X0 = LevelConfigManager.get_instance(); 
        LevelConfigManager val_1 = LevelConfigManager.instance;
        // 0x00B946E4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B946E8: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00B946EC: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B946F0: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00B946F4: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B946F8: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B946FC: CBNZ x21, #0xb94704        | if (GameMgr.UPDATEOnOffEffect != null) goto label_3;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_3;
        }
        // 0x00B94700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B94704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94708: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B9470C: BL #0xc149c0               | X0 = GameMgr.UPDATEOnOffEffect.get_level();
        int val_2 = GameMgr.UPDATEOnOffEffect.level;
        // 0x00B94710: MOV w21, w0                | W21 = val_2;//m1                        
        val_17 = val_2;
        // 0x00B94714: CBNZ x20, #0xb9471c        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00B94718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B9471C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94720: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B94724: MOV w1, w21                | W1 = val_2;//m1                         
        // 0x00B94728: BL #0xda1448               | X0 = val_1.GetTotalRounds(level:  val_17);
        int val_3 = val_1.GetTotalRounds(level:  val_17);
        // 0x00B9472C: LDRB w8, [x19, #0x3c]      | W8 = this._isTriger; //P2               
        // 0x00B94730: MOV w20, w0                | W20 = val_3;//m1                        
        // 0x00B94734: CBNZ w8, #0xb9488c         | if (this._isTriger == true) goto label_10;
        if(this._isTriger == true)
        {
            goto label_10;
        }
        // 0x00B94738: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9473C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94740: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_4 = HeroMgr.instance;
        // 0x00B94744: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00B94748: CBNZ x21, #0xb94750        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B9474C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00B94750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94754: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B94758: BL #0x287fff4              | X0 = val_4.get_captain();               
        Hero val_5 = val_4.captain;
        // 0x00B9475C: MOV x21, x0                | X21 = val_5;//m1                        
        val_17 = val_5;
        // 0x00B94760: CBNZ x21, #0xb94768        | if (val_5 != null) goto label_7;        
        if(val_17 != null)
        {
            goto label_7;
        }
        // 0x00B94764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00B94768: LDR x8, [x21]              | X8 = typeof(Hero);                      
        // 0x00B9476C: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00B94770: LDP x9, x1, [x8, #0x150]   | X9 = public System.Boolean CombatEntity::get_canMove(); X1 = public System.Boolean CombatEntity::get_canMove(); //  | 
        // 0x00B94774: BLR x9                     | X0 = val_5.get_canMove();               
        bool val_6 = val_17.canMove;
        // 0x00B94778: TBZ w0, #0, #0xb9488c      | if (val_6 == false) goto label_10;      
        if(val_6 == false)
        {
            goto label_10;
        }
        // 0x00B9477C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94784: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_7 = NpcMgr.instance;
        // 0x00B94788: MOV x21, x0                | X21 = val_7;//m1                        
        val_17 = val_7;
        // 0x00B9478C: CBNZ x21, #0xb94794        | if (val_7 != null) goto label_9;        
        if(val_17 != null)
        {
            goto label_9;
        }
        // 0x00B94790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00B94794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94798: MOV x0, x21                | X0 = val_7;//m1                         
        // 0x00B9479C: BL #0xd0f68c               | X0 = val_7.get_curRound();              
        int val_8 = val_17.curRound;
        // 0x00B947A0: SUB w8, w20, #1            | W8 = (val_3 - 1);                       
        int val_9 = val_3 - 1;
        // 0x00B947A4: CMP w0, w8                 | STATE = COMPARE(val_8, (val_3 - 1))     
        // 0x00B947A8: B.NE #0xb9488c             | if (val_8 != val_9) goto label_10;      
        if(val_8 != val_9)
        {
            goto label_10;
        }
        // 0x00B947AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B947B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B947B4: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_10 = HeroMgr.instance;
        // 0x00B947B8: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B947BC: CBNZ x20, #0xb947c4        | if (val_10 != null) goto label_11;      
        if(val_10 != null)
        {
            goto label_11;
        }
        // 0x00B947C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_11:
        // 0x00B947C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B947C8: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00B947CC: BL #0x287fff4              | X0 = val_10.get_captain();              
        Hero val_11 = val_10.captain;
        // 0x00B947D0: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00B947D4: CBNZ x20, #0xb947dc        | if (val_11 != null) goto label_12;      
        if(val_11 != null)
        {
            goto label_12;
        }
        // 0x00B947D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_12:
        // 0x00B947DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B947E0: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x00B947E4: BL #0x20d5094              | X0 = val_11.get_transform();            
        UnityEngine.Transform val_12 = val_11.transform;
        // 0x00B947E8: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00B947EC: CBNZ x20, #0xb947f4        | if (val_12 != null) goto label_13;      
        if(val_12 != null)
        {
            goto label_13;
        }
        // 0x00B947F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_13:
        // 0x00B947F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B947F8: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00B947FC: BL #0x2693510              | X0 = val_12.get_position();             
        UnityEngine.Vector3 val_13 = val_12.position;
        // 0x00B94800: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94804: MOV x0, x19                | X0 = 1152921514483438608 (0x100000024CB0D410);//ML01
        // 0x00B94808: MOV v8.16b, v0.16b         | V8 = val_13.x;//m1                      
        // 0x00B9480C: MOV v9.16b, v1.16b         | V9 = val_13.y;//m1                      
        // 0x00B94810: MOV v10.16b, v2.16b        | V10 = val_13.z;//m1                     
        // 0x00B94814: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_14 = this.transform;
        // 0x00B94818: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x00B9481C: CBNZ x20, #0xb94824        | if (val_14 != null) goto label_14;      
        if(val_14 != null)
        {
            goto label_14;
        }
        // 0x00B94820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_14:
        // 0x00B94824: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94828: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x00B9482C: BL #0x2693510              | X0 = val_14.get_position();             
        UnityEngine.Vector3 val_15 = val_14.position;
        // 0x00B94830: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B94834: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B94838: MOV v11.16b, v0.16b        | V11 = val_15.x;//m1                     
        // 0x00B9483C: MOV v12.16b, v1.16b        | V12 = val_15.y;//m1                     
        // 0x00B94840: MOV v13.16b, v2.16b        | V13 = val_15.z;//m1                     
        // 0x00B94844: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B94848: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B9484C: TBZ w8, #0, #0xb9485c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B94850: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B94854: CBNZ w8, #0xb9485c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B94858: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_16:
        // 0x00B9485C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94860: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94864: MOV v0.16b, v8.16b         | V0 = val_13.x;//m1                      
        // 0x00B94868: MOV v1.16b, v9.16b         | V1 = val_13.y;//m1                      
        // 0x00B9486C: MOV v2.16b, v10.16b        | V2 = val_13.z;//m1                      
        // 0x00B94870: MOV v3.16b, v11.16b        | V3 = val_15.x;//m1                      
        // 0x00B94874: MOV v4.16b, v12.16b        | V4 = val_15.y;//m1                      
        // 0x00B94878: MOV v5.16b, v13.16b        | V5 = val_15.z;//m1                      
        // 0x00B9487C: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
        float val_16 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
        // 0x00B94880: FMOV s1, #5.00000000       | S1 = 5;                                 
        // 0x00B94884: FCMP s0, s1                | STATE = COMPARE(val_16, 5)              
        // 0x00B94888: B.LS #0xb948a8             | if (val_16 <= 5f) goto label_17;        
        if(val_16 <= 5f)
        {
            goto label_17;
        }
        label_10:
        // 0x00B9488C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B94890: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B94894: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B94898: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B9489C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B948A0: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B948A4: RET                        |  return;                                
        return;
        label_17:
        // 0x00B948A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B948AC: STRB w8, [x19, #0x3c]      | this._isTriger = true;                   //  dest_result_addr=1152921514483438668
        this._isTriger = true;
        // 0x00B948B0: MOV x0, x19                | X0 = 1152921514483438608 (0x100000024CB0D410);//ML01
        // 0x00B948B4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B948B8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B948BC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B948C0: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B948C4: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B948C8: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B948CC: B #0xb948d0                | this.Play(); return;                    
        this.Play();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B94BF4 (12143604), len: 36  VirtAddr: 0x00B94BF4 RVA: 0x00B94BF4 token: 100690189 methodIndex: 25244 delegateWrapperIndex: 0 methodInvoker: 0
    [UnityEngine.ContextMenu] // 0x286B73C
    public void PlayEditor()
    {
        //
        // Disasemble & Code
        // 0x00B94BF4: STP x20, x19, [sp, #-0x20]! | stack[1152921514483571344] = ???;  stack[1152921514483571352] = ???;  //  dest_result_addr=1152921514483571344 |  dest_result_addr=1152921514483571352
        // 0x00B94BF8: STP x29, x30, [sp, #0x10]  | stack[1152921514483571360] = ???;  stack[1152921514483571368] = ???;  //  dest_result_addr=1152921514483571360 |  dest_result_addr=1152921514483571368
        // 0x00B94BFC: ADD x29, sp, #0x10         | X29 = (1152921514483571344 + 16) = 1152921514483571360 (0x100000024CB2DAA0);
        // 0x00B94C00: MOV x19, x0                | X19 = 1152921514483583376 (0x100000024CB30990);//ML01
        // 0x00B94C04: BL #0xb94c18               | this.UpdateCameraAnimation();           
        this.UpdateCameraAnimation();
        // 0x00B94C08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B94C0C: MOV x0, x19                | X0 = 1152921514483583376 (0x100000024CB30990);//ML01
        // 0x00B94C10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B94C14: B #0xb95710                | this.UpdateBossAnimation(); return;     
        this.UpdateBossAnimation();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B948D0 (12142800), len: 804  VirtAddr: 0x00B948D0 RVA: 0x00B948D0 token: 100690190 methodIndex: 25245 delegateWrapperIndex: 0 methodInvoker: 0
    public void Play()
    {
        //
        // Disasemble & Code
        // 0x00B948D0: STP d11, d10, [sp, #-0x50]! | stack[1152921514483744816] = ???;  stack[1152921514483744824] = ???;  //  dest_result_addr=1152921514483744816 |  dest_result_addr=1152921514483744824
        // 0x00B948D4: STP d9, d8, [sp, #0x10]    | stack[1152921514483744832] = ???;  stack[1152921514483744840] = ???;  //  dest_result_addr=1152921514483744832 |  dest_result_addr=1152921514483744840
        // 0x00B948D8: STP x22, x21, [sp, #0x20]  | stack[1152921514483744848] = ???;  stack[1152921514483744856] = ???;  //  dest_result_addr=1152921514483744848 |  dest_result_addr=1152921514483744856
        // 0x00B948DC: STP x20, x19, [sp, #0x30]  | stack[1152921514483744864] = ???;  stack[1152921514483744872] = ???;  //  dest_result_addr=1152921514483744864 |  dest_result_addr=1152921514483744872
        // 0x00B948E0: STP x29, x30, [sp, #0x40]  | stack[1152921514483744880] = ???;  stack[1152921514483744888] = ???;  //  dest_result_addr=1152921514483744880 |  dest_result_addr=1152921514483744888
        // 0x00B948E4: ADD x29, sp, #0x40         | X29 = (1152921514483744816 + 64) = 1152921514483744880 (0x100000024CB58070);
        // 0x00B948E8: SUB sp, sp, #0x10          | SP = (1152921514483744816 - 16) = 1152921514483744800 (0x100000024CB58020);
        // 0x00B948EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B948F0: LDRB w8, [x20, #0xa6e]     | W8 = (bool)static_value_03733A6E;       
        // 0x00B948F4: MOV x19, x0                | X19 = 1152921514483756896 (0x100000024CB5AF60);//ML01
        // 0x00B948F8: TBNZ w8, #0, #0xb94914     | if (static_value_03733A6E == true) goto label_0;
        // 0x00B948FC: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00B94900: LDR x8, [x8, #0xe48]       | X8 = 0x2B8F8E0;                         
        // 0x00B94904: LDR w0, [x8]               | W0 = 0x14FC;                            
        // 0x00B94908: BL #0x2782188              | X0 = sub_2782188( ?? 0x14FC, ????);     
        // 0x00B9490C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B94910: STRB w8, [x20, #0xa6e]     | static_value_03733A6E = true;            //  dest_result_addr=57883246
        label_0:
        // 0x00B94914: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B94918: STRB w8, [x19, #0x18]      | this.<IsPlaying>k__BackingField = true;  //  dest_result_addr=1152921514483756920
        this.<IsPlaying>k__BackingField = true;
        // 0x00B9491C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B94920: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B94924: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B94928: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B9492C: TBZ w8, #0, #0xb9493c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B94930: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B94934: CBNZ w8, #0xb9493c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B94938: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00B9493C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94940: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94944: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_1 = ZMG.GlobalGOMgr;
        // 0x00B94948: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B9494C: CBNZ x20, #0xb94954        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B94950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B94954: ADRP x21, #0x361e000       | X21 = 56745984 (0x361E000);             
        // 0x00B94958: LDR x21, [x21, #0xad8]     | X21 = (string**)(1152921510322346064)("LS_BOSS_SHOW");
        // 0x00B9495C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94960: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B94964: LDR x1, [x21]              | X1 = "LS_BOSS_SHOW";                    
        // 0x00B94968: BL #0x2881c50              | val_1.Lock2DTouchEvent(key:  "LS_BOSS_SHOW");
        val_1.Lock2DTouchEvent(key:  "LS_BOSS_SHOW");
        // 0x00B9496C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94974: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_2 = ZMG.GlobalGOMgr;
        // 0x00B94978: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B9497C: CBNZ x20, #0xb94984        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B94980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B94984: LDR x1, [x21]              | X1 = "LS_BOSS_SHOW";                    
        // 0x00B94988: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9498C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B94990: BL #0x2881f68              | val_2.Lock3DTouchEvent(key:  "LS_BOSS_SHOW");
        val_2.Lock3DTouchEvent(key:  "LS_BOSS_SHOW");
        // 0x00B94994: MOVZ w8, #0x101            | W8 = 257 (0x101);//ML01                 
        // 0x00B94998: MOV x0, x19                | X0 = 1152921514483756896 (0x100000024CB5AF60);//ML01
        // 0x00B9499C: STP wzr, wzr, [x19, #0x88] | this._camPointIndex = 0;  this._bosPointIndex = 0;  //  dest_result_addr=1152921514483757032 |  dest_result_addr=1152921514483757036
        this._camPointIndex = 0;
        this._bosPointIndex = 0;
        // 0x00B949A0: STRH w8, [x19, #0x90]      | this._isCamPlaying = true; this._isBosPlaying = true;  //  dest_result_addr=1152921514483757040 dest_result_addr=1152921514483757041
        this._isCamPlaying = true;
        this._isBosPlaying = true;
        // 0x00B949A4: BL #0xb96088               | this.GetBossEntity();                   
        this.GetBossEntity();
        // 0x00B949A8: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B949AC: CBNZ x20, #0xb949b4        | if (this._aniJsc != null) goto label_5; 
        if(this._aniJsc != null)
        {
            goto label_5;
        }
        // 0x00B949B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x00B949B4: LDR w8, [x20, #0x20]       | W8 = this._aniJsc._isBoss; //P2         
        // 0x00B949B8: CMP w8, #1                 | STATE = COMPARE(this._aniJsc._isBoss, 0x1)
        // 0x00B949BC: B.NE #0xb94b4c             | if (this._aniJsc._isBoss != 1) goto label_6;
        if(this._aniJsc._isBoss != 1)
        {
            goto label_6;
        }
        // 0x00B949C0: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B949C4: CBNZ x20, #0xb949cc        | if (this._boss != null) goto label_7;   
        if(this._boss != null)
        {
            goto label_7;
        }
        // 0x00B949C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_7:
        // 0x00B949CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B949D0: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B949D4: BL #0x20d5094              | X0 = this._boss.get_transform();        
        UnityEngine.Transform val_3 = this._boss.transform;
        // 0x00B949D8: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B949DC: CBNZ x20, #0xb949e4        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00B949E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B949E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B949E8: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B949EC: BL #0x2693510              | X0 = val_3.get_position();              
        UnityEngine.Vector3 val_4 = val_3.position;
        // 0x00B949F0: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B949F4: STP s0, s1, [x19, #0x48]   | this._bossPos = val_4;  mem[1152921514483756972] = val_4.y;  //  dest_result_addr=1152921514483756968 |  dest_result_addr=1152921514483756972
        this._bossPos = val_4;
        mem[1152921514483756972] = val_4.y;
        // 0x00B949F8: STR s2, [x19, #0x50]       | mem[1152921514483756976] = val_4.z;      //  dest_result_addr=1152921514483756976
        mem[1152921514483756976] = val_4.z;
        // 0x00B949FC: CBNZ x20, #0xb94a04        | if (this._boss != null) goto label_9;   
        if(this._boss != null)
        {
            goto label_9;
        }
        // 0x00B94A00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B94A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94A08: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B94A0C: BL #0x20d5094              | X0 = this._boss.get_transform();        
        UnityEngine.Transform val_5 = this._boss.transform;
        // 0x00B94A10: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B94A14: CBNZ x20, #0xb94a1c        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B94A18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B94A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94A20: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B94A24: BL #0x26937d8              | X0 = val_5.get_rotation();              
        UnityEngine.Quaternion val_6 = val_5.rotation;
        // 0x00B94A28: STP s0, s1, [x19, #0x54]   | this._bossRot = val_6;  mem[1152921514483756984] = val_6.y;  //  dest_result_addr=1152921514483756980 |  dest_result_addr=1152921514483756984
        this._bossRot = val_6;
        mem[1152921514483756984] = val_6.y;
        // 0x00B94A2C: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B94A30: STP s2, s3, [x19, #0x5c]   | mem[1152921514483756988] = val_6.z;  mem[1152921514483756992] = val_6.w;  //  dest_result_addr=1152921514483756988 |  dest_result_addr=1152921514483756992
        mem[1152921514483756988] = val_6.z;
        mem[1152921514483756992] = val_6.w;
        // 0x00B94A34: CBNZ x20, #0xb94a3c        | if (this._boss != null) goto label_11;  
        if(this._boss != null)
        {
            goto label_11;
        }
        // 0x00B94A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00B94A3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94A40: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B94A44: BL #0x20d5094              | X0 = this._boss.get_transform();        
        UnityEngine.Transform val_7 = this._boss.transform;
        // 0x00B94A48: LDR x21, [x19, #0x80]      | X21 = this._aniJsc; //P2                
        // 0x00B94A4C: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B94A50: CBNZ x21, #0xb94a58        | if (this._aniJsc != null) goto label_12;
        if(this._aniJsc != null)
        {
            goto label_12;
        }
        // 0x00B94A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00B94A58: LDP s0, s1, [x21, #0x24]   | S0 = this._aniJsc._bossPos_x; //P2  S1 = this._aniJsc._bossPos_y; //P2  //  | 
        // 0x00B94A5C: LDR s2, [x21, #0x2c]       | S2 = this._aniJsc._bossPos_z; //P2      
        // 0x00B94A60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94A64: MOV x0, sp                 | X0 = 1152921514483744800 (0x100000024CB58020);//ML01
        // 0x00B94A68: STR wzr, [sp, #8]          | stack[1152921514483744808] = 0x0;        //  dest_result_addr=1152921514483744808
        // 0x00B94A6C: STR xzr, [sp]              | stack[1152921514483744800] = 0x0;        //  dest_result_addr=1152921514483744800
        // 0x00B94A70: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B94A74: LDP s8, s9, [sp]           | S8 = 0; S9 = 0;                          //  | 
        // 0x00B94A78: LDR s10, [sp, #8]          | S10 = 0;                                
        // 0x00B94A7C: CBNZ x20, #0xb94a84        | if (val_7 != null) goto label_13;       
        if(val_7 != null)
        {
            goto label_13;
        }
        // 0x00B94A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000024CB58020, ????);
        label_13:
        // 0x00B94A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94A88: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00B94A8C: MOV v0.16b, v8.16b         | V0 = 0 (0x0);//ML01                     
        // 0x00B94A90: MOV v1.16b, v9.16b         | V1 = 0 (0x0);//ML01                     
        // 0x00B94A94: MOV v2.16b, v10.16b        | V2 = 0 (0x0);//ML01                     
        // 0x00B94A98: BL #0x26935b8              | val_7.set_position(value:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        val_7.position = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        // 0x00B94A9C: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B94AA0: CBNZ x20, #0xb94aa8        | if (this._boss != null) goto label_14;  
        if(this._boss != null)
        {
            goto label_14;
        }
        // 0x00B94AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_14:
        // 0x00B94AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94AAC: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B94AB0: BL #0x20d5094              | X0 = this._boss.get_transform();        
        UnityEngine.Transform val_8 = this._boss.transform;
        // 0x00B94AB4: LDR x21, [x19, #0x80]      | X21 = this._aniJsc; //P2                
        // 0x00B94AB8: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B94ABC: CBNZ x21, #0xb94ac4        | if (this._aniJsc != null) goto label_15;
        if(this._aniJsc != null)
        {
            goto label_15;
        }
        // 0x00B94AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_15:
        // 0x00B94AC4: LDR s1, [x21, #0x30]       | S1 = this._aniJsc._bossRot_y; //P2      
        // 0x00B94AC8: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B94ACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94AD0: MOV x0, sp                 | X0 = 1152921514483744800 (0x100000024CB58020);//ML01
        // 0x00B94AD4: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x00B94AD8: STR wzr, [sp, #8]          | stack[1152921514483744808] = 0x0;        //  dest_result_addr=1152921514483744808
        // 0x00B94ADC: STR xzr, [sp]              | stack[1152921514483744800] = 0x0;        //  dest_result_addr=1152921514483744800
        // 0x00B94AE0: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B94AE4: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B94AE8: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B94AEC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00B94AF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B94AF4: TBZ w8, #0, #0xb94b04      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B94AF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B94AFC: CBNZ w8, #0xb94b04         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B94B00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_17:
        // 0x00B94B04: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B94B08: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00B94B0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94B14: BL #0x1b7f628              | X0 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Quaternion val_9 = UnityEngine.Quaternion.Euler(euler:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B94B18: MOV v8.16b, v0.16b         | V8 = val_9.x;//m1                       
        // 0x00B94B1C: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        // 0x00B94B20: MOV v10.16b, v2.16b        | V10 = val_9.z;//m1                      
        // 0x00B94B24: MOV v11.16b, v3.16b        | V11 = val_9.w;//m1                      
        // 0x00B94B28: CBNZ x20, #0xb94b30        | if (val_8 != null) goto label_18;       
        if(val_8 != null)
        {
            goto label_18;
        }
        // 0x00B94B2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_18:
        // 0x00B94B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94B34: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B94B38: MOV v0.16b, v8.16b         | V0 = val_9.x;//m1                       
        // 0x00B94B3C: MOV v1.16b, v9.16b         | V1 = val_9.y;//m1                       
        // 0x00B94B40: MOV v2.16b, v10.16b        | V2 = val_9.z;//m1                       
        // 0x00B94B44: MOV v3.16b, v11.16b        | V3 = val_9.w;//m1                       
        // 0x00B94B48: BL #0x26938b0              | val_8.set_rotation(value:  new UnityEngine.Quaternion() {x = val_9.x, y = val_9.y, z = val_9.z, w = val_9.w});
        val_8.rotation = new UnityEngine.Quaternion() {x = val_9.x, y = val_9.y, z = val_9.z, w = val_9.w};
        label_6:
        // 0x00B94B4C: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B94B50: CBNZ x20, #0xb94b58        | if (this._boss != null) goto label_19;  
        if(this._boss != null)
        {
            goto label_19;
        }
        // 0x00B94B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_19:
        // 0x00B94B58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94B5C: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B94B60: BL #0x20d50fc              | X0 = this._boss.get_gameObject();       
        UnityEngine.GameObject val_10 = this._boss.gameObject;
        // 0x00B94B64: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
        // 0x00B94B68: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921514483732816)("Boss");
        // 0x00B94B6C: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00B94B70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94B74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94B78: LDR x1, [x8]               | X1 = "Boss";                            
        // 0x00B94B7C: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_11 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00B94B80: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B94B84: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00B94B88: MOV w21, w0                | W21 = val_11;//m1                       
        // 0x00B94B8C: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00B94B90: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B94B94: TBZ w9, #0, #0xb94ba8      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00B94B98: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B94B9C: CBNZ w9, #0xb94ba8         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00B94BA0: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B94BA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_21:
        // 0x00B94BA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94BAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94BB0: MOV x1, x20                | X1 = val_10;//m1                        
        // 0x00B94BB4: MOV w2, w21                | W2 = val_11;//m1                        
        // 0x00B94BB8: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_10);
        NGUITools.SetLayer(go:  0, layer:  val_10);
        // 0x00B94BBC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B94BC0: MOV x0, x19                | X0 = 1152921514483756896 (0x100000024CB5AF60);//ML01
        // 0x00B94BC4: BL #0xb96234               | this.SetCameraState(state:  false);     
        this.SetCameraState(state:  false);
        // 0x00B94BC8: MOV x0, x19                | X0 = 1152921514483756896 (0x100000024CB5AF60);//ML01
        // 0x00B94BCC: BL #0xb94c18               | this.UpdateCameraAnimation();           
        this.UpdateCameraAnimation();
        // 0x00B94BD0: MOV x0, x19                | X0 = 1152921514483756896 (0x100000024CB5AF60);//ML01
        // 0x00B94BD4: BL #0xb95710               | this.UpdateBossAnimation();             
        this.UpdateBossAnimation();
        // 0x00B94BD8: SUB sp, x29, #0x40         | SP = (1152921514483744880 - 64) = 1152921514483744816 (0x100000024CB58030);
        // 0x00B94BDC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B94BE0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B94BE4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B94BE8: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B94BEC: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B94BF0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9660C (12150284), len: 548  VirtAddr: 0x00B9660C RVA: 0x00B9660C token: 100690191 methodIndex: 25246 delegateWrapperIndex: 0 methodInvoker: 0
    private void End()
    {
        //
        // Disasemble & Code
        // 0x00B9660C: STP d11, d10, [sp, #-0x50]! | stack[1152921514483963312] = ???;  stack[1152921514483963320] = ???;  //  dest_result_addr=1152921514483963312 |  dest_result_addr=1152921514483963320
        // 0x00B96610: STP d9, d8, [sp, #0x10]    | stack[1152921514483963328] = ???;  stack[1152921514483963336] = ???;  //  dest_result_addr=1152921514483963328 |  dest_result_addr=1152921514483963336
        // 0x00B96614: STP x22, x21, [sp, #0x20]  | stack[1152921514483963344] = ???;  stack[1152921514483963352] = ???;  //  dest_result_addr=1152921514483963344 |  dest_result_addr=1152921514483963352
        // 0x00B96618: STP x20, x19, [sp, #0x30]  | stack[1152921514483963360] = ???;  stack[1152921514483963368] = ???;  //  dest_result_addr=1152921514483963360 |  dest_result_addr=1152921514483963368
        // 0x00B9661C: STP x29, x30, [sp, #0x40]  | stack[1152921514483963376] = ???;  stack[1152921514483963384] = ???;  //  dest_result_addr=1152921514483963376 |  dest_result_addr=1152921514483963384
        // 0x00B96620: ADD x29, sp, #0x40         | X29 = (1152921514483963312 + 64) = 1152921514483963376 (0x100000024CB8D5F0);
        // 0x00B96624: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96628: LDRB w8, [x20, #0xa6f]     | W8 = (bool)static_value_03733A6F;       
        // 0x00B9662C: MOV x19, x0                | X19 = 1152921514483975392 (0x100000024CB904E0);//ML01
        // 0x00B96630: TBNZ w8, #0, #0xb9664c     | if (static_value_03733A6F == true) goto label_0;
        // 0x00B96634: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00B96638: LDR x8, [x8, #0x758]       | X8 = 0x2B8F8D0;                         
        // 0x00B9663C: LDR w0, [x8]               | W0 = 0x14F8;                            
        // 0x00B96640: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F8, ????);     
        // 0x00B96644: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96648: STRB w8, [x20, #0xa6f]     | static_value_03733A6F = true;            //  dest_result_addr=57883247
        label_0:
        // 0x00B9664C: STRB wzr, [x19, #0x18]     | this.<IsPlaying>k__BackingField = false;  //  dest_result_addr=1152921514483975416
        this.<IsPlaying>k__BackingField = false;
        // 0x00B96650: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B96654: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B96658: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B9665C: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B96660: TBZ w8, #0, #0xb96670      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B96664: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B96668: CBNZ w8, #0xb96670         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B9666C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00B96670: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B96674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96678: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_1 = ZMG.GlobalGOMgr;
        // 0x00B9667C: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B96680: CBNZ x20, #0xb96688        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B96684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B96688: ADRP x21, #0x361e000       | X21 = 56745984 (0x361E000);             
        // 0x00B9668C: LDR x21, [x21, #0xad8]     | X21 = (string**)(1152921510322346064)("LS_BOSS_SHOW");
        // 0x00B96690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96694: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B96698: LDR x1, [x21]              | X1 = "LS_BOSS_SHOW";                    
        // 0x00B9669C: BL #0x2881dd8              | val_1.UnLock2DTouchEvent(key:  "LS_BOSS_SHOW");
        val_1.UnLock2DTouchEvent(key:  "LS_BOSS_SHOW");
        // 0x00B966A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B966A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B966A8: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_2 = ZMG.GlobalGOMgr;
        // 0x00B966AC: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B966B0: CBNZ x20, #0xb966b8        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B966B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B966B8: LDR x1, [x21]              | X1 = "LS_BOSS_SHOW";                    
        // 0x00B966BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B966C0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B966C4: BL #0x2882014              | val_2.UnLock3DTouchEvent(key:  "LS_BOSS_SHOW");
        val_2.UnLock3DTouchEvent(key:  "LS_BOSS_SHOW");
        // 0x00B966C8: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B966CC: CBNZ x20, #0xb966d4        | if (this._bossInfoShow != null) goto label_5;
        if(this._bossInfoShow != null)
        {
            goto label_5;
        }
        // 0x00B966D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B966D4: MOV x0, x20                | X0 = this._bossInfoShow;//m1            
        // 0x00B966D8: BL #0xb96830               | this._bossInfoShow.PlayReverse();       
        this._bossInfoShow.PlayReverse();
        // 0x00B966DC: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B966E0: STR xzr, [x19, #0x78]      | this._bossInfoShow = null;               //  dest_result_addr=1152921514483975512
        this._bossInfoShow = 0;
        // 0x00B966E4: CBNZ x20, #0xb966ec        | if (this._boss != null) goto label_6;   
        if(this._boss != null)
        {
            goto label_6;
        }
        // 0x00B966E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._bossInfoShow, ????);
        label_6:
        // 0x00B966EC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B966F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B966F4: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B966F8: BL #0xd89f1c               | this._boss.set_isSkillFrozen(value:  false);
        this._boss.isSkillFrozen = false;
        // 0x00B966FC: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B96700: CBNZ x20, #0xb96708        | if (this._aniJsc != null) goto label_7; 
        if(this._aniJsc != null)
        {
            goto label_7;
        }
        // 0x00B96704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._boss, ????); 
        label_7:
        // 0x00B96708: LDR w8, [x20, #0x20]       | W8 = this._aniJsc._isBoss; //P2         
        // 0x00B9670C: CMP w8, #1                 | STATE = COMPARE(this._aniJsc._isBoss, 0x1)
        // 0x00B96710: B.NE #0xb967a0             | if (this._aniJsc._isBoss != 1) goto label_8;
        if(this._aniJsc._isBoss != 1)
        {
            goto label_8;
        }
        // 0x00B96714: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B96718: CBNZ x20, #0xb96720        | if (this._boss != null) goto label_9;   
        if(this._boss != null)
        {
            goto label_9;
        }
        // 0x00B9671C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._boss, ????); 
        label_9:
        // 0x00B96720: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96724: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B96728: BL #0x20d5094              | X0 = this._boss.get_transform();        
        UnityEngine.Transform val_3 = this._boss.transform;
        // 0x00B9672C: LDP s8, s9, [x19, #0x48]   | S8 = this._bossPos; //P2                 //  | 
        // 0x00B96730: LDR s10, [x19, #0x50]      | 
        // 0x00B96734: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B96738: CBNZ x20, #0xb96740        | if (val_3 != null) goto label_10;       
        if(val_3 != null)
        {
            goto label_10;
        }
        // 0x00B9673C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x00B96740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96744: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B96748: MOV v0.16b, v8.16b         | V0 = this._bossPos;//m1                 
        // 0x00B9674C: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B96750: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B96754: BL #0x26935b8              | val_3.set_position(value:  new UnityEngine.Vector3() {x = this._bossPos, y = V9.16B, z = V10.16B});
        val_3.position = new UnityEngine.Vector3() {x = this._bossPos, y = V9.16B, z = V10.16B};
        // 0x00B96758: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B9675C: CBNZ x20, #0xb96764        | if (this._boss != null) goto label_11;  
        if(this._boss != null)
        {
            goto label_11;
        }
        // 0x00B96760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_11:
        // 0x00B96764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96768: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B9676C: BL #0x20d5094              | X0 = this._boss.get_transform();        
        UnityEngine.Transform val_4 = this._boss.transform;
        // 0x00B96770: LDP s8, s9, [x19, #0x54]   | S8 = this._bossRot; //P2                 //  | 
        // 0x00B96774: LDP s10, s11, [x19, #0x5c] |                                          //  | 
        // 0x00B96778: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B9677C: CBNZ x20, #0xb96784        | if (val_4 != null) goto label_12;       
        if(val_4 != null)
        {
            goto label_12;
        }
        // 0x00B96780: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_12:
        // 0x00B96784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96788: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B9678C: MOV v0.16b, v8.16b         | V0 = this._bossRot;//m1                 
        // 0x00B96790: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B96794: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B96798: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x00B9679C: BL #0x26938b0              | val_4.set_rotation(value:  new UnityEngine.Quaternion() {x = this._bossRot, y = V9.16B, z = V10.16B, w = V11.16B});
        val_4.rotation = new UnityEngine.Quaternion() {x = this._bossRot, y = V9.16B, z = V10.16B, w = V11.16B};
        label_8:
        // 0x00B967A0: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B967A4: CBNZ x20, #0xb967ac        | if (this._boss != null) goto label_13;  
        if(this._boss != null)
        {
            goto label_13;
        }
        // 0x00B967A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x00B967AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B967B0: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B967B4: BL #0x20d50fc              | X0 = this._boss.get_gameObject();       
        UnityEngine.GameObject val_5 = this._boss.gameObject;
        // 0x00B967B8: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B967BC: LDR x8, [x8, #0xa10]       | X8 = (string**)(1152921513542678400)("Player");
        // 0x00B967C0: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B967C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B967C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B967CC: LDR x1, [x8]               | X1 = "Player";                          
        // 0x00B967D0: BL #0x1a732bc              | X0 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        int val_6 = UnityEngine.LayerMask.NameToLayer(layerName:  0);
        // 0x00B967D4: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B967D8: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00B967DC: MOV w21, w0                | W21 = val_6;//m1                        
        // 0x00B967E0: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00B967E4: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B967E8: TBZ w9, #0, #0xb967fc      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B967EC: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B967F0: CBNZ w9, #0xb967fc         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B967F4: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B967F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_15:
        // 0x00B967FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B96800: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96804: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x00B96808: MOV w2, w21                | W2 = val_6;//m1                         
        // 0x00B9680C: BL #0xd0b554               | NGUITools.SetLayer(go:  0, layer:  val_5);
        NGUITools.SetLayer(go:  0, layer:  val_5);
        // 0x00B96810: MOV x0, x19                | X0 = 1152921514483975392 (0x100000024CB904E0);//ML01
        // 0x00B96814: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96818: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B9681C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B96820: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B96824: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B96828: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00B9682C: B #0xb96234                | this.SetCameraState(state:  true); return;
        this.SetCameraState(state:  true);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B94C18 (12143640), len: 2808  VirtAddr: 0x00B94C18 RVA: 0x00B94C18 token: 100690192 methodIndex: 25247 delegateWrapperIndex: 0 methodInvoker: 0
    private void UpdateCameraAnimation()
    {
        //
        // Disasemble & Code
        // 0x00B94C18: STP x28, x27, [sp, #-0x60]! | stack[1152921514484273152] = ???;  stack[1152921514484273160] = ???;  //  dest_result_addr=1152921514484273152 |  dest_result_addr=1152921514484273160
        // 0x00B94C1C: STP x26, x25, [sp, #0x10]  | stack[1152921514484273168] = ???;  stack[1152921514484273176] = ???;  //  dest_result_addr=1152921514484273168 |  dest_result_addr=1152921514484273176
        // 0x00B94C20: STP x24, x23, [sp, #0x20]  | stack[1152921514484273184] = ???;  stack[1152921514484273192] = ???;  //  dest_result_addr=1152921514484273184 |  dest_result_addr=1152921514484273192
        // 0x00B94C24: STP x22, x21, [sp, #0x30]  | stack[1152921514484273200] = ???;  stack[1152921514484273208] = ???;  //  dest_result_addr=1152921514484273200 |  dest_result_addr=1152921514484273208
        // 0x00B94C28: STP x20, x19, [sp, #0x40]  | stack[1152921514484273216] = ???;  stack[1152921514484273224] = ???;  //  dest_result_addr=1152921514484273216 |  dest_result_addr=1152921514484273224
        // 0x00B94C2C: STP x29, x30, [sp, #0x50]  | stack[1152921514484273232] = ???;  stack[1152921514484273240] = ???;  //  dest_result_addr=1152921514484273232 |  dest_result_addr=1152921514484273240
        // 0x00B94C30: ADD x29, sp, #0x50         | X29 = (1152921514484273152 + 80) = 1152921514484273232 (0x100000024CBD9050);
        // 0x00B94C34: SUB sp, sp, #0x50          | SP = (1152921514484273152 - 80) = 1152921514484273072 (0x100000024CBD8FB0);
        // 0x00B94C38: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B94C3C: LDRB w8, [x20, #0xa70]     | W8 = (bool)static_value_03733A70;       
        // 0x00B94C40: MOV x19, x0                | X19 = 1152921514484285248 (0x100000024CBDBF40);//ML01
        // 0x00B94C44: TBNZ w8, #0, #0xb94c60     | if (static_value_03733A70 == true) goto label_0;
        // 0x00B94C48: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B94C4C: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8F8F4;                         
        // 0x00B94C50: LDR w0, [x8]               | W0 = 0x1501;                            
        // 0x00B94C54: BL #0x2782188              | X0 = sub_2782188( ?? 0x1501, ????);     
        // 0x00B94C58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B94C5C: STRB w8, [x20, #0xa70]     | static_value_03733A70 = true;            //  dest_result_addr=57883248
        label_0:
        // 0x00B94C60: LDR w21, [x19, #0x88]      | W21 = this._camPointIndex; //P2         
        // 0x00B94C64: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B94C68: CBNZ x20, #0xb94c70        | if (this._aniJsc != null) goto label_1; 
        if(this._aniJsc != null)
        {
            goto label_1;
        }
        // 0x00B94C6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1501, ????);     
        label_1:
        // 0x00B94C70: LDR x20, [x20, #0x38]      | X20 = this._aniJsc._camera; //P2        
        // 0x00B94C74: CBNZ x20, #0xb94c7c        | if (this._aniJsc._camera != null) goto label_2;
        if(this._aniJsc._camera != null)
        {
            goto label_2;
        }
        // 0x00B94C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1501, ????);     
        label_2:
        // 0x00B94C7C: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B94C80: LDR x8, [x8, #0x8d8]       | X8 = 1152921514484116640;               
        // 0x00B94C84: MOV x0, x20                | X0 = this._aniJsc._camera;//m1          
        // 0x00B94C88: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<AnimationPointJSC>::get_Count();
        // 0x00B94C8C: BL #0x25ed72c              | X0 = this._aniJsc._camera.get_Count();  
        int val_1 = this._aniJsc._camera.Count;
        // 0x00B94C90: CMP w21, w0                | STATE = COMPARE(this._camPointIndex, val_1)
        // 0x00B94C94: B.GE #0xb956e8             | if (this._camPointIndex >= val_1) goto label_3;
        if(this._camPointIndex >= val_1)
        {
            goto label_3;
        }
        // 0x00B94C98: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B94C9C: CBNZ x20, #0xb94ca4        | if (this._aniJsc != null) goto label_4; 
        if(this._aniJsc != null)
        {
            goto label_4;
        }
        // 0x00B94CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B94CA4: LDR x20, [x20, #0x38]      | X20 = this._aniJsc._camera; //P2        
        // 0x00B94CA8: LDR w21, [x19, #0x88]      | W21 = this._camPointIndex; //P2         
        // 0x00B94CAC: CBNZ x20, #0xb94cb4        | if (this._aniJsc._camera != null) goto label_5;
        if(this._aniJsc._camera != null)
        {
            goto label_5;
        }
        // 0x00B94CB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B94CB4: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x00B94CB8: LDR x8, [x8, #0x438]       | X8 = 1152921514484125856;               
        // 0x00B94CBC: MOV x0, x20                | X0 = this._aniJsc._camera;//m1          
        // 0x00B94CC0: MOV w1, w21                | W1 = this._camPointIndex;//m1           
        // 0x00B94CC4: LDR x2, [x8]               | X2 = public AnimationPointJSC System.Collections.Generic.List<AnimationPointJSC>::get_Item(int index);
        // 0x00B94CC8: BL #0x25ed734              | X0 = this._aniJsc._camera.get_Item(index:  this._camPointIndex);
        AnimationPointJSC val_2 = this._aniJsc._camera.Item[this._camPointIndex];
        // 0x00B94CCC: LDR x20, [x19, #0x30]      | X20 = this.BossCamera; //P2             
        // 0x00B94CD0: STR x0, [x19, #0x98]       | this._curCamAni = val_2;                 //  dest_result_addr=1152921514484285400
        this._curCamAni = val_2;
        // 0x00B94CD4: CBNZ x20, #0xb94cdc        | if (this.BossCamera != null) goto label_6;
        if(this.BossCamera != null)
        {
            goto label_6;
        }
        // 0x00B94CD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B94CDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94CE0: MOV x0, x20                | X0 = this.BossCamera;//m1               
        // 0x00B94CE4: BL #0x20d50fc              | X0 = this.BossCamera.get_gameObject();  
        UnityEngine.GameObject val_3 = this.BossCamera.gameObject;
        // 0x00B94CE8: ADRP x26, #0x3630000       | X26 = 56819712 (0x3630000);             
        // 0x00B94CEC: LDR x26, [x26, #0x3d0]     | X26 = 1152921504954501264;              
        // 0x00B94CF0: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B94CF4: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00B94CF8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94CFC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B94D00: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00B94D04: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94D08: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B94D0C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94D10: CBNZ x21, #0xb94d18        | if ( != null) goto label_7;             
        if(null != null)
        {
            goto label_7;
        }
        // 0x00B94D14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_7:
        // 0x00B94D18: ADRP x22, #0x361a000       | X22 = 56729600 (0x361A000);             
        // 0x00B94D1C: LDR x22, [x22, #0x650]     | X22 = (string**)(1152921513636468176)("amount");
        // 0x00B94D20: LDR x0, [x22]              | X0 = "amount";                          
        // 0x00B94D24: CBZ x0, #0xb94d44          | if ("amount" == null) goto label_9;     
        // 0x00B94D28: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94D2C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94D30: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "amount", ????);   
        // 0x00B94D34: CBNZ x0, #0xb94d44         | if ("amount" != null) goto label_9;     
        if("amount" != null)
        {
            goto label_9;
        }
        // 0x00B94D38: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "amount", ????);   
        // 0x00B94D3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94D40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "amount", ????);   
        label_9:
        // 0x00B94D44: LDR x22, [x22]             | X22 = "amount";                         
        // 0x00B94D48: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B94D4C: CBNZ w8, #0xb94d5c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_10;
        // 0x00B94D50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "amount", ????);   
        // 0x00B94D54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94D58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "amount", ????);   
        label_10:
        // 0x00B94D5C: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "amount";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "amount";
        // 0x00B94D60: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B94D64: CBNZ x22, #0xb94d6c        | if (this._curCamAni != null) goto label_11;
        if(this._curCamAni != null)
        {
            goto label_11;
        }
        // 0x00B94D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "amount", ????);   
        label_11:
        // 0x00B94D6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94D70: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B94D74: BL #0xb27b84               | X0 = this._curCamAni.get_VibrationV3(); 
        UnityEngine.Vector3 val_4 = this._curCamAni.VibrationV3;
        // 0x00B94D78: ADRP x27, #0x3673000       | X27 = 57094144 (0x3673000);             
        // 0x00B94D7C: LDR x27, [x27, #0x488]     | X27 = 1152921504695078912;              
        // 0x00B94D80: ADD x1, sp, #0x40          | X1 = (1152921514484273072 + 64) = 1152921514484273136 (0x100000024CBD8FF0);
        // 0x00B94D84: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B94D88: STP s0, s1, [sp, #0x40]    | stack[1152921514484273136] = val_4.x;  stack[1152921514484273140] = val_4.y;  //  dest_result_addr=1152921514484273136 |  dest_result_addr=1152921514484273140
        // 0x00B94D8C: STR s2, [sp, #0x48]        | stack[1152921514484273144] = val_4.z;    //  dest_result_addr=1152921514484273144
        // 0x00B94D90: BL #0x27bc028              | X0 = 1152921514484351040 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_4);
        // 0x00B94D94: MOV x22, x0                | X22 = 1152921514484351040 (0x100000024CBEC040);//ML01
        // 0x00B94D98: CBZ x22, #0xb94dbc         | if (val_4 == 0) goto label_13;          
        if(val_4 == 0)
        {
            goto label_13;
        }
        // 0x00B94D9C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94DA0: MOV x0, x22                | X0 = 1152921514484351040 (0x100000024CBEC040);//ML01
        // 0x00B94DA4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94DA8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x00B94DAC: CBNZ x0, #0xb94dbc         | if (val_4 != 0) goto label_13;          
        if(val_4 != 0)
        {
            goto label_13;
        }
        // 0x00B94DB0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
        // 0x00B94DB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94DB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_13:
        // 0x00B94DBC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B94DC0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B94DC4: B.HI #0xb94dd4             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_14;
        // 0x00B94DC8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B94DCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94DD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_14:
        // 0x00B94DD4: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_4;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_4;
        // 0x00B94DD8: ADRP x24, #0x360c000       | X24 = 56672256 (0x360C000);             
        // 0x00B94DDC: LDR x24, [x24, #0x728]     | X24 = (string**)(1152921510122312064)("time");
        // 0x00B94DE0: LDR x0, [x24]              | X0 = "time";                            
        // 0x00B94DE4: CBZ x0, #0xb94e04          | if ("time" == null) goto label_16;      
        // 0x00B94DE8: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94DEC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94DF0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00B94DF4: CBNZ x0, #0xb94e04         | if ("time" != null) goto label_16;      
        if("time" != null)
        {
            goto label_16;
        }
        // 0x00B94DF8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00B94DFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94E00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_16:
        // 0x00B94E04: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B94E08: LDR x22, [x24]             | X22 = "time";                           
        // 0x00B94E0C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B94E10: B.HI #0xb94e20             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_17;
        // 0x00B94E14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00B94E18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94E1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_17:
        // 0x00B94E20: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00B94E24: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B94E28: CBNZ x22, #0xb94e30        | if (this._curCamAni != null) goto label_18;
        if(this._curCamAni != null)
        {
            goto label_18;
        }
        // 0x00B94E2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_18:
        // 0x00B94E30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94E34: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B94E38: BL #0xb27c70               | X0 = this._curCamAni.get_vibrationTime();
        float val_5 = this._curCamAni.vibrationTime;
        // 0x00B94E3C: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
        // 0x00B94E40: LDR x23, [x23, #0xce8]     | X23 = 1152921504608444416;              
        // 0x00B94E44: ADD x1, sp, #0x3c          | X1 = (1152921514484273072 + 60) = 1152921514484273132 (0x100000024CBD8FEC);
        // 0x00B94E48: STR s0, [sp, #0x3c]        | stack[1152921514484273132] = val_5;      //  dest_result_addr=1152921514484273132
        // 0x00B94E4C: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B94E50: BL #0x27bc028              | X0 = 1152921514484359232 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_5);
        // 0x00B94E54: MOV x22, x0                | X22 = 1152921514484359232 (0x100000024CBEE040);//ML01
        // 0x00B94E58: CBZ x22, #0xb94e7c         | if (val_5 == 0) goto label_20;          
        if(val_5 == 0)
        {
            goto label_20;
        }
        // 0x00B94E5C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94E60: MOV x0, x22                | X0 = 1152921514484359232 (0x100000024CBEE040);//ML01
        // 0x00B94E64: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94E68: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
        // 0x00B94E6C: CBNZ x0, #0xb94e7c         | if (val_5 != 0) goto label_20;          
        if(val_5 != 0)
        {
            goto label_20;
        }
        // 0x00B94E70: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
        // 0x00B94E74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94E78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_20:
        // 0x00B94E7C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B94E80: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B94E84: B.HI #0xb94e94             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_21;
        // 0x00B94E88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00B94E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94E90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_21:
        // 0x00B94E94: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = val_5; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = val_5;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B94E98: ADRP x25, #0x3635000       | X25 = 56840192 (0x3635000);             
        // 0x00B94E9C: LDR x25, [x25, #0x3d8]     | X25 = (string**)(1152921511388387856)("delay");
        // 0x00B94EA0: LDR x0, [x25]              | X0 = "delay";                           
        // 0x00B94EA4: CBZ x0, #0xb94ec4          | if ("delay" == null) goto label_23;     
        // 0x00B94EA8: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94EAC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94EB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "delay", ????);    
        // 0x00B94EB4: CBNZ x0, #0xb94ec4         | if ("delay" != null) goto label_23;     
        if("delay" != null)
        {
            goto label_23;
        }
        // 0x00B94EB8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "delay", ????);    
        // 0x00B94EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94EC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_23:
        // 0x00B94EC4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B94EC8: LDR x22, [x25]             | X22 = "delay";                          
        // 0x00B94ECC: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B94ED0: B.HI #0xb94ee0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_24;
        // 0x00B94ED4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "delay", ????);    
        // 0x00B94ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94EDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_24:
        // 0x00B94EE0: STR x22, [x21, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";
        // 0x00B94EE4: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B94EE8: CBNZ x22, #0xb94ef0        | if (this._curCamAni != null) goto label_25;
        if(this._curCamAni != null)
        {
            goto label_25;
        }
        // 0x00B94EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "delay", ????);    
        label_25:
        // 0x00B94EF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94EF4: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B94EF8: BL #0xb27c80               | X0 = this._curCamAni.get_vibrationDelay();
        float val_6 = this._curCamAni.vibrationDelay;
        // 0x00B94EFC: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B94F00: ADD x1, sp, #0x38          | X1 = (1152921514484273072 + 56) = 1152921514484273128 (0x100000024CBD8FE8);
        // 0x00B94F04: STR s0, [sp, #0x38]        | stack[1152921514484273128] = val_6;      //  dest_result_addr=1152921514484273128
        // 0x00B94F08: BL #0x27bc028              | X0 = 1152921514484367424 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_6);
        // 0x00B94F0C: MOV x22, x0                | X22 = 1152921514484367424 (0x100000024CBF0040);//ML01
        // 0x00B94F10: CBZ x22, #0xb94f34         | if (val_6 == 0) goto label_27;          
        if(val_6 == 0)
        {
            goto label_27;
        }
        // 0x00B94F14: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94F18: MOV x0, x22                | X0 = 1152921514484367424 (0x100000024CBF0040);//ML01
        // 0x00B94F1C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94F20: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
        // 0x00B94F24: CBNZ x0, #0xb94f34         | if (val_6 != 0) goto label_27;          
        if(val_6 != 0)
        {
            goto label_27;
        }
        // 0x00B94F28: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
        // 0x00B94F2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94F30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_27:
        // 0x00B94F34: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B94F38: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B94F3C: B.HI #0xb94f4c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_28;
        // 0x00B94F40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B94F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94F48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_28:
        // 0x00B94F4C: STR x22, [x21, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = val_6; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
        typeof(System.Object[]).__il2cppRuntimeField_48 = val_6;
        typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
        // 0x00B94F50: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B94F54: LDR x8, [x8, #0x178]       | X8 = 1152921504856739840;               
        // 0x00B94F58: LDR x0, [x8]               | X0 = typeof(iTween);                    
        // 0x00B94F5C: LDRB w8, [x0, #0x10a]      | W8 = iTween.__il2cppRuntimeField_10A;   
        // 0x00B94F60: TBZ w8, #0, #0xb94f70      | if (iTween.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00B94F64: LDR w8, [x0, #0xbc]        | W8 = iTween.__il2cppRuntimeField_cctor_finished;
        // 0x00B94F68: CBNZ w8, #0xb94f70         | if (iTween.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00B94F6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(iTween), ????);
        label_30:
        // 0x00B94F70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94F74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B94F78: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94F7C: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_7 = iTween.Hash(args:  0);
        // 0x00B94F80: MOV x2, x0                 | X2 = val_7;//m1                         
        // 0x00B94F84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B94F88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B94F8C: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00B94F90: BL #0x17c87a0              | iTween.ShakePosition(target:  0, args:  val_3);
        iTween.ShakePosition(target:  0, args:  val_3);
        // 0x00B94F94: LDR x20, [x19, #0x30]      | X20 = this.BossCamera; //P2             
        // 0x00B94F98: CBNZ x20, #0xb94fa0        | if (this.BossCamera != null) goto label_31;
        if(this.BossCamera != null)
        {
            goto label_31;
        }
        // 0x00B94F9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_31:
        // 0x00B94FA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94FA4: MOV x0, x20                | X0 = this.BossCamera;//m1               
        // 0x00B94FA8: BL #0x20d50fc              | X0 = this.BossCamera.get_gameObject();  
        UnityEngine.GameObject val_8 = this.BossCamera.gameObject;
        // 0x00B94FAC: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00B94FB0: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B94FB4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94FB8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B94FBC: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
        // 0x00B94FC0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94FC4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B94FC8: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B94FCC: CBNZ x21, #0xb94fd4        | if ( != null) goto label_32;            
        if(null != null)
        {
            goto label_32;
        }
        // 0x00B94FD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_32:
        // 0x00B94FD4: ADRP x22, #0x35b8000       | X22 = 56328192 (0x35B8000);             
        // 0x00B94FD8: LDR x22, [x22, #0x3a0]     | X22 = (string**)(1152921511315277136)("position");
        // 0x00B94FDC: LDR x0, [x22]              | X0 = "position";                        
        // 0x00B94FE0: CBZ x0, #0xb95000          | if ("position" == null) goto label_34;  
        // 0x00B94FE4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B94FE8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B94FEC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "position", ????); 
        // 0x00B94FF0: CBNZ x0, #0xb95000         | if ("position" != null) goto label_34;  
        if("position" != null)
        {
            goto label_34;
        }
        // 0x00B94FF4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "position", ????); 
        // 0x00B94FF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B94FFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "position", ????); 
        label_34:
        // 0x00B95000: LDR x22, [x22]             | X22 = "position";                       
        // 0x00B95004: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95008: CBNZ w8, #0xb95018         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_35;
        // 0x00B9500C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "position", ????); 
        // 0x00B95010: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95014: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "position", ????); 
        label_35:
        // 0x00B95018: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "position";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "position";
        // 0x00B9501C: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B95020: CBNZ x22, #0xb95028        | if (this._curCamAni != null) goto label_36;
        if(this._curCamAni != null)
        {
            goto label_36;
        }
        // 0x00B95024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "position", ????); 
        label_36:
        // 0x00B95028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9502C: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B95030: BL #0xb27adc               | X0 = this._curCamAni.get_Pos();         
        UnityEngine.Vector3 val_9 = this._curCamAni.Pos;
        // 0x00B95034: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B95038: ADD x1, sp, #0x28          | X1 = (1152921514484273072 + 40) = 1152921514484273112 (0x100000024CBD8FD8);
        // 0x00B9503C: STP s0, s1, [sp, #0x28]    | stack[1152921514484273112] = val_9.x;  stack[1152921514484273116] = val_9.y;  //  dest_result_addr=1152921514484273112 |  dest_result_addr=1152921514484273116
        // 0x00B95040: STR s2, [sp, #0x30]        | stack[1152921514484273120] = val_9.z;    //  dest_result_addr=1152921514484273120
        // 0x00B95044: BL #0x27bc028              | X0 = 1152921514484388928 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_9);
        // 0x00B95048: MOV x22, x0                | X22 = 1152921514484388928 (0x100000024CBF5440);//ML01
        // 0x00B9504C: CBZ x22, #0xb95070         | if (val_9 == 0) goto label_38;          
        if(val_9 == 0)
        {
            goto label_38;
        }
        // 0x00B95050: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95054: MOV x0, x22                | X0 = 1152921514484388928 (0x100000024CBF5440);//ML01
        // 0x00B95058: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9505C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
        // 0x00B95060: CBNZ x0, #0xb95070         | if (val_9 != 0) goto label_38;          
        if(val_9 != 0)
        {
            goto label_38;
        }
        // 0x00B95064: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
        // 0x00B95068: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9506C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_38:
        // 0x00B95070: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95074: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B95078: B.HI #0xb95088             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_39;
        // 0x00B9507C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
        // 0x00B95080: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95084: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
        label_39:
        // 0x00B95088: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_9;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_9;
        // 0x00B9508C: LDR x0, [x24]              | X0 = "time";                            
        // 0x00B95090: CBZ x0, #0xb950b0          | if ("time" == null) goto label_41;      
        // 0x00B95094: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95098: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9509C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00B950A0: CBNZ x0, #0xb950b0         | if ("time" != null) goto label_41;      
        if("time" != null)
        {
            goto label_41;
        }
        // 0x00B950A4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00B950A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B950AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_41:
        // 0x00B950B0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B950B4: LDR x22, [x24]             | X22 = "time";                           
        // 0x00B950B8: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B950BC: B.HI #0xb950cc             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_42;
        // 0x00B950C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00B950C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B950C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_42:
        // 0x00B950CC: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00B950D0: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B950D4: CBNZ x22, #0xb950dc        | if (this._curCamAni != null) goto label_43;
        if(this._curCamAni != null)
        {
            goto label_43;
        }
        // 0x00B950D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_43:
        // 0x00B950DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B950E0: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B950E4: BL #0xb27c38               | X0 = this._curCamAni.get_time();        
        float val_10 = this._curCamAni.time;
        // 0x00B950E8: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B950EC: ADD x1, sp, #0x24          | X1 = (1152921514484273072 + 36) = 1152921514484273108 (0x100000024CBD8FD4);
        // 0x00B950F0: STR s0, [sp, #0x24]        | stack[1152921514484273108] = val_10;     //  dest_result_addr=1152921514484273108
        // 0x00B950F4: BL #0x27bc028              | X0 = 1152921514484397120 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_10);
        // 0x00B950F8: MOV x22, x0                | X22 = 1152921514484397120 (0x100000024CBF7440);//ML01
        // 0x00B950FC: CBZ x22, #0xb95120         | if (val_10 == 0) goto label_45;         
        if(val_10 == 0)
        {
            goto label_45;
        }
        // 0x00B95100: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95104: MOV x0, x22                | X0 = 1152921514484397120 (0x100000024CBF7440);//ML01
        // 0x00B95108: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9510C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
        // 0x00B95110: CBNZ x0, #0xb95120         | if (val_10 != 0) goto label_45;         
        if(val_10 != 0)
        {
            goto label_45;
        }
        // 0x00B95114: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
        // 0x00B95118: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9511C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
        label_45:
        // 0x00B95120: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95124: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B95128: B.HI #0xb95138             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_46;
        // 0x00B9512C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
        // 0x00B95130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95134: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
        label_46:
        // 0x00B95138: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = val_10; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = val_10;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B9513C: LDR x0, [x25]              | X0 = "delay";                           
        // 0x00B95140: CBZ x0, #0xb95160          | if ("delay" == null) goto label_48;     
        // 0x00B95144: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95148: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9514C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "delay", ????);    
        // 0x00B95150: CBNZ x0, #0xb95160         | if ("delay" != null) goto label_48;     
        if("delay" != null)
        {
            goto label_48;
        }
        // 0x00B95154: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "delay", ????);    
        // 0x00B95158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9515C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_48:
        // 0x00B95160: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95164: LDR x22, [x25]             | X22 = "delay";                          
        // 0x00B95168: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B9516C: B.HI #0xb9517c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_49;
        // 0x00B95170: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "delay", ????);    
        // 0x00B95174: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95178: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_49:
        // 0x00B9517C: STR x22, [x21, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";
        // 0x00B95180: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B95184: CBNZ x22, #0xb9518c        | if (this._curCamAni != null) goto label_50;
        if(this._curCamAni != null)
        {
            goto label_50;
        }
        // 0x00B95188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "delay", ????);    
        label_50:
        // 0x00B9518C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95190: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B95194: BL #0xb27c28               | X0 = this._curCamAni.get_delay();       
        float val_11 = this._curCamAni.delay;
        // 0x00B95198: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B9519C: ADD x1, sp, #0x20          | X1 = (1152921514484273072 + 32) = 1152921514484273104 (0x100000024CBD8FD0);
        // 0x00B951A0: STR s0, [sp, #0x20]        | stack[1152921514484273104] = val_11;     //  dest_result_addr=1152921514484273104
        // 0x00B951A4: BL #0x27bc028              | X0 = 1152921514484405312 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_11);
        // 0x00B951A8: MOV x22, x0                | X22 = 1152921514484405312 (0x100000024CBF9440);//ML01
        // 0x00B951AC: CBZ x22, #0xb951d0         | if (val_11 == 0) goto label_52;         
        if(val_11 == 0)
        {
            goto label_52;
        }
        // 0x00B951B0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B951B4: MOV x0, x22                | X0 = 1152921514484405312 (0x100000024CBF9440);//ML01
        // 0x00B951B8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B951BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
        // 0x00B951C0: CBNZ x0, #0xb951d0         | if (val_11 != 0) goto label_52;         
        if(val_11 != 0)
        {
            goto label_52;
        }
        // 0x00B951C4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
        // 0x00B951C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B951CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_52:
        // 0x00B951D0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B951D4: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B951D8: B.HI #0xb951e8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_53;
        // 0x00B951DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
        // 0x00B951E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B951E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_53:
        // 0x00B951E8: STR x22, [x21, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = val_11; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
        typeof(System.Object[]).__il2cppRuntimeField_48 = val_11;
        typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
        // 0x00B951EC: ADRP x22, #0x3617000       | X22 = 56717312 (0x3617000);             
        // 0x00B951F0: LDR x22, [x22, #0x9e0]     | X22 = (string**)(1152921513637036544)("easetype");
        // 0x00B951F4: LDR x0, [x22]              | X0 = "easetype";                        
        // 0x00B951F8: CBZ x0, #0xb95218          | if ("easetype" == null) goto label_55;  
        // 0x00B951FC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95200: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95204: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "easetype", ????); 
        // 0x00B95208: CBNZ x0, #0xb95218         | if ("easetype" != null) goto label_55;  
        if("easetype" != null)
        {
            goto label_55;
        }
        // 0x00B9520C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "easetype", ????); 
        // 0x00B95210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95214: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "easetype", ????); 
        label_55:
        // 0x00B95218: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9521C: LDR x22, [x22]             | X22 = "easetype";                       
        // 0x00B95220: CMP w8, #6                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x6)
        // 0x00B95224: B.HI #0xb95234             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x6) goto label_56;
        // 0x00B95228: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "easetype", ????); 
        // 0x00B9522C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95230: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "easetype", ????); 
        label_56:
        // 0x00B95234: STR x22, [x21, #0x50]      | typeof(System.Object[]).__il2cppRuntimeField_50 = "easetype";  //  dest_result_addr=1152921504954501344
        typeof(System.Object[]).__il2cppRuntimeField_50 = "easetype";
        // 0x00B95238: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B9523C: LDR x8, [x8, #0x8b0]       | X8 = 1152921504856899584;               
        // 0x00B95240: ADD x1, sp, #0x1c          | X1 = (1152921514484273072 + 28) = 1152921514484273100 (0x100000024CBD8FCC);
        // 0x00B95244: LDR x0, [x8]               | X0 = typeof(iTween.EaseType);           
        // 0x00B95248: MOVZ w8, #0x15             | W8 = 21 (0x15);//ML01                   
        // 0x00B9524C: STR w8, [sp, #0x1c]        | stack[1152921514484273100] = 0x15;       //  dest_result_addr=1152921514484273100
        // 0x00B95250: BL #0x27bc028              | X0 = 1152921514484409408 = (Il2CppObject*)Box((RuntimeClass*)typeof(iTween.EaseType), 0x15);
        // 0x00B95254: MOV x22, x0                | X22 = 1152921514484409408 (0x100000024CBFA440);//ML01
        // 0x00B95258: CBZ x22, #0xb9527c         | if (0x15 == 0) goto label_58;           
        if(21 == 0)
        {
            goto label_58;
        }
        // 0x00B9525C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95260: MOV x0, x22                | X0 = 1152921514484409408 (0x100000024CBFA440);//ML01
        // 0x00B95264: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95268: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x15, ????);       
        // 0x00B9526C: CBNZ x0, #0xb9527c         | if (0x15 != 0) goto label_58;           
        if(21 != 0)
        {
            goto label_58;
        }
        // 0x00B95270: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x15, ????);       
        // 0x00B95274: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95278: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x15, ????);       
        label_58:
        // 0x00B9527C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95280: CMP w8, #7                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x7)
        // 0x00B95284: B.HI #0xb95294             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x7) goto label_59;
        // 0x00B95288: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x15, ????);       
        // 0x00B9528C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95290: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x15, ????);       
        label_59:
        // 0x00B95294: STR x22, [x21, #0x58]      | typeof(System.Object[]).__il2cppRuntimeField_58 = 0x15;  //  dest_result_addr=1152921504954501352
        typeof(System.Object[]).__il2cppRuntimeField_58 = 21;
        // 0x00B95298: ADRP x22, #0x3637000       | X22 = 56848384 (0x3637000);             
        // 0x00B9529C: LDR x22, [x22, #0x310]     | X22 = (string**)(1152921513683558096)("oncomplete");
        // 0x00B952A0: LDR x0, [x22]              | X0 = "oncomplete";                      
        // 0x00B952A4: CBZ x0, #0xb952c4          | if ("oncomplete" == null) goto label_61;
        // 0x00B952A8: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B952AC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B952B0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "oncomplete", ????);
        // 0x00B952B4: CBNZ x0, #0xb952c4         | if ("oncomplete" != null) goto label_61;
        if("oncomplete" != null)
        {
            goto label_61;
        }
        // 0x00B952B8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "oncomplete", ????);
        // 0x00B952BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B952C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncomplete", ????);
        label_61:
        // 0x00B952C4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B952C8: LDR x22, [x22]             | X22 = "oncomplete";                     
        // 0x00B952CC: CMP w8, #8                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x8)
        // 0x00B952D0: B.HI #0xb952e0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x8) goto label_62;
        // 0x00B952D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "oncomplete", ????);
        // 0x00B952D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B952DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncomplete", ????);
        label_62:
        // 0x00B952E0: STR x22, [x21, #0x60]      | typeof(System.Object[]).__il2cppRuntimeField_60 = "oncomplete";  //  dest_result_addr=1152921504954501360
        typeof(System.Object[]).__il2cppRuntimeField_60 = "oncomplete";
        // 0x00B952E4: ADRP x22, #0x35f9000       | X22 = 56594432 (0x35F9000);             
        // 0x00B952E8: LDR x22, [x22, #0x7e0]     | X22 = (string**)(1152921514484206752)("UpdateCameraAnimation");
        // 0x00B952EC: LDR x0, [x22]              | X0 = "UpdateCameraAnimation";           
        // 0x00B952F0: CBZ x0, #0xb95310          | if ("UpdateCameraAnimation" == null) goto label_64;
        // 0x00B952F4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B952F8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B952FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "UpdateCameraAnimation", ????);
        // 0x00B95300: CBNZ x0, #0xb95310         | if ("UpdateCameraAnimation" != null) goto label_64;
        if("UpdateCameraAnimation" != null)
        {
            goto label_64;
        }
        // 0x00B95304: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "UpdateCameraAnimation", ????);
        // 0x00B95308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9530C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UpdateCameraAnimation", ????);
        label_64:
        // 0x00B95310: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95314: LDR x22, [x22]             | X22 = "UpdateCameraAnimation";          
        // 0x00B95318: CMP w8, #9                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x9)
        // 0x00B9531C: B.HI #0xb9532c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x9) goto label_65;
        // 0x00B95320: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "UpdateCameraAnimation", ????);
        // 0x00B95324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95328: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UpdateCameraAnimation", ????);
        label_65:
        // 0x00B9532C: STR x22, [x21, #0x68]      | typeof(System.Object[]).__il2cppRuntimeField_68 = "UpdateCameraAnimation";  //  dest_result_addr=1152921504954501368
        typeof(System.Object[]).__il2cppRuntimeField_68 = "UpdateCameraAnimation";
        // 0x00B95330: ADRP x22, #0x35f0000       | X22 = 56557568 (0x35F0000);             
        // 0x00B95334: LDR x22, [x22, #0x9e8]     | X22 = (string**)(1152921514484206864)("oncompletetarget");
        // 0x00B95338: LDR x0, [x22]              | X0 = "oncompletetarget";                
        // 0x00B9533C: CBZ x0, #0xb9535c          | if ("oncompletetarget" == null) goto label_67;
        // 0x00B95340: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95344: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95348: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "oncompletetarget", ????);
        // 0x00B9534C: CBNZ x0, #0xb9535c         | if ("oncompletetarget" != null) goto label_67;
        if("oncompletetarget" != null)
        {
            goto label_67;
        }
        // 0x00B95350: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "oncompletetarget", ????);
        // 0x00B95354: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95358: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncompletetarget", ????);
        label_67:
        // 0x00B9535C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95360: LDR x22, [x22]             | X22 = "oncompletetarget";               
        // 0x00B95364: CMP w8, #0xa               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xA)
        // 0x00B95368: B.HI #0xb95378             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xA) goto label_68;
        // 0x00B9536C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "oncompletetarget", ????);
        // 0x00B95370: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95374: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncompletetarget", ????);
        label_68:
        // 0x00B95378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9537C: MOV x0, x19                | X0 = 1152921514484285248 (0x100000024CBDBF40);//ML01
        // 0x00B95380: STR x22, [x21, #0x70]      | typeof(System.Object[]).__il2cppRuntimeField_70 = "oncompletetarget";  //  dest_result_addr=1152921504954501376
        typeof(System.Object[]).__il2cppRuntimeField_70 = "oncompletetarget";
        // 0x00B95384: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_12 = this.gameObject;
        // 0x00B95388: MOV x22, x0                | X22 = val_12;//m1                       
        // 0x00B9538C: CBZ x22, #0xb953b0         | if (val_12 == null) goto label_70;      
        if(val_12 == null)
        {
            goto label_70;
        }
        // 0x00B95390: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95394: MOV x0, x22                | X0 = val_12;//m1                        
        // 0x00B95398: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9539C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
        // 0x00B953A0: CBNZ x0, #0xb953b0         | if (val_12 != null) goto label_70;      
        if(val_12 != null)
        {
            goto label_70;
        }
        // 0x00B953A4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
        // 0x00B953A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B953AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_70:
        // 0x00B953B0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B953B4: CMP w8, #0xb               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xB)
        // 0x00B953B8: B.HI #0xb953c8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xB) goto label_71;
        // 0x00B953BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
        // 0x00B953C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B953C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_71:
        // 0x00B953C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B953CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B953D0: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B953D4: STR x22, [x21, #0x78]      | typeof(System.Object[]).__il2cppRuntimeField_78 = val_12;  //  dest_result_addr=1152921504954501384
        typeof(System.Object[]).__il2cppRuntimeField_78 = val_12;
        // 0x00B953D8: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_13 = iTween.Hash(args:  0);
        // 0x00B953DC: MOV x2, x0                 | X2 = val_13;//m1                        
        // 0x00B953E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B953E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B953E8: MOV x1, x20                | X1 = val_8;//m1                         
        // 0x00B953EC: BL #0x17c41b0              | iTween.MoveTo(target:  0, args:  val_8);
        iTween.MoveTo(target:  0, args:  val_8);
        // 0x00B953F0: LDR x20, [x19, #0x30]      | X20 = this.BossCamera; //P2             
        // 0x00B953F4: CBNZ x20, #0xb953fc        | if (this.BossCamera != null) goto label_72;
        if(this.BossCamera != null)
        {
            goto label_72;
        }
        // 0x00B953F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_72:
        // 0x00B953FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95400: MOV x0, x20                | X0 = this.BossCamera;//m1               
        // 0x00B95404: BL #0x20d50fc              | X0 = this.BossCamera.get_gameObject();  
        UnityEngine.GameObject val_14 = this.BossCamera.gameObject;
        // 0x00B95408: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00B9540C: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x00B95410: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95414: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B95418: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00B9541C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95420: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B95424: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95428: CBNZ x21, #0xb95430        | if ( != null) goto label_73;            
        if(null != null)
        {
            goto label_73;
        }
        // 0x00B9542C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_73:
        // 0x00B95430: ADRP x22, #0x3610000       | X22 = 56688640 (0x3610000);             
        // 0x00B95434: LDR x22, [x22, #0x858]     | X22 = (string**)(1152921512527230304)("rotation");
        // 0x00B95438: LDR x0, [x22]              | X0 = "rotation";                        
        // 0x00B9543C: CBZ x0, #0xb9545c          | if ("rotation" == null) goto label_75;  
        // 0x00B95440: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95444: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95448: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "rotation", ????); 
        // 0x00B9544C: CBNZ x0, #0xb9545c         | if ("rotation" != null) goto label_75;  
        if("rotation" != null)
        {
            goto label_75;
        }
        // 0x00B95450: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "rotation", ????); 
        // 0x00B95454: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95458: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "rotation", ????); 
        label_75:
        // 0x00B9545C: LDR x22, [x22]             | X22 = "rotation";                       
        // 0x00B95460: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95464: CBNZ w8, #0xb95474         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_76;
        // 0x00B95468: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "rotation", ????); 
        // 0x00B9546C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95470: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "rotation", ????); 
        label_76:
        // 0x00B95474: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "rotation";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "rotation";
        // 0x00B95478: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B9547C: CBNZ x22, #0xb95484        | if (this._curCamAni != null) goto label_77;
        if(this._curCamAni != null)
        {
            goto label_77;
        }
        // 0x00B95480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "rotation", ????); 
        label_77:
        // 0x00B95484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95488: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B9548C: BL #0xb27b30               | X0 = this._curCamAni.get_Rot();         
        UnityEngine.Vector3 val_15 = this._curCamAni.Rot;
        // 0x00B95490: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B95494: ADD x1, sp, #0x10          | X1 = (1152921514484273072 + 16) = 1152921514484273088 (0x100000024CBD8FC0);
        // 0x00B95498: STP s0, s1, [sp, #0x10]    | stack[1152921514484273088] = val_15.x;  stack[1152921514484273092] = val_15.y;  //  dest_result_addr=1152921514484273088 |  dest_result_addr=1152921514484273092
        // 0x00B9549C: STR s2, [sp, #0x18]        | stack[1152921514484273096] = val_15.z;   //  dest_result_addr=1152921514484273096
        // 0x00B954A0: BL #0x27bc028              | X0 = 1152921514484435008 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_15);
        // 0x00B954A4: MOV x22, x0                | X22 = 1152921514484435008 (0x100000024CC00840);//ML01
        // 0x00B954A8: CBZ x22, #0xb954cc         | if (val_15 == 0) goto label_79;         
        if(val_15 == 0)
        {
            goto label_79;
        }
        // 0x00B954AC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B954B0: MOV x0, x22                | X0 = 1152921514484435008 (0x100000024CC00840);//ML01
        // 0x00B954B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B954B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
        // 0x00B954BC: CBNZ x0, #0xb954cc         | if (val_15 != 0) goto label_79;         
        if(val_15 != 0)
        {
            goto label_79;
        }
        // 0x00B954C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
        // 0x00B954C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B954C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_79:
        // 0x00B954CC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B954D0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B954D4: B.HI #0xb954e4             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_80;
        // 0x00B954D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
        // 0x00B954DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B954E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
        label_80:
        // 0x00B954E4: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_15;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_15;
        // 0x00B954E8: LDR x0, [x24]              | X0 = "time";                            
        // 0x00B954EC: CBZ x0, #0xb9550c          | if ("time" == null) goto label_82;      
        // 0x00B954F0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B954F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B954F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00B954FC: CBNZ x0, #0xb9550c         | if ("time" != null) goto label_82;      
        if("time" != null)
        {
            goto label_82;
        }
        // 0x00B95500: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00B95504: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95508: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_82:
        // 0x00B9550C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95510: LDR x22, [x24]             | X22 = "time";                           
        // 0x00B95514: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B95518: B.HI #0xb95528             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_83;
        // 0x00B9551C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00B95520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95524: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_83:
        // 0x00B95528: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00B9552C: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B95530: CBNZ x22, #0xb95538        | if (this._curCamAni != null) goto label_84;
        if(this._curCamAni != null)
        {
            goto label_84;
        }
        // 0x00B95534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_84:
        // 0x00B95538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9553C: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B95540: BL #0xb27c38               | X0 = this._curCamAni.get_time();        
        float val_16 = this._curCamAni.time;
        // 0x00B95544: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B95548: ADD x1, sp, #0xc           | X1 = (1152921514484273072 + 12) = 1152921514484273084 (0x100000024CBD8FBC);
        // 0x00B9554C: STR s0, [sp, #0xc]         | stack[1152921514484273084] = val_16;     //  dest_result_addr=1152921514484273084
        // 0x00B95550: BL #0x27bc028              | X0 = 1152921514484443200 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_16);
        // 0x00B95554: MOV x22, x0                | X22 = 1152921514484443200 (0x100000024CC02840);//ML01
        // 0x00B95558: CBZ x22, #0xb9557c         | if (val_16 == 0) goto label_86;         
        if(val_16 == 0)
        {
            goto label_86;
        }
        // 0x00B9555C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95560: MOV x0, x22                | X0 = 1152921514484443200 (0x100000024CC02840);//ML01
        // 0x00B95564: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95568: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
        // 0x00B9556C: CBNZ x0, #0xb9557c         | if (val_16 != 0) goto label_86;         
        if(val_16 != 0)
        {
            goto label_86;
        }
        // 0x00B95570: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
        // 0x00B95574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95578: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
        label_86:
        // 0x00B9557C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95580: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B95584: B.HI #0xb95594             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_87;
        // 0x00B95588: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
        // 0x00B9558C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
        label_87:
        // 0x00B95594: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = val_16; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = val_16;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B95598: LDR x0, [x25]              | X0 = "delay";                           
        // 0x00B9559C: CBZ x0, #0xb955bc          | if ("delay" == null) goto label_89;     
        // 0x00B955A0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B955A4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B955A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "delay", ????);    
        // 0x00B955AC: CBNZ x0, #0xb955bc         | if ("delay" != null) goto label_89;     
        if("delay" != null)
        {
            goto label_89;
        }
        // 0x00B955B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "delay", ????);    
        // 0x00B955B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B955B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_89:
        // 0x00B955BC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B955C0: LDR x22, [x25]             | X22 = "delay";                          
        // 0x00B955C4: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B955C8: B.HI #0xb955d8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_90;
        // 0x00B955CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "delay", ????);    
        // 0x00B955D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B955D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_90:
        // 0x00B955D8: STR x22, [x21, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";
        // 0x00B955DC: LDR x22, [x19, #0x98]      | X22 = this._curCamAni; //P2             
        // 0x00B955E0: CBNZ x22, #0xb955e8        | if (this._curCamAni != null) goto label_91;
        if(this._curCamAni != null)
        {
            goto label_91;
        }
        // 0x00B955E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "delay", ????);    
        label_91:
        // 0x00B955E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B955EC: MOV x0, x22                | X0 = this._curCamAni;//m1               
        // 0x00B955F0: BL #0xb27c28               | X0 = this._curCamAni.get_delay();       
        float val_17 = this._curCamAni.delay;
        // 0x00B955F4: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B955F8: ADD x1, sp, #8             | X1 = (1152921514484273072 + 8) = 1152921514484273080 (0x100000024CBD8FB8);
        // 0x00B955FC: STR s0, [sp, #8]           | stack[1152921514484273080] = val_17;     //  dest_result_addr=1152921514484273080
        // 0x00B95600: BL #0x27bc028              | X0 = 1152921514484451392 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_17);
        // 0x00B95604: MOV x22, x0                | X22 = 1152921514484451392 (0x100000024CC04840);//ML01
        // 0x00B95608: CBZ x22, #0xb9562c         | if (val_17 == 0) goto label_93;         
        if(val_17 == 0)
        {
            goto label_93;
        }
        // 0x00B9560C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95610: MOV x0, x22                | X0 = 1152921514484451392 (0x100000024CC04840);//ML01
        // 0x00B95614: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95618: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
        // 0x00B9561C: CBNZ x0, #0xb9562c         | if (val_17 != 0) goto label_93;         
        if(val_17 != 0)
        {
            goto label_93;
        }
        // 0x00B95620: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
        // 0x00B95624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
        label_93:
        // 0x00B9562C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95630: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B95634: B.HI #0xb95644             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_94;
        // 0x00B95638: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
        // 0x00B9563C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95640: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
        label_94:
        // 0x00B95644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95648: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9564C: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95650: STR x22, [x21, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = val_17; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
        typeof(System.Object[]).__il2cppRuntimeField_48 = val_17;
        typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
        // 0x00B95654: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_18 = iTween.Hash(args:  0);
        // 0x00B95658: MOV x2, x0                 | X2 = val_18;//m1                        
        // 0x00B9565C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95660: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B95664: MOV x1, x20                | X1 = val_14;//m1                        
        // 0x00B95668: BL #0x17c7120              | iTween.RotateTo(target:  0, args:  val_14);
        iTween.RotateTo(target:  0, args:  val_14);
        // 0x00B9566C: LDR x20, [x19, #0x98]      | X20 = this._curCamAni; //P2             
        // 0x00B95670: CBNZ x20, #0xb95678        | if (this._curCamAni != null) goto label_95;
        if(this._curCamAni != null)
        {
            goto label_95;
        }
        // 0x00B95674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_95:
        // 0x00B95678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9567C: MOV x0, x20                | X0 = this._curCamAni;//m1               
        // 0x00B95680: BL #0xb27c48               | X0 = this._curCamAni.get_fun();         
        string val_19 = this._curCamAni.fun;
        // 0x00B95684: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B95688: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B9568C: MOV x20, x0                | X20 = val_19;//m1                       
        // 0x00B95690: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B95694: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B95698: TBZ w9, #0, #0xb956ac      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_97;
        // 0x00B9569C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B956A0: CBNZ w9, #0xb956ac         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_97;
        // 0x00B956A4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B956A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_97:
        // 0x00B956AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B956B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B956B4: MOV x1, x20                | X1 = val_19;//m1                        
        // 0x00B956B8: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_20 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B956BC: LDR w8, [x19, #0x88]       | W8 = this._camPointIndex; //P2          
        int val_21 = this._camPointIndex;
        // 0x00B956C0: ADD w8, w8, #1             | W8 = (this._camPointIndex + 1);         
        val_21 = val_21 + 1;
        // 0x00B956C4: STR w8, [x19, #0x88]       | this._camPointIndex = (this._camPointIndex + 1);  //  dest_result_addr=1152921514484285384
        this._camPointIndex = val_21;
        // 0x00B956C8: SUB sp, x29, #0x50         | SP = (1152921514484273232 - 80) = 1152921514484273152 (0x100000024CBD9000);
        // 0x00B956CC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B956D0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B956D4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B956D8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B956DC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B956E0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B956E4: RET                        |  return;                                
        return;
        label_3:
        // 0x00B956E8: STRB wzr, [x19, #0x90]     | this._isCamPlaying = false;              //  dest_result_addr=1152921514484285392
        this._isCamPlaying = false;
        // 0x00B956EC: MOV x0, x19                | X0 = 1152921514484285248 (0x100000024CBDBF40);//ML01
        // 0x00B956F0: SUB sp, x29, #0x50         | SP = (1152921514484273232 - 80) = 1152921514484273152 (0x100000024CBD9000);
        // 0x00B956F4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B956F8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B956FC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B95700: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B95704: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B95708: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B9570C: B #0xb968b0                | this.Boss3DShowEnd(); return;           
        this.Boss3DShowEnd();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B95710 (12146448), len: 2424  VirtAddr: 0x00B95710 RVA: 0x00B95710 token: 100690193 methodIndex: 25248 delegateWrapperIndex: 0 methodInvoker: 0
    private void UpdateBossAnimation()
    {
        //
        // Disasemble & Code
        // 0x00B95710: STP d9, d8, [sp, #-0x70]!  | stack[1152921514484671968] = ???;  stack[1152921514484671976] = ???;  //  dest_result_addr=1152921514484671968 |  dest_result_addr=1152921514484671976
        // 0x00B95714: STP x28, x27, [sp, #0x10]  | stack[1152921514484671984] = ???;  stack[1152921514484671992] = ???;  //  dest_result_addr=1152921514484671984 |  dest_result_addr=1152921514484671992
        // 0x00B95718: STP x26, x25, [sp, #0x20]  | stack[1152921514484672000] = ???;  stack[1152921514484672008] = ???;  //  dest_result_addr=1152921514484672000 |  dest_result_addr=1152921514484672008
        // 0x00B9571C: STP x24, x23, [sp, #0x30]  | stack[1152921514484672016] = ???;  stack[1152921514484672024] = ???;  //  dest_result_addr=1152921514484672016 |  dest_result_addr=1152921514484672024
        // 0x00B95720: STP x22, x21, [sp, #0x40]  | stack[1152921514484672032] = ???;  stack[1152921514484672040] = ???;  //  dest_result_addr=1152921514484672032 |  dest_result_addr=1152921514484672040
        // 0x00B95724: STP x20, x19, [sp, #0x50]  | stack[1152921514484672048] = ???;  stack[1152921514484672056] = ???;  //  dest_result_addr=1152921514484672048 |  dest_result_addr=1152921514484672056
        // 0x00B95728: STP x29, x30, [sp, #0x60]  | stack[1152921514484672064] = ???;  stack[1152921514484672072] = ???;  //  dest_result_addr=1152921514484672064 |  dest_result_addr=1152921514484672072
        // 0x00B9572C: ADD x29, sp, #0x60         | X29 = (1152921514484671968 + 96) = 1152921514484672064 (0x100000024CC3A640);
        // 0x00B95730: SUB sp, sp, #0x30          | SP = (1152921514484671968 - 48) = 1152921514484671920 (0x100000024CC3A5B0);
        // 0x00B95734: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B95738: LDRB w8, [x20, #0xa71]     | W8 = (bool)static_value_03733A71;       
        // 0x00B9573C: MOV x19, x0                | X19 = 1152921514484684080 (0x100000024CC3D530);//ML01
        // 0x00B95740: TBNZ w8, #0, #0xb9575c     | if (static_value_03733A71 == true) goto label_0;
        // 0x00B95744: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00B95748: LDR x8, [x8, #0x420]       | X8 = 0x2B8F8F0;                         
        // 0x00B9574C: LDR w0, [x8]               | W0 = 0x1500;                            
        // 0x00B95750: BL #0x2782188              | X0 = sub_2782188( ?? 0x1500, ????);     
        // 0x00B95754: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B95758: STRB w8, [x20, #0xa71]     | static_value_03733A71 = true;            //  dest_result_addr=57883249
        label_0:
        // 0x00B9575C: LDR w21, [x19, #0x8c]      | W21 = this._bosPointIndex; //P2         
        // 0x00B95760: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B95764: CBNZ x20, #0xb9576c        | if (this._aniJsc != null) goto label_1; 
        if(this._aniJsc != null)
        {
            goto label_1;
        }
        // 0x00B95768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1500, ????);     
        label_1:
        // 0x00B9576C: LDR x20, [x20, #0x40]      | X20 = this._aniJsc._boss; //P2          
        // 0x00B95770: CBNZ x20, #0xb95778        | if (this._aniJsc._boss != null) goto label_2;
        if(this._aniJsc._boss != null)
        {
            goto label_2;
        }
        // 0x00B95774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1500, ????);     
        label_2:
        // 0x00B95778: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B9577C: LDR x8, [x8, #0x8d8]       | X8 = 1152921514484116640;               
        // 0x00B95780: MOV x0, x20                | X0 = this._aniJsc._boss;//m1            
        // 0x00B95784: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<AnimationPointJSC>::get_Count();
        // 0x00B95788: BL #0x25ed72c              | X0 = this._aniJsc._boss.get_Count();    
        int val_1 = this._aniJsc._boss.Count;
        // 0x00B9578C: CMP w21, w0                | STATE = COMPARE(this._bosPointIndex, val_1)
        // 0x00B95790: B.GE #0xb9605c             | if (this._bosPointIndex >= val_1) goto label_3;
        if(this._bosPointIndex >= val_1)
        {
            goto label_3;
        }
        // 0x00B95794: LDR x20, [x19, #0x80]      | X20 = this._aniJsc; //P2                
        // 0x00B95798: CBNZ x20, #0xb957a0        | if (this._aniJsc != null) goto label_4; 
        if(this._aniJsc != null)
        {
            goto label_4;
        }
        // 0x00B9579C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B957A0: LDR x20, [x20, #0x40]      | X20 = this._aniJsc._boss; //P2          
        // 0x00B957A4: LDR w21, [x19, #0x8c]      | W21 = this._bosPointIndex; //P2         
        // 0x00B957A8: CBNZ x20, #0xb957b0        | if (this._aniJsc._boss != null) goto label_5;
        if(this._aniJsc._boss != null)
        {
            goto label_5;
        }
        // 0x00B957AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B957B0: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x00B957B4: LDR x8, [x8, #0x438]       | X8 = 1152921514484125856;               
        // 0x00B957B8: MOV x0, x20                | X0 = this._aniJsc._boss;//m1            
        // 0x00B957BC: MOV w1, w21                | W1 = this._bosPointIndex;//m1           
        // 0x00B957C0: LDR x2, [x8]               | X2 = public AnimationPointJSC System.Collections.Generic.List<AnimationPointJSC>::get_Item(int index);
        // 0x00B957C4: BL #0x25ed734              | X0 = this._aniJsc._boss.get_Item(index:  this._bosPointIndex);
        AnimationPointJSC val_2 = this._aniJsc._boss.Item[this._bosPointIndex];
        // 0x00B957C8: LDR x20, [x19, #0x28]      | X20 = this.Targer; //P2                 
        // 0x00B957CC: STR x0, [x19, #0xa0]       | this._curBosAni = val_2;                 //  dest_result_addr=1152921514484684240
        this._curBosAni = val_2;
        // 0x00B957D0: CBNZ x20, #0xb957d8        | if (this.Targer != null) goto label_6;  
        if(this.Targer != null)
        {
            goto label_6;
        }
        // 0x00B957D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B957D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B957DC: MOV x0, x20                | X0 = this.Targer;//m1                   
        // 0x00B957E0: BL #0x1a635bc              | X0 = this.Targer.get_gameObject();      
        UnityEngine.GameObject val_3 = this.Targer.gameObject;
        // 0x00B957E4: ADRP x26, #0x3630000       | X26 = 56819712 (0x3630000);             
        // 0x00B957E8: LDR x26, [x26, #0x3d0]     | X26 = 1152921504954501264;              
        // 0x00B957EC: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B957F0: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00B957F4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B957F8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B957FC: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
        // 0x00B95800: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95804: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B95808: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B9580C: CBNZ x21, #0xb95814        | if ( != null) goto label_7;             
        if(null != null)
        {
            goto label_7;
        }
        // 0x00B95810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_7:
        // 0x00B95814: ADRP x22, #0x35b8000       | X22 = 56328192 (0x35B8000);             
        // 0x00B95818: LDR x22, [x22, #0x3a0]     | X22 = (string**)(1152921511315277136)("position");
        // 0x00B9581C: LDR x0, [x22]              | X0 = "position";                        
        // 0x00B95820: CBZ x0, #0xb95840          | if ("position" == null) goto label_9;   
        // 0x00B95824: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95828: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B9582C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "position", ????); 
        // 0x00B95830: CBNZ x0, #0xb95840         | if ("position" != null) goto label_9;   
        if("position" != null)
        {
            goto label_9;
        }
        // 0x00B95834: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "position", ????); 
        // 0x00B95838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9583C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "position", ????); 
        label_9:
        // 0x00B95840: LDR x22, [x22]             | X22 = "position";                       
        // 0x00B95844: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95848: CBNZ w8, #0xb95858         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_10;
        // 0x00B9584C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "position", ????); 
        // 0x00B95850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95854: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "position", ????); 
        label_10:
        // 0x00B95858: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "position";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "position";
        // 0x00B9585C: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B95860: CBNZ x22, #0xb95868        | if (this._curBosAni != null) goto label_11;
        if(this._curBosAni != null)
        {
            goto label_11;
        }
        // 0x00B95864: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "position", ????); 
        label_11:
        // 0x00B95868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9586C: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B95870: BL #0xb27adc               | X0 = this._curBosAni.get_Pos();         
        UnityEngine.Vector3 val_4 = this._curBosAni.Pos;
        // 0x00B95874: ADRP x27, #0x3673000       | X27 = 57094144 (0x3673000);             
        // 0x00B95878: LDR x27, [x27, #0x488]     | X27 = 1152921504695078912;              
        // 0x00B9587C: ADD x1, sp, #0x20          | X1 = (1152921514484671920 + 32) = 1152921514484671952 (0x100000024CC3A5D0);
        // 0x00B95880: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B95884: STP s0, s1, [sp, #0x20]    | stack[1152921514484671952] = val_4.x;  stack[1152921514484671956] = val_4.y;  //  dest_result_addr=1152921514484671952 |  dest_result_addr=1152921514484671956
        // 0x00B95888: STR s2, [sp, #0x28]        | stack[1152921514484671960] = val_4.z;    //  dest_result_addr=1152921514484671960
        // 0x00B9588C: BL #0x27bc028              | X0 = 1152921514484749872 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_4);
        // 0x00B95890: MOV x22, x0                | X22 = 1152921514484749872 (0x100000024CC4D630);//ML01
        // 0x00B95894: CBZ x22, #0xb958b8         | if (val_4 == 0) goto label_13;          
        if(val_4 == 0)
        {
            goto label_13;
        }
        // 0x00B95898: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B9589C: MOV x0, x22                | X0 = 1152921514484749872 (0x100000024CC4D630);//ML01
        // 0x00B958A0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B958A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x00B958A8: CBNZ x0, #0xb958b8         | if (val_4 != 0) goto label_13;          
        if(val_4 != 0)
        {
            goto label_13;
        }
        // 0x00B958AC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
        // 0x00B958B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B958B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_13:
        // 0x00B958B8: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B958BC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B958C0: B.HI #0xb958d0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_14;
        // 0x00B958C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B958C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B958CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_14:
        // 0x00B958D0: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_4;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_4;
        // 0x00B958D4: ADRP x24, #0x360c000       | X24 = 56672256 (0x360C000);             
        // 0x00B958D8: LDR x24, [x24, #0x728]     | X24 = (string**)(1152921510122312064)("time");
        // 0x00B958DC: LDR x0, [x24]              | X0 = "time";                            
        // 0x00B958E0: CBZ x0, #0xb95900          | if ("time" == null) goto label_16;      
        // 0x00B958E4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B958E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B958EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00B958F0: CBNZ x0, #0xb95900         | if ("time" != null) goto label_16;      
        if("time" != null)
        {
            goto label_16;
        }
        // 0x00B958F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00B958F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B958FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_16:
        // 0x00B95900: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95904: LDR x22, [x24]             | X22 = "time";                           
        // 0x00B95908: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B9590C: B.HI #0xb9591c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_17;
        // 0x00B95910: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00B95914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95918: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_17:
        // 0x00B9591C: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00B95920: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B95924: CBNZ x22, #0xb9592c        | if (this._curBosAni != null) goto label_18;
        if(this._curBosAni != null)
        {
            goto label_18;
        }
        // 0x00B95928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_18:
        // 0x00B9592C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95930: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B95934: BL #0xb27c38               | X0 = this._curBosAni.get_time();        
        float val_5 = this._curBosAni.time;
        // 0x00B95938: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
        // 0x00B9593C: LDR x23, [x23, #0xce8]     | X23 = 1152921504608444416;              
        // 0x00B95940: ADD x1, sp, #0x1c          | X1 = (1152921514484671920 + 28) = 1152921514484671948 (0x100000024CC3A5CC);
        // 0x00B95944: STR s0, [sp, #0x1c]        | stack[1152921514484671948] = val_5;      //  dest_result_addr=1152921514484671948
        // 0x00B95948: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B9594C: BL #0x27bc028              | X0 = 1152921514484758064 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_5);
        // 0x00B95950: MOV x22, x0                | X22 = 1152921514484758064 (0x100000024CC4F630);//ML01
        // 0x00B95954: CBZ x22, #0xb95978         | if (val_5 == 0) goto label_20;          
        if(val_5 == 0)
        {
            goto label_20;
        }
        // 0x00B95958: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B9595C: MOV x0, x22                | X0 = 1152921514484758064 (0x100000024CC4F630);//ML01
        // 0x00B95960: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95964: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
        // 0x00B95968: CBNZ x0, #0xb95978         | if (val_5 != 0) goto label_20;          
        if(val_5 != 0)
        {
            goto label_20;
        }
        // 0x00B9596C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
        // 0x00B95970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95974: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_20:
        // 0x00B95978: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B9597C: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B95980: B.HI #0xb95990             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_21;
        // 0x00B95984: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
        // 0x00B95988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9598C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        label_21:
        // 0x00B95990: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = val_5; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = val_5;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B95994: ADRP x25, #0x3635000       | X25 = 56840192 (0x3635000);             
        // 0x00B95998: LDR x25, [x25, #0x3d8]     | X25 = (string**)(1152921511388387856)("delay");
        // 0x00B9599C: LDR x0, [x25]              | X0 = "delay";                           
        // 0x00B959A0: CBZ x0, #0xb959c0          | if ("delay" == null) goto label_23;     
        // 0x00B959A4: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B959A8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B959AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "delay", ????);    
        // 0x00B959B0: CBNZ x0, #0xb959c0         | if ("delay" != null) goto label_23;     
        if("delay" != null)
        {
            goto label_23;
        }
        // 0x00B959B4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "delay", ????);    
        // 0x00B959B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B959BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_23:
        // 0x00B959C0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B959C4: LDR x22, [x25]             | X22 = "delay";                          
        // 0x00B959C8: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B959CC: B.HI #0xb959dc             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_24;
        // 0x00B959D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "delay", ????);    
        // 0x00B959D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B959D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_24:
        // 0x00B959DC: STR x22, [x21, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";
        // 0x00B959E0: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B959E4: CBNZ x22, #0xb959ec        | if (this._curBosAni != null) goto label_25;
        if(this._curBosAni != null)
        {
            goto label_25;
        }
        // 0x00B959E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "delay", ????);    
        label_25:
        // 0x00B959EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B959F0: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B959F4: BL #0xb27c28               | X0 = this._curBosAni.get_delay();       
        float val_6 = this._curBosAni.delay;
        // 0x00B959F8: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B959FC: ADD x1, sp, #0x18          | X1 = (1152921514484671920 + 24) = 1152921514484671944 (0x100000024CC3A5C8);
        // 0x00B95A00: STR s0, [sp, #0x18]        | stack[1152921514484671944] = val_6;      //  dest_result_addr=1152921514484671944
        // 0x00B95A04: BL #0x27bc028              | X0 = 1152921514484766256 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_6);
        // 0x00B95A08: MOV x22, x0                | X22 = 1152921514484766256 (0x100000024CC51630);//ML01
        // 0x00B95A0C: CBZ x22, #0xb95a30         | if (val_6 == 0) goto label_27;          
        if(val_6 == 0)
        {
            goto label_27;
        }
        // 0x00B95A10: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95A14: MOV x0, x22                | X0 = 1152921514484766256 (0x100000024CC51630);//ML01
        // 0x00B95A18: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95A1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
        // 0x00B95A20: CBNZ x0, #0xb95a30         | if (val_6 != 0) goto label_27;          
        if(val_6 != 0)
        {
            goto label_27;
        }
        // 0x00B95A24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
        // 0x00B95A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95A2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_27:
        // 0x00B95A30: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95A34: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B95A38: B.HI #0xb95a48             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_28;
        // 0x00B95A3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B95A40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95A44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_28:
        // 0x00B95A48: STR x22, [x21, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = val_6; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
        typeof(System.Object[]).__il2cppRuntimeField_48 = val_6;
        typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
        // 0x00B95A4C: ADRP x22, #0x3617000       | X22 = 56717312 (0x3617000);             
        // 0x00B95A50: LDR x22, [x22, #0x9e0]     | X22 = (string**)(1152921513637036544)("easetype");
        // 0x00B95A54: LDR x0, [x22]              | X0 = "easetype";                        
        // 0x00B95A58: CBZ x0, #0xb95a78          | if ("easetype" == null) goto label_30;  
        // 0x00B95A5C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95A60: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95A64: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "easetype", ????); 
        // 0x00B95A68: CBNZ x0, #0xb95a78         | if ("easetype" != null) goto label_30;  
        if("easetype" != null)
        {
            goto label_30;
        }
        // 0x00B95A6C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "easetype", ????); 
        // 0x00B95A70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95A74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "easetype", ????); 
        label_30:
        // 0x00B95A78: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95A7C: LDR x22, [x22]             | X22 = "easetype";                       
        // 0x00B95A80: CMP w8, #6                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x6)
        // 0x00B95A84: B.HI #0xb95a94             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x6) goto label_31;
        // 0x00B95A88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "easetype", ????); 
        // 0x00B95A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95A90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "easetype", ????); 
        label_31:
        // 0x00B95A94: STR x22, [x21, #0x50]      | typeof(System.Object[]).__il2cppRuntimeField_50 = "easetype";  //  dest_result_addr=1152921504954501344
        typeof(System.Object[]).__il2cppRuntimeField_50 = "easetype";
        // 0x00B95A98: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B95A9C: LDR x8, [x8, #0x8b0]       | X8 = 1152921504856899584;               
        // 0x00B95AA0: ADD x1, sp, #0x14          | X1 = (1152921514484671920 + 20) = 1152921514484671940 (0x100000024CC3A5C4);
        // 0x00B95AA4: LDR x0, [x8]               | X0 = typeof(iTween.EaseType);           
        // 0x00B95AA8: MOVZ w8, #0x15             | W8 = 21 (0x15);//ML01                   
        // 0x00B95AAC: STR w8, [sp, #0x14]        | stack[1152921514484671940] = 0x15;       //  dest_result_addr=1152921514484671940
        // 0x00B95AB0: BL #0x27bc028              | X0 = 1152921514484770352 = (Il2CppObject*)Box((RuntimeClass*)typeof(iTween.EaseType), 0x15);
        // 0x00B95AB4: MOV x22, x0                | X22 = 1152921514484770352 (0x100000024CC52630);//ML01
        // 0x00B95AB8: CBZ x22, #0xb95adc         | if (0x15 == 0) goto label_33;           
        if(21 == 0)
        {
            goto label_33;
        }
        // 0x00B95ABC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95AC0: MOV x0, x22                | X0 = 1152921514484770352 (0x100000024CC52630);//ML01
        // 0x00B95AC4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95AC8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x15, ????);       
        // 0x00B95ACC: CBNZ x0, #0xb95adc         | if (0x15 != 0) goto label_33;           
        if(21 != 0)
        {
            goto label_33;
        }
        // 0x00B95AD0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x15, ????);       
        // 0x00B95AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95AD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x15, ????);       
        label_33:
        // 0x00B95ADC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95AE0: CMP w8, #7                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x7)
        // 0x00B95AE4: B.HI #0xb95af4             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x7) goto label_34;
        // 0x00B95AE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x15, ????);       
        // 0x00B95AEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95AF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x15, ????);       
        label_34:
        // 0x00B95AF4: STR x22, [x21, #0x58]      | typeof(System.Object[]).__il2cppRuntimeField_58 = 0x15;  //  dest_result_addr=1152921504954501352
        typeof(System.Object[]).__il2cppRuntimeField_58 = 21;
        // 0x00B95AF8: ADRP x22, #0x3637000       | X22 = 56848384 (0x3637000);             
        // 0x00B95AFC: LDR x22, [x22, #0x310]     | X22 = (string**)(1152921513683558096)("oncomplete");
        // 0x00B95B00: LDR x0, [x22]              | X0 = "oncomplete";                      
        // 0x00B95B04: CBZ x0, #0xb95b24          | if ("oncomplete" == null) goto label_36;
        // 0x00B95B08: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95B0C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95B10: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "oncomplete", ????);
        // 0x00B95B14: CBNZ x0, #0xb95b24         | if ("oncomplete" != null) goto label_36;
        if("oncomplete" != null)
        {
            goto label_36;
        }
        // 0x00B95B18: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "oncomplete", ????);
        // 0x00B95B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95B20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncomplete", ????);
        label_36:
        // 0x00B95B24: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95B28: LDR x22, [x22]             | X22 = "oncomplete";                     
        // 0x00B95B2C: CMP w8, #8                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x8)
        // 0x00B95B30: B.HI #0xb95b40             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x8) goto label_37;
        // 0x00B95B34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "oncomplete", ????);
        // 0x00B95B38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95B3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncomplete", ????);
        label_37:
        // 0x00B95B40: STR x22, [x21, #0x60]      | typeof(System.Object[]).__il2cppRuntimeField_60 = "oncomplete";  //  dest_result_addr=1152921504954501360
        typeof(System.Object[]).__il2cppRuntimeField_60 = "oncomplete";
        // 0x00B95B44: ADRP x22, #0x3667000       | X22 = 57044992 (0x3667000);             
        // 0x00B95B48: LDR x22, [x22, #0x2e0]     | X22 = (string**)(1152921514484582144)("UpdateBossAnimation");
        // 0x00B95B4C: LDR x0, [x22]              | X0 = "UpdateBossAnimation";             
        // 0x00B95B50: CBZ x0, #0xb95b70          | if ("UpdateBossAnimation" == null) goto label_39;
        // 0x00B95B54: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95B58: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95B5C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "UpdateBossAnimation", ????);
        // 0x00B95B60: CBNZ x0, #0xb95b70         | if ("UpdateBossAnimation" != null) goto label_39;
        if("UpdateBossAnimation" != null)
        {
            goto label_39;
        }
        // 0x00B95B64: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "UpdateBossAnimation", ????);
        // 0x00B95B68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95B6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UpdateBossAnimation", ????);
        label_39:
        // 0x00B95B70: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95B74: LDR x22, [x22]             | X22 = "UpdateBossAnimation";            
        // 0x00B95B78: CMP w8, #9                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x9)
        // 0x00B95B7C: B.HI #0xb95b8c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x9) goto label_40;
        // 0x00B95B80: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "UpdateBossAnimation", ????);
        // 0x00B95B84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95B88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "UpdateBossAnimation", ????);
        label_40:
        // 0x00B95B8C: STR x22, [x21, #0x68]      | typeof(System.Object[]).__il2cppRuntimeField_68 = "UpdateBossAnimation";  //  dest_result_addr=1152921504954501368
        typeof(System.Object[]).__il2cppRuntimeField_68 = "UpdateBossAnimation";
        // 0x00B95B90: ADRP x22, #0x35f0000       | X22 = 56557568 (0x35F0000);             
        // 0x00B95B94: LDR x22, [x22, #0x9e8]     | X22 = (string**)(1152921514484206864)("oncompletetarget");
        // 0x00B95B98: LDR x0, [x22]              | X0 = "oncompletetarget";                
        // 0x00B95B9C: CBZ x0, #0xb95bbc          | if ("oncompletetarget" == null) goto label_42;
        // 0x00B95BA0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95BA4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95BA8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "oncompletetarget", ????);
        // 0x00B95BAC: CBNZ x0, #0xb95bbc         | if ("oncompletetarget" != null) goto label_42;
        if("oncompletetarget" != null)
        {
            goto label_42;
        }
        // 0x00B95BB0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "oncompletetarget", ????);
        // 0x00B95BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95BB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncompletetarget", ????);
        label_42:
        // 0x00B95BBC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95BC0: LDR x22, [x22]             | X22 = "oncompletetarget";               
        // 0x00B95BC4: CMP w8, #0xa               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xA)
        // 0x00B95BC8: B.HI #0xb95bd8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xA) goto label_43;
        // 0x00B95BCC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "oncompletetarget", ????);
        // 0x00B95BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95BD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "oncompletetarget", ????);
        label_43:
        // 0x00B95BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95BDC: MOV x0, x19                | X0 = 1152921514484684080 (0x100000024CC3D530);//ML01
        // 0x00B95BE0: STR x22, [x21, #0x70]      | typeof(System.Object[]).__il2cppRuntimeField_70 = "oncompletetarget";  //  dest_result_addr=1152921504954501376
        typeof(System.Object[]).__il2cppRuntimeField_70 = "oncompletetarget";
        // 0x00B95BE4: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_7 = this.gameObject;
        // 0x00B95BE8: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00B95BEC: CBZ x22, #0xb95c10         | if (val_7 == null) goto label_45;       
        if(val_7 == null)
        {
            goto label_45;
        }
        // 0x00B95BF0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95BF4: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x00B95BF8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95BFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
        // 0x00B95C00: CBNZ x0, #0xb95c10         | if (val_7 != null) goto label_45;       
        if(val_7 != null)
        {
            goto label_45;
        }
        // 0x00B95C04: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
        // 0x00B95C08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95C0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_45:
        // 0x00B95C10: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95C14: CMP w8, #0xb               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xB)
        // 0x00B95C18: B.HI #0xb95c28             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xB) goto label_46;
        // 0x00B95C1C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00B95C20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95C24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_46:
        // 0x00B95C28: STR x22, [x21, #0x78]      | typeof(System.Object[]).__il2cppRuntimeField_78 = val_7;  //  dest_result_addr=1152921504954501384
        typeof(System.Object[]).__il2cppRuntimeField_78 = val_7;
        // 0x00B95C2C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B95C30: LDR x8, [x8, #0x178]       | X8 = 1152921504856739840;               
        // 0x00B95C34: LDR x0, [x8]               | X0 = typeof(iTween);                    
        // 0x00B95C38: LDRB w8, [x0, #0x10a]      | W8 = iTween.__il2cppRuntimeField_10A;   
        // 0x00B95C3C: TBZ w8, #0, #0xb95c4c      | if (iTween.__il2cppRuntimeField_has_cctor == 0) goto label_48;
        // 0x00B95C40: LDR w8, [x0, #0xbc]        | W8 = iTween.__il2cppRuntimeField_cctor_finished;
        // 0x00B95C44: CBNZ w8, #0xb95c4c         | if (iTween.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
        // 0x00B95C48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(iTween), ????);
        label_48:
        // 0x00B95C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B95C54: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95C58: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_8 = iTween.Hash(args:  0);
        // 0x00B95C5C: MOV x2, x0                 | X2 = val_8;//m1                         
        // 0x00B95C60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95C64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B95C68: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00B95C6C: BL #0x17c41b0              | iTween.MoveTo(target:  0, args:  val_3);
        iTween.MoveTo(target:  0, args:  val_3);
        // 0x00B95C70: LDR x20, [x19, #0x28]      | X20 = this.Targer; //P2                 
        // 0x00B95C74: CBNZ x20, #0xb95c7c        | if (this.Targer != null) goto label_49; 
        if(this.Targer != null)
        {
            goto label_49;
        }
        // 0x00B95C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_49:
        // 0x00B95C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95C80: MOV x0, x20                | X0 = this.Targer;//m1                   
        // 0x00B95C84: BL #0x1a635bc              | X0 = this.Targer.get_gameObject();      
        UnityEngine.GameObject val_9 = this.Targer.gameObject;
        // 0x00B95C88: LDR x21, [x26]             | X21 = typeof(System.Object[]);          
        // 0x00B95C8C: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B95C90: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95C94: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B95C98: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00B95C9C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95CA0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B95CA4: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95CA8: CBNZ x21, #0xb95cb0        | if ( != null) goto label_50;            
        if(null != null)
        {
            goto label_50;
        }
        // 0x00B95CAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_50:
        // 0x00B95CB0: ADRP x22, #0x3610000       | X22 = 56688640 (0x3610000);             
        // 0x00B95CB4: LDR x22, [x22, #0x858]     | X22 = (string**)(1152921512527230304)("rotation");
        // 0x00B95CB8: LDR x0, [x22]              | X0 = "rotation";                        
        // 0x00B95CBC: CBZ x0, #0xb95cdc          | if ("rotation" == null) goto label_52;  
        // 0x00B95CC0: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95CC4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95CC8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "rotation", ????); 
        // 0x00B95CCC: CBNZ x0, #0xb95cdc         | if ("rotation" != null) goto label_52;  
        if("rotation" != null)
        {
            goto label_52;
        }
        // 0x00B95CD0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "rotation", ????); 
        // 0x00B95CD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95CD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "rotation", ????); 
        label_52:
        // 0x00B95CDC: LDR x22, [x22]             | X22 = "rotation";                       
        // 0x00B95CE0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95CE4: CBNZ w8, #0xb95cf4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_53;
        // 0x00B95CE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "rotation", ????); 
        // 0x00B95CEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95CF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "rotation", ????); 
        label_53:
        // 0x00B95CF4: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "rotation";  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = "rotation";
        // 0x00B95CF8: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B95CFC: CBNZ x22, #0xb95d04        | if (this._curBosAni != null) goto label_54;
        if(this._curBosAni != null)
        {
            goto label_54;
        }
        // 0x00B95D00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "rotation", ????); 
        label_54:
        // 0x00B95D04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95D08: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B95D0C: BL #0xb27b30               | X0 = this._curBosAni.get_Rot();         
        UnityEngine.Vector3 val_10 = this._curBosAni.Rot;
        // 0x00B95D10: LDR x0, [x27]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B95D14: ADD x1, sp, #8             | X1 = (1152921514484671920 + 8) = 1152921514484671928 (0x100000024CC3A5B8);
        // 0x00B95D18: STP s0, s1, [sp, #8]       | stack[1152921514484671928] = val_10.x;  stack[1152921514484671932] = val_10.y;  //  dest_result_addr=1152921514484671928 |  dest_result_addr=1152921514484671932
        // 0x00B95D1C: STR s2, [sp, #0x10]        | stack[1152921514484671936] = val_10.z;   //  dest_result_addr=1152921514484671936
        // 0x00B95D20: BL #0x27bc028              | X0 = 1152921514484795952 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_10);
        // 0x00B95D24: MOV x22, x0                | X22 = 1152921514484795952 (0x100000024CC58A30);//ML01
        // 0x00B95D28: CBZ x22, #0xb95d4c         | if (val_10 == 0) goto label_56;         
        if(val_10 == 0)
        {
            goto label_56;
        }
        // 0x00B95D2C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95D30: MOV x0, x22                | X0 = 1152921514484795952 (0x100000024CC58A30);//ML01
        // 0x00B95D34: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95D38: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
        // 0x00B95D3C: CBNZ x0, #0xb95d4c         | if (val_10 != 0) goto label_56;         
        if(val_10 != 0)
        {
            goto label_56;
        }
        // 0x00B95D40: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
        // 0x00B95D44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95D48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
        label_56:
        // 0x00B95D4C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95D50: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B95D54: B.HI #0xb95d64             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_57;
        // 0x00B95D58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
        // 0x00B95D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95D60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
        label_57:
        // 0x00B95D64: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_10;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_10;
        // 0x00B95D68: LDR x0, [x24]              | X0 = "time";                            
        // 0x00B95D6C: CBZ x0, #0xb95d8c          | if ("time" == null) goto label_59;      
        // 0x00B95D70: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95D74: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95D78: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "time", ????);     
        // 0x00B95D7C: CBNZ x0, #0xb95d8c         | if ("time" != null) goto label_59;      
        if("time" != null)
        {
            goto label_59;
        }
        // 0x00B95D80: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "time", ????);     
        // 0x00B95D84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95D88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_59:
        // 0x00B95D8C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95D90: LDR x22, [x24]             | X22 = "time";                           
        // 0x00B95D94: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B95D98: B.HI #0xb95da8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_60;
        // 0x00B95D9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "time", ????);     
        // 0x00B95DA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95DA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "time", ????);     
        label_60:
        // 0x00B95DA8: STR x22, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "time";  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = "time";
        // 0x00B95DAC: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B95DB0: CBNZ x22, #0xb95db8        | if (this._curBosAni != null) goto label_61;
        if(this._curBosAni != null)
        {
            goto label_61;
        }
        // 0x00B95DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "time", ????);     
        label_61:
        // 0x00B95DB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95DBC: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B95DC0: BL #0xb27c38               | X0 = this._curBosAni.get_time();        
        float val_11 = this._curBosAni.time;
        // 0x00B95DC4: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B95DC8: ADD x1, sp, #4             | X1 = (1152921514484671920 + 4) = 1152921514484671924 (0x100000024CC3A5B4);
        // 0x00B95DCC: STR s0, [sp, #4]           | stack[1152921514484671924] = val_11;     //  dest_result_addr=1152921514484671924
        // 0x00B95DD0: BL #0x27bc028              | X0 = 1152921514484804144 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_11);
        // 0x00B95DD4: MOV x22, x0                | X22 = 1152921514484804144 (0x100000024CC5AA30);//ML01
        // 0x00B95DD8: CBZ x22, #0xb95dfc         | if (val_11 == 0) goto label_63;         
        if(val_11 == 0)
        {
            goto label_63;
        }
        // 0x00B95DDC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95DE0: MOV x0, x22                | X0 = 1152921514484804144 (0x100000024CC5AA30);//ML01
        // 0x00B95DE4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95DE8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
        // 0x00B95DEC: CBNZ x0, #0xb95dfc         | if (val_11 != 0) goto label_63;         
        if(val_11 != 0)
        {
            goto label_63;
        }
        // 0x00B95DF0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
        // 0x00B95DF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95DF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_63:
        // 0x00B95DFC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95E00: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B95E04: B.HI #0xb95e14             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_64;
        // 0x00B95E08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
        // 0x00B95E0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95E10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_64:
        // 0x00B95E14: STR x22, [x21, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = val_11; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = val_11;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B95E18: LDR x0, [x25]              | X0 = "delay";                           
        // 0x00B95E1C: CBZ x0, #0xb95e3c          | if ("delay" == null) goto label_66;     
        // 0x00B95E20: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95E24: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95E28: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "delay", ????);    
        // 0x00B95E2C: CBNZ x0, #0xb95e3c         | if ("delay" != null) goto label_66;     
        if("delay" != null)
        {
            goto label_66;
        }
        // 0x00B95E30: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "delay", ????);    
        // 0x00B95E34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95E38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_66:
        // 0x00B95E3C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95E40: LDR x22, [x25]             | X22 = "delay";                          
        // 0x00B95E44: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B95E48: B.HI #0xb95e58             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_67;
        // 0x00B95E4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "delay", ????);    
        // 0x00B95E50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95E54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "delay", ????);    
        label_67:
        // 0x00B95E58: STR x22, [x21, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";  //  dest_result_addr=1152921504954501328
        typeof(System.Object[]).__il2cppRuntimeField_40 = "delay";
        // 0x00B95E5C: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B95E60: CBNZ x22, #0xb95e68        | if (this._curBosAni != null) goto label_68;
        if(this._curBosAni != null)
        {
            goto label_68;
        }
        // 0x00B95E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "delay", ????);    
        label_68:
        // 0x00B95E68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95E6C: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B95E70: BL #0xb27c28               | X0 = this._curBosAni.get_delay();       
        float val_12 = this._curBosAni.delay;
        // 0x00B95E74: LDR x0, [x23]              | X0 = typeof(System.Single);             
        // 0x00B95E78: MOV x1, sp                 | X1 = 1152921514484671920 (0x100000024CC3A5B0);//ML01
        // 0x00B95E7C: STR s0, [sp]               | stack[1152921514484671920] = val_12;     //  dest_result_addr=1152921514484671920
        // 0x00B95E80: BL #0x27bc028              | X0 = 1152921514484812336 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), val_12);
        // 0x00B95E84: MOV x22, x0                | X22 = 1152921514484812336 (0x100000024CC5CA30);//ML01
        // 0x00B95E88: CBZ x22, #0xb95eac         | if (val_12 == 0) goto label_70;         
        if(val_12 == 0)
        {
            goto label_70;
        }
        // 0x00B95E8C: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B95E90: MOV x0, x22                | X0 = 1152921514484812336 (0x100000024CC5CA30);//ML01
        // 0x00B95E94: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B95E98: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
        // 0x00B95E9C: CBNZ x0, #0xb95eac         | if (val_12 != 0) goto label_70;         
        if(val_12 != 0)
        {
            goto label_70;
        }
        // 0x00B95EA0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
        // 0x00B95EA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95EA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_70:
        // 0x00B95EAC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B95EB0: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B95EB4: B.HI #0xb95ec4             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_71;
        // 0x00B95EB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
        // 0x00B95EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95EC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
        label_71:
        // 0x00B95EC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95EC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B95ECC: MOV x1, x21                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B95ED0: STR x22, [x21, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = val_12; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
        typeof(System.Object[]).__il2cppRuntimeField_48 = val_12;
        typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
        // 0x00B95ED4: BL #0x17be770              | X0 = iTween.Hash(args:  0);             
        System.Collections.Hashtable val_13 = iTween.Hash(args:  0);
        // 0x00B95ED8: MOV x2, x0                 | X2 = val_13;//m1                        
        // 0x00B95EDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95EE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B95EE4: MOV x1, x20                | X1 = val_9;//m1                         
        // 0x00B95EE8: BL #0x17c7120              | iTween.RotateTo(target:  0, args:  val_9);
        iTween.RotateTo(target:  0, args:  val_9);
        // 0x00B95EEC: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B95EF0: LDR x21, [x19, #0xa0]      | X21 = this._curBosAni; //P2             
        // 0x00B95EF4: CBNZ x21, #0xb95efc        | if (this._curBosAni != null) goto label_72;
        if(this._curBosAni != null)
        {
            goto label_72;
        }
        // 0x00B95EF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_72:
        // 0x00B95EFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95F00: MOV x0, x21                | X0 = this._curBosAni;//m1               
        // 0x00B95F04: BL #0xb27c28               | X0 = this._curBosAni.get_delay();       
        float val_14 = this._curBosAni.delay;
        // 0x00B95F08: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00B95F0C: ADRP x9, #0x35f7000        | X9 = 56586240 (0x35F7000);              
        // 0x00B95F10: LDR x8, [x8, #0x8d8]       | X8 = 1152921514484636528;               
        // 0x00B95F14: LDR x9, [x9, #0xa40]       | X9 = 1152921504687890432;               
        // 0x00B95F18: MOV v8.16b, v0.16b         | V8 = val_14;//m1                        
        // 0x00B95F1C: LDR x22, [x8]              | X22 = System.Void BossAnimationMgr::<UpdateBossAnimation>m__0(string aniType, float aniTime);
        // 0x00B95F20: LDR x0, [x9]               | X0 = typeof(System.Action<T1, T2>);     
        System.Action<System.String, System.Single> val_15 = null;
        // 0x00B95F24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action<T1, T2>), ????);
        // 0x00B95F28: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00B95F2C: LDR x8, [x8, #0xb0]        | X8 = 1152921514484637552;               
        // 0x00B95F30: MOV x1, x19                | X1 = 1152921514484684080 (0x100000024CC3D530);//ML01
        // 0x00B95F34: MOV x2, x22                | X2 = 1152921514484636528 (0x100000024CC31B70);//ML01
        // 0x00B95F38: MOV x21, x0                | X21 = 1152921504687890432 (0x1000000004D4A000);//ML01
        // 0x00B95F3C: LDR x3, [x8]               | X3 = public System.Void System.Action<System.String, System.Single>::.ctor(object object, IntPtr method);
        // 0x00B95F40: BL #0x12a3508              | .ctor(object:  this, method:  System.Void BossAnimationMgr::<UpdateBossAnimation>m__0(string aniType, float aniTime));
        val_15 = new System.Action<System.String, System.Single>(object:  this, method:  System.Void BossAnimationMgr::<UpdateBossAnimation>m__0(string aniType, float aniTime));
        // 0x00B95F44: LDR x22, [x19, #0xa0]      | X22 = this._curBosAni; //P2             
        // 0x00B95F48: CBNZ x22, #0xb95f50        | if (this._curBosAni != null) goto label_73;
        if(this._curBosAni != null)
        {
            goto label_73;
        }
        // 0x00B95F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void BossAnimationMgr::<UpdateBossAnimation>m__0(string aniType, float aniTime)), ????);
        label_73:
        // 0x00B95F50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95F54: MOV x0, x22                | X0 = this._curBosAni;//m1               
        // 0x00B95F58: BL #0xb27bd8               | X0 = this._curBosAni.get_aniType();     
        string val_16 = this._curBosAni.aniType;
        // 0x00B95F5C: LDR x23, [x19, #0xa0]      | X23 = this._curBosAni; //P2             
        // 0x00B95F60: MOV x22, x0                | X22 = val_16;//m1                       
        // 0x00B95F64: CBNZ x23, #0xb95f6c        | if (this._curBosAni != null) goto label_74;
        if(this._curBosAni != null)
        {
            goto label_74;
        }
        // 0x00B95F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_74:
        // 0x00B95F6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95F70: MOV x0, x23                | X0 = this._curBosAni;//m1               
        // 0x00B95F74: BL #0xb27be8               | X0 = this._curBosAni.get_aniTime();     
        float val_17 = this._curBosAni.aniTime;
        // 0x00B95F78: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B95F7C: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00B95F80: MOV v9.16b, v0.16b         | V9 = val_17;//m1                        
        // 0x00B95F84: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00B95F88: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B95F8C: TBZ w8, #0, #0xb95f9c      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_76;
        // 0x00B95F90: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B95F94: CBNZ w8, #0xb95f9c         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_76;
        // 0x00B95F98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_76:
        // 0x00B95F9C: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B95FA0: LDR x8, [x8, #0xf08]       | X8 = 1152921514484650864;               
        // 0x00B95FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B95FA8: MOV v0.16b, v8.16b         | V0 = val_14;//m1                        
        // 0x00B95FAC: MOV x1, x21                | X1 = 1152921504687890432 (0x1000000004D4A000);//ML01
        // 0x00B95FB0: LDR x3, [x8]               | X3 = public static System.UInt32 BehaviourUtil::DelayCall<System.String, System.Single>(float delaytime, System.Action<T1, T2> act, System.String arg1, System.Single arg2);
        // 0x00B95FB4: MOV x2, x22                | X2 = val_16;//m1                        
        // 0x00B95FB8: MOV v1.16b, v9.16b         | V1 = val_17;//m1                        
        // 0x00B95FBC: BL #0x10ceaec              | X0 = BehaviourUtil.DelayCall<System.Object, System.Single>(delaytime:  val_14, act:  0, arg1:  val_15, arg2:  val_17);
        uint val_18 = BehaviourUtil.DelayCall<System.Object, System.Single>(delaytime:  val_14, act:  0, arg1:  val_15, arg2:  val_17);
        // 0x00B95FC0: MOV w21, w0                | W21 = val_18;//m1                       
        // 0x00B95FC4: CBNZ x20, #0xb95fcc        | if (this._boss != null) goto label_77;  
        if(this._boss != null)
        {
            goto label_77;
        }
        // 0x00B95FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_77:
        // 0x00B95FCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B95FD0: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B95FD4: MOV w1, w21                | W1 = val_18;//m1                        
        // 0x00B95FD8: BL #0xd89e98               | this._boss.AddDelayId(id:  val_18);     
        this._boss.AddDelayId(id:  val_18);
        // 0x00B95FDC: LDR x20, [x19, #0xa0]      | X20 = this._curBosAni; //P2             
        // 0x00B95FE0: CBNZ x20, #0xb95fe8        | if (this._curBosAni != null) goto label_78;
        if(this._curBosAni != null)
        {
            goto label_78;
        }
        // 0x00B95FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._boss, ????); 
        label_78:
        // 0x00B95FE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B95FEC: MOV x0, x20                | X0 = this._curBosAni;//m1               
        // 0x00B95FF0: BL #0xb27c48               | X0 = this._curBosAni.get_fun();         
        string val_19 = this._curBosAni.fun;
        // 0x00B95FF4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B95FF8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B95FFC: MOV x20, x0                | X20 = val_19;//m1                       
        // 0x00B96000: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B96004: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B96008: TBZ w9, #0, #0xb9601c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_80;
        // 0x00B9600C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B96010: CBNZ w9, #0xb9601c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_80;
        // 0x00B96014: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B96018: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_80:
        // 0x00B9601C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B96020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96024: MOV x1, x20                | X1 = val_19;//m1                        
        // 0x00B96028: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_20 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B9602C: LDR w8, [x19, #0x8c]       | W8 = this._bosPointIndex; //P2          
        int val_21 = this._bosPointIndex;
        // 0x00B96030: ADD w8, w8, #1             | W8 = (this._bosPointIndex + 1);         
        val_21 = val_21 + 1;
        // 0x00B96034: STR w8, [x19, #0x8c]       | this._bosPointIndex = (this._bosPointIndex + 1);  //  dest_result_addr=1152921514484684220
        this._bosPointIndex = val_21;
        // 0x00B96038: SUB sp, x29, #0x60         | SP = (1152921514484672064 - 96) = 1152921514484671968 (0x100000024CC3A5E0);
        // 0x00B9603C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96040: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96044: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B96048: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B9604C: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B96050: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B96054: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B96058: RET                        |  return;                                
        return;
        label_3:
        // 0x00B9605C: STRB wzr, [x19, #0x91]     | this._isBosPlaying = false;              //  dest_result_addr=1152921514484684225
        this._isBosPlaying = false;
        // 0x00B96060: MOV x0, x19                | X0 = 1152921514484684080 (0x100000024CC3D530);//ML01
        // 0x00B96064: SUB sp, x29, #0x60         | SP = (1152921514484672064 - 96) = 1152921514484671968 (0x100000024CC3A5E0);
        // 0x00B96068: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9606C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96070: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B96074: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B96078: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B9607C: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B96080: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B96084: B #0xb968b0                | this.Boss3DShowEnd(); return;           
        this.Boss3DShowEnd();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B968B0 (12150960), len: 408  VirtAddr: 0x00B968B0 RVA: 0x00B968B0 token: 100690194 methodIndex: 25249 delegateWrapperIndex: 0 methodInvoker: 0
    private void Boss3DShowEnd()
    {
        //
        // Disasemble & Code
        // 0x00B968B0: STP x22, x21, [sp, #-0x30]! | stack[1152921514484955040] = ???;  stack[1152921514484955048] = ???;  //  dest_result_addr=1152921514484955040 |  dest_result_addr=1152921514484955048
        // 0x00B968B4: STP x20, x19, [sp, #0x10]  | stack[1152921514484955056] = ???;  stack[1152921514484955064] = ???;  //  dest_result_addr=1152921514484955056 |  dest_result_addr=1152921514484955064
        // 0x00B968B8: STP x29, x30, [sp, #0x20]  | stack[1152921514484955072] = ???;  stack[1152921514484955080] = ???;  //  dest_result_addr=1152921514484955072 |  dest_result_addr=1152921514484955080
        // 0x00B968BC: ADD x29, sp, #0x20         | X29 = (1152921514484955040 + 32) = 1152921514484955072 (0x100000024CC7F7C0);
        // 0x00B968C0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B968C4: LDRB w8, [x20, #0xa72]     | W8 = (bool)static_value_03733A72;       
        // 0x00B968C8: MOV x19, x0                | X19 = 1152921514484967088 (0x100000024CC826B0);//ML01
        // 0x00B968CC: TBNZ w8, #0, #0xb968e8     | if (static_value_03733A72 == true) goto label_0;
        // 0x00B968D0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B968D4: LDR x8, [x8, #0x10]        | X8 = 0x2B8F8CC;                         
        // 0x00B968D8: LDR w0, [x8]               | W0 = 0x14F7;                            
        // 0x00B968DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F7, ????);     
        // 0x00B968E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B968E4: STRB w8, [x20, #0xa72]     | static_value_03733A72 = true;            //  dest_result_addr=57883250
        label_0:
        // 0x00B968E8: LDRB w8, [x19, #0x19]      | W8 = this._isEditorPattern; //P2        
        // 0x00B968EC: CBNZ w8, #0xb96a38         | if (this._isEditorPattern == true) goto label_3;
        if(this._isEditorPattern == true)
        {
            goto label_3;
        }
        // 0x00B968F0: LDRH w8, [x19, #0x90]      | W8 = this._isCamPlaying; //P2           
        // 0x00B968F4: AND w9, w8, #0xff          | W9 = (this._isCamPlaying & 255);        
        bool val_1 = this._isCamPlaying & 255;
        // 0x00B968F8: CBNZ w9, #0xb96a38         | if ((this._isCamPlaying & 255) == true) goto label_3;
        if(val_1 == true)
        {
            goto label_3;
        }
        // 0x00B968FC: CMP w8, #0xff              | STATE = COMPARE(this._isCamPlaying, 0xFF)
        // 0x00B96900: B.HI #0xb96a38             | if (this._isCamPlaying > true) goto label_3;
        if(this._isCamPlaying > true)
        {
            goto label_3;
        }
        // 0x00B96904: LDR x20, [x19, #0x70]      | X20 = this._shaderShow; //P2            
        // 0x00B96908: CBNZ x20, #0xb96910        | if (this._shaderShow != null) goto label_4;
        if(this._shaderShow != null)
        {
            goto label_4;
        }
        // 0x00B9690C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14F7, ????);     
        label_4:
        // 0x00B96910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96914: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B96918: MOV x0, x20                | X0 = this._shaderShow;//m1              
        // 0x00B9691C: BL #0x20cb458              | this._shaderShow.set_enabled(value:  true);
        this._shaderShow.enabled = true;
        // 0x00B96920: LDR x20, [x19, #0x70]      | X20 = this._shaderShow; //P2            
        // 0x00B96924: CBNZ x20, #0xb9692c        | if (this._shaderShow != null) goto label_5;
        if(this._shaderShow != null)
        {
            goto label_5;
        }
        // 0x00B96928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._shaderShow, ????);
        label_5:
        // 0x00B9692C: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x00B96930: STR w8, [x20, #0x20]       | this._shaderShow.grayScaleAmount = 1;    //  dest_result_addr=0
        this._shaderShow.grayScaleAmount = 1f;
        // 0x00B96934: LDR x20, [x19, #0x40]      | X20 = this._boss; //P2                  
        // 0x00B96938: CBNZ x20, #0xb96940        | if (this._boss != null) goto label_6;   
        if(this._boss != null)
        {
            goto label_6;
        }
        // 0x00B9693C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._shaderShow, ????);
        label_6:
        // 0x00B96940: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B96944: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B96948: MOV x0, x20                | X0 = this._boss;//m1                    
        // 0x00B9694C: BL #0xd89f1c               | this._boss.set_isSkillFrozen(value:  true);
        this._boss.isSkillFrozen = true;
        // 0x00B96950: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B96954: LDR x21, [x19, #0x40]      | X21 = this._boss; //P2                  
        // 0x00B96958: CBNZ x21, #0xb96960        | if (this._boss != null) goto label_7;   
        if(this._boss != null)
        {
            goto label_7;
        }
        // 0x00B9695C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._boss, ????); 
        label_7:
        // 0x00B96960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96964: MOV x0, x21                | X0 = this._boss;//m1                    
        // 0x00B96968: BL #0xd89aac               | X0 = this._boss.get_bossshow();         
        string val_2 = this._boss.bossshow;
        // 0x00B9696C: LDR x22, [x19, #0x40]      | X22 = this._boss; //P2                  
        // 0x00B96970: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B96974: CBNZ x22, #0xb9697c        | if (this._boss != null) goto label_8;   
        if(this._boss != null)
        {
            goto label_8;
        }
        // 0x00B96978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B9697C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96980: MOV x0, x22                | X0 = this._boss;//m1                    
        // 0x00B96984: BL #0xd89e60               | X0 = this._boss.get_UINamePos();        
        int val_3 = this._boss.UINamePos;
        // 0x00B96988: MOV w22, w0                | W22 = val_3;//m1                        
        // 0x00B9698C: CBNZ x20, #0xb96994        | if (this._bossInfoShow != null) goto label_9;
        if(this._bossInfoShow != null)
        {
            goto label_9;
        }
        // 0x00B96990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00B96994: MOV x0, x20                | X0 = this._bossInfoShow;//m1            
        // 0x00B96998: MOV x1, x21                | X1 = val_2;//m1                         
        // 0x00B9699C: MOV w2, w22                | W2 = val_3;//m1                         
        // 0x00B969A0: BL #0xb96a48               | this._bossInfoShow.SetName(name:  val_2, type:  val_3);
        this._bossInfoShow.SetName(name:  val_2, type:  val_3);
        // 0x00B969A4: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B969A8: CBNZ x20, #0xb969b0        | if (this._bossInfoShow != null) goto label_10;
        if(this._bossInfoShow != null)
        {
            goto label_10;
        }
        // 0x00B969AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._bossInfoShow, ????);
        label_10:
        // 0x00B969B0: MOV x0, x20                | X0 = this._bossInfoShow;//m1            
        // 0x00B969B4: BL #0xb96b20               | this._bossInfoShow.Show();              
        this._bossInfoShow.Show();
        // 0x00B969B8: LDR x20, [x19, #0x78]      | X20 = this._bossInfoShow; //P2          
        // 0x00B969BC: CBNZ x20, #0xb969c4        | if (this._bossInfoShow != null) goto label_11;
        if(this._bossInfoShow != null)
        {
            goto label_11;
        }
        // 0x00B969C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._bossInfoShow, ????);
        label_11:
        // 0x00B969C4: MOV x0, x20                | X0 = this._bossInfoShow;//m1            
        // 0x00B969C8: BL #0xb96b58               | this._bossInfoShow.PlayForward();       
        this._bossInfoShow.PlayForward();
        // 0x00B969CC: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
        // 0x00B969D0: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B969D4: LDR x8, [x8, #0xed8]       | X8 = 1152921514484942064;               
        // 0x00B969D8: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B969DC: LDR x21, [x8]              | X21 = System.Void BossAnimationMgr::End();
        // 0x00B969E0: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_4 = null;
        // 0x00B969E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B969E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B969EC: MOV x1, x19                | X1 = 1152921514484967088 (0x100000024CC826B0);//ML01
        // 0x00B969F0: MOV x2, x21                | X2 = 1152921514484942064 (0x100000024CC7C4F0);//ML01
        // 0x00B969F4: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B969F8: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void BossAnimationMgr::End());
        val_4 = new System.Action(object:  this, method:  System.Void BossAnimationMgr::End());
        // 0x00B969FC: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B96A00: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00B96A04: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00B96A08: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B96A0C: TBZ w8, #0, #0xb96a1c      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B96A10: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B96A14: CBNZ w8, #0xb96a1c         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B96A18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_13:
        // 0x00B96A1C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B96A20: LDR s0, [x8, #0xd5c]       | S0 = 1.7;                               
        // 0x00B96A24: MOV x1, x20                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B96A28: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96A2C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96A30: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B96A34: B #0xb8e194                | X0 = BehaviourUtil.DelayCall(delaytime:  1.7f, act:  null); return;
        uint val_5 = BehaviourUtil.DelayCall(delaytime:  1.7f, act:  null);
        return;
        label_3:
        // 0x00B96A38: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96A3C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96A40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B96A44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96088 (12148872), len: 424  VirtAddr: 0x00B96088 RVA: 0x00B96088 token: 100690195 methodIndex: 25250 delegateWrapperIndex: 0 methodInvoker: 0
    private void GetBossEntity()
    {
        //
        // Disasemble & Code
        //  | 
        var val_10;
        // 0x00B96088: STP x24, x23, [sp, #-0x40]! | stack[1152921514485132560] = ???;  stack[1152921514485132568] = ???;  //  dest_result_addr=1152921514485132560 |  dest_result_addr=1152921514485132568
        // 0x00B9608C: STP x22, x21, [sp, #0x10]  | stack[1152921514485132576] = ???;  stack[1152921514485132584] = ???;  //  dest_result_addr=1152921514485132576 |  dest_result_addr=1152921514485132584
        // 0x00B96090: STP x20, x19, [sp, #0x20]  | stack[1152921514485132592] = ???;  stack[1152921514485132600] = ???;  //  dest_result_addr=1152921514485132592 |  dest_result_addr=1152921514485132600
        // 0x00B96094: STP x29, x30, [sp, #0x30]  | stack[1152921514485132608] = ???;  stack[1152921514485132616] = ???;  //  dest_result_addr=1152921514485132608 |  dest_result_addr=1152921514485132616
        // 0x00B96098: ADD x29, sp, #0x30         | X29 = (1152921514485132560 + 48) = 1152921514485132608 (0x100000024CCAAD40);
        // 0x00B9609C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B960A0: LDRB w8, [x20, #0xa73]     | W8 = (bool)static_value_03733A73;       
        // 0x00B960A4: MOV x19, x0                | X19 = 1152921514485144624 (0x100000024CCADC30);//ML01
        // 0x00B960A8: TBNZ w8, #0, #0xb960c4     | if (static_value_03733A73 == true) goto label_0;
        // 0x00B960AC: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B960B0: LDR x8, [x8, #0xe98]       | X8 = 0x2B8F8D4;                         
        // 0x00B960B4: LDR w0, [x8]               | W0 = 0x14F9;                            
        // 0x00B960B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F9, ????);     
        // 0x00B960BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B960C0: STRB w8, [x20, #0xa73]     | static_value_03733A73 = true;            //  dest_result_addr=57883251
        label_0:
        // 0x00B960C4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B960C8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B960CC: LDR x20, [x19, #0x28]      | X20 = this.Targer; //P2                 
        // 0x00B960D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B960D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B960D8: TBZ w8, #0, #0xb960e8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B960DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B960E0: CBNZ w8, #0xb960e8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B960E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B960E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B960EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B960F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B960F4: MOV x2, x20                | X2 = this.Targer;//m1                   
        // 0x00B960F8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00B960FC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B96100: TBNZ w8, #0, #0xb9621c     | if ((val_1 & 1) == true) goto label_7;  
        if(val_2 == true)
        {
            goto label_7;
        }
        // 0x00B96104: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B96108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9610C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_3 = NpcMgr.instance;
        // 0x00B96110: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B96114: CBNZ x20, #0xb9611c        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00B96118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00B9611C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96120: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B96124: BL #0xd14bbc               | X0 = val_3.GetCurRoundMonster();        
        System.Collections.Generic.List<CombatEntity> val_4 = val_3.GetCurRoundMonster();
        // 0x00B96128: ADRP x24, #0x3646000       | X24 = 56909824 (0x3646000);             
        // 0x00B9612C: ADRP x23, #0x35cf000       | X23 = 56422400 (0x35CF000);             
        // 0x00B96130: LDR x24, [x24, #0xa00]     | X24 = 1152921510857364848;              
        // 0x00B96134: LDR x23, [x23, #0x628]     | X23 = 1152921510857186288;              
        // 0x00B96138: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B9613C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_10 = 0;
        // 0x00B96140: B #0xb96148                |  goto label_5;                          
        goto label_5;
        label_13:
        // 0x00B96144: ADD w21, w21, #1           | W21 = (val_10 + 1) = val_10 (0x00000001);
        val_10 = 1;
        label_5:
        // 0x00B96148: CBNZ x20, #0xb96150        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B9614C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00B96150: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
        // 0x00B96154: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B96158: BL #0x25ed72c              | X0 = val_4.get_Count();                 
        int val_5 = val_4.Count;
        // 0x00B9615C: CMP w21, w0                | STATE = COMPARE(0x1, val_5)             
        // 0x00B96160: B.GE #0xb9621c             | if (val_10 >= val_5) goto label_7;      
        if(val_10 >= val_5)
        {
            goto label_7;
        }
        // 0x00B96164: CBNZ x20, #0xb9616c        | if (val_4 != null) goto label_8;        
        if(val_4 != null)
        {
            goto label_8;
        }
        // 0x00B96168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B9616C: LDR x2, [x23]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00B96170: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B96174: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B96178: BL #0x25ed734              | X0 = val_4.get_Item(index:  1);         
        CombatEntity val_6 = val_4.Item[1];
        // 0x00B9617C: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B96180: CBNZ x22, #0xb96188        | if (val_6 != null) goto label_9;        
        if(val_6 != null)
        {
            goto label_9;
        }
        // 0x00B96184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_9:
        // 0x00B96188: LDR x8, [x22]              | X8 = typeof(CombatEntity);              
        // 0x00B9618C: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B96190: LDR x9, [x8, #0x220]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_220;
        // 0x00B96194: LDR x1, [x8, #0x228]       | X1 = typeof(CombatEntity).__il2cppRuntimeField_228;
        // 0x00B96198: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_220();
        // 0x00B9619C: CMP w0, #3                 | STATE = COMPARE(val_6, 0x3)             
        // 0x00B961A0: B.EQ #0xb961e4             | if (val_6 == 0x3) goto label_10;        
        if(val_6 == 3)
        {
            goto label_10;
        }
        // 0x00B961A4: CBNZ x20, #0xb961ac        | if (val_4 != null) goto label_11;       
        if(val_4 != null)
        {
            goto label_11;
        }
        // 0x00B961A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B961AC: LDR x2, [x23]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00B961B0: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B961B4: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B961B8: BL #0x25ed734              | X0 = val_4.get_Item(index:  1);         
        CombatEntity val_7 = val_4.Item[1];
        // 0x00B961BC: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00B961C0: CBNZ x22, #0xb961c8        | if (val_7 != null) goto label_12;       
        if(val_7 != null)
        {
            goto label_12;
        }
        // 0x00B961C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00B961C8: LDR x8, [x22]              | X8 = typeof(CombatEntity);              
        // 0x00B961CC: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x00B961D0: LDR x9, [x8, #0x220]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_220;
        // 0x00B961D4: LDR x1, [x8, #0x228]       | X1 = typeof(CombatEntity).__il2cppRuntimeField_228;
        // 0x00B961D8: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_220();
        // 0x00B961DC: CMP w0, #5                 | STATE = COMPARE(val_7, 0x5)             
        // 0x00B961E0: B.NE #0xb96144             | if (val_7 != 0x5) goto label_13;        
        if(val_7 != 5)
        {
            goto label_13;
        }
        label_10:
        // 0x00B961E4: CBNZ x20, #0xb961ec        | if (val_4 != null) goto label_14;       
        if(val_4 != null)
        {
            goto label_14;
        }
        // 0x00B961E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_14:
        // 0x00B961EC: LDR x2, [x23]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00B961F0: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B961F4: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B961F8: BL #0x25ed734              | X0 = val_4.get_Item(index:  1);         
        CombatEntity val_8 = val_4.Item[1];
        // 0x00B961FC: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B96200: STR x20, [x19, #0x40]      | this._boss = val_8;                      //  dest_result_addr=1152921514485144688
        this._boss = val_8;
        // 0x00B96204: CBNZ x20, #0xb9620c        | if (val_8 != null) goto label_15;       
        if(val_8 != null)
        {
            goto label_15;
        }
        // 0x00B96208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_15:
        // 0x00B9620C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B96210: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B96214: BL #0x20d50fc              | X0 = val_8.get_gameObject();            
        UnityEngine.GameObject val_9 = val_8.gameObject;
        // 0x00B96218: STR x0, [x19, #0x28]       | this.Targer = val_9;                     //  dest_result_addr=1152921514485144664
        this.Targer = val_9;
        label_7:
        // 0x00B9621C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96220: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96224: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B96228: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B9622C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96230 (12149296), len: 4  VirtAddr: 0x00B96230 RVA: 0x00B96230 token: 100690196 methodIndex: 25251 delegateWrapperIndex: 0 methodInvoker: 0
    private void SetGameState(CombatEntity entity, bool state)
    {
        //
        // Disasemble & Code
        // 0x00B96230: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96234 (12149300), len: 984  VirtAddr: 0x00B96234 RVA: 0x00B96234 token: 100690197 methodIndex: 25252 delegateWrapperIndex: 0 methodInvoker: 0
    private void SetCameraState(bool state)
    {
        //
        // Disasemble & Code
        //  | 
        var val_22;
        //  | 
        var val_23;
        //  | 
        System.Collections.Generic.List<BAMCameras> val_24;
        //  | 
        var val_25;
        // 0x00B96234: STP x28, x27, [sp, #-0x60]! | stack[1152921514485526608] = ???;  stack[1152921514485526616] = ???;  //  dest_result_addr=1152921514485526608 |  dest_result_addr=1152921514485526616
        // 0x00B96238: STP x26, x25, [sp, #0x10]  | stack[1152921514485526624] = ???;  stack[1152921514485526632] = ???;  //  dest_result_addr=1152921514485526624 |  dest_result_addr=1152921514485526632
        // 0x00B9623C: STP x24, x23, [sp, #0x20]  | stack[1152921514485526640] = ???;  stack[1152921514485526648] = ???;  //  dest_result_addr=1152921514485526640 |  dest_result_addr=1152921514485526648
        // 0x00B96240: STP x22, x21, [sp, #0x30]  | stack[1152921514485526656] = ???;  stack[1152921514485526664] = ???;  //  dest_result_addr=1152921514485526656 |  dest_result_addr=1152921514485526664
        // 0x00B96244: STP x20, x19, [sp, #0x40]  | stack[1152921514485526672] = ???;  stack[1152921514485526680] = ???;  //  dest_result_addr=1152921514485526672 |  dest_result_addr=1152921514485526680
        // 0x00B96248: STP x29, x30, [sp, #0x50]  | stack[1152921514485526688] = ???;  stack[1152921514485526696] = ???;  //  dest_result_addr=1152921514485526688 |  dest_result_addr=1152921514485526696
        // 0x00B9624C: ADD x29, sp, #0x50         | X29 = (1152921514485526608 + 80) = 1152921514485526688 (0x100000024CD0B0A0);
        // 0x00B96250: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B96254: LDRB w8, [x20, #0xa74]     | W8 = (bool)static_value_03733A74;       
        // 0x00B96258: MOV w21, w1                | W21 = state;//m1                        
        // 0x00B9625C: MOV x19, x0                | X19 = 1152921514485538704 (0x100000024CD0DF90);//ML01
        // 0x00B96260: TBNZ w8, #0, #0xb9627c     | if (static_value_03733A74 == true) goto label_0;
        // 0x00B96264: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00B96268: LDR x8, [x8, #0x338]       | X8 = 0x2B8F8E4;                         
        // 0x00B9626C: LDR w0, [x8]               | W0 = 0x14FD;                            
        // 0x00B96270: BL #0x2782188              | X0 = sub_2782188( ?? 0x14FD, ????);     
        // 0x00B96274: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96278: STRB w8, [x20, #0xa74]     | static_value_03733A74 = true;            //  dest_result_addr=57883252
        label_0:
        // 0x00B9627C: ADRP x23, #0x364a000       | X23 = 56926208 (0x364A000);             
        // 0x00B96280: ADRP x24, #0x3634000       | X24 = 56836096 (0x3634000);             
        // 0x00B96284: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00B96288: ADRP x26, #0x362f000       | X26 = 56815616 (0x362F000);             
        // 0x00B9628C: ADRP x27, #0x35fe000       | X27 = 56614912 (0x35FE000);             
        // 0x00B96290: LDR x23, [x23, #0x7c8]     | X23 = 1152921514485381488;              
        // 0x00B96294: LDR x24, [x24, #0x130]     | X24 = 1152921514485382512;              
        // 0x00B96298: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        // 0x00B9629C: LDR x26, [x26, #0x968]     | X26 = (string**)(1152921514485383536)("bossCamera");
        // 0x00B962A0: LDR x27, [x27, #0x810]     | X27 = 1152921504697475072;              
        // 0x00B962A4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_22 = 0;
        // 0x00B962A8: AND w8, w21, #1            | W8 = (state & 1);                       
        bool val_1 = state;
        // 0x00B962AC: TBZ w8, #0, #0xb96474      | if ((state & 1) == false) goto label_1; 
        if(val_1 == false)
        {
            goto label_1;
        }
        // 0x00B962B0: B #0xb962c4                |  goto label_2;                          
        goto label_2;
        label_25:
        // 0x00B962B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B962B8: MOV x0, x21                | X0 = state;//m1                         
        // 0x00B962BC: BL #0x20cb458              | state.set_enabled(value:  state);       
        state.enabled = state;
        // 0x00B962C0: ADD w20, w20, #1           | W20 = (val_22 + 1) = val_23 (0x00000001);
        val_23 = 1;
        label_2:
        // 0x00B962C4: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        val_24 = this.cameraList;
        // 0x00B962C8: CBNZ x21, #0xb962d0        | if (this.cameraList != null) goto label_3;
        if(val_24 != null)
        {
            goto label_3;
        }
        // 0x00B962CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? state, ????);      
        label_3:
        // 0x00B962D0: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<BAMCameras>::get_Count();
        // 0x00B962D4: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B962D8: BL #0x25ed72c              | X0 = this.cameraList.get_Count();       
        int val_2 = val_24.Count;
        // 0x00B962DC: CMP w20, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00B962E0: B.GE #0xb965f0             | if (val_23 >= val_2) goto label_27;     
        if(val_23 >= val_2)
        {
            goto label_27;
        }
        // 0x00B962E4: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B962E8: CBNZ x21, #0xb962f0        | if (this.cameraList != null) goto label_5;
        if(this.cameraList != null)
        {
            goto label_5;
        }
        // 0x00B962EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B962F0: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B962F4: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B962F8: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B962FC: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_3 = this.cameraList.Item[1];
        // 0x00B96300: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00B96304: CBNZ x21, #0xb9630c        | if (val_3 != null) goto label_6;        
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00B96308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B9630C: LDR x21, [x21, #0x10]      | X21 = val_3.camera; //P2                
        // 0x00B96310: CBNZ x21, #0xb96318        | if (val_3.camera != null) goto label_7; 
        if(val_3.camera != null)
        {
            goto label_7;
        }
        // 0x00B96314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B96318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9631C: MOV x0, x21                | X0 = val_3.camera;//m1                  
        // 0x00B96320: BL #0x20d5478              | X0 = val_3.camera.get_tag();            
        string val_4 = val_3.camera.tag;
        // 0x00B96324: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B96328: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00B9632C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B96330: TBZ w9, #0, #0xb96344      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B96334: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B96338: CBNZ w9, #0xb96344         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B9633C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B96340: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_9:
        // 0x00B96344: LDR x2, [x26]              | X2 = "bossCamera";                      
        // 0x00B96348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9634C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96350: MOV x1, x21                | X1 = val_4;//m1                         
        // 0x00B96354: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_4);
        bool val_5 = System.String.op_Equality(a:  0, b:  val_4);
        // 0x00B96358: AND w8, w0, #1             | W8 = (val_5 & 1);                       
        bool val_6 = val_5;
        // 0x00B9635C: TBNZ w8, #0, #0xb963c0     | if ((val_5 & 1) == true) goto label_10; 
        if(val_6 == true)
        {
            goto label_10;
        }
        // 0x00B96360: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B96364: CBNZ x21, #0xb9636c        | if (this.cameraList != null) goto label_11;
        if(this.cameraList != null)
        {
            goto label_11;
        }
        // 0x00B96368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00B9636C: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B96370: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B96374: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B96378: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_7 = this.cameraList.Item[1];
        // 0x00B9637C: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00B96380: CBNZ x21, #0xb96388        | if (val_7 != null) goto label_12;       
        if(val_7 != null)
        {
            goto label_12;
        }
        // 0x00B96384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00B96388: LDR x0, [x27]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B9638C: LDR x22, [x21, #0x10]      | X22 = val_7.camera; //P2                
        // 0x00B96390: LDR x21, [x19, #0x30]      | X21 = this.BossCamera; //P2             
        // 0x00B96394: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B96398: TBZ w8, #0, #0xb963a8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B9639C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B963A0: CBNZ w8, #0xb963a8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B963A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_14:
        // 0x00B963A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B963AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B963B0: MOV x1, x22                | X1 = val_7.camera;//m1                  
        // 0x00B963B4: MOV x2, x21                | X2 = this.BossCamera;//m1               
        // 0x00B963B8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_7.camera);
        bool val_8 = UnityEngine.Object.op_Equality(x:  0, y:  val_7.camera);
        // 0x00B963BC: TBZ w0, #0, #0xb963fc      | if (val_8 == false) goto label_15;      
        if(val_8 == false)
        {
            goto label_15;
        }
        label_10:
        // 0x00B963C0: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B963C4: CBNZ x21, #0xb963cc        | if (this.cameraList != null) goto label_16;
        if(this.cameraList != null)
        {
            goto label_16;
        }
        // 0x00B963C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_16:
        // 0x00B963CC: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B963D0: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B963D4: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B963D8: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_9 = this.cameraList.Item[1];
        // 0x00B963DC: MOV x21, x0                | X21 = val_9;//m1                        
        // 0x00B963E0: CBNZ x21, #0xb963e8        | if (val_9 != null) goto label_17;       
        if(val_9 != null)
        {
            goto label_17;
        }
        // 0x00B963E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_17:
        // 0x00B963E8: LDR x21, [x21, #0x10]      | X21 = val_9.camera; //P2                
        // 0x00B963EC: CBNZ x21, #0xb963f4        | if (val_9.camera != null) goto label_18;
        if(val_9.camera != null)
        {
            goto label_18;
        }
        // 0x00B963F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_18:
        // 0x00B963F4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B963F8: B #0xb962b4                |  goto label_25;                         
        goto label_25;
        label_15:
        // 0x00B963FC: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B96400: CBNZ x21, #0xb96408        | if (this.cameraList != null) goto label_20;
        if(this.cameraList != null)
        {
            goto label_20;
        }
        // 0x00B96404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_20:
        // 0x00B96408: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B9640C: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B96410: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B96414: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_10 = this.cameraList.Item[1];
        // 0x00B96418: MOV x21, x0                | X21 = val_10;//m1                       
        // 0x00B9641C: CBNZ x21, #0xb96424        | if (val_10 != null) goto label_21;      
        if(val_10 != null)
        {
            goto label_21;
        }
        // 0x00B96420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_21:
        // 0x00B96424: LDR x21, [x21, #0x10]      | X21 = val_10.camera; //P2               
        // 0x00B96428: LDR x22, [x19, #0x68]      | X22 = this.cameraList; //P2             
        // 0x00B9642C: CBNZ x22, #0xb96434        | if (this.cameraList != null) goto label_22;
        if(this.cameraList != null)
        {
            goto label_22;
        }
        // 0x00B96430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_22:
        // 0x00B96434: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B96438: MOV x0, x22                | X0 = this.cameraList;//m1               
        // 0x00B9643C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B96440: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  1);
        BAMCameras val_11 = this.cameraList.Item[1];
        // 0x00B96444: MOV x22, x0                | X22 = val_11;//m1                       
        // 0x00B96448: CBNZ x22, #0xb96450        | if (val_11 != null) goto label_23;      
        if(val_11 != null)
        {
            goto label_23;
        }
        // 0x00B9644C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_23:
        // 0x00B96450: LDRB w22, [x22, #0x18]     | W22 = val_11.initEnable; //P2           
        // 0x00B96454: CBNZ x21, #0xb9645c        | if (val_10.camera != null) goto label_24;
        if(val_10.camera != null)
        {
            goto label_24;
        }
        // 0x00B96458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_24:
        // 0x00B9645C: CMP w22, #0                | STATE = COMPARE(val_11.initEnable, 0x0) 
        // 0x00B96460: CSET w1, ne                | W1 = val_11.initEnable == true ? 1 : 0; 
        bool val_12 = (val_11.initEnable == true) ? 1 : 0;
        // 0x00B96464: B #0xb962b4                |  goto label_25;                         
        goto label_25;
        label_46:
        // 0x00B96468: MOV x0, x21                | X0 = val_10.camera;//m1                 
        // 0x00B9646C: BL #0x20cb458              | val_10.camera.set_enabled(value:  bool val_12 = (val_11.initEnable == true) ? 1 : 0);
        val_10.camera.enabled = val_12;
        // 0x00B96470: ADD w20, w20, #1           | W20 = (val_23 + 1) = val_25 (0x00000002);
        val_25 = 2;
        label_1:
        // 0x00B96474: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        val_24 = this.cameraList;
        // 0x00B96478: CBNZ x21, #0xb96480        | if (this.cameraList != null) goto label_26;
        if(val_24 != null)
        {
            goto label_26;
        }
        // 0x00B9647C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10.camera, ????);
        label_26:
        // 0x00B96480: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<BAMCameras>::get_Count();
        // 0x00B96484: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B96488: BL #0x25ed72c              | X0 = this.cameraList.get_Count();       
        int val_13 = val_24.Count;
        // 0x00B9648C: CMP w20, w0                | STATE = COMPARE(0x2, val_13)            
        // 0x00B96490: B.GE #0xb965f0             | if (val_25 >= val_13) goto label_27;    
        if(val_25 >= val_13)
        {
            goto label_27;
        }
        // 0x00B96494: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B96498: CBNZ x21, #0xb964a0        | if (this.cameraList != null) goto label_28;
        if(this.cameraList != null)
        {
            goto label_28;
        }
        // 0x00B9649C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_28:
        // 0x00B964A0: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B964A4: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B964A8: MOV w1, w20                | W1 = 2 (0x2);//ML01                     
        // 0x00B964AC: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  2);
        BAMCameras val_14 = this.cameraList.Item[2];
        // 0x00B964B0: MOV x21, x0                | X21 = val_14;//m1                       
        // 0x00B964B4: CBNZ x21, #0xb964bc        | if (val_14 != null) goto label_29;      
        if(val_14 != null)
        {
            goto label_29;
        }
        // 0x00B964B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_29:
        // 0x00B964BC: LDR x21, [x21, #0x10]      | X21 = val_14.camera; //P2               
        // 0x00B964C0: CBNZ x21, #0xb964c8        | if (val_14.camera != null) goto label_30;
        if(val_14.camera != null)
        {
            goto label_30;
        }
        // 0x00B964C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_30:
        // 0x00B964C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B964CC: MOV x0, x21                | X0 = val_14.camera;//m1                 
        // 0x00B964D0: BL #0x20d5478              | X0 = val_14.camera.get_tag();           
        string val_15 = val_14.camera.tag;
        // 0x00B964D4: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00B964D8: MOV x21, x0                | X21 = val_15;//m1                       
        // 0x00B964DC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B964E0: TBZ w9, #0, #0xb964f4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x00B964E4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B964E8: CBNZ w9, #0xb964f4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x00B964EC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B964F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_32:
        // 0x00B964F4: LDR x2, [x26]              | X2 = "bossCamera";                      
        // 0x00B964F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B964FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96500: MOV x1, x21                | X1 = val_15;//m1                        
        // 0x00B96504: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_15);
        bool val_16 = System.String.op_Equality(a:  0, b:  val_15);
        // 0x00B96508: AND w8, w0, #1             | W8 = (val_16 & 1);                      
        bool val_17 = val_16;
        // 0x00B9650C: TBNZ w8, #0, #0xb96570     | if ((val_16 & 1) == true) goto label_33;
        if(val_17 == true)
        {
            goto label_33;
        }
        // 0x00B96510: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B96514: CBNZ x21, #0xb9651c        | if (this.cameraList != null) goto label_34;
        if(this.cameraList != null)
        {
            goto label_34;
        }
        // 0x00B96518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_34:
        // 0x00B9651C: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B96520: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B96524: MOV w1, w20                | W1 = 2 (0x2);//ML01                     
        // 0x00B96528: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  2);
        BAMCameras val_18 = this.cameraList.Item[2];
        // 0x00B9652C: MOV x21, x0                | X21 = val_18;//m1                       
        // 0x00B96530: CBNZ x21, #0xb96538        | if (val_18 != null) goto label_35;      
        if(val_18 != null)
        {
            goto label_35;
        }
        // 0x00B96534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_35:
        // 0x00B96538: LDR x0, [x27]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B9653C: LDR x22, [x21, #0x10]      | X22 = val_18.camera; //P2               
        // 0x00B96540: LDR x21, [x19, #0x30]      | X21 = this.BossCamera; //P2             
        // 0x00B96544: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B96548: TBZ w8, #0, #0xb96558      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_37;
        // 0x00B9654C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B96550: CBNZ w8, #0xb96558         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
        // 0x00B96554: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_37:
        // 0x00B96558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9655C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96560: MOV x1, x22                | X1 = val_18.camera;//m1                 
        // 0x00B96564: MOV x2, x21                | X2 = this.BossCamera;//m1               
        // 0x00B96568: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_18.camera);
        bool val_19 = UnityEngine.Object.op_Equality(x:  0, y:  val_18.camera);
        // 0x00B9656C: TBZ w0, #0, #0xb965b0      | if (val_19 == false) goto label_38;     
        if(val_19 == false)
        {
            goto label_38;
        }
        label_33:
        // 0x00B96570: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B96574: CBNZ x21, #0xb9657c        | if (this.cameraList != null) goto label_39;
        if(this.cameraList != null)
        {
            goto label_39;
        }
        // 0x00B96578: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_39:
        // 0x00B9657C: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B96580: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B96584: MOV w1, w20                | W1 = 2 (0x2);//ML01                     
        // 0x00B96588: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  2);
        BAMCameras val_20 = this.cameraList.Item[2];
        // 0x00B9658C: MOV x21, x0                | X21 = val_20;//m1                       
        // 0x00B96590: CBNZ x21, #0xb96598        | if (val_20 != null) goto label_40;      
        if(val_20 != null)
        {
            goto label_40;
        }
        // 0x00B96594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_40:
        // 0x00B96598: LDR x21, [x21, #0x10]      | X21 = val_20.camera; //P2               
        // 0x00B9659C: CBNZ x21, #0xb965a4        | if (val_20.camera != null) goto label_41;
        if(val_20.camera != null)
        {
            goto label_41;
        }
        // 0x00B965A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_41:
        // 0x00B965A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B965A8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B965AC: B #0xb96468                |  goto label_46;                         
        goto label_46;
        label_38:
        // 0x00B965B0: LDR x21, [x19, #0x68]      | X21 = this.cameraList; //P2             
        // 0x00B965B4: CBNZ x21, #0xb965bc        | if (this.cameraList != null) goto label_43;
        if(this.cameraList != null)
        {
            goto label_43;
        }
        // 0x00B965B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_43:
        // 0x00B965BC: LDR x2, [x24]              | X2 = public BAMCameras System.Collections.Generic.List<BAMCameras>::get_Item(int index);
        // 0x00B965C0: MOV x0, x21                | X0 = this.cameraList;//m1               
        // 0x00B965C4: MOV w1, w20                | W1 = 2 (0x2);//ML01                     
        // 0x00B965C8: BL #0x25ed734              | X0 = this.cameraList.get_Item(index:  2);
        BAMCameras val_21 = this.cameraList.Item[2];
        // 0x00B965CC: MOV x21, x0                | X21 = val_21;//m1                       
        // 0x00B965D0: CBNZ x21, #0xb965d8        | if (val_21 != null) goto label_44;      
        if(val_21 != null)
        {
            goto label_44;
        }
        // 0x00B965D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_44:
        // 0x00B965D8: LDR x21, [x21, #0x10]      | X21 = val_21.camera; //P2               
        // 0x00B965DC: CBNZ x21, #0xb965e4        | if (val_21.camera != null) goto label_45;
        if(val_21.camera != null)
        {
            goto label_45;
        }
        // 0x00B965E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_45:
        // 0x00B965E4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B965E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B965EC: B #0xb96468                |  goto label_46;                         
        goto label_46;
        label_27:
        // 0x00B965F0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B965F4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B965F8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B965FC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B96600: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B96604: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B96608: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B96BE4 (12151780), len: 152  VirtAddr: 0x00B96BE4 RVA: 0x00B96BE4 token: 100690198 methodIndex: 25253 delegateWrapperIndex: 0 methodInvoker: 0
    private void <UpdateBossAnimation>m__0(string aniType, float aniTime)
    {
        //
        // Disasemble & Code
        // 0x00B96BE4: STP d9, d8, [sp, #-0x40]!  | stack[1152921514485782000] = ???;  stack[1152921514485782008] = ???;  //  dest_result_addr=1152921514485782000 |  dest_result_addr=1152921514485782008
        // 0x00B96BE8: STP x22, x21, [sp, #0x10]  | stack[1152921514485782016] = ???;  stack[1152921514485782024] = ???;  //  dest_result_addr=1152921514485782016 |  dest_result_addr=1152921514485782024
        // 0x00B96BEC: STP x20, x19, [sp, #0x20]  | stack[1152921514485782032] = ???;  stack[1152921514485782040] = ???;  //  dest_result_addr=1152921514485782032 |  dest_result_addr=1152921514485782040
        // 0x00B96BF0: STP x29, x30, [sp, #0x30]  | stack[1152921514485782048] = ???;  stack[1152921514485782056] = ???;  //  dest_result_addr=1152921514485782048 |  dest_result_addr=1152921514485782056
        // 0x00B96BF4: ADD x29, sp, #0x30         | X29 = (1152921514485782000 + 48) = 1152921514485782048 (0x100000024CD49620);
        // 0x00B96BF8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B96BFC: LDRB w8, [x21, #0xa75]     | W8 = (bool)static_value_03733A75;       
        // 0x00B96C00: MOV v8.16b, v0.16b         | V8 = aniTime;//m1                       
        // 0x00B96C04: MOV x19, x1                | X19 = aniType;//m1                      
        // 0x00B96C08: MOV x20, x0                | X20 = 1152921514485794064 (0x100000024CD4C510);//ML01
        // 0x00B96C0C: TBNZ w8, #0, #0xb96c28     | if (static_value_03733A75 == true) goto label_0;
        // 0x00B96C10: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00B96C14: LDR x8, [x8, #0x778]       | X8 = 0x2B8F8E8;                         
        // 0x00B96C18: LDR w0, [x8]               | W0 = 0x14FE;                            
        // 0x00B96C1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14FE, ????);     
        // 0x00B96C20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B96C24: STRB w8, [x21, #0xa75]     | static_value_03733A75 = true;            //  dest_result_addr=57883253
        label_0:
        // 0x00B96C28: LDR x20, [x20, #0x28]      | X20 = this.Targer; //P2                 
        // 0x00B96C2C: CBNZ x20, #0xb96c34        | if (this.Targer != null) goto label_1;  
        if(this.Targer != null)
        {
            goto label_1;
        }
        // 0x00B96C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14FE, ????);     
        label_1:
        // 0x00B96C34: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B96C38: LDR x8, [x8, #0x198]       | X8 = 1152921511884050752;               
        // 0x00B96C3C: MOV x0, x20                | X0 = this.Targer;//m1                   
        // 0x00B96C40: LDR x1, [x8]               | X1 = public AnimationRunner UnityEngine.GameObject::GetComponent<AnimationRunner>();
        // 0x00B96C44: BL #0x23d5abc              | X0 = this.Targer.GetComponent<AnimationRunner>();
        AnimationRunner val_1 = this.Targer.GetComponent<AnimationRunner>();
        // 0x00B96C48: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B96C4C: CBNZ x20, #0xb96c54        | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x00B96C50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00B96C54: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B96C58: MOV x1, x19                | X1 = aniType;//m1                       
        // 0x00B96C5C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B96C60: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B96C64: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B96C68: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B96C6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B96C70: MOV v0.16b, v8.16b         | V0 = aniTime;//m1                       
        // 0x00B96C74: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B96C78: B #0xb285f8                | val_1.Play(aniName:  aniType, playTime:  aniTime, isSkill:  false); return;
        val_1.Play(aniName:  aniType, playTime:  aniTime, isSkill:  false);
        return;
    
    }

}
