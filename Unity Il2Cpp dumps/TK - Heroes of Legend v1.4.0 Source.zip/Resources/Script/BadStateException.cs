using UnityEngine;

namespace Pathfinding.Ionic.Zip
{
    [System.Runtime.InteropServices.GuidAttribute] // 0x281408C
    public class BadStateException : ZipException
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x0197037C (26674044), len: 8  VirtAddr: 0x0197037C RVA: 0x0197037C token: 100663347 methodIndex: 20857 delegateWrapperIndex: 0 methodInvoker: 0
        public BadStateException(string message)
        {
            //
            // Disasemble & Code
            // 0x0197037C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01970380: B #0x1c32b48               | this..ctor(message:  message); return;  
            val_1 = new System.Exception(message:  message);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01970384 (26674052), len: 8  VirtAddr: 0x01970384 RVA: 0x01970384 token: 100663348 methodIndex: 20858 delegateWrapperIndex: 0 methodInvoker: 0
        public BadStateException(string message, System.Exception innerException)
        {
            //
            // Disasemble & Code
            // 0x01970384: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01970388: B #0x1c3e600               | innerException..ctor(message:  message, innerException:  innerException); return;
            val_1 = new System.Exception(message:  message, innerException:  System.Exception val_1 = innerException);
            return;
        
        }
    
    }

}
