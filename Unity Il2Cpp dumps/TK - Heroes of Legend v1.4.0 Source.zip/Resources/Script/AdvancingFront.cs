using UnityEngine;

namespace Pathfinding.Poly2Tri
{
    public class AdvancingFront
    {
        // Fields
        public Pathfinding.Poly2Tri.AdvancingFrontNode Head; //  0x00000010
        public Pathfinding.Poly2Tri.AdvancingFrontNode Tail; //  0x00000018
        protected Pathfinding.Poly2Tri.AdvancingFrontNode Search; //  0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0273CC48 (41143368), len: 60  VirtAddr: 0x0273CC48 RVA: 0x0273CC48 token: 100663345 methodIndex: 21562 delegateWrapperIndex: 0 methodInvoker: 0
        public AdvancingFront(Pathfinding.Poly2Tri.AdvancingFrontNode head, Pathfinding.Poly2Tri.AdvancingFrontNode tail)
        {
            //
            // Disasemble & Code
            // 0x0273CC48: STP x22, x21, [sp, #-0x30]! | stack[1152921509767216000] = ???;  stack[1152921509767216008] = ???;  //  dest_result_addr=1152921509767216000 |  dest_result_addr=1152921509767216008
            // 0x0273CC4C: STP x20, x19, [sp, #0x10]  | stack[1152921509767216016] = ???;  stack[1152921509767216024] = ???;  //  dest_result_addr=1152921509767216016 |  dest_result_addr=1152921509767216024
            // 0x0273CC50: STP x29, x30, [sp, #0x20]  | stack[1152921509767216032] = ???;  stack[1152921509767216040] = ???;  //  dest_result_addr=1152921509767216032 |  dest_result_addr=1152921509767216040
            // 0x0273CC54: ADD x29, sp, #0x20         | X29 = (1152921509767216000 + 32) = 1152921509767216032 (0x100000013394FBA0);
            // 0x0273CC58: MOV x20, x1                | X20 = head;//m1                         
            // 0x0273CC5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0273CC60: MOV x19, x2                | X19 = tail;//m1                         
            // 0x0273CC64: MOV x21, x0                | X21 = 1152921509767228048 (0x1000000133952A90);//ML01
            // 0x0273CC68: BL #0x16f59f0              | tail..ctor();                           
            val_1 = new System.Object();
            // 0x0273CC6C: STP x20, x19, [x21, #0x10] | this.Head = head;  this.Tail = tail;     //  dest_result_addr=1152921509767228064 |  dest_result_addr=1152921509767228072
            this.Head = head;
            this.Tail = val_1;
            // 0x0273CC70: STR x20, [x21, #0x20]      | this.Search = head;                      //  dest_result_addr=1152921509767228080
            this.Search = head;
            // 0x0273CC74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0273CC78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0273CC7C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0273CC80: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CC84 (41143428), len: 4  VirtAddr: 0x0273CC84 RVA: 0x0273CC84 token: 100663346 methodIndex: 21563 delegateWrapperIndex: 0 methodInvoker: 0
        public void AddNode(Pathfinding.Poly2Tri.AdvancingFrontNode node)
        {
            //
            // Disasemble & Code
            // 0x0273CC84: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CC88 (41143432), len: 4  VirtAddr: 0x0273CC88 RVA: 0x0273CC88 token: 100663347 methodIndex: 21564 delegateWrapperIndex: 0 methodInvoker: 0
        public void RemoveNode(Pathfinding.Poly2Tri.AdvancingFrontNode node)
        {
            //
            // Disasemble & Code
            // 0x0273CC88: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CC8C (41143436), len: 320  VirtAddr: 0x0273CC8C RVA: 0x0273CC8C token: 100663348 methodIndex: 21565 delegateWrapperIndex: 0 methodInvoker: 0
        public override string ToString()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Poly2Tri.AdvancingFrontNode val_6;
            //  | 
            var val_7;
            // 0x0273CC8C: STP d9, d8, [sp, #-0x50]!  | stack[1152921509767617584] = ???;  stack[1152921509767617592] = ???;  //  dest_result_addr=1152921509767617584 |  dest_result_addr=1152921509767617592
            // 0x0273CC90: STP x24, x23, [sp, #0x10]  | stack[1152921509767617600] = ???;  stack[1152921509767617608] = ???;  //  dest_result_addr=1152921509767617600 |  dest_result_addr=1152921509767617608
            // 0x0273CC94: STP x22, x21, [sp, #0x20]  | stack[1152921509767617616] = ???;  stack[1152921509767617624] = ???;  //  dest_result_addr=1152921509767617616 |  dest_result_addr=1152921509767617624
            // 0x0273CC98: STP x20, x19, [sp, #0x30]  | stack[1152921509767617632] = ???;  stack[1152921509767617640] = ???;  //  dest_result_addr=1152921509767617632 |  dest_result_addr=1152921509767617640
            // 0x0273CC9C: STP x29, x30, [sp, #0x40]  | stack[1152921509767617648] = ???;  stack[1152921509767617656] = ???;  //  dest_result_addr=1152921509767617648 |  dest_result_addr=1152921509767617656
            // 0x0273CCA0: ADD x29, sp, #0x40         | X29 = (1152921509767617584 + 64) = 1152921509767617648 (0x10000001339B1C70);
            // 0x0273CCA4: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
            // 0x0273CCA8: LDRB w8, [x19, #0xb52]     | W8 = (bool)static_value_03743B52;       
            // 0x0273CCAC: MOV x20, x0                | X20 = 1152921509767629664 (0x10000001339B4B60);//ML01
            // 0x0273CCB0: TBNZ w8, #0, #0x273cccc    | if (static_value_03743B52 == true) goto label_0;
            // 0x0273CCB4: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0273CCB8: LDR x8, [x8, #0x68]        | X8 = 0x2B8AA6C;                         
            // 0x0273CCBC: LDR w0, [x8]               | W0 = 0x159;                             
            // 0x0273CCC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x159, ????);      
            // 0x0273CCC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0273CCC8: STRB w8, [x19, #0xb52]     | static_value_03743B52 = true;            //  dest_result_addr=57949010
            label_0:
            // 0x0273CCCC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0273CCD0: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x0273CCD4: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x0273CCD8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x0273CCDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0273CCE0: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0273CCE4: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x0273CCE8: LDP x22, x8, [x20, #0x10]  | X22 = this.Head; //P2  X8 = this.Tail; //P2  //  | 
            val_6 = this.Head;
            // 0x0273CCEC: CMP x22, x8                | STATE = COMPARE(this.Head, this.Tail)   
            // 0x0273CCF0: B.EQ #0x273cd60            | if (val_6 == this.Tail) goto label_1;   
            if(val_6 == this.Tail)
            {
                goto label_1;
            }
            // 0x0273CCF4: ADRP x23, #0x35f7000       | X23 = 56586240 (0x35F7000);             
            // 0x0273CCF8: LDR x23, [x23, #0xe18]     | X23 = (string**)(1152921509767572816)("->");
            label_7:
            // 0x0273CCFC: CBNZ x22, #0x273cd04       | if (this.Head != null) goto label_2;    
            if(val_6 != null)
            {
                goto label_2;
            }
            // 0x0273CD00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x0273CD04: LDR x21, [x22, #0x28]      | X21 = this.Head.Point; //P2             
            // 0x0273CD08: CBNZ x21, #0x273cd10       | if (this.Head.Point != null) goto label_3;
            if(this.Head.Point != null)
            {
                goto label_3;
            }
            // 0x0273CD0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x0273CD10: LDR d8, [x21, #0x10]       | D8 = this.Head.Point.X; //P2            
            // 0x0273CD14: CBNZ x19, #0x273cd1c       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x0273CD18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_4:
            // 0x0273CD1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0273CD20: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0273CD24: MOV v0.16b, v8.16b         | V0 = this.Head.Point.X;//m1             
            // 0x0273CD28: BL #0x1b5ba44              | X0 = Append(value:  this.Head.Point.X); 
            System.Text.StringBuilder val_2 = Append(value:  this.Head.Point.X);
            // 0x0273CD2C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0273CD30: CBNZ x21, #0x273cd38       | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x0273CD34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x0273CD38: LDR x1, [x23]              | X1 = "->";                              
            // 0x0273CD3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0273CD40: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0273CD44: BL #0x1b5b818              | X0 = val_2.Append(value:  "->");        
            System.Text.StringBuilder val_3 = val_2.Append(value:  "->");
            // 0x0273CD48: CBNZ x22, #0x273cd50       | if (this.Head != null) goto label_6;    
            if(val_6 != null)
            {
                goto label_6;
            }
            // 0x0273CD4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x0273CD50: LDR x22, [x22, #0x10]      | X22 = this.Head.Next; //P2              
            val_6 = this.Head.Next;
            // 0x0273CD54: LDR x8, [x20, #0x18]       | X8 = this.Tail; //P2                    
            // 0x0273CD58: CMP x22, x8                | STATE = COMPARE(this.Head.Next, this.Tail)
            // 0x0273CD5C: B.NE #0x273ccfc            | if (val_6 != this.Tail) goto label_7;   
            if(val_6 != this.Tail)
            {
                goto label_7;
            }
            label_1:
            // 0x0273CD60: CBNZ x22, #0x273cd68       | if (this.Head.Next != null) goto label_8;
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x0273CD64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_8:
            // 0x0273CD68: LDR x20, [x22, #0x28]      | X20 = this.Head.Next.Point; //P2        
            // 0x0273CD6C: CBNZ x20, #0x273cd74       | if (this.Head.Next.Point != null) goto label_9;
            if(this.Head.Next.Point != null)
            {
                goto label_9;
            }
            // 0x0273CD70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x0273CD74: LDR d8, [x20, #0x10]       | D8 = this.Head.Next.Point.X; //P2       
            // 0x0273CD78: CBZ x19, #0x273cd90        | if ( == 0) goto label_10;               
            if(null == 0)
            {
                goto label_10;
            }
            // 0x0273CD7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x0273CD80: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0273CD84: MOV v0.16b, v8.16b         | V0 = this.Head.Next.Point.X;//m1        
            // 0x0273CD88: BL #0x1b5ba44              | X0 = Append(value:  this.Head.Next.Point.X);
            System.Text.StringBuilder val_4 = Append(value:  this.Head.Next.Point.X);
            // 0x0273CD8C: B #0x273cda8               |  goto label_11;                         
            goto label_11;
            label_10:
            // 0x0273CD90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x0273CD94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x0273CD98: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0273CD9C: MOV v0.16b, v8.16b         | V0 = this.Head.Next.Point.X;//m1        
            // 0x0273CDA0: BL #0x1b5ba44              | X0 = Append(value:  this.Head.Next.Point.X);
            System.Text.StringBuilder val_5 = Append(value:  this.Head.Next.Point.X);
            // 0x0273CDA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_11:
            // 0x0273CDA8: LDR x8, [x19]              | X8 = ;                                  
            // 0x0273CDAC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0273CDB0: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x0273CDB4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0273CDB8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0273CDBC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0273CDC0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0273CDC4: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
            // 0x0273CDC8: BR x2                      | goto mem[null + 320];                   
            goto mem[null + 320];
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CDCC (41143756), len: 8  VirtAddr: 0x0273CDCC RVA: 0x0273CDCC token: 100663349 methodIndex: 21566 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.Poly2Tri.AdvancingFrontNode FindSearchNode(double x)
        {
            //
            // Disasemble & Code
            // 0x0273CDCC: LDR x0, [x0, #0x20]        | X0 = this.Search; //P2                  
            // 0x0273CDD0: RET                        |  return (Pathfinding.Poly2Tri.AdvancingFrontNode)this.Search;
            return this.Search;
            //  |  // // {name=val_0, type=Pathfinding.Poly2Tri.AdvancingFrontNode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CDD4 (41143764), len: 48  VirtAddr: 0x0273CDD4 RVA: 0x0273CDD4 token: 100663350 methodIndex: 21567 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.Poly2Tri.AdvancingFrontNode LocateNode(Pathfinding.Poly2Tri.TriangulationPoint point)
        {
            //
            // Disasemble & Code
            // 0x0273CDD4: STP x20, x19, [sp, #-0x20]! | stack[1152921509767894880] = ???;  stack[1152921509767894888] = ???;  //  dest_result_addr=1152921509767894880 |  dest_result_addr=1152921509767894888
            // 0x0273CDD8: STP x29, x30, [sp, #0x10]  | stack[1152921509767894896] = ???;  stack[1152921509767894904] = ???;  //  dest_result_addr=1152921509767894896 |  dest_result_addr=1152921509767894904
            // 0x0273CDDC: ADD x29, sp, #0x10         | X29 = (1152921509767894880 + 16) = 1152921509767894896 (0x10000001339F5770);
            // 0x0273CDE0: MOV x20, x1                | X20 = point;//m1                        
            // 0x0273CDE4: MOV x19, x0                | X19 = 1152921509767906912 (0x10000001339F8660);//ML01
            // 0x0273CDE8: CBNZ x20, #0x273cdf0       | if (point != null) goto label_0;        
            if(point != null)
            {
                goto label_0;
            }
            // 0x0273CDEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0273CDF0: LDR d0, [x20, #0x10]       | D0 = point.X; //P2                      
            // 0x0273CDF4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0273CDF8: MOV x0, x19                | X0 = 1152921509767906912 (0x10000001339F8660);//ML01
            // 0x0273CDFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0273CE00: B #0x273ce04               | return this.LocateNode(x:  point.X);    
            return this.LocateNode(x:  point.X);
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CE04 (41143812), len: 136  VirtAddr: 0x0273CE04 RVA: 0x0273CE04 token: 100663351 methodIndex: 21568 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.Poly2Tri.AdvancingFrontNode LocateNode(double x)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Poly2Tri.AdvancingFrontNode val_1;
            // 0x0273CE04: STP d9, d8, [sp, #-0x30]!  | stack[1152921509768031440] = ???;  stack[1152921509768031448] = ???;  //  dest_result_addr=1152921509768031440 |  dest_result_addr=1152921509768031448
            // 0x0273CE08: STP x20, x19, [sp, #0x10]  | stack[1152921509768031456] = ???;  stack[1152921509768031464] = ???;  //  dest_result_addr=1152921509768031456 |  dest_result_addr=1152921509768031464
            // 0x0273CE0C: STP x29, x30, [sp, #0x20]  | stack[1152921509768031472] = ???;  stack[1152921509768031480] = ???;  //  dest_result_addr=1152921509768031472 |  dest_result_addr=1152921509768031480
            // 0x0273CE10: ADD x29, sp, #0x20         | X29 = (1152921509768031440 + 32) = 1152921509768031472 (0x1000000133A16CF0);
            // 0x0273CE14: MOV x20, x0                | X20 = 1152921509768043488 (0x1000000133A19BE0);//ML01
            // 0x0273CE18: LDR x19, [x20, #0x20]      | X19 = this.Search; //P2                 
            // 0x0273CE1C: MOV v8.16b, v0.16b         | V8 = x;//m1                             
            // 0x0273CE20: CBNZ x19, #0x273ce28       | if (this.Search != null) goto label_0;  
            if(this.Search != null)
            {
                goto label_0;
            }
            // 0x0273CE24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0273CE28: LDR d0, [x19, #0x20]       | D0 = this.Search.Value; //P2            
            // 0x0273CE2C: FCMP d0, d8                | STATE = COMPARE(this.Search.Value, x)   
            // 0x0273CE30: B.LE #0x273ce50            | if (this.Search.Value <= x) goto label_6;
            if(this.Search.Value <= x)
            {
                goto label_6;
            }
            label_3:
            // 0x0273CE34: LDR x19, [x19, #0x18]      | X19 = this.Search.Prev; //P2            
            val_1 = this.Search.Prev;
            // 0x0273CE38: CBZ x19, #0x273ce74        | if (this.Search.Prev == null) goto label_5;
            if(val_1 == null)
            {
                goto label_5;
            }
            // 0x0273CE3C: LDR d0, [x19, #0x20]       | D0 = this.Search.Prev.Value; //P2       
            // 0x0273CE40: FCMP d0, d8                | STATE = COMPARE(this.Search.Prev.Value, x)
            // 0x0273CE44: B.HI #0x273ce34            | if (this.Search.Prev.Value > x) goto label_3;
            if(this.Search.Prev.Value > x)
            {
                goto label_3;
            }
            // 0x0273CE48: STR x19, [x20, #0x20]      | this.Search = this.Search.Prev;          //  dest_result_addr=1152921509768043520
            this.Search = val_1;
            // 0x0273CE4C: B #0x273ce78               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x0273CE50: LDR x19, [x19, #0x10]      | X19 = this.Search.Next; //P2            
            // 0x0273CE54: CBZ x19, #0x273ce74        | if (this.Search.Next == null) goto label_5;
            if(this.Search.Next == null)
            {
                goto label_5;
            }
            // 0x0273CE58: LDR d0, [x19, #0x20]       | D0 = this.Search.Next.Value; //P2       
            // 0x0273CE5C: FCMP d0, d8                | STATE = COMPARE(this.Search.Next.Value, x)
            // 0x0273CE60: B.LE #0x273ce50            | if (this.Search.Next.Value <= x) goto label_6;
            if(this.Search.Next.Value <= x)
            {
                goto label_6;
            }
            // 0x0273CE64: LDR x8, [x19, #0x18]       | X8 = this.Search.Next.Prev; //P2        
            // 0x0273CE68: STR x8, [x20, #0x20]       | this.Search = this.Search.Next.Prev;     //  dest_result_addr=1152921509768043520
            this.Search = this.Search.Next.Prev;
            // 0x0273CE6C: LDR x19, [x19, #0x18]      | X19 = this.Search.Next.Prev; //P2       
            val_1 = this.Search.Next.Prev;
            // 0x0273CE70: B #0x273ce78               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x0273CE74: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_1 = 0;
            label_7:
            // 0x0273CE78: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x0273CE7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0273CE80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0273CE84: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x0273CE88: RET                        |  return (Pathfinding.Poly2Tri.AdvancingFrontNode)null;
            return (Pathfinding.Poly2Tri.AdvancingFrontNode)val_1;
            //  |  // // {name=val_0, type=Pathfinding.Poly2Tri.AdvancingFrontNode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0273CE8C (41143948), len: 368  VirtAddr: 0x0273CE8C RVA: 0x0273CE8C token: 100663352 methodIndex: 21569 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.Poly2Tri.AdvancingFrontNode LocatePoint(Pathfinding.Poly2Tri.TriangulationPoint point)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Poly2Tri.AdvancingFrontNode val_3;
            // 0x0273CE8C: STP d9, d8, [sp, #-0x40]!  | stack[1152921509768222432] = ???;  stack[1152921509768222440] = ???;  //  dest_result_addr=1152921509768222432 |  dest_result_addr=1152921509768222440
            // 0x0273CE90: STP x22, x21, [sp, #0x10]  | stack[1152921509768222448] = ???;  stack[1152921509768222456] = ???;  //  dest_result_addr=1152921509768222448 |  dest_result_addr=1152921509768222456
            // 0x0273CE94: STP x20, x19, [sp, #0x20]  | stack[1152921509768222464] = ???;  stack[1152921509768222472] = ???;  //  dest_result_addr=1152921509768222464 |  dest_result_addr=1152921509768222472
            // 0x0273CE98: STP x29, x30, [sp, #0x30]  | stack[1152921509768222480] = ???;  stack[1152921509768222488] = ???;  //  dest_result_addr=1152921509768222480 |  dest_result_addr=1152921509768222488
            // 0x0273CE9C: ADD x29, sp, #0x30         | X29 = (1152921509768222432 + 48) = 1152921509768222480 (0x1000000133A45710);
            // 0x0273CEA0: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
            // 0x0273CEA4: LDRB w8, [x20, #0xb53]     | W8 = (bool)static_value_03743B53;       
            // 0x0273CEA8: MOV x21, x1                | X21 = point;//m1                        
            // 0x0273CEAC: MOV x19, x0                | X19 = 1152921509768234496 (0x1000000133A48600);//ML01
            // 0x0273CEB0: TBNZ w8, #0, #0x273cecc    | if (static_value_03743B53 == true) goto label_0;
            // 0x0273CEB4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0273CEB8: LDR x8, [x8, #0xad0]       | X8 = 0x2B8AA68;                         
            // 0x0273CEBC: LDR w0, [x8]               | W0 = 0x158;                             
            // 0x0273CEC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x158, ????);      
            // 0x0273CEC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0273CEC8: STRB w8, [x20, #0xb53]     | static_value_03743B53 = true;            //  dest_result_addr=57949011
            label_0:
            // 0x0273CECC: CBNZ x21, #0x273ced4       | if (point != null) goto label_1;        
            if(point != null)
            {
                goto label_1;
            }
            // 0x0273CED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_1:
            // 0x0273CED4: LDR d8, [x21, #0x10]       | D8 = point.X; //P2                      
            // 0x0273CED8: LDR x20, [x19, #0x20]      | X20 = this.Search; //P2                 
            val_3 = this.Search;
            // 0x0273CEDC: CBNZ x20, #0x273cee4       | if (this.Search != null) goto label_2;  
            if(val_3 != null)
            {
                goto label_2;
            }
            // 0x0273CEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_2:
            // 0x0273CEE4: LDR x22, [x20, #0x28]      | X22 = this.Search.Point; //P2           
            // 0x0273CEE8: CBNZ x22, #0x273cef0       | if (this.Search.Point != null) goto label_3;
            if(this.Search.Point != null)
            {
                goto label_3;
            }
            // 0x0273CEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_3:
            // 0x0273CEF0: LDR d0, [x22, #0x10]       | D0 = this.Search.Point.X; //P2          
            // 0x0273CEF4: FCMP d8, d0                | STATE = COMPARE(point.X, this.Search.Point.X)
            // 0x0273CEF8: B.NE #0x273cf50            | if (point.X != this.Search.Point.X) goto label_4;
            if(point.X != this.Search.Point.X)
            {
                goto label_4;
            }
            // 0x0273CEFC: CBNZ x20, #0x273cf04       | if (this.Search != null) goto label_5;  
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x0273CF00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_5:
            // 0x0273CF04: LDR x8, [x20, #0x28]       | X8 = this.Search.Point; //P2            
            // 0x0273CF08: CMP x8, x21                | STATE = COMPARE(this.Search.Point, point)
            // 0x0273CF0C: B.EQ #0x273cfa0            | if (this.Search.Point == point) goto label_22;
            if(this.Search.Point == point)
            {
                goto label_22;
            }
            // 0x0273CF10: LDR x22, [x20, #0x18]      | X22 = this.Search.Prev; //P2            
            // 0x0273CF14: CBNZ x22, #0x273cf1c       | if (this.Search.Prev != null) goto label_7;
            if(this.Search.Prev != null)
            {
                goto label_7;
            }
            // 0x0273CF18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_7:
            // 0x0273CF1C: LDR x8, [x22, #0x28]       | X8 = this.Search.Prev.Point; //P2       
            // 0x0273CF20: CMP x8, x21                | STATE = COMPARE(this.Search.Prev.Point, point)
            // 0x0273CF24: B.EQ #0x273cf9c            | if (this.Search.Prev.Point == point) goto label_8;
            if(this.Search.Prev.Point == point)
            {
                goto label_8;
            }
            // 0x0273CF28: LDR x22, [x20, #0x10]      | X22 = this.Search.Next; //P2            
            // 0x0273CF2C: CBNZ x22, #0x273cf34       | if (this.Search.Next != null) goto label_9;
            if(this.Search.Next != null)
            {
                goto label_9;
            }
            // 0x0273CF30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_9:
            // 0x0273CF34: LDR x8, [x22, #0x28]       | X8 = this.Search.Next.Point; //P2       
            // 0x0273CF38: CMP x8, x21                | STATE = COMPARE(this.Search.Next.Point, point)
            // 0x0273CF3C: B.NE #0x273cfbc            | if (this.Search.Next.Point != point) goto label_10;
            if(this.Search.Next.Point != point)
            {
                goto label_10;
            }
            // 0x0273CF40: CBNZ x20, #0x273cf48       | if (this.Search != null) goto label_11; 
            if(val_3 != null)
            {
                goto label_11;
            }
            // 0x0273CF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_11:
            // 0x0273CF48: LDR x20, [x20, #0x10]      | X20 = this.Search.Next; //P2            
            val_3 = this.Search.Next;
            // 0x0273CF4C: B #0x273cfa0               |  goto label_22;                         
            goto label_22;
            label_4:
            // 0x0273CF50: B.PL #0x273cf74            | if (point.X >= 0) goto label_20;        
            if(point.X >= 0)
            {
                goto label_20;
            }
            label_16:
            // 0x0273CF54: CBNZ x20, #0x273cf5c       | if (this.Search != null) goto label_14; 
            if(val_3 != null)
            {
                goto label_14;
            }
            // 0x0273CF58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_14:
            // 0x0273CF5C: LDR x20, [x20, #0x18]      | X20 = this.Search.Prev; //P2            
            val_3 = this.Search.Prev;
            // 0x0273CF60: CBZ x20, #0x273cf94        | if (this.Search.Prev == null) goto label_19;
            if(val_3 == null)
            {
                goto label_19;
            }
            // 0x0273CF64: LDR x8, [x20, #0x28]       | X8 = this.Search.Prev.Point; //P2       
            // 0x0273CF68: CMP x8, x21                | STATE = COMPARE(this.Search.Prev.Point, point)
            // 0x0273CF6C: B.NE #0x273cf54            | if (this.Search.Prev.Point != point) goto label_16;
            if(this.Search.Prev.Point != point)
            {
                goto label_16;
            }
            // 0x0273CF70: B #0x273cfa0               |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x0273CF74: CBNZ x20, #0x273cf7c       | if (this.Search != null) goto label_18; 
            if(val_3 != null)
            {
                goto label_18;
            }
            // 0x0273CF78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x158, ????);      
            label_18:
            // 0x0273CF7C: LDR x20, [x20, #0x10]      | X20 = this.Search.Next; //P2            
            val_3 = this.Search.Next;
            // 0x0273CF80: CBZ x20, #0x273cf94        | if (this.Search.Next == null) goto label_19;
            if(val_3 == null)
            {
                goto label_19;
            }
            // 0x0273CF84: LDR x8, [x20, #0x28]       | X8 = this.Search.Next.Point; //P2       
            // 0x0273CF88: CMP x8, x21                | STATE = COMPARE(this.Search.Next.Point, point)
            // 0x0273CF8C: B.NE #0x273cf74            | if (this.Search.Next.Point != point) goto label_20;
            if(this.Search.Next.Point != point)
            {
                goto label_20;
            }
            // 0x0273CF90: B #0x273cfa0               |  goto label_22;                         
            goto label_22;
            label_19:
            // 0x0273CF94: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x0273CF98: B #0x273cfa0               |  goto label_22;                         
            goto label_22;
            label_8:
            // 0x0273CF9C: LDR x20, [x20, #0x18]      | X20 = this.Search.Prev; //P2            
            val_3 = this.Search.Prev;
            label_22:
            // 0x0273CFA0: STR x20, [x19, #0x20]      | this.Search = this.Search.Prev;          //  dest_result_addr=1152921509768234528
            this.Search = val_3;
            // 0x0273CFA4: MOV x0, x20                | X0 = this.Search.Prev;//m1              
            // 0x0273CFA8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0273CFAC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0273CFB0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0273CFB4: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
            // 0x0273CFB8: RET                        |  return (Pathfinding.Poly2Tri.AdvancingFrontNode)this.Search.Prev;
            return (Pathfinding.Poly2Tri.AdvancingFrontNode)val_3;
            //  |  // // {name=val_0, type=Pathfinding.Poly2Tri.AdvancingFrontNode, size=8, nGRN=0 }
            label_10:
            // 0x0273CFBC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0273CFC0: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x0273CFC4: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x0273CFC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x0273CFCC: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x0273CFD0: LDR x8, [x8, #0x8d0]       | X8 = (string**)(1152921509768209312)("Failed to find Node for given afront point");
            // 0x0273CFD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0273CFD8: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0273CFDC: LDR x1, [x8]               | X1 = "Failed to find Node for given afront point";
            // 0x0273CFE0: BL #0x1c32b48              | .ctor(message:  "Failed to find Node for given afront point");
            val_1 = new System.Exception(message:  "Failed to find Node for given afront point");
            // 0x0273CFE4: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x0273CFE8: LDR x8, [x8, #0xce0]       | X8 = 1152921509768209472;               
            // 0x0273CFEC: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            Pathfinding.Poly2Tri.AdvancingFrontNode val_2 = val_1;
            // 0x0273CFF0: LDR x1, [x8]               | X1 = public Pathfinding.Poly2Tri.AdvancingFrontNode Pathfinding.Poly2Tri.AdvancingFront::LocatePoint(Pathfinding.Poly2Tri.TriangulationPoint point);
            // 0x0273CFF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x0273CFF8: BL #0x273cffc              | .ctor(point:  public Pathfinding.Poly2Tri.AdvancingFrontNode Pathfinding.Poly2Tri.AdvancingFront::LocatePoint(Pathfinding.Poly2Tri.TriangulationPoint point));
            val_2 = new Pathfinding.Poly2Tri.AdvancingFrontNode(point:  public Pathfinding.Poly2Tri.AdvancingFrontNode Pathfinding.Poly2Tri.AdvancingFront::LocatePoint(Pathfinding.Poly2Tri.TriangulationPoint point));
        
        }
    
    }

}
