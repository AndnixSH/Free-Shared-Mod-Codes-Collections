using UnityEngine;

namespace Newtonsoft.Json.ObservableSupport
{
    public sealed class AddingNewEventHandler : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x02936B20 (43215648), len: 16  VirtAddr: 0x02936B20 RVA: 0x02936B20 token: 100685895 methodIndex: 48496 delegateWrapperIndex: 0 methodInvoker: 0
        public AddingNewEventHandler(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x02936B20: LDR x8, [x2]               | X8 = method;                            
            // 0x02936B24: STP x1, x2, [x0, #0x20]    | mem[1152921513871932064] = object;  mem[1152921513871932072] = method;  //  dest_result_addr=1152921513871932064 |  dest_result_addr=1152921513871932072
            mem[1152921513871932064] = object;
            mem[1152921513871932072] = method;
            // 0x02936B28: STR x8, [x0, #0x10]        | mem[1152921513871932048] = method;       //  dest_result_addr=1152921513871932048
            mem[1152921513871932048] = method;
            // 0x02936B2C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x02936B30 (43215664), len: 968  VirtAddr: 0x02936B30 RVA: 0x02936B30 token: 100685896 methodIndex: 48497 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Invoke(object sender, Newtonsoft.Json.ObservableSupport.AddingNewEventArgs e)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            label_1:
            // 0x02936B30: STP x24, x23, [sp, #-0x40]! | stack[1152921513872060640] = ???;  stack[1152921513872060648] = ???;  //  dest_result_addr=1152921513872060640 |  dest_result_addr=1152921513872060648
            // 0x02936B34: STP x22, x21, [sp, #0x10]  | stack[1152921513872060656] = ???;  stack[1152921513872060664] = ???;  //  dest_result_addr=1152921513872060656 |  dest_result_addr=1152921513872060664
            // 0x02936B38: STP x20, x19, [sp, #0x20]  | stack[1152921513872060672] = ???;  stack[1152921513872060680] = ???;  //  dest_result_addr=1152921513872060672 |  dest_result_addr=1152921513872060680
            // 0x02936B3C: STP x29, x30, [sp, #0x30]  | stack[1152921513872060688] = ???;  stack[1152921513872060696] = ???;  //  dest_result_addr=1152921513872060688 |  dest_result_addr=1152921513872060696
            // 0x02936B40: ADD x29, sp, #0x30         | X29 = (1152921513872060640 + 48) = 1152921513872060688 (0x10000002283FF110);
            // 0x02936B44: SUB sp, sp, #0x10          | SP = (1152921513872060640 - 16) = 1152921513872060624 (0x10000002283FF0D0);
            // 0x02936B48: MOV x23, x0                | X23 = 1152921513872072704 (0x1000000228402000);//ML01
            // 0x02936B4C: LDR x0, [x23, #0x58]       | 
            // 0x02936B50: MOV x19, x2                | X19 = e;//m1                            
            // 0x02936B54: MOV x20, x1                | X20 = sender;//m1                       
            // 0x02936B58: CBZ x0, #0x2936b68         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x02936B5C: MOV x1, x20                | X1 = sender;//m1                        
            // 0x02936B60: MOV x2, x19                | X2 = e;//m1                             
            val_13 = e;
            // 0x02936B64: BL #0x2936b30              |  R0 = label_1();                        
            label_0:
            // 0x02936B68: LDR x0, [x23, #0x10]       | 
            // 0x02936B6C: STR x0, [sp, #8]           | stack[1152921513872060632] = this;       //  dest_result_addr=1152921513872060632
            // 0x02936B70: LDP x22, x21, [x23, #0x20] |                                          //  | 
            // 0x02936B74: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936B78: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
            // 0x02936B7C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936B80: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
            // 0x02936B84: LDRB w9, [x21, #0x4e]      | W9 = X21 + 78;                          
            // 0x02936B88: AND w8, w0, #1             | W8 = (X21 & 1);                         
            var val_1 = X21 & 1;
            // 0x02936B8C: TBZ w8, #0, #0x2936c28     | if (((X21 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x02936B90: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x02936B94: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
            // 0x02936B98: B.NE #0x2936c38            | if (X21 + 78 != 0x2) goto label_3;      
            if((X21 + 78) != 2)
            {
                goto label_3;
            }
            // 0x02936B9C: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x02936BA0: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
            // 0x02936BA4: B.EQ #0x2936cf4            | if (X21 + 76 == 65535) goto label_7;    
            if((X21 + 76) == 65535)
            {
                goto label_7;
            }
            // 0x02936BA8: CBZ x22, #0x2936bb8        | if (X22 == 0) goto label_5;             
            if(X22 == 0)
            {
                goto label_5;
            }
            // 0x02936BAC: LDR x8, [x22]              | X8 = X22;                               
            // 0x02936BB0: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
            // 0x02936BB4: TBNZ w8, #0, #0x2936cf4    | if ((X22 + 237 & 0x1) != 0) goto label_7;
            if(((X22 + 237) & 1) != 0)
            {
                goto label_7;
            }
            label_5:
            // 0x02936BB8: LDR x8, [x23, #0x18]       | 
            // 0x02936BBC: CBZ x8, #0x2936cf4         | if (X22 + 237 == 0) goto label_7;       
            if((X22 + 237) == 0)
            {
                goto label_7;
            }
            // 0x02936BC0: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936BC4: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x02936BC8: MOV w23, w0                | W23 = X21;//m1                          
            // 0x02936BCC: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936BD0: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X21.pressedSprite;
            // 0x02936BD4: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x02936BD8: TBZ w23, #0, #0x2936d48    | if ((X21 & 0x1) == 0) goto label_8;     
            if((X21 & 1) == 0)
            {
                goto label_8;
            }
            // 0x02936BDC: TBZ w0, #0, #0x2936e00     | if ((val_2 & 0x1) == 0) goto label_9;   
            if((val_2 & 1) == 0)
            {
                goto label_9;
            }
            // 0x02936BE0: LDR x8, [x22]              | X8 = X22;                               
            var val_19 = X22;
            // 0x02936BE4: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x02936BE8: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x02936BEC: LDRH w9, [x8, #0x102]      | W9 = X22 + 258;                         
            // 0x02936BF0: CBZ x9, #0x2936c1c         | if (X22 + 258 == 0) goto label_10;      
            if((X22 + 258) == 0)
            {
                goto label_10;
            }
            // 0x02936BF4: LDR x10, [x8, #0x98]       | X10 = X22 + 152;                        
            var val_11 = X22 + 152;
            // 0x02936BF8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x02936BFC: ADD x10, x10, #8           | X10 = (X22 + 152 + 8);                  
            val_11 = val_11 + 8;
            label_12:
            // 0x02936C00: LDUR x12, [x10, #-8]       | X12 = (X22 + 152 + 8) + -8;             
            // 0x02936C04: CMP x12, x1                | STATE = COMPARE((X22 + 152 + 8) + -8, X21 + 24)
            // 0x02936C08: B.EQ #0x2936e48            | if ((X22 + 152 + 8) + -8 == X21 + 24) goto label_11;
            if(((X22 + 152 + 8) + -8) == (X21 + 24))
            {
                goto label_11;
            }
            // 0x02936C0C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x02936C10: ADD x10, x10, #0x10        | X10 = ((X22 + 152 + 8) + 16);           
            val_11 = val_11 + 16;
            // 0x02936C14: CMP x11, x9                | STATE = COMPARE((0 + 1), X22 + 258)     
            // 0x02936C18: B.LO #0x2936c00            | if (0 < X22 + 258) goto label_12;       
            if(val_12 < (X22 + 258))
            {
                goto label_12;
            }
            label_10:
            // 0x02936C1C: MOV x0, x22                | X0 = X22;//m1                           
            val_14 = X22;
            // 0x02936C20: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
            // 0x02936C24: B #0x2936e58               |  goto label_13;                         
            goto label_13;
            label_2:
            // 0x02936C28: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
            // 0x02936C2C: B.NE #0x2936cc4            | if (X21 + 78 != 0x2) goto label_14;     
            if((X21 + 78) != 2)
            {
                goto label_14;
            }
            // 0x02936C30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02936C34: B #0x2936cf8               |  goto label_15;                         
            goto label_15;
            label_3:
            // 0x02936C38: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
            // 0x02936C3C: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
            // 0x02936C40: B.EQ #0x2936d20            | if (X21 + 76 == 65535) goto label_19;   
            if((X21 + 76) == 65535)
            {
                goto label_19;
            }
            // 0x02936C44: CBZ x22, #0x2936c54        | if (X22 == 0) goto label_17;            
            if(X22 == 0)
            {
                goto label_17;
            }
            // 0x02936C48: LDR x8, [x22]              | X8 = X22;                               
            // 0x02936C4C: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
            // 0x02936C50: TBNZ w8, #0, #0x2936d20    | if ((X22 + 237 & 0x1) != 0) goto label_19;
            if(((X22 + 237) & 1) != 0)
            {
                goto label_19;
            }
            label_17:
            // 0x02936C54: LDR x8, [x23, #0x18]       | 
            // 0x02936C58: CBZ x8, #0x2936d20         | if (X22 + 237 == 0) goto label_19;      
            if((X22 + 237) == 0)
            {
                goto label_19;
            }
            // 0x02936C5C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936C60: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x02936C64: MOV w22, w0                | W22 = X21;//m1                          
            // 0x02936C68: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936C6C: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X21.pressedSprite;
            // 0x02936C70: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
            // 0x02936C74: TBZ w22, #0, #0x2936da4    | if ((X21 & 0x1) == 0) goto label_20;    
            if((X21 & 1) == 0)
            {
                goto label_20;
            }
            // 0x02936C78: TBZ w0, #0, #0x2936e14     | if ((val_3 & 0x1) == 0) goto label_21;  
            if((val_3 & 1) == 0)
            {
                goto label_21;
            }
            // 0x02936C7C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x02936C80: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x02936C84: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x02936C88: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x02936C8C: CBZ x9, #0x2936cb8         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
            // 0x02936C90: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x02936C94: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x02936C98: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_24:
            // 0x02936C9C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x02936CA0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X21 + 24)
            // 0x02936CA4: B.EQ #0x2936e80            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X21 + 24) goto label_23;
            // 0x02936CA8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x02936CAC: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x02936CB0: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x02936CB4: B.LO #0x2936c9c            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_24;
            label_22:
            // 0x02936CB8: MOV x0, x20                | X0 = sender;//m1                        
            val_15 = sender;
            // 0x02936CBC: BL #0x2776c24              | X0 = sub_2776C24( ?? sender, ????);     
            // 0x02936CC0: B #0x2936e90               |  goto label_25;                         
            goto label_25;
            label_14:
            // 0x02936CC4: LDR x5, [sp, #8]           | X5 = this;                              
            // 0x02936CC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02936CCC: MOV x1, x22                | X1 = X22;//m1                           
            // 0x02936CD0: MOV x2, x20                | X2 = sender;//m1                        
            // 0x02936CD4: MOV x3, x19                | X3 = e;//m1                             
            // 0x02936CD8: MOV x4, x21                | X4 = X21;//m1                           
            // 0x02936CDC: SUB sp, x29, #0x30         | SP = (1152921513872060688 - 48) = 1152921513872060640 (0x10000002283FF0E0);
            // 0x02936CE0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02936CE4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02936CE8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02936CEC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02936CF0: BR x5                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x02936CF4: MOV x0, x22                | X0 = X22;//m1                           
            label_15:
            // 0x02936CF8: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x02936CFC: MOV x1, x20                | X1 = sender;//m1                        
            // 0x02936D00: MOV x2, x19                | X2 = e;//m1                             
            // 0x02936D04: MOV x3, x21                | X3 = X21;//m1                           
            label_42:
            // 0x02936D08: SUB sp, x29, #0x30         | SP = (1152921513872060688 - 48) = 1152921513872060640 (0x10000002283FF0E0);
            // 0x02936D0C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02936D10: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02936D14: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02936D18: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02936D1C: BR x4                      | X0 = this( ?? X22, ????);               
            label_19:
            // 0x02936D20: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x02936D24: MOV x0, x20                | X0 = sender;//m1                        
            // 0x02936D28: MOV x1, x19                | X1 = e;//m1                             
            // 0x02936D2C: MOV x2, x21                | X2 = X21;//m1                           
            label_43:
            // 0x02936D30: SUB sp, x29, #0x30         | SP = (1152921513872060688 - 48) = 1152921513872060640 (0x10000002283FF0E0);
            // 0x02936D34: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02936D38: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02936D3C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02936D40: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02936D44: BR x3                      | X0 = this( ?? sender, ????);            
            label_8:
            // 0x02936D48: LDRH w23, [x21, #0x4c]     | W23 = X21 + 76;                         
            // 0x02936D4C: TBZ w0, #0, #0x2936e28     | if ((val_2 & 0x1) == 0) goto label_26;  
            if((val_2 & 1) == 0)
            {
                goto label_26;
            }
            // 0x02936D50: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936D54: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_4 = X21.pressedSprite;
            // 0x02936D58: LDR x9, [x22]              | X9 = X22;                               
            // 0x02936D5C: MOV x8, x0                 | X8 = val_4;//m1                         
            // 0x02936D60: LDRH w10, [x9, #0x102]     | W10 = X22 + 258;                        
            // 0x02936D64: CBZ x10, #0x2936d90        | if (X22 + 258 == 0) goto label_27;      
            if((X22 + 258) == 0)
            {
                goto label_27;
            }
            // 0x02936D68: LDR x11, [x9, #0x98]       | X11 = X22 + 152;                        
            var val_14 = X22 + 152;
            // 0x02936D6C: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x02936D70: ADD x11, x11, #8           | X11 = (X22 + 152 + 8);                  
            val_14 = val_14 + 8;
            label_29:
            // 0x02936D74: LDUR x13, [x11, #-8]       | X13 = (X22 + 152 + 8) + -8;             
            // 0x02936D78: CMP x13, x8                | STATE = COMPARE((X22 + 152 + 8) + -8, val_4)
            // 0x02936D7C: B.EQ #0x2936eb4            | if ((X22 + 152 + 8) + -8 == val_4) goto label_28;
            if(((X22 + 152 + 8) + -8) == val_4)
            {
                goto label_28;
            }
            // 0x02936D80: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x02936D84: ADD x11, x11, #0x10        | X11 = ((X22 + 152 + 8) + 16);           
            val_14 = val_14 + 16;
            // 0x02936D88: CMP x12, x10               | STATE = COMPARE((0 + 1), X22 + 258)     
            // 0x02936D8C: B.LO #0x2936d74            | if (0 < X22 + 258) goto label_29;       
            if(val_15 < (X22 + 258))
            {
                goto label_29;
            }
            label_27:
            // 0x02936D90: MOV x0, x22                | X0 = X22;//m1                           
            val_16 = X22;
            // 0x02936D94: MOV x1, x8                 | X1 = val_4;//m1                         
            // 0x02936D98: MOV w2, w23                | W2 = X21 + 76;//m1                      
            // 0x02936D9C: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
            // 0x02936DA0: B #0x2936ec4               |  goto label_30;                         
            goto label_30;
            label_20:
            // 0x02936DA4: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
            // 0x02936DA8: TBZ w0, #0, #0x2936e38     | if ((val_3 & 0x1) == 0) goto label_31;  
            if((val_3 & 1) == 0)
            {
                goto label_31;
            }
            // 0x02936DAC: MOV x0, x21                | X0 = X21;//m1                           
            // 0x02936DB0: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_5 = X21.pressedSprite;
            // 0x02936DB4: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x02936DB8: MOV x8, x0                 | X8 = val_5;//m1                         
            // 0x02936DBC: LDRH w10, [x9, #0x102]     | W10 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x02936DC0: CBZ x10, #0x2936dec        | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
            // 0x02936DC4: LDR x11, [x9, #0x98]       | X11 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x02936DC8: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_16 = 0;
            // 0x02936DCC: ADD x11, x11, #8           | X11 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_34:
            // 0x02936DD0: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x02936DD4: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_5)
            // 0x02936DD8: B.EQ #0x2936ed8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_5) goto label_33;
            // 0x02936DDC: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x02936DE0: ADD x11, x11, #0x10        | X11 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x02936DE4: CMP x12, x10               | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x02936DE8: B.LO #0x2936dd0            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_34;
            label_32:
            // 0x02936DEC: MOV x0, x20                | X0 = sender;//m1                        
            val_17 = sender;
            // 0x02936DF0: MOV x1, x8                 | X1 = val_5;//m1                         
            // 0x02936DF4: MOV w2, w22                | W2 = X21 + 76;//m1                      
            val_13 = X21 + 76;
            // 0x02936DF8: BL #0x2776c24              | X0 = sub_2776C24( ?? sender, ????);     
            // 0x02936DFC: B #0x2936ee8               |  goto label_35;                         
            goto label_35;
            label_9:
            // 0x02936E00: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x02936E04: LDR x9, [x22]              | X9 = X22;                               
            // 0x02936E08: ADD x8, x9, x8, lsl #4     | X8 = (X22 + (X21 + 76) << 4);           
            var val_6 = X22 + ((X21 + 76) << 4);
            // 0x02936E0C: LDR x0, [x8, #0x118]       | X0 = (X22 + (X21 + 76) << 4) + 280;     
            val_18 = mem[(X22 + (X21 + 76) << 4) + 280];
            val_18 = (X22 + (X21 + 76) << 4) + 280;
            // 0x02936E10: B #0x2936e5c               |  goto label_36;                         
            goto label_36;
            label_21:
            // 0x02936E14: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x02936E18: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x02936E1C: ADD x8, x9, x8, lsl #4     | X8 = (1152921504606900224 + (X21 + 76) << 4);
            object val_7 = 1152921504606900224 + ((X21 + 76) << 4);
            // 0x02936E20: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
            val_19 = mem[(1152921504606900224 + (X21 + 76) << 4) + 280];
            // 0x02936E24: B #0x2936e94               |  goto label_37;                         
            goto label_37;
            label_26:
            // 0x02936E28: LDR x8, [x22]              | X8 = X22;                               
            var val_17 = X22;
            // 0x02936E2C: ADD x8, x8, w23, uxtw #4   | X8 = (X22 + X21 + 76);                  
            val_17 = val_17 + (X21 + 76);
            // 0x02936E30: LDP x4, x3, [x8, #0x110]   | X4 = (X22 + X21 + 76) + 272; X3 = (X22 + X21 + 76) + 272 + 8; //  | 
            // 0x02936E34: B #0x2936ec8               |  goto label_38;                         
            goto label_38;
            label_31:
            // 0x02936E38: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x02936E3C: ADD x8, x8, w22, uxtw #4   | X8 = (1152921504606900224 + X21 + 76);  
            object val_8 = 1152921504606900224 + (X21 + 76);
            // 0x02936E40: LDP x3, x2, [x8, #0x110]   |                                          //  not_find_field!1:272 |  not_find_field!1:280
            // 0x02936E44: B #0x2936eec               |  goto label_39;                         
            goto label_39;
            label_11:
            // 0x02936E48: LDR w9, [x10]              | W9 = (X22 + 152 + 8);                   
            var val_18 = val_11;
            // 0x02936E4C: ADD w9, w9, w2             | W9 = ((X22 + 152 + 8) + X21 + 76);      
            val_18 = val_18 + (X21 + 76);
            // 0x02936E50: ADD x8, x8, w9, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
            val_19 = val_19 + val_18;
            // 0x02936E54: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
            val_14 = val_19 + 272;
            label_13:
            // 0x02936E58: LDR x0, [x0, #8]           | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            val_18 = mem[((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8];
            val_18 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            label_36:
            // 0x02936E5C: MOV x1, x21                | X1 = X21;//m1                           
            // 0x02936E60: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
            // 0x02936E64: MOV x8, x0                 | X8 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x02936E68: LDR x4, [x8]               | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
            // 0x02936E6C: MOV x0, x22                | X0 = X22;//m1                           
            // 0x02936E70: MOV x1, x20                | X1 = sender;//m1                        
            // 0x02936E74: MOV x2, x19                | X2 = e;//m1                             
            // 0x02936E78: MOV x3, x8                 | X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x02936E7C: B #0x2936d08               |  goto label_42;                         
            goto label_42;
            label_23:
            // 0x02936E80: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x02936E84: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
            // 0x02936E88: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
            // 0x02936E8C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
            label_25:
            // 0x02936E90: LDR x0, [x0, #8]           | 
            label_37:
            // 0x02936E94: MOV x1, x21                | X1 = X21;//m1                           
            // 0x02936E98: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_3, ????);      
            // 0x02936E9C: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x02936EA0: LDR x3, [x8]               | X3 = typeof(UnityEngine.Sprite);        
            // 0x02936EA4: MOV x0, x20                | X0 = sender;//m1                        
            // 0x02936EA8: MOV x1, x19                | X1 = e;//m1                             
            // 0x02936EAC: MOV x2, x8                 | X2 = val_3;//m1                         
            // 0x02936EB0: B #0x2936d30               |  goto label_43;                         
            goto label_43;
            label_28:
            // 0x02936EB4: LDR w8, [x11]              | W8 = (X22 + 152 + 8);                   
            var val_20 = val_14;
            // 0x02936EB8: ADD w8, w8, w23            | W8 = ((X22 + 152 + 8) + X21 + 76);      
            val_20 = val_20 + (X21 + 76);
            // 0x02936EBC: ADD x8, x9, w8, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
            val_20 = X22 + val_20;
            // 0x02936EC0: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
            val_16 = val_20 + 272;
            label_30:
            // 0x02936EC4: LDP x4, x3, [x0]           | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272); X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
            label_38:
            // 0x02936EC8: MOV x0, x22                | X0 = X22;//m1                           
            // 0x02936ECC: MOV x1, x20                | X1 = sender;//m1                        
            // 0x02936ED0: MOV x2, x19                | X2 = e;//m1                             
            // 0x02936ED4: B #0x2936d08               |  goto label_42;                         
            goto label_42;
            label_33:
            // 0x02936ED8: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x02936EDC: ADD w8, w8, w22            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
            // 0x02936EE0: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
            // 0x02936EE4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
            label_35:
            // 0x02936EE8: LDP x3, x2, [x0]           | X3 = typeof(UnityEngine.Sprite);         //  | 
            label_39:
            // 0x02936EEC: MOV x0, x20                | X0 = sender;//m1                        
            // 0x02936EF0: MOV x1, x19                | X1 = e;//m1                             
            // 0x02936EF4: B #0x2936d30               |  goto label_43;                         
            goto label_43;
        
        }
        //
        // Offset in libil2cpp.so: 0x02936EF8 (43216632), len: 52  VirtAddr: 0x02936EF8 RVA: 0x02936EF8 token: 100685897 methodIndex: 48498 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(object sender, Newtonsoft.Json.ObservableSupport.AddingNewEventArgs e, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x02936EF8: STP x29, x30, [sp, #-0x10]! | stack[1152921513872213648] = ???;  stack[1152921513872213656] = ???;  //  dest_result_addr=1152921513872213648 |  dest_result_addr=1152921513872213656
            // 0x02936EFC: MOV x29, sp                | X29 = 1152921513872213648 (0x1000000228424690);//ML01
            // 0x02936F00: SUB sp, sp, #0x20          | SP = (1152921513872213648 - 32) = 1152921513872213616 (0x1000000228424670);
            // 0x02936F04: STP xzr, xzr, [sp, #0x10]  | stack[1152921513872213632] = 0x0;  stack[1152921513872213640] = 0x0;  //  dest_result_addr=1152921513872213632 |  dest_result_addr=1152921513872213640
            // 0x02936F08: STP xzr, x2, [sp, #8]      | stack[1152921513872213624] = 0x0;  stack[1152921513872213632] = e;  //  dest_result_addr=1152921513872213624 |  dest_result_addr=1152921513872213632
            // 0x02936F0C: STR x1, [sp, #8]           | stack[1152921513872213624] = sender;     //  dest_result_addr=1152921513872213624
            // 0x02936F10: ADD x1, sp, #8             | X1 = (1152921513872213616 + 8) = 1152921513872213624 (0x1000000228424678);
            // 0x02936F14: MOV x2, x3                 | X2 = callback;//m1                      
            // 0x02936F18: MOV x3, x4                 | X3 = object;//m1                        
            // 0x02936F1C: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x02936F20: MOV sp, x29                | SP = 1152921513872213648 (0x1000000228424690);//ML01
            // 0x02936F24: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x02936F28: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02936F2C (43216684), len: 16  VirtAddr: 0x02936F2C RVA: 0x02936F2C token: 100685898 methodIndex: 48499 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void EndInvoke(System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x02936F2C: MOV x8, x1                 | X8 = result;//m1                        
            // 0x02936F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02936F34: MOV x0, x8                 | X0 = result;//m1                        
            // 0x02936F38: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
        
        }
    
    }

}
