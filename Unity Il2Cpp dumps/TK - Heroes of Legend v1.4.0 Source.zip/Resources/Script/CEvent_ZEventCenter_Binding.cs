using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CEvent_ZEventCenter_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0143A520 (21210400), len: 8  VirtAddr: 0x0143A520 RVA: 0x0143A520 token: 100664210 methodIndex: 30257 delegateWrapperIndex: 0 methodInvoker: 0
        public CEvent_ZEventCenter_Binding()
        {
            //
            // Disasemble & Code
            // 0x0143A520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A524: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0143A528 (21210408), len: 1820  VirtAddr: 0x0143A528 RVA: 0x0143A528 token: 100664211 methodIndex: 30258 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            var val_18;
            //  | 
            System.Type[] val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            string val_22;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_24;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_26;
            // 0x0143A528: STP x28, x27, [sp, #-0x60]! | stack[1152921510120032576] = ???;  stack[1152921510120032584] = ???;  //  dest_result_addr=1152921510120032576 |  dest_result_addr=1152921510120032584
            // 0x0143A52C: STP x26, x25, [sp, #0x10]  | stack[1152921510120032592] = ???;  stack[1152921510120032600] = ???;  //  dest_result_addr=1152921510120032592 |  dest_result_addr=1152921510120032600
            // 0x0143A530: STP x24, x23, [sp, #0x20]  | stack[1152921510120032608] = ???;  stack[1152921510120032616] = ???;  //  dest_result_addr=1152921510120032608 |  dest_result_addr=1152921510120032616
            // 0x0143A534: STP x22, x21, [sp, #0x30]  | stack[1152921510120032624] = ???;  stack[1152921510120032632] = ???;  //  dest_result_addr=1152921510120032624 |  dest_result_addr=1152921510120032632
            // 0x0143A538: STP x20, x19, [sp, #0x40]  | stack[1152921510120032640] = ???;  stack[1152921510120032648] = ???;  //  dest_result_addr=1152921510120032640 |  dest_result_addr=1152921510120032648
            // 0x0143A53C: STP x29, x30, [sp, #0x50]  | stack[1152921510120032656] = ???;  stack[1152921510120032664] = ???;  //  dest_result_addr=1152921510120032656 |  dest_result_addr=1152921510120032664
            // 0x0143A540: ADD x29, sp, #0x50         | X29 = (1152921510120032576 + 80) = 1152921510120032656 (0x10000001489C8990);
            // 0x0143A544: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143A548: LDRB w8, [x20, #0x6e]      | W8 = (bool)static_value_0373706E;       
            // 0x0143A54C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143A550: TBNZ w8, #0, #0x143a56c    | if (static_value_0373706E == true) goto label_0;
            // 0x0143A554: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x0143A558: LDR x8, [x8, #0x3a8]       | X8 = 0x2B9051C;                         
            // 0x0143A55C: LDR w0, [x8]               | W0 = 0x180B;                            
            // 0x0143A560: BL #0x2782188              | X0 = sub_2782188( ?? 0x180B, ????);     
            // 0x0143A564: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143A568: STRB w8, [x20, #0x6e]      | static_value_0373706E = true;            //  dest_result_addr=57897070
            label_0:
            // 0x0143A56C: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x0143A570: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            val_18 = 1152921504609562624;
            // 0x0143A574: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0143A578: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x0143A57C: LDR x8, [x8, #0x3a0]       | X8 = 1152921504898379776;               
            // 0x0143A580: LDR x20, [x8]              | X20 = typeof(CEvent.ZEventCenter);      
            // 0x0143A584: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143A588: TBZ w8, #0, #0x143a598     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0143A58C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143A590: CBNZ w8, #0x143a598        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0143A594: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0143A598: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A59C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A5A0: MOV x1, x20                | X1 = 1152921504898379776 (0x1000000011607000);//ML01
            // 0x0143A5A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A5A8: ADRP x28, #0x35ef000       | X28 = 56553472 (0x35EF000);             
            // 0x0143A5AC: LDR x28, [x28, #0xff0]     | X28 = 1152921504987155056;              
            val_19 = 1152921504987155056;
            // 0x0143A5B0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x0143A5B4: LDR x21, [x28]             | X21 = typeof(System.Type[]);            
            // 0x0143A5B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A5BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0143A5C0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0143A5C4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A5C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0143A5CC: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x0143A5D0: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            val_20 = 1152921504608284672;
            // 0x0143A5D4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A5D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A5DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A5E0: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x0143A5E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A5E8: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x0143A5EC: CBNZ x21, #0x143a5f4       | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x0143A5F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x0143A5F4: CBZ x22, #0x143a618        | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x0143A5F8: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143A5FC: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x0143A600: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143A604: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x0143A608: CBNZ x0, #0x143a618        | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x0143A60C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x0143A610: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A614: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x0143A618: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143A61C: CBNZ w8, #0x143a62c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x0143A620: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x0143A624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x0143A62C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x0143A630: ADRP x23, #0x365c000       | X23 = 56999936 (0x365C000);             
            // 0x0143A634: LDR x23, [x23, #0x748]     | X23 = 1152921504898113536;              
            val_21 = 1152921504898113536;
            // 0x0143A638: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A63C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A640: LDR x1, [x23]              | X1 = typeof(CEvent.EventFunc<T>);       
            // 0x0143A644: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A648: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0143A64C: CBZ x22, #0x143a670        | if (val_3 == null) goto label_8;        
            if(val_3 == null)
            {
                goto label_8;
            }
            // 0x0143A650: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143A654: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x0143A658: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143A65C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x0143A660: CBNZ x0, #0x143a670        | if (val_3 != null) goto label_8;        
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x0143A664: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x0143A668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A66C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_8:
            // 0x0143A670: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143A674: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0143A678: B.HI #0x143a688            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_9;
            // 0x0143A67C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x0143A680: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A684: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_9:
            // 0x0143A688: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_3;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_3;
            // 0x0143A68C: CBNZ x20, #0x143a694       | if (val_1 != null) goto label_10;       
            if(val_1 != null)
            {
                goto label_10;
            }
            // 0x0143A690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x0143A694: ADRP x26, #0x35d7000       | X26 = 56455168 (0x35D7000);             
            // 0x0143A698: LDR x26, [x26, #0xed8]     | X26 = (string**)(1152921510119975296)("AddEventListener");
            val_22 = "AddEventListener";
            // 0x0143A69C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A6A0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143A6A4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143A6A8: LDR x1, [x26]              | X1 = "AddEventListener";                
            // 0x0143A6AC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143A6B0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A6B4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0143A6B8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "AddEventListener", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "AddEventListener", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0143A6BC: ADRP x24, #0x364c000       | X24 = 56934400 (0x364C000);             
            // 0x0143A6C0: LDR x24, [x24, #0x468]     | X24 = 1152921504783843328;              
            // 0x0143A6C4: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x0143A6C8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143A6CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143A6D0: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache0;
            val_23 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache0;
            // 0x0143A6D4: CBNZ x22, #0x143a748       | if (ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache0 != null) goto label_11;
            if(val_23 != null)
            {
                goto label_11;
            }
            // 0x0143A6D8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143A6DC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0143A6E0: LDR x8, [x8, #0xae8]       | X8 = 1152921510119979504;               
            // 0x0143A6E4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0143A6E8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0143A6EC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_5 = null;
            // 0x0143A6F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0143A6F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A6F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A6FC: MOV x2, x22                | X2 = 1152921510119979504 (0x10000001489BB9F0);//ML01
            // 0x0143A700: MOV x26, x28               | X26 = 57978136 (0x374AD18);//ML01       
            // 0x0143A704: MOV x28, x25               | X28 = 57977376 (0x374AA20);//ML01       
            // 0x0143A708: MOV x25, x27               | X25 = 57965408 (0x3747B60);//ML01       
            // 0x0143A70C: MOV x27, x23               | X27 = 57967872 (0x3748500);//ML01       
            // 0x0143A710: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143A714: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0143A718: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143A71C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143A720: STR x23, [x8]              | ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783847424
            ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache0 = val_5;
            // 0x0143A724: MOV x23, x27               | X23 = 57967872 (0x3748500);//ML01       
            val_21 = val_21;
            // 0x0143A728: MOV x27, x25               | X27 = 57965408 (0x3747B60);//ML01       
            val_20 = val_20;
            // 0x0143A72C: MOV x25, x28               | X25 = 57977376 (0x374AA20);//ML01       
            val_18 = val_18;
            // 0x0143A730: MOV x28, x26               | X28 = 57978136 (0x374AD18);//ML01       
            val_19 = val_19;
            // 0x0143A734: ADRP x26, #0x35d7000       | X26 = 56455168 (0x35D7000);             
            // 0x0143A738: LDR x26, [x26, #0xed8]     | X26 = (string**)(1152921510119975296)("AddEventListener");
            val_22 = "AddEventListener";
            // 0x0143A73C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143A740: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143A744: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_23 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache0;
            label_11:
            // 0x0143A748: CBNZ x19, #0x143a750       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x0143A74C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_12:
            // 0x0143A750: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A754: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143A758: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x0143A75C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143A760: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_23);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_23);
            // 0x0143A764: LDR x21, [x28]             | X21 = typeof(System.Type[]);            
            // 0x0143A768: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A76C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0143A770: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x0143A774: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A778: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0143A77C: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x0143A780: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x0143A784: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A788: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143A78C: TBZ w9, #0, #0x143a7a0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x0143A790: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143A794: CBNZ w9, #0x143a7a0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x0143A798: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143A79C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_14:
            // 0x0143A7A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A7A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A7A8: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0143A7AC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A7B0: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x0143A7B4: CBNZ x21, #0x143a7bc       | if ( != null) goto label_15;            
            if(null != null)
            {
                goto label_15;
            }
            // 0x0143A7B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x0143A7BC: CBZ x22, #0x143a7e0        | if (val_6 == null) goto label_17;       
            if(val_6 == null)
            {
                goto label_17;
            }
            // 0x0143A7C0: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143A7C4: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x0143A7C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143A7CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x0143A7D0: CBNZ x0, #0x143a7e0        | if (val_6 != null) goto label_17;       
            if(val_6 != null)
            {
                goto label_17;
            }
            // 0x0143A7D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x0143A7D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A7DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_17:
            // 0x0143A7E0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143A7E4: CBNZ w8, #0x143a7f4        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_18;
            // 0x0143A7E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x0143A7EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A7F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_18:
            // 0x0143A7F4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_6;
            // 0x0143A7F8: LDR x1, [x23]              | X1 = typeof(CEvent.EventFunc<T>);       
            // 0x0143A7FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A804: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A808: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x0143A80C: CBZ x22, #0x143a830        | if (val_7 == null) goto label_20;       
            if(val_7 == null)
            {
                goto label_20;
            }
            // 0x0143A810: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143A814: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x0143A818: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143A81C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x0143A820: CBNZ x0, #0x143a830        | if (val_7 != null) goto label_20;       
            if(val_7 != null)
            {
                goto label_20;
            }
            // 0x0143A824: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x0143A828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A82C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_20:
            // 0x0143A830: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143A834: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0143A838: B.HI #0x143a848            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_21;
            // 0x0143A83C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x0143A840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_21:
            // 0x0143A848: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_7;
            // 0x0143A84C: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x0143A850: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x0143A854: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A858: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A85C: LDR x1, [x8]               | X1 = typeof(System.Boolean);            
            // 0x0143A860: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A864: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0143A868: CBZ x22, #0x143a88c        | if (val_8 == null) goto label_23;       
            if(val_8 == null)
            {
                goto label_23;
            }
            // 0x0143A86C: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143A870: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x0143A874: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143A878: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x0143A87C: CBNZ x0, #0x143a88c        | if (val_8 != null) goto label_23;       
            if(val_8 != null)
            {
                goto label_23;
            }
            // 0x0143A880: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x0143A884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A888: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_23:
            // 0x0143A88C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143A890: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x0143A894: B.HI #0x143a8a4            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_24;
            // 0x0143A898: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x0143A89C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A8A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_24:
            // 0x0143A8A4: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_8;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_8;
            // 0x0143A8A8: CBNZ x20, #0x143a8b0       | if (val_1 != null) goto label_25;       
            if(val_1 != null)
            {
                goto label_25;
            }
            // 0x0143A8AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_25:
            // 0x0143A8B0: LDR x1, [x26]              | X1 = "AddEventListener";                
            // 0x0143A8B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A8B8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143A8BC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143A8C0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143A8C4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A8C8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0143A8CC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  val_22 = "AddEventListener", bindingAttr:  30, binder:  0, types:  val_19, modifiers:  0);
            System.Reflection.MethodInfo val_9 = val_1.GetMethod(name:  val_22, bindingAttr:  30, binder:  0, types:  val_19, modifiers:  0);
            // 0x0143A8D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143A8D4: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x0143A8D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143A8DC: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache1;
            val_24 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache1;
            // 0x0143A8E0: CBNZ x22, #0x143a934       | if (ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache1 != null) goto label_26;
            if(val_24 != null)
            {
                goto label_26;
            }
            // 0x0143A8E4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x0143A8E8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0143A8EC: LDR x8, [x8, #0x958]       | X8 = 1152921510119996912;               
            // 0x0143A8F0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0143A8F4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0143A8F8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_10 = null;
            // 0x0143A8FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0143A900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A904: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A908: MOV x2, x22                | X2 = 1152921510119996912 (0x10000001489BFDF0);//ML01
            // 0x0143A90C: MOV x26, x23               | X26 = 57967872 (0x3748500);//ML01       
            // 0x0143A910: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143A914: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0143A918: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143A91C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143A920: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783847432
            ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache1 = val_10;
            // 0x0143A924: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143A928: MOV x23, x26               | X23 = 57967872 (0x3748500);//ML01       
            val_21 = val_21;
            // 0x0143A92C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143A930: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_24 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache1;
            label_26:
            // 0x0143A934: CBNZ x19, #0x143a93c       | if (X1 != 0) goto label_27;             
            if(X1 != 0)
            {
                goto label_27;
            }
            // 0x0143A938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::AddEventListener_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_27:
            // 0x0143A93C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A940: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143A944: MOV x1, x21                | X1 = val_9;//m1                         
            // 0x0143A948: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143A94C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_9, func:  val_24);
            X1.RegisterCLRMethodRedirection(mi:  val_9, func:  val_24);
            // 0x0143A950: LDR x21, [x28]             | X21 = typeof(System.Type[]);            
            // 0x0143A954: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A958: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0143A95C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0143A960: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A964: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0143A968: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x0143A96C: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x0143A970: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x0143A974: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143A978: LDR x22, [x9]              | X22 = typeof(CEvent.ZEvent);            
            // 0x0143A97C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143A980: TBZ w9, #0, #0x143a994     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x0143A984: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143A988: CBNZ w9, #0x143a994        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x0143A98C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143A990: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_29:
            // 0x0143A994: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A998: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A99C: MOV x1, x22                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x0143A9A0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A9A4: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x0143A9A8: CBNZ x21, #0x143a9b0       | if ( != null) goto label_30;            
            if(null != null)
            {
                goto label_30;
            }
            // 0x0143A9AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_30:
            // 0x0143A9B0: CBZ x22, #0x143a9d4        | if (val_11 == null) goto label_32;      
            if(val_11 == null)
            {
                goto label_32;
            }
            // 0x0143A9B4: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143A9B8: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x0143A9BC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143A9C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x0143A9C4: CBNZ x0, #0x143a9d4        | if (val_11 != null) goto label_32;      
            if(val_11 != null)
            {
                goto label_32;
            }
            // 0x0143A9C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x0143A9CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A9D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_32:
            // 0x0143A9D4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143A9D8: CBNZ w8, #0x143a9e8        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_33;
            // 0x0143A9DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x0143A9E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A9E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_33:
            // 0x0143A9E8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;
            // 0x0143A9EC: CBNZ x20, #0x143a9f4       | if (val_1 != null) goto label_34;       
            if(val_1 != null)
            {
                goto label_34;
            }
            // 0x0143A9F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_34:
            // 0x0143A9F4: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x0143A9F8: LDR x8, [x8, #0x590]       | X8 = (string**)(1152921510120002032)("DispatchEvent");
            // 0x0143A9FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AA00: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143AA04: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143AA08: LDR x1, [x8]               | X1 = "DispatchEvent";                   
            // 0x0143AA0C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143AA10: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143AA14: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0143AA18: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "DispatchEvent", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_12 = val_1.GetMethod(name:  "DispatchEvent", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0143AA1C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143AA20: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x0143AA24: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143AA28: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache2;
            val_25 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache2;
            // 0x0143AA2C: CBNZ x22, #0x143aa80       | if (ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache2 != null) goto label_35;
            if(val_25 != null)
            {
                goto label_35;
            }
            // 0x0143AA30: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x0143AA34: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0143AA38: LDR x8, [x8, #0x640]       | X8 = 1152921510120006224;               
            // 0x0143AA3C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0143AA40: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::DispatchEvent_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0143AA44: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13 = null;
            // 0x0143AA48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0143AA4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AA50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AA54: MOV x2, x22                | X2 = 1152921510120006224 (0x10000001489C2250);//ML01
            // 0x0143AA58: MOV x26, x23               | X26 = 57967872 (0x3748500);//ML01       
            // 0x0143AA5C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143AA60: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::DispatchEvent_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::DispatchEvent_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0143AA64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143AA68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143AA6C: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783847440
            ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache2 = val_13;
            // 0x0143AA70: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143AA74: MOV x23, x26               | X23 = 57967872 (0x3748500);//ML01       
            val_21 = val_21;
            // 0x0143AA78: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143AA7C: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_25 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache2;
            label_35:
            // 0x0143AA80: CBNZ x19, #0x143aa88       | if (X1 != 0) goto label_36;             
            if(X1 != 0)
            {
                goto label_36;
            }
            // 0x0143AA84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::DispatchEvent_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_36:
            // 0x0143AA88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AA8C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143AA90: MOV x1, x21                | X1 = val_12;//m1                        
            // 0x0143AA94: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143AA98: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_25);
            X1.RegisterCLRMethodRedirection(mi:  val_12, func:  val_25);
            // 0x0143AA9C: LDR x21, [x28]             | X21 = typeof(System.Type[]);            
            // 0x0143AAA0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143AAA4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0143AAA8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0143AAAC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143AAB0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x0143AAB4: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x0143AAB8: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x0143AABC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143AAC0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143AAC4: TBZ w9, #0, #0x143aad8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x0143AAC8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143AACC: CBNZ w9, #0x143aad8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x0143AAD0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143AAD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_38:
            // 0x0143AAD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143AAE0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0143AAE4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143AAE8: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x0143AAEC: CBNZ x21, #0x143aaf4       | if ( != null) goto label_39;            
            if(null != null)
            {
                goto label_39;
            }
            // 0x0143AAF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_39:
            // 0x0143AAF4: CBZ x22, #0x143ab18        | if (val_14 == null) goto label_41;      
            if(val_14 == null)
            {
                goto label_41;
            }
            // 0x0143AAF8: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143AAFC: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x0143AB00: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143AB04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x0143AB08: CBNZ x0, #0x143ab18        | if (val_14 != null) goto label_41;      
            if(val_14 != null)
            {
                goto label_41;
            }
            // 0x0143AB0C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x0143AB10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AB14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_41:
            // 0x0143AB18: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143AB1C: CBNZ w8, #0x143ab2c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_42;
            // 0x0143AB20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x0143AB24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AB28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_42:
            // 0x0143AB2C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_14;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_14;
            // 0x0143AB30: LDR x1, [x23]              | X1 = typeof(CEvent.EventFunc<T>);       
            // 0x0143AB34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AB38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143AB3C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143AB40: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x0143AB44: CBZ x22, #0x143ab68        | if (val_15 == null) goto label_44;      
            if(val_15 == null)
            {
                goto label_44;
            }
            // 0x0143AB48: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143AB4C: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x0143AB50: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0143AB54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x0143AB58: CBNZ x0, #0x143ab68        | if (val_15 != null) goto label_44;      
            if(val_15 != null)
            {
                goto label_44;
            }
            // 0x0143AB5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x0143AB60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AB64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_44:
            // 0x0143AB68: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143AB6C: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0143AB70: B.HI #0x143ab80            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_45;
            // 0x0143AB74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x0143AB78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AB7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_45:
            // 0x0143AB80: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_15;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_15;
            // 0x0143AB84: CBNZ x20, #0x143ab8c       | if (val_1 != null) goto label_46;       
            if(val_1 != null)
            {
                goto label_46;
            }
            // 0x0143AB88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_46:
            // 0x0143AB8C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x0143AB90: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921510120015440)("RemoveEventListener");
            // 0x0143AB94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AB98: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143AB9C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143ABA0: LDR x1, [x8]               | X1 = "RemoveEventListener";             
            // 0x0143ABA4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143ABA8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143ABAC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0143ABB0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "RemoveEventListener", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_16 = val_1.GetMethod(name:  "RemoveEventListener", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x0143ABB4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143ABB8: MOV x20, x0                | X20 = val_16;//m1                       
            // 0x0143ABBC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143ABC0: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache3;
            val_26 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache3;
            // 0x0143ABC4: CBNZ x21, #0x143ac10       | if (ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache3 != null) goto label_47;
            if(val_26 != null)
            {
                goto label_47;
            }
            // 0x0143ABC8: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x0143ABCC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x0143ABD0: LDR x8, [x8, #0xf00]       | X8 = 1152921510120019648;               
            // 0x0143ABD4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x0143ABD8: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::RemoveEventListener_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0143ABDC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_17 = null;
            // 0x0143ABE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x0143ABE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143ABE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143ABEC: MOV x2, x21                | X2 = 1152921510120019648 (0x10000001489C56C0);//ML01
            // 0x0143ABF0: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143ABF4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::RemoveEventListener_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::RemoveEventListener_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0143ABF8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143ABFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143AC00: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783847448
            ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache3 = val_17;
            // 0x0143AC04: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding);
            // 0x0143AC08: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143AC0C: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_26 = ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding.<>f__mg$cache3;
            label_47:
            // 0x0143AC10: CBNZ x19, #0x143ac18       | if (X1 != 0) goto label_48;             
            if(X1 != 0)
            {
                goto label_48;
            }
            // 0x0143AC14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEventCenter_Binding::RemoveEventListener_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_48:
            // 0x0143AC18: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143AC1C: MOV x1, x20                | X1 = val_16;//m1                        
            // 0x0143AC20: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143AC24: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0143AC28: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0143AC2C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0143AC30: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0143AC34: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0143AC38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AC3C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0143AC40: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_16, func:  val_26); return;
            X1.RegisterCLRMethodRedirection(mi:  val_16, func:  val_26);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0143AC44 (21212228), len: 748  VirtAddr: 0x0143AC44 RVA: 0x0143AC44 token: 100664212 methodIndex: 30259 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* AddEventListener_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            CEvent.EventFunc<CEvent.ZEvent> val_14;
            // 0x0143AC44: STP x26, x25, [sp, #-0x50]! | stack[1152921510120242896] = ???;  stack[1152921510120242904] = ???;  //  dest_result_addr=1152921510120242896 |  dest_result_addr=1152921510120242904
            // 0x0143AC48: STP x24, x23, [sp, #0x10]  | stack[1152921510120242912] = ???;  stack[1152921510120242920] = ???;  //  dest_result_addr=1152921510120242912 |  dest_result_addr=1152921510120242920
            // 0x0143AC4C: STP x22, x21, [sp, #0x20]  | stack[1152921510120242928] = ???;  stack[1152921510120242936] = ???;  //  dest_result_addr=1152921510120242928 |  dest_result_addr=1152921510120242936
            // 0x0143AC50: STP x20, x19, [sp, #0x30]  | stack[1152921510120242944] = ???;  stack[1152921510120242952] = ???;  //  dest_result_addr=1152921510120242944 |  dest_result_addr=1152921510120242952
            // 0x0143AC54: STP x29, x30, [sp, #0x40]  | stack[1152921510120242960] = ???;  stack[1152921510120242968] = ???;  //  dest_result_addr=1152921510120242960 |  dest_result_addr=1152921510120242968
            // 0x0143AC58: ADD x29, sp, #0x40         | X29 = (1152921510120242896 + 64) = 1152921510120242960 (0x10000001489FBF10);
            // 0x0143AC5C: SUB sp, sp, #0x10          | SP = (1152921510120242896 - 16) = 1152921510120242880 (0x10000001489FBEC0);
            // 0x0143AC60: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143AC64: LDRB w8, [x20, #0x6f]      | W8 = (bool)static_value_0373706F;       
            // 0x0143AC68: MOV x21, x3                | X21 = X3;//m1                           
            // 0x0143AC6C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0143AC70: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143AC74: TBNZ w8, #0, #0x143ac90    | if (static_value_0373706F == true) goto label_0;
            // 0x0143AC78: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x0143AC7C: LDR x8, [x8, #0xaa8]       | X8 = 0x2B90510;                         
            // 0x0143AC80: LDR w0, [x8]               | W0 = 0x1808;                            
            // 0x0143AC84: BL #0x2782188              | X0 = sub_2782188( ?? 0x1808, ????);     
            // 0x0143AC88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143AC8C: STRB w8, [x20, #0x6f]      | static_value_0373706F = true;            //  dest_result_addr=57897071
            label_0:
            // 0x0143AC90: CBNZ x19, #0x143ac98       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143AC94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1808, ????);     
            label_1:
            // 0x0143AC98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AC9C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143ACA0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143ACA4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143ACA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143ACAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143ACB0: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143ACB4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143ACB8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143ACBC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0143ACC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143ACC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143ACC8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143ACCC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143ACD0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143ACD4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143ACD8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143ACDC: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x0143ACE0: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0143ACE4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143ACE8: LDR x9, [x9, #0x748]       | X9 = 1152921504898113536;               
            // 0x0143ACEC: LDR x24, [x9]              | X24 = typeof(CEvent.EventFunc<T>);      
            // 0x0143ACF0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143ACF4: TBZ w9, #0, #0x143ad08     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143ACF8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143ACFC: CBNZ w9, #0x143ad08        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0143AD00: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143AD04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143AD08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AD0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143AD10: MOV x1, x24                | X1 = 1152921504898113536 (0x10000000115C6000);//ML01
            // 0x0143AD14: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143AD18: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143AD1C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0143AD20: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143AD24: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143AD28: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143AD2C: TBZ w9, #0, #0x143ad40     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0143AD30: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143AD34: CBNZ w9, #0x143ad40        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143AD38: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143AD3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0143AD40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AD44: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143AD48: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143AD4C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143AD50: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0143AD54: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143AD58: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143AD5C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0143AD60: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0143AD64: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143AD68: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0143AD6C: TBZ w9, #0, #0x143ad80     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0143AD70: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143AD74: CBNZ w9, #0x143ad80        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143AD78: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0143AD7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0143AD80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AD84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AD88: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0143AD8C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0143AD90: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0143AD94: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0143AD98: CBZ x0, #0x143ade0         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0143AD9C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x0143ADA0: LDR x8, [x8, #0x980]       | X8 = 1152921504898113536;               
            // 0x0143ADA4: LDR x1, [x8]               | X1 = typeof(CEvent.EventFunc<T>);       
            // 0x0143ADA8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143ADAC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(CEvent.EventFunc<T>))
            // 0x0143ADB0: MOV x24, x0                | X24 = val_6;//m1                        
            val_13 = val_6;
            // 0x0143ADB4: B.EQ #0x143ade0            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0143ADB8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143ADBC: MOV x8, sp                 | X8 = 1152921510120242880 (0x10000001489FBEC0);//ML01
            // 0x0143ADC0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143ADC4: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510120230976]
            // 0x0143ADC8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0143ADCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143ADD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0143ADD4: MOV x0, sp                 | X0 = 1152921510120242880 (0x10000001489FBEC0);//ML01
            // 0x0143ADD8: BL #0x299a140              | 
            // 0x0143ADDC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_9:
            // 0x0143ADE0: CBNZ x19, #0x143ade8       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0143ADE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001489FBEC0, ????);
            label_10:
            // 0x0143ADE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143ADEC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143ADF0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143ADF4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143ADF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143ADFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AE00: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143AE04: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143AE08: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143AE0C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0143AE10: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0143AE14: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0143AE18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AE1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143AE20: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143AE24: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143AE28: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0143AE2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AE30: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143AE34: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0143AE38: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143AE3C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0143AE40: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143AE44: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0143AE48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AE4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AE50: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0143AE54: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0143AE58: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x0143AE5C: CBZ x0, #0x143aea4         | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x0143AE60: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0143AE64: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0143AE68: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143AE6C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143AE70: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0143AE74: MOV x21, x0                | X21 = val_11;//m1                       
            val_14 = val_11;
            // 0x0143AE78: B.EQ #0x143aea4            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x0143AE7C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143AE80: ADD x8, sp, #8             | X8 = (1152921510120242880 + 8) = 1152921510120242888 (0x10000001489FBEC8);
            // 0x0143AE84: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143AE88: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510120230976]
            // 0x0143AE8C: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0143AE90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AE94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0143AE98: ADD x0, sp, #8             | X0 = (1152921510120242880 + 8) = 1152921510120242888 (0x10000001489FBEC8);
            // 0x0143AE9C: BL #0x299a140              | 
            // 0x0143AEA0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_12:
            // 0x0143AEA4: CBNZ x19, #0x143aeac       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0143AEA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001489FBEC8, ????);
            label_13:
            // 0x0143AEAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143AEB0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143AEB4: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0143AEB8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143AEBC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0143AEC0: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
            // 0x0143AEC4: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
            // 0x0143AEC8: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
            // 0x0143AECC: TBZ w8, #0, #0x143aedc     | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x0143AED0: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
            // 0x0143AED4: CBNZ w8, #0x143aedc        | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x0143AED8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
            label_15:
            // 0x0143AEDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AEE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AEE4: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x0143AEE8: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0143AEEC: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  val_14);
            CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  val_14);
            // 0x0143AEF0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143AEF4: SUB sp, x29, #0x40         | SP = (1152921510120242960 - 64) = 1152921510120242896 (0x10000001489FBED0);
            // 0x0143AEF8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0143AEFC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0143AF00: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0143AF04: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0143AF08: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0143AF0C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143AF10: MOV x19, x0                | 
            // 0x0143AF14: MOV x0, sp                 | 
            // 0x0143AF18: B #0x143af24               | 
            // 0x0143AF1C: MOV x19, x0                | 
            // 0x0143AF20: ADD x0, sp, #8             | 
            label_16:
            // 0x0143AF24: BL #0x299a140              | 
            // 0x0143AF28: MOV x0, x19                | 
            // 0x0143AF2C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0143AF30 (21212976), len: 800  VirtAddr: 0x0143AF30 RVA: 0x0143AF30 token: 100664213 methodIndex: 30260 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* AddEventListener_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_15;
            //  | 
            CEvent.EventFunc<CEvent.ZEvent> val_16;
            // 0x0143AF30: STP x28, x27, [sp, #-0x60]! | stack[1152921510120436800] = ???;  stack[1152921510120436808] = ???;  //  dest_result_addr=1152921510120436800 |  dest_result_addr=1152921510120436808
            // 0x0143AF34: STP x26, x25, [sp, #0x10]  | stack[1152921510120436816] = ???;  stack[1152921510120436824] = ???;  //  dest_result_addr=1152921510120436816 |  dest_result_addr=1152921510120436824
            // 0x0143AF38: STP x24, x23, [sp, #0x20]  | stack[1152921510120436832] = ???;  stack[1152921510120436840] = ???;  //  dest_result_addr=1152921510120436832 |  dest_result_addr=1152921510120436840
            // 0x0143AF3C: STP x22, x21, [sp, #0x30]  | stack[1152921510120436848] = ???;  stack[1152921510120436856] = ???;  //  dest_result_addr=1152921510120436848 |  dest_result_addr=1152921510120436856
            // 0x0143AF40: STP x20, x19, [sp, #0x40]  | stack[1152921510120436864] = ???;  stack[1152921510120436872] = ???;  //  dest_result_addr=1152921510120436864 |  dest_result_addr=1152921510120436872
            // 0x0143AF44: STP x29, x30, [sp, #0x50]  | stack[1152921510120436880] = ???;  stack[1152921510120436888] = ???;  //  dest_result_addr=1152921510120436880 |  dest_result_addr=1152921510120436888
            // 0x0143AF48: ADD x29, sp, #0x50         | X29 = (1152921510120436800 + 80) = 1152921510120436880 (0x1000000148A2B490);
            // 0x0143AF4C: SUB sp, sp, #0x10          | SP = (1152921510120436800 - 16) = 1152921510120436784 (0x1000000148A2B430);
            // 0x0143AF50: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143AF54: LDRB w8, [x20, #0x70]      | W8 = (bool)static_value_03737070;       
            // 0x0143AF58: MOV x21, x3                | X21 = X3;//m1                           
            // 0x0143AF5C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0143AF60: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143AF64: TBNZ w8, #0, #0x143af80    | if (static_value_03737070 == true) goto label_0;
            // 0x0143AF68: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x0143AF6C: LDR x8, [x8, #0x8e8]       | X8 = 0x2B90514;                         
            // 0x0143AF70: LDR w0, [x8]               | W0 = 0x1809;                            
            // 0x0143AF74: BL #0x2782188              | X0 = sub_2782188( ?? 0x1809, ????);     
            // 0x0143AF78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143AF7C: STRB w8, [x20, #0x70]      | static_value_03737070 = true;            //  dest_result_addr=57897072
            label_0:
            // 0x0143AF80: CBNZ x19, #0x143af88       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143AF84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1809, ????);     
            label_1:
            // 0x0143AF88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143AF8C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143AF90: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143AF94: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143AF98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AF9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AFA0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x0143AFA4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143AFA8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143AFAC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0143AFB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AFB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AFB8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143AFBC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143AFC0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143AFC4: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0143AFC8: CBNZ x24, #0x143afd0       | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x0143AFCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x0143AFD0: LDR w27, [x24, #4]         | W27 = val_3 + 4;                        
            // 0x0143AFD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143AFD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143AFDC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143AFE0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143AFE4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143AFE8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143AFEC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143AFF0: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x0143AFF4: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x0143AFF8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143AFFC: LDR x9, [x9, #0x748]       | X9 = 1152921504898113536;               
            // 0x0143B000: LDR x24, [x9]              | X24 = typeof(CEvent.EventFunc<T>);      
            // 0x0143B004: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143B008: TBZ w9, #0, #0x143b01c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0143B00C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143B010: CBNZ w9, #0x143b01c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0143B014: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143B018: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x0143B01C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B024: MOV x1, x24                | X1 = 1152921504898113536 (0x10000000115C6000);//ML01
            // 0x0143B028: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143B02C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143B030: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0143B034: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x0143B038: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143B03C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143B040: TBZ w9, #0, #0x143b054     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0143B044: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143B048: CBNZ w9, #0x143b054        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0143B04C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143B050: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x0143B054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B058: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143B05C: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x0143B060: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143B064: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0143B068: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143B06C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143B070: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0143B074: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x0143B078: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143B07C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0143B080: TBZ w9, #0, #0x143b094     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0143B084: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143B088: CBNZ w9, #0x143b094        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0143B08C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0143B090: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x0143B094: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B098: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B09C: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x0143B0A0: MOV x2, x26                | X2 = val_6;//m1                         
            // 0x0143B0A4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x0143B0A8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x0143B0AC: CBZ x0, #0x143b0f4         | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x0143B0B0: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x0143B0B4: LDR x8, [x8, #0x980]       | X8 = 1152921504898113536;               
            // 0x0143B0B8: LDR x1, [x8]               | X1 = typeof(CEvent.EventFunc<T>);       
            // 0x0143B0BC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143B0C0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(CEvent.EventFunc<T>))
            // 0x0143B0C4: MOV x24, x0                | X24 = val_7;//m1                        
            val_15 = val_7;
            // 0x0143B0C8: B.EQ #0x143b0f4            | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x0143B0CC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143B0D0: MOV x8, sp                 | X8 = 1152921510120436784 (0x1000000148A2B430);//ML01
            // 0x0143B0D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143B0D8: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510120424896]
            // 0x0143B0DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0143B0E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B0E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0143B0E8: MOV x0, sp                 | X0 = 1152921510120436784 (0x1000000148A2B430);//ML01
            // 0x0143B0EC: BL #0x299a140              | 
            // 0x0143B0F0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x0143B0F4: CBNZ x19, #0x143b0fc       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0143B0F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148A2B430, ????);
            label_11:
            // 0x0143B0FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B100: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B104: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x0143B108: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143B10C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B110: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B114: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x0143B118: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143B11C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143B120: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0143B124: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0143B128: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x0143B12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B130: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B134: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143B138: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143B13C: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x0143B140: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B144: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143B148: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x0143B14C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143B150: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0143B154: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143B158: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x0143B15C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B160: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B164: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x0143B168: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x0143B16C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x0143B170: CBZ x0, #0x143b1b8         | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x0143B174: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0143B178: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0143B17C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143B180: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143B184: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0143B188: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x0143B18C: B.EQ #0x143b1b8            | if (typeof(System.Object) == null) goto label_13;
            if(null == null)
            {
                goto label_13;
            }
            // 0x0143B190: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143B194: ADD x8, sp, #8             | X8 = (1152921510120436784 + 8) = 1152921510120436792 (0x1000000148A2B438);
            // 0x0143B198: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143B19C: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510120424896]
            // 0x0143B1A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x0143B1A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B1A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x0143B1AC: ADD x0, sp, #8             | X0 = (1152921510120436784 + 8) = 1152921510120436792 (0x1000000148A2B438);
            // 0x0143B1B0: BL #0x299a140              | 
            // 0x0143B1B4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_13:
            // 0x0143B1B8: CBNZ x19, #0x143b1c0       | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x0143B1BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148A2B438, ????);
            label_14:
            // 0x0143B1C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B1C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B1C8: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x0143B1CC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143B1D0: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0143B1D4: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
            // 0x0143B1D8: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
            // 0x0143B1DC: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
            // 0x0143B1E0: TBZ w8, #0, #0x143b1f0     | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x0143B1E4: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
            // 0x0143B1E8: CBNZ w8, #0x143b1f0        | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x0143B1EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
            label_16:
            // 0x0143B1F0: CMP w27, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x0143B1F4: CSET w3, eq                | W3 = val_3 + 4 == 0x1 ? 1 : 0;          
            var val_14 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x0143B1F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B1FC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143B200: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x0143B204: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0143B208: BL #0xd81e50               | CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  val_16, isInsert:  false);
            CEvent.ZEventCenter.AddEventListener(eventType:  0, fun:  val_16, isInsert:  false);
            // 0x0143B20C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143B210: SUB sp, x29, #0x50         | SP = (1152921510120436880 - 80) = 1152921510120436800 (0x1000000148A2B440);
            // 0x0143B214: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0143B218: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0143B21C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0143B220: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0143B224: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0143B228: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0143B22C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143B230: MOV x19, x0                | 
            // 0x0143B234: MOV x0, sp                 | 
            // 0x0143B238: B #0x143b244               | 
            // 0x0143B23C: MOV x19, x0                | 
            // 0x0143B240: ADD x0, sp, #8             | 
            label_17:
            // 0x0143B244: BL #0x299a140              | 
            // 0x0143B248: MOV x0, x19                | 
            // 0x0143B24C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0143B250 (21213776), len: 556  VirtAddr: 0x0143B250 RVA: 0x0143B250 token: 100664214 methodIndex: 30261 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* DispatchEvent_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x0143B250: STP x24, x23, [sp, #-0x40]! | stack[1152921510120618464] = ???;  stack[1152921510120618472] = ???;  //  dest_result_addr=1152921510120618464 |  dest_result_addr=1152921510120618472
            // 0x0143B254: STP x22, x21, [sp, #0x10]  | stack[1152921510120618480] = ???;  stack[1152921510120618488] = ???;  //  dest_result_addr=1152921510120618480 |  dest_result_addr=1152921510120618488
            // 0x0143B258: STP x20, x19, [sp, #0x20]  | stack[1152921510120618496] = ???;  stack[1152921510120618504] = ???;  //  dest_result_addr=1152921510120618496 |  dest_result_addr=1152921510120618504
            // 0x0143B25C: STP x29, x30, [sp, #0x30]  | stack[1152921510120618512] = ???;  stack[1152921510120618520] = ???;  //  dest_result_addr=1152921510120618512 |  dest_result_addr=1152921510120618520
            // 0x0143B260: ADD x29, sp, #0x30         | X29 = (1152921510120618464 + 48) = 1152921510120618512 (0x1000000148A57A10);
            // 0x0143B264: SUB sp, sp, #0x10          | SP = (1152921510120618464 - 16) = 1152921510120618448 (0x1000000148A579D0);
            // 0x0143B268: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143B26C: LDRB w8, [x20, #0x71]      | W8 = (bool)static_value_03737071;       
            // 0x0143B270: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0143B274: MOV x21, x2                | X21 = X2;//m1                           
            // 0x0143B278: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143B27C: TBNZ w8, #0, #0x143b298    | if (static_value_03737071 == true) goto label_0;
            // 0x0143B280: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x0143B284: LDR x8, [x8, #0x7f8]       | X8 = 0x2B90518;                         
            // 0x0143B288: LDR w0, [x8]               | W0 = 0x180A;                            
            // 0x0143B28C: BL #0x2782188              | X0 = sub_2782188( ?? 0x180A, ????);     
            // 0x0143B290: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143B294: STRB w8, [x20, #0x71]      | static_value_03737071 = true;            //  dest_result_addr=57897073
            label_0:
            // 0x0143B298: CBNZ x19, #0x143b2a0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143B29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x180A, ????);     
            label_1:
            // 0x0143B2A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B2A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B2A8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143B2AC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143B2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B2B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B2B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143B2BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0143B2C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143B2C4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0143B2C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B2CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B2D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143B2D4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x0143B2D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143B2DC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143B2E0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143B2E4: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x0143B2E8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x0143B2EC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143B2F0: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x0143B2F4: LDR x24, [x9]              | X24 = typeof(CEvent.ZEvent);            
            // 0x0143B2F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143B2FC: TBZ w9, #0, #0x143b310     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143B300: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143B304: CBNZ w9, #0x143b310        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0143B308: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143B30C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143B310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B318: MOV x1, x24                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x0143B31C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143B320: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143B324: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0143B328: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143B32C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143B330: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143B334: TBZ w9, #0, #0x143b348     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0143B338: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143B33C: CBNZ w9, #0x143b348        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143B340: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143B344: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0143B348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B34C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143B350: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0143B354: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143B358: MOV x3, x22                | X3 = X3;//m1                            
            // 0x0143B35C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143B360: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143B364: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0143B368: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x0143B36C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143B370: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0143B374: TBZ w9, #0, #0x143b388     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0143B378: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143B37C: CBNZ w9, #0x143b388        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143B380: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0143B384: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0143B388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B38C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B390: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0143B394: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x0143B398: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0143B39C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x0143B3A0: CBZ x0, #0x143b404         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x0143B3A4: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x0143B3A8: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x0143B3AC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143B3B0: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x0143B3B4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143B3B8: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143B3BC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143B3C0: B.LO #0x143b3dc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x0143B3C4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x0143B3C8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHie
            // 0x0143B3CC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143B3D0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x0143B3D4: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x0143B3D8: B.EQ #0x143b404            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x0143B3DC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143B3E0: ADD x8, sp, #8             | X8 = (1152921510120618448 + 8) = 1152921510120618456 (0x1000000148A579D8);
            // 0x0143B3E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143B3E8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510120606528]
            // 0x0143B3EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0143B3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B3F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0143B3F8: ADD x0, sp, #8             | X0 = (1152921510120618448 + 8) = 1152921510120618456 (0x1000000148A579D8);
            // 0x0143B3FC: BL #0x299a140              | 
            // 0x0143B400: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x0143B404: CBNZ x19, #0x143b40c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0143B408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148A579D8, ????);
            label_11:
            // 0x0143B40C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B410: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B414: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x0143B418: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143B41C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0143B420: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
            // 0x0143B424: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
            // 0x0143B428: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
            // 0x0143B42C: TBZ w8, #0, #0x143b43c     | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x0143B430: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
            // 0x0143B434: CBNZ w8, #0x143b43c        | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x0143B438: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
            label_13:
            // 0x0143B43C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B444: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x0143B448: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
            CEvent.ZEventCenter.DispatchEvent(ev:  0);
            // 0x0143B44C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143B450: SUB sp, x29, #0x30         | SP = (1152921510120618512 - 48) = 1152921510120618464 (0x1000000148A579E0);
            // 0x0143B454: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0143B458: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0143B45C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0143B460: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0143B464: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143B468: MOV x19, x0                | 
            // 0x0143B46C: ADD x0, sp, #8             | 
            // 0x0143B470: BL #0x299a140              | 
            // 0x0143B474: MOV x0, x19                | 
            // 0x0143B478: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0143B47C (21214332), len: 748  VirtAddr: 0x0143B47C RVA: 0x0143B47C token: 100664215 methodIndex: 30262 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* RemoveEventListener_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            CEvent.EventFunc<CEvent.ZEvent> val_14;
            // 0x0143B47C: STP x26, x25, [sp, #-0x50]! | stack[1152921510120800080] = ???;  stack[1152921510120800088] = ???;  //  dest_result_addr=1152921510120800080 |  dest_result_addr=1152921510120800088
            // 0x0143B480: STP x24, x23, [sp, #0x10]  | stack[1152921510120800096] = ???;  stack[1152921510120800104] = ???;  //  dest_result_addr=1152921510120800096 |  dest_result_addr=1152921510120800104
            // 0x0143B484: STP x22, x21, [sp, #0x20]  | stack[1152921510120800112] = ???;  stack[1152921510120800120] = ???;  //  dest_result_addr=1152921510120800112 |  dest_result_addr=1152921510120800120
            // 0x0143B488: STP x20, x19, [sp, #0x30]  | stack[1152921510120800128] = ???;  stack[1152921510120800136] = ???;  //  dest_result_addr=1152921510120800128 |  dest_result_addr=1152921510120800136
            // 0x0143B48C: STP x29, x30, [sp, #0x40]  | stack[1152921510120800144] = ???;  stack[1152921510120800152] = ???;  //  dest_result_addr=1152921510120800144 |  dest_result_addr=1152921510120800152
            // 0x0143B490: ADD x29, sp, #0x40         | X29 = (1152921510120800080 + 64) = 1152921510120800144 (0x1000000148A83F90);
            // 0x0143B494: SUB sp, sp, #0x10          | SP = (1152921510120800080 - 16) = 1152921510120800064 (0x1000000148A83F40);
            // 0x0143B498: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143B49C: LDRB w8, [x20, #0x72]      | W8 = (bool)static_value_03737072;       
            // 0x0143B4A0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x0143B4A4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0143B4A8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143B4AC: TBNZ w8, #0, #0x143b4c8    | if (static_value_03737072 == true) goto label_0;
            // 0x0143B4B0: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x0143B4B4: LDR x8, [x8, #0x388]       | X8 = 0x2B90520;                         
            // 0x0143B4B8: LDR w0, [x8]               | W0 = 0x180C;                            
            // 0x0143B4BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x180C, ????);     
            // 0x0143B4C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143B4C4: STRB w8, [x20, #0x72]      | static_value_03737072 = true;            //  dest_result_addr=57897074
            label_0:
            // 0x0143B4C8: CBNZ x19, #0x143b4d0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143B4CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x180C, ????);     
            label_1:
            // 0x0143B4D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B4D4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B4D8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143B4DC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143B4E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B4E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B4E8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143B4EC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143B4F0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143B4F4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x0143B4F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B4FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B500: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143B504: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143B508: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143B50C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143B510: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143B514: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x0143B518: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0143B51C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143B520: LDR x9, [x9, #0x748]       | X9 = 1152921504898113536;               
            // 0x0143B524: LDR x24, [x9]              | X24 = typeof(CEvent.EventFunc<T>);      
            // 0x0143B528: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143B52C: TBZ w9, #0, #0x143b540     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143B530: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143B534: CBNZ w9, #0x143b540        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0143B538: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143B53C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143B540: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B544: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B548: MOV x1, x24                | X1 = 1152921504898113536 (0x10000000115C6000);//ML01
            // 0x0143B54C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143B550: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143B554: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0143B558: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143B55C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143B560: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143B564: TBZ w9, #0, #0x143b578     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0143B568: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143B56C: CBNZ w9, #0x143b578        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143B570: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143B574: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0143B578: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B57C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143B580: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143B584: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143B588: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0143B58C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143B590: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143B594: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0143B598: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0143B59C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143B5A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0143B5A4: TBZ w9, #0, #0x143b5b8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0143B5A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143B5AC: CBNZ w9, #0x143b5b8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143B5B0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0143B5B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0143B5B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B5BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B5C0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0143B5C4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0143B5C8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0143B5CC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x0143B5D0: CBZ x0, #0x143b618         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x0143B5D4: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x0143B5D8: LDR x8, [x8, #0x980]       | X8 = 1152921504898113536;               
            // 0x0143B5DC: LDR x1, [x8]               | X1 = typeof(CEvent.EventFunc<T>);       
            // 0x0143B5E0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143B5E4: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(CEvent.EventFunc<T>))
            // 0x0143B5E8: MOV x24, x0                | X24 = val_6;//m1                        
            val_13 = val_6;
            // 0x0143B5EC: B.EQ #0x143b618            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x0143B5F0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143B5F4: MOV x8, sp                 | X8 = 1152921510120800064 (0x1000000148A83F40);//ML01
            // 0x0143B5F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143B5FC: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510120788160]
            // 0x0143B600: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0143B604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B608: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0143B60C: MOV x0, sp                 | X0 = 1152921510120800064 (0x1000000148A83F40);//ML01
            // 0x0143B610: BL #0x299a140              | 
            // 0x0143B614: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_9:
            // 0x0143B618: CBNZ x19, #0x143b620       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0143B61C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148A83F40, ????);
            label_10:
            // 0x0143B620: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B624: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B628: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143B62C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143B630: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B634: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B638: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143B63C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143B640: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143B644: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0143B648: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0143B64C: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0143B650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B654: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B658: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143B65C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143B660: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0143B664: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B668: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143B66C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0143B670: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143B674: MOV x3, x21                | X3 = X3;//m1                            
            // 0x0143B678: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143B67C: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0143B680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B684: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B688: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0143B68C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0143B690: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x0143B694: CBZ x0, #0x143b6dc         | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x0143B698: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0143B69C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0143B6A0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143B6A4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143B6A8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0143B6AC: MOV x21, x0                | X21 = val_11;//m1                       
            val_14 = val_11;
            // 0x0143B6B0: B.EQ #0x143b6dc            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x0143B6B4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143B6B8: ADD x8, sp, #8             | X8 = (1152921510120800064 + 8) = 1152921510120800072 (0x1000000148A83F48);
            // 0x0143B6BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143B6C0: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510120788160]
            // 0x0143B6C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0143B6C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B6CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0143B6D0: ADD x0, sp, #8             | X0 = (1152921510120800064 + 8) = 1152921510120800072 (0x1000000148A83F48);
            // 0x0143B6D4: BL #0x299a140              | 
            // 0x0143B6D8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_12:
            // 0x0143B6DC: CBNZ x19, #0x143b6e4       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0143B6E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148A83F48, ????);
            label_13:
            // 0x0143B6E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B6E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B6EC: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0143B6F0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143B6F4: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0143B6F8: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
            // 0x0143B6FC: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
            // 0x0143B700: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
            // 0x0143B704: TBZ w8, #0, #0x143b714     | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x0143B708: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
            // 0x0143B70C: CBNZ w8, #0x143b714        | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x0143B710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
            label_15:
            // 0x0143B714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B718: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B71C: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x0143B720: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x0143B724: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  val_14);
            CEvent.ZEventCenter.RemoveEventListener(eventType:  0, func:  val_14);
            // 0x0143B728: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x0143B72C: SUB sp, x29, #0x40         | SP = (1152921510120800144 - 64) = 1152921510120800080 (0x1000000148A83F50);
            // 0x0143B730: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0143B734: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0143B738: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0143B73C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0143B740: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0143B744: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143B748: MOV x19, x0                | 
            // 0x0143B74C: MOV x0, sp                 | 
            // 0x0143B750: B #0x143b75c               | 
            // 0x0143B754: MOV x19, x0                | 
            // 0x0143B758: ADD x0, sp, #8             | 
            label_16:
            // 0x0143B75C: BL #0x299a140              | 
            // 0x0143B760: MOV x0, x19                | 
            // 0x0143B764: BL #0x980800               | 
        
        }
    
    }

}
