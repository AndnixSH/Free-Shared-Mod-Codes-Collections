using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    [System.FlagsAttribute] // 0x28137E0
    public enum AssemblyAttributes
    {
        // Fields
        PublicKey = 1
        ,SideBySideCompatible = 0
        ,Retargetable = 256
        ,WindowsRuntime = 512
        ,DisableJITCompileOptimizer = 16384
        ,EnableJITCompileTracking = 32768
        
    
    }

}
