using UnityEngine;
public class cameraShotCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public int nextId; //  0x00000014
    public int storyId; //  0x00000018
    public int isNextWith; //  0x0000001C
    public int preId; //  0x00000020
    public int funType; //  0x00000024
    public string param1; //  0x00000028
    public string param2; //  0x00000030
    public string param3; //  0x00000038
    public string param4; //  0x00000040
    public string param5; //  0x00000048
    public string param6; //  0x00000050
    public string param7; //  0x00000058
    public string param8; //  0x00000060
    public string remark; //  0x00000068
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BAD788 (12244872), len: 8  VirtAddr: 0x00BAD788 RVA: 0x00BAD788 token: 100690510 methodIndex: 25723 delegateWrapperIndex: 0 methodInvoker: 0
    public cameraShotCfg()
    {
        //
        // Disasemble & Code
        // 0x00BAD788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BAD78C: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BAD790 (12244880), len: 964  VirtAddr: 0x00BAD790 RVA: 0x00BAD790 token: 100690511 methodIndex: 25724 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00BAD790: STP x22, x21, [sp, #-0x30]! | stack[1152921514530050432] = ???;  stack[1152921514530050440] = ???;  //  dest_result_addr=1152921514530050432 |  dest_result_addr=1152921514530050440
        // 0x00BAD794: STP x20, x19, [sp, #0x10]  | stack[1152921514530050448] = ???;  stack[1152921514530050456] = ???;  //  dest_result_addr=1152921514530050448 |  dest_result_addr=1152921514530050456
        // 0x00BAD798: STP x29, x30, [sp, #0x20]  | stack[1152921514530050464] = ???;  stack[1152921514530050472] = ???;  //  dest_result_addr=1152921514530050464 |  dest_result_addr=1152921514530050472
        // 0x00BAD79C: ADD x29, sp, #0x20         | X29 = (1152921514530050432 + 32) = 1152921514530050464 (0x100000024F7811A0);
        // 0x00BAD7A0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BAD7A4: LDRB w8, [x21, #0xb09]     | W8 = (bool)static_value_03733B09;       
        // 0x00BAD7A8: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00BAD7AC: MOV x19, x0                | X19 = 1152921514530062480 (0x100000024F784090);//ML01
        // 0x00BAD7B0: TBNZ w8, #0, #0xbad7cc     | if (static_value_03733B09 == true) goto label_0;
        // 0x00BAD7B4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00BAD7B8: LDR x8, [x8, #0x238]       | X8 = 0x2B90264;                         
        // 0x00BAD7BC: LDR w0, [x8]               | W0 = 0x175D;                            
        // 0x00BAD7C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x175D, ????);     
        // 0x00BAD7C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BAD7C8: STRB w8, [x21, #0xb09]     | static_value_03733B09 = true;            //  dest_result_addr=57883401
        label_0:
        // 0x00BAD7CC: CBNZ x20, #0xbad7d4        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00BAD7D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x175D, ????);     
        label_1:
        // 0x00BAD7D4: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00BAD7D8: ADRP x21, #0x3667000       | X21 = 57044992 (0x3667000);             
        // 0x00BAD7DC: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00BAD7E0: LDR x21, [x21, #0x90]      | X21 = 1152921510817398768;              
        // 0x00BAD7E4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD7E8: LDR x1, [x8]               | X1 = "id";                              
        // 0x00BAD7EC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD7F0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00BAD7F4: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00BAD7F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD7FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD800: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00BAD804: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514530062496
        this.id = val_2;
        // 0x00BAD808: CBZ x20, #0xbad83c         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00BAD80C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00BAD810: LDR x8, [x8, #0x2f0]       | X8 = (string**)(1152921514529951392)("nextId");
        // 0x00BAD814: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD818: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD81C: LDR x1, [x8]               | X1 = "nextId";                          
        // 0x00BAD820: BL #0x23fc26c              | X0 = _info.get_Item(key:  "nextId");    
        string val_3 = _info.Item["nextId"];
        // 0x00BAD824: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00BAD828: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD82C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD830: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_4 = System.Int32.Parse(s:  0);
        // 0x00BAD834: STR w0, [x19, #0x14]       | this.nextId = val_4;                     //  dest_result_addr=1152921514530062500
        this.nextId = val_4;
        // 0x00BAD838: B #0xbad870                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00BAD83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00BAD840: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x00BAD844: LDR x8, [x8, #0x2f0]       | X8 = (string**)(1152921514529951392)("nextId");
        // 0x00BAD848: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD84C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD850: LDR x1, [x8]               | X1 = "nextId";                          
        // 0x00BAD854: BL #0x23fc26c              | X0 = _info.get_Item(key:  "nextId");    
        string val_5 = _info.Item["nextId"];
        // 0x00BAD858: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00BAD85C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD864: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_6 = System.Int32.Parse(s:  0);
        // 0x00BAD868: STR w0, [x19, #0x14]       | this.nextId = val_6;                     //  dest_result_addr=1152921514530062500
        this.nextId = val_6;
        // 0x00BAD86C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_3:
        // 0x00BAD870: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00BAD874: LDR x8, [x8, #0x410]       | X8 = (string**)(1152921510597321408)("storyId");
        // 0x00BAD878: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD87C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD880: LDR x1, [x8]               | X1 = "storyId";                         
        // 0x00BAD884: BL #0x23fc26c              | X0 = _info.get_Item(key:  "storyId");   
        string val_7 = _info.Item["storyId"];
        // 0x00BAD888: MOV x1, x0                 | X1 = val_7;//m1                         
        // 0x00BAD88C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD894: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_8 = System.Int32.Parse(s:  0);
        // 0x00BAD898: STR w0, [x19, #0x18]       | this.storyId = val_8;                    //  dest_result_addr=1152921514530062504
        this.storyId = val_8;
        // 0x00BAD89C: CBZ x20, #0xbad8d0         | if (_info == null) goto label_4;        
        if(_info == null)
        {
            goto label_4;
        }
        // 0x00BAD8A0: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00BAD8A4: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921514529963760)("isNextWith");
        // 0x00BAD8A8: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD8AC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD8B0: LDR x1, [x8]               | X1 = "isNextWith";                      
        // 0x00BAD8B4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isNextWith");
        string val_9 = _info.Item["isNextWith"];
        // 0x00BAD8B8: MOV x1, x0                 | X1 = val_9;//m1                         
        // 0x00BAD8BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD8C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD8C4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_10 = System.Int32.Parse(s:  0);
        // 0x00BAD8C8: STR w0, [x19, #0x1c]       | this.isNextWith = val_10;                //  dest_result_addr=1152921514530062508
        this.isNextWith = val_10;
        // 0x00BAD8CC: B #0xbad904                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00BAD8D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        // 0x00BAD8D4: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00BAD8D8: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921514529963760)("isNextWith");
        // 0x00BAD8DC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD8E0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD8E4: LDR x1, [x8]               | X1 = "isNextWith";                      
        // 0x00BAD8E8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "isNextWith");
        string val_11 = _info.Item["isNextWith"];
        // 0x00BAD8EC: MOV x1, x0                 | X1 = val_11;//m1                        
        // 0x00BAD8F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD8F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD8F8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_12 = System.Int32.Parse(s:  0);
        // 0x00BAD8FC: STR w0, [x19, #0x1c]       | this.isNextWith = val_12;                //  dest_result_addr=1152921514530062508
        this.isNextWith = val_12;
        // 0x00BAD900: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_5:
        // 0x00BAD904: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x00BAD908: LDR x8, [x8, #0xc78]       | X8 = (string**)(1152921514529972048)("preId");
        // 0x00BAD90C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD910: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD914: LDR x1, [x8]               | X1 = "preId";                           
        // 0x00BAD918: BL #0x23fc26c              | X0 = _info.get_Item(key:  "preId");     
        string val_13 = _info.Item["preId"];
        // 0x00BAD91C: MOV x1, x0                 | X1 = val_13;//m1                        
        // 0x00BAD920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD924: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD928: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_14 = System.Int32.Parse(s:  0);
        // 0x00BAD92C: STR w0, [x19, #0x20]       | this.preId = val_14;                     //  dest_result_addr=1152921514530062512
        this.preId = val_14;
        // 0x00BAD930: CBZ x20, #0xbad964         | if (_info == null) goto label_6;        
        if(_info == null)
        {
            goto label_6;
        }
        // 0x00BAD934: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00BAD938: LDR x8, [x8, #0x408]       | X8 = (string**)(1152921514529976224)("funType");
        // 0x00BAD93C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD940: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD944: LDR x1, [x8]               | X1 = "funType";                         
        // 0x00BAD948: BL #0x23fc26c              | X0 = _info.get_Item(key:  "funType");   
        string val_15 = _info.Item["funType"];
        // 0x00BAD94C: MOV x1, x0                 | X1 = val_15;//m1                        
        // 0x00BAD950: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD954: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD958: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_16 = System.Int32.Parse(s:  0);
        // 0x00BAD95C: STR w0, [x19, #0x24]       | this.funType = val_16;                   //  dest_result_addr=1152921514530062516
        this.funType = val_16;
        // 0x00BAD960: B #0xbad998                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00BAD964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        // 0x00BAD968: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00BAD96C: LDR x8, [x8, #0x408]       | X8 = (string**)(1152921514529976224)("funType");
        // 0x00BAD970: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD974: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD978: LDR x1, [x8]               | X1 = "funType";                         
        // 0x00BAD97C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "funType");   
        string val_17 = _info.Item["funType"];
        // 0x00BAD980: MOV x1, x0                 | X1 = val_17;//m1                        
        // 0x00BAD984: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BAD988: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BAD98C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_18 = System.Int32.Parse(s:  0);
        // 0x00BAD990: STR w0, [x19, #0x24]       | this.funType = val_18;                   //  dest_result_addr=1152921514530062516
        this.funType = val_18;
        // 0x00BAD994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_7:
        // 0x00BAD998: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00BAD99C: LDR x8, [x8, #0xe8]        | X8 = (string**)(1152921514529984512)("param1");
        // 0x00BAD9A0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD9A4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD9A8: LDR x1, [x8]               | X1 = "param1";                          
        // 0x00BAD9AC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param1");    
        string val_19 = _info.Item["param1"];
        // 0x00BAD9B0: STR x0, [x19, #0x28]       | this.param1 = val_19;                    //  dest_result_addr=1152921514530062520
        this.param1 = val_19;
        // 0x00BAD9B4: CBZ x20, #0xbad9d8         | if (_info == null) goto label_8;        
        if(_info == null)
        {
            goto label_8;
        }
        // 0x00BAD9B8: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00BAD9BC: LDR x8, [x8, #0x2d0]       | X8 = (string**)(1152921514529988688)("param2");
        // 0x00BAD9C0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD9C4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD9C8: LDR x1, [x8]               | X1 = "param2";                          
        // 0x00BAD9CC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param2");    
        string val_20 = _info.Item["param2"];
        // 0x00BAD9D0: STR x0, [x19, #0x30]       | this.param2 = val_20;                    //  dest_result_addr=1152921514530062528
        this.param2 = val_20;
        // 0x00BAD9D4: B #0xbad9fc                |  goto label_9;                          
        goto label_9;
        label_8:
        // 0x00BAD9D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        // 0x00BAD9DC: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
        // 0x00BAD9E0: LDR x8, [x8, #0x2d0]       | X8 = (string**)(1152921514529988688)("param2");
        // 0x00BAD9E4: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BAD9E8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BAD9EC: LDR x1, [x8]               | X1 = "param2";                          
        // 0x00BAD9F0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param2");    
        string val_21 = _info.Item["param2"];
        // 0x00BAD9F4: STR x0, [x19, #0x30]       | this.param2 = val_21;                    //  dest_result_addr=1152921514530062528
        this.param2 = val_21;
        // 0x00BAD9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_9:
        // 0x00BAD9FC: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
        // 0x00BADA00: LDR x8, [x8, #0x678]       | X8 = (string**)(1152921514529996960)("param3");
        // 0x00BADA04: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADA08: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADA0C: LDR x1, [x8]               | X1 = "param3";                          
        // 0x00BADA10: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param3");    
        string val_22 = _info.Item["param3"];
        // 0x00BADA14: STR x0, [x19, #0x38]       | this.param3 = val_22;                    //  dest_result_addr=1152921514530062536
        this.param3 = val_22;
        // 0x00BADA18: CBZ x20, #0xbada3c         | if (_info == null) goto label_10;       
        if(_info == null)
        {
            goto label_10;
        }
        // 0x00BADA1C: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00BADA20: LDR x8, [x8, #0xd50]       | X8 = (string**)(1152921514530001136)("param4");
        // 0x00BADA24: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADA28: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADA2C: LDR x1, [x8]               | X1 = "param4";                          
        // 0x00BADA30: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param4");    
        string val_23 = _info.Item["param4"];
        // 0x00BADA34: STR x0, [x19, #0x40]       | this.param4 = val_23;                    //  dest_result_addr=1152921514530062544
        this.param4 = val_23;
        // 0x00BADA38: B #0xbada60                |  goto label_11;                         
        goto label_11;
        label_10:
        // 0x00BADA3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        // 0x00BADA40: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00BADA44: LDR x8, [x8, #0xd50]       | X8 = (string**)(1152921514530001136)("param4");
        // 0x00BADA48: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADA4C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADA50: LDR x1, [x8]               | X1 = "param4";                          
        // 0x00BADA54: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param4");    
        string val_24 = _info.Item["param4"];
        // 0x00BADA58: STR x0, [x19, #0x40]       | this.param4 = val_24;                    //  dest_result_addr=1152921514530062544
        this.param4 = val_24;
        // 0x00BADA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_11:
        // 0x00BADA60: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00BADA64: LDR x8, [x8, #0xaf0]       | X8 = (string**)(1152921514530009408)("param5");
        // 0x00BADA68: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADA6C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADA70: LDR x1, [x8]               | X1 = "param5";                          
        // 0x00BADA74: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param5");    
        string val_25 = _info.Item["param5"];
        // 0x00BADA78: STR x0, [x19, #0x48]       | this.param5 = val_25;                    //  dest_result_addr=1152921514530062552
        this.param5 = val_25;
        // 0x00BADA7C: CBZ x20, #0xbadaa0         | if (_info == null) goto label_12;       
        if(_info == null)
        {
            goto label_12;
        }
        // 0x00BADA80: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00BADA84: LDR x8, [x8, #0x7b0]       | X8 = (string**)(1152921514530013584)("param6");
        // 0x00BADA88: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADA8C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADA90: LDR x1, [x8]               | X1 = "param6";                          
        // 0x00BADA94: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param6");    
        string val_26 = _info.Item["param6"];
        // 0x00BADA98: STR x0, [x19, #0x50]       | this.param6 = val_26;                    //  dest_result_addr=1152921514530062560
        this.param6 = val_26;
        // 0x00BADA9C: B #0xbadac4                |  goto label_13;                         
        goto label_13;
        label_12:
        // 0x00BADAA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        // 0x00BADAA4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00BADAA8: LDR x8, [x8, #0x7b0]       | X8 = (string**)(1152921514530013584)("param6");
        // 0x00BADAAC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADAB0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADAB4: LDR x1, [x8]               | X1 = "param6";                          
        // 0x00BADAB8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param6");    
        string val_27 = _info.Item["param6"];
        // 0x00BADABC: STR x0, [x19, #0x50]       | this.param6 = val_27;                    //  dest_result_addr=1152921514530062560
        this.param6 = val_27;
        // 0x00BADAC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_13:
        // 0x00BADAC4: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00BADAC8: LDR x8, [x8, #0xba8]       | X8 = (string**)(1152921514530021856)("param7");
        // 0x00BADACC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADAD0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADAD4: LDR x1, [x8]               | X1 = "param7";                          
        // 0x00BADAD8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param7");    
        string val_28 = _info.Item["param7"];
        // 0x00BADADC: STR x0, [x19, #0x58]       | this.param7 = val_28;                    //  dest_result_addr=1152921514530062568
        this.param7 = val_28;
        // 0x00BADAE0: CBZ x20, #0xbadb04         | if (_info == null) goto label_14;       
        if(_info == null)
        {
            goto label_14;
        }
        // 0x00BADAE4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00BADAE8: LDR x8, [x8, #0xfe0]       | X8 = (string**)(1152921514530026032)("param8");
        // 0x00BADAEC: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADAF0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADAF4: LDR x1, [x8]               | X1 = "param8";                          
        // 0x00BADAF8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param8");    
        string val_29 = _info.Item["param8"];
        // 0x00BADAFC: STR x0, [x19, #0x60]       | this.param8 = val_29;                    //  dest_result_addr=1152921514530062576
        this.param8 = val_29;
        // 0x00BADB00: B #0xbadb28                |  goto label_15;                         
        goto label_15;
        label_14:
        // 0x00BADB04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        // 0x00BADB08: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00BADB0C: LDR x8, [x8, #0xfe0]       | X8 = (string**)(1152921514530026032)("param8");
        // 0x00BADB10: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADB14: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADB18: LDR x1, [x8]               | X1 = "param8";                          
        // 0x00BADB1C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "param8");    
        string val_30 = _info.Item["param8"];
        // 0x00BADB20: STR x0, [x19, #0x60]       | this.param8 = val_30;                    //  dest_result_addr=1152921514530062576
        this.param8 = val_30;
        // 0x00BADB24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_15:
        // 0x00BADB28: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00BADB2C: LDR x8, [x8, #0xf80]       | X8 = (string**)(1152921514530034304)("remark");
        // 0x00BADB30: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00BADB34: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00BADB38: LDR x1, [x8]               | X1 = "remark";                          
        // 0x00BADB3C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "remark");    
        string val_31 = _info.Item["remark"];
        // 0x00BADB40: STR x0, [x19, #0x68]       | this.remark = val_31;                    //  dest_result_addr=1152921514530062584
        this.remark = val_31;
        // 0x00BADB44: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BADB48: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BADB4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BADB50: RET                        |  return;                                
        return;
    
    }

}
