using UnityEngine;

namespace ProtoBuf.Meta
{
    public class CallbackSet
    {
        // Fields
        private readonly ProtoBuf.Meta.MetaType metaType; //  0x00000010
        private System.Reflection.MethodInfo beforeSerialize; //  0x00000018
        private System.Reflection.MethodInfo afterSerialize; //  0x00000020
        private System.Reflection.MethodInfo beforeDeserialize; //  0x00000028
        private System.Reflection.MethodInfo afterDeserialize; //  0x00000030
        
        // Properties
        internal System.Reflection.MethodInfo Item { get; }
        public System.Reflection.MethodInfo BeforeSerialize { get; set; }
        public System.Reflection.MethodInfo BeforeDeserialize { get; set; }
        public System.Reflection.MethodInfo AfterSerialize { get; set; }
        public System.Reflection.MethodInfo AfterDeserialize { get; set; }
        public bool NonTrivial { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00C801EC (13107692), len: 160  VirtAddr: 0x00C801EC RVA: 0x00C801EC token: 100689252 methodIndex: 53464 delegateWrapperIndex: 0 methodInvoker: 0
        internal CallbackSet(ProtoBuf.Meta.MetaType metaType)
        {
            //
            // Disasemble & Code
            // 0x00C801EC: STP x22, x21, [sp, #-0x30]! | stack[1152921514353633168] = ???;  stack[1152921514353633176] = ???;  //  dest_result_addr=1152921514353633168 |  dest_result_addr=1152921514353633176
            // 0x00C801F0: STP x20, x19, [sp, #0x10]  | stack[1152921514353633184] = ???;  stack[1152921514353633192] = ???;  //  dest_result_addr=1152921514353633184 |  dest_result_addr=1152921514353633192
            // 0x00C801F4: STP x29, x30, [sp, #0x20]  | stack[1152921514353633200] = ???;  stack[1152921514353633208] = ???;  //  dest_result_addr=1152921514353633200 |  dest_result_addr=1152921514353633208
            // 0x00C801F8: ADD x29, sp, #0x20         | X29 = (1152921514353633168 + 32) = 1152921514353633200 (0x1000000244F427B0);
            // 0x00C801FC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00C80200: LDRB w8, [x21, #0xfa9]     | W8 = (bool)static_value_03733FA9;       
            // 0x00C80204: MOV x19, x1                | X19 = metaType;//m1                     
            // 0x00C80208: MOV x20, x0                | X20 = 1152921514353645216 (0x1000000244F456A0);//ML01
            // 0x00C8020C: TBNZ w8, #0, #0xc80228     | if (static_value_03733FA9 == true) goto label_0;
            // 0x00C80210: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00C80214: LDR x8, [x8, #0x510]       | X8 = 0x2B90090;                         
            // 0x00C80218: LDR w0, [x8]               | W0 = 0x16E8;                            
            // 0x00C8021C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16E8, ????);     
            // 0x00C80220: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C80224: STRB w8, [x21, #0xfa9]     | static_value_03733FA9 = true;            //  dest_result_addr=57884585
            label_0:
            // 0x00C80228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C8022C: MOV x0, x20                | X0 = 1152921514353645216 (0x1000000244F456A0);//ML01
            // 0x00C80230: BL #0x16f59f0              | this..ctor();                           
            // 0x00C80234: CBZ x19, #0xc8024c         | if (metaType == null) goto label_1;     
            if(metaType == null)
            {
                goto label_1;
            }
            // 0x00C80238: STR x19, [x20, #0x10]      | this.metaType = metaType;                //  dest_result_addr=1152921514353645232
            this.metaType = metaType;
            // 0x00C8023C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80240: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C80244: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C80248: RET                        |  return;                                
            return;
            label_1:
            // 0x00C8024C: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00C80250: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00C80254: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_1 = null;
            // 0x00C80258: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C8025C: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x00C80260: LDR x8, [x8, #0x7f0]       | X8 = (string**)(1152921514353583232)("metaType");
            // 0x00C80264: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C80268: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C8026C: LDR x1, [x8]               | X1 = "metaType";                        
            // 0x00C80270: BL #0x18b3df0              | .ctor(paramName:  "metaType");          
            val_1 = new System.ArgumentNullException(paramName:  "metaType");
            // 0x00C80274: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00C80278: LDR x8, [x8, #0x718]       | X8 = 1152921514353583328;               
            // 0x00C8027C: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C80280: LDR x1, [x8]               | X1 = System.Void ProtoBuf.Meta.CallbackSet::.ctor(ProtoBuf.Meta.MetaType metaType);
            // 0x00C80284: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C80288: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
            System.Byte[] val_2 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C8028C (13107852), len: 376  VirtAddr: 0x00C8028C RVA: 0x00C8028C token: 100689253 methodIndex: 53465 delegateWrapperIndex: 0 methodInvoker: 0
        internal System.Reflection.MethodInfo get_Item(ProtoBuf.Meta.TypeModel.CallbackType callbackType)
        {
            //
            // Disasemble & Code
            //  | 
            System.Reflection.MethodInfo val_7;
            // 0x00C8028C: STP x22, x21, [sp, #-0x30]! | stack[1152921514353840624] = ???;  stack[1152921514353840632] = ???;  //  dest_result_addr=1152921514353840624 |  dest_result_addr=1152921514353840632
            // 0x00C80290: STP x20, x19, [sp, #0x10]  | stack[1152921514353840640] = ???;  stack[1152921514353840648] = ???;  //  dest_result_addr=1152921514353840640 |  dest_result_addr=1152921514353840648
            // 0x00C80294: STP x29, x30, [sp, #0x20]  | stack[1152921514353840656] = ???;  stack[1152921514353840664] = ???;  //  dest_result_addr=1152921514353840656 |  dest_result_addr=1152921514353840664
            // 0x00C80298: ADD x29, sp, #0x20         | X29 = (1152921514353840624 + 32) = 1152921514353840656 (0x1000000244F75210);
            // 0x00C8029C: SUB sp, sp, #0x10          | SP = (1152921514353840624 - 16) = 1152921514353840608 (0x1000000244F751E0);
            // 0x00C802A0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00C802A4: LDRB w8, [x21, #0xfaa]     | W8 = (bool)static_value_03733FAA;       
            // 0x00C802A8: MOV w20, w1                | W20 = callbackType;//m1                 
            // 0x00C802AC: MOV x19, x0                | X19 = 1152921514353852672 (0x1000000244F78100);//ML01
            // 0x00C802B0: STR w20, [sp, #0xc]        | stack[1152921514353840620] = callbackType;  //  dest_result_addr=1152921514353840620
            // 0x00C802B4: TBNZ w8, #0, #0xc802d0     | if (static_value_03733FAA == true) goto label_0;
            // 0x00C802B8: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00C802BC: LDR x8, [x8, #0xc88]       | X8 = 0x2B9009C;                         
            // 0x00C802C0: LDR w0, [x8]               | W0 = 0x16EB;                            
            // 0x00C802C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x16EB, ????);     
            // 0x00C802C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C802CC: STRB w8, [x21, #0xfaa]     | static_value_03733FAA = true;            //  dest_result_addr=57884586
            label_0:
            // 0x00C802D0: ADD w8, w20, #3            | W8 = (callbackType + 3);                
            CallbackType val_1 = callbackType + 3;
            // 0x00C802D4: CMP w20, #4                | STATE = COMPARE(callbackType, 0x4)      
            // 0x00C802D8: CSEL w8, w8, wzr, lo       | W8 = callbackType < 0x4 ? (callbackType + 3) : 0;
            var val_2 = (callbackType < 4) ? (val_1) : 0;
            // 0x00C802DC: SUB w8, w8, #3             | W8 = (callbackType < 0x4 ? (callbackType + 3) : 0 - 3);
            val_2 = val_2 - 3;
            // 0x00C802E0: CMP w8, #3                 | STATE = COMPARE((callbackType < 0x4 ? (callbackType + 3) : 0 - 3), 0x3)
            // 0x00C802E4: B.HI #0xc80330             | if (val_2 > 0x3) goto label_1;          
            if(val_2 > 3)
            {
                goto label_1;
            }
            // 0x00C802E8: ADRP x9, #0x2a93000        | X9 = 44642304 (0x2A93000);              
            // 0x00C802EC: ADD x9, x9, #0x8cc         | X9 = (44642304 + 2252) = 44644556 (0x02A938CC);
            // 0x00C802F0: LDRSW x8, [x9, x8, lsl #2] | X8 = 44644556 + ((callbackType < 0x4 ? (callbackType + 3) : 0 - 3)) << 2;
            var val_7 = 44644556 + ((callbackType < 0x4 ? (callbackType + 3) : 0 - 3)) << 2;
            // 0x00C802F4: ADD x8, x8, x9             | X8 = (44644556 + ((callbackType < 0x4 ? (callbackType + 3) : 0 - 3)) << 2 + 44644556);
            val_7 = val_7 + 44644556;
            // 0x00C802F8: BR x8                      | goto (44644556 + ((callbackType < 0x4 ? (callbackType + 3) : 0 - 3)) << 2 + 44644556);
            goto (44644556 + ((callbackType < 0x4 ? (callbackType + 3) : 0 - 3)) << 2 + 44644556);
            // 0x00C802FC: ADD x8, x19, #0x18         | X8 = this.beforeSerialize;//AP2 res_addr=1152921514353852696
            val_7 = this.beforeSerialize;
            // 0x00C80300: B #0xc80318                |  goto label_4;                          
            goto label_4;
            // 0x00C80304: ADD x8, x19, #0x28         | X8 = this.beforeDeserialize;//AP2 res_addr=1152921514353852712
            val_7 = this.beforeDeserialize;
            // 0x00C80308: B #0xc80318                |  goto label_4;                          
            goto label_4;
            // 0x00C8030C: ADD x8, x19, #0x20         | X8 = this.afterSerialize;//AP2 res_addr=1152921514353852704
            val_7 = this.afterSerialize;
            // 0x00C80310: B #0xc80318                |  goto label_4;                          
            goto label_4;
            // 0x00C80314: ADD x8, x19, #0x30         | X8 = this.afterDeserialize;//AP2 res_addr=1152921514353852720
            val_7 = this.afterDeserialize;
            label_4:
            // 0x00C80318: LDR x0, [x8]               |  //  not_find_field!1:0
            // 0x00C8031C: SUB sp, x29, #0x20         | SP = (1152921514353840656 - 32) = 1152921514353840624 (0x1000000244F751F0);
            // 0x00C80320: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80324: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C80328: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C8032C: RET                        |  return (System.Reflection.MethodInfo)mem[this.afterDeserialize];
            return (System.Reflection.MethodInfo)mem[this.afterDeserialize];
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
            label_1:
            // 0x00C80330: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00C80334: LDR x8, [x8, #0x618]       | X8 = 1152921504883523584;               
            // 0x00C80338: ADD x1, sp, #0xc           | X1 = (1152921514353840608 + 12) = 1152921514353840620 (0x1000000244F751EC);
            // 0x00C8033C: LDR x0, [x8]               | X0 = typeof(TypeModel.CallbackType);    
            // 0x00C80340: BL #0x27bc028              | X0 = 1152921514353888768 = (Il2CppObject*)Box((RuntimeClass*)typeof(TypeModel.CallbackType), callbackType);
            // 0x00C80344: MOV x20, x0                | X20 = 1152921514353888768 (0x1000000244F80E00);//ML01
            // 0x00C80348: CBNZ x20, #0xc80350        | if (callbackType != 0) goto label_5;    
            if(callbackType != 0)
            {
                goto label_5;
            }
            // 0x00C8034C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? callbackType, ????);
            label_5:
            // 0x00C80350: LDR x8, [x20]              | X8 = typeof(TypeModel.CallbackType);    
            // 0x00C80354: MOV x0, x20                | X0 = 1152921514353888768 (0x1000000244F80E00);//ML01
            // 0x00C80358: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
            // 0x00C8035C: BLR x9                     | X0 = callbackType.ToString();           
            string val_3 = callbackType.ToString();
            // 0x00C80360: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00C80364: CBNZ x20, #0xc8036c        | if (callbackType != 0) goto label_6;    
            if(callbackType != 0)
            {
                goto label_6;
            }
            // 0x00C80368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x00C8036C: MOV x0, x20                | X0 = 1152921514353888768 (0x1000000244F80E00);//ML01
            // 0x00C80370: BL #0x27bc4e8              | callbackType.System.IDisposable.Dispose();
            callbackType.System.IDisposable.Dispose();
            // 0x00C80374: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00C80378: LDR w8, [x0]               | W8 = typeof(TypeModel.CallbackType);    
            // 0x00C8037C: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x00C80380: STR w8, [sp, #0xc]         | stack[1152921514353840620] = typeof(TypeModel.CallbackType);  //  dest_result_addr=1152921514353840620
            // 0x00C80384: LDR x0, [x9]               | X0 = typeof(System.String);             
            // 0x00C80388: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00C8038C: TBZ w8, #0, #0xc8039c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00C80390: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C80394: CBNZ w8, #0xc8039c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00C80398: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x00C8039C: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x00C803A0: LDR x8, [x8, #0x4d0]       | X8 = (string**)(1152921514353786464)("Callback type not supported: ");
            // 0x00C803A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C803A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C803AC: MOV x2, x19                | X2 = val_3;//m1                         
            // 0x00C803B0: LDR x1, [x8]               | X1 = "Callback type not supported: ";   
            // 0x00C803B4: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Callback type not supported: ");
            string val_4 = System.String.Concat(str0:  0, str1:  "Callback type not supported: ");
            // 0x00C803B8: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00C803BC: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x00C803C0: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00C803C4: LDR x8, [x8]               | X8 = typeof(System.ArgumentException);  
            // 0x00C803C8: MOV x0, x8                 | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            System.ArgumentException val_5 = null;
            // 0x00C803CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x00C803D0: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00C803D4: LDR x8, [x8, #0xe88]       | X8 = (string**)(1152921514353790688)("callbackType");
            // 0x00C803D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C803DC: MOV x1, x19                | X1 = val_4;//m1                         
            // 0x00C803E0: MOV x20, x0                | X20 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00C803E4: LDR x2, [x8]               | X2 = "callbackType";                    
            // 0x00C803E8: BL #0x18b3ee4              | .ctor(message:  val_4, paramName:  "callbackType");
            val_5 = new System.ArgumentException(message:  val_4, paramName:  "callbackType");
            // 0x00C803EC: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00C803F0: LDR x8, [x8, #0x880]       | X8 = 1152921514353790784;               
            // 0x00C803F4: MOV x0, x20                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00C803F8: LDR x1, [x8]               | X1 = System.Reflection.MethodInfo ProtoBuf.Meta.CallbackSet::get_Item(ProtoBuf.Meta.TypeModel.CallbackType callbackType);
            // 0x00C803FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x00C80400: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  44994560);
            System.Byte[] val_6 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  44994560);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80404 (13108228), len: 416  VirtAddr: 0x00C80404 RVA: 0x00C80404 token: 100689254 methodIndex: 53466 delegateWrapperIndex: 0 methodInvoker: 0
        internal static bool CheckCallbackParameters(ProtoBuf.Meta.TypeModel model, System.Reflection.MethodInfo method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00C80404: STP x26, x25, [sp, #-0x50]! | stack[1152921514354030416] = ???;  stack[1152921514354030424] = ???;  //  dest_result_addr=1152921514354030416 |  dest_result_addr=1152921514354030424
            // 0x00C80408: STP x24, x23, [sp, #0x10]  | stack[1152921514354030432] = ???;  stack[1152921514354030440] = ???;  //  dest_result_addr=1152921514354030432 |  dest_result_addr=1152921514354030440
            // 0x00C8040C: STP x22, x21, [sp, #0x20]  | stack[1152921514354030448] = ???;  stack[1152921514354030456] = ???;  //  dest_result_addr=1152921514354030448 |  dest_result_addr=1152921514354030456
            // 0x00C80410: STP x20, x19, [sp, #0x30]  | stack[1152921514354030464] = ???;  stack[1152921514354030472] = ???;  //  dest_result_addr=1152921514354030464 |  dest_result_addr=1152921514354030472
            // 0x00C80414: STP x29, x30, [sp, #0x40]  | stack[1152921514354030480] = ???;  stack[1152921514354030488] = ???;  //  dest_result_addr=1152921514354030480 |  dest_result_addr=1152921514354030488
            // 0x00C80418: ADD x29, sp, #0x40         | X29 = (1152921514354030416 + 64) = 1152921514354030480 (0x1000000244FA3790);
            // 0x00C8041C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00C80420: LDRB w8, [x21, #0xfab]     | W8 = (bool)static_value_03733FAB;       
            // 0x00C80424: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00C80428: MOV x19, x1                | X19 = method;//m1                       
            // 0x00C8042C: TBNZ w8, #0, #0xc80448     | if (static_value_03733FAB == true) goto label_0;
            // 0x00C80430: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00C80434: LDR x8, [x8, #0x718]       | X8 = 0x2B90094;                         
            // 0x00C80438: LDR w0, [x8]               | W0 = 0x16E9;                            
            // 0x00C8043C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16E9, ????);     
            // 0x00C80440: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C80444: STRB w8, [x21, #0xfab]     | static_value_03733FAB = true;            //  dest_result_addr=57884587
            label_0:
            // 0x00C80448: CBNZ x20, #0xc80450        | if (X2 != 0) goto label_1;              
            if(X2 != 0)
            {
                goto label_1;
            }
            // 0x00C8044C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16E9, ????);     
            label_1:
            // 0x00C80450: LDR x8, [x20]              | X8 = X2;                                
            // 0x00C80454: MOV x0, x20                | X0 = X2;//m1                            
            // 0x00C80458: LDR x9, [x8, #0x200]       | X9 = X2 + 512;                          
            // 0x00C8045C: LDR x1, [x8, #0x208]       | X1 = X2 + 520;                          
            val_7 = mem[X2 + 520];
            val_7 = X2 + 520;
            // 0x00C80460: BLR x9                     | X0 = X2 + 512();                        
            // 0x00C80464: ADRP x24, #0x3650000       | X24 = 56950784 (0x3650000);             
            // 0x00C80468: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x00C8046C: ADRP x26, #0x3630000       | X26 = 56819712 (0x3630000);             
            // 0x00C80470: LDR x24, [x24, #0x38]      | X24 = 1152921504884482048;              
            // 0x00C80474: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x00C80478: LDR x26, [x26, #0xac0]     | X26 = 1152921504609562624;              
            // 0x00C8047C: MOV x20, x0                | X20 = X2;//m1                           
            // 0x00C80480: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00C80484: B #0xc8048c                |  goto label_2;                          
            goto label_2;
            label_14:
            // 0x00C80488: ADD w23, w23, #1           | W23 = (val_8 + 1) = val_8 (0x00000001); 
            val_8 = 1;
            label_2:
            // 0x00C8048C: CBNZ x20, #0xc80494        | if (X2 != 0) goto label_3;              
            if(X2 != 0)
            {
                goto label_3;
            }
            // 0x00C80490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_3:
            // 0x00C80494: LDR w8, [x20, #0x18]       | W8 = X2 + 24;                           
            // 0x00C80498: CMP w23, w8                | STATE = COMPARE(0x1, X2 + 24)           
            // 0x00C8049C: B.GE #0xc80588             | if (val_8 >= X2 + 24) goto label_4;     
            if(val_8 >= (X2 + 24))
            {
                goto label_4;
            }
            // 0x00C804A0: SXTW x21, w23              | X21 = 1 (0x00000001);                   
            // 0x00C804A4: CMP w23, w8                | STATE = COMPARE(0x1, X2 + 24)           
            // 0x00C804A8: B.LO #0xc804b8             | if (val_8 < X2 + 24) goto label_5;      
            if(val_8 < (X2 + 24))
            {
                goto label_5;
            }
            // 0x00C804AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
            // 0x00C804B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x00C804B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
            label_5:
            // 0x00C804B8: ADD x8, x20, x21, lsl #3   | X8 = (X2 + 8);                          
            var val_1 = X2 + 8;
            // 0x00C804BC: LDR x21, [x8, #0x20]       | X21 = (X2 + 8) + 32;                    
            // 0x00C804C0: CBNZ x21, #0xc804c8        | if ((X2 + 8) + 32 != 0) goto label_6;   
            if(((X2 + 8) + 32) != 0)
            {
                goto label_6;
            }
            // 0x00C804C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_6:
            // 0x00C804C8: LDR x8, [x21]              | X8 = (X2 + 8) + 32;                     
            // 0x00C804CC: MOV x0, x21                | X0 = (X2 + 8) + 32;//m1                 
            // 0x00C804D0: LDP x9, x1, [x8, #0x170]   | X9 = (X2 + 8) + 32 + 368; X1 = (X2 + 8) + 32 + 368 + 8; //  | 
            // 0x00C804D4: BLR x9                     | X0 = (X2 + 8) + 32 + 368();             
            // 0x00C804D8: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x00C804DC: LDR x22, [x24]             | X22 = typeof(ProtoBuf.SerializationContext);
            // 0x00C804E0: MOV x21, x0                | X21 = (X2 + 8) + 32;//m1                
            val_6 = (X2 + 8) + 32;
            // 0x00C804E4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00C804E8: TBZ w9, #0, #0xc804fc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00C804EC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00C804F0: CBNZ w9, #0xc804fc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00C804F4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00C804F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_8:
            // 0x00C804FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C80500: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C80504: MOV x1, x22                | X1 = 1152921504884482048 (0x10000000108C6000);//ML01
            // 0x00C80508: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00C8050C: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00C80510: CBNZ x19, #0xc80518        | if (method != null) goto label_9;       
            if(method != null)
            {
                goto label_9;
            }
            // 0x00C80514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x00C80518: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C8051C: MOV x0, x19                | X0 = method;//m1                        
            // 0x00C80520: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x00C80524: BL #0x2974090              | X0 = method.MapType(type:  val_2);      
            System.Type val_3 = method.MapType(type:  val_2);
            // 0x00C80528: CMP x21, x0                | STATE = COMPARE((X2 + 8) + 32, val_3)   
            // 0x00C8052C: B.EQ #0xc80488             | if (val_6 == val_3) goto label_14;      
            if(val_6 == val_3)
            {
                goto label_14;
            }
            // 0x00C80530: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x00C80534: LDR x22, [x26]             | X22 = typeof(System.Type);              
            // 0x00C80538: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00C8053C: TBZ w8, #0, #0xc8054c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00C80540: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00C80544: CBNZ w8, #0xc8054c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00C80548: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_12:
            // 0x00C8054C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C80550: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C80554: MOV x1, x22                | X1 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00C80558: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00C8055C: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00C80560: CBNZ x19, #0xc80568        | if (method != null) goto label_13;      
            if(method != null)
            {
                goto label_13;
            }
            // 0x00C80564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x00C80568: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C8056C: MOV x0, x19                | X0 = method;//m1                        
            // 0x00C80570: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00C80574: BL #0x2974090              | X0 = method.MapType(type:  val_4);      
            System.Type val_5 = method.MapType(type:  val_4);
            // 0x00C80578: CMP x21, x0                | STATE = COMPARE((X2 + 8) + 32, val_5)   
            // 0x00C8057C: B.EQ #0xc80488             | if (val_6 == val_5) goto label_14;      
            if(val_6 == val_5)
            {
                goto label_14;
            }
            // 0x00C80580: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x00C80584: B #0xc8058c                |  goto label_15;                         
            goto label_15;
            label_4:
            // 0x00C80588: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_9 = 1;
            label_15:
            // 0x00C8058C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80590: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C80594: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C80598: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C8059C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C805A0: RET                        |  return (System.Boolean)true;           
            return (bool)val_9;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C805A4 (13108644), len: 372  VirtAddr: 0x00C805A4 RVA: 0x00C805A4 token: 100689255 methodIndex: 53467 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Reflection.MethodInfo SanityCheckCallback(ProtoBuf.Meta.TypeModel model, System.Reflection.MethodInfo callback)
        {
            //
            // Disasemble & Code
            //  | 
            ProtoBuf.Meta.MetaType val_10;
            // 0x00C805A4: STP x22, x21, [sp, #-0x30]! | stack[1152921514354266576] = ???;  stack[1152921514354266584] = ???;  //  dest_result_addr=1152921514354266576 |  dest_result_addr=1152921514354266584
            // 0x00C805A8: STP x20, x19, [sp, #0x10]  | stack[1152921514354266592] = ???;  stack[1152921514354266600] = ???;  //  dest_result_addr=1152921514354266592 |  dest_result_addr=1152921514354266600
            // 0x00C805AC: STP x29, x30, [sp, #0x20]  | stack[1152921514354266608] = ???;  stack[1152921514354266616] = ???;  //  dest_result_addr=1152921514354266608 |  dest_result_addr=1152921514354266616
            // 0x00C805B0: ADD x29, sp, #0x20         | X29 = (1152921514354266576 + 32) = 1152921514354266608 (0x1000000244FDD1F0);
            // 0x00C805B4: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00C805B8: LDRB w8, [x22, #0xfac]     | W8 = (bool)static_value_03733FAC;       
            // 0x00C805BC: MOV x19, x2                | X19 = callback;//m1                     
            // 0x00C805C0: MOV x20, x1                | X20 = model;//m1                        
            // 0x00C805C4: MOV x21, x0                | X21 = 1152921514354278624 (0x1000000244FE00E0);//ML01
            // 0x00C805C8: TBNZ w8, #0, #0xc805e4     | if (static_value_03733FAC == true) goto label_0;
            // 0x00C805CC: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00C805D0: LDR x8, [x8, #0xb78]       | X8 = 0x2B900A0;                         
            // 0x00C805D4: LDR w0, [x8]               | W0 = 0x16EC;                            
            // 0x00C805D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16EC, ????);     
            // 0x00C805DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C805E0: STRB w8, [x22, #0xfac]     | static_value_03733FAC = true;            //  dest_result_addr=57884588
            label_0:
            // 0x00C805E4: LDR x21, [x21, #0x10]      | X21 = this.metaType; //P2               
            val_10 = this.metaType;
            // 0x00C805E8: CBNZ x21, #0xc805f0        | if (this.metaType != null) goto label_1;
            if(val_10 != null)
            {
                goto label_1;
            }
            // 0x00C805EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16EC, ????);     
            label_1:
            // 0x00C805F0: MOV x0, x21                | X0 = this.metaType;//m1                 
            // 0x00C805F4: BL #0xc80718               | this.metaType.ThrowIfFrozen();          
            val_10.ThrowIfFrozen();
            // 0x00C805F8: CBZ x19, #0xc8069c         | if (callback == null) goto label_2;     
            if(callback == null)
            {
                goto label_2;
            }
            // 0x00C805FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C80600: MOV x0, x19                | X0 = callback;//m1                      
            // 0x00C80604: BL #0x13bbe68              | X0 = callback.get_IsStatic();           
            bool val_1 = callback.IsStatic;
            // 0x00C80608: TBNZ w0, #0, #0xc806cc     | if (val_1 == true) goto label_3;        
            if(val_1 == true)
            {
                goto label_3;
            }
            // 0x00C8060C: LDR x8, [x19]              | X8 = typeof(System.Reflection.MethodInfo);
            // 0x00C80610: MOV x0, x19                | X0 = callback;//m1                      
            // 0x00C80614: LDR x9, [x8, #0x380]       | X9 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_380;
            // 0x00C80618: LDR x1, [x8, #0x388]       | X1 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_388;
            // 0x00C8061C: BLR x9                     | X0 = typeof(System.Reflection.MethodInfo).__il2cppRuntimeField_380();
            // 0x00C80620: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00C80624: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00C80628: ADRP x9, #0x35de000        | X9 = 56483840 (0x35DE000);              
            // 0x00C8062C: MOV x21, x0                | X21 = callback;//m1                     
            val_10 = callback;
            // 0x00C80630: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00C80634: LDR x9, [x9, #0x3f0]       | X9 = 1152921504609509376;               
            // 0x00C80638: LDR x22, [x9]              | X22 = typeof(System.Void);              
            // 0x00C8063C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00C80640: TBZ w9, #0, #0xc80654      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00C80644: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00C80648: CBNZ w9, #0xc80654         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00C8064C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00C80650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00C80654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C80658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C8065C: MOV x1, x22                | X1 = 1152921504609509376 (0x100000000028A000);//ML01
            // 0x00C80660: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00C80664: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00C80668: CBNZ x20, #0xc80670        | if (model != null) goto label_6;        
            if(model != null)
            {
                goto label_6;
            }
            // 0x00C8066C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00C80670: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C80674: MOV x0, x20                | X0 = model;//m1                         
            // 0x00C80678: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x00C8067C: BL #0x2974090              | X0 = model.MapType(type:  val_2);       
            System.Type val_3 = model.MapType(type:  val_2);
            // 0x00C80680: CMP x21, x0                | STATE = COMPARE(callback, val_3)        
            // 0x00C80684: B.NE #0xc806b0             | if (val_10 != val_3) goto label_8;      
            if(val_10 != val_3)
            {
                goto label_8;
            }
            // 0x00C80688: MOV x1, x20                | X1 = model;//m1                         
            // 0x00C8068C: MOV x2, x19                | X2 = callback;//m1                      
            // 0x00C80690: BL #0xc80404               | X0 = ProtoBuf.Meta.CallbackSet.CheckCallbackParameters(model:  System.Type val_3 = model.MapType(type:  val_2), method:  model);
            bool val_4 = ProtoBuf.Meta.CallbackSet.CheckCallbackParameters(model:  val_3, method:  model);
            // 0x00C80694: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x00C80698: TBZ w8, #0, #0xc806b0      | if ((val_4 & 1) == false) goto label_8; 
            if(val_5 == false)
            {
                goto label_8;
            }
            label_2:
            // 0x00C8069C: MOV x0, x19                | X0 = callback;//m1                      
            // 0x00C806A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C806A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C806A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C806AC: RET                        |  return (System.Reflection.MethodInfo)callback;
            return (System.Reflection.MethodInfo)callback;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
            label_8:
            // 0x00C806B0: MOV x1, x19                | X1 = callback;//m1                      
            // 0x00C806B4: BL #0xc80808               | X0 = ProtoBuf.Meta.CallbackSet.CreateInvalidCallbackSignature(method:  val_3);
            System.Exception val_6 = ProtoBuf.Meta.CallbackSet.CreateInvalidCallbackSignature(method:  val_3);
            // 0x00C806B8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00C806BC: LDR x8, [x8, #0x908]       | X8 = 1152921514354179648;               
            // 0x00C806C0: LDR x1, [x8]               | X1 = System.Reflection.MethodInfo ProtoBuf.Meta.CallbackSet::SanityCheckCallback(ProtoBuf.Meta.TypeModel model, System.Reflection.MethodInfo callback);
            // 0x00C806C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00C806C8: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  System.Exception val_6 = ProtoBuf.Meta.CallbackSet.CreateInvalidCallbackSignature(method:  val_3));
            System.Byte[] val_7 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  val_6);
            label_3:
            // 0x00C806CC: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00C806D0: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x00C806D4: LDR x0, [x8]               | X0 = typeof(System.ArgumentException);  
            System.ArgumentException val_8 = null;
            // 0x00C806D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x00C806DC: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00C806E0: ADRP x9, #0x364e000        | X9 = 56942592 (0x364E000);              
            // 0x00C806E4: LDR x8, [x8, #0xe68]       | X8 = (string**)(1152921514354217536)("Callbacks cannot be static");
            // 0x00C806E8: LDR x9, [x9, #0xd08]       | X9 = (string**)(1152921514354217664)("callback");
            // 0x00C806EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C806F0: MOV x19, x0                | X19 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00C806F4: LDR x1, [x8]               | X1 = "Callbacks cannot be static";      
            // 0x00C806F8: LDR x2, [x9]               | X2 = "callback";                        
            // 0x00C806FC: BL #0x18b3ee4              | .ctor(message:  "Callbacks cannot be static", paramName:  "callback");
            val_8 = new System.ArgumentException(message:  "Callbacks cannot be static", paramName:  "callback");
            // 0x00C80700: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00C80704: LDR x8, [x8, #0x908]       | X8 = 1152921514354179648;               
            // 0x00C80708: MOV x0, x19                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x00C8070C: LDR x1, [x8]               | X1 = System.Reflection.MethodInfo ProtoBuf.Meta.CallbackSet::SanityCheckCallback(ProtoBuf.Meta.TypeModel model, System.Reflection.MethodInfo callback);
            // 0x00C80710: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x00C80714: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  44994560);
            System.Byte[] val_9 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  44994560);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80808 (13109256), len: 268  VirtAddr: 0x00C80808 RVA: 0x00C80808 token: 100689256 methodIndex: 53468 delegateWrapperIndex: 0 methodInvoker: 0
        internal static System.Exception CreateInvalidCallbackSignature(System.Reflection.MethodInfo method)
        {
            //
            // Disasemble & Code
            // 0x00C80808: STP x20, x19, [sp, #-0x20]! | stack[1152921514354485216] = ???;  stack[1152921514354485224] = ???;  //  dest_result_addr=1152921514354485216 |  dest_result_addr=1152921514354485224
            // 0x00C8080C: STP x29, x30, [sp, #0x10]  | stack[1152921514354485232] = ???;  stack[1152921514354485240] = ???;  //  dest_result_addr=1152921514354485232 |  dest_result_addr=1152921514354485240
            // 0x00C80810: ADD x29, sp, #0x10         | X29 = (1152921514354485216 + 16) = 1152921514354485232 (0x10000002450127F0);
            // 0x00C80814: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C80818: LDRB w8, [x20, #0xfad]     | W8 = (bool)static_value_03733FAD;       
            // 0x00C8081C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00C80820: TBNZ w8, #0, #0xc8083c     | if (static_value_03733FAD == true) goto label_0;
            // 0x00C80824: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00C80828: LDR x8, [x8, #0x7d8]       | X8 = 0x2B90098;                         
            // 0x00C8082C: LDR w0, [x8]               | W0 = 0x16EA;                            
            // 0x00C80830: BL #0x2782188              | X0 = sub_2782188( ?? 0x16EA, ????);     
            // 0x00C80834: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C80838: STRB w8, [x20, #0xfad]     | static_value_03733FAD = true;            //  dest_result_addr=57884589
            label_0:
            // 0x00C8083C: CBNZ x19, #0xc80844        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00C80840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16EA, ????);     
            label_1:
            // 0x00C80844: LDR x8, [x19]              | X8 = X1;                                
            // 0x00C80848: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C8084C: LDP x9, x1, [x8, #0x170]   | X9 = X1 + 368; X1 = X1 + 368 + 8;        //  | 
            // 0x00C80850: BLR x9                     | X0 = X1 + 368();                        
            // 0x00C80854: MOV x20, x0                | X20 = X1;//m1                           
            // 0x00C80858: CBNZ x20, #0xc80860        | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x00C8085C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_2:
            // 0x00C80860: LDR x8, [x20]              | X8 = X1;                                
            // 0x00C80864: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00C80868: LDR x9, [x8, #0x230]       | X9 = X1 + 560;                          
            // 0x00C8086C: LDR x1, [x8, #0x238]       | X1 = X1 + 568;                          
            // 0x00C80870: BLR x9                     | X0 = X1 + 560();                        
            // 0x00C80874: LDR x8, [x19]              | X8 = X1;                                
            // 0x00C80878: MOV x20, x0                | X20 = X1;//m1                           
            // 0x00C8087C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C80880: LDP x9, x1, [x8, #0x190]   | X9 = X1 + 400; X1 = X1 + 400 + 8;        //  | 
            // 0x00C80884: BLR x9                     | X0 = X1 + 400();                        
            // 0x00C80888: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C8088C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00C80890: MOV x19, x0                | X19 = X1;//m1                           
            // 0x00C80894: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00C80898: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00C8089C: TBZ w9, #0, #0xc808b0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C808A0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C808A4: CBNZ w9, #0xc808b0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C808A8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00C808AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_4:
            // 0x00C808B0: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00C808B4: ADRP x9, #0x35e0000        | X9 = 56492032 (0x35E0000);              
            // 0x00C808B8: LDR x8, [x8, #0xdb8]       | X8 = (string**)(1152921514354469024)("Invalid callback signature in ");
            // 0x00C808BC: LDR x9, [x9, #0x9a0]       | X9 = (string**)(1152921509414037808)(".");
            // 0x00C808C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C808C4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C808C8: LDR x1, [x8]               | X1 = "Invalid callback signature in ";  
            // 0x00C808CC: LDR x3, [x9]               | X3 = ".";                               
            // 0x00C808D0: MOV x2, x20                | X2 = X1;//m1                            
            // 0x00C808D4: MOV x4, x19                | X4 = X1;//m1                            
            // 0x00C808D8: BL #0x18b0400              | X0 = System.String.Concat(str0:  0, str1:  "Invalid callback signature in ", str2:  X1, str3:  ".");
            string val_1 = System.String.Concat(str0:  0, str1:  "Invalid callback signature in ", str2:  X1, str3:  ".");
            // 0x00C808DC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00C808E0: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x00C808E4: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00C808E8: LDR x8, [x8]               | X8 = typeof(System.NotSupportedException);
            // 0x00C808EC: MOV x0, x8                 | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            System.NotSupportedException val_2 = null;
            // 0x00C808F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x00C808F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C808F8: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00C808FC: MOV x20, x0                | X20 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00C80900: BL #0x16f7cac              | .ctor(message:  val_1);                 
            val_2 = new System.NotSupportedException(message:  val_1);
            // 0x00C80904: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80908: MOV x0, x20                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00C8090C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C80910: RET                        |  return (System.Exception)typeof(System.NotSupportedException);
            return (System.Exception)val_2;
            //  |  // // {name=val_0, type=System.Exception, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80914 (13109524), len: 8  VirtAddr: 0x00C80914 RVA: 0x00C80914 token: 100689257 methodIndex: 53469 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.MethodInfo get_BeforeSerialize()
        {
            //
            // Disasemble & Code
            // 0x00C80914: LDR x0, [x0, #0x18]        | X0 = this.beforeSerialize; //P2         
            // 0x00C80918: RET                        |  return (System.Reflection.MethodInfo)this.beforeSerialize;
            return this.beforeSerialize;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C8091C (13109532), len: 72  VirtAddr: 0x00C8091C RVA: 0x00C8091C token: 100689258 methodIndex: 53470 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_BeforeSerialize(System.Reflection.MethodInfo value)
        {
            //
            // Disasemble & Code
            // 0x00C8091C: STP x22, x21, [sp, #-0x30]! | stack[1152921514354741968] = ???;  stack[1152921514354741976] = ???;  //  dest_result_addr=1152921514354741968 |  dest_result_addr=1152921514354741976
            // 0x00C80920: STP x20, x19, [sp, #0x10]  | stack[1152921514354741984] = ???;  stack[1152921514354741992] = ???;  //  dest_result_addr=1152921514354741984 |  dest_result_addr=1152921514354741992
            // 0x00C80924: STP x29, x30, [sp, #0x20]  | stack[1152921514354742000] = ???;  stack[1152921514354742008] = ???;  //  dest_result_addr=1152921514354742000 |  dest_result_addr=1152921514354742008
            // 0x00C80928: ADD x29, sp, #0x20         | X29 = (1152921514354741968 + 32) = 1152921514354742000 (0x10000002450512F0);
            // 0x00C8092C: MOV x19, x0                | X19 = 1152921514354754016 (0x10000002450541E0);//ML01
            // 0x00C80930: LDR x21, [x19, #0x10]      | X21 = this.metaType; //P2               
            // 0x00C80934: MOV x20, x1                | X20 = value;//m1                        
            // 0x00C80938: CBNZ x21, #0xc80940        | if (this.metaType != null) goto label_0;
            if(this.metaType != null)
            {
                goto label_0;
            }
            // 0x00C8093C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C80940: LDR x1, [x21, #0x38]       | X1 = this.metaType.model; //P2          
            // 0x00C80944: MOV x0, x19                | X0 = 1152921514354754016 (0x10000002450541E0);//ML01
            // 0x00C80948: MOV x2, x20                | X2 = value;//m1                         
            // 0x00C8094C: BL #0xc805a4               | X0 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            System.Reflection.MethodInfo val_1 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            // 0x00C80950: STR x0, [x19, #0x18]       | this.beforeSerialize = val_1;            //  dest_result_addr=1152921514354754040
            this.beforeSerialize = val_1;
            // 0x00C80954: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80958: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C8095C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C80960: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C8096C (13109612), len: 8  VirtAddr: 0x00C8096C RVA: 0x00C8096C token: 100689259 methodIndex: 53471 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.MethodInfo get_BeforeDeserialize()
        {
            //
            // Disasemble & Code
            // 0x00C8096C: LDR x0, [x0, #0x28]        | X0 = this.beforeDeserialize; //P2       
            // 0x00C80970: RET                        |  return (System.Reflection.MethodInfo)this.beforeDeserialize;
            return this.beforeDeserialize;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80974 (13109620), len: 72  VirtAddr: 0x00C80974 RVA: 0x00C80974 token: 100689260 methodIndex: 53472 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_BeforeDeserialize(System.Reflection.MethodInfo value)
        {
            //
            // Disasemble & Code
            // 0x00C80974: STP x22, x21, [sp, #-0x30]! | stack[1152921514355006928] = ???;  stack[1152921514355006936] = ???;  //  dest_result_addr=1152921514355006928 |  dest_result_addr=1152921514355006936
            // 0x00C80978: STP x20, x19, [sp, #0x10]  | stack[1152921514355006944] = ???;  stack[1152921514355006952] = ???;  //  dest_result_addr=1152921514355006944 |  dest_result_addr=1152921514355006952
            // 0x00C8097C: STP x29, x30, [sp, #0x20]  | stack[1152921514355006960] = ???;  stack[1152921514355006968] = ???;  //  dest_result_addr=1152921514355006960 |  dest_result_addr=1152921514355006968
            // 0x00C80980: ADD x29, sp, #0x20         | X29 = (1152921514355006928 + 32) = 1152921514355006960 (0x1000000245091DF0);
            // 0x00C80984: MOV x19, x0                | X19 = 1152921514355018976 (0x1000000245094CE0);//ML01
            // 0x00C80988: LDR x21, [x19, #0x10]      | X21 = this.metaType; //P2               
            // 0x00C8098C: MOV x20, x1                | X20 = value;//m1                        
            // 0x00C80990: CBNZ x21, #0xc80998        | if (this.metaType != null) goto label_0;
            if(this.metaType != null)
            {
                goto label_0;
            }
            // 0x00C80994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C80998: LDR x1, [x21, #0x38]       | X1 = this.metaType.model; //P2          
            // 0x00C8099C: MOV x0, x19                | X0 = 1152921514355018976 (0x1000000245094CE0);//ML01
            // 0x00C809A0: MOV x2, x20                | X2 = value;//m1                         
            // 0x00C809A4: BL #0xc805a4               | X0 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            System.Reflection.MethodInfo val_1 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            // 0x00C809A8: STR x0, [x19, #0x28]       | this.beforeDeserialize = val_1;          //  dest_result_addr=1152921514355019016
            this.beforeDeserialize = val_1;
            // 0x00C809AC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C809B0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C809B4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C809B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C809BC (13109692), len: 8  VirtAddr: 0x00C809BC RVA: 0x00C809BC token: 100689261 methodIndex: 53473 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.MethodInfo get_AfterSerialize()
        {
            //
            // Disasemble & Code
            // 0x00C809BC: LDR x0, [x0, #0x20]        | X0 = this.afterSerialize; //P2          
            // 0x00C809C0: RET                        |  return (System.Reflection.MethodInfo)this.afterSerialize;
            return this.afterSerialize;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C809C4 (13109700), len: 72  VirtAddr: 0x00C809C4 RVA: 0x00C809C4 token: 100689262 methodIndex: 53474 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_AfterSerialize(System.Reflection.MethodInfo value)
        {
            //
            // Disasemble & Code
            // 0x00C809C4: STP x22, x21, [sp, #-0x30]! | stack[1152921514355271888] = ???;  stack[1152921514355271896] = ???;  //  dest_result_addr=1152921514355271888 |  dest_result_addr=1152921514355271896
            // 0x00C809C8: STP x20, x19, [sp, #0x10]  | stack[1152921514355271904] = ???;  stack[1152921514355271912] = ???;  //  dest_result_addr=1152921514355271904 |  dest_result_addr=1152921514355271912
            // 0x00C809CC: STP x29, x30, [sp, #0x20]  | stack[1152921514355271920] = ???;  stack[1152921514355271928] = ???;  //  dest_result_addr=1152921514355271920 |  dest_result_addr=1152921514355271928
            // 0x00C809D0: ADD x29, sp, #0x20         | X29 = (1152921514355271888 + 32) = 1152921514355271920 (0x10000002450D28F0);
            // 0x00C809D4: MOV x19, x0                | X19 = 1152921514355283936 (0x10000002450D57E0);//ML01
            // 0x00C809D8: LDR x21, [x19, #0x10]      | X21 = this.metaType; //P2               
            // 0x00C809DC: MOV x20, x1                | X20 = value;//m1                        
            // 0x00C809E0: CBNZ x21, #0xc809e8        | if (this.metaType != null) goto label_0;
            if(this.metaType != null)
            {
                goto label_0;
            }
            // 0x00C809E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C809E8: LDR x1, [x21, #0x38]       | X1 = this.metaType.model; //P2          
            // 0x00C809EC: MOV x0, x19                | X0 = 1152921514355283936 (0x10000002450D57E0);//ML01
            // 0x00C809F0: MOV x2, x20                | X2 = value;//m1                         
            // 0x00C809F4: BL #0xc805a4               | X0 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            System.Reflection.MethodInfo val_1 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            // 0x00C809F8: STR x0, [x19, #0x20]       | this.afterSerialize = val_1;             //  dest_result_addr=1152921514355283968
            this.afterSerialize = val_1;
            // 0x00C809FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80A00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C80A04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C80A08: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80A0C (13109772), len: 8  VirtAddr: 0x00C80A0C RVA: 0x00C80A0C token: 100689263 methodIndex: 53475 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Reflection.MethodInfo get_AfterDeserialize()
        {
            //
            // Disasemble & Code
            // 0x00C80A0C: LDR x0, [x0, #0x30]        | X0 = this.afterDeserialize; //P2        
            // 0x00C80A10: RET                        |  return (System.Reflection.MethodInfo)this.afterDeserialize;
            return this.afterDeserialize;
            //  |  // // {name=val_0, type=System.Reflection.MethodInfo, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80A14 (13109780), len: 72  VirtAddr: 0x00C80A14 RVA: 0x00C80A14 token: 100689264 methodIndex: 53476 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_AfterDeserialize(System.Reflection.MethodInfo value)
        {
            //
            // Disasemble & Code
            // 0x00C80A14: STP x22, x21, [sp, #-0x30]! | stack[1152921514355536848] = ???;  stack[1152921514355536856] = ???;  //  dest_result_addr=1152921514355536848 |  dest_result_addr=1152921514355536856
            // 0x00C80A18: STP x20, x19, [sp, #0x10]  | stack[1152921514355536864] = ???;  stack[1152921514355536872] = ???;  //  dest_result_addr=1152921514355536864 |  dest_result_addr=1152921514355536872
            // 0x00C80A1C: STP x29, x30, [sp, #0x20]  | stack[1152921514355536880] = ???;  stack[1152921514355536888] = ???;  //  dest_result_addr=1152921514355536880 |  dest_result_addr=1152921514355536888
            // 0x00C80A20: ADD x29, sp, #0x20         | X29 = (1152921514355536848 + 32) = 1152921514355536880 (0x10000002451133F0);
            // 0x00C80A24: MOV x19, x0                | X19 = 1152921514355548896 (0x10000002451162E0);//ML01
            // 0x00C80A28: LDR x21, [x19, #0x10]      | X21 = this.metaType; //P2               
            // 0x00C80A2C: MOV x20, x1                | X20 = value;//m1                        
            // 0x00C80A30: CBNZ x21, #0xc80a38        | if (this.metaType != null) goto label_0;
            if(this.metaType != null)
            {
                goto label_0;
            }
            // 0x00C80A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00C80A38: LDR x1, [x21, #0x38]       | X1 = this.metaType.model; //P2          
            // 0x00C80A3C: MOV x0, x19                | X0 = 1152921514355548896 (0x10000002451162E0);//ML01
            // 0x00C80A40: MOV x2, x20                | X2 = value;//m1                         
            // 0x00C80A44: BL #0xc805a4               | X0 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            System.Reflection.MethodInfo val_1 = this.SanityCheckCallback(model:  this.metaType.model, callback:  value);
            // 0x00C80A48: STR x0, [x19, #0x30]       | this.afterDeserialize = val_1;           //  dest_result_addr=1152921514355548944
            this.afterDeserialize = val_1;
            // 0x00C80A4C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00C80A50: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00C80A54: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00C80A58: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C80A5C (13109852), len: 48  VirtAddr: 0x00C80A5C RVA: 0x00C80A5C token: 100689265 methodIndex: 53477 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_NonTrivial()
        {
            //
            // Disasemble & Code
            // 0x00C80A5C: LDR x8, [x0, #0x18]        | X8 = this.beforeSerialize; //P2         
            // 0x00C80A60: CBNZ x8, #0xc80a74         | if (this.beforeSerialize != null) goto label_1;
            if(this.beforeSerialize != null)
            {
                goto label_1;
            }
            // 0x00C80A64: LDR x8, [x0, #0x28]        | X8 = this.beforeDeserialize; //P2       
            // 0x00C80A68: CBNZ x8, #0xc80a74         | if (this.beforeDeserialize != null) goto label_1;
            if(this.beforeDeserialize != null)
            {
                goto label_1;
            }
            // 0x00C80A6C: LDR x8, [x0, #0x20]        | X8 = this.afterSerialize; //P2          
            // 0x00C80A70: CBZ x8, #0xc80a7c          | if (this.afterSerialize == null) goto label_2;
            if(this.afterSerialize == null)
            {
                goto label_2;
            }
            label_1:
            // 0x00C80A74: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00C80A78: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_2:
            // 0x00C80A7C: LDR x8, [x0, #0x30]        | X8 = this.afterDeserialize; //P2        
            // 0x00C80A80: CMP x8, #0                 | STATE = COMPARE(this.afterDeserialize, 0x0)
            // 0x00C80A84: CSET w0, ne                | W0 = this.afterDeserialize != null ? 1 : 0;
            var val_1 = (this.afterDeserialize != 0) ? 1 : 0;
            // 0x00C80A88: RET                        |  return (System.Boolean)this.afterDeserialize != null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
