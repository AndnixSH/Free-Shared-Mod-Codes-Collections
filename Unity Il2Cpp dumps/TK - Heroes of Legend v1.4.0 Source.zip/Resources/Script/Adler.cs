using UnityEngine;

namespace Pathfinding.Ionic.Zlib
{
    public sealed class Adler
    {
        // Fields
        private static readonly uint BASE; // static_offset: 0x00000000
        private static readonly int NMAX; // static_offset: 0x00000004
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0198A608 (26781192), len: 100  VirtAddr: 0x0198A608 RVA: 0x0198A608 token: 100663858 methodIndex: 21270 delegateWrapperIndex: 0 methodInvoker: 0
        private static Adler()
        {
            //
            // Disasemble & Code
            // 0x0198A608: STP x20, x19, [sp, #-0x20]! | stack[1152921509730402800] = ???;  stack[1152921509730402808] = ???;  //  dest_result_addr=1152921509730402800 |  dest_result_addr=1152921509730402808
            // 0x0198A60C: STP x29, x30, [sp, #0x10]  | stack[1152921509730402816] = ???;  stack[1152921509730402824] = ???;  //  dest_result_addr=1152921509730402816 |  dest_result_addr=1152921509730402824
            // 0x0198A610: ADD x29, sp, #0x10         | X29 = (1152921509730402800 + 16) = 1152921509730402816 (0x1000000131634200);
            // 0x0198A614: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x0198A618: LDRB w8, [x19, #0x4a8]     | W8 = (bool)static_value_037394A8;       
            // 0x0198A61C: TBNZ w8, #0, #0x198a638    | if (static_value_037394A8 == true) goto label_0;
            // 0x0198A620: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x0198A624: LDR x8, [x8, #0x420]       | X8 = 0x2B8AA50;                         
            // 0x0198A628: LDR w0, [x8]               | W0 = 0x152;                             
            // 0x0198A62C: BL #0x2782188              | X0 = sub_2782188( ?? 0x152, ????);      
            // 0x0198A630: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0198A634: STRB w8, [x19, #0x4a8]     | static_value_037394A8 = true;            //  dest_result_addr=57906344
            label_0:
            // 0x0198A638: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0198A63C: LDR x8, [x8, #0x9e0]       | X8 = 1152921504753704960;               
            // 0x0198A640: MOVZ w10, #0xfff1          | W10 = 65521 (0xFFF1);//ML01             
            // 0x0198A644: LDR x9, [x8]               | X9 = typeof(Pathfinding.Ionic.Zlib.Adler);
            // 0x0198A648: LDR x9, [x9, #0xa0]        | X9 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_static_fields;
            // 0x0198A64C: STR w10, [x9]              | Pathfinding.Ionic.Zlib.Adler.BASE = 0xFFF1;  //  dest_result_addr=1152921504753709056
            Pathfinding.Ionic.Zlib.Adler.BASE = 65521;
            // 0x0198A650: LDR x8, [x8]               | X8 = typeof(Pathfinding.Ionic.Zlib.Adler);
            // 0x0198A654: MOVZ w9, #0x15b0           | W9 = 5552 (0x15B0);//ML01               
            // 0x0198A658: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_static_fields;
            // 0x0198A65C: STR w9, [x8, #4]           | Pathfinding.Ionic.Zlib.Adler.NMAX = 5552;  //  dest_result_addr=1152921504753709060
            Pathfinding.Ionic.Zlib.Adler.NMAX = 5552;
            // 0x0198A660: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0198A664: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0198A668: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0198A66C (26781292), len: 1340  VirtAddr: 0x0198A66C RVA: 0x0198A66C token: 100663859 methodIndex: 21271 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint Adler32(uint adler, byte[] buf, int index, int len)
        {
            //
            // Disasemble & Code
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            int val_61;
            //  | 
            var val_62;
            //  | 
            var val_63;
            //  | 
            var val_64;
            //  | 
            var val_65;
            //  | 
            var val_66;
            //  | 
            var val_67;
            //  | 
            var val_68;
            //  | 
            var val_69;
            //  | 
            var val_70;
            //  | 
            var val_71;
            //  | 
            var val_72;
            //  | 
            var val_73;
            // 0x0198A66C: STP x28, x27, [sp, #-0x60]! | stack[1152921509730551600] = ???;  stack[1152921509730551608] = ???;  //  dest_result_addr=1152921509730551600 |  dest_result_addr=1152921509730551608
            // 0x0198A670: STP x26, x25, [sp, #0x10]  | stack[1152921509730551616] = ???;  stack[1152921509730551624] = ???;  //  dest_result_addr=1152921509730551616 |  dest_result_addr=1152921509730551624
            // 0x0198A674: STP x24, x23, [sp, #0x20]  | stack[1152921509730551632] = ???;  stack[1152921509730551640] = ???;  //  dest_result_addr=1152921509730551632 |  dest_result_addr=1152921509730551640
            // 0x0198A678: STP x22, x21, [sp, #0x30]  | stack[1152921509730551648] = ???;  stack[1152921509730551656] = ???;  //  dest_result_addr=1152921509730551648 |  dest_result_addr=1152921509730551656
            // 0x0198A67C: STP x20, x19, [sp, #0x40]  | stack[1152921509730551664] = ???;  stack[1152921509730551672] = ???;  //  dest_result_addr=1152921509730551664 |  dest_result_addr=1152921509730551672
            // 0x0198A680: STP x29, x30, [sp, #0x50]  | stack[1152921509730551680] = ???;  stack[1152921509730551688] = ???;  //  dest_result_addr=1152921509730551680 |  dest_result_addr=1152921509730551688
            // 0x0198A684: ADD x29, sp, #0x50         | X29 = (1152921509730551600 + 80) = 1152921509730551680 (0x1000000131658780);
            // 0x0198A688: SUB sp, sp, #0x20          | SP = (1152921509730551600 - 32) = 1152921509730551568 (0x1000000131658710);
            // 0x0198A68C: ADRP x19, #0x3739000       | X19 = 57905152 (0x3739000);             
            // 0x0198A690: LDRB w8, [x19, #0x4a9]     | W8 = (bool)static_value_037394A9;       
            // 0x0198A694: MOV w27, w4                | W27 = W4;//m1                           
            val_55 = W4;
            // 0x0198A698: MOV w20, w3                | W20 = len;//m1                          
            val_56 = len;
            // 0x0198A69C: MOV x21, x2                | X21 = index;//m1                        
            // 0x0198A6A0: MOV w22, w1                | W22 = buf;//m1                          
            // 0x0198A6A4: TBNZ w8, #0, #0x198a6c0    | if (static_value_037394A9 == true) goto label_0;
            // 0x0198A6A8: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x0198A6AC: LDR x8, [x8, #0x7a0]       | X8 = 0x2B8AA54;                         
            // 0x0198A6B0: LDR w0, [x8]               | W0 = 0x153;                             
            // 0x0198A6B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x153, ????);      
            // 0x0198A6B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0198A6BC: STRB w8, [x19, #0x4a9]     | static_value_037394A9 = true;            //  dest_result_addr=57906345
            label_0:
            // 0x0198A6C0: CBZ x21, #0x198ab84        | if (index == 0) goto label_1;           
            if(index == 0)
            {
                goto label_1;
            }
            // 0x0198A6C4: AND w26, w22, #0xffff      | W26 = (buf & 65535);                    
            val_57 = buf & 65535;
            // 0x0198A6C8: LSR w22, w22, #0x10        | W22 = (buf >> 16);                      
            val_58 = buf >> 16;
            // 0x0198A6CC: CMP w27, #1                | STATE = COMPARE(W4, 0x1)                
            // 0x0198A6D0: B.LT #0x198ab7c            | if (val_55 < 0x1) goto label_2;         
            if(val_55 < 1)
            {
                goto label_2;
            }
            // 0x0198A6D4: ADRP x28, #0x3660000       | X28 = 57016320 (0x3660000);             
            // 0x0198A6D8: LDR x28, [x28, #0x9e0]     | X28 = 1152921504753704960;              
            val_59 = 1152921504753704960;
            // 0x0198A6DC: LDR x0, [x28]              | X0 = typeof(Pathfinding.Ionic.Zlib.Adler);
            val_60 = null;
            label_33:
            // 0x0198A6E0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_10A;
            // 0x0198A6E4: TBZ w8, #0, #0x198a6f8     | if (Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0198A6E8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_cctor_finished;
            // 0x0198A6EC: CBNZ w8, #0x198a6f8        | if (Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0198A6F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A6F4: LDR x0, [x28]              | X0 = typeof(Pathfinding.Ionic.Zlib.Adler);
            val_60 = null;
            label_4:
            // 0x0198A6F8: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_static_fields;
            // 0x0198A6FC: LDR w8, [x8, #4]           | W8 = Pathfinding.Ionic.Zlib.Adler.NMAX; 
            // 0x0198A700: CMP w27, w8                | STATE = COMPARE(W4, Pathfinding.Ionic.Zlib.Adler.NMAX)
            // 0x0198A704: MOV w10, w27               | W10 = W4;//m1                           
            val_61 = val_55;
            // 0x0198A708: B.LT #0x198a738            | if (val_55 < Pathfinding.Ionic.Zlib.Adler.NMAX) goto label_8;
            if(val_55 < Pathfinding.Ionic.Zlib.Adler.NMAX)
            {
                goto label_8;
            }
            // 0x0198A70C: LDRB w9, [x0, #0x10a]      | W9 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_10A;
            // 0x0198A710: TBNZ w9, #0, #0x198a71c    | if (Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_has_cctor != 0) goto label_6;
            // 0x0198A714: MOV w10, w8                | W10 = Pathfinding.Ionic.Zlib.Adler.NMAX;//m1
            val_61 = Pathfinding.Ionic.Zlib.Adler.NMAX;
            // 0x0198A718: B #0x198a738               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x0198A71C: LDR w9, [x0, #0xbc]        | W9 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_cctor_finished;
            // 0x0198A720: MOV w10, w8                | W10 = Pathfinding.Ionic.Zlib.Adler.NMAX;//m1
            val_61 = Pathfinding.Ionic.Zlib.Adler.NMAX;
            // 0x0198A724: CBNZ w9, #0x198a738        | if (Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0198A728: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A72C: LDR x8, [x28]              | X8 = typeof(Pathfinding.Ionic.Zlib.Adler);
            // 0x0198A730: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_static_fields;
            // 0x0198A734: LDR w10, [x8, #4]          | W10 = Pathfinding.Ionic.Zlib.Adler.NMAX;
            val_61 = Pathfinding.Ionic.Zlib.Adler.NMAX;
            label_8:
            // 0x0198A738: SUBS w8, w10, #0x10        | W8 = (Pathfinding.Ionic.Zlib.Adler.NMAX - 16);
            int val_1 = val_61 - 16;
            // 0x0198A73C: B.GE #0x198a74c            | if (val_55 >= Pathfinding.Ionic.Zlib.Adler.NMAX) goto label_9;
            if(val_55 >= Pathfinding.Ionic.Zlib.Adler.NMAX)
            {
                goto label_9;
            }
            // 0x0198A740: MOV w24, w10               | W24 = Pathfinding.Ionic.Zlib.Adler.NMAX;//m1
            val_62 = val_61;
            // 0x0198A744: STR w10, [sp, #0x1c]       | stack[1152921509730551596] = Pathfinding.Ionic.Zlib.Adler.NMAX;  //  dest_result_addr=1152921509730551596
            // 0x0198A748: B #0x198aaec               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x0198A74C: STP w8, w27, [sp, #0x14]   | stack[1152921509730551588] = (Pathfinding.Ionic.Zlib.Adler.NMAX - 16);  stack[1152921509730551592] = W4;  //  dest_result_addr=1152921509730551588 |  dest_result_addr=1152921509730551592
            // 0x0198A750: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            var val_49 = 0;
            // 0x0198A754: AND w9, w8, #0xfffffff0    | W9 = ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280);
            int val_2 = val_1 & 4294967280;
            // 0x0198A758: ADD w8, w20, #0x10         | W8 = (len + 16);                        
            int val_3 = val_56 + 16;
            // 0x0198A75C: MOV w28, w10               | W28 = Pathfinding.Ionic.Zlib.Adler.NMAX;//m1
            var val_48 = val_61;
            // 0x0198A760: STP w8, w9, [sp, #0xc]     | stack[1152921509730551580] = (len + 16);  stack[1152921509730551584] = ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280);  //  dest_result_addr=1152921509730551580 |  dest_result_addr=1152921509730551584
            // 0x0198A764: STR w10, [sp, #0x1c]       | stack[1152921509730551596] = Pathfinding.Ionic.Zlib.Adler.NMAX;  //  dest_result_addr=1152921509730551596
            label_27:
            // 0x0198A768: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            // 0x0198A76C: ADD w19, w20, w27          | W19 = (len + 0);                        
            int val_4 = val_56 + val_49;
            // 0x0198A770: ADD w25, w19, #1           | W25 = ((len + 0) + 1);                  
            int val_5 = val_4 + 1;
            // 0x0198A774: SXTW x24, w19              | X24 = (long)(int)((len + 0));           
            // 0x0198A778: CMP w19, w8                | STATE = COMPARE((len + 0), index + 24)  
            // 0x0198A77C: B.LO #0x198a790            | if (val_4 < val_63) goto label_11;      
            if(val_4 < val_63)
            {
                goto label_11;
            }
            // 0x0198A780: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A788: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A78C: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_11:
            // 0x0198A790: ADD x9, x21, x24           | X9 = (index + (long)(int)((len + 0)));  
            int val_6 = index + (long)val_4;
            // 0x0198A794: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)((len + 0))) + 32;
            // 0x0198A798: SXTW x23, w25              | X23 = (long)(int)(((len + 0) + 1));     
            // 0x0198A79C: ADD w25, w24, #1           | W25 = ((long)(int)((len + 0)) + 1);     
            var val_7 = (long)val_4 + 1;
            // 0x0198A7A0: ADD w19, w19, #2           | W19 = ((len + 0) + 2);                  
            val_4 = val_4 + 2;
            // 0x0198A7A4: ADD w24, w9, w26           | W24 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535));
            System.Byte[] val_8 = ((index + (long)(int)((len + 0))) + 32) + val_57;
            // 0x0198A7A8: ADD w22, w24, w22          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)]; //PARR1 
            // 0x0198A7AC: CMP w25, w8                | STATE = COMPARE(((long)(int)((len + 0)) + 1), index + 24)
            // 0x0198A7B0: B.LO #0x198a7c4            | if (val_7 < val_63) goto label_12;      
            if(val_7 < val_63)
            {
                goto label_12;
            }
            // 0x0198A7B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A7B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A7BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A7C0: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_12:
            // 0x0198A7C4: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 1)));
            int val_9 = index + (long)val_5;
            // 0x0198A7C8: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 1))) + 32;
            // 0x0198A7CC: ADD w26, w20, w27          | W26 = (len + 0);                        
            int val_10 = val_56 + val_49;
            // 0x0198A7D0: SXTW x19, w19              | X19 = (long)(int)(((len + 0) + 2));     
            // 0x0198A7D4: ADD w25, w25, #1           | W25 = (((long)(int)((len + 0)) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A7D8: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf &
            val_8 = ((index + (long)(int)(((len + 0) + 1))) + 32) + val_8;
            // 0x0198A7DC: ADD w23, w26, #3           | W23 = ((len + 0) + 3);                  
            int val_11 = val_10 + 3;
            // 0x0198A7E0: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))]; //PARR1 
            // 0x0198A7E4: CMP w25, w8                | STATE = COMPARE((((long)(int)((len + 0)) + 1) + 1), index + 24)
            // 0x0198A7E8: B.LO #0x198a7fc            | if (val_7 < val_63) goto label_13;      
            if(val_7 < val_63)
            {
                goto label_13;
            }
            // 0x0198A7EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A7F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A7F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A7F8: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_13:
            // 0x0198A7FC: ADD x9, x21, x19           | X9 = (index + (long)(int)(((len + 0) + 2)));
            int val_12 = index + (long)val_4;
            // 0x0198A800: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 2))) + 32;
            // 0x0198A804: ADD w19, w26, #4           | W19 = ((len + 0) + 4);                  
            int val_13 = val_10 + 4;
            // 0x0198A808: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 3));     
            // 0x0198A80C: ADD w25, w25, #1           | W25 = ((((long)(int)((len + 0)) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A810: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 2))) + 32) + val_8;
            // 0x0198A814: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))]; //PARR1 
            // 0x0198A818: CMP w25, w8                | STATE = COMPARE(((((long)(int)((len + 0)) + 1) + 1) + 1), index + 24)
            // 0x0198A81C: B.LO #0x198a830            | if (val_7 < val_63) goto label_14;      
            if(val_7 < val_63)
            {
                goto label_14;
            }
            // 0x0198A820: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A824: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A828: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A82C: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_14:
            // 0x0198A830: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 3)));
            int val_14 = index + (long)val_11;
            // 0x0198A834: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 3))) + 32;
            // 0x0198A838: ADD w26, w20, w27          | W26 = (len + 0);                        
            int val_15 = val_56 + val_49;
            // 0x0198A83C: SXTW x19, w19              | X19 = (long)(int)(((len + 0) + 4));     
            // 0x0198A840: ADD w25, w25, #1           | W25 = (((((long)(int)((len + 0)) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A844: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 3))) + 32) + val_8;
            // 0x0198A848: ADD w23, w26, #5           | W23 = ((len + 0) + 5);                  
            int val_16 = val_15 + 5;
            // 0x0198A84C: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A850: CMP w25, w8                | STATE = COMPARE((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A854: B.LO #0x198a868            | if (val_7 < val_63) goto label_15;      
            if(val_7 < val_63)
            {
                goto label_15;
            }
            // 0x0198A858: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A85C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A860: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A864: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_15:
            // 0x0198A868: ADD x9, x21, x19           | X9 = (index + (long)(int)(((len + 0) + 4)));
            int val_17 = index + (long)val_13;
            // 0x0198A86C: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 4))) + 32;
            // 0x0198A870: ADD w19, w26, #6           | W19 = ((len + 0) + 6);                  
            int val_18 = val_15 + 6;
            // 0x0198A874: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 5));     
            // 0x0198A878: ADD w25, w25, #1           | W25 = ((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A87C: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 4))) + 32 + ((index + (long)(int)(((len + 0) + 3))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 4))) + 32) + val_8;
            // 0x0198A880: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A884: CMP w25, w8                | STATE = COMPARE(((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A888: B.LO #0x198a89c            | if (val_7 < val_63) goto label_16;      
            if(val_7 < val_63)
            {
                goto label_16;
            }
            // 0x0198A88C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A890: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A894: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A898: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_16:
            // 0x0198A89C: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 5)));
            int val_19 = index + (long)val_16;
            // 0x0198A8A0: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 5))) + 32;
            // 0x0198A8A4: ADD w26, w20, w27          | W26 = (len + 0);                        
            int val_20 = val_56 + val_49;
            // 0x0198A8A8: SXTW x19, w19              | X19 = (long)(int)(((len + 0) + 6));     
            // 0x0198A8AC: ADD w25, w25, #1           | W25 = (((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A8B0: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 5))) + 32 + ((index + (long)(int)(((len + 0) + 4))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 5))) + 32) + val_8;
            // 0x0198A8B4: ADD w23, w26, #7           | W23 = ((len + 0) + 7);                  
            int val_21 = val_20 + 7;
            // 0x0198A8B8: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A8BC: CMP w25, w8                | STATE = COMPARE((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A8C0: B.LO #0x198a8d4            | if (val_7 < val_63) goto label_17;      
            if(val_7 < val_63)
            {
                goto label_17;
            }
            // 0x0198A8C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A8C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A8CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A8D0: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_17:
            // 0x0198A8D4: ADD x9, x21, x19           | X9 = (index + (long)(int)(((len + 0) + 6)));
            int val_22 = index + (long)val_18;
            // 0x0198A8D8: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 6))) + 32;
            // 0x0198A8DC: ADD w19, w26, #8           | W19 = ((len + 0) + 8);                  
            int val_23 = val_20 + 8;
            // 0x0198A8E0: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 7));     
            // 0x0198A8E4: ADD w25, w25, #1           | W25 = ((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A8E8: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 6))) + 32 + ((index + (long)(int)(((len + 0) + 5))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 6))) + 32) + val_8;
            // 0x0198A8EC: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A8F0: CMP w25, w8                | STATE = COMPARE(((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A8F4: B.LO #0x198a908            | if (val_7 < val_63) goto label_18;      
            if(val_7 < val_63)
            {
                goto label_18;
            }
            // 0x0198A8F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A8FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A900: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A904: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_18:
            // 0x0198A908: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 7)));
            int val_24 = index + (long)val_21;
            // 0x0198A90C: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 7))) + 32;
            // 0x0198A910: ADD w26, w20, w27          | W26 = (len + 0);                        
            int val_25 = val_56 + val_49;
            // 0x0198A914: SXTW x19, w19              | X19 = (long)(int)(((len + 0) + 8));     
            // 0x0198A918: ADD w25, w25, #1           | W25 = (((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A91C: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 7))) + 32 + ((index + (long)(int)(((len + 0) + 6))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 7))) + 32) + val_8;
            // 0x0198A920: ADD w23, w26, #9           | W23 = ((len + 0) + 9);                  
            int val_26 = val_25 + 9;
            // 0x0198A924: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A928: CMP w25, w8                | STATE = COMPARE((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A92C: B.LO #0x198a940            | if (val_7 < val_63) goto label_19;      
            if(val_7 < val_63)
            {
                goto label_19;
            }
            // 0x0198A930: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A938: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A93C: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_19:
            // 0x0198A940: ADD x9, x21, x19           | X9 = (index + (long)(int)(((len + 0) + 8)));
            int val_27 = index + (long)val_23;
            // 0x0198A944: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 8))) + 32;
            // 0x0198A948: ADD w19, w26, #0xa         | W19 = ((len + 0) + 10);                 
            int val_28 = val_25 + 10;
            // 0x0198A94C: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 9));     
            // 0x0198A950: ADD w25, w25, #1           | W25 = ((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A954: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 8))) + 32 + ((index + (long)(int)(((len + 0) + 7))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 8))) + 32) + val_8;
            // 0x0198A958: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A95C: CMP w25, w8                | STATE = COMPARE(((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A960: B.LO #0x198a974            | if (val_7 < val_63) goto label_20;      
            if(val_7 < val_63)
            {
                goto label_20;
            }
            // 0x0198A964: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A96C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A970: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_20:
            // 0x0198A974: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 9)));
            int val_29 = index + (long)val_26;
            // 0x0198A978: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 9))) + 32;
            // 0x0198A97C: ADD w26, w20, w27          | W26 = (len + 0);                        
            int val_30 = val_56 + val_49;
            // 0x0198A980: SXTW x19, w19              | X19 = (long)(int)(((len + 0) + 10));    
            // 0x0198A984: ADD w25, w25, #1           | W25 = (((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A988: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 9))) + 32 + ((index + (long)(int)(((len + 0) + 8))) + 32 + 
            val_8 = ((index + (long)(int)(((len + 0) + 9))) + 32) + val_8;
            // 0x0198A98C: ADD w23, w26, #0xb         | W23 = ((len + 0) + 11);                 
            int val_31 = val_30 + 11;
            // 0x0198A990: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A994: CMP w25, w8                | STATE = COMPARE((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A998: B.LO #0x198a9ac            | if (val_7 < val_63) goto label_21;      
            if(val_7 < val_63)
            {
                goto label_21;
            }
            // 0x0198A99C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A9A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A9A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A9A8: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_21:
            // 0x0198A9AC: ADD x9, x21, x19           | X9 = (index + (long)(int)(((len + 0) + 10)));
            int val_32 = index + (long)val_28;
            // 0x0198A9B0: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 10))) + 32;
            // 0x0198A9B4: ADD w19, w26, #0xc         | W19 = ((len + 0) + 12);                 
            int val_33 = val_30 + 12;
            // 0x0198A9B8: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 11));    
            // 0x0198A9BC: ADD w25, w25, #1           | W25 = ((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1);
            val_7 = val_7 + 1;
            // 0x0198A9C0: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 10))) + 32 + ((index + (long)(int)(((len + 0) + 9))) + 32 +
            val_8 = ((index + (long)(int)(((len + 0) + 10))) + 32) + val_8;
            // 0x0198A9C4: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198A9C8: CMP w25, w8                | STATE = COMPARE(((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198A9CC: B.LO #0x198a9e0            | if (val_7 < val_63) goto label_22;      
            if(val_7 < val_63)
            {
                goto label_22;
            }
            // 0x0198A9D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A9D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198A9D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198A9DC: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_22:
            // 0x0198A9E0: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 11)));
            int val_34 = index + (long)val_31;
            // 0x0198A9E4: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 11))) + 32;
            // 0x0198A9E8: ADD w26, w20, w27          | W26 = (len + 0);                        
            int val_35 = val_56 + val_49;
            // 0x0198A9EC: SXTW x19, w19              | X19 = (long)(int)(((len + 0) + 12));    
            // 0x0198A9F0: ADD w25, w25, #1           | W25 = (((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1)
            val_7 = val_7 + 1;
            // 0x0198A9F4: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 11))) + 32 + ((index + (long)(int)(((len + 0) + 10))) + 32 
            val_8 = ((index + (long)(int)(((len + 0) + 11))) + 32) + val_8;
            // 0x0198A9F8: ADD w23, w26, #0xd         | W23 = ((len + 0) + 13);                 
            int val_36 = val_35 + 13;
            // 0x0198A9FC: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198AA00: CMP w25, w8                | STATE = COMPARE((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198AA04: B.LO #0x198aa18            | if (val_7 < val_63) goto label_23;      
            if(val_7 < val_63)
            {
                goto label_23;
            }
            // 0x0198AA08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AA0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198AA10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AA14: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_23:
            // 0x0198AA18: ADD x9, x21, x19           | X9 = (index + (long)(int)(((len + 0) + 12)));
            int val_37 = index + (long)val_33;
            // 0x0198AA1C: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 12))) + 32;
            // 0x0198AA20: ADD w19, w26, #0xe         | W19 = ((len + 0) + 14);                 
            int val_38 = val_35 + 14;
            // 0x0198AA24: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 13));    
            // 0x0198AA28: ADD w25, w25, #1           | W25 = ((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1
            val_7 = val_7 + 1;
            // 0x0198AA2C: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 12))) + 32 + ((index + (long)(int)(((len + 0) + 11))) + 32 
            val_8 = ((index + (long)(int)(((len + 0) + 12))) + 32) + val_8;
            // 0x0198AA30: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198AA34: CMP w25, w8                | STATE = COMPARE(((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198AA38: B.LO #0x198aa4c            | if (val_7 < val_63) goto label_24;      
            if(val_7 < val_63)
            {
                goto label_24;
            }
            // 0x0198AA3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198AA44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AA48: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_24:
            // 0x0198AA4C: ADD x9, x21, x23           | X9 = (index + (long)(int)(((len + 0) + 13)));
            int val_39 = index + (long)val_36;
            // 0x0198AA50: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 13))) + 32;
            // 0x0198AA54: ADD w10, w20, w27          | W10 = (len + 0);                        
            int val_40 = val_56 + val_49;
            // 0x0198AA58: SXTW x26, w19              | X26 = (long)(int)(((len + 0) + 14));    
            // 0x0198AA5C: ADD w19, w25, #1           | W19 = (((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 
            var val_41 = val_7 + 1;
            // 0x0198AA60: ADD w24, w9, w24           | W24 = ((index + (long)(int)(((len + 0) + 13))) + 32 + ((index + (long)(int)(((len + 0) + 12))) + 32 
            val_8 = ((index + (long)(int)(((len + 0) + 13))) + 32) + val_8;
            // 0x0198AA64: ADD w23, w10, #0xf         | W23 = ((len + 0) + 15);                 
            int val_42 = val_40 + 15;
            // 0x0198AA68: ADD w22, w22, w24          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198AA6C: CMP w19, w8                | STATE = COMPARE((((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198AA70: B.LO #0x198aa84            | if (val_41 < val_63) goto label_25;     
            if(val_41 < val_63)
            {
                goto label_25;
            }
            // 0x0198AA74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AA78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198AA7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AA80: LDR x8, [x21, #0x18]       | X8 = index + 24;                        
            val_63 = mem[index + 24];
            val_63 = index + 24;
            label_25:
            // 0x0198AA84: ADD x9, x21, x26           | X9 = (index + (long)(int)(((len + 0) + 14)));
            int val_43 = index + (long)val_38;
            // 0x0198AA88: LDRB w9, [x9, #0x20]       | W9 = (index + (long)(int)(((len + 0) + 14))) + 32;
            // 0x0198AA8C: ADD w10, w19, #1           | W10 = ((((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) +
            var val_44 = val_41 + 1;
            // 0x0198AA90: SXTW x23, w23              | X23 = (long)(int)(((len + 0) + 15));    
            val_64 = (long)val_42;
            // 0x0198AA94: CMP w10, w8                | STATE = COMPARE(((((((((((((((((long)(int)((len + 0)) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1) + 1), index + 24)
            // 0x0198AA98: ADD w19, w9, w24           | W19 = ((index + (long)(int)(((len + 0) + 14))) + 32 + ((index + (long)(int)(((len + 0) + 13))) + 32 
            val_54 = ((index + (long)(int)(((len + 0) + 14))) + 32) + val_8;
            // 0x0198AA9C: ADD w22, w22, w19          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198AAA0: B.LO #0x198aab0            | if (val_44 < val_63) goto label_26;     
            if(val_44 < val_63)
            {
                goto label_26;
            }
            // 0x0198AAA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AAA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198AAAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            label_26:
            // 0x0198AAB0: ADD x8, x21, x23           | X8 = (index + (long)(int)(((len + 0) + 15)));
            int val_45 = index + val_64;
            // 0x0198AAB4: LDRB w8, [x8, #0x20]       | W8 = (index + (long)(int)(((len + 0) + 15))) + 32;
            // 0x0198AAB8: SUB w28, w28, #0x10        | W28 = (Pathfinding.Ionic.Zlib.Adler.NMAX - 16);
            val_48 = val_48 - 16;
            // 0x0198AABC: ADD w27, w27, #0x10        | W27 = (0 + 16);                         
            val_49 = val_49 + 16;
            // 0x0198AAC0: CMP w28, #0xf              | STATE = COMPARE((Pathfinding.Ionic.Zlib.Adler.NMAX - 16), 0xF)
            // 0x0198AAC4: ADD w26, w8, w19           | W26 = ((index + (long)(int)(((len + 0) + 15))) + 32 + ((index + (long)(int)(((len + 0) + 14))) + 32 
            val_65 = ((index + (long)(int)(((len + 0) + 15))) + 32) + val_54;
            // 0x0198AAC8: ADD w22, w22, w26          | W22 = ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535))))][((index + (long)(int)(((len + 0) + 3))) + 32 + ((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len
            // 0x0198AACC: B.GT #0x198a768            | if (val_61 > 15) goto label_27;         
            if(val_48 > 15)
            {
                goto label_27;
            }
            // 0x0198AAD0: LDP w9, w8, [sp, #0x10]    | W9 = ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280); W8 = (Pathfinding.Ionic.Zlib.Adler.NMAX - 16); //  | 
            // 0x0198AAD4: ADRP x28, #0x3660000       | X28 = 57016320 (0x3660000);             
            // 0x0198AAD8: LDR w27, [sp, #0x18]       | W27 = W4;                               
            val_67 = val_55;
            // 0x0198AADC: SUB w24, w8, w9            | W24 = ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) - ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 429496
            val_62 = val_1 - val_2;
            // 0x0198AAE0: LDR w8, [sp, #0xc]         | W8 = (len + 16);                        
            // 0x0198AAE4: LDR x28, [x28, #0x9e0]     | X28 = 1152921504753704960;              
            val_59 = 1152921504753704960;
            // 0x0198AAE8: ADD w20, w8, w9            | W20 = ((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280));
            val_56 = val_3 + val_2;
            label_10:
            // 0x0198AAEC: MOV w25, w24               | W25 = ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) - ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280));//m1
            val_68 = val_62;
            // 0x0198AAF0: MOV w8, w20                | W8 = ((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280));//m1
            var val_50 = val_56;
            // 0x0198AAF4: CBZ w24, #0x198ab38        | if (((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) - ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)) == 0) goto label_28;
            if(val_62 == 0)
            {
                goto label_28;
            }
            label_30:
            // 0x0198AAF8: LDR w9, [x21, #0x18]       | W9 = index + 24;                        
            // 0x0198AAFC: ADD w19, w8, #1            | W19 = (((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)) + 1);
            val_54 = val_50 + 1;
            // 0x0198AB00: SXTW x23, w8               | X23 = (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)));
            val_64 = (long)val_50;
            // 0x0198AB04: CMP w8, w9                 | STATE = COMPARE(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)), index + 24)
            // 0x0198AB08: B.LO #0x198ab18            | if (val_56 < index + 24) goto label_29; 
            if(val_50 < (index + 24))
            {
                goto label_29;
            }
            // 0x0198AB0C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AB10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0198AB14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            label_29:
            // 0x0198AB18: ADD x8, x21, x23           | X8 = (index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280))));
            val_50 = index + val_64;
            // 0x0198AB1C: LDRB w8, [x8, #0x20]       | W8 = (index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)))) + 32;
            // 0x0198AB20: SUB w25, w25, #1           | W25 = (((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) - ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 42949
            val_68 = val_68 - 1;
            // 0x0198AB24: ADD w26, w8, w26           | W26 = ((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280))))
            val_65 = ((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)))) + 32) + val_65;
            // 0x0198AB28: ADD w22, w26, w22          | W22 = ((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)))) + 32 + ((index + (long)(int)(((len + 0) + 15))) + 32 + ((index + (long)(int)(((len + 0) + 14))) + 32 + (([((index + (long)(int)((len + 0))) + 32 + (buf & 65535))[(buf >> 16)][((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((len + 0))) + 32 + (buf & 65535)))][((index + (long)(int)(((len + 0) + 2))) + 32 + ((index + (long)(int)(((len + 0) + 1))) + 32 + ((index + (long)(int)((le
            // 0x0198AB2C: MOV w8, w19                | W8 = (((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)) + 1);//m1
            // 0x0198AB30: CBNZ w25, #0x198aaf8       | if ((((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) - ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)) - 1) != 0) goto label_30;
            if(val_68 != 0)
            {
                goto label_30;
            }
            // 0x0198AB34: ADD w20, w24, w20          | W20 = (((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) - ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 42949
            val_56 = val_62 + val_56;
            label_28:
            // 0x0198AB38: LDR x0, [x28]              | X0 = typeof(Pathfinding.Ionic.Zlib.Adler);
            // 0x0198AB3C: LDR w9, [sp, #0x1c]        | W9 = Pathfinding.Ionic.Zlib.Adler.NMAX; 
            // 0x0198AB40: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_10A;
            // 0x0198AB44: SUB w27, w27, w9           | W27 = (W4 - Pathfinding.Ionic.Zlib.Adler.NMAX);
            val_70 = val_67 - val_61;
            // 0x0198AB48: TBZ w8, #0, #0x198ab5c     | if (Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x0198AB4C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_cctor_finished;
            // 0x0198AB50: CBNZ w8, #0x198ab5c        | if (Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x0198AB54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Zlib.Adler), ????);
            // 0x0198AB58: LDR x0, [x28]              | X0 = typeof(Pathfinding.Ionic.Zlib.Adler);
            val_69 = null;
            label_32:
            // 0x0198AB5C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Ionic.Zlib.Adler.__il2cppRuntimeField_static_fields;
            // 0x0198AB60: CMP w27, #0                | STATE = COMPARE((W4 - Pathfinding.Ionic.Zlib.Adler.NMAX), 0x0)
            // 0x0198AB64: LDR w8, [x8]               | W8 = Pathfinding.Ionic.Zlib.Adler.BASE; 
            // 0x0198AB68: UDIV w9, w26, w8           | W9 = (((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280))))
            System.Byte[] val_46 = val_65 / Pathfinding.Ionic.Zlib.Adler.BASE;
            // 0x0198AB6C: UDIV w10, w22, w8          | W10 = (((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280)))
            System.Byte[] val_47 = val_65[val_8[val_58][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_54][val_65]] / Pathfinding.Ionic.Zlib.Adler.BASE;
            // 0x0198AB70: MSUB w26, w9, w8, w26      | W26 = ((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280))))
            val_71 = val_65 - (val_46 * Pathfinding.Ionic.Zlib.Adler.BASE);
            // 0x0198AB74: MSUB w22, w10, w8, w22     | W22 = ((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280))))
            val_72 = val_65[val_8[val_58][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_8][val_54][val_65]] - (val_47 * Pathfinding.Ionic.Zlib.Adler.BASE);
            // 0x0198AB78: B.GT #0x198a6e0            | if (val_70 > 0) goto label_33;          
            if(val_70 > 0)
            {
                goto label_33;
            }
            label_2:
            // 0x0198AB7C: ORR w0, w26, w22, lsl #16  | W0 = (((index + (long)(int)(((len + 16) + ((Pathfinding.Ionic.Zlib.Adler.NMAX - 16) & 4294967280))))
            val_73 = val_71 | (val_72 << 16);
            // 0x0198AB80: B #0x198ab88               |  goto label_34;                         
            goto label_34;
            label_1:
            // 0x0198AB84: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_73 = 1;
            label_34:
            // 0x0198AB88: SUB sp, x29, #0x50         | SP = (1152921509730551680 - 80) = 1152921509730551600 (0x1000000131658730);
            // 0x0198AB8C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0198AB90: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0198AB94: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0198AB98: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0198AB9C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0198ABA0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0198ABA4: RET                        |  return (System.UInt32)0x1;             
            return (uint)val_73;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
    
    }

}
