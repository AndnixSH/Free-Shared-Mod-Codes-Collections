using UnityEngine;

namespace Pathfinding
{
    public class ABPath : Path
    {
        // Fields
        public bool recalcStartEndCosts; //  0x00000109
        public Pathfinding.GraphNode startNode; //  0x00000110
        public Pathfinding.GraphNode endNode; //  0x00000118
        public Pathfinding.GraphNode startHint; //  0x00000120
        public Pathfinding.GraphNode endHint; //  0x00000128
        public UnityEngine.Vector3 originalStartPoint; //  0x00000130
        public UnityEngine.Vector3 originalEndPoint; //  0x0000013C
        public UnityEngine.Vector3 startPoint; //  0x00000148
        public UnityEngine.Vector3 endPoint; //  0x00000154
        protected bool hasEndPoint; //  0x00000160
        public Pathfinding.Int3 startIntPoint; //  0x00000164
        public bool calculatePartial; //  0x00000170
        protected Pathfinding.PathNode partialBestTarget; //  0x00000178
        protected int[] endNodeCosts; //  0x00000180
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00D1C0FC (13746428), len: 228  VirtAddr: 0x00D1C0FC RVA: 0x00D1C0FC token: 100683581 methodIndex: 49685 delegateWrapperIndex: 0 methodInvoker: 0
        [System.ObsoleteAttribute] // 0x285C6C8
        public ABPath(UnityEngine.Vector3 start, UnityEngine.Vector3 end, OnPathDelegate callbackDelegate)
        {
            //
            // Disasemble & Code
            // 0x00D1C0FC: STP d13, d12, [sp, #-0x60]! | stack[1152921513504988672] = ???;  stack[1152921513504988680] = ???;  //  dest_result_addr=1152921513504988672 |  dest_result_addr=1152921513504988680
            // 0x00D1C100: STP d11, d10, [sp, #0x10]  | stack[1152921513504988688] = ???;  stack[1152921513504988696] = ???;  //  dest_result_addr=1152921513504988688 |  dest_result_addr=1152921513504988696
            // 0x00D1C104: STP d9, d8, [sp, #0x20]    | stack[1152921513504988704] = ???;  stack[1152921513504988712] = ???;  //  dest_result_addr=1152921513504988704 |  dest_result_addr=1152921513504988712
            // 0x00D1C108: STP x22, x21, [sp, #0x30]  | stack[1152921513504988720] = ???;  stack[1152921513504988728] = ???;  //  dest_result_addr=1152921513504988720 |  dest_result_addr=1152921513504988728
            // 0x00D1C10C: STP x20, x19, [sp, #0x40]  | stack[1152921513504988736] = ???;  stack[1152921513504988744] = ???;  //  dest_result_addr=1152921513504988736 |  dest_result_addr=1152921513504988744
            // 0x00D1C110: STP x29, x30, [sp, #0x50]  | stack[1152921513504988752] = ???;  stack[1152921513504988760] = ???;  //  dest_result_addr=1152921513504988752 |  dest_result_addr=1152921513504988760
            // 0x00D1C114: ADD x29, sp, #0x50         | X29 = (1152921513504988672 + 80) = 1152921513504988752 (0x10000002125EDE50);
            // 0x00D1C118: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00D1C11C: LDRB w8, [x21, #0x2d0]     | W8 = (bool)static_value_037342D0;       
            // 0x00D1C120: MOV x19, x1                | X19 = callbackDelegate;//m1             
            // 0x00D1C124: MOV v8.16b, v5.16b         | V8 = end.z;//m1                         
            // 0x00D1C128: MOV v9.16b, v4.16b         | V9 = end.y;//m1                         
            // 0x00D1C12C: MOV v10.16b, v3.16b        | V10 = end.x;//m1                        
            // 0x00D1C130: MOV v11.16b, v2.16b        | V11 = start.z;//m1                      
            // 0x00D1C134: MOV v12.16b, v1.16b        | V12 = start.y;//m1                      
            // 0x00D1C138: MOV v13.16b, v0.16b        | V13 = start.x;//m1                      
            // 0x00D1C13C: MOV x20, x0                | X20 = 1152921513505000768 (0x10000002125F0D40);//ML01
            // 0x00D1C140: TBNZ w8, #0, #0xd1c15c     | if (static_value_037342D0 == true) goto label_0;
            // 0x00D1C144: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00D1C148: LDR x8, [x8, #0xc00]       | X8 = 0x2B8A760;                         
            // 0x00D1C14C: LDR w0, [x8]               | W0 = 0x96;                              
            // 0x00D1C150: BL #0x2782188              | X0 = sub_2782188( ?? 0x96, ????);       
            // 0x00D1C154: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C158: STRB w8, [x21, #0x2d0]     | static_value_037342D0 = true;            //  dest_result_addr=57885392
            label_0:
            // 0x00D1C15C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C160: STRB w8, [x20, #0x109]     | this.recalcStartEndCosts = true;         //  dest_result_addr=1152921513505001033
            this.recalcStartEndCosts = true;
            // 0x00D1C164: STRB w8, [x20, #0x160]     | this.hasEndPoint = true;                 //  dest_result_addr=1152921513505001120
            this.hasEndPoint = true;
            // 0x00D1C168: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00D1C16C: LDR x8, [x8, #0x110]       | X8 = 1152921504840552448;               
            // 0x00D1C170: LDR x0, [x8]               | X0 = typeof(Pathfinding.Path);          
            // 0x00D1C174: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Path.__il2cppRuntimeField_10A;
            // 0x00D1C178: TBZ w8, #0, #0xd1c188      | if (Pathfinding.Path.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00D1C17C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C180: CBNZ w8, #0xd1c188         | if (Pathfinding.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00D1C184: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Path), ????);
            label_2:
            // 0x00D1C188: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C18C: MOV x0, x20                | X0 = 1152921513505000768 (0x10000002125F0D40);//ML01
            // 0x00D1C190: BL #0x1402a98              | this..ctor();                           
            // 0x00D1C194: LDR x8, [x20]              | X8 = typeof(Pathfinding.ABPath);        
            // 0x00D1C198: MOV x0, x20                | X0 = 1152921513505000768 (0x10000002125F0D40);//ML01
            // 0x00D1C19C: LDP x9, x1, [x8, #0x180]   | X9 = typeof(Pathfinding.ABPath).__il2cppRuntimeField_180; X1 = typeof(Pathfinding.ABPath).__il2cppRuntimeField_188; //  | 
            // 0x00D1C1A0: BLR x9                     | X0 = typeof(Pathfinding.ABPath).__il2cppRuntimeField_180();
            // 0x00D1C1A4: STR x19, [x20, #0x20]      | mem[1152921513505000800] = callbackDelegate;  //  dest_result_addr=1152921513505000800
            mem[1152921513505000800] = callbackDelegate;
            // 0x00D1C1A8: MOV x0, x20                | X0 = 1152921513505000768 (0x10000002125F0D40);//ML01
            // 0x00D1C1AC: MOV v2.16b, v11.16b        | V2 = start.z;//m1                       
            // 0x00D1C1B0: MOV v3.16b, v10.16b        | V3 = end.x;//m1                         
            // 0x00D1C1B4: MOV v4.16b, v9.16b         | V4 = end.y;//m1                         
            // 0x00D1C1B8: MOV v5.16b, v8.16b         | V5 = end.z;//m1                         
            // 0x00D1C1BC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1C1C0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1C1C4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1C1C8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00D1C1CC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00D1C1D0: MOV v0.16b, v13.16b        | V0 = start.x;//m1                       
            // 0x00D1C1D4: MOV v1.16b, v12.16b        | V1 = start.y;//m1                       
            // 0x00D1C1D8: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
            // 0x00D1C1DC: B #0xd1c334                | this.UpdateStartEnd(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, end:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z}); return;
            this.UpdateStartEnd(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, end:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z});
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1C1E8 (13746664), len: 116  VirtAddr: 0x00D1C1E8 RVA: 0x00D1C1E8 token: 100683582 methodIndex: 49686 delegateWrapperIndex: 0 methodInvoker: 0
        public ABPath()
        {
            //
            // Disasemble & Code
            // 0x00D1C1E8: STP x20, x19, [sp, #-0x20]! | stack[1152921513505104832] = ???;  stack[1152921513505104840] = ???;  //  dest_result_addr=1152921513505104832 |  dest_result_addr=1152921513505104840
            // 0x00D1C1EC: STP x29, x30, [sp, #0x10]  | stack[1152921513505104848] = ???;  stack[1152921513505104856] = ???;  //  dest_result_addr=1152921513505104848 |  dest_result_addr=1152921513505104856
            // 0x00D1C1F0: ADD x29, sp, #0x10         | X29 = (1152921513505104832 + 16) = 1152921513505104848 (0x100000021260A3D0);
            // 0x00D1C1F4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1C1F8: LDRB w8, [x20, #0x2d1]     | W8 = (bool)static_value_037342D1;       
            // 0x00D1C1FC: MOV x19, x0                | X19 = 1152921513505116864 (0x100000021260D2C0);//ML01
            // 0x00D1C200: TBNZ w8, #0, #0xd1c21c     | if (static_value_037342D1 == true) goto label_0;
            // 0x00D1C204: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00D1C208: LDR x8, [x8, #0x3f0]       | X8 = 0x2B8A764;                         
            // 0x00D1C20C: LDR w0, [x8]               | W0 = 0x97;                              
            // 0x00D1C210: BL #0x2782188              | X0 = sub_2782188( ?? 0x97, ????);       
            // 0x00D1C214: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C218: STRB w8, [x20, #0x2d1]     | static_value_037342D1 = true;            //  dest_result_addr=57885393
            label_0:
            // 0x00D1C21C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C220: STRB w8, [x19, #0x109]     | this.recalcStartEndCosts = true;         //  dest_result_addr=1152921513505117129
            this.recalcStartEndCosts = true;
            // 0x00D1C224: STRB w8, [x19, #0x160]     | this.hasEndPoint = true;                 //  dest_result_addr=1152921513505117216
            this.hasEndPoint = true;
            // 0x00D1C228: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00D1C22C: LDR x8, [x8, #0x110]       | X8 = 1152921504840552448;               
            // 0x00D1C230: LDR x0, [x8]               | X0 = typeof(Pathfinding.Path);          
            // 0x00D1C234: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Path.__il2cppRuntimeField_10A;
            // 0x00D1C238: TBZ w8, #0, #0xd1c248      | if (Pathfinding.Path.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00D1C23C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C240: CBNZ w8, #0xd1c248         | if (Pathfinding.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00D1C244: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Path), ????);
            label_2:
            // 0x00D1C248: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1C24C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C250: MOV x0, x19                | X0 = 1152921513505116864 (0x100000021260D2C0);//ML01
            // 0x00D1C254: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00D1C258: B #0x1402a98               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1C25C (13746780), len: 216  VirtAddr: 0x00D1C25C RVA: 0x00D1C25C token: 100683583 methodIndex: 49687 delegateWrapperIndex: 0 methodInvoker: 0
        public static Pathfinding.ABPath Construct(UnityEngine.Vector3 start, UnityEngine.Vector3 end, OnPathDelegate callback)
        {
            //
            // Disasemble & Code
            // 0x00D1C25C: STP d13, d12, [sp, #-0x50]! | stack[1152921513505226000] = ???;  stack[1152921513505226008] = ???;  //  dest_result_addr=1152921513505226000 |  dest_result_addr=1152921513505226008
            // 0x00D1C260: STP d11, d10, [sp, #0x10]  | stack[1152921513505226016] = ???;  stack[1152921513505226024] = ???;  //  dest_result_addr=1152921513505226016 |  dest_result_addr=1152921513505226024
            // 0x00D1C264: STP d9, d8, [sp, #0x20]    | stack[1152921513505226032] = ???;  stack[1152921513505226040] = ???;  //  dest_result_addr=1152921513505226032 |  dest_result_addr=1152921513505226040
            // 0x00D1C268: STP x20, x19, [sp, #0x30]  | stack[1152921513505226048] = ???;  stack[1152921513505226056] = ???;  //  dest_result_addr=1152921513505226048 |  dest_result_addr=1152921513505226056
            // 0x00D1C26C: STP x29, x30, [sp, #0x40]  | stack[1152921513505226064] = ???;  stack[1152921513505226072] = ???;  //  dest_result_addr=1152921513505226064 |  dest_result_addr=1152921513505226072
            // 0x00D1C270: ADD x29, sp, #0x40         | X29 = (1152921513505226000 + 64) = 1152921513505226064 (0x1000000212627D50);
            // 0x00D1C274: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1C278: LDRB w8, [x20, #0x2d2]     | W8 = (bool)static_value_037342D2;       
            // 0x00D1C27C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00D1C280: MOV v8.16b, v5.16b         | V8 = end.z;//m1                         
            // 0x00D1C284: MOV v9.16b, v4.16b         | V9 = end.y;//m1                         
            // 0x00D1C288: MOV v10.16b, v3.16b        | V10 = end.x;//m1                        
            // 0x00D1C28C: MOV v11.16b, v2.16b        | V11 = start.z;//m1                      
            // 0x00D1C290: MOV v12.16b, v1.16b        | V12 = start.y;//m1                      
            // 0x00D1C294: MOV v13.16b, v0.16b        | V13 = start.x;//m1                      
            // 0x00D1C298: TBNZ w8, #0, #0xd1c2b4     | if (static_value_037342D2 == true) goto label_0;
            // 0x00D1C29C: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00D1C2A0: LDR x8, [x8, #0x2c0]       | X8 = 0x2B8A76C;                         
            // 0x00D1C2A4: LDR w0, [x8]               | W0 = 0x99;                              
            // 0x00D1C2A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x99, ????);       
            // 0x00D1C2AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C2B0: STRB w8, [x20, #0x2d2]     | static_value_037342D2 = true;            //  dest_result_addr=57885394
            label_0:
            // 0x00D1C2B4: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00D1C2B8: LDR x8, [x8, #0xc80]       | X8 = 1152921504839860224;               
            // 0x00D1C2BC: LDR x0, [x8]               | X0 = typeof(Pathfinding.PathPool<T>);   
            // 0x00D1C2C0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_10A;
            // 0x00D1C2C4: TBZ w8, #0, #0xd1c2d4      | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00D1C2C8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C2CC: CBNZ w8, #0xd1c2d4         | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00D1C2D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.PathPool<T>), ????);
            label_2:
            // 0x00D1C2D4: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x00D1C2D8: LDR x8, [x8, #0xc18]       | X8 = 1152921513505208960;               
            // 0x00D1C2DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C2E0: LDR x1, [x8]               | X1 = public static Pathfinding.ABPath Pathfinding.PathPool<Pathfinding.ABPath>::GetPath();
            // 0x00D1C2E4: BL #0x19f1938              | X0 = Pathfinding.PathPool<Pathfinding.RandomPath>.GetPath();
            Pathfinding.RandomPath val_1 = Pathfinding.PathPool<Pathfinding.RandomPath>.GetPath();
            // 0x00D1C2E8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00D1C2EC: CBNZ x20, #0xd1c2f4        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00D1C2F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00D1C2F4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00D1C2F8: MOV v0.16b, v13.16b        | V0 = start.x;//m1                       
            // 0x00D1C2FC: MOV v1.16b, v12.16b        | V1 = start.y;//m1                       
            // 0x00D1C300: MOV v2.16b, v11.16b        | V2 = start.z;//m1                       
            // 0x00D1C304: MOV v3.16b, v10.16b        | V3 = end.x;//m1                         
            // 0x00D1C308: MOV v4.16b, v9.16b         | V4 = end.y;//m1                         
            // 0x00D1C30C: MOV v5.16b, v8.16b         | V5 = end.z;//m1                         
            // 0x00D1C310: STR x19, [x20, #0x20]      | mem2[0] = X1;                            //  dest_result_addr=0
            mem2[0] = X1;
            // 0x00D1C314: BL #0xd1c334               | val_1.UpdateStartEnd(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, end:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z});
            val_1.UpdateStartEnd(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, end:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z});
            // 0x00D1C318: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00D1C31C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1C320: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1C324: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00D1C328: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00D1C32C: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x00D1C330: RET                        |  return (Pathfinding.ABPath)val_1;      
            return (Pathfinding.ABPath)val_1;
            //  |  // // {name=val_0, type=Pathfinding.ABPath, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1C1E0 (13746656), len: 8  VirtAddr: 0x00D1C1E0 RVA: 0x00D1C1E0 token: 100683584 methodIndex: 49688 delegateWrapperIndex: 0 methodInvoker: 0
        protected void Setup(UnityEngine.Vector3 start, UnityEngine.Vector3 end, OnPathDelegate callbackDelegate)
        {
            //
            // Disasemble & Code
            // 0x00D1C1E0: STR x1, [x0, #0x20]        | mem[1152921513505362400] = callbackDelegate;  //  dest_result_addr=1152921513505362400
            mem[1152921513505362400] = callbackDelegate;
            // 0x00D1C1E4: B #0xd1c334                | this.UpdateStartEnd(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, end:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z}); return;
            this.UpdateStartEnd(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, end:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z});
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1C334 (13746996), len: 260  VirtAddr: 0x00D1C334 RVA: 0x00D1C334 token: 100683585 methodIndex: 49689 delegateWrapperIndex: 0 methodInvoker: 0
        protected void UpdateStartEnd(UnityEngine.Vector3 start, UnityEngine.Vector3 end)
        {
            //
            // Disasemble & Code
            // 0x00D1C334: STP d13, d12, [sp, #-0x50]! | stack[1152921513505466384] = ???;  stack[1152921513505466392] = ???;  //  dest_result_addr=1152921513505466384 |  dest_result_addr=1152921513505466392
            // 0x00D1C338: STP d11, d10, [sp, #0x10]  | stack[1152921513505466400] = ???;  stack[1152921513505466408] = ???;  //  dest_result_addr=1152921513505466400 |  dest_result_addr=1152921513505466408
            // 0x00D1C33C: STP d9, d8, [sp, #0x20]    | stack[1152921513505466416] = ???;  stack[1152921513505466424] = ???;  //  dest_result_addr=1152921513505466416 |  dest_result_addr=1152921513505466424
            // 0x00D1C340: STP x20, x19, [sp, #0x30]  | stack[1152921513505466432] = ???;  stack[1152921513505466440] = ???;  //  dest_result_addr=1152921513505466432 |  dest_result_addr=1152921513505466440
            // 0x00D1C344: STP x29, x30, [sp, #0x40]  | stack[1152921513505466448] = ???;  stack[1152921513505466456] = ???;  //  dest_result_addr=1152921513505466448 |  dest_result_addr=1152921513505466456
            // 0x00D1C348: ADD x29, sp, #0x40         | X29 = (1152921513505466384 + 64) = 1152921513505466448 (0x1000000212662850);
            // 0x00D1C34C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1C350: LDRB w8, [x20, #0x2d3]     | W8 = (bool)static_value_037342D3;       
            // 0x00D1C354: MOV v8.16b, v5.16b         | V8 = end.z;//m1                         
            // 0x00D1C358: MOV v9.16b, v4.16b         | V9 = end.y;//m1                         
            // 0x00D1C35C: MOV v10.16b, v3.16b        | V10 = end.x;//m1                        
            // 0x00D1C360: MOV v11.16b, v2.16b        | V11 = start.z;//m1                      
            // 0x00D1C364: MOV v12.16b, v1.16b        | V12 = start.y;//m1                      
            // 0x00D1C368: MOV v13.16b, v0.16b        | V13 = start.x;//m1                      
            // 0x00D1C36C: MOV x19, x0                | X19 = 1152921513505478464 (0x1000000212665740);//ML01
            // 0x00D1C370: TBNZ w8, #0, #0xd1c38c     | if (static_value_037342D3 == true) goto label_0;
            // 0x00D1C374: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00D1C378: LDR x8, [x8, #0x1d0]       | X8 = 0x2B8A78C;                         
            // 0x00D1C37C: LDR w0, [x8]               | W0 = 0xA1;                              
            // 0x00D1C380: BL #0x2782188              | X0 = sub_2782188( ?? 0xA1, ????);       
            // 0x00D1C384: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C388: STRB w8, [x20, #0x2d3]     | static_value_037342D3 = true;            //  dest_result_addr=57885395
            label_0:
            // 0x00D1C38C: STR s8, [x19, #0x15c]      | mem[1152921513505478812] = end.z;        //  dest_result_addr=1152921513505478812
            mem[1152921513505478812] = end.z;
            // 0x00D1C390: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C394: STR s13, [x19, #0x130]     | this.originalStartPoint = start;         //  dest_result_addr=1152921513505478768
            this.originalStartPoint = start;
            // 0x00D1C398: STR s12, [x19, #0x134]     | mem[1152921513505478772] = start.y;      //  dest_result_addr=1152921513505478772
            mem[1152921513505478772] = start.y;
            // 0x00D1C39C: STR s11, [x19, #0x138]     | mem[1152921513505478776] = start.z;      //  dest_result_addr=1152921513505478776
            mem[1152921513505478776] = start.z;
            // 0x00D1C3A0: STR s10, [x19, #0x13c]     | this.originalEndPoint = end;             //  dest_result_addr=1152921513505478780
            this.originalEndPoint = end;
            // 0x00D1C3A4: STR s9, [x19, #0x140]      | mem[1152921513505478784] = end.y;        //  dest_result_addr=1152921513505478784
            mem[1152921513505478784] = end.y;
            // 0x00D1C3A8: STR s8, [x19, #0x144]      | mem[1152921513505478788] = end.z;        //  dest_result_addr=1152921513505478788
            mem[1152921513505478788] = end.z;
            // 0x00D1C3AC: STR s13, [x19, #0x148]     | this.startPoint = start;                 //  dest_result_addr=1152921513505478792
            this.startPoint = start;
            // 0x00D1C3B0: STR s12, [x19, #0x14c]     | mem[1152921513505478796] = start.y;      //  dest_result_addr=1152921513505478796
            mem[1152921513505478796] = start.y;
            // 0x00D1C3B4: STR s11, [x19, #0x150]     | mem[1152921513505478800] = start.z;      //  dest_result_addr=1152921513505478800
            mem[1152921513505478800] = start.z;
            // 0x00D1C3B8: STR s10, [x19, #0x154]     | this.endPoint = end;                     //  dest_result_addr=1152921513505478804
            this.endPoint = end;
            // 0x00D1C3BC: STR s9, [x19, #0x158]      | mem[1152921513505478808] = end.y;        //  dest_result_addr=1152921513505478808
            mem[1152921513505478808] = end.y;
            // 0x00D1C3C0: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C3C4: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C3C8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C3CC: TBZ w8, #0, #0xd1c3dc      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00D1C3D0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C3D4: CBNZ w8, #0xd1c3dc         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00D1C3D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_2:
            // 0x00D1C3DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C3E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C3E4: MOV v0.16b, v13.16b        | V0 = start.x;//m1                       
            // 0x00D1C3E8: MOV v1.16b, v12.16b        | V1 = start.y;//m1                       
            // 0x00D1C3EC: MOV v2.16b, v11.16b        | V2 = start.z;//m1                       
            // 0x00D1C3F0: BL #0x1548f50              | X0 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z});
            Pathfinding.Int3 val_1 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z});
            // 0x00D1C3F4: ADD x8, x19, #0x164        | X8 = this.startIntPoint;//AP2 res_addr=1152921513505478820
            // 0x00D1C3F8: STR x0, [x8]               | mem2[0] = val_1.x; mem[4] = val_1.y;     //  dest_result_addr=0 dest_result_addr=4
            mem2[0] = val_1.x;
            mem[4] = val_1.y;
            // 0x00D1C3FC: STR w1, [x19, #0x16c]      | mem[1152921513505478828] = val_1.z;      //  dest_result_addr=1152921513505478828
            mem[1152921513505478828] = val_1.z;
            // 0x00D1C400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C408: MOV v0.16b, v10.16b        | V0 = end.x;//m1                         
            // 0x00D1C40C: MOV v1.16b, v9.16b         | V1 = end.y;//m1                         
            // 0x00D1C410: MOV v2.16b, v8.16b         | V2 = end.z;//m1                         
            // 0x00D1C414: BL #0x1548f50              | X0 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z});
            Pathfinding.Int3 val_2 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = end.x, y = end.y, z = end.z});
            // 0x00D1C418: STR x0, [x19, #0xe0]       | mem[1152921513505478688] = val_2.x; mem[1152921513505478692] = val_2.y;  //  dest_result_addr=1152921513505478688 dest_result_addr=1152921513505478692
            mem[1152921513505478688] = val_2.x;
            mem[1152921513505478692] = val_2.y;
            // 0x00D1C41C: STR w1, [x19, #0xe8]       | mem[1152921513505478696] = val_2.z;      //  dest_result_addr=1152921513505478696
            mem[1152921513505478696] = val_2.z;
            // 0x00D1C420: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1C424: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1C428: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00D1C42C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00D1C430: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
            // 0x00D1C434: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1C438 (13747256), len: 1448  VirtAddr: 0x00D1C438 RVA: 0x00D1C438 token: 100683586 methodIndex: 49690 delegateWrapperIndex: 0 methodInvoker: 0
        public override uint GetConnectionSpecialCost(Pathfinding.GraphNode a, Pathfinding.GraphNode b, uint currentCost)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Int3 val_17;
            //  | 
            var val_18;
            //  | 
            int val_19;
            //  | 
            Pathfinding.Int3 val_20;
            //  | 
            var val_21;
            //  | 
            float val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            int val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            int val_28;
            //  | 
            var val_29;
            // 0x00D1C438: STP x28, x27, [sp, #-0x60]! | stack[1152921513505594752] = ???;  stack[1152921513505594760] = ???;  //  dest_result_addr=1152921513505594752 |  dest_result_addr=1152921513505594760
            // 0x00D1C43C: STP x26, x25, [sp, #0x10]  | stack[1152921513505594768] = ???;  stack[1152921513505594776] = ???;  //  dest_result_addr=1152921513505594768 |  dest_result_addr=1152921513505594776
            // 0x00D1C440: STP x24, x23, [sp, #0x20]  | stack[1152921513505594784] = ???;  stack[1152921513505594792] = ???;  //  dest_result_addr=1152921513505594784 |  dest_result_addr=1152921513505594792
            // 0x00D1C444: STP x22, x21, [sp, #0x30]  | stack[1152921513505594800] = ???;  stack[1152921513505594808] = ???;  //  dest_result_addr=1152921513505594800 |  dest_result_addr=1152921513505594808
            // 0x00D1C448: STP x20, x19, [sp, #0x40]  | stack[1152921513505594816] = ???;  stack[1152921513505594824] = ???;  //  dest_result_addr=1152921513505594816 |  dest_result_addr=1152921513505594824
            // 0x00D1C44C: STP x29, x30, [sp, #0x50]  | stack[1152921513505594832] = ???;  stack[1152921513505594840] = ???;  //  dest_result_addr=1152921513505594832 |  dest_result_addr=1152921513505594840
            // 0x00D1C450: ADD x29, sp, #0x50         | X29 = (1152921513505594752 + 80) = 1152921513505594832 (0x1000000212681DD0);
            // 0x00D1C454: SUB sp, sp, #0xc0          | SP = (1152921513505594752 - 192) = 1152921513505594560 (0x1000000212681CC0);
            // 0x00D1C458: ADRP x23, #0x3734000       | X23 = 57884672 (0x3734000);             
            // 0x00D1C45C: LDRB w8, [x23, #0x2d4]     | W8 = (bool)static_value_037342D4;       
            // 0x00D1C460: MOV w19, w3                | W19 = currentCost;//m1                  
            val_18 = currentCost;
            // 0x00D1C464: MOV x20, x2                | X20 = b;//m1                            
            // 0x00D1C468: MOV x21, x1                | X21 = a;//m1                            
            val_19 = a;
            // 0x00D1C46C: MOV x22, x0                | X22 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C470: TBNZ w8, #0, #0xd1c48c     | if (static_value_037342D4 == true) goto label_0;
            // 0x00D1C474: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00D1C478: LDR x8, [x8, #0xef0]       | X8 = 0x2B8A774;                         
            // 0x00D1C47C: LDR w0, [x8]               | W0 = 0x9B;                              
            // 0x00D1C480: BL #0x2782188              | X0 = sub_2782188( ?? 0x9B, ????);       
            // 0x00D1C484: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1C488: STRB w8, [x23, #0x2d4]     | static_value_037342D4 = true;            //  dest_result_addr=57885396
            label_0:
            // 0x00D1C48C: STUR wzr, [x29, #-0x58]    | stack[1152921513505594744] = 0x0;        //  dest_result_addr=1152921513505594744
            // 0x00D1C490: STUR xzr, [x29, #-0x60]    | stack[1152921513505594736] = 0x0;        //  dest_result_addr=1152921513505594736
            // 0x00D1C494: STUR wzr, [x29, #-0x68]    | stack[1152921513505594728] = 0x0;        //  dest_result_addr=1152921513505594728
            // 0x00D1C498: STUR xzr, [x29, #-0x70]    | stack[1152921513505594720] = 0x0;        //  dest_result_addr=1152921513505594720
            // 0x00D1C49C: STUR wzr, [x29, #-0x78]    | stack[1152921513505594712] = 0x0;        //  dest_result_addr=1152921513505594712
            // 0x00D1C4A0: STUR xzr, [x29, #-0x80]    | stack[1152921513505594704] = 0x0;        //  dest_result_addr=1152921513505594704
            // 0x00D1C4A4: STR wzr, [sp, #0x88]       | stack[1152921513505594696] = 0x0;        //  dest_result_addr=1152921513505594696
            // 0x00D1C4A8: STR xzr, [sp, #0x80]       | stack[1152921513505594688] = 0x0;        //  dest_result_addr=1152921513505594688
            // 0x00D1C4AC: STR wzr, [sp, #0x78]       | stack[1152921513505594680] = 0x0;        //  dest_result_addr=1152921513505594680
            // 0x00D1C4B0: STR xzr, [sp, #0x70]       | stack[1152921513505594672] = 0x0;        //  dest_result_addr=1152921513505594672
            // 0x00D1C4B4: STR wzr, [sp, #0x68]       | stack[1152921513505594664] = 0x0;        //  dest_result_addr=1152921513505594664
            // 0x00D1C4B8: STR xzr, [sp, #0x60]       | stack[1152921513505594656] = 0x0;        //  dest_result_addr=1152921513505594656
            // 0x00D1C4BC: STR wzr, [sp, #0x58]       | stack[1152921513505594648] = 0x0;        //  dest_result_addr=1152921513505594648
            // 0x00D1C4C0: STR xzr, [sp, #0x50]       | stack[1152921513505594640] = 0x0;        //  dest_result_addr=1152921513505594640
            // 0x00D1C4C4: STR wzr, [sp, #0x48]       | stack[1152921513505594632] = 0x0;        //  dest_result_addr=1152921513505594632
            // 0x00D1C4C8: STR xzr, [sp, #0x40]       | stack[1152921513505594624] = 0x0;        //  dest_result_addr=1152921513505594624
            // 0x00D1C4CC: STR wzr, [sp, #0x38]       | stack[1152921513505594616] = 0x0;        //  dest_result_addr=1152921513505594616
            // 0x00D1C4D0: STR xzr, [sp, #0x30]       | stack[1152921513505594608] = 0x0;        //  dest_result_addr=1152921513505594608
            // 0x00D1C4D4: STR wzr, [sp, #0x28]       | stack[1152921513505594600] = 0x0;        //  dest_result_addr=1152921513505594600
            // 0x00D1C4D8: STR xzr, [sp, #0x20]       | stack[1152921513505594592] = 0x0;        //  dest_result_addr=1152921513505594592
            // 0x00D1C4DC: STR wzr, [sp, #0x18]       | stack[1152921513505594584] = 0x0;        //  dest_result_addr=1152921513505594584
            // 0x00D1C4E0: STR xzr, [sp, #0x10]       | stack[1152921513505594576] = 0x0;        //  dest_result_addr=1152921513505594576
            // 0x00D1C4E4: STR wzr, [sp, #8]          | stack[1152921513505594568] = 0x0;        //  dest_result_addr=1152921513505594568
            // 0x00D1C4E8: STR xzr, [sp]              | stack[1152921513505594560] = 0x0;        //  dest_result_addr=1152921513505594560
            // 0x00D1C4EC: LDR x9, [x22, #0x110]      | X9 = this.startNode; //P2               
            // 0x00D1C4F0: CBZ x9, #0xd1c5c4          | if (this.startNode == null) goto label_2;
            if(this.startNode == null)
            {
                goto label_2;
            }
            // 0x00D1C4F4: LDR x8, [x22, #0x118]      | X8 = this.endNode; //P2                 
            // 0x00D1C4F8: CBZ x8, #0xd1c5c4          | if (this.endNode == null) goto label_2; 
            if(this.endNode == null)
            {
                goto label_2;
            }
            // 0x00D1C4FC: CMP x9, x21                | STATE = COMPARE(this.startNode, a)      
            // 0x00D1C500: B.EQ #0xd1c740             | if (this.startNode == val_19) goto label_3;
            if(this.startNode == val_19)
            {
                goto label_3;
            }
            // 0x00D1C504: CMP x9, x20                | STATE = COMPARE(this.startNode, b)      
            // 0x00D1C508: B.EQ #0xd1c774             | if (this.startNode == b) goto label_4;  
            if(this.startNode == b)
            {
                goto label_4;
            }
            // 0x00D1C50C: CMP x8, x21                | STATE = COMPARE(this.endNode, a)        
            // 0x00D1C510: B.EQ #0xd1c7a8             | if (this.endNode == val_19) goto label_5;
            if(this.endNode == val_19)
            {
                goto label_5;
            }
            // 0x00D1C514: CMP x8, x20                | STATE = COMPARE(this.endNode, b)        
            // 0x00D1C518: B.NE #0xd1c9bc             | if (this.endNode != b) goto label_13;   
            if(this.endNode != b)
            {
                goto label_13;
            }
            // 0x00D1C51C: LDR x23, [x22, #0xe0]      | 
            // 0x00D1C520: LDR w22, [x22, #0xe8]      | 
            // 0x00D1C524: CBNZ x21, #0xd1c52c        | if (a != null) goto label_7;            
            if(val_19 != null)
            {
                goto label_7;
            }
            // 0x00D1C528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9B, ????);       
            label_7:
            // 0x00D1C52C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C530: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C534: LDR x25, [x21, #0x20]      | X25 = a.position; //P2                  
            val_20 = a.position;
            // 0x00D1C538: LDR w24, [x21, #0x28]      | 
            // 0x00D1C53C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C540: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C544: TBZ w8, #0, #0xd1c554      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00D1C548: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C54C: CBNZ w8, #0xd1c554         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00D1C550: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_9:
            // 0x00D1C554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C558: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C55C: MOV x1, x23                | X1 = 57884672 (0x3734000);//ML01        
            // 0x00D1C560: MOV x2, x22                | X2 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C564: MOV x3, x25                | X3 = a.position;//m1                    
            // 0x00D1C568: MOV x4, x24                | X4 = X24;//m1                           
            // 0x00D1C56C: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = 57884672}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            Pathfinding.Int3 val_1 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = 57884672}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            // 0x00D1C570: STR x0, [sp, #0x50]        | stack[1152921513505594640] = val_1.x; stack[1152921513505594644] = val_1.y;  //  dest_result_addr=1152921513505594640 dest_result_addr=1152921513505594644
            // 0x00D1C574: STR w1, [sp, #0x58]        | stack[1152921513505594648] = val_1.z;    //  dest_result_addr=1152921513505594648
            // 0x00D1C578: ADD x0, sp, #0x50          | X0 = (1152921513505594560 + 80) = 1152921513505594640 (0x1000000212681D10);
            // 0x00D1C57C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C580: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681D10, ????);
            // 0x00D1C584: LDR x23, [x21, #0x20]      | X23 = a.position; //P2                  
            val_17 = a.position;
            // 0x00D1C588: LDR w22, [x21, #0x28]      | 
            // 0x00D1C58C: MOV w21, w0                | W21 = 1152921513505594640 (0x1000000212681D10);//ML01
            val_19;
            // 0x00D1C590: CBNZ x20, #0xd1c598        | if (b != null) goto label_10;           
            if(b != null)
            {
                goto label_10;
            }
            // 0x00D1C594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D10, ????);
            label_10:
            // 0x00D1C598: LDR x3, [x20, #0x20]       | X3 = b.position; //P2                   
            // 0x00D1C59C: LDR w4, [x20, #0x28]       | 
            // 0x00D1C5A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C5A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C5A8: MOV x1, x23                | X1 = a.position;//m1                    
            // 0x00D1C5AC: MOV x2, x22                | X2 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C5B0: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = b.position});
            Pathfinding.Int3 val_2 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = b.position});
            // 0x00D1C5B4: STR x0, [sp, #0x40]        | stack[1152921513505594624] = val_2.x; stack[1152921513505594628] = val_2.y;  //  dest_result_addr=1152921513505594624 dest_result_addr=1152921513505594628
            // 0x00D1C5B8: STR w1, [sp, #0x48]        | stack[1152921513505594632] = val_2.z;    //  dest_result_addr=1152921513505594632
            // 0x00D1C5BC: ADD x0, sp, #0x40          | X0 = (1152921513505594560 + 64) = 1152921513505594624 (0x1000000212681D00);
            // 0x00D1C5C0: B #0xd1c67c                |  goto label_11;                         
            goto label_11;
            label_2:
            // 0x00D1C5C4: CMP x9, x21                | STATE = COMPARE(this.startNode, a)      
            // 0x00D1C5C8: B.EQ #0xd1c68c             | if (this.startNode == val_19) goto label_12;
            if(this.startNode == val_19)
            {
                goto label_12;
            }
            // 0x00D1C5CC: CMP x9, x20                | STATE = COMPARE(this.startNode, b)      
            // 0x00D1C5D0: B.NE #0xd1c9bc             | if (this.startNode != b) goto label_13; 
            if(this.startNode != b)
            {
                goto label_13;
            }
            // 0x00D1C5D4: ADD x8, x22, #0x164        | X8 = this.startIntPoint;//AP2 res_addr=1152921513505607204
            // 0x00D1C5D8: LDR x23, [x8]              | X23 = this.startIntPoint.x;             
            // 0x00D1C5DC: LDR w22, [x22, #0x16c]     | 
            // 0x00D1C5E0: CBNZ x21, #0xd1c5e8        | if (a != null) goto label_14;           
            if(val_19 != null)
            {
                goto label_14;
            }
            // 0x00D1C5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9B, ????);       
            label_14:
            // 0x00D1C5E8: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C5EC: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C5F0: LDR x25, [x21, #0x20]      | X25 = a.position; //P2                  
            val_20 = a.position;
            // 0x00D1C5F4: LDR w24, [x21, #0x28]      | 
            // 0x00D1C5F8: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C5FC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C600: TBZ w8, #0, #0xd1c610      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00D1C604: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C608: CBNZ w8, #0xd1c610         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00D1C60C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_16:
            // 0x00D1C610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C614: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C618: MOV x1, x23                | X1 = this.startIntPoint.x;//m1          
            // 0x00D1C61C: MOV x2, x22                | X2 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C620: MOV x3, x25                | X3 = a.position;//m1                    
            // 0x00D1C624: MOV x4, x24                | X4 = X24;//m1                           
            // 0x00D1C628: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = this.startIntPoint.x}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            Pathfinding.Int3 val_3 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = this.startIntPoint.x}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            // 0x00D1C62C: STR x0, [sp, #0x10]        | stack[1152921513505594576] = val_3.x; stack[1152921513505594580] = val_3.y;  //  dest_result_addr=1152921513505594576 dest_result_addr=1152921513505594580
            // 0x00D1C630: STR w1, [sp, #0x18]        | stack[1152921513505594584] = val_3.z;    //  dest_result_addr=1152921513505594584
            // 0x00D1C634: ADD x0, sp, #0x10          | X0 = (1152921513505594560 + 16) = 1152921513505594576 (0x1000000212681CD0);
            // 0x00D1C638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C63C: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681CD0, ????);
            // 0x00D1C640: LDR x23, [x21, #0x20]      | X23 = a.position; //P2                  
            val_17 = a.position;
            // 0x00D1C644: LDR w22, [x21, #0x28]      | 
            // 0x00D1C648: MOV w21, w0                | W21 = 1152921513505594576 (0x1000000212681CD0);//ML01
            val_19;
            // 0x00D1C64C: CBNZ x20, #0xd1c654        | if (b != null) goto label_17;           
            if(b != null)
            {
                goto label_17;
            }
            // 0x00D1C650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681CD0, ????);
            label_17:
            // 0x00D1C654: LDR x3, [x20, #0x20]       | X3 = b.position; //P2                   
            // 0x00D1C658: LDR w4, [x20, #0x28]       | 
            // 0x00D1C65C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C660: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C664: MOV x1, x23                | X1 = a.position;//m1                    
            // 0x00D1C668: MOV x2, x22                | X2 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C66C: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = b.position});
            Pathfinding.Int3 val_4 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = b.position});
            // 0x00D1C670: STR x0, [sp]               | stack[1152921513505594560] = val_4.x; stack[1152921513505594564] = val_4.y;  //  dest_result_addr=1152921513505594560 dest_result_addr=1152921513505594564
            // 0x00D1C674: STR w1, [sp, #8]           | stack[1152921513505594568] = val_4.z;    //  dest_result_addr=1152921513505594568
            // 0x00D1C678: MOV x0, sp                 | X0 = 1152921513505594560 (0x1000000212681CC0);//ML01
            val_21;
            label_11:
            // 0x00D1C67C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C680: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681CC0, ????);
            // 0x00D1C684: SCVTF d0, w21              | D0 = 1.15292150460685E+18;              
            val_22 = 1.15292150460685E+18;
            // 0x00D1C688: B #0xd1c9a8                |  goto label_18;                         
            goto label_18;
            label_12:
            // 0x00D1C68C: ADD x8, x22, #0x164        | X8 = this.startIntPoint;//AP2 res_addr=1152921513505607204
            // 0x00D1C690: LDR x23, [x8]              | X23 = this.startIntPoint.x;             
            // 0x00D1C694: LDR w22, [x22, #0x16c]     | 
            // 0x00D1C698: CBNZ x20, #0xd1c6a0        | if (b != null) goto label_19;           
            if(b != null)
            {
                goto label_19;
            }
            // 0x00D1C69C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9B, ????);       
            label_19:
            // 0x00D1C6A0: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C6A4: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C6A8: LDR x25, [x20, #0x20]      | X25 = b.position; //P2                  
            val_20 = b.position;
            // 0x00D1C6AC: LDR w24, [x20, #0x28]      | 
            // 0x00D1C6B0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C6B4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C6B8: TBZ w8, #0, #0xd1c6c8      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00D1C6BC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C6C0: CBNZ w8, #0xd1c6c8         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00D1C6C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_21:
            // 0x00D1C6C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C6CC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C6D0: MOV x1, x23                | X1 = this.startIntPoint.x;//m1          
            // 0x00D1C6D4: MOV x2, x22                | X2 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C6D8: MOV x3, x25                | X3 = b.position;//m1                    
            // 0x00D1C6DC: MOV x4, x24                | X4 = X24;//m1                           
            // 0x00D1C6E0: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = this.startIntPoint.x}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            Pathfinding.Int3 val_5 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = this.startIntPoint.x}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            // 0x00D1C6E4: STR x0, [sp, #0x30]        | stack[1152921513505594608] = val_5.x; stack[1152921513505594612] = val_5.y;  //  dest_result_addr=1152921513505594608 dest_result_addr=1152921513505594612
            // 0x00D1C6E8: STR w1, [sp, #0x38]        | stack[1152921513505594616] = val_5.z;    //  dest_result_addr=1152921513505594616
            // 0x00D1C6EC: ADD x0, sp, #0x30          | X0 = (1152921513505594560 + 48) = 1152921513505594608 (0x1000000212681CF0);
            // 0x00D1C6F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C6F4: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681CF0, ????);
            // 0x00D1C6F8: MOV w22, w0                | W22 = 1152921513505594608 (0x1000000212681CF0);//ML01
            val_23;
            // 0x00D1C6FC: CBNZ x21, #0xd1c704        | if (a != null) goto label_22;           
            if(val_19 != null)
            {
                goto label_22;
            }
            // 0x00D1C700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681CF0, ????);
            label_22:
            // 0x00D1C704: LDR x23, [x21, #0x20]      | X23 = a.position; //P2                  
            val_17 = a.position;
            // 0x00D1C708: LDR w21, [x21, #0x28]      | 
            // 0x00D1C70C: CBNZ x20, #0xd1c714        | if (b != null) goto label_23;           
            if(b != null)
            {
                goto label_23;
            }
            // 0x00D1C710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681CF0, ????);
            label_23:
            // 0x00D1C714: LDR x3, [x20, #0x20]       | X3 = b.position; //P2                   
            // 0x00D1C718: LDR w4, [x20, #0x28]       | 
            // 0x00D1C71C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C720: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C724: MOV x1, x23                | X1 = a.position;//m1                    
            // 0x00D1C728: MOV x2, x21                | X2 = a;//m1                             
            // 0x00D1C72C: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            Pathfinding.Int3 val_6 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            // 0x00D1C730: STR x0, [sp, #0x20]        | stack[1152921513505594592] = val_6.x; stack[1152921513505594596] = val_6.y;  //  dest_result_addr=1152921513505594592 dest_result_addr=1152921513505594596
            // 0x00D1C734: STR w1, [sp, #0x28]        | stack[1152921513505594600] = val_6.z;    //  dest_result_addr=1152921513505594600
            // 0x00D1C738: ADD x0, sp, #0x20          | X0 = (1152921513505594560 + 32) = 1152921513505594592 (0x1000000212681CE0);
            // 0x00D1C73C: B #0xd1c99c                |  goto label_41;                         
            goto label_41;
            label_3:
            // 0x00D1C740: ADD x9, x22, #0x164        | X9 = this.startIntPoint;//AP2 res_addr=1152921513505607204
            // 0x00D1C744: LDR x9, [x9]               | X9 = this.startIntPoint.x;              
            // 0x00D1C748: LDR w24, [x22, #0x16c]     | 
            // 0x00D1C74C: CMP x8, x20                | STATE = COMPARE(this.endNode, b)        
            // 0x00D1C750: CSEL x23, xzr, x9, eq      | X23 = this.endNode == b ? 0 : this.startIntPoint.x;
            var val_7 = (this.endNode == b) ? 0 : (this.startIntPoint.x);
            // 0x00D1C754: CSEL x26, xzr, x24, eq     | X26 = this.endNode == b ? 0 : X24;      
            var val_8 = (this.endNode == b) ? 0 : (X24);
            // 0x00D1C758: B.EQ #0xd1c858             | if (this.endNode == b) goto label_25;   
            if(this.endNode == b)
            {
                goto label_25;
            }
            // 0x00D1C75C: CBNZ x20, #0xd1c764        | if (b != null) goto label_26;           
            if(b != null)
            {
                goto label_26;
            }
            // 0x00D1C760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9B, ????);       
            label_26:
            // 0x00D1C764: LDR x25, [x20, #0x20]      | X25 = b.position; //P2                  
            val_20 = b.position;
            // 0x00D1C768: LDR w22, [x20, #0x28]      | 
            // 0x00D1C76C: MOV x24, x26               | X24 = this.endNode == b ? 0 : X24;//m1  
            val_24 = val_8;
            // 0x00D1C770: B #0xd1c864                |  goto label_27;                         
            goto label_27;
            label_4:
            // 0x00D1C774: ADD x9, x22, #0x164        | X9 = this.startIntPoint;//AP2 res_addr=1152921513505607204
            // 0x00D1C778: LDR x9, [x9]               | X9 = this.startIntPoint.x;              
            // 0x00D1C77C: LDR w24, [x22, #0x16c]     | 
            // 0x00D1C780: CMP x8, x21                | STATE = COMPARE(this.endNode, a)        
            // 0x00D1C784: CSEL x23, xzr, x9, eq      | X23 = this.endNode == val_19 ? 0 : this.startIntPoint.x;
            var val_9 = (this.endNode == val_19) ? 0 : (this.startIntPoint.x);
            // 0x00D1C788: CSEL x26, xzr, x24, eq     | X26 = this.endNode == val_19 ? 0 : X24; 
            var val_10 = (this.endNode == val_19) ? 0 : (X24);
            // 0x00D1C78C: B.EQ #0xd1c8fc             | if (this.endNode == val_19) goto label_28;
            if(this.endNode == val_19)
            {
                goto label_28;
            }
            // 0x00D1C790: CBNZ x21, #0xd1c798        | if (a != null) goto label_29;           
            if(val_19 != null)
            {
                goto label_29;
            }
            // 0x00D1C794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9B, ????);       
            label_29:
            // 0x00D1C798: LDR x25, [x21, #0x20]      | X25 = a.position; //P2                  
            val_20 = a.position;
            // 0x00D1C79C: LDR w22, [x21, #0x28]      | 
            // 0x00D1C7A0: MOV x24, x26               | X24 = this.endNode == val_19 ? 0 : X24;//m1
            val_27 = val_10;
            // 0x00D1C7A4: B #0xd1c908                |  goto label_30;                         
            goto label_30;
            label_5:
            // 0x00D1C7A8: LDR x23, [x22, #0xe0]      | 
            // 0x00D1C7AC: LDR w22, [x22, #0xe8]      | 
            // 0x00D1C7B0: CBNZ x20, #0xd1c7b8        | if (b != null) goto label_31;           
            if(b != null)
            {
                goto label_31;
            }
            // 0x00D1C7B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9B, ????);       
            label_31:
            // 0x00D1C7B8: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C7BC: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C7C0: LDR x25, [x20, #0x20]      | X25 = b.position; //P2                  
            val_20 = b.position;
            // 0x00D1C7C4: LDR w24, [x20, #0x28]      | 
            // 0x00D1C7C8: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C7CC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C7D0: TBZ w8, #0, #0xd1c7e0      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x00D1C7D4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C7D8: CBNZ w8, #0xd1c7e0         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x00D1C7DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_33:
            // 0x00D1C7E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C7E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C7E8: MOV x1, x23                | X1 = 57884672 (0x3734000);//ML01        
            // 0x00D1C7EC: MOV x2, x22                | X2 = 1152921513505606848 (0x1000000212684CC0);//ML01
            // 0x00D1C7F0: MOV x3, x25                | X3 = b.position;//m1                    
            // 0x00D1C7F4: MOV x4, x24                | X4 = X24;//m1                           
            // 0x00D1C7F8: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = 57884672}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            Pathfinding.Int3 val_11 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = 57884672}, rhs:  new Pathfinding.Int3() {x = 308825280, y = 268435458, z = val_20});
            // 0x00D1C7FC: STR x0, [sp, #0x70]        | stack[1152921513505594672] = val_11.x; stack[1152921513505594676] = val_11.y;  //  dest_result_addr=1152921513505594672 dest_result_addr=1152921513505594676
            // 0x00D1C800: STR w1, [sp, #0x78]        | stack[1152921513505594680] = val_11.z;   //  dest_result_addr=1152921513505594680
            // 0x00D1C804: ADD x0, sp, #0x70          | X0 = (1152921513505594560 + 112) = 1152921513505594672 (0x1000000212681D30);
            // 0x00D1C808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C80C: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681D30, ????);
            // 0x00D1C810: MOV w22, w0                | W22 = 1152921513505594672 (0x1000000212681D30);//ML01
            val_23;
            // 0x00D1C814: CBNZ x21, #0xd1c81c        | if (a != null) goto label_34;           
            if(val_19 != null)
            {
                goto label_34;
            }
            // 0x00D1C818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D30, ????);
            label_34:
            // 0x00D1C81C: LDR x23, [x21, #0x20]      | X23 = a.position; //P2                  
            val_17 = a.position;
            // 0x00D1C820: LDR w21, [x21, #0x28]      | 
            // 0x00D1C824: CBNZ x20, #0xd1c82c        | if (b != null) goto label_35;           
            if(b != null)
            {
                goto label_35;
            }
            // 0x00D1C828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D30, ????);
            label_35:
            // 0x00D1C82C: LDR x3, [x20, #0x20]       | X3 = b.position; //P2                   
            // 0x00D1C830: LDR w4, [x20, #0x28]       | 
            // 0x00D1C834: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C838: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C83C: MOV x1, x23                | X1 = a.position;//m1                    
            // 0x00D1C840: MOV x2, x21                | X2 = a;//m1                             
            // 0x00D1C844: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            Pathfinding.Int3 val_12 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            // 0x00D1C848: STR x0, [sp, #0x60]        | stack[1152921513505594656] = val_12.x; stack[1152921513505594660] = val_12.y;  //  dest_result_addr=1152921513505594656 dest_result_addr=1152921513505594660
            // 0x00D1C84C: STR w1, [sp, #0x68]        | stack[1152921513505594664] = val_12.z;   //  dest_result_addr=1152921513505594664
            // 0x00D1C850: ADD x0, sp, #0x60          | X0 = (1152921513505594560 + 96) = 1152921513505594656 (0x1000000212681D20);
            // 0x00D1C854: B #0xd1c99c                |  goto label_41;                         
            goto label_41;
            label_25:
            // 0x00D1C858: LDR x25, [x22, #0xe0]      | 
            // 0x00D1C85C: LDR w22, [x22, #0xe8]      | 
            // 0x00D1C860: MOV x23, x9                | X23 = this.startIntPoint.x;//m1         
            val_25 = this.startIntPoint.x;
            label_27:
            // 0x00D1C864: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C868: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C86C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C870: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C874: TBZ w8, #0, #0xd1c884      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x00D1C878: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C87C: CBNZ w8, #0xd1c884         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x00D1C880: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_38:
            // 0x00D1C884: AND x4, x22, #0xffffffff   | X4 = (this & 4294967295) = 308825280 (0x12684CC0);
            // 0x00D1C888: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C88C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C890: MOV x1, x23                | X1 = this.startIntPoint.x;//m1          
            // 0x00D1C894: MOV x2, x24                | X2 = X24;//m1                           
            // 0x00D1C898: MOV x3, x25                | X3 = X25;//m1                           
            // 0x00D1C89C: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_25}, rhs:  new Pathfinding.Int3() {x = X24, y = X24, z = X25});
            Pathfinding.Int3 val_13 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_25}, rhs:  new Pathfinding.Int3() {x = X24, y = X24, z = X25});
            // 0x00D1C8A0: STUR x0, [x29, #-0x60]     | stack[1152921513505594736] = val_13.x; stack[1152921513505594740] = val_13.y;  //  dest_result_addr=1152921513505594736 dest_result_addr=1152921513505594740
            // 0x00D1C8A4: STUR w1, [x29, #-0x58]     | stack[1152921513505594744] = val_13.z;   //  dest_result_addr=1152921513505594744
            // 0x00D1C8A8: SUB x0, x29, #0x60         | X0 = (1152921513505594832 - 96) = 1152921513505594736 (0x1000000212681D70);
            // 0x00D1C8AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C8B0: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681D70, ????);
            // 0x00D1C8B4: MOV w22, w0                | W22 = 1152921513505594736 (0x1000000212681D70);//ML01
            val_23;
            // 0x00D1C8B8: CBNZ x21, #0xd1c8c0        | if (a != null) goto label_39;           
            if(val_19 != null)
            {
                goto label_39;
            }
            // 0x00D1C8BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D70, ????);
            label_39:
            // 0x00D1C8C0: LDR x23, [x21, #0x20]      | X23 = a.position; //P2                  
            val_17 = a.position;
            // 0x00D1C8C4: LDR w21, [x21, #0x28]      | 
            // 0x00D1C8C8: CBNZ x20, #0xd1c8d0        | if (b != null) goto label_40;           
            if(b != null)
            {
                goto label_40;
            }
            // 0x00D1C8CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D70, ????);
            label_40:
            // 0x00D1C8D0: LDR x3, [x20, #0x20]       | X3 = b.position; //P2                   
            // 0x00D1C8D4: LDR w4, [x20, #0x28]       | 
            // 0x00D1C8D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C8DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C8E0: MOV x1, x23                | X1 = a.position;//m1                    
            // 0x00D1C8E4: MOV x2, x21                | X2 = a;//m1                             
            // 0x00D1C8E8: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            Pathfinding.Int3 val_14 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            // 0x00D1C8EC: STUR x0, [x29, #-0x70]     | stack[1152921513505594720] = val_14.x; stack[1152921513505594724] = val_14.y;  //  dest_result_addr=1152921513505594720 dest_result_addr=1152921513505594724
            // 0x00D1C8F0: STUR w1, [x29, #-0x68]     | stack[1152921513505594728] = val_14.z;   //  dest_result_addr=1152921513505594728
            // 0x00D1C8F4: SUB x0, x29, #0x70         | X0 = (1152921513505594832 - 112) = 1152921513505594720 (0x1000000212681D60);
            // 0x00D1C8F8: B #0xd1c99c                |  goto label_41;                         
            goto label_41;
            label_28:
            // 0x00D1C8FC: LDR x25, [x22, #0xe0]      | 
            // 0x00D1C900: LDR w22, [x22, #0xe8]      | 
            // 0x00D1C904: MOV x23, x9                | X23 = this.startIntPoint.x;//m1         
            val_28 = this.startIntPoint.x;
            label_30:
            // 0x00D1C908: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1C90C: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x00D1C910: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1C914: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1C918: TBZ w8, #0, #0xd1c928      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x00D1C91C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1C920: CBNZ w8, #0xd1c928         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x00D1C924: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_43:
            // 0x00D1C928: AND x4, x22, #0xffffffff   | X4 = (this & 4294967295) = 308825280 (0x12684CC0);
            // 0x00D1C92C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C930: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C934: MOV x1, x23                | X1 = this.startIntPoint.x;//m1          
            // 0x00D1C938: MOV x2, x24                | X2 = X24;//m1                           
            // 0x00D1C93C: MOV x3, x25                | X3 = X25;//m1                           
            // 0x00D1C940: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_28}, rhs:  new Pathfinding.Int3() {x = X24, y = X24, z = X25});
            Pathfinding.Int3 val_15 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_28}, rhs:  new Pathfinding.Int3() {x = X24, y = X24, z = X25});
            // 0x00D1C944: STUR x0, [x29, #-0x80]     | stack[1152921513505594704] = val_15.x; stack[1152921513505594708] = val_15.y;  //  dest_result_addr=1152921513505594704 dest_result_addr=1152921513505594708
            // 0x00D1C948: STUR w1, [x29, #-0x78]     | stack[1152921513505594712] = val_15.z;   //  dest_result_addr=1152921513505594712
            // 0x00D1C94C: SUB x0, x29, #0x80         | X0 = (1152921513505594832 - 128) = 1152921513505594704 (0x1000000212681D50);
            // 0x00D1C950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C954: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681D50, ????);
            // 0x00D1C958: MOV w22, w0                | W22 = 1152921513505594704 (0x1000000212681D50);//ML01
            val_23;
            // 0x00D1C95C: CBNZ x21, #0xd1c964        | if (a != null) goto label_44;           
            if(val_19 != null)
            {
                goto label_44;
            }
            // 0x00D1C960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D50, ????);
            label_44:
            // 0x00D1C964: LDR x23, [x21, #0x20]      | X23 = a.position; //P2                  
            val_17 = a.position;
            // 0x00D1C968: LDR w21, [x21, #0x28]      | 
            // 0x00D1C96C: CBNZ x20, #0xd1c974        | if (b != null) goto label_45;           
            if(b != null)
            {
                goto label_45;
            }
            // 0x00D1C970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000212681D50, ????);
            label_45:
            // 0x00D1C974: LDR x3, [x20, #0x20]       | X3 = b.position; //P2                   
            // 0x00D1C978: LDR w4, [x20, #0x28]       | 
            // 0x00D1C97C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1C980: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00D1C984: MOV x1, x23                | X1 = a.position;//m1                    
            // 0x00D1C988: MOV x2, x21                | X2 = a;//m1                             
            // 0x00D1C98C: BL #0x1549148              | X0 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            Pathfinding.Int3 val_16 = Pathfinding.Int3.op_Subtraction(lhs:  new Pathfinding.Int3() {z = val_17}, rhs:  new Pathfinding.Int3() {x = val_19, y = val_19, z = b.position});
            // 0x00D1C990: STR x0, [sp, #0x80]        | stack[1152921513505594688] = val_16.x; stack[1152921513505594692] = val_16.y;  //  dest_result_addr=1152921513505594688 dest_result_addr=1152921513505594692
            // 0x00D1C994: STR w1, [sp, #0x88]        | stack[1152921513505594696] = val_16.z;   //  dest_result_addr=1152921513505594696
            // 0x00D1C998: ADD x0, sp, #0x80          | X0 = (1152921513505594560 + 128) = 1152921513505594688 (0x1000000212681D40);
            label_41:
            // 0x00D1C99C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1C9A0: BL #0x1549d64              | X0 = sub_1549D64( ?? 0x1000000212681D40, ????);
            // 0x00D1C9A4: SCVTF d0, w22              | D0 = 1.15292150460685E+18;              
            val_22 = 1.15292150460685E+18;
            label_18:
            // 0x00D1C9A8: UCVTF d1, w19              | D1 = (double)(currentCost);             
            double val_17 = (double)val_18;
            // 0x00D1C9AC: SCVTF d2, w0               | D2 = 1.15292150460685E+18;              
            // 0x00D1C9B0: FDIV d1, d1, d2            | D1 = (currentCost / 1.15292150460685E+18);
            val_17 = val_17 / (1.15292150460685E+18);
            // 0x00D1C9B4: FMUL d0, d0, d1            | D0 = (val_22 * (currentCost / 1.15292150460685E+18));
            val_22 = val_22 * val_17;
            // 0x00D1C9B8: FCVTZU w19, d0             | 
            label_13:
            // 0x00D1C9BC: MOV w0, w19                | W0 = currentCost;//m1                   
            // 0x00D1C9C0: SUB sp, x29, #0x50         | SP = (1152921513505594832 - 80) = 1152921513505594752 (0x1000000212681D80);
            // 0x00D1C9C4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1C9C8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1C9CC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1C9D0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00D1C9D4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00D1C9D8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00D1C9DC: RET                        |  return (System.UInt32)currentCost;     
            return (uint)val_18;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1C9E0 (13748704), len: 252  VirtAddr: 0x00D1C9E0 RVA: 0x00D1C9E0 token: 100683587 methodIndex: 49691 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Reset()
        {
            //
            // Disasemble & Code
            // 0x00D1C9E0: STP x20, x19, [sp, #-0x20]! | stack[1152921513505723200] = ???;  stack[1152921513505723208] = ???;  //  dest_result_addr=1152921513505723200 |  dest_result_addr=1152921513505723208
            // 0x00D1C9E4: STP x29, x30, [sp, #0x10]  | stack[1152921513505723216] = ???;  stack[1152921513505723224] = ???;  //  dest_result_addr=1152921513505723216 |  dest_result_addr=1152921513505723224
            // 0x00D1C9E8: ADD x29, sp, #0x10         | X29 = (1152921513505723200 + 16) = 1152921513505723216 (0x10000002126A1350);
            // 0x00D1C9EC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1C9F0: LDRB w8, [x20, #0x2d5]     | W8 = (bool)static_value_037342D5;       
            // 0x00D1C9F4: MOV x19, x0                | X19 = 1152921513505735232 (0x10000002126A4240);//ML01
            // 0x00D1C9F8: TBNZ w8, #0, #0xd1ca14     | if (static_value_037342D5 == true) goto label_0;
            // 0x00D1C9FC: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00D1CA00: LDR x8, [x8, #0xb68]       | X8 = 0x2B8A788;                         
            // 0x00D1CA04: LDR w0, [x8]               | W0 = 0xA0;                              
            // 0x00D1CA08: BL #0x2782188              | X0 = sub_2782188( ?? 0xA0, ????);       
            // 0x00D1CA0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1CA10: STRB w8, [x20, #0x2d5]     | static_value_037342D5 = true;            //  dest_result_addr=57885397
            label_0:
            // 0x00D1CA14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CA18: MOV x0, x19                | X0 = 1152921513505735232 (0x10000002126A4240);//ML01
            // 0x00D1CA1C: BL #0x1403898              | this.Reset();                           
            this.Reset();
            // 0x00D1CA20: STP xzr, xzr, [x19, #0x120] | this.startHint = null;  this.endHint = null;  //  dest_result_addr=1152921513505735520 |  dest_result_addr=1152921513505735528
            this.startHint = 0;
            this.endHint = 0;
            // 0x00D1CA24: STP xzr, xzr, [x19, #0x110] | this.startNode = null;  this.endNode = null;  //  dest_result_addr=1152921513505735504 |  dest_result_addr=1152921513505735512
            this.startNode = 0;
            this.endNode = 0;
            // 0x00D1CA28: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00D1CA2C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00D1CA30: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x00D1CA34: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00D1CA38: TBZ w8, #0, #0xd1ca48      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00D1CA3C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1CA40: CBNZ w8, #0xd1ca48         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00D1CA44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x00D1CA48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CA4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CA50: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_1 = UnityEngine.Vector3.zero;
            // 0x00D1CA54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CA58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CA5C: STR s0, [x19, #0x130]      | this.originalStartPoint = val_1;         //  dest_result_addr=1152921513505735536
            this.originalStartPoint = val_1;
            // 0x00D1CA60: STR s1, [x19, #0x134]      | mem[1152921513505735540] = val_1.y;      //  dest_result_addr=1152921513505735540
            mem[1152921513505735540] = val_1.y;
            // 0x00D1CA64: STR s2, [x19, #0x138]      | mem[1152921513505735544] = val_1.z;      //  dest_result_addr=1152921513505735544
            mem[1152921513505735544] = val_1.z;
            // 0x00D1CA68: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.zero;
            // 0x00D1CA6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CA70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CA74: STR s0, [x19, #0x13c]      | this.originalEndPoint = val_2;           //  dest_result_addr=1152921513505735548
            this.originalEndPoint = val_2;
            // 0x00D1CA78: STR s1, [x19, #0x140]      | mem[1152921513505735552] = val_2.y;      //  dest_result_addr=1152921513505735552
            mem[1152921513505735552] = val_2.y;
            // 0x00D1CA7C: STR s2, [x19, #0x144]      | mem[1152921513505735556] = val_2.z;      //  dest_result_addr=1152921513505735556
            mem[1152921513505735556] = val_2.z;
            // 0x00D1CA80: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.zero;
            // 0x00D1CA84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CA88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CA8C: STR s0, [x19, #0x148]      | this.startPoint = val_3;                 //  dest_result_addr=1152921513505735560
            this.startPoint = val_3;
            // 0x00D1CA90: STR s1, [x19, #0x14c]      | mem[1152921513505735564] = val_3.y;      //  dest_result_addr=1152921513505735564
            mem[1152921513505735564] = val_3.y;
            // 0x00D1CA94: STR s2, [x19, #0x150]      | mem[1152921513505735568] = val_3.z;      //  dest_result_addr=1152921513505735568
            mem[1152921513505735568] = val_3.z;
            // 0x00D1CA98: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_4 = UnityEngine.Vector3.zero;
            // 0x00D1CA9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1CAA0: STRB w8, [x19, #0x160]     | this.hasEndPoint = true;                 //  dest_result_addr=1152921513505735584
            this.hasEndPoint = true;
            // 0x00D1CAA4: ADD x8, x19, #0x164        | X8 = this.startIntPoint;//AP2 res_addr=1152921513505735588
            // 0x00D1CAA8: STR s0, [x19, #0x154]      | this.endPoint = val_4;                   //  dest_result_addr=1152921513505735572
            this.endPoint = val_4;
            // 0x00D1CAAC: STR s1, [x19, #0x158]      | mem[1152921513505735576] = val_4.y;      //  dest_result_addr=1152921513505735576
            mem[1152921513505735576] = val_4.y;
            // 0x00D1CAB0: STR s2, [x19, #0x15c]      | mem[1152921513505735580] = val_4.z;      //  dest_result_addr=1152921513505735580
            mem[1152921513505735580] = val_4.z;
            // 0x00D1CAB4: STRB wzr, [x19, #0x170]    | this.calculatePartial = false;           //  dest_result_addr=1152921513505735600
            this.calculatePartial = false;
            // 0x00D1CAB8: STR xzr, [x19, #0x178]     | this.partialBestTarget = null;           //  dest_result_addr=1152921513505735608
            this.partialBestTarget = 0;
            // 0x00D1CABC: STR xzr, [x8]              | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x00D1CAC0: STR xzr, [x19, #0x180]     | this.endNodeCosts = null;                //  dest_result_addr=1152921513505735616
            this.endNodeCosts = 0;
            // 0x00D1CAC4: STR wzr, [x19, #0x16c]     | mem[1152921513505735596] = 0x0;          //  dest_result_addr=1152921513505735596
            mem[1152921513505735596] = 0;
            // 0x00D1CAC8: STR xzr, [x19, #0xe0]      | mem[1152921513505735456] = 0x0;          //  dest_result_addr=1152921513505735456
            mem[1152921513505735456] = 0;
            // 0x00D1CACC: STR wzr, [x19, #0xe8]      | mem[1152921513505735464] = 0x0;          //  dest_result_addr=1152921513505735464
            mem[1152921513505735464] = 0;
            // 0x00D1CAD0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1CAD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00D1CAD8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1CADC (13748956), len: 1484  VirtAddr: 0x00D1CADC RVA: 0x00D1CADC token: 100683588 methodIndex: 49692 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Prepare()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.GraphNode val_2;
            //  | 
            UnityEngine.Vector3 val_3;
            //  | 
            float val_4;
            //  | 
            float val_5;
            //  | 
            var val_18;
            //  | 
            Pathfinding.GraphNode val_19;
            //  | 
            UnityEngine.Vector3 val_20;
            //  | 
            float val_21;
            //  | 
            var val_22;
            //  | 
            float val_23;
            //  | 
            var val_24;
            //  | 
            string val_25;
            //  | 
            var val_26;
            // 0x00D1CADC: STP d11, d10, [sp, #-0x60]! | stack[1152921513505914112] = ???;  stack[1152921513505914120] = ???;  //  dest_result_addr=1152921513505914112 |  dest_result_addr=1152921513505914120
            // 0x00D1CAE0: STP d9, d8, [sp, #0x10]    | stack[1152921513505914128] = ???;  stack[1152921513505914136] = ???;  //  dest_result_addr=1152921513505914128 |  dest_result_addr=1152921513505914136
            // 0x00D1CAE4: STP x24, x23, [sp, #0x20]  | stack[1152921513505914144] = ???;  stack[1152921513505914152] = ???;  //  dest_result_addr=1152921513505914144 |  dest_result_addr=1152921513505914152
            // 0x00D1CAE8: STP x22, x21, [sp, #0x30]  | stack[1152921513505914160] = ???;  stack[1152921513505914168] = ???;  //  dest_result_addr=1152921513505914160 |  dest_result_addr=1152921513505914168
            // 0x00D1CAEC: STP x20, x19, [sp, #0x40]  | stack[1152921513505914176] = ???;  stack[1152921513505914184] = ???;  //  dest_result_addr=1152921513505914176 |  dest_result_addr=1152921513505914184
            // 0x00D1CAF0: STP x29, x30, [sp, #0x50]  | stack[1152921513505914192] = ???;  stack[1152921513505914200] = ???;  //  dest_result_addr=1152921513505914192 |  dest_result_addr=1152921513505914200
            // 0x00D1CAF4: ADD x29, sp, #0x50         | X29 = (1152921513505914112 + 80) = 1152921513505914192 (0x10000002126CFD50);
            // 0x00D1CAF8: SUB sp, sp, #0x40          | SP = (1152921513505914112 - 64) = 1152921513505914048 (0x10000002126CFCC0);
            // 0x00D1CAFC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1CB00: LDRB w8, [x20, #0x2d6]     | W8 = (bool)static_value_037342D6;       
            // 0x00D1CB04: MOV x19, x0                | X19 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1CB08: TBNZ w8, #0, #0xd1cb24     | if (static_value_037342D6 == true) goto label_0;
            // 0x00D1CB0C: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x00D1CB10: LDR x8, [x8, #0x188]       | X8 = 0x2B8A780;                         
            // 0x00D1CB14: LDR w0, [x8]               | W0 = 0x9E;                              
            // 0x00D1CB18: BL #0x2782188              | X0 = sub_2782188( ?? 0x9E, ????);       
            // 0x00D1CB1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1CB20: STRB w8, [x20, #0x2d6]     | static_value_037342D6 = true;            //  dest_result_addr=57885398
            label_0:
            // 0x00D1CB24: LDR x20, [x19, #0xa8]      | 
            // 0x00D1CB28: LDR w21, [x19, #0xec]      | 
            // 0x00D1CB2C: CBNZ x20, #0xd1cb34        | if ( != 0) goto label_1;                
            if(!=0)
            {
                goto label_1;
            }
            // 0x00D1CB30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9E, ????);       
            label_1:
            // 0x00D1CB34: STR w21, [x20, #0x20]      | static_value_03734020 = ;                //  dest_result_addr=57884704
            // 0x00D1CB38: ADRP x23, #0x362c000       | X23 = 56803328 (0x362C000);             
            // 0x00D1CB3C: LDR x23, [x23, #0xe80]     | X23 = 1152921504837996544;              
            // 0x00D1CB40: LDR x0, [x23]              | X0 = typeof(AstarPath);                 
            val_18 = null;
            // 0x00D1CB44: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x00D1CB48: TBZ w8, #0, #0xd1cb5c      | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00D1CB4C: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x00D1CB50: CBNZ w8, #0xd1cb5c         | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00D1CB54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x00D1CB58: LDR x0, [x23]              | X0 = typeof(AstarPath);                 
            val_18 = null;
            label_3:
            // 0x00D1CB5C: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x00D1CB60: LDR s8, [x19, #0x148]      | S8 = this.startPoint; //P2              
            // 0x00D1CB64: LDR s9, [x19, #0x14c]      | 
            // 0x00D1CB68: LDR s10, [x19, #0x150]     | 
            // 0x00D1CB6C: LDR x20, [x19, #0xa8]      | 
            // 0x00D1CB70: LDR x22, [x8, #0x18]       | X22 = AstarPath.active;                 
            // 0x00D1CB74: LDR x21, [x19, #0x120]     | X21 = this.startHint; //P2              
            // 0x00D1CB78: CBNZ x22, #0xd1cb80        | if (AstarPath.active != null) goto label_4;
            if(AstarPath.active != null)
            {
                goto label_4;
            }
            // 0x00D1CB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_4:
            // 0x00D1CB80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00D1CB84: ADD x8, sp, #0x10          | X8 = (1152921513505914048 + 16) = 1152921513505914064 (0x10000002126CFCD0);
            // 0x00D1CB88: MOV x0, x22                | X0 = AstarPath.active;//m1              
            // 0x00D1CB8C: MOV v0.16b, v8.16b         | V0 = this.startPoint;//m1               
            // 0x00D1CB90: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
            // 0x00D1CB94: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
            // 0x00D1CB98: MOV x1, x20                | X1 = 57884672 (0x3734000);//ML01        
            // 0x00D1CB9C: MOV x2, x21                | X2 = this.startHint;//m1                
            // 0x00D1CBA0: BL #0xb40790               | X0 = AstarPath.active.GetNearest(position:  new UnityEngine.Vector3() {x = this.startPoint, y = V9.16B, z = V10.16B}, constraint:  static_value_03734000, hint:  this.startHint);
            Pathfinding.NNInfo val_1 = AstarPath.active.GetNearest(position:  new UnityEngine.Vector3() {x = this.startPoint, y = V9.16B, z = V10.16B}, constraint:  static_value_03734000, hint:  this.startHint);
            // 0x00D1CBA4: LDR x20, [sp, #0x10]       | X20 = val_2;                             //  find_add[1152921513505902208]
            val_19 = val_2;
            // 0x00D1CBA8: LDP w21, w22, [sp, #0x20]  | W21 = val_3; W22 = val_4;                //  find_add[1152921513505902208] |  find_add[1152921513505902208]
            val_20 = val_3;
            // 0x00D1CBAC: LDR s8, [sp, #0x28]        | S8 = val_5;                              //  find_add[1152921513505902208]
            val_21 = val_5;
            // 0x00D1CBB0: LDR x0, [x19, #0xa8]       | 
            // 0x00D1CBB4: CBZ x0, #0xd1cbfc          | if (AstarPath.active == null) goto label_7;
            if(AstarPath.active == null)
            {
                goto label_7;
            }
            // 0x00D1CBB8: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00D1CBBC: LDR x8, [x8, #0x838]       | X8 = 1152921504836239360;               
            // 0x00D1CBC0: LDR x9, [x0]               | X9 =  typeof(AstarPath);                
            // 0x00D1CBC4: LDR x8, [x8]               | X8 = typeof(Pathfinding.PathNNConstraint);
            // 0x00D1CBC8: LDRB w11, [x9, #0x104]     | W11 = AstarPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00D1CBCC: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.PathNNConstraint.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00D1CBD0: CMP w11, w10               | STATE = COMPARE(AstarPath.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.PathNNConstraint.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00D1CBD4: B.LO #0xd1cbfc             | if (AstarPath.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.PathNNConstraint.__il2cppRuntimeField_typeHierarchyDepth) goto label_7;
            // 0x00D1CBD8: LDR x9, [x9, #0xb0]        | X9 = AstarPath.__il2cppRuntimeField_typeHierarchy;
            // 0x00D1CBDC: ADD x9, x9, x10, lsl #3    | X9 = (AstarPath.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PathNNConstraint.__il2cppRuntimeFi
            // 0x00D1CBE0: LDUR x9, [x9, #-8]         | X9 = (AstarPath.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PathNNConstraint.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            val_22 = (AstarPath.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PathNNConstraint.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00D1CBE4: CMP x9, x8                 | STATE = COMPARE((AstarPath.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PathNNConstraint.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.PathNNConstraint))
            // 0x00D1CBE8: B.NE #0xd1cbfc             | if (val_22 != null) goto label_7;       
            if(val_22 != null)
            {
                goto label_7;
            }
            // 0x00D1CBEC: LDR x8, [x0]               | X8 =  typeof(AstarPath);                
            // 0x00D1CBF0: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00D1CBF4: LDP x9, x2, [x8, #0x170]   | X9 = typeof(AstarPath).__il2cppRuntimeField_170; X2 = typeof(AstarPath).__il2cppRuntimeField_178; //  | 
            // 0x00D1CBF8: BLR x9                     | X0 = typeof(AstarPath).__il2cppRuntimeField_170();
            label_7:
            // 0x00D1CBFC: STR s8, [x19, #0x150]      | mem[1152921513505926544] = val_5;        //  dest_result_addr=1152921513505926544
            mem[1152921513505926544] = val_21;
            // 0x00D1CC00: ADRP x24, #0x3660000       | X24 = 57016320 (0x3660000);             
            // 0x00D1CC04: STR w21, [x19, #0x148]     | this.startPoint = val_3;                 //  dest_result_addr=1152921513505926536
            this.startPoint = val_20;
            // 0x00D1CC08: STR w22, [x19, #0x14c]     | mem[1152921513505926540] = val_4;        //  dest_result_addr=1152921513505926540
            mem[1152921513505926540] = val_4;
            // 0x00D1CC0C: LDR x24, [x24, #0x540]     | X24 = 1152921504839380992;              
            // 0x00D1CC10: FMOV s10, w21              | S10 = (val_3);                          
            val_23 = val_20;
            // 0x00D1CC14: FMOV s9, w22               | S9 = (val_4);                           
            // 0x00D1CC18: LDR x0, [x24]              | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1CC1C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1CC20: TBZ w8, #0, #0xd1cc30      | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00D1CC24: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1CC28: CBNZ w8, #0xd1cc30         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00D1CC2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_9:
            // 0x00D1CC30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CC34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CC38: MOV v0.16b, v10.16b        | V0 = val_3;//m1                         
            // 0x00D1CC3C: MOV v1.16b, v9.16b         | V1 = val_4;//m1                         
            // 0x00D1CC40: MOV v2.16b, v8.16b         | V2 = val_5;//m1                         
            // 0x00D1CC44: BL #0x1548f50              | X0 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = val_23, y = val_4, z = val_21});
            Pathfinding.Int3 val_6 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = val_23, y = val_4, z = val_21});
            // 0x00D1CC48: ADD x8, x19, #0x164        | X8 = this.startIntPoint;//AP2 res_addr=1152921513505926564
            // 0x00D1CC4C: STR x0, [x8]               | mem2[0] = val_6.x; mem[4] = val_6.y;     //  dest_result_addr=0 dest_result_addr=4
            mem2[0] = val_6.x;
            mem[4] = val_6.y;
            // 0x00D1CC50: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1CC54: STR w1, [x19, #0x16c]      | mem[1152921513505926572] = val_6.z;      //  dest_result_addr=1152921513505926572
            mem[1152921513505926572] = val_6.z;
            // 0x00D1CC58: STR x20, [x19, #0x110]     | this.startNode = val_2;                  //  dest_result_addr=1152921513505926480
            this.startNode = val_19;
            // 0x00D1CC5C: CBZ w8, #0xd1cd28          | if (this.hasEndPoint == false) goto label_10;
            if(this.hasEndPoint == false)
            {
                goto label_10;
            }
            // 0x00D1CC60: LDR x0, [x23]              | X0 = typeof(AstarPath);                 
            val_24 = null;
            // 0x00D1CC64: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x00D1CC68: TBZ w8, #0, #0xd1cc7c      | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00D1CC6C: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x00D1CC70: CBNZ w8, #0xd1cc7c         | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00D1CC74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x00D1CC78: LDR x0, [x23]              | X0 = typeof(AstarPath);                 
            val_24 = null;
            label_12:
            // 0x00D1CC7C: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x00D1CC80: LDR s8, [x19, #0x154]      | S8 = this.endPoint; //P2                
            // 0x00D1CC84: LDR s9, [x19, #0x158]      | 
            // 0x00D1CC88: LDR s10, [x19, #0x15c]     | 
            // 0x00D1CC8C: LDR x20, [x19, #0xa8]      | 
            // 0x00D1CC90: LDR x22, [x8, #0x18]       | X22 = AstarPath.active;                 
            // 0x00D1CC94: LDR x21, [x19, #0x128]     | X21 = this.endHint; //P2                
            // 0x00D1CC98: CBNZ x22, #0xd1cca0        | if (AstarPath.active != null) goto label_13;
            if(AstarPath.active != null)
            {
                goto label_13;
            }
            // 0x00D1CC9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_13:
            // 0x00D1CCA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00D1CCA4: ADD x8, sp, #0x10          | X8 = (1152921513505914048 + 16) = 1152921513505914064 (0x10000002126CFCD0);
            // 0x00D1CCA8: MOV x0, x22                | X0 = AstarPath.active;//m1              
            // 0x00D1CCAC: MOV v0.16b, v8.16b         | V0 = this.endPoint;//m1                 
            // 0x00D1CCB0: MOV v1.16b, v9.16b         | V1 = val_4;//m1                         
            // 0x00D1CCB4: MOV v2.16b, v10.16b        | V2 = val_3;//m1                         
            // 0x00D1CCB8: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00D1CCBC: MOV x2, x21                | X2 = this.endHint;//m1                  
            // 0x00D1CCC0: BL #0xb40790               | X0 = AstarPath.active.GetNearest(position:  new UnityEngine.Vector3() {x = this.endPoint, y = val_4, z = val_23}, constraint:  val_19, hint:  this.endHint);
            Pathfinding.NNInfo val_7 = AstarPath.active.GetNearest(position:  new UnityEngine.Vector3() {x = this.endPoint, y = val_4, z = val_23}, constraint:  val_19, hint:  this.endHint);
            // 0x00D1CCC4: LDP w8, w9, [sp, #0x20]    | W8 = val_3; W9 = val_4;                  //  find_add[1152921513505902208] |  find_add[1152921513505902208]
            // 0x00D1CCC8: LDR s8, [sp, #0x28]        | S8 = val_5;                              //  find_add[1152921513505902208]
            val_21 = val_5;
            // 0x00D1CCCC: LDR x21, [sp, #0x10]       | X21 = val_2;                             //  find_add[1152921513505902208]
            val_20 = val_2;
            // 0x00D1CCD0: STR w8, [x19, #0x154]      | this.endPoint = val_3;                   //  dest_result_addr=1152921513505926548
            this.endPoint = val_3;
            // 0x00D1CCD4: STR s8, [x19, #0x15c]      | mem[1152921513505926556] = val_5;        //  dest_result_addr=1152921513505926556
            mem[1152921513505926556] = val_21;
            // 0x00D1CCD8: STR w9, [x19, #0x158]      | mem[1152921513505926552] = val_4;        //  dest_result_addr=1152921513505926552
            mem[1152921513505926552] = val_4;
            // 0x00D1CCDC: LDR x0, [x24]              | X0 = typeof(Pathfinding.Int3);          
            // 0x00D1CCE0: FMOV s10, w8               | S10 = (val_3);                          
            val_23 = val_3;
            // 0x00D1CCE4: FMOV s9, w9                | S9 = (val_4);                           
            // 0x00D1CCE8: LDRB w10, [x0, #0x10a]     | W10 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x00D1CCEC: TBZ w10, #0, #0xd1ccfc     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00D1CCF0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1CCF4: CBNZ w8, #0xd1ccfc         | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00D1CCF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_15:
            // 0x00D1CCFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CD00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CD04: MOV v0.16b, v10.16b        | V0 = val_3;//m1                         
            // 0x00D1CD08: MOV v1.16b, v9.16b         | V1 = val_4;//m1                         
            // 0x00D1CD0C: MOV v2.16b, v8.16b         | V2 = val_5;//m1                         
            // 0x00D1CD10: BL #0x1548f50              | X0 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = val_23, y = val_4, z = val_21});
            Pathfinding.Int3 val_8 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = val_23, y = val_4, z = val_21});
            // 0x00D1CD14: LDR x20, [x19, #0x110]     | X20 = this.startNode; //P2              
            val_19 = this.startNode;
            // 0x00D1CD18: STR x0, [x19, #0xe0]       | mem[1152921513505926432] = val_8.x; mem[1152921513505926436] = val_8.y;  //  dest_result_addr=1152921513505926432 dest_result_addr=1152921513505926436
            mem[1152921513505926432] = val_8.x;
            mem[1152921513505926436] = val_8.y;
            // 0x00D1CD1C: STR w1, [x19, #0xe8]       | mem[1152921513505926440] = val_8.z;      //  dest_result_addr=1152921513505926440
            mem[1152921513505926440] = val_8.z;
            // 0x00D1CD20: STR x21, [x19, #0x118]     | this.endNode = val_2;                    //  dest_result_addr=1152921513505926488
            this.endNode = val_20;
            // 0x00D1CD24: STR x21, [x19, #0xd8]      | mem[1152921513505926424] = val_2;        //  dest_result_addr=1152921513505926424
            mem[1152921513505926424] = val_20;
            label_10:
            // 0x00D1CD28: CBZ x20, #0xd1d00c         | if (this.startNode == null) goto label_16;
            if(val_19 == null)
            {
                goto label_16;
            }
            // 0x00D1CD2C: LDR x8, [x19, #0x118]      | X8 = this.endNode; //P2                 
            // 0x00D1CD30: CBNZ x8, #0xd1cd54         | if (this.endNode != null) goto label_18;
            if(this.endNode != null)
            {
                goto label_18;
            }
            // 0x00D1CD34: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1CD38: CBZ w8, #0xd1cd54          | if (this.hasEndPoint == false) goto label_18;
            if(this.hasEndPoint == false)
            {
                goto label_18;
            }
            // 0x00D1CD3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CD40: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1CD44: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1CD48: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00D1CD4C: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921513505864192)("Couldn\'t find a close node to the end point");
            val_25 = "Couldn\'t find a close node to the end point";
            // 0x00D1CD50: B #0xd1d078                |  goto label_53;                         
            goto label_53;
            label_18:
            // 0x00D1CD54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CD58: MOV x0, x20                | X0 = this.startNode;//m1                
            // 0x00D1CD5C: BL #0x168e5f0              | X0 = this.startNode.get_Walkable();     
            bool val_9 = val_19.Walkable;
            // 0x00D1CD60: AND w8, w0, #1             | W8 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x00D1CD64: TBZ w8, #0, #0xd1d034      | if ((val_9 & 1) == false) goto label_20;
            if(val_10 == false)
            {
                goto label_20;
            }
            // 0x00D1CD68: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1CD6C: CBZ w8, #0xd1d088          | if (this.hasEndPoint == false) goto label_27;
            if(this.hasEndPoint == false)
            {
                goto label_27;
            }
            // 0x00D1CD70: LDR x20, [x19, #0x118]     | X20 = this.endNode; //P2                
            // 0x00D1CD74: CBNZ x20, #0xd1cd7c        | if (this.endNode != null) goto label_22;
            if(this.endNode != null)
            {
                goto label_22;
            }
            // 0x00D1CD78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_22:
            // 0x00D1CD7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CD80: MOV x0, x20                | X0 = this.endNode;//m1                  
            // 0x00D1CD84: BL #0x168e5f0              | X0 = this.endNode.get_Walkable();       
            bool val_11 = this.endNode.Walkable;
            // 0x00D1CD88: AND w8, w0, #1             | W8 = (val_11 & 1);                      
            bool val_12 = val_11;
            // 0x00D1CD8C: TBZ w8, #0, #0xd1d064      | if ((val_11 & 1) == false) goto label_23;
            if(val_12 == false)
            {
                goto label_23;
            }
            // 0x00D1CD90: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1CD94: CBZ w8, #0xd1d088          | if (this.hasEndPoint == false) goto label_27;
            if(this.hasEndPoint == false)
            {
                goto label_27;
            }
            // 0x00D1CD98: LDR x20, [x19, #0x110]     | X20 = this.startNode; //P2              
            // 0x00D1CD9C: CBNZ x20, #0xd1cda4        | if (this.startNode != null) goto label_25;
            if(this.startNode != null)
            {
                goto label_25;
            }
            // 0x00D1CDA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_25:
            // 0x00D1CDA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CDA8: MOV x0, x20                | X0 = this.startNode;//m1                
            // 0x00D1CDAC: BL #0x16947c8              | X0 = this.startNode.get_Area();         
            uint val_13 = this.startNode.Area;
            // 0x00D1CDB0: LDR x21, [x19, #0x118]     | X21 = this.endNode; //P2                
            val_20 = this.endNode;
            // 0x00D1CDB4: MOV w20, w0                | W20 = val_13;//m1                       
            // 0x00D1CDB8: CBNZ x21, #0xd1cdc0        | if (this.endNode != null) goto label_26;
            if(val_20 != null)
            {
                goto label_26;
            }
            // 0x00D1CDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_26:
            // 0x00D1CDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CDC4: MOV x0, x21                | X0 = this.endNode;//m1                  
            // 0x00D1CDC8: BL #0x16947c8              | X0 = this.endNode.get_Area();           
            uint val_14 = val_20.Area;
            // 0x00D1CDCC: CMP w20, w0                | STATE = COMPARE(val_13, val_14)         
            // 0x00D1CDD0: B.EQ #0xd1d088             | if (val_13 == val_14) goto label_27;    
            if(val_13 == val_14)
            {
                goto label_27;
            }
            // 0x00D1CDD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CDD8: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1CDDC: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1CDE0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00D1CDE4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00D1CDE8: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x00D1CDEC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00D1CDF0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00D1CDF4: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x00D1CDF8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00D1CDFC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00D1CE00: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00D1CE04: CBNZ x20, #0xd1ce0c        | if ( != null) goto label_28;            
            if(null != null)
            {
                goto label_28;
            }
            // 0x00D1CE08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_28:
            // 0x00D1CE0C: ADRP x21, #0x363c000       | X21 = 56868864 (0x363C000);             
            // 0x00D1CE10: LDR x21, [x21]             | X21 = (string**)(1152921513505876640)("There is no valid path to the target (start area: ");
            // 0x00D1CE14: LDR x0, [x21]              | X0 = "There is no valid path to the target (start area: ";
            // 0x00D1CE18: CBZ x0, #0xd1ce38          | if ("There is no valid path to the target (start area: " == null) goto label_30;
            // 0x00D1CE1C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00D1CE20: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00D1CE24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "There is no valid path to the target (start area: ", ????);
            // 0x00D1CE28: CBNZ x0, #0xd1ce38         | if ("There is no valid path to the target (start area: " != null) goto label_30;
            if(("There is no valid path to the target (start area: ") != null)
            {
                goto label_30;
            }
            // 0x00D1CE2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "There is no valid path to the target (start area: ", ????);
            // 0x00D1CE30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CE34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "There is no valid path to the target (start area: ", ????);
            label_30:
            // 0x00D1CE38: LDR x21, [x21]             | X21 = "There is no valid path to the target (start area: ";
            // 0x00D1CE3C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00D1CE40: CBNZ w8, #0xd1ce50         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_31;
            // 0x00D1CE44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "There is no valid path to the target (start area: ", ????);
            // 0x00D1CE48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CE4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "There is no valid path to the target (start area: ", ????);
            label_31:
            // 0x00D1CE50: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "There is no valid path to the target (start area: ";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "There is no valid path to the target (start area: ";
            // 0x00D1CE54: LDR x21, [x19, #0x110]     | X21 = this.startNode; //P2              
            // 0x00D1CE58: CBNZ x21, #0xd1ce60        | if (this.startNode != null) goto label_32;
            if(this.startNode != null)
            {
                goto label_32;
            }
            // 0x00D1CE5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "There is no valid path to the target (start area: ", ????);
            label_32:
            // 0x00D1CE60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CE64: MOV x0, x21                | X0 = this.startNode;//m1                
            // 0x00D1CE68: BL #0x16947c8              | X0 = this.startNode.get_Area();         
            uint val_15 = this.startNode.Area;
            // 0x00D1CE6C: ADRP x22, #0x35e2000       | X22 = 56500224 (0x35E2000);             
            // 0x00D1CE70: LDR x22, [x22, #0xe18]     | X22 = 1152921504607645696;              
            // 0x00D1CE74: STR w0, [sp, #0x10]        | val_2 = val_15;                          //  dest_result_addr=1152921513505914064
            val_2 = val_15;
            // 0x00D1CE78: ADD x1, sp, #0x10          | X1 = (1152921513505914048 + 16) = 1152921513505914064 (0x10000002126CFCD0);
            // 0x00D1CE7C: LDR x8, [x22]              | X8 = typeof(System.UInt32);             
            // 0x00D1CE80: MOV x0, x8                 | X0 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00D1CE84: BL #0x27bc028              | X0 = 1152921513506015552 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), val_15);
            // 0x00D1CE88: MOV x21, x0                | X21 = 1152921513506015552 (0x10000002126E8940);//ML01
            // 0x00D1CE8C: CBZ x21, #0xd1ceb0         | if (val_15 == 0) goto label_34;         
            if(val_2 == 0)
            {
                goto label_34;
            }
            // 0x00D1CE90: LDR x8, [x20]              | X8 = ;                                  
            // 0x00D1CE94: MOV x0, x21                | X0 = 1152921513506015552 (0x10000002126E8940);//ML01
            // 0x00D1CE98: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00D1CE9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x00D1CEA0: CBNZ x0, #0xd1ceb0         | if (val_15 != 0) goto label_34;         
            if(val_2 != 0)
            {
                goto label_34;
            }
            // 0x00D1CEA4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x00D1CEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CEAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_34:
            // 0x00D1CEB0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00D1CEB4: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00D1CEB8: B.HI #0xd1cec8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_35;
            // 0x00D1CEBC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x00D1CEC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CEC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_35:
            // 0x00D1CEC8: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_15; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;
            typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
            // 0x00D1CECC: ADRP x21, #0x3622000       | X21 = 56762368 (0x3622000);             
            // 0x00D1CED0: LDR x21, [x21, #0x30]      | X21 = (string**)(1152921513505885008)(", target area: ");
            // 0x00D1CED4: LDR x0, [x21]              | X0 = ", target area: ";                 
            // 0x00D1CED8: CBZ x0, #0xd1cef8          | if (", target area: " == null) goto label_37;
            // 0x00D1CEDC: LDR x8, [x20]              | X8 = ;                                  
            // 0x00D1CEE0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00D1CEE4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ", target area: ", ????);
            // 0x00D1CEE8: CBNZ x0, #0xd1cef8         | if (", target area: " != null) goto label_37;
            if((", target area: ") != null)
            {
                goto label_37;
            }
            // 0x00D1CEEC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ", target area: ", ????);
            // 0x00D1CEF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CEF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ", target area: ", ????);
            label_37:
            // 0x00D1CEF8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00D1CEFC: LDR x21, [x21]             | X21 = ", target area: ";                
            // 0x00D1CF00: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00D1CF04: B.HI #0xd1cf14             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_38;
            // 0x00D1CF08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ", target area: ", ????);
            // 0x00D1CF0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CF10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ", target area: ", ????);
            label_38:
            // 0x00D1CF14: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = ", target area: ";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = ", target area: ";
            // 0x00D1CF18: LDR x21, [x19, #0x118]     | X21 = this.endNode; //P2                
            // 0x00D1CF1C: CBNZ x21, #0xd1cf24        | if (this.endNode != null) goto label_39;
            if(this.endNode != null)
            {
                goto label_39;
            }
            // 0x00D1CF20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ", target area: ", ????);
            label_39:
            // 0x00D1CF24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CF28: MOV x0, x21                | X0 = this.endNode;//m1                  
            // 0x00D1CF2C: BL #0x16947c8              | X0 = this.endNode.get_Area();           
            uint val_16 = this.endNode.Area;
            // 0x00D1CF30: LDR x8, [x22]              | X8 = typeof(System.UInt32);             
            // 0x00D1CF34: STR w0, [sp, #0xc]         | stack[1152921513505914060] = val_16;     //  dest_result_addr=1152921513505914060
            // 0x00D1CF38: ADD x1, sp, #0xc           | X1 = (1152921513505914048 + 12) = 1152921513505914060 (0x10000002126CFCCC);
            // 0x00D1CF3C: MOV x0, x8                 | X0 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x00D1CF40: BL #0x27bc028              | X0 = 1152921513506023744 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), val_16);
            // 0x00D1CF44: MOV x21, x0                | X21 = 1152921513506023744 (0x10000002126EA940);//ML01
            // 0x00D1CF48: CBZ x21, #0xd1cf6c         | if (val_16 == 0) goto label_41;         
            if(val_16 == 0)
            {
                goto label_41;
            }
            // 0x00D1CF4C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00D1CF50: MOV x0, x21                | X0 = 1152921513506023744 (0x10000002126EA940);//ML01
            // 0x00D1CF54: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00D1CF58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x00D1CF5C: CBNZ x0, #0xd1cf6c         | if (val_16 != 0) goto label_41;         
            if(val_16 != 0)
            {
                goto label_41;
            }
            // 0x00D1CF60: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x00D1CF64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CF68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_41:
            // 0x00D1CF6C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00D1CF70: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00D1CF74: B.HI #0xd1cf84             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_42;
            // 0x00D1CF78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x00D1CF7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CF80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_42:
            // 0x00D1CF84: STR x21, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = val_16; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
            typeof(System.Object[]).__il2cppRuntimeField_38 = val_16;
            typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
            // 0x00D1CF88: ADRP x21, #0x366a000       | X21 = 57057280 (0x366A000);             
            // 0x00D1CF8C: LDR x21, [x21, #0x170]     | X21 = (string**)(1152921509409721808)(")");
            // 0x00D1CF90: LDR x0, [x21]              | X0 = ")";                               
            // 0x00D1CF94: CBZ x0, #0xd1cfb4          | if (")" == null) goto label_44;         
            // 0x00D1CF98: LDR x8, [x20]              | X8 = ;                                  
            // 0x00D1CF9C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00D1CFA0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ")", ????);        
            // 0x00D1CFA4: CBNZ x0, #0xd1cfb4         | if (")" != null) goto label_44;         
            if(")" != null)
            {
                goto label_44;
            }
            // 0x00D1CFA8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ")", ????);        
            // 0x00D1CFAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CFB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ")", ????);        
            label_44:
            // 0x00D1CFB4: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00D1CFB8: LDR x21, [x21]             | X21 = ")";                              
            val_20 = ")";
            // 0x00D1CFBC: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x00D1CFC0: B.HI #0xd1cfd0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_45;
            // 0x00D1CFC4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ")", ????);        
            // 0x00D1CFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1CFCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ")", ????);        
            label_45:
            // 0x00D1CFD0: STR x21, [x20, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = ")";  //  dest_result_addr=1152921504954501328
            typeof(System.Object[]).__il2cppRuntimeField_40 = val_20;
            // 0x00D1CFD4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00D1CFD8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00D1CFDC: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00D1CFE0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00D1CFE4: TBZ w8, #0, #0xd1cff4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x00D1CFE8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00D1CFEC: CBNZ w8, #0xd1cff4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x00D1CFF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_47:
            // 0x00D1CFF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1CFF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1CFFC: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00D1D000: BL #0x18b07f0              | X0 = System.String.Concat(args:  0);    
            string val_17 = System.String.Concat(args:  0);
            // 0x00D1D004: MOV x1, x0                 | X1 = val_17;//m1                        
            val_26 = val_17;
            // 0x00D1D008: B #0xd1d07c                |  goto label_48;                         
            goto label_48;
            label_16:
            // 0x00D1D00C: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1D010: CBZ w8, #0xd1d01c          | if (this.hasEndPoint == false) goto label_49;
            if(this.hasEndPoint == false)
            {
                goto label_49;
            }
            // 0x00D1D014: LDR x8, [x19, #0x118]      | X8 = this.endNode; //P2                 
            // 0x00D1D018: CBZ x8, #0xd1d04c          | if (this.endNode == null) goto label_50;
            if(this.endNode == null)
            {
                goto label_50;
            }
            label_49:
            // 0x00D1D01C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D020: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1D024: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1D028: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00D1D02C: LDR x8, [x8, #0xb08]       | X8 = (string**)(1152921513505901504)("Couldn\'t find a close node to the start point");
            val_25 = "Couldn\'t find a close node to the start point";
            // 0x00D1D030: B #0xd1d078                |  goto label_53;                         
            goto label_53;
            label_20:
            // 0x00D1D034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D038: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1D03C: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1D040: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00D1D044: LDR x8, [x8, #0x928]       | X8 = (string**)(1152921513505901664)("The node closest to the start point is not walkable");
            val_25 = "The node closest to the start point is not walkable";
            // 0x00D1D048: B #0xd1d078                |  goto label_53;                         
            goto label_53;
            label_50:
            // 0x00D1D04C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D050: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1D054: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1D058: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x00D1D05C: LDR x8, [x8, #8]           | X8 = (string**)(1152921513505901840)("Couldn\'t find close nodes to the start point or the end point");
            val_25 = "Couldn\'t find close nodes to the start point or the end point";
            // 0x00D1D060: B #0xd1d078                |  goto label_53;                         
            goto label_53;
            label_23:
            // 0x00D1D064: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D068: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1D06C: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1D070: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00D1D074: LDR x8, [x8, #0x910]       | X8 = (string**)(1152921513505902032)("The node closest to the end point is not walkable");
            val_25 = "The node closest to the end point is not walkable";
            label_53:
            // 0x00D1D078: LDR x1, [x8]               | X1 = "The node closest to the end point is not walkable";
            label_48:
            // 0x00D1D07C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D080: MOV x0, x19                | X0 = 1152921513505926208 (0x10000002126D2C40);//ML01
            // 0x00D1D084: BL #0x140339c              | this.LogError(msg:  val_25 = "The node closest to the end point is not walkable");
            this.LogError(msg:  val_25);
            label_27:
            // 0x00D1D088: SUB sp, x29, #0x50         | SP = (1152921513505914192 - 80) = 1152921513505914112 (0x10000002126CFD00);
            // 0x00D1D08C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D090: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D094: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D098: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00D1D09C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x00D1D0A0: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
            // 0x00D1D0A4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1D0A8 (13750440), len: 768  VirtAddr: 0x00D1D0A8 RVA: 0x00D1D0A8 token: 100683589 methodIndex: 49693 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Initialize()
        {
            //
            // Disasemble & Code
            // 0x00D1D0A8: STP x22, x21, [sp, #-0x30]! | stack[1152921513506165600] = ???;  stack[1152921513506165608] = ???;  //  dest_result_addr=1152921513506165600 |  dest_result_addr=1152921513506165608
            // 0x00D1D0AC: STP x20, x19, [sp, #0x10]  | stack[1152921513506165616] = ???;  stack[1152921513506165624] = ???;  //  dest_result_addr=1152921513506165616 |  dest_result_addr=1152921513506165624
            // 0x00D1D0B0: STP x29, x30, [sp, #0x20]  | stack[1152921513506165632] = ???;  stack[1152921513506165640] = ???;  //  dest_result_addr=1152921513506165632 |  dest_result_addr=1152921513506165640
            // 0x00D1D0B4: ADD x29, sp, #0x20         | X29 = (1152921513506165600 + 32) = 1152921513506165632 (0x100000021270D380);
            // 0x00D1D0B8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1D0BC: LDRB w8, [x20, #0x2d7]     | W8 = (bool)static_value_037342D7;       
            // 0x00D1D0C0: MOV x19, x0                | X19 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D0C4: TBNZ w8, #0, #0xd1d0e0     | if (static_value_037342D7 == true) goto label_0;
            // 0x00D1D0C8: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00D1D0CC: LDR x8, [x8, #0x108]       | X8 = 0x2B8A77C;                         
            // 0x00D1D0D0: LDR w0, [x8]               | W0 = 0x9D;                              
            // 0x00D1D0D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x9D, ????);       
            // 0x00D1D0D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1D0DC: STRB w8, [x20, #0x2d7]     | static_value_037342D7 = true;            //  dest_result_addr=57885399
            label_0:
            // 0x00D1D0E0: LDR x20, [x19, #0x110]     | X20 = this.startNode; //P2              
            // 0x00D1D0E4: CBZ x20, #0xd1d120         | if (this.startNode == null) goto label_1;
            if(this.startNode == null)
            {
                goto label_1;
            }
            // 0x00D1D0E8: LDR x21, [x19, #0x18]      | 
            // 0x00D1D0EC: CBNZ x21, #0xd1d0f4        | if (X21 != 0) goto label_2;             
            if(X21 != 0)
            {
                goto label_2;
            }
            // 0x00D1D0F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9D, ????);       
            label_2:
            // 0x00D1D0F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D0F8: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1D0FC: MOV x1, x20                | X1 = this.startNode;//m1                
            // 0x00D1D100: BL #0x140535c              | X0 = X21.GetPathNode(node:  this.startNode);
            Pathfinding.PathNode val_1 = X21.GetPathNode(node:  this.startNode);
            // 0x00D1D104: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00D1D108: CBNZ x20, #0xd1d110        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00D1D10C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00D1D110: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D114: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00D1D118: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00D1D11C: BL #0x1405c48              | val_1.set_flag2(value:  true);          
            val_1.flag2 = true;
            label_1:
            // 0x00D1D120: LDR x20, [x19, #0x118]     | X20 = this.endNode; //P2                
            // 0x00D1D124: CBZ x20, #0xd1d160         | if (this.endNode == null) goto label_4; 
            if(this.endNode == null)
            {
                goto label_4;
            }
            // 0x00D1D128: LDR x21, [x19, #0x18]      | 
            // 0x00D1D12C: CBNZ x21, #0xd1d134        | if (X21 != 0) goto label_5;             
            if(X21 != 0)
            {
                goto label_5;
            }
            // 0x00D1D130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00D1D134: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D138: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1D13C: MOV x1, x20                | X1 = this.endNode;//m1                  
            // 0x00D1D140: BL #0x140535c              | X0 = X21.GetPathNode(node:  this.endNode);
            Pathfinding.PathNode val_2 = X21.GetPathNode(node:  this.endNode);
            // 0x00D1D144: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00D1D148: CBNZ x20, #0xd1d150        | if (val_2 != null) goto label_6;        
            if(val_2 != null)
            {
                goto label_6;
            }
            // 0x00D1D14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00D1D150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D154: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00D1D158: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00D1D15C: BL #0x1405c48              | val_2.set_flag2(value:  true);          
            val_2.flag2 = true;
            label_4:
            // 0x00D1D160: LDR x20, [x19, #0x110]     | X20 = this.startNode; //P2              
            // 0x00D1D164: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1D168: CBZ w8, #0xd1d178          | if (this.hasEndPoint == false) goto label_7;
            if(this.hasEndPoint == false)
            {
                goto label_7;
            }
            // 0x00D1D16C: LDR x8, [x19, #0x118]      | X8 = this.endNode; //P2                 
            // 0x00D1D170: CMP x20, x8                | STATE = COMPARE(this.startNode, this.endNode)
            // 0x00D1D174: B.EQ #0xd1d2c8             | if (this.startNode == this.endNode) goto label_8;
            if(this.startNode == this.endNode)
            {
                goto label_8;
            }
            label_7:
            // 0x00D1D178: LDR x21, [x19, #0x18]      | 
            // 0x00D1D17C: CBNZ x21, #0xd1d184        | if (X21 != 0) goto label_9;             
            if(X21 != 0)
            {
                goto label_9;
            }
            // 0x00D1D180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x00D1D184: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D188: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1D18C: MOV x1, x20                | X1 = this.startNode;//m1                
            // 0x00D1D190: BL #0x140535c              | X0 = X21.GetPathNode(node:  this.startNode);
            Pathfinding.PathNode val_3 = X21.GetPathNode(node:  this.startNode);
            // 0x00D1D194: LDR x21, [x19, #0x110]     | X21 = this.startNode; //P2              
            // 0x00D1D198: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00D1D19C: CBNZ x20, #0xd1d1a4        | if (val_3 != null) goto label_10;       
            if(val_3 != null)
            {
                goto label_10;
            }
            // 0x00D1D1A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x00D1D1A4: STR x21, [x20, #0x10]      | val_3.node = this.startNode;             //  dest_result_addr=0
            val_3.node = this.startNode;
            // 0x00D1D1A8: LDR x21, [x19, #0x18]      | 
            // 0x00D1D1AC: CBNZ x21, #0xd1d1b4        | if (this.startNode != null) goto label_11;
            if(this.startNode != null)
            {
                goto label_11;
            }
            // 0x00D1D1B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_11:
            // 0x00D1D1B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D1B8: MOV x0, x21                | X0 = this.startNode;//m1                
            // 0x00D1D1BC: BL #0x1404d14              | X0 = this.startNode.get_PathID();       
            ushort val_4 = this.startNode.PathID;
            // 0x00D1D1C0: STRH w0, [x20, #0x20]      | val_3.pathID = val_4;                    //  dest_result_addr=0
            val_3.pathID = val_4;
            // 0x00D1D1C4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1D1C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D1CC: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00D1D1D0: STR xzr, [x20, #0x18]      | val_3.parent = null;                     //  dest_result_addr=0
            val_3.parent = 0;
            // 0x00D1D1D4: BL #0x1405bd4              | val_3.set_cost(value:  0);              
            val_3.cost = 0;
            // 0x00D1D1D8: LDR x1, [x19, #0x110]      | X1 = this.startNode; //P2               
            // 0x00D1D1DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D1E0: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D1E4: BL #0x1403274              | X0 = this.GetTraversalCost(node:  this.startNode);
            uint val_5 = this.GetTraversalCost(node:  this.startNode);
            // 0x00D1D1E8: MOV w1, w0                 | W1 = val_5;//m1                         
            // 0x00D1D1EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D1F0: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00D1D1F4: BL #0x1405c98              | val_3.set_G(value:  val_5);             
            val_3.G = val_5;
            // 0x00D1D1F8: LDR x1, [x19, #0x110]      | X1 = this.startNode; //P2               
            // 0x00D1D1FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D200: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D204: BL #0x1402e98              | X0 = this.CalculateHScore(node:  this.startNode);
            uint val_6 = this.CalculateHScore(node:  this.startNode);
            // 0x00D1D208: MOV w1, w0                 | W1 = val_6;//m1                         
            // 0x00D1D20C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D210: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00D1D214: BL #0x1405ca8              | val_3.set_H(value:  val_6);             
            val_3.H = val_6;
            // 0x00D1D218: LDR x22, [x19, #0x110]     | X22 = this.startNode; //P2              
            // 0x00D1D21C: LDR x21, [x19, #0x18]      | 
            // 0x00D1D220: CBNZ x22, #0xd1d228        | if (this.startNode != null) goto label_12;
            if(this.startNode != null)
            {
                goto label_12;
            }
            // 0x00D1D224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_12:
            // 0x00D1D228: LDR x8, [x22]              | X8 = typeof(Pathfinding.GraphNode);     
            // 0x00D1D22C: MOV x0, x22                | X0 = this.startNode;//m1                
            // 0x00D1D230: MOV x1, x19                | X1 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D234: MOV x2, x20                | X2 = val_3;//m1                         
            // 0x00D1D238: LDP x9, x4, [x8, #0x1e0]   | X9 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E0; X4 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E8; //  | 
            // 0x00D1D23C: MOV x3, x21                | X3 = this.startNode;//m1                
            // 0x00D1D240: BLR x9                     | X0 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E0();
            // 0x00D1D244: LDR w8, [x19, #0x88]       | 
            // 0x00D1D248: LDR x21, [x19, #0x18]      | 
            // 0x00D1D24C: STR x20, [x19, #0x178]     | this.partialBestTarget = val_3;          //  dest_result_addr=1152921513506178024
            this.partialBestTarget = val_3;
            // 0x00D1D250: ADD w8, w8, #1             |  //  not_find_field:typeof(Pathfinding.GraphNode).1
            // 0x00D1D254: STR w8, [x19, #0x88]       | mem[1152921513506177784] = typeof(Pathfinding.GraphNode);  //  dest_result_addr=1152921513506177784
            mem[1152921513506177784] = null;
            // 0x00D1D258: CBNZ x21, #0xd1d260        | if (this.startNode != null) goto label_13;
            if(this.startNode != null)
            {
                goto label_13;
            }
            // 0x00D1D25C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.startNode, ????);
            label_13:
            // 0x00D1D260: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D264: MOV x0, x21                | X0 = this.startNode;//m1                
            // 0x00D1D268: BL #0x14052ec              | X0 = this.startNode.HeapEmpty();        
            bool val_7 = this.startNode.HeapEmpty();
            // 0x00D1D26C: TBZ w0, #0, #0xd1d29c      | if (val_7 == false) goto label_14;      
            if(val_7 == false)
            {
                goto label_14;
            }
            // 0x00D1D270: LDRB w8, [x19, #0x170]     | W8 = this.calculatePartial; //P2        
            // 0x00D1D274: CBZ w8, #0xd1d308          | if (this.calculatePartial == false) goto label_15;
            if(this.calculatePartial == false)
            {
                goto label_15;
            }
            // 0x00D1D278: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D27C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00D1D280: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D284: BL #0x1402bf8              | this.set_CompleteState(value:  3);      
            this.CompleteState = 3;
            // 0x00D1D288: LDR x8, [x19]              | X8 = typeof(Pathfinding.ABPath);        
            // 0x00D1D28C: LDR x1, [x19, #0x178]      | X1 = this.partialBestTarget; //P2       
            // 0x00D1D290: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D294: LDP x9, x2, [x8, #0x1a0]   | X9 = System.Void Pathfinding.Path::Trace(Pathfinding.PathNode from); X2 = System.Void Pathfinding.Path::Trace(Pathfinding.PathNode from); //  | 
            // 0x00D1D298: BLR x9                     | this.Trace(from:  this.partialBestTarget);
            this.Trace(from:  this.partialBestTarget);
            label_14:
            // 0x00D1D29C: LDR x20, [x19, #0x18]      | 
            // 0x00D1D2A0: CBNZ x20, #0xd1d2a8        | if (val_3 != null) goto label_16;       
            if(val_3 != null)
            {
                goto label_16;
            }
            // 0x00D1D2A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_16:
            // 0x00D1D2A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D2AC: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00D1D2B0: BL #0x140528c              | X0 = val_3.PopNode();                   
            Pathfinding.PathNode val_8 = val_3.PopNode();
            // 0x00D1D2B4: STR x0, [x19, #0x78]       | mem[1152921513506177768] = val_8;        //  dest_result_addr=1152921513506177768
            mem[1152921513506177768] = val_8;
            // 0x00D1D2B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D2BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D2C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D2C4: RET                        |  return;                                
            return;
            label_8:
            // 0x00D1D2C8: LDR x21, [x19, #0x18]      | 
            // 0x00D1D2CC: CBNZ x21, #0xd1d2d4        | if (X21 != 0) goto label_17;            
            if(X21 != 0)
            {
                goto label_17;
            }
            // 0x00D1D2D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_17:
            // 0x00D1D2D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D2D8: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1D2DC: MOV x1, x20                | X1 = this.startNode;//m1                
            // 0x00D1D2E0: BL #0x140535c              | X0 = X21.GetPathNode(node:  this.startNode);
            Pathfinding.PathNode val_9 = X21.GetPathNode(node:  this.startNode);
            // 0x00D1D2E4: LDR x21, [x19, #0x118]     | X21 = this.endNode; //P2                
            // 0x00D1D2E8: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00D1D2EC: CBZ x20, #0xd1d338         | if (val_9 == null) goto label_18;       
            if(val_9 == null)
            {
                goto label_18;
            }
            // 0x00D1D2F0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1D2F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D2F8: MOV x0, x20                | X0 = val_9;//m1                         
            // 0x00D1D2FC: STP x21, xzr, [x20, #0x10] | val_9.node = this.endNode;  val_9.parent = null;  //  dest_result_addr=0 |  dest_result_addr=0
            val_9.node = this.endNode;
            val_9.parent = 0;
            // 0x00D1D300: BL #0x1405ca8              | val_9.set_H(value:  0);                 
            val_9.H = 0;
            // 0x00D1D304: B #0xd1d368                |  goto label_19;                         
            goto label_19;
            label_15:
            // 0x00D1D308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D30C: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D310: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1D314: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00D1D318: LDR x8, [x8, #0x6b8]       | X8 = (string**)(1152921513506153472)("No open points, the start node didn\'t open any nodes");
            // 0x00D1D31C: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D324: LDR x1, [x8]               | X1 = "No open points, the start node didn\'t open any nodes";
            // 0x00D1D328: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D32C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D330: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D334: B #0x140339c               | this.LogError(msg:  "No open points, the start node didn\'t open any nodes"); return;
            this.LogError(msg:  "No open points, the start node didn\'t open any nodes");
            return;
            label_18:
            // 0x00D1D338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00D1D33C: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x00D1D340: STR x21, [x8]              | mem[16] = this.endNode;                  //  dest_result_addr=16
            mem[16] = this.endNode;
            // 0x00D1D344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00D1D348: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x00D1D34C: STR xzr, [x8]              | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = 0;
            // 0x00D1D350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00D1D354: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1D358: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1D35C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D360: BL #0x1405ca8              | 0.set_H(value:  0);                     
            0.H = 0;
            // 0x00D1D364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_19:
            // 0x00D1D368: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1D36C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D370: MOV x0, x20                | X0 = val_9;//m1                         
            // 0x00D1D374: BL #0x1405c98              | val_9.set_G(value:  0);                 
            val_9.G = 0;
            // 0x00D1D378: LDR x8, [x19]              | X8 = typeof(Pathfinding.ABPath);        
            // 0x00D1D37C: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D380: MOV x1, x20                | X1 = val_9;//m1                         
            // 0x00D1D384: LDP x9, x2, [x8, #0x1a0]   | X9 = System.Void Pathfinding.Path::Trace(Pathfinding.PathNode from); X2 = System.Void Pathfinding.Path::Trace(Pathfinding.PathNode from); //  | 
            // 0x00D1D388: BLR x9                     | this.Trace(from:  val_9);               
            this.Trace(from:  val_9);
            // 0x00D1D38C: MOV x0, x19                | X0 = 1152921513506177648 (0x1000000212710270);//ML01
            // 0x00D1D390: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D394: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D39C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00D1D3A0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D3A4: B #0x1402bf8               | this.set_CompleteState(value:  2); return;
            this.CompleteState = 2;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1D3A8 (13751208), len: 176  VirtAddr: 0x00D1D3A8 RVA: 0x00D1D3A8 token: 100683590 methodIndex: 49694 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Cleanup()
        {
            //
            // Disasemble & Code
            // 0x00D1D3A8: STP x22, x21, [sp, #-0x30]! | stack[1152921513506355424] = ???;  stack[1152921513506355432] = ???;  //  dest_result_addr=1152921513506355424 |  dest_result_addr=1152921513506355432
            // 0x00D1D3AC: STP x20, x19, [sp, #0x10]  | stack[1152921513506355440] = ???;  stack[1152921513506355448] = ???;  //  dest_result_addr=1152921513506355440 |  dest_result_addr=1152921513506355448
            // 0x00D1D3B0: STP x29, x30, [sp, #0x20]  | stack[1152921513506355456] = ???;  stack[1152921513506355464] = ???;  //  dest_result_addr=1152921513506355456 |  dest_result_addr=1152921513506355464
            // 0x00D1D3B4: ADD x29, sp, #0x20         | X29 = (1152921513506355424 + 32) = 1152921513506355456 (0x100000021273B900);
            // 0x00D1D3B8: MOV x19, x0                | X19 = 1152921513506367472 (0x100000021273E7F0);//ML01
            // 0x00D1D3BC: LDR x20, [x19, #0x110]     | X20 = this.startNode; //P2              
            // 0x00D1D3C0: CBZ x20, #0xd1d3fc         | if (this.startNode == null) goto label_0;
            if(this.startNode == null)
            {
                goto label_0;
            }
            // 0x00D1D3C4: LDR x21, [x19, #0x18]      | 
            // 0x00D1D3C8: CBNZ x21, #0xd1d3d0        | if (X21 != 0) goto label_1;             
            if(X21 != 0)
            {
                goto label_1;
            }
            // 0x00D1D3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00D1D3D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D3D4: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1D3D8: MOV x1, x20                | X1 = this.startNode;//m1                
            // 0x00D1D3DC: BL #0x140535c              | X0 = X21.GetPathNode(node:  this.startNode);
            Pathfinding.PathNode val_1 = X21.GetPathNode(node:  this.startNode);
            // 0x00D1D3E0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00D1D3E4: CBNZ x20, #0xd1d3ec        | if (val_1 != null) goto label_2;        
            if(val_1 != null)
            {
                goto label_2;
            }
            // 0x00D1D3E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00D1D3EC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1D3F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D3F4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00D1D3F8: BL #0x1405c48              | val_1.set_flag2(value:  false);         
            val_1.flag2 = false;
            label_0:
            // 0x00D1D3FC: LDR x20, [x19, #0x118]     | X20 = this.endNode; //P2                
            // 0x00D1D400: CBZ x20, #0xd1d448         | if (this.endNode == null) goto label_3; 
            if(this.endNode == null)
            {
                goto label_3;
            }
            // 0x00D1D404: LDR x19, [x19, #0x18]      | 
            // 0x00D1D408: CBNZ x19, #0xd1d410        | if (this != null) goto label_4;         
            if(this != null)
            {
                goto label_4;
            }
            // 0x00D1D40C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00D1D410: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D414: MOV x0, x19                | X0 = 1152921513506367472 (0x100000021273E7F0);//ML01
            // 0x00D1D418: MOV x1, x20                | X1 = this.endNode;//m1                  
            // 0x00D1D41C: BL #0x140535c              | X0 = this.GetPathNode(node:  this.endNode);
            Pathfinding.PathNode val_2 = this.GetPathNode(node:  this.endNode);
            // 0x00D1D420: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00D1D424: CBNZ x19, #0xd1d42c        | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00D1D428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x00D1D42C: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00D1D430: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D434: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D438: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1D43C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D440: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D444: B #0x1405c48               | val_2.set_flag2(value:  false); return; 
            val_2.flag2 = false;
            return;
            label_3:
            // 0x00D1D448: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D44C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D450: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D454: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1D458 (13751384), len: 688  VirtAddr: 0x00D1D458 RVA: 0x00D1D458 token: 100683591 methodIndex: 49695 delegateWrapperIndex: 0 methodInvoker: 0
        public override void CalculateStep(long targetTick)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            Pathfinding.PathNode val_16;
            // 0x00D1D458: STP x26, x25, [sp, #-0x50]! | stack[1152921513506521984] = ???;  stack[1152921513506521992] = ???;  //  dest_result_addr=1152921513506521984 |  dest_result_addr=1152921513506521992
            // 0x00D1D45C: STP x24, x23, [sp, #0x10]  | stack[1152921513506522000] = ???;  stack[1152921513506522008] = ???;  //  dest_result_addr=1152921513506522000 |  dest_result_addr=1152921513506522008
            // 0x00D1D460: STP x22, x21, [sp, #0x20]  | stack[1152921513506522016] = ???;  stack[1152921513506522024] = ???;  //  dest_result_addr=1152921513506522016 |  dest_result_addr=1152921513506522024
            // 0x00D1D464: STP x20, x19, [sp, #0x30]  | stack[1152921513506522032] = ???;  stack[1152921513506522040] = ???;  //  dest_result_addr=1152921513506522032 |  dest_result_addr=1152921513506522040
            // 0x00D1D468: STP x29, x30, [sp, #0x40]  | stack[1152921513506522048] = ???;  stack[1152921513506522056] = ???;  //  dest_result_addr=1152921513506522048 |  dest_result_addr=1152921513506522056
            // 0x00D1D46C: ADD x29, sp, #0x40         | X29 = (1152921513506521984 + 64) = 1152921513506522048 (0x10000002127643C0);
            // 0x00D1D470: SUB sp, sp, #0x10          | SP = (1152921513506521984 - 16) = 1152921513506521968 (0x1000000212764370);
            // 0x00D1D474: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00D1D478: LDRB w8, [x21, #0x2d8]     | W8 = (bool)static_value_037342D8;       
            // 0x00D1D47C: MOV x20, x1                | X20 = targetTick;//m1                   
            // 0x00D1D480: MOV x19, x0                | X19 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D484: TBNZ w8, #0, #0xd1d4a0     | if (static_value_037342D8 == true) goto label_0;
            // 0x00D1D488: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00D1D48C: LDR x8, [x8, #0x9d8]       | X8 = 0x2B8A768;                         
            // 0x00D1D490: LDR w0, [x8]               | W0 = 0x98;                              
            // 0x00D1D494: BL #0x2782188              | X0 = sub_2782188( ?? 0x98, ????);       
            // 0x00D1D498: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            bool val_11 = true;
            // 0x00D1D49C: STRB w8, [x21, #0x2d8]     | static_value_037342D8 = true;            //  dest_result_addr=57885400
            label_0:
            // 0x00D1D4A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D4A4: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D4A8: STP xzr, xzr, [sp]         | stack[1152921513506521968] = 0x0;  stack[1152921513506521976] = 0x0;  //  dest_result_addr=1152921513506521968 |  dest_result_addr=1152921513506521976
            // 0x00D1D4AC: BL #0x1402bf0              | X0 = this.get_CompleteState();          
            PathCompleteState val_1 = this.CompleteState;
            // 0x00D1D4B0: CBNZ w0, #0xd1d62c         | if (val_1 != 0) goto label_19;          
            if(val_1 != 0)
            {
                goto label_19;
            }
            // 0x00D1D4B4: ADRP x24, #0x364f000       | X24 = 56946688 (0x364F000);             
            // 0x00D1D4B8: LDR x24, [x24, #0x9e0]     | X24 = 1152921504652693504;              
            // 0x00D1D4BC: MOVZ w25, #0xf, lsl #16    | W25 = 983040 (0xF0000);//ML01           
            // 0x00D1D4C0: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00D1D4C4: MOVK w25, #0x4241          | W25 = 1000001 (0xF4241);                
            label_18:
            // 0x00D1D4C8: LDR w8, [x19, #0x88]       | 
            // 0x00D1D4CC: LDR x21, [x19, #0x78]      | 
            // 0x00D1D4D0: ADD w8, w8, #1             | W8 = (true + 1);                        
            val_11 = val_11 + 1;
            // 0x00D1D4D4: STR w8, [x19, #0x88]       | mem[1152921513506534200] = (true + 1);   //  dest_result_addr=1152921513506534200
            mem[1152921513506534200] = val_11;
            // 0x00D1D4D8: CBNZ x21, #0xd1d4e0        | if ( != 0) goto label_2;                
            if(!=0)
            {
                goto label_2;
            }
            // 0x00D1D4DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00D1D4E0: LDR x8, [x21, #0x10]       | X8 = (bool)static_value_03734010;       
            // 0x00D1D4E4: LDR x9, [x19, #0x118]      | X9 = this.endNode; //P2                 
            // 0x00D1D4E8: CMP x8, x9                 | STATE = COMPARE(static_value_03734010, this.endNode)
            // 0x00D1D4EC: B.EQ #0xd1d61c             | if (static_value_03734010 == this.endNode) goto label_3;
            // 0x00D1D4F0: LDR x21, [x19, #0x78]      | 
            // 0x00D1D4F4: CBNZ x21, #0xd1d4fc        | if ( != 0) goto label_4;                
            if(!=0)
            {
                goto label_4;
            }
            // 0x00D1D4F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00D1D4FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D500: MOV x0, x21                | X0 = 57884672 (0x3734000);//ML01        
            // 0x00D1D504: BL #0x1405ca0              | X0 = get_H();                           
            uint val_2 = H;
            // 0x00D1D508: LDR x22, [x19, #0x178]     | X22 = this.partialBestTarget; //P2      
            // 0x00D1D50C: MOV w21, w0                | W21 = val_2;//m1                        
            // 0x00D1D510: CBNZ x22, #0xd1d518        | if (this.partialBestTarget != null) goto label_5;
            if(this.partialBestTarget != null)
            {
                goto label_5;
            }
            // 0x00D1D514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x00D1D518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D51C: MOV x0, x22                | X0 = this.partialBestTarget;//m1        
            // 0x00D1D520: BL #0x1405ca0              | X0 = this.partialBestTarget.get_H();    
            uint val_3 = this.partialBestTarget.H;
            // 0x00D1D524: CMP w21, w0                | STATE = COMPARE(val_2, val_3)           
            // 0x00D1D528: B.HS #0xd1d538             | if (val_2 >= val_3) goto label_6;       
            if(val_2 >= val_3)
            {
                goto label_6;
            }
            // 0x00D1D52C: LDR x22, [x19, #0x78]      | 
            // 0x00D1D530: STR x22, [x19, #0x178]     | this.partialBestTarget = this.partialBestTarget;  //  dest_result_addr=1152921513506534440
            this.partialBestTarget = this.partialBestTarget;
            // 0x00D1D534: B #0xd1d53c                |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x00D1D538: LDR x22, [x19, #0x78]      | 
            label_7:
            // 0x00D1D53C: MOV x21, x22               | X21 = this.partialBestTarget;//m1       
            val_14 = this.partialBestTarget;
            // 0x00D1D540: CBNZ x22, #0xd1d54c        | if (this.partialBestTarget != null) goto label_8;
            if(this.partialBestTarget != null)
            {
                goto label_8;
            }
            // 0x00D1D544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x00D1D548: LDR x21, [x19, #0x78]      | 
            label_8:
            // 0x00D1D54C: LDR x23, [x22, #0x10]      | X23 = this.partialBestTarget.node; //P2 
            // 0x00D1D550: LDR x22, [x19, #0x18]      | 
            // 0x00D1D554: CBNZ x23, #0xd1d55c        | if (this.partialBestTarget.node != null) goto label_9;
            if(this.partialBestTarget.node != null)
            {
                goto label_9;
            }
            // 0x00D1D558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x00D1D55C: LDR x8, [x23]              | X8 = typeof(Pathfinding.GraphNode);     
            // 0x00D1D560: MOV x0, x23                | X0 = this.partialBestTarget.node;//m1   
            // 0x00D1D564: MOV x1, x19                | X1 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D568: MOV x2, x21                | X2 = this.partialBestTarget;//m1        
            // 0x00D1D56C: LDP x9, x4, [x8, #0x1e0]   | X9 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E0; X4 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E8; //  | 
            // 0x00D1D570: MOV x3, x22                | X3 = this.partialBestTarget;//m1        
            // 0x00D1D574: BLR x9                     | X0 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E0();
            // 0x00D1D578: LDR x21, [x19, #0x18]      | 
            // 0x00D1D57C: CBNZ x21, #0xd1d584        | if (this.partialBestTarget != null) goto label_10;
            if(val_14 != null)
            {
                goto label_10;
            }
            // 0x00D1D580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.partialBestTarget.node, ????);
            label_10:
            // 0x00D1D584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D588: MOV x0, x21                | X0 = this.partialBestTarget;//m1        
            // 0x00D1D58C: BL #0x14052ec              | X0 = this.partialBestTarget.HeapEmpty();
            bool val_4 = val_14.HeapEmpty();
            // 0x00D1D590: TBNZ w0, #0, #0xd1d6a0     | if (val_4 == true) goto label_11;       
            if(val_4 == true)
            {
                goto label_11;
            }
            // 0x00D1D594: LDR x21, [x19, #0x18]      | 
            // 0x00D1D598: CBNZ x21, #0xd1d5a0        | if (this.partialBestTarget != null) goto label_12;
            if(val_14 != null)
            {
                goto label_12;
            }
            // 0x00D1D59C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x00D1D5A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D5A4: MOV x0, x21                | X0 = this.partialBestTarget;//m1        
            // 0x00D1D5A8: BL #0x140528c              | X0 = this.partialBestTarget.PopNode();  
            Pathfinding.PathNode val_5 = val_14.PopNode();
            // 0x00D1D5AC: STR x0, [x19, #0x78]       | mem[1152921513506534184] = val_5;        //  dest_result_addr=1152921513506534184
            mem[1152921513506534184] = val_5;
            // 0x00D1D5B0: CMP w26, #0x1f5            | STATE = COMPARE(0x0, 0x1F5)             
            // 0x00D1D5B4: B.LT #0xd1d604             | if (val_12 < 0x1F5) goto label_13;      
            if(val_12 < 501)
            {
                goto label_13;
            }
            // 0x00D1D5B8: LDR x0, [x24]              | X0 = typeof(System.DateTime);           
            // 0x00D1D5BC: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00D1D5C0: TBZ w8, #0, #0xd1d5d0      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00D1D5C4: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00D1D5C8: CBNZ w8, #0xd1d5d0         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00D1D5CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_15:
            // 0x00D1D5D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1D5D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D5D8: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
            System.DateTime val_6 = System.DateTime.UtcNow;
            // 0x00D1D5DC: STP x0, x1, [sp]           | stack[1152921513506521968] = val_6.ticks._ticks;  stack[1152921513506521976] = val_6.kind;  //  dest_result_addr=1152921513506521968 |  dest_result_addr=1152921513506521976
            // 0x00D1D5E0: MOV x0, sp                 | X0 = 1152921513506521968 (0x1000000212764370);//ML01
            // 0x00D1D5E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D5E8: BL #0x1bacf30              | X0 = val_6.ticks._ticks.get_Ticks();    
            long val_7 = val_6.ticks._ticks.Ticks;
            // 0x00D1D5EC: CMP x0, x20                | STATE = COMPARE(val_7, targetTick)      
            // 0x00D1D5F0: B.GE #0xd1d684             | if (val_7 >= targetTick) goto label_24; 
            if(val_7 >= targetTick)
            {
                goto label_24;
            }
            // 0x00D1D5F4: LDR w8, [x19, #0x88]       | 
            // 0x00D1D5F8: CMP w8, w25                | STATE = COMPARE(System.DateTime.__il2cppRuntimeField_cctor_finished, 0xF4241)
            // 0x00D1D5FC: B.GE #0xd1d6c8             | if (System.DateTime.__il2cppRuntimeField_cctor_finished >= 0xF4241) goto label_17;
            // 0x00D1D600: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_13:
            // 0x00D1D604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D608: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D60C: ADD w26, w26, #1           | W26 = (val_12 + 1);                     
            val_12 = val_12 + 1;
            // 0x00D1D610: BL #0x1402bf0              | X0 = this.get_CompleteState();          
            PathCompleteState val_8 = this.CompleteState;
            // 0x00D1D614: CBZ w0, #0xd1d4c8          | if (val_8 == 0) goto label_18;          
            if(val_8 == 0)
            {
                goto label_18;
            }
            // 0x00D1D618: B #0xd1d62c                |  goto label_19;                         
            goto label_19;
            label_3:
            // 0x00D1D61C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D620: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00D1D624: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D628: BL #0x1402bf8              | this.set_CompleteState(value:  2);      
            this.CompleteState = 2;
            label_19:
            // 0x00D1D62C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D630: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D634: BL #0x1402bf0              | X0 = this.get_CompleteState();          
            PathCompleteState val_9 = this.CompleteState;
            // 0x00D1D638: CMP w0, #2                 | STATE = COMPARE(val_9, 0x2)             
            // 0x00D1D63C: B.NE #0xd1d64c             | if (val_9 != 0x2) goto label_20;        
            if(val_9 != 2)
            {
                goto label_20;
            }
            // 0x00D1D640: LDR x8, [x19]              | X8 = typeof(Pathfinding.ABPath);        
            // 0x00D1D644: LDR x1, [x19, #0x78]       | 
            // 0x00D1D648: B #0xd1d674                |  goto label_21;                         
            goto label_21;
            label_20:
            // 0x00D1D64C: LDRB w8, [x19, #0x170]     | W8 = this.calculatePartial; //P2        
            // 0x00D1D650: CBZ w8, #0xd1d684          | if (this.calculatePartial == false) goto label_24;
            if(this.calculatePartial == false)
            {
                goto label_24;
            }
            // 0x00D1D654: LDR x8, [x19, #0x178]      | X8 = this.partialBestTarget; //P2       
            // 0x00D1D658: CBZ x8, #0xd1d684          | if (this.partialBestTarget == null) goto label_24;
            if(this.partialBestTarget == null)
            {
                goto label_24;
            }
            // 0x00D1D65C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D660: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00D1D664: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D668: BL #0x1402bf8              | this.set_CompleteState(value:  3);      
            this.CompleteState = 3;
            // 0x00D1D66C: LDR x8, [x19]              | X8 = typeof(Pathfinding.ABPath);        
            // 0x00D1D670: LDR x1, [x19, #0x178]      | X1 = this.partialBestTarget; //P2       
            val_16 = this.partialBestTarget;
            label_21:
            // 0x00D1D674: LDR x9, [x8, #0x1a0]       | X9 = System.Void Pathfinding.Path::Trace(Pathfinding.PathNode from);
            // 0x00D1D678: LDR x2, [x8, #0x1a8]       | X2 = System.Void Pathfinding.Path::Trace(Pathfinding.PathNode from);
            // 0x00D1D67C: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D680: BLR x9                     | this.Trace(from:  val_16 = this.partialBestTarget);
            this.Trace(from:  val_16);
            label_24:
            // 0x00D1D684: SUB sp, x29, #0x40         | SP = (1152921513506522048 - 64) = 1152921513506521984 (0x1000000212764380);
            // 0x00D1D688: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1D68C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1D690: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1D694: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00D1D698: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00D1D69C: RET                        |  return;                                
            return;
            label_11:
            // 0x00D1D6A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D6A4: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D6A8: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x00D1D6AC: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00D1D6B0: LDR x8, [x8, #0x8a8]       | X8 = (string**)(1152921513506508720)("No open points, whole area searched");
            // 0x00D1D6B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D6B8: MOV x0, x19                | X0 = 1152921513506534064 (0x10000002127672B0);//ML01
            // 0x00D1D6BC: LDR x1, [x8]               | X1 = "No open points, whole area searched";
            // 0x00D1D6C0: BL #0x140339c              | this.LogError(msg:  "No open points, whole area searched");
            this.LogError(msg:  "No open points, whole area searched");
            // 0x00D1D6C4: B #0xd1d684                |  goto label_24;                         
            goto label_24;
            label_17:
            // 0x00D1D6C8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00D1D6CC: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00D1D6D0: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_10 = null;
            // 0x00D1D6D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00D1D6D8: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00D1D6DC: LDR x8, [x8, #0xbc0]       | X8 = (string**)(1152921513506508864)("Probable infinite loop. Over 1,000,000 nodes searched");
            // 0x00D1D6E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D6E4: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00D1D6E8: LDR x1, [x8]               | X1 = "Probable infinite loop. Over 1,000,000 nodes searched";
            // 0x00D1D6EC: BL #0x1c32b48              | .ctor(message:  "Probable infinite loop. Over 1,000,000 nodes searched");
            val_10 = new System.Exception(message:  "Probable infinite loop. Over 1,000,000 nodes searched");
            // 0x00D1D6F0: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00D1D6F4: LDR x8, [x8, #0xd40]       | X8 = 1152921513506509040;               
            // 0x00D1D6F8: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00D1D6FC: LDR x1, [x8]               | X1 = public System.Void Pathfinding.ABPath::CalculateStep(long targetTick);
            // 0x00D1D700: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00D1D704: BL #0xd1d708               | ResetCosts(p:  public System.Void Pathfinding.ABPath::CalculateStep(long targetTick));
            ResetCosts(p:  public System.Void Pathfinding.ABPath::CalculateStep(long targetTick));
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1D708 (13752072), len: 4  VirtAddr: 0x00D1D708 RVA: 0x00D1D708 token: 100683592 methodIndex: 49696 delegateWrapperIndex: 0 methodInvoker: 0
        public void ResetCosts(Pathfinding.Path p)
        {
            //
            // Disasemble & Code
            // 0x00D1D708: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1D70C (13752076), len: 1984  VirtAddr: 0x00D1D70C RVA: 0x00D1D70C token: 100683593 methodIndex: 49697 delegateWrapperIndex: 0 methodInvoker: 0
        public override string DebugString(PathLog logMode)
        {
            //
            // Disasemble & Code
            //  | 
            var val_65;
            //  | 
            var val_66;
            //  | 
            var val_67;
            //  | 
            string val_68;
            //  | 
            string val_69;
            //  | 
            var val_70;
            // 0x00D1D70C: STP x24, x23, [sp, #-0x40]! | stack[1152921513507004944] = ???;  stack[1152921513507004952] = ???;  //  dest_result_addr=1152921513507004944 |  dest_result_addr=1152921513507004952
            // 0x00D1D710: STP x22, x21, [sp, #0x10]  | stack[1152921513507004960] = ???;  stack[1152921513507004968] = ???;  //  dest_result_addr=1152921513507004960 |  dest_result_addr=1152921513507004968
            // 0x00D1D714: STP x20, x19, [sp, #0x20]  | stack[1152921513507004976] = ???;  stack[1152921513507004984] = ???;  //  dest_result_addr=1152921513507004976 |  dest_result_addr=1152921513507004984
            // 0x00D1D718: STP x29, x30, [sp, #0x30]  | stack[1152921513507004992] = ???;  stack[1152921513507005000] = ???;  //  dest_result_addr=1152921513507004992 |  dest_result_addr=1152921513507005000
            // 0x00D1D71C: ADD x29, sp, #0x30         | X29 = (1152921513507004944 + 48) = 1152921513507004992 (0x10000002127DA240);
            // 0x00D1D720: SUB sp, sp, #0x30          | SP = (1152921513507004944 - 48) = 1152921513507004896 (0x10000002127DA1E0);
            // 0x00D1D724: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1D728: LDRB w8, [x20, #0x2d9]     | W8 = (bool)static_value_037342D9;       
            // 0x00D1D72C: MOV w21, w1                | W21 = logMode;//m1                      
            val_65 = logMode;
            // 0x00D1D730: MOV x19, x0                | X19 = 1152921513507017008 (0x10000002127DD130);//ML01
            // 0x00D1D734: TBNZ w8, #0, #0xd1d750     | if (static_value_037342D9 == true) goto label_0;
            // 0x00D1D738: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00D1D73C: LDR x8, [x8, #0x648]       | X8 = 0x2B8A770;                         
            // 0x00D1D740: LDR w0, [x8]               | W0 = 0x9A;                              
            // 0x00D1D744: BL #0x2782188              | X0 = sub_2782188( ?? 0x9A, ????);       
            // 0x00D1D748: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1D74C: STRB w8, [x20, #0x2d9]     | static_value_037342D9 = true;            //  dest_result_addr=57885401
            label_0:
            // 0x00D1D750: STP wzr, wzr, [sp, #0x28]  | stack[1152921513507004936] = 0x0;  stack[1152921513507004940] = 0x0;  //  dest_result_addr=1152921513507004936 |  dest_result_addr=1152921513507004940
            // 0x00D1D754: STR xzr, [sp, #0x20]       | stack[1152921513507004928] = 0x0;        //  dest_result_addr=1152921513507004928
            // 0x00D1D758: STR wzr, [sp, #0x18]       | stack[1152921513507004920] = 0x0;        //  dest_result_addr=1152921513507004920
            // 0x00D1D75C: STR xzr, [sp, #0x10]       | stack[1152921513507004912] = 0x0;        //  dest_result_addr=1152921513507004912
            // 0x00D1D760: CBZ w21, #0xd1d780         | if (logMode == 0) goto label_1;         
            if(val_65 == 0)
            {
                goto label_1;
            }
            // 0x00D1D764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D768: MOV x0, x19                | X0 = 1152921513507017008 (0x10000002127DD130);//ML01
            // 0x00D1D76C: BL #0x1402c00              | X0 = this.get_error();                  
            bool val_1 = this.error;
            // 0x00D1D770: CMP w21, #4                | STATE = COMPARE(logMode, 0x4)           
            // 0x00D1D774: B.NE #0xd1d7b0             | if (val_65 != 0x4) goto label_3;        
            if(val_65 != 4)
            {
                goto label_3;
            }
            // 0x00D1D778: EOR w8, w0, #1             | W8 = (val_1 ^ 1);                       
            bool val_2 = val_1 ^ 1;
            // 0x00D1D77C: TBZ w8, #0, #0xd1d7b0      | if ((val_1 ^ 1) == false) goto label_3; 
            if(val_2 == false)
            {
                goto label_3;
            }
            label_1:
            // 0x00D1D780: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
            // 0x00D1D784: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
            val_66 = 1152921504608284672;
            // 0x00D1D788: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_67 = null;
            // 0x00D1D78C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00D1D790: TBZ w8, #0, #0xd1d7a4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00D1D794: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00D1D798: CBNZ w8, #0xd1d7a4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00D1D79C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00D1D7A0: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_67 = null;
            label_5:
            // 0x00D1D7A4: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00D1D7A8: LDR x0, [x8]               | X0 = System.String.Empty;               
            val_68 = System.String.Empty;
            // 0x00D1D7AC: B #0xd1deb4                |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x00D1D7B0: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00D1D7B4: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00D1D7B8: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_3 = null;
            // 0x00D1D7BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00D1D7C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D7C4: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D7C8: BL #0x1b5a30c              | .ctor();                                
            val_3 = new System.Text.StringBuilder();
            // 0x00D1D7CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D7D0: MOV x0, x19                | X0 = 1152921513507017008 (0x10000002127DD130);//ML01
            // 0x00D1D7D4: BL #0x1402c00              | X0 = this.get_error();                  
            bool val_4 = this.error;
            // 0x00D1D7D8: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00D1D7DC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x00D1D7E0: LDR x8, [x8, #0xf08]       | X8 = (string**)(1152921513239246304)("Path Failed : ");
            // 0x00D1D7E4: LDR x9, [x9, #0xf98]       | X9 = (string**)(1152921513239246400)("Path Completed : ");
            // 0x00D1D7E8: TST w0, #1                 | STATE = COMPARE(val_4, 0x1)             
            // 0x00D1D7EC: CSEL x8, x8, x9, ne        | X8 = val_4 != true ? "Path Failed : " : "Path Completed : ";
            string val_5 = (val_4 != true) ? ("Path Failed : ") : ("Path Completed : ");
            // 0x00D1D7F0: LDR x22, [x8]              | X22 = val_4 != true ? "Path Failed : " : "Path Completed : ";
            // 0x00D1D7F4: CBZ x20, #0xd1d80c         | if ( == 0) goto label_7;                
            if(null == 0)
            {
                goto label_7;
            }
            // 0x00D1D7F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D7FC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D800: MOV x1, x22                | X1 = val_4 != true ? "Path Failed : " : "Path Completed : ";//m1
            // 0x00D1D804: BL #0x1b5b818              | X0 = Append(value:  val_5);             
            System.Text.StringBuilder val_6 = Append(value:  val_5);
            // 0x00D1D808: B #0xd1d824                |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x00D1D80C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00D1D810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D814: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D818: MOV x1, x22                | X1 = val_4 != true ? "Path Failed : " : "Path Completed : ";//m1
            // 0x00D1D81C: BL #0x1b5b818              | X0 = Append(value:  val_5);             
            System.Text.StringBuilder val_7 = Append(value:  val_5);
            // 0x00D1D820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_8:
            // 0x00D1D824: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00D1D828: LDR x8, [x8, #0x6e0]       | X8 = (string**)(1152921513239254704)("Computation Time ");
            // 0x00D1D82C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D830: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D834: LDR x1, [x8]               | X1 = "Computation Time ";               
            // 0x00D1D838: BL #0x1b5b818              | X0 = Append(value:  "Computation Time ");
            System.Text.StringBuilder val_8 = Append(value:  "Computation Time ");
            // 0x00D1D83C: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00D1D840: ADRP x9, #0x3625000        | X9 = 56774656 (0x3625000);              
            // 0x00D1D844: LDR x8, [x8, #0x610]       | X8 = (string**)(1152921513506795504)("0.000");
            // 0x00D1D848: LDR x9, [x9, #0xd70]       | X9 = (string**)(1152921513196862176)("0.00");
            // 0x00D1D84C: CMP w21, #2                | STATE = COMPARE(logMode, 0x2)           
            // 0x00D1D850: ADD x0, x19, #0x80         | X0 = (this + 128) = 1152921513507017136 (0x10000002127DD1B0);
            // 0x00D1D854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D858: CSEL x8, x8, x9, eq        | X8 = val_65 == 0x2 ? "0.000" : "0.00";  
            string val_9 = (val_65 == 2) ? ("0.000") : ("0.00");
            // 0x00D1D85C: LDR x1, [x8]               | X1 = val_65 == 0x2 ? "0.000" : "0.00";  
            // 0x00D1D860: BL #0x18a7768              | X0 = ToString(format:  val_9);          
            string val_10 = ToString(format:  val_9);
            // 0x00D1D864: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00D1D868: CBZ x20, #0xd1d880         | if ( == 0) goto label_9;                
            if(null == 0)
            {
                goto label_9;
            }
            // 0x00D1D86C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D870: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D874: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00D1D878: BL #0x1b5b818              | X0 = Append(value:  val_10);            
            System.Text.StringBuilder val_11 = Append(value:  val_10);
            // 0x00D1D87C: B #0xd1d898                |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x00D1D880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            // 0x00D1D884: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D888: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D88C: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00D1D890: BL #0x1b5b818              | X0 = Append(value:  val_10);            
            System.Text.StringBuilder val_12 = Append(value:  val_10);
            // 0x00D1D894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_10:
            // 0x00D1D898: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00D1D89C: LDR x8, [x8, #0xc20]       | X8 = (string**)(1152921513506807872)(" ms Searched Nodes ");
            // 0x00D1D8A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D8A4: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D8A8: LDR x1, [x8]               | X1 = " ms Searched Nodes ";             
            // 0x00D1D8AC: BL #0x1b5b818              | X0 = Append(value:  " ms Searched Nodes ");
            System.Text.StringBuilder val_13 = Append(value:  " ms Searched Nodes ");
            // 0x00D1D8B0: LDR w22, [x19, #0x88]      | 
            // 0x00D1D8B4: CBNZ x20, #0xd1d8bc        | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00D1D8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_11:
            // 0x00D1D8BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D8C0: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D8C4: MOV w1, w22                | W1 = val_10;//m1                        
            // 0x00D1D8C8: BL #0x1b5bac4              | X0 = Append(value:  val_10);            
            System.Text.StringBuilder val_14 = Append(value:  val_10);
            // 0x00D1D8CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D8D0: MOV x0, x19                | X0 = 1152921513507017008 (0x10000002127DD130);//ML01
            // 0x00D1D8D4: BL #0x1402c00              | X0 = this.get_error();                  
            bool val_15 = this.error;
            // 0x00D1D8D8: AND w8, w0, #1             | W8 = (val_15 & 1);                      
            bool val_16 = val_15;
            // 0x00D1D8DC: TBNZ w8, #0, #0xd1dcfc     | if ((val_15 & 1) == true) goto label_44;
            if(val_16 == true)
            {
                goto label_44;
            }
            // 0x00D1D8E0: CBNZ x20, #0xd1d8e8        | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x00D1D8E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_13:
            // 0x00D1D8E8: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x00D1D8EC: LDR x8, [x8, #0x880]       | X8 = (string**)(1152921513239283792)(" Path Length ");
            // 0x00D1D8F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D8F4: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D8F8: LDR x1, [x8]               | X1 = " Path Length ";                   
            // 0x00D1D8FC: BL #0x1b5b818              | X0 = Append(value:  " Path Length ");   
            System.Text.StringBuilder val_17 = Append(value:  " Path Length ");
            // 0x00D1D900: LDR x0, [x19, #0x60]       | 
            // 0x00D1D904: CBZ x0, #0xd1d930          | if (val_17 == null) goto label_14;      
            if(val_17 == null)
            {
                goto label_14;
            }
            // 0x00D1D908: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00D1D90C: LDR x8, [x8, #0xb50]       | X8 = 1152921513122910176;               
            // 0x00D1D910: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.GraphNode>::get_Count();
            // 0x00D1D914: BL #0x25ed72c              | X0 = val_17.get_Count();                
            int val_18 = val_17.Count;
            // 0x00D1D918: STR w0, [sp, #0x2c]        | stack[1152921513507004940] = val_18;     //  dest_result_addr=1152921513507004940
            // 0x00D1D91C: ADD x0, sp, #0x2c          | X0 = (1152921513507004896 + 44) = 1152921513507004940 (0x10000002127DA20C);
            // 0x00D1D920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1D924: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
            // 0x00D1D928: MOV x22, x0                | X22 = 1152921513507004940 (0x10000002127DA20C);//ML01
            val_69;
            // 0x00D1D92C: B #0xd1d93c                |  goto label_15;                         
            goto label_15;
            label_14:
            // 0x00D1D930: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00D1D934: LDR x8, [x8, #0x518]       | X8 = (string**)(1152921513239292080)("Null");
            // 0x00D1D938: LDR x22, [x8]              | X22 = "Null";                           
            val_69 = "Null";
            label_15:
            // 0x00D1D93C: CBNZ x20, #0xd1d944        | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x00D1D940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_16:
            // 0x00D1D944: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D948: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D94C: MOV x1, x22                | X1 = 1152921513239292080 (0x100000020288A8B0);//ML01
            // 0x00D1D950: BL #0x1b5b818              | X0 = Append(value:  val_69);            
            System.Text.StringBuilder val_19 = Append(value:  val_69);
            // 0x00D1D954: CMP w21, #2                | STATE = COMPARE(logMode, 0x2)           
            // 0x00D1D958: B.NE #0xd1dcfc             | if (val_65 != 0x2) goto label_44;       
            if(val_65 != 2)
            {
                goto label_44;
            }
            // 0x00D1D95C: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x00D1D960: LDR w8, [x19, #0x84]       | 
            // 0x00D1D964: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x00D1D968: ADD x1, sp, #0xc           | X1 = (1152921513507004896 + 12) = 1152921513507004908 (0x10000002127DA1EC);
            // 0x00D1D96C: STR w8, [sp, #0xc]         | stack[1152921513507004908] = (string**)(1152921513239292080)("Null");  //  dest_result_addr=1152921513507004908
            // 0x00D1D970: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x00D1D974: BL #0x27bc028              | X0 = 1152921513507094064 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (string**)(1152921513239292080)("Null"));
            // 0x00D1D978: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00D1D97C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00D1D980: MOV x22, x0                | X22 = 1152921513507094064 (0x10000002127EFE30);//ML01
            // 0x00D1D984: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00D1D988: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00D1D98C: TBZ w9, #0, #0xd1d9a0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00D1D990: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00D1D994: CBNZ w9, #0xd1d9a0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00D1D998: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00D1D99C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_19:
            // 0x00D1D9A0: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00D1D9A4: LDR x8, [x8, #0xf40]       | X8 = (string**)(1152921513239300352)("\nSearch Iterations ");
            // 0x00D1D9A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1D9AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00D1D9B0: MOV x2, x22                | X2 = 1152921513507094064 (0x10000002127EFE30);//ML01
            // 0x00D1D9B4: LDR x1, [x8]               | X1 = "\nSearch Iterations ";            
            // 0x00D1D9B8: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "\nSearch Iterations ");
            string val_20 = System.String.Concat(arg0:  0, arg1:  "\nSearch Iterations ");
            // 0x00D1D9BC: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x00D1D9C0: CBNZ x20, #0xd1d9c8        | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x00D1D9C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_20:
            // 0x00D1D9C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D9CC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1D9D0: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x00D1D9D4: BL #0x1b5b818              | X0 = Append(value:  val_20);            
            System.Text.StringBuilder val_21 = Append(value:  val_20);
            // 0x00D1D9D8: LDRB w8, [x19, #0x160]     | W8 = this.hasEndPoint; //P2             
            // 0x00D1D9DC: CBZ w8, #0xd1dbe8          | if (this.hasEndPoint == false) goto label_22;
            if(this.hasEndPoint == false)
            {
                goto label_22;
            }
            // 0x00D1D9E0: LDR x22, [x19, #0x118]     | X22 = this.endNode; //P2                
            // 0x00D1D9E4: CBZ x22, #0xd1dbe8         | if (this.endNode == null) goto label_22;
            if(this.endNode == null)
            {
                goto label_22;
            }
            // 0x00D1D9E8: LDR x23, [x19, #0x18]      | 
            // 0x00D1D9EC: CBNZ x23, #0xd1d9f4        | if (X23 != 0) goto label_23;            
            if(X23 != 0)
            {
                goto label_23;
            }
            // 0x00D1D9F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_23:
            // 0x00D1D9F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1D9F8: MOV x0, x23                | X0 = X23;//m1                           
            // 0x00D1D9FC: MOV x1, x22                | X1 = this.endNode;//m1                  
            // 0x00D1DA00: BL #0x140535c              | X0 = X23.GetPathNode(node:  this.endNode);
            Pathfinding.PathNode val_22 = X23.GetPathNode(node:  this.endNode);
            // 0x00D1DA04: MOV x22, x0                | X22 = val_22;//m1                       
            // 0x00D1DA08: CBNZ x20, #0xd1da10        | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x00D1DA0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_24:
            // 0x00D1DA10: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00D1DA14: LDR x8, [x8, #0xa30]       | X8 = (string**)(1152921513506844848)("\nEnd Node\n\tG: ");
            // 0x00D1DA18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DA1C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DA20: LDR x1, [x8]               | X1 = "\nEnd Node\n\tG: ";               
            // 0x00D1DA24: BL #0x1b5b818              | X0 = Append(value:  "\nEnd Node\n\tG: ");
            System.Text.StringBuilder val_23 = Append(value:  "\nEnd Node\n\tG: ");
            // 0x00D1DA28: CBNZ x22, #0xd1da30        | if (val_22 != null) goto label_25;      
            if(val_22 != null)
            {
                goto label_25;
            }
            // 0x00D1DA2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_25:
            // 0x00D1DA30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DA34: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x00D1DA38: BL #0x1405c90              | X0 = val_22.get_G();                    
            uint val_24 = val_22.G;
            // 0x00D1DA3C: MOV w23, w0                | W23 = val_24;//m1                       
            // 0x00D1DA40: CBZ x20, #0xd1da58         | if ( == 0) goto label_26;               
            if(null == 0)
            {
                goto label_26;
            }
            // 0x00D1DA44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DA48: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DA4C: MOV w1, w23                | W1 = val_24;//m1                        
            // 0x00D1DA50: BL #0x1b5bc50              | X0 = Append(value:  val_24);            
            System.Text.StringBuilder val_25 = Append(value:  val_24);
            // 0x00D1DA54: B #0xd1da70                |  goto label_27;                         
            goto label_27;
            label_26:
            // 0x00D1DA58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            // 0x00D1DA5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DA60: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DA64: MOV w1, w23                | W1 = val_24;//m1                        
            // 0x00D1DA68: BL #0x1b5bc50              | X0 = Append(value:  val_24);            
            System.Text.StringBuilder val_26 = Append(value:  val_24);
            // 0x00D1DA6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_27:
            // 0x00D1DA70: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00D1DA74: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921513506857248)("\n\tH: ");
            // 0x00D1DA78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DA7C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DA80: LDR x1, [x8]               | X1 = "\n\tH: ";                         
            // 0x00D1DA84: BL #0x1b5b818              | X0 = Append(value:  "\n\tH: ");         
            System.Text.StringBuilder val_27 = Append(value:  "\n\tH: ");
            // 0x00D1DA88: CBNZ x22, #0xd1da90        | if (val_22 != null) goto label_28;      
            if(val_22 != null)
            {
                goto label_28;
            }
            // 0x00D1DA8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_28:
            // 0x00D1DA90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DA94: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x00D1DA98: BL #0x1405ca0              | X0 = val_22.get_H();                    
            uint val_28 = val_22.H;
            // 0x00D1DA9C: MOV w23, w0                | W23 = val_28;//m1                       
            // 0x00D1DAA0: CBZ x20, #0xd1dab8         | if ( == 0) goto label_29;               
            if(null == 0)
            {
                goto label_29;
            }
            // 0x00D1DAA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DAA8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DAAC: MOV w1, w23                | W1 = val_28;//m1                        
            // 0x00D1DAB0: BL #0x1b5bc50              | X0 = Append(value:  val_28);            
            System.Text.StringBuilder val_29 = Append(value:  val_28);
            // 0x00D1DAB4: B #0xd1dad0                |  goto label_30;                         
            goto label_30;
            label_29:
            // 0x00D1DAB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            // 0x00D1DABC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DAC0: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DAC4: MOV w1, w23                | W1 = val_28;//m1                        
            // 0x00D1DAC8: BL #0x1b5bc50              | X0 = Append(value:  val_28);            
            System.Text.StringBuilder val_30 = Append(value:  val_28);
            // 0x00D1DACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_30:
            // 0x00D1DAD0: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00D1DAD4: LDR x8, [x8, #0xbc8]       | X8 = (string**)(1152921513506869632)("\n\tF: ");
            // 0x00D1DAD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DADC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DAE0: LDR x1, [x8]               | X1 = "\n\tF: ";                         
            // 0x00D1DAE4: BL #0x1b5b818              | X0 = Append(value:  "\n\tF: ");         
            System.Text.StringBuilder val_31 = Append(value:  "\n\tF: ");
            // 0x00D1DAE8: CBNZ x22, #0xd1daf0        | if (val_22 != null) goto label_31;      
            if(val_22 != null)
            {
                goto label_31;
            }
            // 0x00D1DAEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_31:
            // 0x00D1DAF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DAF4: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x00D1DAF8: BL #0x1405cb0              | X0 = val_22.get_F();                    
            uint val_32 = val_22.F;
            // 0x00D1DAFC: MOV w22, w0                | W22 = val_32;//m1                       
            // 0x00D1DB00: CBZ x20, #0xd1db18         | if ( == 0) goto label_32;               
            if(null == 0)
            {
                goto label_32;
            }
            // 0x00D1DB04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DB08: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DB0C: MOV w1, w22                | W1 = val_32;//m1                        
            // 0x00D1DB10: BL #0x1b5bc50              | X0 = Append(value:  val_32);            
            System.Text.StringBuilder val_33 = Append(value:  val_32);
            // 0x00D1DB14: B #0xd1db30                |  goto label_33;                         
            goto label_33;
            label_32:
            // 0x00D1DB18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            // 0x00D1DB1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DB20: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DB24: MOV w1, w22                | W1 = val_32;//m1                        
            // 0x00D1DB28: BL #0x1b5bc50              | X0 = Append(value:  val_32);            
            System.Text.StringBuilder val_34 = Append(value:  val_32);
            // 0x00D1DB2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_33:
            // 0x00D1DB30: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00D1DB34: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921513506882016)("\n\tPoint: ");
            // 0x00D1DB38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DB3C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DB40: LDR x1, [x8]               | X1 = "\n\tPoint: ";                     
            // 0x00D1DB44: BL #0x1b5b818              | X0 = Append(value:  "\n\tPoint: ");     
            System.Text.StringBuilder val_35 = Append(value:  "\n\tPoint: ");
            // 0x00D1DB48: LDR w8, [x19, #0x154]      | W8 = this.endPoint; //P2                
            // 0x00D1DB4C: LDR w9, [x19, #0x158]      | 
            // 0x00D1DB50: LDR w10, [x19, #0x15c]     | 
            // 0x00D1DB54: ADD x0, sp, #0x20          | X0 = (1152921513507004896 + 32) = 1152921513507004928 (0x10000002127DA200);
            // 0x00D1DB58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DB5C: STP w8, w9, [sp, #0x20]    | stack[1152921513507004928] = this.endPoint;  stack[1152921513507004932] = System.String.__il2cppRuntimeField_cctor_finished;  //  dest_result_addr=1152921513507004928 |  dest_result_addr=1152921513507004932
            // 0x00D1DB60: STR w10, [sp, #0x28]       | stack[1152921513507004936] = ???;        //  dest_result_addr=1152921513507004936
            // 0x00D1DB64: BL #0x269a990              | X0 = label_UnityEngine_Vector3_op_Inequality_GL0269A990();
            // 0x00D1DB68: MOV x22, x0                | X22 = 1152921513507004928 (0x10000002127DA200);//ML01
            // 0x00D1DB6C: CBZ x20, #0xd1db84         | if ( == 0) goto label_34;               
            if(null == 0)
            {
                goto label_34;
            }
            // 0x00D1DB70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DB74: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DB78: MOV x1, x22                | X1 = 1152921513507004928 (0x10000002127DA200);//ML01
            // 0x00D1DB7C: BL #0x1b5b818              | X0 = Append(value:  this.endPoint);     
            System.Text.StringBuilder val_36 = Append(value:  this.endPoint);
            // 0x00D1DB80: B #0xd1db9c                |  goto label_35;                         
            goto label_35;
            label_34:
            // 0x00D1DB84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002127DA200, ????);
            // 0x00D1DB88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DB8C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DB90: MOV x1, x22                | X1 = 1152921513507004928 (0x10000002127DA200);//ML01
            // 0x00D1DB94: BL #0x1b5b818              | X0 = Append(value:  this.endPoint);     
            System.Text.StringBuilder val_37 = Append(value:  this.endPoint);
            // 0x00D1DB98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_35:
            // 0x00D1DB9C: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00D1DBA0: LDR x8, [x8, #0x358]       | X8 = (string**)(1152921513506894400)("\n\tGraph: ");
            // 0x00D1DBA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DBA8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DBAC: LDR x1, [x8]               | X1 = "\n\tGraph: ";                     
            // 0x00D1DBB0: BL #0x1b5b818              | X0 = Append(value:  "\n\tGraph: ");     
            System.Text.StringBuilder val_38 = Append(value:  "\n\tGraph: ");
            // 0x00D1DBB4: LDR x22, [x19, #0x118]     | X22 = this.endNode; //P2                
            // 0x00D1DBB8: CBNZ x22, #0xd1dbc0        | if (this.endNode != null) goto label_36;
            if(this.endNode != null)
            {
                goto label_36;
            }
            // 0x00D1DBBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_36:
            // 0x00D1DBC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DBC4: MOV x0, x22                | X0 = this.endNode;//m1                  
            // 0x00D1DBC8: BL #0x168237c              | X0 = this.endNode.get_GraphIndex();     
            uint val_39 = this.endNode.GraphIndex;
            // 0x00D1DBCC: MOV w22, w0                | W22 = val_39;//m1                       
            // 0x00D1DBD0: CBNZ x20, #0xd1dbd8        | if ( != 0) goto label_37;               
            if(null != 0)
            {
                goto label_37;
            }
            // 0x00D1DBD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_37:
            // 0x00D1DBD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DBDC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DBE0: MOV w1, w22                | W1 = val_39;//m1                        
            // 0x00D1DBE4: BL #0x1b5bc50              | X0 = Append(value:  val_39);            
            System.Text.StringBuilder val_40 = Append(value:  val_39);
            label_22:
            // 0x00D1DBE8: CBZ x20, #0xd1dc08         | if ( == 0) goto label_38;               
            if(null == 0)
            {
                goto label_38;
            }
            // 0x00D1DBEC: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00D1DBF0: LDR x8, [x8, #0x648]       | X8 = (string**)(1152921513506906784)("\nStart Node");
            // 0x00D1DBF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DBF8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DBFC: LDR x1, [x8]               | X1 = "\nStart Node";                    
            // 0x00D1DC00: BL #0x1b5b818              | X0 = Append(value:  "\nStart Node");    
            System.Text.StringBuilder val_41 = Append(value:  "\nStart Node");
            // 0x00D1DC04: B #0xd1dc28                |  goto label_39;                         
            goto label_39;
            label_38:
            // 0x00D1DC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            // 0x00D1DC0C: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00D1DC10: LDR x8, [x8, #0x648]       | X8 = (string**)(1152921513506906784)("\nStart Node");
            // 0x00D1DC14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DC18: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DC1C: LDR x1, [x8]               | X1 = "\nStart Node";                    
            // 0x00D1DC20: BL #0x1b5b818              | X0 = Append(value:  "\nStart Node");    
            System.Text.StringBuilder val_42 = Append(value:  "\nStart Node");
            // 0x00D1DC24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_39:
            // 0x00D1DC28: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00D1DC2C: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921513506882016)("\n\tPoint: ");
            // 0x00D1DC30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DC34: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DC38: LDR x1, [x8]               | X1 = "\n\tPoint: ";                     
            // 0x00D1DC3C: BL #0x1b5b818              | X0 = Append(value:  "\n\tPoint: ");     
            System.Text.StringBuilder val_43 = Append(value:  "\n\tPoint: ");
            // 0x00D1DC40: LDR w8, [x19, #0x148]      | W8 = this.startPoint; //P2              
            // 0x00D1DC44: LDR w9, [x19, #0x14c]      | 
            // 0x00D1DC48: LDR w10, [x19, #0x150]     | 
            // 0x00D1DC4C: ADD x0, sp, #0x10          | X0 = (1152921513507004896 + 16) = 1152921513507004912 (0x10000002127DA1F0);
            // 0x00D1DC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DC54: STP w8, w9, [sp, #0x10]    | stack[1152921513507004912] = this.startPoint;  stack[1152921513507004916] = System.String.__il2cppRuntimeField_cctor_finished;  //  dest_result_addr=1152921513507004912 |  dest_result_addr=1152921513507004916
            // 0x00D1DC58: STR w10, [sp, #0x18]       | stack[1152921513507004920] = ???;        //  dest_result_addr=1152921513507004920
            // 0x00D1DC5C: BL #0x269a990              | X0 = label_UnityEngine_Vector3_op_Inequality_GL0269A990();
            // 0x00D1DC60: MOV x22, x0                | X22 = 1152921513507004912 (0x10000002127DA1F0);//ML01
            // 0x00D1DC64: CBZ x20, #0xd1dc7c         | if ( == 0) goto label_40;               
            if(null == 0)
            {
                goto label_40;
            }
            // 0x00D1DC68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DC6C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DC70: MOV x1, x22                | X1 = 1152921513507004912 (0x10000002127DA1F0);//ML01
            // 0x00D1DC74: BL #0x1b5b818              | X0 = Append(value:  this.startPoint);   
            System.Text.StringBuilder val_44 = Append(value:  this.startPoint);
            // 0x00D1DC78: B #0xd1dc94                |  goto label_41;                         
            goto label_41;
            label_40:
            // 0x00D1DC7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002127DA1F0, ????);
            // 0x00D1DC80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DC84: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DC88: MOV x1, x22                | X1 = 1152921513507004912 (0x10000002127DA1F0);//ML01
            // 0x00D1DC8C: BL #0x1b5b818              | X0 = Append(value:  this.startPoint);   
            System.Text.StringBuilder val_45 = Append(value:  this.startPoint);
            // 0x00D1DC90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
            label_41:
            // 0x00D1DC94: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00D1DC98: LDR x8, [x8, #0x358]       | X8 = (string**)(1152921513506894400)("\n\tGraph: ");
            // 0x00D1DC9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DCA0: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DCA4: LDR x1, [x8]               | X1 = "\n\tGraph: ";                     
            // 0x00D1DCA8: BL #0x1b5b818              | X0 = Append(value:  "\n\tGraph: ");     
            System.Text.StringBuilder val_46 = Append(value:  "\n\tGraph: ");
            // 0x00D1DCAC: LDR x0, [x19, #0x110]      | X0 = this.startNode; //P2               
            // 0x00D1DCB0: CBZ x0, #0xd1dcdc          | if (this.startNode == null) goto label_42;
            if(this.startNode == null)
            {
                goto label_42;
            }
            // 0x00D1DCB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DCB8: BL #0x168237c              | X0 = this.startNode.get_GraphIndex();   
            uint val_47 = this.startNode.GraphIndex;
            // 0x00D1DCBC: MOV w22, w0                | W22 = val_47;//m1                       
            // 0x00D1DCC0: CBNZ x20, #0xd1dcc8        | if ( != 0) goto label_43;               
            if(null != 0)
            {
                goto label_43;
            }
            // 0x00D1DCC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
            label_43:
            // 0x00D1DCC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DCCC: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DCD0: MOV w1, w22                | W1 = val_47;//m1                        
            // 0x00D1DCD4: BL #0x1b5bc50              | X0 = Append(value:  val_47);            
            System.Text.StringBuilder val_48 = Append(value:  val_47);
            // 0x00D1DCD8: B #0xd1dcfc                |  goto label_44;                         
            goto label_44;
            label_42:
            // 0x00D1DCDC: CBNZ x20, #0xd1dce4        | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x00D1DCE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.startNode, ????);
            label_45:
            // 0x00D1DCE4: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00D1DCE8: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921513506939648)("< null startNode >");
            // 0x00D1DCEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DCF0: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DCF4: LDR x1, [x8]               | X1 = "< null startNode >";              
            // 0x00D1DCF8: BL #0x1b5b818              | X0 = Append(value:  "< null startNode >");
            System.Text.StringBuilder val_49 = Append(value:  "< null startNode >");
            label_44:
            // 0x00D1DCFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DD00: MOV x0, x19                | X0 = 1152921513507017008 (0x10000002127DD130);//ML01
            // 0x00D1DD04: BL #0x1402c00              | X0 = this.get_error();                  
            bool val_50 = this.error;
            // 0x00D1DD08: TBZ w0, #0, #0xd1dd54      | if (val_50 == false) goto label_46;     
            if(val_50 == false)
            {
                goto label_46;
            }
            // 0x00D1DD0C: CBNZ x20, #0xd1dd14        | if ( != 0) goto label_47;               
            if(null != 0)
            {
                goto label_47;
            }
            // 0x00D1DD10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
            label_47:
            // 0x00D1DD14: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00D1DD18: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921513239312752)("\nError: ");
            // 0x00D1DD1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DD20: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DD24: LDR x1, [x8]               | X1 = "\nError: ";                       
            // 0x00D1DD28: BL #0x1b5b818              | X0 = Append(value:  "\nError: ");       
            System.Text.StringBuilder val_51 = Append(value:  "\nError: ");
            // 0x00D1DD2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DD30: MOV x0, x19                | X0 = 1152921513507017008 (0x10000002127DD130);//ML01
            // 0x00D1DD34: BL #0x1402c10              | X0 = this.get_errorLog();               
            string val_52 = this.errorLog;
            // 0x00D1DD38: MOV x22, x0                | X22 = val_52;//m1                       
            // 0x00D1DD3C: CBNZ x20, #0xd1dd44        | if ( != 0) goto label_48;               
            if(null != 0)
            {
                goto label_48;
            }
            // 0x00D1DD40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
            label_48:
            // 0x00D1DD44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DD48: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DD4C: MOV x1, x22                | X1 = val_52;//m1                        
            // 0x00D1DD50: BL #0x1b5b818              | X0 = Append(value:  val_52);            
            System.Text.StringBuilder val_53 = Append(value:  val_52);
            label_46:
            // 0x00D1DD54: CMP w21, #2                | STATE = COMPARE(logMode, 0x2)           
            // 0x00D1DD58: B.NE #0xd1de50             | if (val_65 != 0x2) goto label_59;       
            if(val_65 != 2)
            {
                goto label_59;
            }
            // 0x00D1DD5C: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00D1DD60: LDR x8, [x8, #0xe80]       | X8 = 1152921504837996544;               
            // 0x00D1DD64: LDR x0, [x8]               | X0 = typeof(AstarPath);                 
            // 0x00D1DD68: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x00D1DD6C: TBZ w8, #0, #0xd1dd7c      | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x00D1DD70: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x00D1DD74: CBNZ w8, #0xd1dd7c         | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x00D1DD78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            label_51:
            // 0x00D1DD7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1DD80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DD84: BL #0xb37458               | X0 = AstarPath.get_IsUsingMultithreading();
            bool val_54 = AstarPath.IsUsingMultithreading;
            // 0x00D1DD88: AND w8, w0, #1             | W8 = (val_54 & 1);                      
            bool val_55 = val_54;
            // 0x00D1DD8C: TBNZ w8, #0, #0xd1de50     | if ((val_54 & 1) == true) goto label_59;
            if(val_55 == true)
            {
                goto label_59;
            }
            // 0x00D1DD90: CBNZ x20, #0xd1dd98        | if ( != 0) goto label_53;               
            if(null != 0)
            {
                goto label_53;
            }
            // 0x00D1DD94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
            label_53:
            // 0x00D1DD98: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00D1DD9C: LDR x8, [x8, #0x150]       | X8 = (string**)(1152921513239325136)("\nCallback references ");
            // 0x00D1DDA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DDA4: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DDA8: LDR x1, [x8]               | X1 = "\nCallback references ";          
            // 0x00D1DDAC: BL #0x1b5b818              | X0 = Append(value:  "\nCallback references ");
            System.Text.StringBuilder val_56 = Append(value:  "\nCallback references ");
            // 0x00D1DDB0: LDR x0, [x19, #0x20]       | 
            // 0x00D1DDB4: CBZ x0, #0xd1de30          | if (val_56 == null) goto label_54;      
            if(val_56 == null)
            {
                goto label_54;
            }
            // 0x00D1DDB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DDBC: BL #0x1c33830              | X0 = val_56.get_Target();               
            object val_57 = val_56.Target;
            // 0x00D1DDC0: MOV x21, x0                | X21 = val_57;//m1                       
            // 0x00D1DDC4: CBNZ x21, #0xd1ddcc        | if (val_57 != null) goto label_55;      
            if(val_57 != null)
            {
                goto label_55;
            }
            // 0x00D1DDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
            label_55:
            // 0x00D1DDCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DDD0: MOV x0, x21                | X0 = val_57;//m1                        
            // 0x00D1DDD4: BL #0x16fb28c              | X0 = val_57.GetType();                  
            System.Type val_58 = val_57.GetType();
            // 0x00D1DDD8: MOV x21, x0                | X21 = val_58;//m1                       
            // 0x00D1DDDC: CBNZ x21, #0xd1dde4        | if (val_58 != null) goto label_56;      
            if(val_58 != null)
            {
                goto label_56;
            }
            // 0x00D1DDE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
            label_56:
            // 0x00D1DDE4: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x00D1DDE8: MOV x0, x21                | X0 = val_58;//m1                        
            // 0x00D1DDEC: LDR x9, [x8, #0x230]       | X9 = typeof(System.Type).__il2cppRuntimeField_230;
            // 0x00D1DDF0: LDR x1, [x8, #0x238]       | X1 = typeof(System.Type).__il2cppRuntimeField_238;
            // 0x00D1DDF4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_230();
            // 0x00D1DDF8: MOV x21, x0                | X21 = val_58;//m1                       
            // 0x00D1DDFC: CBNZ x20, #0xd1de04        | if ( != 0) goto label_57;               
            if(null != 0)
            {
                goto label_57;
            }
            // 0x00D1DE00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
            label_57:
            // 0x00D1DE04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DE08: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DE0C: MOV x1, x21                | X1 = val_58;//m1                        
            // 0x00D1DE10: BL #0x1b5b818              | X0 = Append(value:  val_58);            
            System.Text.StringBuilder val_59 = Append(value:  val_58);
            // 0x00D1DE14: MOV x21, x0                | X21 = val_59;//m1                       
            val_65 = val_59;
            // 0x00D1DE18: CBNZ x21, #0xd1de20        | if (val_59 != null) goto label_58;      
            if(val_65 != null)
            {
                goto label_58;
            }
            // 0x00D1DE1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
            label_58:
            // 0x00D1DE20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1DE24: MOV x0, x21                | X0 = val_59;//m1                        
            // 0x00D1DE28: BL #0x1b5c038              | X0 = val_59.AppendLine();               
            System.Text.StringBuilder val_60 = val_65.AppendLine();
            // 0x00D1DE2C: B #0xd1de50                |  goto label_59;                         
            goto label_59;
            label_54:
            // 0x00D1DE30: CBNZ x20, #0xd1de38        | if ( != 0) goto label_60;               
            if(null != 0)
            {
                goto label_60;
            }
            // 0x00D1DE34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
            label_60:
            // 0x00D1DE38: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00D1DE3C: LDR x8, [x8, #0x5f0]       | X8 = (string**)(1152921513169195088)("NULL");
            // 0x00D1DE40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DE44: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DE48: LDR x1, [x8]               | X1 = "NULL";                            
            // 0x00D1DE4C: BL #0x1b5c068              | X0 = AppendLine(value:  "NULL");        
            System.Text.StringBuilder val_61 = AppendLine(value:  "NULL");
            label_59:
            // 0x00D1DE50: CBNZ x20, #0xd1de58        | if ( != 0) goto label_61;               
            if(null != 0)
            {
                goto label_61;
            }
            // 0x00D1DE54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
            label_61:
            // 0x00D1DE58: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00D1DE5C: LDR x8, [x8, #0x6b8]       | X8 = (string**)(1152921513239353920)("\nPath Number ");
            // 0x00D1DE60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DE64: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DE68: LDR x1, [x8]               | X1 = "\nPath Number ";                  
            // 0x00D1DE6C: BL #0x1b5b818              | X0 = Append(value:  "\nPath Number ");  
            System.Text.StringBuilder val_62 = Append(value:  "\nPath Number ");
            // 0x00D1DE70: LDRH w19, [x19, #0xd4]     | 
            // 0x00D1DE74: CBZ x20, #0xd1de8c         | if ( == 0) goto label_62;               
            if(null == 0)
            {
                goto label_62;
            }
            // 0x00D1DE78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DE7C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DE80: MOV w1, w19                | W1 = 1152921513507017008 (0x10000002127DD130);//ML01
            val_70 = this;
            // 0x00D1DE84: BL #0x1b5bc10              | X0 = Append(value:  53552);             
            System.Text.StringBuilder val_63 = Append(value:  53552);
            // 0x00D1DE88: B #0xd1dea4                |  goto label_63;                         
            goto label_63;
            label_62:
            // 0x00D1DE8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
            // 0x00D1DE90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1DE94: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00D1DE98: MOV w1, w19                | W1 = 1152921513507017008 (0x10000002127DD130);//ML01
            val_70 = this;
            // 0x00D1DE9C: BL #0x1b5bc10              | X0 = Append(value:  53552);             
            System.Text.StringBuilder val_64 = Append(value:  53552);
            // 0x00D1DEA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
            label_63:
            // 0x00D1DEA4: LDR x8, [x20]              | X8 = ;                                  
            // 0x00D1DEA8: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            val_68 = val_3;
            // 0x00D1DEAC: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x00D1DEB0: BLR x9                     | X0 = mem[null + 320]();                 
            label_6:
            // 0x00D1DEB4: SUB sp, x29, #0x30         | SP = (1152921513507004992 - 48) = 1152921513507004944 (0x10000002127DA210);
            // 0x00D1DEB8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1DEBC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1DEC0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1DEC4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00D1DEC8: RET                        |  return (System.String)typeof(System.Text.StringBuilder);
            return (string)val_68;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1DECC (13754060), len: 116  VirtAddr: 0x00D1DECC RVA: 0x00D1DECC token: 100683594 methodIndex: 49698 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Recycle()
        {
            //
            // Disasemble & Code
            // 0x00D1DECC: STP x20, x19, [sp, #-0x20]! | stack[1152921513507330992] = ???;  stack[1152921513507331000] = ???;  //  dest_result_addr=1152921513507330992 |  dest_result_addr=1152921513507331000
            // 0x00D1DED0: STP x29, x30, [sp, #0x10]  | stack[1152921513507331008] = ???;  stack[1152921513507331016] = ???;  //  dest_result_addr=1152921513507331008 |  dest_result_addr=1152921513507331016
            // 0x00D1DED4: ADD x29, sp, #0x10         | X29 = (1152921513507330992 + 16) = 1152921513507331008 (0x1000000212829BC0);
            // 0x00D1DED8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1DEDC: LDRB w8, [x20, #0x2da]     | W8 = (bool)static_value_037342DA;       
            // 0x00D1DEE0: MOV x19, x0                | X19 = 1152921513507343024 (0x100000021282CAB0);//ML01
            // 0x00D1DEE4: TBNZ w8, #0, #0xd1df00     | if (static_value_037342DA == true) goto label_0;
            // 0x00D1DEE8: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00D1DEEC: LDR x8, [x8, #0x770]       | X8 = 0x2B8A784;                         
            // 0x00D1DEF0: LDR w0, [x8]               | W0 = 0x9F;                              
            // 0x00D1DEF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x9F, ????);       
            // 0x00D1DEF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1DEFC: STRB w8, [x20, #0x2da]     | static_value_037342DA = true;            //  dest_result_addr=57885402
            label_0:
            // 0x00D1DF00: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00D1DF04: LDR x8, [x8, #0xc80]       | X8 = 1152921504839860224;               
            // 0x00D1DF08: LDR x0, [x8]               | X0 = typeof(Pathfinding.PathPool<T>);   
            // 0x00D1DF0C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_10A;
            // 0x00D1DF10: TBZ w8, #0, #0xd1df20      | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00D1DF14: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00D1DF18: CBNZ w8, #0xd1df20         | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00D1DF1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.PathPool<T>), ????);
            label_2:
            // 0x00D1DF20: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00D1DF24: LDR x8, [x8, #0x720]       | X8 = 1152921513507318000;               
            // 0x00D1DF28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1DF2C: MOV x1, x19                | X1 = 1152921513507343024 (0x100000021282CAB0);//ML01
            // 0x00D1DF30: LDR x2, [x8]               | X2 = public static System.Void Pathfinding.PathPool<Pathfinding.ABPath>::Recycle(Pathfinding.ABPath path);
            // 0x00D1DF34: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1DF38: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00D1DF3C: B #0x19f0bd8               | Pathfinding.PathPool<Pathfinding.RandomPath>.Recycle(path:  0); return;
            Pathfinding.PathPool<Pathfinding.RandomPath>.Recycle(path:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1DF40 (13754176), len: 704  VirtAddr: 0x00D1DF40 RVA: 0x00D1DF40 token: 100683595 methodIndex: 49699 delegateWrapperIndex: 0 methodInvoker: 0
        public UnityEngine.Vector3 GetMovementVector(UnityEngine.Vector3 point)
        {
            //
            // Disasemble & Code
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            float val_20;
            //  | 
            float val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            float val_26;
            //  | 
            var val_27;
            // 0x00D1DF40: STP d15, d14, [sp, #-0x90]! | stack[1152921513507442880] = ???;  stack[1152921513507442888] = ???;  //  dest_result_addr=1152921513507442880 |  dest_result_addr=1152921513507442888
            // 0x00D1DF44: STP d13, d12, [sp, #0x10]  | stack[1152921513507442896] = ???;  stack[1152921513507442904] = ???;  //  dest_result_addr=1152921513507442896 |  dest_result_addr=1152921513507442904
            // 0x00D1DF48: STP d11, d10, [sp, #0x20]  | stack[1152921513507442912] = ???;  stack[1152921513507442920] = ???;  //  dest_result_addr=1152921513507442912 |  dest_result_addr=1152921513507442920
            // 0x00D1DF4C: STP d9, d8, [sp, #0x30]    | stack[1152921513507442928] = ???;  stack[1152921513507442936] = ???;  //  dest_result_addr=1152921513507442928 |  dest_result_addr=1152921513507442936
            // 0x00D1DF50: STP x26, x25, [sp, #0x40]  | stack[1152921513507442944] = ???;  stack[1152921513507442952] = ???;  //  dest_result_addr=1152921513507442944 |  dest_result_addr=1152921513507442952
            // 0x00D1DF54: STP x24, x23, [sp, #0x50]  | stack[1152921513507442960] = ???;  stack[1152921513507442968] = ???;  //  dest_result_addr=1152921513507442960 |  dest_result_addr=1152921513507442968
            // 0x00D1DF58: STP x22, x21, [sp, #0x60]  | stack[1152921513507442976] = ???;  stack[1152921513507442984] = ???;  //  dest_result_addr=1152921513507442976 |  dest_result_addr=1152921513507442984
            // 0x00D1DF5C: STP x20, x19, [sp, #0x70]  | stack[1152921513507442992] = ???;  stack[1152921513507443000] = ???;  //  dest_result_addr=1152921513507442992 |  dest_result_addr=1152921513507443000
            // 0x00D1DF60: STP x29, x30, [sp, #0x80]  | stack[1152921513507443008] = ???;  stack[1152921513507443016] = ???;  //  dest_result_addr=1152921513507443008 |  dest_result_addr=1152921513507443016
            // 0x00D1DF64: ADD x29, sp, #0x80         | X29 = (1152921513507442880 + 128) = 1152921513507443008 (0x1000000212845140);
            // 0x00D1DF68: SUB sp, sp, #0x20          | SP = (1152921513507442880 - 32) = 1152921513507442848 (0x10000002128450A0);
            // 0x00D1DF6C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1DF70: LDRB w8, [x20, #0x2db]     | W8 = (bool)static_value_037342DB;       
            // 0x00D1DF74: MOV v8.16b, v2.16b         | V8 = point.z;//m1                       
            // 0x00D1DF78: MOV v9.16b, v1.16b         | V9 = point.y;//m1                       
            // 0x00D1DF7C: MOV v10.16b, v0.16b        | V10 = point.x;//m1                      
            // 0x00D1DF80: MOV x19, x0                | X19 = 1152921513507455024 (0x1000000212848030);//ML01
            val_16 = this;
            // 0x00D1DF84: TBNZ w8, #0, #0xd1dfa0     | if (static_value_037342DB == true) goto label_0;
            // 0x00D1DF88: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00D1DF8C: LDR x8, [x8, #0xc88]       | X8 = 0x2B8A778;                         
            // 0x00D1DF90: LDR w0, [x8]               | W0 = 0x9C;                              
            // 0x00D1DF94: BL #0x2782188              | X0 = sub_2782188( ?? 0x9C, ????);       
            // 0x00D1DF98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1DF9C: STRB w8, [x20, #0x2db]     | static_value_037342DB = true;            //  dest_result_addr=57885403
            label_0:
            // 0x00D1DFA0: STR wzr, [sp, #0x18]       | stack[1152921513507442872] = 0x0;        //  dest_result_addr=1152921513507442872
            // 0x00D1DFA4: STR xzr, [sp, #0x10]       | stack[1152921513507442864] = 0x0;        //  dest_result_addr=1152921513507442864
            // 0x00D1DFA8: LDR x0, [x19, #0x68]       | 
            // 0x00D1DFAC: CBZ x0, #0xd1e020          | if (0x9C == 0) goto label_2;            
            if(156 == 0)
            {
                goto label_2;
            }
            // 0x00D1DFB0: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
            // 0x00D1DFB4: LDR x22, [x22, #0x5e0]     | X22 = 1152921510909311600;              
            // 0x00D1DFB8: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
            // 0x00D1DFBC: BL #0x2643344              | X0 = 156.get_Count();                   
            int val_1 = 156.Count;
            // 0x00D1DFC0: CBZ w0, #0xd1e020          | if (val_1 == 0) goto label_2;           
            if(val_1 == 0)
            {
                goto label_2;
            }
            // 0x00D1DFC4: LDR x20, [x19, #0x68]      | 
            // 0x00D1DFC8: CBNZ x20, #0xd1dfd0        | if ( != 0) goto label_3;                
            if(!=0)
            {
                goto label_3;
            }
            // 0x00D1DFCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00D1DFD0: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
            // 0x00D1DFD4: MOV x0, x20                | X0 = 57884672 (0x3734000);//ML01        
            // 0x00D1DFD8: BL #0x2643344              | X0 = get_Count();                       
            int val_2 = Count;
            // 0x00D1DFDC: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
            // 0x00D1DFE0: B.NE #0xd1e050             | if (val_2 != 1) goto label_4;           
            if(val_2 != 1)
            {
                goto label_4;
            }
            // 0x00D1DFE4: LDR x19, [x19, #0x68]      | 
            // 0x00D1DFE8: CBNZ x19, #0xd1dff0        | if (this != null) goto label_5;         
            if(this != null)
            {
                goto label_5;
            }
            // 0x00D1DFEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x00D1DFF0: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00D1DFF4: LDR x8, [x8, #0x1f0]       | X8 = 1152921510909481968;               
            // 0x00D1DFF8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1DFFC: MOV x0, x19                | X0 = 1152921513507455024 (0x1000000212848030);//ML01
            // 0x00D1E000: LDR x2, [x8]               | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
            // 0x00D1E004: BL #0x264334c              | X0 = this.get_Item(index:  0);          
            UnityEngine.Vector3 val_3 = this.Item[0];
            // 0x00D1E008: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00D1E00C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00D1E010: MOV v11.16b, v0.16b        | V11 = val_3.x;//m1                      
            val_20 = val_3.x;
            // 0x00D1E014: MOV v12.16b, v1.16b        | V12 = val_3.y;//m1                      
            val_21 = val_3.y;
            // 0x00D1E018: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            val_22 = null;
            // 0x00D1E01C: B #0xd1e198                |  goto label_6;                          
            goto label_6;
            label_2:
            // 0x00D1E020: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00D1E024: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00D1E028: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x00D1E02C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00D1E030: TBZ w8, #0, #0xd1e040      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00D1E034: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1E038: CBNZ w8, #0xd1e040         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00D1E03C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_8:
            // 0x00D1E040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1E044: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E048: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_4 = UnityEngine.Vector3.zero;
            // 0x00D1E04C: B #0xd1e1d4                |  goto label_9;                          
            goto label_9;
            label_4:
            // 0x00D1E050: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x00D1E054: ADRP x25, #0x363e000       | X25 = 56877056 (0x363E000);             
            // 0x00D1E058: ADRP x23, #0x3673000       | X23 = 57094144 (0x3673000);             
            // 0x00D1E05C: LDR s14, [x8, #0x930]      | S14 = Infinity;                         
            val_26 = Infinityf;
            // 0x00D1E060: LDR x25, [x25, #0x1f0]     | X25 = 1152921510909481968;              
            // 0x00D1E064: LDR x23, [x23, #0x488]     | X23 = 1152921504695078912;              
            // 0x00D1E068: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            int val_16 = 0;
            // 0x00D1E06C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_27 = 0;
            // 0x00D1E070: B #0xd1e0bc                |  goto label_10;                         
            goto label_10;
            label_17:
            // 0x00D1E074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1E078: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E07C: MOV v0.16b, v11.16b        | V0 = V11.16B;//m1                       
            // 0x00D1E080: MOV v1.16b, v12.16b        | V1 = V12.16B;//m1                       
            // 0x00D1E084: MOV v2.16b, v13.16b        | V2 = V13.16B;//m1                       
            // 0x00D1E088: MOV v3.16b, v10.16b        | V3 = point.x;//m1                       
            // 0x00D1E08C: MOV v4.16b, v9.16b         | V4 = point.y;//m1                       
            // 0x00D1E090: MOV v5.16b, v8.16b         | V5 = point.z;//m1                       
            // 0x00D1E094: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = V11.16B, y = V12.16B, z = V13.16B}, b:  new UnityEngine.Vector3() {x = point.x, y = point.y, z = point.z});
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = V11.16B, y = V12.16B, z = V13.16B}, b:  new UnityEngine.Vector3() {x = point.x, y = point.y, z = point.z});
            // 0x00D1E098: ADD x0, sp, #0x10          | X0 = (1152921513507442848 + 16) = 1152921513507442864 (0x10000002128450B0);
            // 0x00D1E09C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E0A0: STP s0, s1, [sp, #0x10]    | stack[1152921513507442864] = val_5.x;  stack[1152921513507442868] = val_5.y;  //  dest_result_addr=1152921513507442864 |  dest_result_addr=1152921513507442868
            // 0x00D1E0A4: STR s2, [sp, #0x18]        | stack[1152921513507442872] = val_5.z;    //  dest_result_addr=1152921513507442872
            // 0x00D1E0A8: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x00D1E0AC: SUB w8, w20, #1            | W8 = (0 - 1) = -1 (0xFFFFFFFFFFFFFFFF); 
            // 0x00D1E0B0: FCMP s0, s14               | STATE = COMPARE(val_5.x, Infinity)      
            // 0x00D1E0B4: CSEL w24, w8, w24, mi      | W24 = val_5.x < 0 ? -1 : val_27;        
            var val_6 = (val_5.x < 0) ? (-1) : (val_27);
            // 0x00D1E0B8: FCSEL s14, s0, s14, mi     | S14 = val_5.x < 0 ? val_5.x : val_26;   
            var val_7 = (val_5.x < 0) ? val_5.x : (val_26);
            label_10:
            // 0x00D1E0BC: LDR x21, [x19, #0x68]      | 
            // 0x00D1E0C0: CBNZ x21, #0xd1e0c8        | if (X21 != 0) goto label_11;            
            if(X21 != 0)
            {
                goto label_11;
            }
            // 0x00D1E0C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002128450B0, ????);
            label_11:
            // 0x00D1E0C8: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
            // 0x00D1E0CC: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1E0D0: BL #0x2643344              | X0 = X21.get_Count();                   
            int val_8 = X21.Count;
            // 0x00D1E0D4: LDR x21, [x19, #0x68]      | 
            // 0x00D1E0D8: SUB w26, w0, #1            | W26 = (val_8 - 1);                      
            int val_9 = val_8 - 1;
            // 0x00D1E0DC: CBNZ x21, #0xd1e0e4        | if (X21 != 0) goto label_12;            
            if(X21 != 0)
            {
                goto label_12;
            }
            // 0x00D1E0E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_12:
            // 0x00D1E0E4: CMP w20, w26               | STATE = COMPARE(0x0, (val_8 - 1))       
            // 0x00D1E0E8: B.GE #0xd1e17c             | if (0 >= val_9) goto label_13;          
            if(val_16 >= val_9)
            {
                goto label_13;
            }
            // 0x00D1E0EC: LDR x2, [x25]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
            // 0x00D1E0F0: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1E0F4: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
            // 0x00D1E0F8: BL #0x264334c              | X0 = X21.get_Item(index:  0);           
            UnityEngine.Vector3 val_10 = X21.Item[0];
            // 0x00D1E0FC: LDR x21, [x19, #0x68]      | 
            // 0x00D1E100: MOV v11.16b, v0.16b        | V11 = val_10.x;//m1                     
            // 0x00D1E104: MOV v12.16b, v1.16b        | V12 = val_10.y;//m1                     
            // 0x00D1E108: MOV v13.16b, v2.16b        | V13 = val_10.z;//m1                     
            // 0x00D1E10C: CBNZ x21, #0xd1e114        | if (X21 != 0) goto label_14;            
            if(X21 != 0)
            {
                goto label_14;
            }
            // 0x00D1E110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X21, ????);        
            label_14:
            // 0x00D1E114: LDR x2, [x25]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
            // 0x00D1E118: ADD w20, w20, #1           | W20 = (0 + 1);                          
            val_16 = val_16 + 1;
            // 0x00D1E11C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1E120: MOV w1, w20                | W1 = (0 + 1);//m1                       
            // 0x00D1E124: BL #0x264334c              | X0 = X21.get_Item(index:  0);           
            UnityEngine.Vector3 val_11 = X21.Item[val_16];
            // 0x00D1E128: MOV v3.16b, v0.16b         | V3 = val_11.x;//m1                      
            // 0x00D1E12C: MOV v4.16b, v1.16b         | V4 = val_11.y;//m1                      
            // 0x00D1E130: MOV v5.16b, v2.16b         | V5 = val_11.z;//m1                      
            // 0x00D1E134: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1E138: MOV v0.16b, v11.16b        | V0 = val_10.x;//m1                      
            // 0x00D1E13C: MOV v1.16b, v12.16b        | V1 = val_10.y;//m1                      
            // 0x00D1E140: MOV v2.16b, v13.16b        | V2 = val_10.z;//m1                      
            // 0x00D1E144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E148: STP s9, s8, [sp, #4]       | stack[1152921513507442852] = point.y;  stack[1152921513507442856] = point.z;  //  dest_result_addr=1152921513507442852 |  dest_result_addr=1152921513507442856
            // 0x00D1E14C: STR s10, [sp]              | stack[1152921513507442848] = point.x;    //  dest_result_addr=1152921513507442848
            // 0x00D1E150: BL #0x168393c              | X0 = Pathfinding.AstarMath.NearestPointStrict(lineStart:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, lineEnd:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, point:  new UnityEngine.Vector3() {x = point.x, y = point.z, z = val_5.x});
            UnityEngine.Vector3 val_12 = Pathfinding.AstarMath.NearestPointStrict(lineStart:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, lineEnd:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, point:  new UnityEngine.Vector3() {x = point.x, y = point.z, z = val_5.x});
            // 0x00D1E154: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x00D1E158: MOV v11.16b, v0.16b        | V11 = val_12.x;//m1                     
            // 0x00D1E15C: MOV v12.16b, v1.16b        | V12 = val_12.y;//m1                     
            // 0x00D1E160: MOV v13.16b, v2.16b        | V13 = val_12.z;//m1                     
            // 0x00D1E164: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00D1E168: TBZ w8, #0, #0xd1e074      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00D1E16C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1E170: CBNZ w8, #0xd1e074         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00D1E174: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            // 0x00D1E178: B #0xd1e074                |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x00D1E17C: LDR x2, [x25]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
            // 0x00D1E180: ADD w1, w24, #1            | W1 = (val_5.x < 0 ? -1 : val_27 + 1);   
            int val_13 = val_6 + 1;
            // 0x00D1E184: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00D1E188: BL #0x264334c              | X0 = X21.get_Item(index:  int val_13 = val_6 + 1);
            UnityEngine.Vector3 val_14 = X21.Item[val_13];
            // 0x00D1E18C: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
            val_22 = null;
            // 0x00D1E190: MOV v11.16b, v0.16b        | V11 = val_14.x;//m1                     
            val_20 = val_14.x;
            // 0x00D1E194: MOV v12.16b, v1.16b        | V12 = val_14.y;//m1                     
            val_21 = val_14.y;
            label_6:
            // 0x00D1E198: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00D1E19C: MOV v13.16b, v2.16b        | V13 = val_14.z;//m1                     
            // 0x00D1E1A0: TBZ w8, #0, #0xd1e1b0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00D1E1A4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00D1E1A8: CBNZ w8, #0xd1e1b0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00D1E1AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_19:
            // 0x00D1E1B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00D1E1B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E1B8: MOV v0.16b, v11.16b        | V0 = val_14.x;//m1                      
            // 0x00D1E1BC: MOV v1.16b, v12.16b        | V1 = val_14.y;//m1                      
            // 0x00D1E1C0: MOV v2.16b, v13.16b        | V2 = val_14.z;//m1                      
            // 0x00D1E1C4: MOV v3.16b, v10.16b        | V3 = point.x;//m1                       
            // 0x00D1E1C8: MOV v4.16b, v9.16b         | V4 = point.y;//m1                       
            // 0x00D1E1CC: MOV v5.16b, v8.16b         | V5 = point.z;//m1                       
            // 0x00D1E1D0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_20, y = val_21, z = val_14.z}, b:  new UnityEngine.Vector3() {x = point.x, y = point.y, z = point.z});
            UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_20, y = val_21, z = val_14.z}, b:  new UnityEngine.Vector3() {x = point.x, y = point.y, z = point.z});
            label_9:
            // 0x00D1E1D4: SUB sp, x29, #0x80         | SP = (1152921513507443008 - 128) = 1152921513507442880 (0x10000002128450C0);
            // 0x00D1E1D8: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1E1DC: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1E1E0: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1E1E4: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
            // 0x00D1E1E8: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
            // 0x00D1E1EC: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x00D1E1F0: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x00D1E1F4: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x00D1E1F8: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
            // 0x00D1E1FC: RET                        |  return new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z};
            return new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z};
            //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
        
        }
    
    }

}
