using UnityEngine;
public class buffCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public float lasttime; //  0x00000014
    public int type; //  0x00000018
    public bool break_skill; //  0x0000001C
    public int anti_type; //  0x00000020
    public bool anti_repeat; //  0x00000024
    public int main_type; //  0x00000028
    public bool self_repeat; //  0x0000002C
    public bool self_replace; //  0x0000002D
    public int fun1; //  0x00000030
    public int para1; //  0x00000034
    public int fun2; //  0x00000038
    public int para2; //  0x0000003C
    public int fun3; //  0x00000040
    public int para3; //  0x00000044
    public int fun4; //  0x00000048
    public int para4; //  0x0000004C
    public int effid; //  0x00000050
    public bool permanent; //  0x00000054
    public string name; //  0x00000058
    public float range; //  0x00000060
    public int forcountry; //  0x00000064
    public int forelement; //  0x00000068
    public int forsex; //  0x0000006C
    public int atktype; //  0x00000070
    public int forBoss; //  0x00000074
    public int forenv; //  0x00000078
    public int showwordfortype; //  0x0000007C
    public string effect_text; //  0x00000080
    public string path_text; //  0x00000088
    public string heaven_awaken; //  0x00000090
    public int icon_effect; //  0x00000098
    public int buff_layer; //  0x0000009C
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B9744C (12153932), len: 8  VirtAddr: 0x00B9744C RVA: 0x00B9744C token: 100690508 methodIndex: 25270 delegateWrapperIndex: 0 methodInvoker: 0
    public buffCfg()
    {
        //
        // Disasemble & Code
        // 0x00B9744C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B97450: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B97454 (12153940), len: 2432  VirtAddr: 0x00B97454 RVA: 0x00B97454 token: 100690509 methodIndex: 25271 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00B97454: STP x22, x21, [sp, #-0x30]! | stack[1152921514529530448] = ???;  stack[1152921514529530456] = ???;  //  dest_result_addr=1152921514529530448 |  dest_result_addr=1152921514529530456
        // 0x00B97458: STP x20, x19, [sp, #0x10]  | stack[1152921514529530464] = ???;  stack[1152921514529530472] = ???;  //  dest_result_addr=1152921514529530464 |  dest_result_addr=1152921514529530472
        // 0x00B9745C: STP x29, x30, [sp, #0x20]  | stack[1152921514529530480] = ???;  stack[1152921514529530488] = ???;  //  dest_result_addr=1152921514529530480 |  dest_result_addr=1152921514529530488
        // 0x00B97460: ADD x29, sp, #0x20         | X29 = (1152921514529530448 + 32) = 1152921514529530480 (0x100000024F702270);
        // 0x00B97464: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B97468: LDRB w8, [x21, #0xa7c]     | W8 = (bool)static_value_03733A7C;       
        // 0x00B9746C: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00B97470: MOV x19, x0                | X19 = 1152921514529542496 (0x100000024F705160);//ML01
        // 0x00B97474: TBNZ w8, #0, #0xb97490     | if (static_value_03733A7C == true) goto label_0;
        // 0x00B97478: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
        // 0x00B9747C: LDR x8, [x8, #0x290]       | X8 = 0x2B8FA60;                         
        // 0x00B97480: LDR w0, [x8]               | W0 = 0x155C;                            
        // 0x00B97484: BL #0x2782188              | X0 = sub_2782188( ?? 0x155C, ????);     
        // 0x00B97488: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9748C: STRB w8, [x21, #0xa7c]     | static_value_03733A7C = true;            //  dest_result_addr=57883260
        label_0:
        // 0x00B97490: CBNZ x20, #0xb97498        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00B97494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x155C, ????);     
        label_1:
        // 0x00B97498: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00B9749C: ADRP x22, #0x3667000       | X22 = 57044992 (0x3667000);             
        // 0x00B974A0: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00B974A4: LDR x22, [x22, #0x90]      | X22 = 1152921510817398768;              
        // 0x00B974A8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B974AC: LDR x1, [x8]               | X1 = "id";                              
        // 0x00B974B0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B974B4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00B974B8: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00B974BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B974C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B974C4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00B974C8: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514529542512
        this.id = val_2;
        // 0x00B974CC: CBZ x20, #0xb97500         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00B974D0: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B974D4: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921510681023168)("lasttime");
        // 0x00B974D8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B974DC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B974E0: LDR x1, [x8]               | X1 = "lasttime";                        
        // 0x00B974E4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "lasttime");  
        string val_3 = _info.Item["lasttime"];
        // 0x00B974E8: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00B974EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B974F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B974F4: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_4 = System.Single.Parse(s:  0);
        // 0x00B974F8: STR s0, [x19, #0x14]       | this.lasttime = val_4;                   //  dest_result_addr=1152921514529542516
        this.lasttime = val_4;
        // 0x00B974FC: B #0xb97534                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00B97500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B97504: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
        // 0x00B97508: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921510681023168)("lasttime");
        // 0x00B9750C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97510: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97514: LDR x1, [x8]               | X1 = "lasttime";                        
        // 0x00B97518: BL #0x23fc26c              | X0 = _info.get_Item(key:  "lasttime");  
        string val_5 = _info.Item["lasttime"];
        // 0x00B9751C: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00B97520: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97524: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97528: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_6 = System.Single.Parse(s:  0);
        // 0x00B9752C: STR s0, [x19, #0x14]       | this.lasttime = val_6;                   //  dest_result_addr=1152921514529542516
        this.lasttime = val_6;
        // 0x00B97530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00B97534: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B97538: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921510122301360)("type");
        // 0x00B9753C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97540: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97544: LDR x1, [x8]               | X1 = "type";                            
        // 0x00B97548: BL #0x23fc26c              | X0 = _info.get_Item(key:  "type");      
        string val_7 = _info.Item["type"];
        // 0x00B9754C: MOV x1, x0                 | X1 = val_7;//m1                         
        // 0x00B97550: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97554: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97558: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_8 = System.Int32.Parse(s:  0);
        // 0x00B9755C: STR w0, [x19, #0x18]       | this.type = val_8;                       //  dest_result_addr=1152921514529542520
        this.type = val_8;
        // 0x00B97560: CBNZ x20, #0xb97568        | if (_info != null) goto label_4;        
        if(_info != null)
        {
            goto label_4;
        }
        // 0x00B97564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_4:
        // 0x00B97568: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x00B9756C: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921514529335664)("break_skill");
        // 0x00B97570: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97574: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97578: LDR x1, [x8]               | X1 = "break_skill";                     
        // 0x00B9757C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "break_skill");
        string val_9 = _info.Item["break_skill"];
        // 0x00B97580: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B97584: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x00B97588: MOV x21, x0                | X21 = val_9;//m1                        
        // 0x00B9758C: LDR x8, [x8]               | X8 = typeof(System.Boolean);            
        // 0x00B97590: LDRB w9, [x8, #0x10a]      | W9 = System.Boolean.__il2cppRuntimeField_10A;
        // 0x00B97594: TBZ w9, #0, #0xb975a8      | if (System.Boolean.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B97598: LDR w9, [x8, #0xbc]        | W9 = System.Boolean.__il2cppRuntimeField_cctor_finished;
        // 0x00B9759C: CBNZ w9, #0xb975a8         | if (System.Boolean.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B975A0: MOV x0, x8                 | X0 = 1152921504608604160 (0x10000000001AD000);//ML01
        // 0x00B975A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Boolean), ????);
        label_6:
        // 0x00B975A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B975AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B975B0: MOV x1, x21                | X1 = val_9;//m1                         
        // 0x00B975B4: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_10 = System.Boolean.Parse(value:  0);
        // 0x00B975B8: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        bool val_11 = val_10;
        // 0x00B975BC: STRB w8, [x19, #0x1c]      | this.break_skill = (val_10 & 1);         //  dest_result_addr=1152921514529542524
        this.break_skill = val_11;
        // 0x00B975C0: CBZ x20, #0xb975f4         | if (_info == null) goto label_7;        
        if(_info == null)
        {
            goto label_7;
        }
        // 0x00B975C4: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00B975C8: LDR x8, [x8, #0x130]       | X8 = (string**)(1152921514529339856)("anti_type");
        // 0x00B975CC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B975D0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B975D4: LDR x1, [x8]               | X1 = "anti_type";                       
        // 0x00B975D8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "anti_type"); 
        string val_12 = _info.Item["anti_type"];
        // 0x00B975DC: MOV x1, x0                 | X1 = val_12;//m1                        
        // 0x00B975E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B975E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B975E8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_13 = System.Int32.Parse(s:  0);
        // 0x00B975EC: STR w0, [x19, #0x20]       | this.anti_type = val_13;                 //  dest_result_addr=1152921514529542528
        this.anti_type = val_13;
        // 0x00B975F0: B #0xb97628                |  goto label_8;                          
        goto label_8;
        label_7:
        // 0x00B975F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B975F8: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00B975FC: LDR x8, [x8, #0x130]       | X8 = (string**)(1152921514529339856)("anti_type");
        // 0x00B97600: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97604: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97608: LDR x1, [x8]               | X1 = "anti_type";                       
        // 0x00B9760C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "anti_type"); 
        string val_14 = _info.Item["anti_type"];
        // 0x00B97610: MOV x1, x0                 | X1 = val_14;//m1                        
        // 0x00B97614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9761C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_15 = System.Int32.Parse(s:  0);
        // 0x00B97620: STR w0, [x19, #0x20]       | this.anti_type = val_15;                 //  dest_result_addr=1152921514529542528
        this.anti_type = val_15;
        // 0x00B97624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_8:
        // 0x00B97628: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B9762C: LDR x8, [x8, #0xe48]       | X8 = (string**)(1152921514529348144)("anti_repeat");
        // 0x00B97630: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97634: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97638: LDR x1, [x8]               | X1 = "anti_repeat";                     
        // 0x00B9763C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "anti_repeat");
        string val_16 = _info.Item["anti_repeat"];
        // 0x00B97640: MOV x1, x0                 | X1 = val_16;//m1                        
        // 0x00B97644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97648: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9764C: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_17 = System.Boolean.Parse(value:  0);
        // 0x00B97650: AND w8, w0, #1             | W8 = (val_17 & 1);                      
        bool val_18 = val_17;
        // 0x00B97654: STRB w8, [x19, #0x24]      | this.anti_repeat = (val_17 & 1);         //  dest_result_addr=1152921514529542532
        this.anti_repeat = val_18;
        // 0x00B97658: CBZ x20, #0xb9768c         | if (_info == null) goto label_9;        
        if(_info == null)
        {
            goto label_9;
        }
        // 0x00B9765C: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00B97660: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921514529352336)("main_type");
        // 0x00B97664: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97668: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B9766C: LDR x1, [x8]               | X1 = "main_type";                       
        // 0x00B97670: BL #0x23fc26c              | X0 = _info.get_Item(key:  "main_type"); 
        string val_19 = _info.Item["main_type"];
        // 0x00B97674: MOV x1, x0                 | X1 = val_19;//m1                        
        // 0x00B97678: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9767C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97680: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_20 = System.Int32.Parse(s:  0);
        // 0x00B97684: STR w0, [x19, #0x28]       | this.main_type = val_20;                 //  dest_result_addr=1152921514529542536
        this.main_type = val_20;
        // 0x00B97688: B #0xb976c0                |  goto label_10;                         
        goto label_10;
        label_9:
        // 0x00B9768C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00B97690: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00B97694: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921514529352336)("main_type");
        // 0x00B97698: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B9769C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B976A0: LDR x1, [x8]               | X1 = "main_type";                       
        // 0x00B976A4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "main_type"); 
        string val_21 = _info.Item["main_type"];
        // 0x00B976A8: MOV x1, x0                 | X1 = val_21;//m1                        
        // 0x00B976AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B976B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B976B4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_22 = System.Int32.Parse(s:  0);
        // 0x00B976B8: STR w0, [x19, #0x28]       | this.main_type = val_22;                 //  dest_result_addr=1152921514529542536
        this.main_type = val_22;
        // 0x00B976BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_10:
        // 0x00B976C0: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
        // 0x00B976C4: LDR x8, [x8, #0xf08]       | X8 = (string**)(1152921514529360624)("self_repeat");
        // 0x00B976C8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B976CC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B976D0: LDR x1, [x8]               | X1 = "self_repeat";                     
        // 0x00B976D4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "self_repeat");
        string val_23 = _info.Item["self_repeat"];
        // 0x00B976D8: MOV x1, x0                 | X1 = val_23;//m1                        
        // 0x00B976DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B976E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B976E4: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_24 = System.Boolean.Parse(value:  0);
        // 0x00B976E8: AND w8, w0, #1             | W8 = (val_24 & 1);                      
        bool val_25 = val_24;
        // 0x00B976EC: STRB w8, [x19, #0x2c]      | this.self_repeat = (val_24 & 1);         //  dest_result_addr=1152921514529542540
        this.self_repeat = val_25;
        // 0x00B976F0: CBZ x20, #0xb97728         | if (_info == null) goto label_11;       
        if(_info == null)
        {
            goto label_11;
        }
        // 0x00B976F4: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00B976F8: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921514529364816)("self_replace");
        // 0x00B976FC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97700: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97704: LDR x1, [x8]               | X1 = "self_replace";                    
        // 0x00B97708: BL #0x23fc26c              | X0 = _info.get_Item(key:  "self_replace");
        string val_26 = _info.Item["self_replace"];
        // 0x00B9770C: MOV x1, x0                 | X1 = val_26;//m1                        
        // 0x00B97710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97714: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97718: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_27 = System.Boolean.Parse(value:  0);
        // 0x00B9771C: AND w8, w0, #1             | W8 = (val_27 & 1);                      
        bool val_28 = val_27;
        // 0x00B97720: STRB w8, [x19, #0x2d]      | this.self_replace = (val_27 & 1);        //  dest_result_addr=1152921514529542541
        this.self_replace = val_28;
        // 0x00B97724: B #0xb97760                |  goto label_12;                         
        goto label_12;
        label_11:
        // 0x00B97728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        // 0x00B9772C: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00B97730: LDR x8, [x8, #0x3a0]       | X8 = (string**)(1152921514529364816)("self_replace");
        // 0x00B97734: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97738: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B9773C: LDR x1, [x8]               | X1 = "self_replace";                    
        // 0x00B97740: BL #0x23fc26c              | X0 = _info.get_Item(key:  "self_replace");
        string val_29 = _info.Item["self_replace"];
        // 0x00B97744: MOV x1, x0                 | X1 = val_29;//m1                        
        // 0x00B97748: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9774C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97750: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_30 = System.Boolean.Parse(value:  0);
        // 0x00B97754: AND w8, w0, #1             | W8 = (val_30 & 1);                      
        bool val_31 = val_30;
        // 0x00B97758: STRB w8, [x19, #0x2d]      | this.self_replace = (val_30 & 1);        //  dest_result_addr=1152921514529542541
        this.self_replace = val_31;
        // 0x00B9775C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_12:
        // 0x00B97760: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00B97764: LDR x8, [x8, #0xe78]       | X8 = (string**)(1152921514529373104)("fun1");
        // 0x00B97768: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B9776C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97770: LDR x1, [x8]               | X1 = "fun1";                            
        // 0x00B97774: BL #0x23fc26c              | X0 = _info.get_Item(key:  "fun1");      
        string val_32 = _info.Item["fun1"];
        // 0x00B97778: MOV x1, x0                 | X1 = val_32;//m1                        
        // 0x00B9777C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97780: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97784: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_33 = System.Int32.Parse(s:  0);
        // 0x00B97788: STR w0, [x19, #0x30]       | this.fun1 = val_33;                      //  dest_result_addr=1152921514529542544
        this.fun1 = val_33;
        // 0x00B9778C: CBZ x20, #0xb977c0         | if (_info == null) goto label_13;       
        if(_info == null)
        {
            goto label_13;
        }
        // 0x00B97790: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B97794: LDR x8, [x8, #0xce8]       | X8 = (string**)(1152921514529377280)("para1");
        // 0x00B97798: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B9779C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B977A0: LDR x1, [x8]               | X1 = "para1";                           
        // 0x00B977A4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para1");     
        string val_34 = _info.Item["para1"];
        // 0x00B977A8: MOV x1, x0                 | X1 = val_34;//m1                        
        // 0x00B977AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B977B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B977B4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_35 = System.Int32.Parse(s:  0);
        // 0x00B977B8: STR w0, [x19, #0x34]       | this.para1 = val_35;                     //  dest_result_addr=1152921514529542548
        this.para1 = val_35;
        // 0x00B977BC: B #0xb977f4                |  goto label_14;                         
        goto label_14;
        label_13:
        // 0x00B977C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        // 0x00B977C4: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B977C8: LDR x8, [x8, #0xce8]       | X8 = (string**)(1152921514529377280)("para1");
        // 0x00B977CC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B977D0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B977D4: LDR x1, [x8]               | X1 = "para1";                           
        // 0x00B977D8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para1");     
        string val_36 = _info.Item["para1"];
        // 0x00B977DC: MOV x1, x0                 | X1 = val_36;//m1                        
        // 0x00B977E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B977E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B977E8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_37 = System.Int32.Parse(s:  0);
        // 0x00B977EC: STR w0, [x19, #0x34]       | this.para1 = val_37;                     //  dest_result_addr=1152921514529542548
        this.para1 = val_37;
        // 0x00B977F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_14:
        // 0x00B977F4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B977F8: LDR x8, [x8, #0xf40]       | X8 = (string**)(1152921514529385552)("fun2");
        // 0x00B977FC: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97800: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97804: LDR x1, [x8]               | X1 = "fun2";                            
        // 0x00B97808: BL #0x23fc26c              | X0 = _info.get_Item(key:  "fun2");      
        string val_38 = _info.Item["fun2"];
        // 0x00B9780C: MOV x1, x0                 | X1 = val_38;//m1                        
        // 0x00B97810: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97814: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97818: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_39 = System.Int32.Parse(s:  0);
        // 0x00B9781C: STR w0, [x19, #0x38]       | this.fun2 = val_39;                      //  dest_result_addr=1152921514529542552
        this.fun2 = val_39;
        // 0x00B97820: CBZ x20, #0xb97854         | if (_info == null) goto label_15;       
        if(_info == null)
        {
            goto label_15;
        }
        // 0x00B97824: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B97828: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921514529389728)("para2");
        // 0x00B9782C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97830: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97834: LDR x1, [x8]               | X1 = "para2";                           
        // 0x00B97838: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para2");     
        string val_40 = _info.Item["para2"];
        // 0x00B9783C: MOV x1, x0                 | X1 = val_40;//m1                        
        // 0x00B97840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97844: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97848: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_41 = System.Int32.Parse(s:  0);
        // 0x00B9784C: STR w0, [x19, #0x3c]       | this.para2 = val_41;                     //  dest_result_addr=1152921514529542556
        this.para2 = val_41;
        // 0x00B97850: B #0xb97888                |  goto label_16;                         
        goto label_16;
        label_15:
        // 0x00B97854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        // 0x00B97858: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B9785C: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921514529389728)("para2");
        // 0x00B97860: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97864: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97868: LDR x1, [x8]               | X1 = "para2";                           
        // 0x00B9786C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para2");     
        string val_42 = _info.Item["para2"];
        // 0x00B97870: MOV x1, x0                 | X1 = val_42;//m1                        
        // 0x00B97874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97878: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9787C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_43 = System.Int32.Parse(s:  0);
        // 0x00B97880: STR w0, [x19, #0x3c]       | this.para2 = val_43;                     //  dest_result_addr=1152921514529542556
        this.para2 = val_43;
        // 0x00B97884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_16:
        // 0x00B97888: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B9788C: LDR x8, [x8, #0x2a8]       | X8 = (string**)(1152921514529398000)("fun3");
        // 0x00B97890: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97894: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97898: LDR x1, [x8]               | X1 = "fun3";                            
        // 0x00B9789C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "fun3");      
        string val_44 = _info.Item["fun3"];
        // 0x00B978A0: MOV x1, x0                 | X1 = val_44;//m1                        
        // 0x00B978A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B978A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B978AC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_45 = System.Int32.Parse(s:  0);
        // 0x00B978B0: STR w0, [x19, #0x40]       | this.fun3 = val_45;                      //  dest_result_addr=1152921514529542560
        this.fun3 = val_45;
        // 0x00B978B4: CBZ x20, #0xb978e8         | if (_info == null) goto label_17;       
        if(_info == null)
        {
            goto label_17;
        }
        // 0x00B978B8: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B978BC: LDR x8, [x8, #0xc18]       | X8 = (string**)(1152921514529402176)("para3");
        // 0x00B978C0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B978C4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B978C8: LDR x1, [x8]               | X1 = "para3";                           
        // 0x00B978CC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para3");     
        string val_46 = _info.Item["para3"];
        // 0x00B978D0: MOV x1, x0                 | X1 = val_46;//m1                        
        // 0x00B978D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B978D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B978DC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_47 = System.Int32.Parse(s:  0);
        // 0x00B978E0: STR w0, [x19, #0x44]       | this.para3 = val_47;                     //  dest_result_addr=1152921514529542564
        this.para3 = val_47;
        // 0x00B978E4: B #0xb9791c                |  goto label_18;                         
        goto label_18;
        label_17:
        // 0x00B978E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        // 0x00B978EC: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B978F0: LDR x8, [x8, #0xc18]       | X8 = (string**)(1152921514529402176)("para3");
        // 0x00B978F4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B978F8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B978FC: LDR x1, [x8]               | X1 = "para3";                           
        // 0x00B97900: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para3");     
        string val_48 = _info.Item["para3"];
        // 0x00B97904: MOV x1, x0                 | X1 = val_48;//m1                        
        // 0x00B97908: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9790C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97910: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_49 = System.Int32.Parse(s:  0);
        // 0x00B97914: STR w0, [x19, #0x44]       | this.para3 = val_49;                     //  dest_result_addr=1152921514529542564
        this.para3 = val_49;
        // 0x00B97918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_18:
        // 0x00B9791C: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00B97920: LDR x8, [x8, #0x100]       | X8 = (string**)(1152921514529410448)("fun4");
        // 0x00B97924: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97928: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B9792C: LDR x1, [x8]               | X1 = "fun4";                            
        // 0x00B97930: BL #0x23fc26c              | X0 = _info.get_Item(key:  "fun4");      
        string val_50 = _info.Item["fun4"];
        // 0x00B97934: MOV x1, x0                 | X1 = val_50;//m1                        
        // 0x00B97938: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9793C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97940: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_51 = System.Int32.Parse(s:  0);
        // 0x00B97944: STR w0, [x19, #0x48]       | this.fun4 = val_51;                      //  dest_result_addr=1152921514529542568
        this.fun4 = val_51;
        // 0x00B97948: CBZ x20, #0xb9797c         | if (_info == null) goto label_19;       
        if(_info == null)
        {
            goto label_19;
        }
        // 0x00B9794C: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00B97950: LDR x8, [x8, #0x430]       | X8 = (string**)(1152921514529414624)("para4");
        // 0x00B97954: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97958: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B9795C: LDR x1, [x8]               | X1 = "para4";                           
        // 0x00B97960: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para4");     
        string val_52 = _info.Item["para4"];
        // 0x00B97964: MOV x1, x0                 | X1 = val_52;//m1                        
        // 0x00B97968: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9796C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97970: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_53 = System.Int32.Parse(s:  0);
        // 0x00B97974: STR w0, [x19, #0x4c]       | this.para4 = val_53;                     //  dest_result_addr=1152921514529542572
        this.para4 = val_53;
        // 0x00B97978: B #0xb979b0                |  goto label_20;                         
        goto label_20;
        label_19:
        // 0x00B9797C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        // 0x00B97980: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00B97984: LDR x8, [x8, #0x430]       | X8 = (string**)(1152921514529414624)("para4");
        // 0x00B97988: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B9798C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97990: LDR x1, [x8]               | X1 = "para4";                           
        // 0x00B97994: BL #0x23fc26c              | X0 = _info.get_Item(key:  "para4");     
        string val_54 = _info.Item["para4"];
        // 0x00B97998: MOV x1, x0                 | X1 = val_54;//m1                        
        // 0x00B9799C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B979A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B979A4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_55 = System.Int32.Parse(s:  0);
        // 0x00B979A8: STR w0, [x19, #0x4c]       | this.para4 = val_55;                     //  dest_result_addr=1152921514529542572
        this.para4 = val_55;
        // 0x00B979AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_20:
        // 0x00B979B0: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B979B4: LDR x8, [x8, #0xb90]       | X8 = (string**)(1152921514529422896)("effid");
        // 0x00B979B8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B979BC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B979C0: LDR x1, [x8]               | X1 = "effid";                           
        // 0x00B979C4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "effid");     
        string val_56 = _info.Item["effid"];
        // 0x00B979C8: MOV x1, x0                 | X1 = val_56;//m1                        
        // 0x00B979CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B979D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B979D4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_57 = System.Int32.Parse(s:  0);
        // 0x00B979D8: STR w0, [x19, #0x50]       | this.effid = val_57;                     //  dest_result_addr=1152921514529542576
        this.effid = val_57;
        // 0x00B979DC: CBZ x20, #0xb97a14         | if (_info == null) goto label_21;       
        if(_info == null)
        {
            goto label_21;
        }
        // 0x00B979E0: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x00B979E4: LDR x8, [x8, #0x968]       | X8 = (string**)(1152921514529427072)("permanent");
        // 0x00B979E8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B979EC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B979F0: LDR x1, [x8]               | X1 = "permanent";                       
        // 0x00B979F4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "permanent"); 
        string val_58 = _info.Item["permanent"];
        // 0x00B979F8: MOV x1, x0                 | X1 = val_58;//m1                        
        // 0x00B979FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97A00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97A04: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_59 = System.Boolean.Parse(value:  0);
        // 0x00B97A08: AND w8, w0, #1             | W8 = (val_59 & 1);                      
        bool val_60 = val_59;
        // 0x00B97A0C: STRB w8, [x19, #0x54]      | this.permanent = (val_59 & 1);           //  dest_result_addr=1152921514529542580
        this.permanent = val_60;
        // 0x00B97A10: B #0xb97a4c                |  goto label_22;                         
        goto label_22;
        label_21:
        // 0x00B97A14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
        // 0x00B97A18: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
        // 0x00B97A1C: LDR x8, [x8, #0x968]       | X8 = (string**)(1152921514529427072)("permanent");
        // 0x00B97A20: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97A24: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97A28: LDR x1, [x8]               | X1 = "permanent";                       
        // 0x00B97A2C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "permanent"); 
        string val_61 = _info.Item["permanent"];
        // 0x00B97A30: MOV x1, x0                 | X1 = val_61;//m1                        
        // 0x00B97A34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97A38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97A3C: BL #0x18d4a40              | X0 = System.Boolean.Parse(value:  0);   
        bool val_62 = System.Boolean.Parse(value:  0);
        // 0x00B97A40: AND w8, w0, #1             | W8 = (val_62 & 1);                      
        bool val_63 = val_62;
        // 0x00B97A44: STRB w8, [x19, #0x54]      | this.permanent = (val_62 & 1);           //  dest_result_addr=1152921514529542580
        this.permanent = val_63;
        // 0x00B97A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
        label_22:
        // 0x00B97A4C: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B97A50: LDR x8, [x8, #0x5f0]       | X8 = (string**)(1152921509593945888)("name");
        // 0x00B97A54: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97A58: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97A5C: LDR x1, [x8]               | X1 = "name";                            
        // 0x00B97A60: BL #0x23fc26c              | X0 = _info.get_Item(key:  "name");      
        string val_64 = _info.Item["name"];
        // 0x00B97A64: STR x0, [x19, #0x58]       | this.name = val_64;                      //  dest_result_addr=1152921514529542584
        this.name = val_64;
        // 0x00B97A68: CBZ x20, #0xb97a9c         | if (_info == null) goto label_23;       
        if(_info == null)
        {
            goto label_23;
        }
        // 0x00B97A6C: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B97A70: LDR x8, [x8, #0x748]       | X8 = (string**)(1152921514529439456)("range");
        // 0x00B97A74: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97A78: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97A7C: LDR x1, [x8]               | X1 = "range";                           
        // 0x00B97A80: BL #0x23fc26c              | X0 = _info.get_Item(key:  "range");     
        string val_65 = _info.Item["range"];
        // 0x00B97A84: MOV x1, x0                 | X1 = val_65;//m1                        
        // 0x00B97A88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97A8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97A90: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_66 = System.Single.Parse(s:  0);
        // 0x00B97A94: STR s0, [x19, #0x60]       | this.range = val_66;                     //  dest_result_addr=1152921514529542592
        this.range = val_66;
        // 0x00B97A98: B #0xb97ad0                |  goto label_24;                         
        goto label_24;
        label_23:
        // 0x00B97A9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        // 0x00B97AA0: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00B97AA4: LDR x8, [x8, #0x748]       | X8 = (string**)(1152921514529439456)("range");
        // 0x00B97AA8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97AAC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97AB0: LDR x1, [x8]               | X1 = "range";                           
        // 0x00B97AB4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "range");     
        string val_67 = _info.Item["range"];
        // 0x00B97AB8: MOV x1, x0                 | X1 = val_67;//m1                        
        // 0x00B97ABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97AC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97AC4: BL #0x18a7260              | X0 = System.Single.Parse(s:  0);        
        float val_68 = System.Single.Parse(s:  0);
        // 0x00B97AC8: STR s0, [x19, #0x60]       | this.range = val_68;                     //  dest_result_addr=1152921514529542592
        this.range = val_68;
        // 0x00B97ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_24:
        // 0x00B97AD0: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
        // 0x00B97AD4: LDR x8, [x8, #0x2a8]       | X8 = (string**)(1152921514529447728)("forcountry");
        // 0x00B97AD8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97ADC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97AE0: LDR x1, [x8]               | X1 = "forcountry";                      
        // 0x00B97AE4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forcountry");
        string val_69 = _info.Item["forcountry"];
        // 0x00B97AE8: MOV x1, x0                 | X1 = val_69;//m1                        
        // 0x00B97AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97AF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97AF4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_70 = System.Int32.Parse(s:  0);
        // 0x00B97AF8: STR w0, [x19, #0x64]       | this.forcountry = val_70;                //  dest_result_addr=1152921514529542596
        this.forcountry = val_70;
        // 0x00B97AFC: CBZ x20, #0xb97b30         | if (_info == null) goto label_25;       
        if(_info == null)
        {
            goto label_25;
        }
        // 0x00B97B00: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B97B04: LDR x8, [x8, #0xb58]       | X8 = (string**)(1152921514529451920)("forelement");
        // 0x00B97B08: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97B0C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97B10: LDR x1, [x8]               | X1 = "forelement";                      
        // 0x00B97B14: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forelement");
        string val_71 = _info.Item["forelement"];
        // 0x00B97B18: MOV x1, x0                 | X1 = val_71;//m1                        
        // 0x00B97B1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97B20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97B24: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_72 = System.Int32.Parse(s:  0);
        // 0x00B97B28: STR w0, [x19, #0x68]       | this.forelement = val_72;                //  dest_result_addr=1152921514529542600
        this.forelement = val_72;
        // 0x00B97B2C: B #0xb97b64                |  goto label_26;                         
        goto label_26;
        label_25:
        // 0x00B97B30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        // 0x00B97B34: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B97B38: LDR x8, [x8, #0xb58]       | X8 = (string**)(1152921514529451920)("forelement");
        // 0x00B97B3C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97B40: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97B44: LDR x1, [x8]               | X1 = "forelement";                      
        // 0x00B97B48: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forelement");
        string val_73 = _info.Item["forelement"];
        // 0x00B97B4C: MOV x1, x0                 | X1 = val_73;//m1                        
        // 0x00B97B50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97B54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97B58: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_74 = System.Int32.Parse(s:  0);
        // 0x00B97B5C: STR w0, [x19, #0x68]       | this.forelement = val_74;                //  dest_result_addr=1152921514529542600
        this.forelement = val_74;
        // 0x00B97B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_26:
        // 0x00B97B64: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B97B68: LDR x8, [x8, #0xbf0]       | X8 = (string**)(1152921514529460208)("forsex");
        // 0x00B97B6C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97B70: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97B74: LDR x1, [x8]               | X1 = "forsex";                          
        // 0x00B97B78: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forsex");    
        string val_75 = _info.Item["forsex"];
        // 0x00B97B7C: MOV x1, x0                 | X1 = val_75;//m1                        
        // 0x00B97B80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97B84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97B88: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_76 = System.Int32.Parse(s:  0);
        // 0x00B97B8C: STR w0, [x19, #0x6c]       | this.forsex = val_76;                    //  dest_result_addr=1152921514529542604
        this.forsex = val_76;
        // 0x00B97B90: CBZ x20, #0xb97bc4         | if (_info == null) goto label_27;       
        if(_info == null)
        {
            goto label_27;
        }
        // 0x00B97B94: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B97B98: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921514529464384)("atktype");
        // 0x00B97B9C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97BA0: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97BA4: LDR x1, [x8]               | X1 = "atktype";                         
        // 0x00B97BA8: BL #0x23fc26c              | X0 = _info.get_Item(key:  "atktype");   
        string val_77 = _info.Item["atktype"];
        // 0x00B97BAC: MOV x1, x0                 | X1 = val_77;//m1                        
        // 0x00B97BB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97BB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97BB8: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_78 = System.Int32.Parse(s:  0);
        // 0x00B97BBC: STR w0, [x19, #0x70]       | this.atktype = val_78;                   //  dest_result_addr=1152921514529542608
        this.atktype = val_78;
        // 0x00B97BC0: B #0xb97bf8                |  goto label_28;                         
        goto label_28;
        label_27:
        // 0x00B97BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        // 0x00B97BC8: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B97BCC: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921514529464384)("atktype");
        // 0x00B97BD0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97BD4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97BD8: LDR x1, [x8]               | X1 = "atktype";                         
        // 0x00B97BDC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "atktype");   
        string val_79 = _info.Item["atktype"];
        // 0x00B97BE0: MOV x1, x0                 | X1 = val_79;//m1                        
        // 0x00B97BE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97BE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97BEC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_80 = System.Int32.Parse(s:  0);
        // 0x00B97BF0: STR w0, [x19, #0x70]       | this.atktype = val_80;                   //  dest_result_addr=1152921514529542608
        this.atktype = val_80;
        // 0x00B97BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_28:
        // 0x00B97BF8: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x00B97BFC: LDR x8, [x8, #0xe10]       | X8 = (string**)(1152921514529472672)("forBoss");
        // 0x00B97C00: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97C04: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97C08: LDR x1, [x8]               | X1 = "forBoss";                         
        // 0x00B97C0C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forBoss");   
        string val_81 = _info.Item["forBoss"];
        // 0x00B97C10: MOV x1, x0                 | X1 = val_81;//m1                        
        // 0x00B97C14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97C18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97C1C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_82 = System.Int32.Parse(s:  0);
        // 0x00B97C20: STR w0, [x19, #0x74]       | this.forBoss = val_82;                   //  dest_result_addr=1152921514529542612
        this.forBoss = val_82;
        // 0x00B97C24: CBZ x20, #0xb97c58         | if (_info == null) goto label_29;       
        if(_info == null)
        {
            goto label_29;
        }
        // 0x00B97C28: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
        // 0x00B97C2C: LDR x8, [x8, #0xd0]        | X8 = (string**)(1152921514529476864)("forenv");
        // 0x00B97C30: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97C34: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97C38: LDR x1, [x8]               | X1 = "forenv";                          
        // 0x00B97C3C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forenv");    
        string val_83 = _info.Item["forenv"];
        // 0x00B97C40: MOV x1, x0                 | X1 = val_83;//m1                        
        // 0x00B97C44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97C48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97C4C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_84 = System.Int32.Parse(s:  0);
        // 0x00B97C50: STR w0, [x19, #0x78]       | this.forenv = val_84;                    //  dest_result_addr=1152921514529542616
        this.forenv = val_84;
        // 0x00B97C54: B #0xb97c8c                |  goto label_30;                         
        goto label_30;
        label_29:
        // 0x00B97C58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
        // 0x00B97C5C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
        // 0x00B97C60: LDR x8, [x8, #0xd0]        | X8 = (string**)(1152921514529476864)("forenv");
        // 0x00B97C64: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97C68: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97C6C: LDR x1, [x8]               | X1 = "forenv";                          
        // 0x00B97C70: BL #0x23fc26c              | X0 = _info.get_Item(key:  "forenv");    
        string val_85 = _info.Item["forenv"];
        // 0x00B97C74: MOV x1, x0                 | X1 = val_85;//m1                        
        // 0x00B97C78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97C7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97C80: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_86 = System.Int32.Parse(s:  0);
        // 0x00B97C84: STR w0, [x19, #0x78]       | this.forenv = val_86;                    //  dest_result_addr=1152921514529542616
        this.forenv = val_86;
        // 0x00B97C88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_86, ????);     
        label_30:
        // 0x00B97C8C: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B97C90: LDR x8, [x8, #0x6f0]       | X8 = (string**)(1152921514529485136)("showwordfortype");
        // 0x00B97C94: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97C98: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97C9C: LDR x1, [x8]               | X1 = "showwordfortype";                 
        // 0x00B97CA0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "showwordfortype");
        string val_87 = _info.Item["showwordfortype"];
        // 0x00B97CA4: MOV x1, x0                 | X1 = val_87;//m1                        
        // 0x00B97CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97CB0: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_88 = System.Int32.Parse(s:  0);
        // 0x00B97CB4: STR w0, [x19, #0x7c]       | this.showwordfortype = val_88;           //  dest_result_addr=1152921514529542620
        this.showwordfortype = val_88;
        // 0x00B97CB8: CBZ x20, #0xb97cdc         | if (_info == null) goto label_31;       
        if(_info == null)
        {
            goto label_31;
        }
        // 0x00B97CBC: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B97CC0: LDR x8, [x8, #0xe80]       | X8 = (string**)(1152921514529489344)("effect_text");
        // 0x00B97CC4: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97CC8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97CCC: LDR x1, [x8]               | X1 = "effect_text";                     
        // 0x00B97CD0: BL #0x23fc26c              | X0 = _info.get_Item(key:  "effect_text");
        string val_89 = _info.Item["effect_text"];
        // 0x00B97CD4: STR x0, [x19, #0x80]       | this.effect_text = val_89;               //  dest_result_addr=1152921514529542624
        this.effect_text = val_89;
        // 0x00B97CD8: B #0xb97d00                |  goto label_32;                         
        goto label_32;
        label_31:
        // 0x00B97CDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_88, ????);     
        // 0x00B97CE0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B97CE4: LDR x8, [x8, #0xe80]       | X8 = (string**)(1152921514529489344)("effect_text");
        // 0x00B97CE8: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97CEC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97CF0: LDR x1, [x8]               | X1 = "effect_text";                     
        // 0x00B97CF4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "effect_text");
        string val_90 = _info.Item["effect_text"];
        // 0x00B97CF8: STR x0, [x19, #0x80]       | this.effect_text = val_90;               //  dest_result_addr=1152921514529542624
        this.effect_text = val_90;
        // 0x00B97CFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_90, ????);     
        label_32:
        // 0x00B97D00: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B97D04: LDR x8, [x8, #0x970]       | X8 = (string**)(1152921514529497632)("path_text");
        // 0x00B97D08: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97D0C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97D10: LDR x1, [x8]               | X1 = "path_text";                       
        // 0x00B97D14: BL #0x23fc26c              | X0 = _info.get_Item(key:  "path_text"); 
        string val_91 = _info.Item["path_text"];
        // 0x00B97D18: STR x0, [x19, #0x88]       | this.path_text = val_91;                 //  dest_result_addr=1152921514529542632
        this.path_text = val_91;
        // 0x00B97D1C: CBZ x20, #0xb97d40         | if (_info == null) goto label_33;       
        if(_info == null)
        {
            goto label_33;
        }
        // 0x00B97D20: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B97D24: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921514529501824)("heaven_awaken");
        // 0x00B97D28: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97D2C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97D30: LDR x1, [x8]               | X1 = "heaven_awaken";                   
        // 0x00B97D34: BL #0x23fc26c              | X0 = _info.get_Item(key:  "heaven_awaken");
        string val_92 = _info.Item["heaven_awaken"];
        // 0x00B97D38: STR x0, [x19, #0x90]       | this.heaven_awaken = val_92;             //  dest_result_addr=1152921514529542640
        this.heaven_awaken = val_92;
        // 0x00B97D3C: B #0xb97d64                |  goto label_34;                         
        goto label_34;
        label_33:
        // 0x00B97D40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_91, ????);     
        // 0x00B97D44: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B97D48: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921514529501824)("heaven_awaken");
        // 0x00B97D4C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97D50: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97D54: LDR x1, [x8]               | X1 = "heaven_awaken";                   
        // 0x00B97D58: BL #0x23fc26c              | X0 = _info.get_Item(key:  "heaven_awaken");
        string val_93 = _info.Item["heaven_awaken"];
        // 0x00B97D5C: STR x0, [x19, #0x90]       | this.heaven_awaken = val_93;             //  dest_result_addr=1152921514529542640
        this.heaven_awaken = val_93;
        // 0x00B97D60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
        label_34:
        // 0x00B97D64: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
        // 0x00B97D68: LDR x8, [x8, #0x220]       | X8 = (string**)(1152921514529510112)("icon_effect");
        // 0x00B97D6C: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97D70: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97D74: LDR x1, [x8]               | X1 = "icon_effect";                     
        // 0x00B97D78: BL #0x23fc26c              | X0 = _info.get_Item(key:  "icon_effect");
        string val_94 = _info.Item["icon_effect"];
        // 0x00B97D7C: MOV x1, x0                 | X1 = val_94;//m1                        
        // 0x00B97D80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97D84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97D88: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_95 = System.Int32.Parse(s:  0);
        // 0x00B97D8C: STR w0, [x19, #0x98]       | this.icon_effect = val_95;               //  dest_result_addr=1152921514529542648
        this.icon_effect = val_95;
        // 0x00B97D90: CBNZ x20, #0xb97d98        | if (_info != null) goto label_35;       
        if(_info != null)
        {
            goto label_35;
        }
        // 0x00B97D94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_95, ????);     
        label_35:
        // 0x00B97D98: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
        // 0x00B97D9C: LDR x8, [x8, #0xa98]       | X8 = (string**)(1152921514529514304)("buff_layer");
        // 0x00B97DA0: LDR x2, [x22]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B97DA4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B97DA8: LDR x1, [x8]               | X1 = "buff_layer";                      
        // 0x00B97DAC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "buff_layer");
        string val_96 = _info.Item["buff_layer"];
        // 0x00B97DB0: MOV x1, x0                 | X1 = val_96;//m1                        
        // 0x00B97DB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B97DB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B97DBC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_97 = System.Int32.Parse(s:  0);
        // 0x00B97DC0: STR w0, [x19, #0x9c]       | this.buff_layer = val_97;                //  dest_result_addr=1152921514529542652
        this.buff_layer = val_97;
        // 0x00B97DC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B97DC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B97DCC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B97DD0: RET                        |  return;                                
        return;
    
    }

}
