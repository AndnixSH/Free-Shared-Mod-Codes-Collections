using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AIPath_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache14; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache15; // static_offset: 0x000000A8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache16; // static_offset: 0x000000B0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache17; // static_offset: 0x000000B8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache18; // static_offset: 0x000000C0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache19; // static_offset: 0x000000C8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1A; // static_offset: 0x000000D0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1B; // static_offset: 0x000000D8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1C; // static_offset: 0x000000E0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1D; // static_offset: 0x000000E8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1E; // static_offset: 0x000000F0
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1F; // static_offset: 0x000000F8
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache20; // static_offset: 0x00000100
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache21; // static_offset: 0x00000108
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache22; // static_offset: 0x00000110
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache23; // static_offset: 0x00000118
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache24; // static_offset: 0x00000120
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache25; // static_offset: 0x00000128
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache26; // static_offset: 0x00000130
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache27; // static_offset: 0x00000138
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache28; // static_offset: 0x00000140
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BB121C (12259868), len: 8  VirtAddr: 0x00BB121C RVA: 0x00BB121C token: 100663685 methodIndex: 29730 delegateWrapperIndex: 0 methodInvoker: 0
        public AIPath_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BB121C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1220: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB1224 (12259876), len: 6776  VirtAddr: 0x00BB1224 RVA: 0x00BB1224 token: 100663686 methodIndex: 29731 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_56;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_57;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_58;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_59;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_60;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_61;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_62;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_63;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_64;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_65;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_66;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_67;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_68;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_69;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_70;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_71;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_72;
            // 0x00BB1224: STP x26, x25, [sp, #-0x50]! | stack[1152921510033389440] = ???;  stack[1152921510033389448] = ???;  //  dest_result_addr=1152921510033389440 |  dest_result_addr=1152921510033389448
            // 0x00BB1228: STP x24, x23, [sp, #0x10]  | stack[1152921510033389456] = ???;  stack[1152921510033389464] = ???;  //  dest_result_addr=1152921510033389456 |  dest_result_addr=1152921510033389464
            // 0x00BB122C: STP x22, x21, [sp, #0x20]  | stack[1152921510033389472] = ???;  stack[1152921510033389480] = ???;  //  dest_result_addr=1152921510033389472 |  dest_result_addr=1152921510033389480
            // 0x00BB1230: STP x20, x19, [sp, #0x30]  | stack[1152921510033389488] = ???;  stack[1152921510033389496] = ???;  //  dest_result_addr=1152921510033389488 |  dest_result_addr=1152921510033389496
            // 0x00BB1234: STP x29, x30, [sp, #0x40]  | stack[1152921510033389504] = ???;  stack[1152921510033389512] = ???;  //  dest_result_addr=1152921510033389504 |  dest_result_addr=1152921510033389512
            // 0x00BB1238: ADD x29, sp, #0x40         | X29 = (1152921510033389440 + 64) = 1152921510033389504 (0x10000001437277C0);
            // 0x00BB123C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB1240: LDRB w8, [x20, #0xb17]     | W8 = (bool)static_value_03733B17;       
            // 0x00BB1244: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB1248: TBNZ w8, #0, #0xbb1264     | if (static_value_03733B17 == true) goto label_0;
            // 0x00BB124C: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00BB1250: LDR x8, [x8, #0x410]       | X8 = 0x2B8AB74;                         
            // 0x00BB1254: LDR w0, [x8]               | W0 = 0x19B;                             
            // 0x00BB1258: BL #0x2782188              | X0 = sub_2782188( ?? 0x19B, ????);      
            // 0x00BB125C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB1260: STRB w8, [x20, #0xb17]     | static_value_03733B17 = true;            //  dest_result_addr=57883415
            label_0:
            // 0x00BB1264: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00BB1268: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x00BB126C: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BB1270: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00BB1274: LDR x8, [x8, #0x160]       | X8 = 1152921504835227648;               
            // 0x00BB1278: LDR x20, [x8]              | X20 = typeof(AIPath);                   
            // 0x00BB127C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB1280: TBZ w8, #0, #0xbb1290      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BB1284: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB1288: CBNZ w8, #0xbb1290         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BB128C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BB1290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB1294: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB1298: MOV x1, x20                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB129C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB12A0: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x00BB12A4: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x00BB12A8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB12AC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB12B0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB12B4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB12B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB12BC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB12C0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB12C4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB12C8: CBNZ x20, #0xbb12d0        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BB12CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x00BB12D0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00BB12D4: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921510033279824)("get_canMove");
            // 0x00BB12D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB12DC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB12E0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB12E4: LDR x1, [x8]               | X1 = "get_canMove";                     
            // 0x00BB12E8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB12EC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB12F0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB12F4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_canMove", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_canMove", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB12F8: ADRP x24, #0x360d000       | X24 = 56676352 (0x360D000);             
            // 0x00BB12FC: LDR x24, [x24, #0xf40]     | X24 = 1152921504782565376;              
            // 0x00BB1300: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BB1304: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1308: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB130C: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0;
            // 0x00BB1310: CBNZ x22, #0xbb135c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0) != null)
            {
                goto label_4;
            }
            // 0x00BB1314: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BB1318: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB131C: LDR x8, [x8, #0x380]       | X8 = 1152921510033284016;               
            // 0x00BB1320: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1324: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_canMove_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1328: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x00BB132C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1334: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1338: MOV x2, x22                | X2 = 1152921510033284016 (0x100000014370DBB0);//ML01
            // 0x00BB133C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_3;
            // 0x00BB1340: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_canMove_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_canMove_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1344: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1348: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB134C: STR x23, [x8]              | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569472
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0 = val_56;
            // 0x00BB1350: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1354: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1358: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_4:
            // 0x00BB135C: CBNZ x19, #0xbb1364        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BB1360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_canMove_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x00BB1364: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1368: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB136C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BB1370: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1374: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache0);
            // 0x00BB1378: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB137C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1380: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB1384: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB1388: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB138C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB1390: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x00BB1394: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB1398: LDR x9, [x9, #0xcb8]       | X9 = 1152921504608604160;               
            // 0x00BB139C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB13A0: LDR x22, [x9]              | X22 = typeof(System.Boolean);           
            // 0x00BB13A4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB13A8: TBZ w9, #0, #0xbb13bc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB13AC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB13B0: CBNZ w9, #0xbb13bc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB13B4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB13B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x00BB13BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB13C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB13C4: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x00BB13C8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB13CC: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BB13D0: CBNZ x21, #0xbb13d8        | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x00BB13D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x00BB13D8: CBZ x22, #0xbb13fc         | if (val_4 == null) goto label_10;       
            if(val_4 == null)
            {
                goto label_10;
            }
            // 0x00BB13DC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB13E0: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00BB13E4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB13E8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00BB13EC: CBNZ x0, #0xbb13fc         | if (val_4 != null) goto label_10;       
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x00BB13F0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00BB13F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB13F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_10:
            // 0x00BB13FC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB1400: CBNZ w8, #0xbb1410         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_11;
            // 0x00BB1404: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00BB1408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB140C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_11:
            // 0x00BB1410: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;
            // 0x00BB1414: CBNZ x20, #0xbb141c        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BB1418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x00BB141C: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00BB1420: LDR x8, [x8, #0x4a8]       | X8 = (string**)(1152921510033289136)("set_canMove");
            // 0x00BB1424: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1428: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB142C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1430: LDR x1, [x8]               | X1 = "set_canMove";                     
            // 0x00BB1434: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1438: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB143C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1440: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "set_canMove", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_5 = val_1.GetMethod(name:  "set_canMove", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1444: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1448: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x00BB144C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1450: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1;
            // 0x00BB1454: CBNZ x22, #0xbb14a0        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1 != null) goto label_13;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1) != null)
            {
                goto label_13;
            }
            // 0x00BB1458: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BB145C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1460: LDR x8, [x8, #0xd68]       | X8 = 1152921510033293328;               
            // 0x00BB1464: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1468: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::set_canMove_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB146C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_6 = null;
            // 0x00BB1470: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1474: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1478: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB147C: MOV x2, x22                | X2 = 1152921510033293328 (0x1000000143710010);//ML01
            // 0x00BB1480: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_6;
            // 0x00BB1484: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::set_canMove_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::set_canMove_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1488: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB148C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1490: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569480
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1 = val_56;
            // 0x00BB1494: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1498: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB149C: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_13:
            // 0x00BB14A0: CBNZ x19, #0xbb14a8        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BB14A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::set_canMove_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x00BB14A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB14AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB14B0: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x00BB14B4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB14B8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_5, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_5, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1);
            // 0x00BB14BC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB14C0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB14C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB14C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB14CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB14D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB14D4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB14D8: CBNZ x20, #0xbb14e0        | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x00BB14DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_15:
            // 0x00BB14E0: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00BB14E4: LDR x8, [x8, #0x7c8]       | X8 = (string**)(1152921510033294352)("get_TargetReached");
            // 0x00BB14E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB14EC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB14F0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB14F4: LDR x1, [x8]               | X1 = "get_TargetReached";               
            // 0x00BB14F8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB14FC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1500: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1504: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_TargetReached", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_7 = val_1.GetMethod(name:  "get_TargetReached", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1508: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB150C: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x00BB1510: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1514: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2;
            // 0x00BB1518: CBNZ x22, #0xbb1564        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2 != null) goto label_16;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2) != null)
            {
                goto label_16;
            }
            // 0x00BB151C: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00BB1520: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1524: LDR x8, [x8, #0xf00]       | X8 = 1152921510033298560;               
            // 0x00BB1528: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB152C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_TargetReached_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1530: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_8 = null;
            // 0x00BB1534: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB153C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1540: MOV x2, x22                | X2 = 1152921510033298560 (0x1000000143711480);//ML01
            // 0x00BB1544: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_8;
            // 0x00BB1548: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_TargetReached_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_TargetReached_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB154C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1550: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1554: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569488
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2 = val_56;
            // 0x00BB1558: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB155C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1560: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_16:
            // 0x00BB1564: CBNZ x19, #0xbb156c        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BB1568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::get_TargetReached_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_17:
            // 0x00BB156C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1570: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1574: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x00BB1578: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB157C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2);
            X1.RegisterCLRMethodRedirection(mi:  val_7, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache2);
            // 0x00BB1580: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB1584: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1588: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB158C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1590: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1594: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB1598: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB159C: CBNZ x20, #0xbb15a4        | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x00BB15A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_18:
            // 0x00BB15A4: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x00BB15A8: LDR x8, [x8, #0x7f0]       | X8 = (string**)(1152921510024538688)("Start");
            // 0x00BB15AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB15B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB15B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB15B8: LDR x1, [x8]               | X1 = "Start";                           
            // 0x00BB15BC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB15C0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB15C4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB15C8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Start", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_9 = val_1.GetMethod(name:  "Start", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB15CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB15D0: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x00BB15D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB15D8: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3;
            // 0x00BB15DC: CBNZ x22, #0xbb1628        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3 != null) goto label_19;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3) != null)
            {
                goto label_19;
            }
            // 0x00BB15E0: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00BB15E4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB15E8: LDR x8, [x8, #0x8f0]       | X8 = 1152921510033303680;               
            // 0x00BB15EC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB15F0: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Start_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB15F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_10 = null;
            // 0x00BB15F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB15FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1604: MOV x2, x22                | X2 = 1152921510033303680 (0x1000000143712880);//ML01
            // 0x00BB1608: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_10;
            // 0x00BB160C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Start_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Start_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1610: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1614: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1618: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569496
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3 = val_56;
            // 0x00BB161C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1620: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1624: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_19:
            // 0x00BB1628: CBNZ x19, #0xbb1630        | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x00BB162C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Start_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_20:
            // 0x00BB1630: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1634: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1638: MOV x1, x21                | X1 = val_9;//m1                         
            // 0x00BB163C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1640: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_9, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3);
            X1.RegisterCLRMethodRedirection(mi:  val_9, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache3);
            // 0x00BB1644: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB1648: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB164C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB1650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1654: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1658: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB165C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1660: CBNZ x20, #0xbb1668        | if (val_1 != null) goto label_21;       
            if(val_1 != null)
            {
                goto label_21;
            }
            // 0x00BB1664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_21:
            // 0x00BB1668: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00BB166C: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921510033304704)("OnDisable");
            // 0x00BB1670: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1674: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB1678: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB167C: LDR x1, [x8]               | X1 = "OnDisable";                       
            // 0x00BB1680: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1684: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1688: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB168C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnDisable", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_11 = val_1.GetMethod(name:  "OnDisable", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1690: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1694: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x00BB1698: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB169C: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4;
            // 0x00BB16A0: CBNZ x22, #0xbb16ec        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4 != null) goto label_22;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4) != null)
            {
                goto label_22;
            }
            // 0x00BB16A4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00BB16A8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB16AC: LDR x8, [x8, #0xdc8]       | X8 = 1152921510033308896;               
            // 0x00BB16B0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB16B4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnDisable_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB16B8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12 = null;
            // 0x00BB16BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB16C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB16C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB16C8: MOV x2, x22                | X2 = 1152921510033308896 (0x1000000143713CE0);//ML01
            // 0x00BB16CC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_12;
            // 0x00BB16D0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnDisable_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnDisable_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB16D4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB16D8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB16DC: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569504
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4 = val_56;
            // 0x00BB16E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB16E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB16E8: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_22:
            // 0x00BB16EC: CBNZ x19, #0xbb16f4        | if (X1 != 0) goto label_23;             
            if(X1 != 0)
            {
                goto label_23;
            }
            // 0x00BB16F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnDisable_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_23:
            // 0x00BB16F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB16F8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB16FC: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x00BB1700: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1704: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_11, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4);
            X1.RegisterCLRMethodRedirection(mi:  val_11, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache4);
            // 0x00BB1708: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB170C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1710: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB1714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1718: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB171C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB1720: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1724: CBNZ x20, #0xbb172c        | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x00BB1728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_24:
            // 0x00BB172C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00BB1730: LDR x8, [x8, #0x8a0]       | X8 = (string**)(1152921510033309920)("TrySearchPath");
            // 0x00BB1734: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1738: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB173C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1740: LDR x1, [x8]               | X1 = "TrySearchPath";                   
            // 0x00BB1744: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1748: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB174C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1750: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "TrySearchPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_13 = val_1.GetMethod(name:  "TrySearchPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1754: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1758: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x00BB175C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1760: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5;
            // 0x00BB1764: CBNZ x22, #0xbb17b0        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5 != null) goto label_25;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5) != null)
            {
                goto label_25;
            }
            // 0x00BB1768: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BB176C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1770: LDR x8, [x8, #0x7f8]       | X8 = 1152921510033314112;               
            // 0x00BB1774: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1778: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::TrySearchPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB177C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_14 = null;
            // 0x00BB1780: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB178C: MOV x2, x22                | X2 = 1152921510033314112 (0x1000000143715140);//ML01
            // 0x00BB1790: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_14;
            // 0x00BB1794: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::TrySearchPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::TrySearchPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1798: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB179C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB17A0: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569512
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5 = val_56;
            // 0x00BB17A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB17A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB17AC: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_25:
            // 0x00BB17B0: CBNZ x19, #0xbb17b8        | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x00BB17B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::TrySearchPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_26:
            // 0x00BB17B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB17BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB17C0: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x00BB17C4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB17C8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5);
            X1.RegisterCLRMethodRedirection(mi:  val_13, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache5);
            // 0x00BB17CC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB17D0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB17D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB17D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB17DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB17E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB17E4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB17E8: CBNZ x20, #0xbb17f0        | if (val_1 != null) goto label_27;       
            if(val_1 != null)
            {
                goto label_27;
            }
            // 0x00BB17EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_27:
            // 0x00BB17F0: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00BB17F4: LDR x8, [x8, #0x848]       | X8 = (string**)(1152921510033315136)("SearchPath");
            // 0x00BB17F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB17FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB1800: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1804: LDR x1, [x8]               | X1 = "SearchPath";                      
            // 0x00BB1808: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB180C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1810: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1814: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SearchPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_15 = val_1.GetMethod(name:  "SearchPath", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1818: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB181C: MOV x21, x0                | X21 = val_15;//m1                       
            // 0x00BB1820: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1824: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6;
            // 0x00BB1828: CBNZ x22, #0xbb1874        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6 != null) goto label_28;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6) != null)
            {
                goto label_28;
            }
            // 0x00BB182C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x00BB1830: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1834: LDR x8, [x8, #0x620]       | X8 = 1152921510033319328;               
            // 0x00BB1838: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB183C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::SearchPath_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1840: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_16 = null;
            // 0x00BB1844: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB184C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1850: MOV x2, x22                | X2 = 1152921510033319328 (0x10000001437165A0);//ML01
            // 0x00BB1854: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_16;
            // 0x00BB1858: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::SearchPath_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::SearchPath_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB185C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1860: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1864: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569520
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6 = val_56;
            // 0x00BB1868: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB186C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1870: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_28:
            // 0x00BB1874: CBNZ x19, #0xbb187c        | if (X1 != 0) goto label_29;             
            if(X1 != 0)
            {
                goto label_29;
            }
            // 0x00BB1878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::SearchPath_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_29:
            // 0x00BB187C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1880: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1884: MOV x1, x21                | X1 = val_15;//m1                        
            // 0x00BB1888: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB188C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_15, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6);
            X1.RegisterCLRMethodRedirection(mi:  val_15, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache6);
            // 0x00BB1890: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB1894: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1898: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB189C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB18A0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB18A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB18A8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB18AC: CBNZ x20, #0xbb18b4        | if (val_1 != null) goto label_30;       
            if(val_1 != null)
            {
                goto label_30;
            }
            // 0x00BB18B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_30:
            // 0x00BB18B4: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00BB18B8: LDR x8, [x8, #0x960]       | X8 = (string**)(1152921510033320352)("OnTargetReached");
            // 0x00BB18BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB18C0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB18C4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB18C8: LDR x1, [x8]               | X1 = "OnTargetReached";                 
            // 0x00BB18CC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB18D0: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB18D4: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB18D8: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnTargetReached", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "OnTargetReached", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB18DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB18E0: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x00BB18E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB18E8: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7;
            // 0x00BB18EC: CBNZ x22, #0xbb1938        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7 != null) goto label_31;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7) != null)
            {
                goto label_31;
            }
            // 0x00BB18F0: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x00BB18F4: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB18F8: LDR x8, [x8, #0x2e0]       | X8 = 1152921510033324560;               
            // 0x00BB18FC: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1900: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnTargetReached_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1904: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x00BB1908: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB190C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1910: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1914: MOV x2, x22                | X2 = 1152921510033324560 (0x1000000143717A10);//ML01
            // 0x00BB1918: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_18;
            // 0x00BB191C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnTargetReached_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnTargetReached_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1920: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1924: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1928: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569528
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7 = val_56;
            // 0x00BB192C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1930: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1934: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_31:
            // 0x00BB1938: CBNZ x19, #0xbb1940        | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x00BB193C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnTargetReached_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_32:
            // 0x00BB1940: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1944: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1948: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x00BB194C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1950: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache7);
            // 0x00BB1954: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB1958: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB195C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB1960: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BB1964: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1968: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB196C: ADRP x9, #0x35e1000        | X9 = 56496128 (0x35E1000);              
            // 0x00BB1970: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BB1974: LDR x9, [x9, #0x728]       | X9 = 1152921504840552448;               
            // 0x00BB1978: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB197C: LDR x22, [x9]              | X22 = typeof(Pathfinding.Path);         
            // 0x00BB1980: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB1984: TBZ w9, #0, #0xbb1998      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x00BB1988: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB198C: CBNZ w9, #0xbb1998         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x00BB1990: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB1994: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x00BB1998: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB199C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB19A0: MOV x1, x22                | X1 = 1152921504840552448 (0x100000000DEE1000);//ML01
            // 0x00BB19A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB19A8: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x00BB19AC: CBNZ x21, #0xbb19b4        | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x00BB19B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_35:
            // 0x00BB19B4: CBZ x22, #0xbb19d8         | if (val_19 == null) goto label_37;      
            if(val_19 == null)
            {
                goto label_37;
            }
            // 0x00BB19B8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB19BC: MOV x0, x22                | X0 = val_19;//m1                        
            // 0x00BB19C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB19C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x00BB19C8: CBNZ x0, #0xbb19d8         | if (val_19 != null) goto label_37;      
            if(val_19 != null)
            {
                goto label_37;
            }
            // 0x00BB19CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x00BB19D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB19D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_37:
            // 0x00BB19D8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BB19DC: CBNZ w8, #0xbb19ec         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x00BB19E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x00BB19E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB19E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_38:
            // 0x00BB19EC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_19;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_19;
            // 0x00BB19F0: CBNZ x20, #0xbb19f8        | if (val_1 != null) goto label_39;       
            if(val_1 != null)
            {
                goto label_39;
            }
            // 0x00BB19F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_39:
            // 0x00BB19F8: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00BB19FC: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921510033329680)("OnPathComplete");
            // 0x00BB1A00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1A04: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB1A08: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1A0C: LDR x1, [x8]               | X1 = "OnPathComplete";                  
            // 0x00BB1A10: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1A14: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1A18: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1A1C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnPathComplete", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_20 = val_1.GetMethod(name:  "OnPathComplete", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1A20: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1A24: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x00BB1A28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1A2C: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8;
            // 0x00BB1A30: CBNZ x22, #0xbb1a7c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8 != null) goto label_40;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8) != null)
            {
                goto label_40;
            }
            // 0x00BB1A34: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x00BB1A38: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1A3C: LDR x8, [x8, #0xbf0]       | X8 = 1152921510033333872;               
            // 0x00BB1A40: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1A44: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnPathComplete_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1A48: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_21 = null;
            // 0x00BB1A4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1A54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1A58: MOV x2, x22                | X2 = 1152921510033333872 (0x1000000143719E70);//ML01
            // 0x00BB1A5C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_21;
            // 0x00BB1A60: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnPathComplete_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnPathComplete_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1A64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1A68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1A6C: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569536
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8 = val_56;
            // 0x00BB1A70: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1A74: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1A78: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_40:
            // 0x00BB1A7C: CBNZ x19, #0xbb1a84        | if (X1 != 0) goto label_41;             
            if(X1 != 0)
            {
                goto label_41;
            }
            // 0x00BB1A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::OnPathComplete_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_41:
            // 0x00BB1A84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1A88: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1A8C: MOV x1, x21                | X1 = val_20;//m1                        
            // 0x00BB1A90: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1A94: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_20, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8);
            X1.RegisterCLRMethodRedirection(mi:  val_20, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache8);
            // 0x00BB1A98: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB1A9C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1AA0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB1AA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1AA8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1AAC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB1AB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1AB4: CBNZ x20, #0xbb1abc        | if (val_1 != null) goto label_42;       
            if(val_1 != null)
            {
                goto label_42;
            }
            // 0x00BB1AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_42:
            // 0x00BB1ABC: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BB1AC0: LDR x8, [x8, #0x600]       | X8 = (string**)(1152921510033334896)("GetFeetPosition");
            // 0x00BB1AC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1AC8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB1ACC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1AD0: LDR x1, [x8]               | X1 = "GetFeetPosition";                 
            // 0x00BB1AD4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1AD8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1ADC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1AE0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetFeetPosition", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_22 = val_1.GetMethod(name:  "GetFeetPosition", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1AE4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1AE8: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x00BB1AEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1AF0: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9;
            // 0x00BB1AF4: CBNZ x22, #0xbb1b40        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9 != null) goto label_43;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9) != null)
            {
                goto label_43;
            }
            // 0x00BB1AF8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00BB1AFC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1B00: LDR x8, [x8, #0xa70]       | X8 = 1152921510033339104;               
            // 0x00BB1B04: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1B08: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::GetFeetPosition_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1B0C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23 = null;
            // 0x00BB1B10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1B14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1B18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1B1C: MOV x2, x22                | X2 = 1152921510033339104 (0x100000014371B2E0);//ML01
            // 0x00BB1B20: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_23;
            // 0x00BB1B24: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::GetFeetPosition_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::GetFeetPosition_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1B28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1B2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1B30: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569544
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9 = val_56;
            // 0x00BB1B34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1B38: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1B3C: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_43:
            // 0x00BB1B40: CBNZ x19, #0xbb1b48        | if (X1 != 0) goto label_44;             
            if(X1 != 0)
            {
                goto label_44;
            }
            // 0x00BB1B44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::GetFeetPosition_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_44:
            // 0x00BB1B48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1B4C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1B50: MOV x1, x21                | X1 = val_22;//m1                        
            // 0x00BB1B54: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1B58: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_22, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9);
            X1.RegisterCLRMethodRedirection(mi:  val_22, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache9);
            // 0x00BB1B5C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BB1B60: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1B64: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB1B68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1B6C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1B70: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB1B74: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1B78: CBNZ x20, #0xbb1b80        | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x00BB1B7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_45:
            // 0x00BB1B80: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BB1B84: LDR x8, [x8, #0x3a8]       | X8 = (string**)(1152921510033340128)("Update");
            // 0x00BB1B88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1B8C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB1B90: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1B94: LDR x1, [x8]               | X1 = "Update";                          
            // 0x00BB1B98: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1B9C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB1BA0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BB1BA4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Update", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_24 = val_1.GetMethod(name:  "Update", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB1BA8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1BAC: MOV x21, x0                | X21 = val_24;//m1                       
            // 0x00BB1BB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1BB4: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA;
            // 0x00BB1BB8: CBNZ x22, #0xbb1c04        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA != null) goto label_46;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA) != null)
            {
                goto label_46;
            }
            // 0x00BB1BBC: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BB1BC0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB1BC4: LDR x8, [x8, #0xc58]       | X8 = 1152921510033344304;               
            // 0x00BB1BC8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB1BCC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Update_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB1BD0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25 = null;
            // 0x00BB1BD4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB1BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1BDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1BE0: MOV x2, x22                | X2 = 1152921510033344304 (0x100000014371C730);//ML01
            // 0x00BB1BE4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_56 = val_25;
            // 0x00BB1BE8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Update_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Update_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB1BEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1BF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1BF4: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782569552
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA = val_56;
            // 0x00BB1BF8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1BFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1C00: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_46:
            // 0x00BB1C04: CBNZ x19, #0xbb1c0c        | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x00BB1C08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AIPath_Binding::Update_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_47:
            // 0x00BB1C0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1C10: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1C14: MOV x1, x21                | X1 = val_24;//m1                        
            // 0x00BB1C18: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB1C1C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheA);
            // 0x00BB1C20: CBNZ x20, #0xbb1c28        | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x00BB1C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_48:
            // 0x00BB1C28: ADRP x9, #0x3617000        | X9 = 56717312 (0x3617000);              
            // 0x00BB1C2C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB1C30: LDR x9, [x9, #0xfa0]       | X9 = (string**)(1152921510033345328)("AIId");
            // 0x00BB1C34: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1C38: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1C3C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB1C40: LDR x1, [x9]               | X1 = "AIId";                            
            // 0x00BB1C44: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB1C48: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB1C4C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1C50: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB1C54: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1C58: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB;
            // 0x00BB1C5C: CBNZ x22, #0xbb1ca8        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB != null) goto label_49;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB) != null)
            {
                goto label_49;
            }
            // 0x00BB1C60: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x00BB1C64: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB1C68: LDR x8, [x8, #0x118]       | X8 = 1152921510033345408;               
            // 0x00BB1C6C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB1C70: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_AIId_0(ref object o);
            // 0x00BB1C74: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_26 = null;
            // 0x00BB1C78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB1C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1C80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1C84: MOV x2, x22                | X2 = 1152921510033345408 (0x100000014371CB80);//ML01
            // 0x00BB1C88: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_26;
            // 0x00BB1C8C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_AIId_0(ref object o));
            val_26 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_AIId_0(ref object o));
            // 0x00BB1C90: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1C94: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1C98: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569560
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB = val_56;
            // 0x00BB1C9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1CA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1CA4: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_49:
            // 0x00BB1CA8: CBNZ x19, #0xbb1cb0        | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x00BB1CAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_AIId_0(ref object o)), ????);
            label_50:
            // 0x00BB1CB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1CB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1CB8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB1CBC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB1CC0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheB);
            // 0x00BB1CC4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1CC8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1CCC: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC;
            // 0x00BB1CD0: CBNZ x22, #0xbb1d1c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC != null) goto label_51;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC) != null)
            {
                goto label_51;
            }
            // 0x00BB1CD4: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x00BB1CD8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB1CDC: LDR x8, [x8, #0xe90]       | X8 = 1152921510033346432;               
            // 0x00BB1CE0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB1CE4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_AIId_0(ref object o, object v);
            // 0x00BB1CE8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_27 = null;
            // 0x00BB1CEC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB1CF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1CF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1CF8: MOV x2, x22                | X2 = 1152921510033346432 (0x100000014371CF80);//ML01
            // 0x00BB1CFC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_27;
            // 0x00BB1D00: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_AIId_0(ref object o, object v));
            val_27 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_AIId_0(ref object o, object v));
            // 0x00BB1D04: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1D08: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1D0C: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569568
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC = val_56;
            // 0x00BB1D10: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1D14: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1D18: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_51:
            // 0x00BB1D1C: CBNZ x19, #0xbb1d24        | if (X1 != 0) goto label_52;             
            if(X1 != 0)
            {
                goto label_52;
            }
            // 0x00BB1D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_AIId_0(ref object o, object v)), ????);
            label_52:
            // 0x00BB1D24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1D28: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1D2C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB1D30: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB1D34: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheC);
            // 0x00BB1D38: CBNZ x20, #0xbb1d40        | if (val_1 != null) goto label_53;       
            if(val_1 != null)
            {
                goto label_53;
            }
            // 0x00BB1D3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_53:
            // 0x00BB1D40: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x00BB1D44: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB1D48: LDR x9, [x9, #0x560]       | X9 = (string**)(1152921510033347456)("repathRate");
            // 0x00BB1D4C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1D50: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1D54: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB1D58: LDR x1, [x9]               | X1 = "repathRate";                      
            // 0x00BB1D5C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB1D60: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB1D64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1D68: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB1D6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1D70: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD;
            // 0x00BB1D74: CBNZ x22, #0xbb1dc0        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD != null) goto label_54;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD) != null)
            {
                goto label_54;
            }
            // 0x00BB1D78: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00BB1D7C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB1D80: LDR x8, [x8, #0x508]       | X8 = 1152921510033347552;               
            // 0x00BB1D84: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB1D88: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_repathRate_1(ref object o);
            // 0x00BB1D8C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_28 = null;
            // 0x00BB1D90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB1D94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1D98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1D9C: MOV x2, x22                | X2 = 1152921510033347552 (0x100000014371D3E0);//ML01
            // 0x00BB1DA0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_28;
            // 0x00BB1DA4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_repathRate_1(ref object o));
            val_28 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_repathRate_1(ref object o));
            // 0x00BB1DA8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1DAC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1DB0: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569576
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD = val_56;
            // 0x00BB1DB4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1DB8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1DBC: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_54:
            // 0x00BB1DC0: CBNZ x19, #0xbb1dc8        | if (X1 != 0) goto label_55;             
            if(X1 != 0)
            {
                goto label_55;
            }
            // 0x00BB1DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_repathRate_1(ref object o)), ????);
            label_55:
            // 0x00BB1DC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1DCC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1DD0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB1DD4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB1DD8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheD);
            // 0x00BB1DDC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1DE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1DE4: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE;
            // 0x00BB1DE8: CBNZ x22, #0xbb1e34        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE != null) goto label_56;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE) != null)
            {
                goto label_56;
            }
            // 0x00BB1DEC: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x00BB1DF0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB1DF4: LDR x8, [x8, #0x928]       | X8 = 1152921510033348576;               
            // 0x00BB1DF8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB1DFC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_repathRate_1(ref object o, object v);
            // 0x00BB1E00: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_29 = null;
            // 0x00BB1E04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB1E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1E0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1E10: MOV x2, x22                | X2 = 1152921510033348576 (0x100000014371D7E0);//ML01
            // 0x00BB1E14: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_29;
            // 0x00BB1E18: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_repathRate_1(ref object o, object v));
            val_29 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_repathRate_1(ref object o, object v));
            // 0x00BB1E1C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1E20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1E24: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569584
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE = val_56;
            // 0x00BB1E28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1E2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1E30: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_56:
            // 0x00BB1E34: CBNZ x19, #0xbb1e3c        | if (X1 != 0) goto label_57;             
            if(X1 != 0)
            {
                goto label_57;
            }
            // 0x00BB1E38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_repathRate_1(ref object o, object v)), ????);
            label_57:
            // 0x00BB1E3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1E40: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1E44: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB1E48: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB1E4C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheE);
            // 0x00BB1E50: CBNZ x20, #0xbb1e58        | if (val_1 != null) goto label_58;       
            if(val_1 != null)
            {
                goto label_58;
            }
            // 0x00BB1E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_58:
            // 0x00BB1E58: ADRP x9, #0x3655000        | X9 = 56971264 (0x3655000);              
            // 0x00BB1E5C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB1E60: LDR x9, [x9, #0x698]       | X9 = (string**)(1152921510033349600)("target");
            // 0x00BB1E64: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1E68: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1E6C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB1E70: LDR x1, [x9]               | X1 = "target";                          
            // 0x00BB1E74: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB1E78: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB1E7C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1E80: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB1E84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1E88: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF;
            // 0x00BB1E8C: CBNZ x22, #0xbb1ed8        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF != null) goto label_59;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF) != null)
            {
                goto label_59;
            }
            // 0x00BB1E90: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00BB1E94: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB1E98: LDR x8, [x8, #0x150]       | X8 = 1152921510033349680;               
            // 0x00BB1E9C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB1EA0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_target_2(ref object o);
            // 0x00BB1EA4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_30 = null;
            // 0x00BB1EA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB1EAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1EB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1EB4: MOV x2, x22                | X2 = 1152921510033349680 (0x100000014371DC30);//ML01
            // 0x00BB1EB8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_30;
            // 0x00BB1EBC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_target_2(ref object o));
            val_30 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_target_2(ref object o));
            // 0x00BB1EC0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1EC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1EC8: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569592
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF = val_56;
            // 0x00BB1ECC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1ED0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1ED4: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_59:
            // 0x00BB1ED8: CBNZ x19, #0xbb1ee0        | if (X1 != 0) goto label_60;             
            if(X1 != 0)
            {
                goto label_60;
            }
            // 0x00BB1EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_target_2(ref object o)), ????);
            label_60:
            // 0x00BB1EE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1EE4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1EE8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB1EEC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB1EF0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cacheF);
            // 0x00BB1EF4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1EF8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1EFC: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10;
            // 0x00BB1F00: CBNZ x22, #0xbb1f4c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10 != null) goto label_61;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10) != null)
            {
                goto label_61;
            }
            // 0x00BB1F04: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00BB1F08: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB1F0C: LDR x8, [x8, #0x508]       | X8 = 1152921510033350704;               
            // 0x00BB1F10: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB1F14: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_target_2(ref object o, object v);
            // 0x00BB1F18: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_31 = null;
            // 0x00BB1F1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB1F20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1F24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1F28: MOV x2, x22                | X2 = 1152921510033350704 (0x100000014371E030);//ML01
            // 0x00BB1F2C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_31;
            // 0x00BB1F30: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_target_2(ref object o, object v));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_target_2(ref object o, object v));
            // 0x00BB1F34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1F38: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1F3C: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569600
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10 = val_56;
            // 0x00BB1F40: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1F44: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1F48: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_61:
            // 0x00BB1F4C: CBNZ x19, #0xbb1f54        | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x00BB1F50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_target_2(ref object o, object v)), ????);
            label_62:
            // 0x00BB1F54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1F58: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB1F5C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB1F60: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB1F64: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache10);
            // 0x00BB1F68: CBNZ x20, #0xbb1f70        | if (val_1 != null) goto label_63;       
            if(val_1 != null)
            {
                goto label_63;
            }
            // 0x00BB1F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_63:
            // 0x00BB1F70: ADRP x9, #0x3602000        | X9 = 56631296 (0x3602000);              
            // 0x00BB1F74: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB1F78: LDR x9, [x9, #0xdf8]       | X9 = (string**)(1152921510033351728)("canSearch");
            // 0x00BB1F7C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB1F80: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB1F84: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB1F88: LDR x1, [x9]               | X1 = "canSearch";                       
            // 0x00BB1F8C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB1F90: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB1F94: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1F98: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB1F9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1FA0: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11;
            // 0x00BB1FA4: CBNZ x22, #0xbb1ff0        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11 != null) goto label_64;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11) != null)
            {
                goto label_64;
            }
            // 0x00BB1FA8: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00BB1FAC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB1FB0: LDR x8, [x8, #0x100]       | X8 = 1152921510033351824;               
            // 0x00BB1FB4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB1FB8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canSearch_3(ref object o);
            // 0x00BB1FBC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32 = null;
            // 0x00BB1FC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB1FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB1FC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1FCC: MOV x2, x22                | X2 = 1152921510033351824 (0x100000014371E490);//ML01
            // 0x00BB1FD0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_32;
            // 0x00BB1FD4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canSearch_3(ref object o));
            val_32 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canSearch_3(ref object o));
            // 0x00BB1FD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1FDC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1FE0: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569608
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11 = val_56;
            // 0x00BB1FE4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB1FE8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB1FEC: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_64:
            // 0x00BB1FF0: CBNZ x19, #0xbb1ff8        | if (X1 != 0) goto label_65;             
            if(X1 != 0)
            {
                goto label_65;
            }
            // 0x00BB1FF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canSearch_3(ref object o)), ????);
            label_65:
            // 0x00BB1FF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB1FFC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2000: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2004: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2008: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache11);
            // 0x00BB200C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2010: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2014: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12;
            // 0x00BB2018: CBNZ x22, #0xbb2064        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12 != null) goto label_66;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12) != null)
            {
                goto label_66;
            }
            // 0x00BB201C: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x00BB2020: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB2024: LDR x8, [x8, #0xac0]       | X8 = 1152921510033352848;               
            // 0x00BB2028: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB202C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canSearch_3(ref object o, object v);
            // 0x00BB2030: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_33 = null;
            // 0x00BB2034: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB203C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2040: MOV x2, x22                | X2 = 1152921510033352848 (0x100000014371E890);//ML01
            // 0x00BB2044: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_33;
            // 0x00BB2048: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canSearch_3(ref object o, object v));
            val_33 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canSearch_3(ref object o, object v));
            // 0x00BB204C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2050: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2054: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569616
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12 = val_56;
            // 0x00BB2058: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB205C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2060: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_66:
            // 0x00BB2064: CBNZ x19, #0xbb206c        | if (X1 != 0) goto label_67;             
            if(X1 != 0)
            {
                goto label_67;
            }
            // 0x00BB2068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canSearch_3(ref object o, object v)), ????);
            label_67:
            // 0x00BB206C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2070: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2074: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2078: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB207C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache12);
            // 0x00BB2080: CBNZ x20, #0xbb2088        | if (val_1 != null) goto label_68;       
            if(val_1 != null)
            {
                goto label_68;
            }
            // 0x00BB2084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_68:
            // 0x00BB2088: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
            // 0x00BB208C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2090: LDR x9, [x9, #0xf48]       | X9 = (string**)(1152921510033353872)("canMoveNextWaypoint");
            // 0x00BB2094: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2098: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB209C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB20A0: LDR x1, [x9]               | X1 = "canMoveNextWaypoint";             
            // 0x00BB20A4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB20A8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB20AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB20B0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB20B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB20B8: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13;
            // 0x00BB20BC: CBNZ x22, #0xbb2108        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13 != null) goto label_69;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13) != null)
            {
                goto label_69;
            }
            // 0x00BB20C0: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x00BB20C4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB20C8: LDR x8, [x8, #0xaa0]       | X8 = 1152921510033353984;               
            // 0x00BB20CC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB20D0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canMoveNextWaypoint_4(ref object o);
            // 0x00BB20D4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_34 = null;
            // 0x00BB20D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB20DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB20E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB20E4: MOV x2, x22                | X2 = 1152921510033353984 (0x100000014371ED00);//ML01
            // 0x00BB20E8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_34;
            // 0x00BB20EC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canMoveNextWaypoint_4(ref object o));
            val_34 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canMoveNextWaypoint_4(ref object o));
            // 0x00BB20F0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB20F4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB20F8: STR x23, [x8, #0x98]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569624
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13 = val_56;
            // 0x00BB20FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2100: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2104: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_69:
            // 0x00BB2108: CBNZ x19, #0xbb2110        | if (X1 != 0) goto label_70;             
            if(X1 != 0)
            {
                goto label_70;
            }
            // 0x00BB210C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_canMoveNextWaypoint_4(ref object o)), ????);
            label_70:
            // 0x00BB2110: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2114: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2118: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB211C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2120: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache13);
            // 0x00BB2124: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2128: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB212C: LDR x22, [x8, #0xa0]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14;
            // 0x00BB2130: CBNZ x22, #0xbb217c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14 != null) goto label_71;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14) != null)
            {
                goto label_71;
            }
            // 0x00BB2134: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00BB2138: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB213C: LDR x8, [x8, #0x2b8]       | X8 = 1152921510033355008;               
            // 0x00BB2140: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB2144: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canMoveNextWaypoint_4(ref object o, object v);
            // 0x00BB2148: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_35 = null;
            // 0x00BB214C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2154: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2158: MOV x2, x22                | X2 = 1152921510033355008 (0x100000014371F100);//ML01
            // 0x00BB215C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_35;
            // 0x00BB2160: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canMoveNextWaypoint_4(ref object o, object v));
            val_35 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canMoveNextWaypoint_4(ref object o, object v));
            // 0x00BB2164: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2168: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB216C: STR x23, [x8, #0xa0]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569632
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14 = val_56;
            // 0x00BB2170: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2174: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2178: LDR x22, [x8, #0xa0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_71:
            // 0x00BB217C: CBNZ x19, #0xbb2184        | if (X1 != 0) goto label_72;             
            if(X1 != 0)
            {
                goto label_72;
            }
            // 0x00BB2180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_canMoveNextWaypoint_4(ref object o, object v)), ????);
            label_72:
            // 0x00BB2184: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2188: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB218C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2190: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB2194: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache14);
            // 0x00BB2198: CBNZ x20, #0xbb21a0        | if (val_1 != null) goto label_73;       
            if(val_1 != null)
            {
                goto label_73;
            }
            // 0x00BB219C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_73:
            // 0x00BB21A0: ADRP x9, #0x3645000        | X9 = 56905728 (0x3645000);              
            // 0x00BB21A4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB21A8: LDR x9, [x9, #0x2f8]       | X9 = (string**)(1152921510033356032)("speed");
            // 0x00BB21AC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB21B0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB21B4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB21B8: LDR x1, [x9]               | X1 = "speed";                           
            // 0x00BB21BC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB21C0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB21C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB21C8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB21CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB21D0: LDR x22, [x8, #0xa8]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15;
            // 0x00BB21D4: CBNZ x22, #0xbb2220        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15 != null) goto label_74;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15) != null)
            {
                goto label_74;
            }
            // 0x00BB21D8: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00BB21DC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB21E0: LDR x8, [x8, #0x960]       | X8 = 1152921510033356112;               
            // 0x00BB21E4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB21E8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_speed_5(ref object o);
            // 0x00BB21EC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_36 = null;
            // 0x00BB21F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB21F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB21F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB21FC: MOV x2, x22                | X2 = 1152921510033356112 (0x100000014371F550);//ML01
            // 0x00BB2200: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_36;
            // 0x00BB2204: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_speed_5(ref object o));
            val_36 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_speed_5(ref object o));
            // 0x00BB2208: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB220C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2210: STR x23, [x8, #0xa8]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569640
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15 = val_56;
            // 0x00BB2214: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2218: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB221C: LDR x22, [x8, #0xa8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_74:
            // 0x00BB2220: CBNZ x19, #0xbb2228        | if (X1 != 0) goto label_75;             
            if(X1 != 0)
            {
                goto label_75;
            }
            // 0x00BB2224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_speed_5(ref object o)), ????);
            label_75:
            // 0x00BB2228: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB222C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2230: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2234: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2238: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache15);
            // 0x00BB223C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2240: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2244: LDR x22, [x8, #0xb0]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16;
            // 0x00BB2248: CBNZ x22, #0xbb2294        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16 != null) goto label_76;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16) != null)
            {
                goto label_76;
            }
            // 0x00BB224C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00BB2250: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB2254: LDR x8, [x8, #0x1f0]       | X8 = 1152921510033357136;               
            // 0x00BB2258: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB225C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_speed_5(ref object o, object v);
            // 0x00BB2260: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_37 = null;
            // 0x00BB2264: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2268: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB226C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2270: MOV x2, x22                | X2 = 1152921510033357136 (0x100000014371F950);//ML01
            // 0x00BB2274: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_37;
            // 0x00BB2278: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_speed_5(ref object o, object v));
            val_37 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_speed_5(ref object o, object v));
            // 0x00BB227C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2280: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2284: STR x23, [x8, #0xb0]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569648
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16 = val_56;
            // 0x00BB2288: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB228C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2290: LDR x22, [x8, #0xb0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_76:
            // 0x00BB2294: CBNZ x19, #0xbb229c        | if (X1 != 0) goto label_77;             
            if(X1 != 0)
            {
                goto label_77;
            }
            // 0x00BB2298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_speed_5(ref object o, object v)), ????);
            label_77:
            // 0x00BB229C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB22A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB22A4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB22A8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB22AC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache16);
            // 0x00BB22B0: CBNZ x20, #0xbb22b8        | if (val_1 != null) goto label_78;       
            if(val_1 != null)
            {
                goto label_78;
            }
            // 0x00BB22B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_78:
            // 0x00BB22B8: ADRP x9, #0x35bd000        | X9 = 56348672 (0x35BD000);              
            // 0x00BB22BC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB22C0: LDR x9, [x9, #0x1d8]       | X9 = (string**)(1152921510033358160)("turningSpeed");
            // 0x00BB22C4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB22C8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB22CC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB22D0: LDR x1, [x9]               | X1 = "turningSpeed";                    
            // 0x00BB22D4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB22D8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB22DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB22E0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB22E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB22E8: LDR x22, [x8, #0xb8]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17;
            // 0x00BB22EC: CBNZ x22, #0xbb2338        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17 != null) goto label_79;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17) != null)
            {
                goto label_79;
            }
            // 0x00BB22F0: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00BB22F4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB22F8: LDR x8, [x8, #0xac0]       | X8 = 1152921510033358256;               
            // 0x00BB22FC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2300: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_turningSpeed_6(ref object o);
            // 0x00BB2304: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_38 = null;
            // 0x00BB2308: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB230C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2310: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2314: MOV x2, x22                | X2 = 1152921510033358256 (0x100000014371FDB0);//ML01
            // 0x00BB2318: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_38;
            // 0x00BB231C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_turningSpeed_6(ref object o));
            val_38 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_turningSpeed_6(ref object o));
            // 0x00BB2320: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2324: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2328: STR x23, [x8, #0xb8]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569656
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17 = val_56;
            // 0x00BB232C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2330: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2334: LDR x22, [x8, #0xb8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            label_79:
            // 0x00BB2338: CBNZ x19, #0xbb2340        | if (X1 != 0) goto label_80;             
            if(X1 != 0)
            {
                goto label_80;
            }
            // 0x00BB233C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_turningSpeed_6(ref object o)), ????);
            label_80:
            // 0x00BB2340: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2344: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2348: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB234C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2350: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache17);
            // 0x00BB2354: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2358: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB235C: LDR x22, [x8, #0xc0]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18;
            // 0x00BB2360: CBNZ x22, #0xbb23ac        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18 != null) goto label_81;
            if((ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18) != null)
            {
                goto label_81;
            }
            // 0x00BB2364: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00BB2368: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB236C: LDR x8, [x8, #0xb00]       | X8 = 1152921510033359280;               
            // 0x00BB2370: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB2374: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_turningSpeed_6(ref object o, object v);
            // 0x00BB2378: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_39 = null;
            // 0x00BB237C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2380: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2384: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2388: MOV x2, x22                | X2 = 1152921510033359280 (0x10000001437201B0);//ML01
            // 0x00BB238C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_39;
            // 0x00BB2390: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_turningSpeed_6(ref object o, object v));
            val_39 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_turningSpeed_6(ref object o, object v));
            // 0x00BB2394: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2398: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB239C: STR x23, [x8, #0xc0]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569664
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18 = val_56;
            // 0x00BB23A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB23A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB23A8: LDR x22, [x8, #0xc0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            label_81:
            // 0x00BB23AC: CBNZ x19, #0xbb23b4        | if (X1 != 0) goto label_82;             
            if(X1 != 0)
            {
                goto label_82;
            }
            // 0x00BB23B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_turningSpeed_6(ref object o, object v)), ????);
            label_82:
            // 0x00BB23B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB23B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB23BC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB23C0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB23C4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache18);
            // 0x00BB23C8: CBNZ x20, #0xbb23d0        | if (val_1 != null) goto label_83;       
            if(val_1 != null)
            {
                goto label_83;
            }
            // 0x00BB23CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_83:
            // 0x00BB23D0: ADRP x9, #0x35c8000        | X9 = 56393728 (0x35C8000);              
            // 0x00BB23D4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB23D8: LDR x9, [x9, #0x500]       | X9 = (string**)(1152921510033360304)("slowdownDistance");
            // 0x00BB23DC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB23E0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB23E4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB23E8: LDR x1, [x9]               | X1 = "slowdownDistance";                
            // 0x00BB23EC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB23F0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB23F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB23F8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB23FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2400: LDR x22, [x8, #0xc8]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache19;
            val_57 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache19;
            // 0x00BB2404: CBNZ x22, #0xbb2450        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache19 != null) goto label_84;
            if(val_57 != null)
            {
                goto label_84;
            }
            // 0x00BB2408: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BB240C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2410: LDR x8, [x8, #0xf70]       | X8 = 1152921510033360416;               
            // 0x00BB2414: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2418: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_slowdownDistance_7(ref object o);
            // 0x00BB241C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_40 = null;
            // 0x00BB2420: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB2424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2428: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB242C: MOV x2, x22                | X2 = 1152921510033360416 (0x1000000143720620);//ML01
            // 0x00BB2430: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_40;
            // 0x00BB2434: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_slowdownDistance_7(ref object o));
            val_40 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_slowdownDistance_7(ref object o));
            // 0x00BB2438: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB243C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2440: STR x23, [x8, #0xc8]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache19 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569672
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache19 = val_56;
            // 0x00BB2444: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2448: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB244C: LDR x22, [x8, #0xc8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_57 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache19;
            label_84:
            // 0x00BB2450: CBNZ x19, #0xbb2458        | if (X1 != 0) goto label_85;             
            if(X1 != 0)
            {
                goto label_85;
            }
            // 0x00BB2454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_slowdownDistance_7(ref object o)), ????);
            label_85:
            // 0x00BB2458: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB245C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2460: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2464: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2468: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_57);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_57);
            // 0x00BB246C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2470: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2474: LDR x22, [x8, #0xd0]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1A;
            val_58 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1A;
            // 0x00BB2478: CBNZ x22, #0xbb24c4        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1A != null) goto label_86;
            if(val_58 != null)
            {
                goto label_86;
            }
            // 0x00BB247C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB2480: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB2484: LDR x8, [x8, #0x4b0]       | X8 = 1152921510033361440;               
            // 0x00BB2488: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB248C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_slowdownDistance_7(ref object o, object v);
            // 0x00BB2490: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_41 = null;
            // 0x00BB2494: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB249C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB24A0: MOV x2, x22                | X2 = 1152921510033361440 (0x1000000143720A20);//ML01
            // 0x00BB24A4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_41;
            // 0x00BB24A8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_slowdownDistance_7(ref object o, object v));
            val_41 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_slowdownDistance_7(ref object o, object v));
            // 0x00BB24AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB24B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB24B4: STR x23, [x8, #0xd0]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1A = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569680
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1A = val_56;
            // 0x00BB24B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB24BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB24C0: LDR x22, [x8, #0xd0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_58 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1A;
            label_86:
            // 0x00BB24C4: CBNZ x19, #0xbb24cc        | if (X1 != 0) goto label_87;             
            if(X1 != 0)
            {
                goto label_87;
            }
            // 0x00BB24C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_slowdownDistance_7(ref object o, object v)), ????);
            label_87:
            // 0x00BB24CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB24D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB24D4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB24D8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB24DC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_58);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_58);
            // 0x00BB24E0: CBNZ x20, #0xbb24e8        | if (val_1 != null) goto label_88;       
            if(val_1 != null)
            {
                goto label_88;
            }
            // 0x00BB24E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_88:
            // 0x00BB24E8: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x00BB24EC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB24F0: LDR x9, [x9, #0x710]       | X9 = (string**)(1152921510033362464)("pickNextWaypointDist");
            // 0x00BB24F4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB24F8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB24FC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2500: LDR x1, [x9]               | X1 = "pickNextWaypointDist";            
            // 0x00BB2504: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2508: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB250C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2510: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB2514: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2518: LDR x22, [x8, #0xd8]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1B;
            val_59 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1B;
            // 0x00BB251C: CBNZ x22, #0xbb2568        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1B != null) goto label_89;
            if(val_59 != null)
            {
                goto label_89;
            }
            // 0x00BB2520: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB2524: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2528: LDR x8, [x8, #0xc88]       | X8 = 1152921510033362576;               
            // 0x00BB252C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2530: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_pickNextWaypointDist_8(ref object o);
            // 0x00BB2534: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_42 = null;
            // 0x00BB2538: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB253C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2540: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2544: MOV x2, x22                | X2 = 1152921510033362576 (0x1000000143720E90);//ML01
            // 0x00BB2548: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_42;
            // 0x00BB254C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_pickNextWaypointDist_8(ref object o));
            val_42 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_pickNextWaypointDist_8(ref object o));
            // 0x00BB2550: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2554: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2558: STR x23, [x8, #0xd8]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1B = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569688
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1B = val_56;
            // 0x00BB255C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2560: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2564: LDR x22, [x8, #0xd8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_59 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1B;
            label_89:
            // 0x00BB2568: CBNZ x19, #0xbb2570        | if (X1 != 0) goto label_90;             
            if(X1 != 0)
            {
                goto label_90;
            }
            // 0x00BB256C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_pickNextWaypointDist_8(ref object o)), ????);
            label_90:
            // 0x00BB2570: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2574: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2578: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB257C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2580: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_59);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_59);
            // 0x00BB2584: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2588: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB258C: LDR x22, [x8, #0xe0]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1C;
            val_60 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1C;
            // 0x00BB2590: CBNZ x22, #0xbb25dc        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1C != null) goto label_91;
            if(val_60 != null)
            {
                goto label_91;
            }
            // 0x00BB2594: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00BB2598: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB259C: LDR x8, [x8, #0x210]       | X8 = 1152921510033363600;               
            // 0x00BB25A0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB25A4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_pickNextWaypointDist_8(ref object o, object v);
            // 0x00BB25A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_43 = null;
            // 0x00BB25AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB25B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB25B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB25B8: MOV x2, x22                | X2 = 1152921510033363600 (0x1000000143721290);//ML01
            // 0x00BB25BC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_43;
            // 0x00BB25C0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_pickNextWaypointDist_8(ref object o, object v));
            val_43 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_pickNextWaypointDist_8(ref object o, object v));
            // 0x00BB25C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB25C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB25CC: STR x23, [x8, #0xe0]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1C = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569696
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1C = val_56;
            // 0x00BB25D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB25D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB25D8: LDR x22, [x8, #0xe0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_60 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1C;
            label_91:
            // 0x00BB25DC: CBNZ x19, #0xbb25e4        | if (X1 != 0) goto label_92;             
            if(X1 != 0)
            {
                goto label_92;
            }
            // 0x00BB25E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_pickNextWaypointDist_8(ref object o, object v)), ????);
            label_92:
            // 0x00BB25E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB25E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB25EC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB25F0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB25F4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_60);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_60);
            // 0x00BB25F8: CBNZ x20, #0xbb2600        | if (val_1 != null) goto label_93;       
            if(val_1 != null)
            {
                goto label_93;
            }
            // 0x00BB25FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_93:
            // 0x00BB2600: ADRP x9, #0x3660000        | X9 = 57016320 (0x3660000);              
            // 0x00BB2604: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2608: LDR x9, [x9, #0x238]       | X9 = (string**)(1152921510033364624)("forwardLook");
            // 0x00BB260C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2610: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB2614: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2618: LDR x1, [x9]               | X1 = "forwardLook";                     
            // 0x00BB261C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2620: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB2624: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2628: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB262C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2630: LDR x22, [x8, #0xe8]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1D;
            val_61 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1D;
            // 0x00BB2634: CBNZ x22, #0xbb2680        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1D != null) goto label_94;
            if(val_61 != null)
            {
                goto label_94;
            }
            // 0x00BB2638: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00BB263C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2640: LDR x8, [x8, #0x6f0]       | X8 = 1152921510033364720;               
            // 0x00BB2644: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2648: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_forwardLook_9(ref object o);
            // 0x00BB264C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_44 = null;
            // 0x00BB2650: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB2654: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2658: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB265C: MOV x2, x22                | X2 = 1152921510033364720 (0x10000001437216F0);//ML01
            // 0x00BB2660: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_44;
            // 0x00BB2664: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_forwardLook_9(ref object o));
            val_44 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_forwardLook_9(ref object o));
            // 0x00BB2668: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB266C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2670: STR x23, [x8, #0xe8]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1D = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569704
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1D = val_56;
            // 0x00BB2674: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2678: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB267C: LDR x22, [x8, #0xe8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_61 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1D;
            label_94:
            // 0x00BB2680: CBNZ x19, #0xbb2688        | if (X1 != 0) goto label_95;             
            if(X1 != 0)
            {
                goto label_95;
            }
            // 0x00BB2684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_forwardLook_9(ref object o)), ????);
            label_95:
            // 0x00BB2688: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB268C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2690: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2694: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2698: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_61);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_61);
            // 0x00BB269C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB26A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB26A4: LDR x22, [x8, #0xf0]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1E;
            val_62 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1E;
            // 0x00BB26A8: CBNZ x22, #0xbb26f4        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1E != null) goto label_96;
            if(val_62 != null)
            {
                goto label_96;
            }
            // 0x00BB26AC: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00BB26B0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB26B4: LDR x8, [x8, #0xf70]       | X8 = 1152921510033365744;               
            // 0x00BB26B8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB26BC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_forwardLook_9(ref object o, object v);
            // 0x00BB26C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_45 = null;
            // 0x00BB26C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB26C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB26CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB26D0: MOV x2, x22                | X2 = 1152921510033365744 (0x1000000143721AF0);//ML01
            // 0x00BB26D4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_45;
            // 0x00BB26D8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_forwardLook_9(ref object o, object v));
            val_45 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_forwardLook_9(ref object o, object v));
            // 0x00BB26DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB26E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB26E4: STR x23, [x8, #0xf0]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1E = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569712
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1E = val_56;
            // 0x00BB26E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB26EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB26F0: LDR x22, [x8, #0xf0]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_62 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1E;
            label_96:
            // 0x00BB26F4: CBNZ x19, #0xbb26fc        | if (X1 != 0) goto label_97;             
            if(X1 != 0)
            {
                goto label_97;
            }
            // 0x00BB26F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_forwardLook_9(ref object o, object v)), ????);
            label_97:
            // 0x00BB26FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2700: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2704: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2708: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB270C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_62);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_62);
            // 0x00BB2710: CBNZ x20, #0xbb2718        | if (val_1 != null) goto label_98;       
            if(val_1 != null)
            {
                goto label_98;
            }
            // 0x00BB2714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_98:
            // 0x00BB2718: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB271C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2720: LDR x9, [x9, #0x398]       | X9 = (string**)(1152921510033366768)("endReachedDistance");
            // 0x00BB2724: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2728: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB272C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2730: LDR x1, [x9]               | X1 = "endReachedDistance";              
            // 0x00BB2734: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2738: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB273C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2740: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB2744: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2748: LDR x22, [x8, #0xf8]       | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1F;
            val_63 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1F;
            // 0x00BB274C: CBNZ x22, #0xbb2798        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1F != null) goto label_99;
            if(val_63 != null)
            {
                goto label_99;
            }
            // 0x00BB2750: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00BB2754: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2758: LDR x8, [x8, #0xb78]       | X8 = 1152921510033366880;               
            // 0x00BB275C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2760: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_endReachedDistance_10(ref object o);
            // 0x00BB2764: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_46 = null;
            // 0x00BB2768: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB276C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2770: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2774: MOV x2, x22                | X2 = 1152921510033366880 (0x1000000143721F60);//ML01
            // 0x00BB2778: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_46;
            // 0x00BB277C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_endReachedDistance_10(ref object o));
            val_46 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_endReachedDistance_10(ref object o));
            // 0x00BB2780: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2784: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2788: STR x23, [x8, #0xf8]       | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1F = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569720
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1F = val_56;
            // 0x00BB278C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2790: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2794: LDR x22, [x8, #0xf8]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_63 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache1F;
            label_99:
            // 0x00BB2798: CBNZ x19, #0xbb27a0        | if (X1 != 0) goto label_100;            
            if(X1 != 0)
            {
                goto label_100;
            }
            // 0x00BB279C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_endReachedDistance_10(ref object o)), ????);
            label_100:
            // 0x00BB27A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB27A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB27A8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB27AC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB27B0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_63);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_63);
            // 0x00BB27B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB27B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB27BC: LDR x22, [x8, #0x100]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache20;
            val_64 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache20;
            // 0x00BB27C0: CBNZ x22, #0xbb280c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache20 != null) goto label_101;
            if(val_64 != null)
            {
                goto label_101;
            }
            // 0x00BB27C4: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x00BB27C8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB27CC: LDR x8, [x8, #0x838]       | X8 = 1152921510033367904;               
            // 0x00BB27D0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB27D4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_endReachedDistance_10(ref object o, object v);
            // 0x00BB27D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_47 = null;
            // 0x00BB27DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB27E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB27E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB27E8: MOV x2, x22                | X2 = 1152921510033367904 (0x1000000143722360);//ML01
            // 0x00BB27EC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_47;
            // 0x00BB27F0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_endReachedDistance_10(ref object o, object v));
            val_47 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_endReachedDistance_10(ref object o, object v));
            // 0x00BB27F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB27F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB27FC: STR x23, [x8, #0x100]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache20 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569728
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache20 = val_56;
            // 0x00BB2800: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2804: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2808: LDR x22, [x8, #0x100]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_64 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache20;
            label_101:
            // 0x00BB280C: CBNZ x19, #0xbb2814        | if (X1 != 0) goto label_102;            
            if(X1 != 0)
            {
                goto label_102;
            }
            // 0x00BB2810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_endReachedDistance_10(ref object o, object v)), ????);
            label_102:
            // 0x00BB2814: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2818: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB281C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2820: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB2824: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_64);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_64);
            // 0x00BB2828: CBNZ x20, #0xbb2830        | if (val_1 != null) goto label_103;      
            if(val_1 != null)
            {
                goto label_103;
            }
            // 0x00BB282C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_103:
            // 0x00BB2830: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
            // 0x00BB2834: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2838: LDR x9, [x9, #0xbd8]       | X9 = (string**)(1152921510033368928)("closestOnPathCheck");
            // 0x00BB283C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2840: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB2844: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2848: LDR x1, [x9]               | X1 = "closestOnPathCheck";              
            // 0x00BB284C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2850: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB2854: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2858: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB285C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2860: LDR x22, [x8, #0x108]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache21;
            val_65 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache21;
            // 0x00BB2864: CBNZ x22, #0xbb28b0        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache21 != null) goto label_104;
            if(val_65 != null)
            {
                goto label_104;
            }
            // 0x00BB2868: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00BB286C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2870: LDR x8, [x8, #0x98]        | X8 = 1152921510033369040;               
            // 0x00BB2874: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2878: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_closestOnPathCheck_11(ref object o);
            // 0x00BB287C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_48 = null;
            // 0x00BB2880: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB2884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2888: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB288C: MOV x2, x22                | X2 = 1152921510033369040 (0x10000001437227D0);//ML01
            // 0x00BB2890: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_48;
            // 0x00BB2894: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_closestOnPathCheck_11(ref object o));
            val_48 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_closestOnPathCheck_11(ref object o));
            // 0x00BB2898: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB289C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB28A0: STR x23, [x8, #0x108]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569736
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache21 = val_56;
            // 0x00BB28A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB28A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB28AC: LDR x22, [x8, #0x108]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_65 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache21;
            label_104:
            // 0x00BB28B0: CBNZ x19, #0xbb28b8        | if (X1 != 0) goto label_105;            
            if(X1 != 0)
            {
                goto label_105;
            }
            // 0x00BB28B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_closestOnPathCheck_11(ref object o)), ????);
            label_105:
            // 0x00BB28B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB28BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB28C0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB28C4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB28C8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_65);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_65);
            // 0x00BB28CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB28D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB28D4: LDR x22, [x8, #0x110]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache22;
            val_66 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache22;
            // 0x00BB28D8: CBNZ x22, #0xbb2924        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache22 != null) goto label_106;
            if(val_66 != null)
            {
                goto label_106;
            }
            // 0x00BB28DC: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00BB28E0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB28E4: LDR x8, [x8, #0x390]       | X8 = 1152921510033370064;               
            // 0x00BB28E8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB28EC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_closestOnPathCheck_11(ref object o, object v);
            // 0x00BB28F0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_49 = null;
            // 0x00BB28F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB28F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB28FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2900: MOV x2, x22                | X2 = 1152921510033370064 (0x1000000143722BD0);//ML01
            // 0x00BB2904: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_49;
            // 0x00BB2908: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_closestOnPathCheck_11(ref object o, object v));
            val_49 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_closestOnPathCheck_11(ref object o, object v));
            // 0x00BB290C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2910: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2914: STR x23, [x8, #0x110]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569744
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache22 = val_56;
            // 0x00BB2918: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB291C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2920: LDR x22, [x8, #0x110]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_66 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache22;
            label_106:
            // 0x00BB2924: CBNZ x19, #0xbb292c        | if (X1 != 0) goto label_107;            
            if(X1 != 0)
            {
                goto label_107;
            }
            // 0x00BB2928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_closestOnPathCheck_11(ref object o, object v)), ????);
            label_107:
            // 0x00BB292C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2930: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2934: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2938: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB293C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_66);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_66);
            // 0x00BB2940: CBNZ x20, #0xbb2948        | if (val_1 != null) goto label_108;      
            if(val_1 != null)
            {
                goto label_108;
            }
            // 0x00BB2944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_108:
            // 0x00BB2948: ADRP x9, #0x35f3000        | X9 = 56569856 (0x35F3000);              
            // 0x00BB294C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2950: LDR x9, [x9, #0x388]       | X9 = (string**)(1152921510033371088)("tr");
            // 0x00BB2954: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2958: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB295C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2960: LDR x1, [x9]               | X1 = "tr";                              
            // 0x00BB2964: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2968: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB296C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2970: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB2974: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2978: LDR x22, [x8, #0x118]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache23;
            val_67 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache23;
            // 0x00BB297C: CBNZ x22, #0xbb29c8        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache23 != null) goto label_109;
            if(val_67 != null)
            {
                goto label_109;
            }
            // 0x00BB2980: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00BB2984: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2988: LDR x8, [x8, #0x80]        | X8 = 1152921510033371168;               
            // 0x00BB298C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2990: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_tr_12(ref object o);
            // 0x00BB2994: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_50 = null;
            // 0x00BB2998: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB299C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB29A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB29A4: MOV x2, x22                | X2 = 1152921510033371168 (0x1000000143723020);//ML01
            // 0x00BB29A8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_50;
            // 0x00BB29AC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_tr_12(ref object o));
            val_50 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_tr_12(ref object o));
            // 0x00BB29B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB29B4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB29B8: STR x23, [x8, #0x118]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache23 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569752
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache23 = val_56;
            // 0x00BB29BC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB29C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB29C4: LDR x22, [x8, #0x118]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_67 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache23;
            label_109:
            // 0x00BB29C8: CBNZ x19, #0xbb29d0        | if (X1 != 0) goto label_110;            
            if(X1 != 0)
            {
                goto label_110;
            }
            // 0x00BB29CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_tr_12(ref object o)), ????);
            label_110:
            // 0x00BB29D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB29D4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB29D8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB29DC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB29E0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_67);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_67);
            // 0x00BB29E4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB29E8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB29EC: LDR x22, [x8, #0x120]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache24;
            val_68 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache24;
            // 0x00BB29F0: CBNZ x22, #0xbb2a3c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache24 != null) goto label_111;
            if(val_68 != null)
            {
                goto label_111;
            }
            // 0x00BB29F4: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00BB29F8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB29FC: LDR x8, [x8, #0x150]       | X8 = 1152921510033372192;               
            // 0x00BB2A00: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB2A04: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_tr_12(ref object o, object v);
            // 0x00BB2A08: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_51 = null;
            // 0x00BB2A0C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2A10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2A14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2A18: MOV x2, x22                | X2 = 1152921510033372192 (0x1000000143723420);//ML01
            // 0x00BB2A1C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_51;
            // 0x00BB2A20: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_tr_12(ref object o, object v));
            val_51 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_tr_12(ref object o, object v));
            // 0x00BB2A24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2A28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2A2C: STR x23, [x8, #0x120]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache24 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569760
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache24 = val_56;
            // 0x00BB2A30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2A34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2A38: LDR x22, [x8, #0x120]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_68 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache24;
            label_111:
            // 0x00BB2A3C: CBNZ x19, #0xbb2a44        | if (X1 != 0) goto label_112;            
            if(X1 != 0)
            {
                goto label_112;
            }
            // 0x00BB2A40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_tr_12(ref object o, object v)), ????);
            label_112:
            // 0x00BB2A44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2A48: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2A4C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2A50: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB2A54: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_68);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_68);
            // 0x00BB2A58: CBNZ x20, #0xbb2a60        | if (val_1 != null) goto label_113;      
            if(val_1 != null)
            {
                goto label_113;
            }
            // 0x00BB2A5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_113:
            // 0x00BB2A60: ADRP x9, #0x3668000        | X9 = 57049088 (0x3668000);              
            // 0x00BB2A64: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2A68: LDR x9, [x9, #0x660]       | X9 = (string**)(1152921510033373216)("IsSearchPathing");
            // 0x00BB2A6C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2A70: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB2A74: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2A78: LDR x1, [x9]               | X1 = "IsSearchPathing";                 
            // 0x00BB2A7C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2A80: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB2A84: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2A88: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB2A8C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2A90: LDR x22, [x8, #0x128]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache25;
            val_69 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache25;
            // 0x00BB2A94: CBNZ x22, #0xbb2ae0        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache25 != null) goto label_114;
            if(val_69 != null)
            {
                goto label_114;
            }
            // 0x00BB2A98: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00BB2A9C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2AA0: LDR x8, [x8, #0x8b0]       | X8 = 1152921510033373328;               
            // 0x00BB2AA4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2AA8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_IsSearchPathing_13(ref object o);
            // 0x00BB2AAC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_52 = null;
            // 0x00BB2AB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB2AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2AB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2ABC: MOV x2, x22                | X2 = 1152921510033373328 (0x1000000143723890);//ML01
            // 0x00BB2AC0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_56 = val_52;
            // 0x00BB2AC4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_IsSearchPathing_13(ref object o));
            val_52 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_IsSearchPathing_13(ref object o));
            // 0x00BB2AC8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2ACC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2AD0: STR x23, [x8, #0x128]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache25 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569768
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache25 = val_56;
            // 0x00BB2AD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2AD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2ADC: LDR x22, [x8, #0x128]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_69 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache25;
            label_114:
            // 0x00BB2AE0: CBNZ x19, #0xbb2ae8        | if (X1 != 0) goto label_115;            
            if(X1 != 0)
            {
                goto label_115;
            }
            // 0x00BB2AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_IsSearchPathing_13(ref object o)), ????);
            label_115:
            // 0x00BB2AE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2AEC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2AF0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2AF4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2AF8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_69);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_69);
            // 0x00BB2AFC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2B00: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2B04: LDR x22, [x8, #0x130]      | X22 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache26;
            val_70 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache26;
            // 0x00BB2B08: CBNZ x22, #0xbb2b54        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache26 != null) goto label_116;
            if(val_70 != null)
            {
                goto label_116;
            }
            // 0x00BB2B0C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00BB2B10: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB2B14: LDR x8, [x8, #0x4a8]       | X8 = 1152921510033374352;               
            // 0x00BB2B18: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB2B1C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_IsSearchPathing_13(ref object o, object v);
            // 0x00BB2B20: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_53 = null;
            // 0x00BB2B24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2B2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2B30: MOV x2, x22                | X2 = 1152921510033374352 (0x1000000143723C90);//ML01
            // 0x00BB2B34: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_56 = val_53;
            // 0x00BB2B38: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_IsSearchPathing_13(ref object o, object v));
            val_53 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_IsSearchPathing_13(ref object o, object v));
            // 0x00BB2B3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2B40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2B44: STR x23, [x8, #0x130]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache26 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569776
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache26 = val_56;
            // 0x00BB2B48: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2B4C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2B50: LDR x22, [x8, #0x130]      | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_70 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache26;
            label_116:
            // 0x00BB2B54: CBNZ x19, #0xbb2b5c        | if (X1 != 0) goto label_117;            
            if(X1 != 0)
            {
                goto label_117;
            }
            // 0x00BB2B58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_IsSearchPathing_13(ref object o, object v)), ????);
            label_117:
            // 0x00BB2B5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2B60: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2B64: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB2B68: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB2B6C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_70);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_70);
            // 0x00BB2B70: CBNZ x20, #0xbb2b78        | if (val_1 != null) goto label_118;      
            if(val_1 != null)
            {
                goto label_118;
            }
            // 0x00BB2B74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_118:
            // 0x00BB2B78: ADRP x9, #0x35e8000        | X9 = 56524800 (0x35E8000);              
            // 0x00BB2B7C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB2B80: LDR x9, [x9, #0xcf8]       | X9 = (string**)(1152921510033375376)("targetPoint");
            // 0x00BB2B84: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB2B88: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB2B8C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB2B90: LDR x1, [x9]               | X1 = "targetPoint";                     
            // 0x00BB2B94: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB2B98: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB2B9C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2BA0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB2BA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2BA8: LDR x21, [x8, #0x138]      | X21 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache27;
            val_71 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache27;
            // 0x00BB2BAC: CBNZ x21, #0xbb2bf8        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache27 != null) goto label_119;
            if(val_71 != null)
            {
                goto label_119;
            }
            // 0x00BB2BB0: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00BB2BB4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB2BB8: LDR x8, [x8, #0xf40]       | X8 = 1152921510033375472;               
            // 0x00BB2BBC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB2BC0: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_targetPoint_14(ref object o);
            // 0x00BB2BC4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_54 = null;
            // 0x00BB2BC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB2BCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2BD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2BD4: MOV x2, x21                | X2 = 1152921510033375472 (0x10000001437240F0);//ML01
            // 0x00BB2BD8: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2BDC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_targetPoint_14(ref object o));
            val_54 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_targetPoint_14(ref object o));
            // 0x00BB2BE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2BE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2BE8: STR x22, [x8, #0x138]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache27 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782569784
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache27 = val_54;
            // 0x00BB2BEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2BF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2BF4: LDR x21, [x8, #0x138]      | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_71 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache27;
            label_119:
            // 0x00BB2BF8: CBNZ x19, #0xbb2c00        | if (X1 != 0) goto label_120;            
            if(X1 != 0)
            {
                goto label_120;
            }
            // 0x00BB2BFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AIPath_Binding::get_targetPoint_14(ref object o)), ????);
            label_120:
            // 0x00BB2C00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2C04: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2C08: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB2C0C: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB2C10: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_71);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_71);
            // 0x00BB2C14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2C18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2C1C: LDR x21, [x8, #0x140]      | X21 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache28;
            val_72 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache28;
            // 0x00BB2C20: CBNZ x21, #0xbb2c6c        | if (ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache28 != null) goto label_121;
            if(val_72 != null)
            {
                goto label_121;
            }
            // 0x00BB2C24: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x00BB2C28: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB2C2C: LDR x8, [x8, #0x490]       | X8 = 1152921510033376496;               
            // 0x00BB2C30: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB2C34: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_targetPoint_14(ref object o, object v);
            // 0x00BB2C38: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_55 = null;
            // 0x00BB2C3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB2C40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2C44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2C48: MOV x2, x21                | X2 = 1152921510033376496 (0x10000001437244F0);//ML01
            // 0x00BB2C4C: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB2C50: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_targetPoint_14(ref object o, object v));
            val_55 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_targetPoint_14(ref object o, object v));
            // 0x00BB2C54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2C58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2C5C: STR x22, [x8, #0x140]      | ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache28 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782569792
            ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache28 = val_55;
            // 0x00BB2C60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AIPath_Binding);
            // 0x00BB2C64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AIPath_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB2C68: LDR x21, [x8, #0x140]      | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_72 = ILRuntime.Runtime.Generated.AIPath_Binding.<>f__mg$cache28;
            label_121:
            // 0x00BB2C6C: CBNZ x19, #0xbb2c74        | if (X1 != 0) goto label_122;            
            if(X1 != 0)
            {
                goto label_122;
            }
            // 0x00BB2C70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AIPath_Binding::set_targetPoint_14(ref object o, object v)), ????);
            label_122:
            // 0x00BB2C74: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2C78: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB2C7C: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB2C80: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB2C84: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB2C88: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB2C8C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB2C90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2C94: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BB2C98: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_72); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_72);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB2C9C (12266652), len: 616  VirtAddr: 0x00BB2C9C RVA: 0x00BB2C9C token: 100663687 methodIndex: 29732 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_canMove_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BB2C9C: STP x26, x25, [sp, #-0x50]! | stack[1152921510033591552] = ???;  stack[1152921510033591560] = ???;  //  dest_result_addr=1152921510033591552 |  dest_result_addr=1152921510033591560
            // 0x00BB2CA0: STP x24, x23, [sp, #0x10]  | stack[1152921510033591568] = ???;  stack[1152921510033591576] = ???;  //  dest_result_addr=1152921510033591568 |  dest_result_addr=1152921510033591576
            // 0x00BB2CA4: STP x22, x21, [sp, #0x20]  | stack[1152921510033591584] = ???;  stack[1152921510033591592] = ???;  //  dest_result_addr=1152921510033591584 |  dest_result_addr=1152921510033591592
            // 0x00BB2CA8: STP x20, x19, [sp, #0x30]  | stack[1152921510033591600] = ???;  stack[1152921510033591608] = ???;  //  dest_result_addr=1152921510033591600 |  dest_result_addr=1152921510033591608
            // 0x00BB2CAC: STP x29, x30, [sp, #0x40]  | stack[1152921510033591616] = ???;  stack[1152921510033591624] = ???;  //  dest_result_addr=1152921510033591616 |  dest_result_addr=1152921510033591624
            // 0x00BB2CB0: ADD x29, sp, #0x40         | X29 = (1152921510033591552 + 64) = 1152921510033591616 (0x1000000143758D40);
            // 0x00BB2CB4: SUB sp, sp, #0x10          | SP = (1152921510033591552 - 16) = 1152921510033591536 (0x1000000143758CF0);
            // 0x00BB2CB8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB2CBC: LDRB w8, [x19, #0xb18]     | W8 = (bool)static_value_03733B18;       
            // 0x00BB2CC0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB2CC4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB2CC8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BB2CCC: TBNZ w8, #0, #0xbb2ce8     | if (static_value_03733B18 == true) goto label_0;
            // 0x00BB2CD0: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00BB2CD4: LDR x8, [x8, #0xe68]       | X8 = 0x2B8AB24;                         
            // 0x00BB2CD8: LDR w0, [x8]               | W0 = 0x187;                             
            // 0x00BB2CDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x187, ????);      
            // 0x00BB2CE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB2CE4: STRB w8, [x19, #0xb18]     | static_value_03733B18 = true;            //  dest_result_addr=57883416
            label_0:
            // 0x00BB2CE8: CBNZ x20, #0xbb2cf0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB2CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x187, ????);      
            label_1:
            // 0x00BB2CF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2CF4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB2CF8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB2CFC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB2D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2D04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2D08: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB2D0C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB2D10: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB2D14: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BB2D18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2D1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2D20: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB2D24: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB2D28: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB2D2C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB2D30: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB2D34: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB2D38: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB2D3C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB2D40: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB2D44: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB2D48: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB2D4C: TBZ w9, #0, #0xbb2d60      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB2D50: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB2D54: CBNZ w9, #0xbb2d60         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB2D58: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB2D5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB2D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB2D68: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB2D6C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB2D70: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BB2D74: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BB2D78: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB2D7C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB2D80: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB2D84: TBZ w9, #0, #0xbb2d98      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB2D88: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB2D8C: CBNZ w9, #0xbb2d98         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB2D90: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB2D94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB2D98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2D9C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB2DA0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB2DA4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB2DA8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB2DAC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB2DB0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB2DB4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB2DB8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB2DBC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB2DC0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB2DC4: TBZ w9, #0, #0xbb2dd8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB2DC8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB2DCC: CBNZ w9, #0xbb2dd8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB2DD0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB2DD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB2DD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2DDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2DE0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB2DE4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB2DE8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB2DEC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BB2DF0: CBZ x0, #0xbb2e54          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB2DF4: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB2DF8: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB2DFC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB2E00: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB2E04: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB2E08: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB2E0C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB2E10: B.LO #0xbb2e2c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB2E14: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB2E18: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB2E1C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB2E20: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB2E24: MOV x22, x0                | X22 = val_6;//m1                        
            val_10 = val_6;
            // 0x00BB2E28: B.EQ #0xbb2e54             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB2E2C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB2E30: ADD x8, sp, #8             | X8 = (1152921510033591536 + 8) = 1152921510033591544 (0x1000000143758CF8);
            // 0x00BB2E34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB2E38: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510033579632]
            // 0x00BB2E3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB2E40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2E44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB2E48: ADD x0, sp, #8             | X0 = (1152921510033591536 + 8) = 1152921510033591544 (0x1000000143758CF8);
            // 0x00BB2E4C: BL #0x299a140              | 
            // 0x00BB2E50: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_10:
            // 0x00BB2E54: CBNZ x20, #0xbb2e5c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB2E58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143758CF8, ????);
            label_11:
            // 0x00BB2E5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB2E60: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB2E64: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB2E68: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB2E6C: CBNZ x22, #0xbb2e74        | if (0x0 != 0) goto label_12;            
            if(val_10 != 0)
            {
                goto label_12;
            }
            // 0x00BB2E70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB2E74: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BB2E78: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2E7C: LDP x9, x1, [x8, #0x150]   | X9 = mem[282584257677007]; X1 = mem[282584257677015]; //  | 
            // 0x00BB2E80: BLR x9                     | X0 = mem[282584257677007]();            
            // 0x00BB2E84: MOV w20, w0                | W20 = 0 (0x0);//ML01                    
            // 0x00BB2E88: CBZ x19, #0xbb2e9c         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BB2E8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB2E90: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BB2E94: AND w20, w20, #1           | W20 = (val_10 & 1) = val_11 (0x00000000);
            val_11 = 0;
            // 0x00BB2E98: B #0xbb2eb0                |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x00BB2E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x00BB2EA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB2EA4: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BB2EA8: AND w20, w20, #1           | W20 = (val_10 & 1);                     
            val_11 = val_10 & 1;
            // 0x00BB2EAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_14:
            // 0x00BB2EB0: STR w20, [x19, #4]         | mem2[0] = (val_10 & 1);                  //  dest_result_addr=0
            mem2[0] = val_11;
            // 0x00BB2EB4: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB2EB8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BB2EBC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BB2EC0: TBZ w9, #0, #0xbb2ed0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00BB2EC4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BB2EC8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BB2ECC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_15:
            // 0x00BB2ED0: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_9 = val_12 + val_2;
            // 0x00BB2ED4: SUB sp, x29, #0x40         | SP = (1152921510033591616 - 64) = 1152921510033591552 (0x1000000143758D00);
            // 0x00BB2ED8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB2EDC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB2EE0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB2EE4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB2EE8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BB2EEC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB2EF0: MOV x19, x0                | 
            // 0x00BB2EF4: ADD x0, sp, #8             | 
            // 0x00BB2EF8: BL #0x299a140              | 
            // 0x00BB2EFC: MOV x0, x19                | 
            // 0x00BB2F00: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB2F04 (12267268), len: 584  VirtAddr: 0x00BB2F04 RVA: 0x00BB2F04 token: 100663688 methodIndex: 29733 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* set_canMove_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_11;
            // 0x00BB2F04: STP x26, x25, [sp, #-0x50]! | stack[1152921510033760896] = ???;  stack[1152921510033760904] = ???;  //  dest_result_addr=1152921510033760896 |  dest_result_addr=1152921510033760904
            // 0x00BB2F08: STP x24, x23, [sp, #0x10]  | stack[1152921510033760912] = ???;  stack[1152921510033760920] = ???;  //  dest_result_addr=1152921510033760912 |  dest_result_addr=1152921510033760920
            // 0x00BB2F0C: STP x22, x21, [sp, #0x20]  | stack[1152921510033760928] = ???;  stack[1152921510033760936] = ???;  //  dest_result_addr=1152921510033760928 |  dest_result_addr=1152921510033760936
            // 0x00BB2F10: STP x20, x19, [sp, #0x30]  | stack[1152921510033760944] = ???;  stack[1152921510033760952] = ???;  //  dest_result_addr=1152921510033760944 |  dest_result_addr=1152921510033760952
            // 0x00BB2F14: STP x29, x30, [sp, #0x40]  | stack[1152921510033760960] = ???;  stack[1152921510033760968] = ???;  //  dest_result_addr=1152921510033760960 |  dest_result_addr=1152921510033760968
            // 0x00BB2F18: ADD x29, sp, #0x40         | X29 = (1152921510033760896 + 64) = 1152921510033760960 (0x10000001437822C0);
            // 0x00BB2F1C: SUB sp, sp, #0x10          | SP = (1152921510033760896 - 16) = 1152921510033760880 (0x1000000143782270);
            // 0x00BB2F20: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB2F24: LDRB w8, [x20, #0xb19]     | W8 = (bool)static_value_03733B19;       
            // 0x00BB2F28: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB2F2C: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB2F30: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB2F34: TBNZ w8, #0, #0xbb2f50     | if (static_value_03733B19 == true) goto label_0;
            // 0x00BB2F38: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB2F3C: LDR x8, [x8, #0x408]       | X8 = 0x2B8AB80;                         
            // 0x00BB2F40: LDR w0, [x8]               | W0 = 0x19E;                             
            // 0x00BB2F44: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E, ????);      
            // 0x00BB2F48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB2F4C: STRB w8, [x20, #0xb19]     | static_value_03733B19 = true;            //  dest_result_addr=57883417
            label_0:
            // 0x00BB2F50: CBNZ x19, #0xbb2f58        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB2F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19E, ????);      
            label_1:
            // 0x00BB2F58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB2F5C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB2F60: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB2F64: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB2F68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2F6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2F70: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BB2F74: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB2F78: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB2F7C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB2F80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2F84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2F88: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB2F8C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB2F90: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB2F94: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BB2F98: CBNZ x24, #0xbb2fa0        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BB2F9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BB2FA0: LDR w25, [x24, #4]         | W25 = val_3 + 4;                        
            // 0x00BB2FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2FA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB2FAC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BB2FB0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB2FB4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB2FB8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB2FBC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB2FC0: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB2FC4: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00BB2FC8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB2FCC: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB2FD0: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB2FD4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB2FD8: TBZ w9, #0, #0xbb2fec      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BB2FDC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB2FE0: CBNZ w9, #0xbb2fec         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BB2FE4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB2FE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BB2FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB2FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB2FF4: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB2FF8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB2FFC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB3000: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB3004: MOV x24, x0                | X24 = val_5;//m1                        
            // 0x00BB3008: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB300C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB3010: TBZ w9, #0, #0xbb3024      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BB3014: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3018: CBNZ w9, #0xbb3024         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BB301C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB3020: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BB3024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3028: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB302C: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00BB3030: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB3034: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB3038: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB303C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB3040: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB3044: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00BB3048: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB304C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB3050: TBZ w9, #0, #0xbb3064      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BB3054: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3058: CBNZ w9, #0xbb3064         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BB305C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB3060: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BB3064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3068: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB306C: MOV x1, x24                | X1 = val_5;//m1                         
            // 0x00BB3070: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x00BB3074: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BB3078: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BB307C: CBZ x0, #0xbb30e0          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BB3080: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB3084: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB3088: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB308C: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB3090: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3094: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3098: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB309C: B.LO #0xbb30b8             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BB30A0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB30A4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB30A8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB30AC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB30B0: MOV x22, x0                | X22 = val_7;//m1                        
            val_11 = val_7;
            // 0x00BB30B4: B.EQ #0xbb30e0             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BB30B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB30BC: ADD x8, sp, #8             | X8 = (1152921510033760880 + 8) = 1152921510033760888 (0x1000000143782278);
            // 0x00BB30C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB30C4: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510033748976]
            // 0x00BB30C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BB30CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB30D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BB30D4: ADD x0, sp, #8             | X0 = (1152921510033760880 + 8) = 1152921510033760888 (0x1000000143782278);
            // 0x00BB30D8: BL #0x299a140              | 
            // 0x00BB30DC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_11:
            // 0x00BB30E0: CBNZ x19, #0xbb30e8        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BB30E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143782278, ????);
            label_12:
            // 0x00BB30E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB30EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB30F0: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x00BB30F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB30F8: CBNZ x22, #0xbb3100        | if (0x0 != 0) goto label_13;            
            if(val_11 != 0)
            {
                goto label_13;
            }
            // 0x00BB30FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BB3100: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BB3104: CMP w25, #1                | STATE = COMPARE(val_3 + 4, 0x1)         
            // 0x00BB3108: CSET w1, eq                | W1 = val_3 + 4 == 0x1 ? 1 : 0;          
            var val_10 = ((val_3 + 4) == 1) ? 1 : 0;
            // 0x00BB310C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3110: LDP x9, x2, [x8, #0x160]   | X9 = mem[282584257677023]; X2 = mem[282584257677031]; //  | 
            // 0x00BB3114: BLR x9                     | X0 = mem[282584257677023]();            
            // 0x00BB3118: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB311C: SUB sp, x29, #0x40         | SP = (1152921510033760960 - 64) = 1152921510033760896 (0x1000000143782280);
            // 0x00BB3120: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB3124: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB3128: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB312C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB3130: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BB3134: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB3138: MOV x19, x0                | 
            // 0x00BB313C: ADD x0, sp, #8             | 
            // 0x00BB3140: BL #0x299a140              | 
            // 0x00BB3144: MOV x0, x19                | 
            // 0x00BB3148: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB314C (12267852), len: 612  VirtAddr: 0x00BB314C RVA: 0x00BB314C token: 100663689 methodIndex: 29734 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_TargetReached_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x00BB314C: STP x26, x25, [sp, #-0x50]! | stack[1152921510033930240] = ???;  stack[1152921510033930248] = ???;  //  dest_result_addr=1152921510033930240 |  dest_result_addr=1152921510033930248
            // 0x00BB3150: STP x24, x23, [sp, #0x10]  | stack[1152921510033930256] = ???;  stack[1152921510033930264] = ???;  //  dest_result_addr=1152921510033930256 |  dest_result_addr=1152921510033930264
            // 0x00BB3154: STP x22, x21, [sp, #0x20]  | stack[1152921510033930272] = ???;  stack[1152921510033930280] = ???;  //  dest_result_addr=1152921510033930272 |  dest_result_addr=1152921510033930280
            // 0x00BB3158: STP x20, x19, [sp, #0x30]  | stack[1152921510033930288] = ???;  stack[1152921510033930296] = ???;  //  dest_result_addr=1152921510033930288 |  dest_result_addr=1152921510033930296
            // 0x00BB315C: STP x29, x30, [sp, #0x40]  | stack[1152921510033930304] = ???;  stack[1152921510033930312] = ???;  //  dest_result_addr=1152921510033930304 |  dest_result_addr=1152921510033930312
            // 0x00BB3160: ADD x29, sp, #0x40         | X29 = (1152921510033930240 + 64) = 1152921510033930304 (0x10000001437AB840);
            // 0x00BB3164: SUB sp, sp, #0x10          | SP = (1152921510033930240 - 16) = 1152921510033930224 (0x10000001437AB7F0);
            // 0x00BB3168: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB316C: LDRB w8, [x19, #0xb1a]     | W8 = (bool)static_value_03733B1A;       
            // 0x00BB3170: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB3174: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB3178: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BB317C: TBNZ w8, #0, #0xbb3198     | if (static_value_03733B1A == true) goto label_0;
            // 0x00BB3180: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00BB3184: LDR x8, [x8, #0xb98]       | X8 = 0x2B8AB58;                         
            // 0x00BB3188: LDR w0, [x8]               | W0 = 0x194;                             
            // 0x00BB318C: BL #0x2782188              | X0 = sub_2782188( ?? 0x194, ????);      
            // 0x00BB3190: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB3194: STRB w8, [x19, #0xb1a]     | static_value_03733B1A = true;            //  dest_result_addr=57883418
            label_0:
            // 0x00BB3198: CBNZ x20, #0xbb31a0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB319C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x194, ????);      
            label_1:
            // 0x00BB31A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB31A4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB31A8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB31AC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB31B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB31B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB31B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB31BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB31C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB31C4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BB31C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB31CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB31D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB31D4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB31D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB31DC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB31E0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB31E4: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB31E8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB31EC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB31F0: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB31F4: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB31F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB31FC: TBZ w9, #0, #0xbb3210      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3200: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3204: CBNZ w9, #0xbb3210         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB3208: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB320C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3210: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3214: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3218: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB321C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB3220: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BB3224: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BB3228: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB322C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB3230: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB3234: TBZ w9, #0, #0xbb3248      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB3238: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB323C: CBNZ w9, #0xbb3248         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB3240: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB3244: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB3248: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB324C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB3250: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB3254: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB3258: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB325C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB3260: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB3264: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB3268: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB326C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB3270: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB3274: TBZ w9, #0, #0xbb3288      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB3278: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB327C: CBNZ w9, #0xbb3288         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB3280: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB3284: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB3288: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB328C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3290: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB3294: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB3298: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB329C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00BB32A0: CBZ x0, #0xbb3304          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB32A4: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB32A8: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB32AC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB32B0: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB32B4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB32B8: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB32BC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB32C0: B.LO #0xbb32dc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB32C4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB32C8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB32CC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB32D0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB32D4: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x00BB32D8: B.EQ #0xbb3304             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB32DC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB32E0: ADD x8, sp, #8             | X8 = (1152921510033930224 + 8) = 1152921510033930232 (0x10000001437AB7F8);
            // 0x00BB32E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB32E8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510033918320]
            // 0x00BB32EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB32F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB32F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB32F8: ADD x0, sp, #8             | X0 = (1152921510033930224 + 8) = 1152921510033930232 (0x10000001437AB7F8);
            // 0x00BB32FC: BL #0x299a140              | 
            // 0x00BB3300: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x00BB3304: CBNZ x20, #0xbb330c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB3308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001437AB7F8, ????);
            label_11:
            // 0x00BB330C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3310: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB3314: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB3318: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB331C: CBNZ x22, #0xbb3324        | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x00BB3320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB3324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3328: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB332C: BL #0xb24258               | X0 = val_13.get_TargetReached();        
            bool val_9 = val_13.TargetReached;
            // 0x00BB3330: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x00BB3334: CBZ x19, #0xbb3348         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BB3338: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB333C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BB3340: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x00BB3344: B #0xbb335c                |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x00BB3348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00BB334C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB3350: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x00BB3354: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x00BB3358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x00BB335C: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x00BB3360: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB3364: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x00BB3368: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BB336C: TBZ w9, #0, #0xbb337c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x00BB3370: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BB3374: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BB3378: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x00BB337C: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x00BB3380: SUB sp, x29, #0x40         | SP = (1152921510033930304 - 64) = 1152921510033930240 (0x10000001437AB800);
            // 0x00BB3384: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB3388: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB338C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB3390: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB3394: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BB3398: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB339C: MOV x19, x0                | 
            // 0x00BB33A0: ADD x0, sp, #8             | 
            // 0x00BB33A4: BL #0x299a140              | 
            // 0x00BB33A8: MOV x0, x19                | 
            // 0x00BB33AC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB33B0 (12268464), len: 532  VirtAddr: 0x00BB33B0 RVA: 0x00BB33B0 token: 100663690 methodIndex: 29735 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Start_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BB33B0: STP x24, x23, [sp, #-0x40]! | stack[1152921510034099600] = ???;  stack[1152921510034099608] = ???;  //  dest_result_addr=1152921510034099600 |  dest_result_addr=1152921510034099608
            // 0x00BB33B4: STP x22, x21, [sp, #0x10]  | stack[1152921510034099616] = ???;  stack[1152921510034099624] = ???;  //  dest_result_addr=1152921510034099616 |  dest_result_addr=1152921510034099624
            // 0x00BB33B8: STP x20, x19, [sp, #0x20]  | stack[1152921510034099632] = ???;  stack[1152921510034099640] = ???;  //  dest_result_addr=1152921510034099632 |  dest_result_addr=1152921510034099640
            // 0x00BB33BC: STP x29, x30, [sp, #0x30]  | stack[1152921510034099648] = ???;  stack[1152921510034099656] = ???;  //  dest_result_addr=1152921510034099648 |  dest_result_addr=1152921510034099656
            // 0x00BB33C0: ADD x29, sp, #0x30         | X29 = (1152921510034099600 + 48) = 1152921510034099648 (0x10000001437D4DC0);
            // 0x00BB33C4: SUB sp, sp, #0x10          | SP = (1152921510034099600 - 16) = 1152921510034099584 (0x10000001437D4D80);
            // 0x00BB33C8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB33CC: LDRB w8, [x20, #0xb1b]     | W8 = (bool)static_value_03733B1B;       
            // 0x00BB33D0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB33D4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB33D8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB33DC: TBNZ w8, #0, #0xbb33f8     | if (static_value_03733B1B == true) goto label_0;
            // 0x00BB33E0: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00BB33E4: LDR x8, [x8, #0x7f0]       | X8 = 0x2B8ABBC;                         
            // 0x00BB33E8: LDR w0, [x8]               | W0 = 0x1AD;                             
            // 0x00BB33EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1AD, ????);      
            // 0x00BB33F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB33F4: STRB w8, [x20, #0xb1b]     | static_value_03733B1B = true;            //  dest_result_addr=57883419
            label_0:
            // 0x00BB33F8: CBNZ x19, #0xbb3400        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB33FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AD, ????);      
            label_1:
            // 0x00BB3400: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3404: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB3408: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB340C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB3410: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3414: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3418: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB341C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3420: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3424: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB3428: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB342C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3430: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3434: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3438: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB343C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB3440: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB3444: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB3448: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB344C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB3450: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB3454: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB3458: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB345C: TBZ w9, #0, #0xbb3470      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3460: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3464: CBNZ w9, #0xbb3470         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB3468: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB346C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3478: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB347C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB3480: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB3484: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB3488: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB348C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB3490: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB3494: TBZ w9, #0, #0xbb34a8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB3498: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB349C: CBNZ w9, #0xbb34a8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB34A0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB34A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB34A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB34AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB34B0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB34B4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB34B8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB34BC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB34C0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB34C4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB34C8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB34CC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB34D0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB34D4: TBZ w9, #0, #0xbb34e8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB34D8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB34DC: CBNZ w9, #0xbb34e8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB34E0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB34E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB34E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB34EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB34F0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB34F4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB34F8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB34FC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BB3500: CBZ x0, #0xbb3564          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB3504: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB3508: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB350C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB3510: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB3514: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3518: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB351C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB3520: B.LO #0xbb353c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB3524: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB3528: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB352C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB3530: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB3534: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BB3538: B.EQ #0xbb3564             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB353C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB3540: ADD x8, sp, #8             | X8 = (1152921510034099584 + 8) = 1152921510034099592 (0x10000001437D4D88);
            // 0x00BB3544: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB3548: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510034087664]
            // 0x00BB354C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB3550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3554: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB3558: ADD x0, sp, #8             | X0 = (1152921510034099584 + 8) = 1152921510034099592 (0x10000001437D4D88);
            // 0x00BB355C: BL #0x299a140              | 
            // 0x00BB3560: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BB3564: CBNZ x19, #0xbb356c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB3568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001437D4D88, ????);
            label_11:
            // 0x00BB356C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3570: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB3574: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB3578: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB357C: CBNZ x22, #0xbb3584        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BB3580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB3584: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BB3588: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB358C: LDP x9, x1, [x8, #0x180]   | X9 = mem[282584257677055]; X1 = mem[282584257677063]; //  | 
            // 0x00BB3590: BLR x9                     | X0 = mem[282584257677055]();            
            // 0x00BB3594: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB3598: SUB sp, x29, #0x30         | SP = (1152921510034099648 - 48) = 1152921510034099600 (0x10000001437D4D90);
            // 0x00BB359C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB35A0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB35A4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB35A8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB35AC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB35B0: MOV x19, x0                | 
            // 0x00BB35B4: ADD x0, sp, #8             | 
            // 0x00BB35B8: BL #0x299a140              | 
            // 0x00BB35BC: MOV x0, x19                | 
            // 0x00BB35C0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB35C4 (12268996), len: 528  VirtAddr: 0x00BB35C4 RVA: 0x00BB35C4 token: 100663691 methodIndex: 29736 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnDisable_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BB35C4: STP x24, x23, [sp, #-0x40]! | stack[1152921510034268944] = ???;  stack[1152921510034268952] = ???;  //  dest_result_addr=1152921510034268944 |  dest_result_addr=1152921510034268952
            // 0x00BB35C8: STP x22, x21, [sp, #0x10]  | stack[1152921510034268960] = ???;  stack[1152921510034268968] = ???;  //  dest_result_addr=1152921510034268960 |  dest_result_addr=1152921510034268968
            // 0x00BB35CC: STP x20, x19, [sp, #0x20]  | stack[1152921510034268976] = ???;  stack[1152921510034268984] = ???;  //  dest_result_addr=1152921510034268976 |  dest_result_addr=1152921510034268984
            // 0x00BB35D0: STP x29, x30, [sp, #0x30]  | stack[1152921510034268992] = ???;  stack[1152921510034269000] = ???;  //  dest_result_addr=1152921510034268992 |  dest_result_addr=1152921510034269000
            // 0x00BB35D4: ADD x29, sp, #0x30         | X29 = (1152921510034268944 + 48) = 1152921510034268992 (0x10000001437FE340);
            // 0x00BB35D8: SUB sp, sp, #0x10          | SP = (1152921510034268944 - 16) = 1152921510034268928 (0x10000001437FE300);
            // 0x00BB35DC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB35E0: LDRB w8, [x20, #0xb1c]     | W8 = (bool)static_value_03733B1C;       
            // 0x00BB35E4: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB35E8: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB35EC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB35F0: TBNZ w8, #0, #0xbb360c     | if (static_value_03733B1C == true) goto label_0;
            // 0x00BB35F4: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00BB35F8: LDR x8, [x8, #0xe10]       | X8 = 0x2B8AB68;                         
            // 0x00BB35FC: LDR w0, [x8]               | W0 = 0x198;                             
            // 0x00BB3600: BL #0x2782188              | X0 = sub_2782188( ?? 0x198, ????);      
            // 0x00BB3604: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB3608: STRB w8, [x20, #0xb1c]     | static_value_03733B1C = true;            //  dest_result_addr=57883420
            label_0:
            // 0x00BB360C: CBNZ x19, #0xbb3614        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB3610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x198, ????);      
            label_1:
            // 0x00BB3614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3618: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB361C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB3620: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB3624: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3628: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB362C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3630: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3634: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3638: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB363C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3640: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3644: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3648: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB364C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3650: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB3654: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB3658: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB365C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB3660: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB3664: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB3668: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB366C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB3670: TBZ w9, #0, #0xbb3684      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3674: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3678: CBNZ w9, #0xbb3684         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB367C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB3680: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3684: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3688: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB368C: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB3690: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB3694: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB3698: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB369C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB36A0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB36A4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB36A8: TBZ w9, #0, #0xbb36bc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB36AC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB36B0: CBNZ w9, #0xbb36bc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB36B4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB36B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB36BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB36C0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB36C4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB36C8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB36CC: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB36D0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB36D4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB36D8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB36DC: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB36E0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB36E4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB36E8: TBZ w9, #0, #0xbb36fc      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB36EC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB36F0: CBNZ w9, #0xbb36fc         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB36F4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB36F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB36FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3700: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3704: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB3708: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB370C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB3710: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BB3714: CBZ x0, #0xbb3778          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB3718: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB371C: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB3720: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB3724: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB3728: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB372C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3730: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB3734: B.LO #0xbb3750             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB3738: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB373C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB3740: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB3744: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB3748: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BB374C: B.EQ #0xbb3778             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB3750: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB3754: ADD x8, sp, #8             | X8 = (1152921510034268928 + 8) = 1152921510034268936 (0x10000001437FE308);
            // 0x00BB3758: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB375C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510034257008]
            // 0x00BB3760: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB3764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3768: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB376C: ADD x0, sp, #8             | X0 = (1152921510034268928 + 8) = 1152921510034268936 (0x10000001437FE308);
            // 0x00BB3770: BL #0x299a140              | 
            // 0x00BB3774: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BB3778: CBNZ x19, #0xbb3780        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB377C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001437FE308, ????);
            label_11:
            // 0x00BB3780: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3784: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB3788: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB378C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB3790: CBNZ x22, #0xbb3798        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BB3794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB3798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB379C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB37A0: BL #0xb24548               | val_9.OnDisable();                      
            val_9.OnDisable();
            // 0x00BB37A4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB37A8: SUB sp, x29, #0x30         | SP = (1152921510034268992 - 48) = 1152921510034268944 (0x10000001437FE310);
            // 0x00BB37AC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB37B0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB37B4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB37B8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB37BC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB37C0: MOV x19, x0                | 
            // 0x00BB37C4: ADD x0, sp, #8             | 
            // 0x00BB37C8: BL #0x299a140              | 
            // 0x00BB37CC: MOV x0, x19                | 
            // 0x00BB37D0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB37D4 (12269524), len: 588  VirtAddr: 0x00BB37D4 RVA: 0x00BB37D4 token: 100663692 methodIndex: 29737 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* TrySearchPath_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BB37D4: STP x26, x25, [sp, #-0x50]! | stack[1152921510034438272] = ???;  stack[1152921510034438280] = ???;  //  dest_result_addr=1152921510034438272 |  dest_result_addr=1152921510034438280
            // 0x00BB37D8: STP x24, x23, [sp, #0x10]  | stack[1152921510034438288] = ???;  stack[1152921510034438296] = ???;  //  dest_result_addr=1152921510034438288 |  dest_result_addr=1152921510034438296
            // 0x00BB37DC: STP x22, x21, [sp, #0x20]  | stack[1152921510034438304] = ???;  stack[1152921510034438312] = ???;  //  dest_result_addr=1152921510034438304 |  dest_result_addr=1152921510034438312
            // 0x00BB37E0: STP x20, x19, [sp, #0x30]  | stack[1152921510034438320] = ???;  stack[1152921510034438328] = ???;  //  dest_result_addr=1152921510034438320 |  dest_result_addr=1152921510034438328
            // 0x00BB37E4: STP x29, x30, [sp, #0x40]  | stack[1152921510034438336] = ???;  stack[1152921510034438344] = ???;  //  dest_result_addr=1152921510034438336 |  dest_result_addr=1152921510034438344
            // 0x00BB37E8: ADD x29, sp, #0x40         | X29 = (1152921510034438272 + 64) = 1152921510034438336 (0x10000001438278C0);
            // 0x00BB37EC: SUB sp, sp, #0x10          | SP = (1152921510034438272 - 16) = 1152921510034438256 (0x1000000143827870);
            // 0x00BB37F0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB37F4: LDRB w8, [x19, #0xb1d]     | W8 = (bool)static_value_03733B1D;       
            // 0x00BB37F8: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB37FC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB3800: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BB3804: TBNZ w8, #0, #0xbb3820     | if (static_value_03733B1D == true) goto label_0;
            // 0x00BB3808: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00BB380C: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8ABC0;                         
            // 0x00BB3810: LDR w0, [x8]               | W0 = 0x1AE;                             
            // 0x00BB3814: BL #0x2782188              | X0 = sub_2782188( ?? 0x1AE, ????);      
            // 0x00BB3818: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB381C: STRB w8, [x19, #0xb1d]     | static_value_03733B1D = true;            //  dest_result_addr=57883421
            label_0:
            // 0x00BB3820: CBNZ x20, #0xbb3828        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB3824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AE, ????);      
            label_1:
            // 0x00BB3828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB382C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB3830: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB3834: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB3838: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB383C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3840: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3844: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3848: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB384C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BB3850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3854: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3858: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB385C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3860: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3864: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB3868: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB386C: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB3870: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB3874: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB3878: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB387C: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB3880: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB3884: TBZ w9, #0, #0xbb3898      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3888: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB388C: CBNZ w9, #0xbb3898         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB3890: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB3894: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3898: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB389C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB38A0: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB38A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB38A8: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BB38AC: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BB38B0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB38B4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB38B8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB38BC: TBZ w9, #0, #0xbb38d0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB38C0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB38C4: CBNZ w9, #0xbb38d0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB38C8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB38CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB38D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB38D4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB38D8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB38DC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB38E0: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB38E4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB38E8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB38EC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB38F0: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB38F4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB38F8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB38FC: TBZ w9, #0, #0xbb3910      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB3900: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3904: CBNZ w9, #0xbb3910         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB3908: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB390C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB3910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3914: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3918: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB391C: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB3920: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB3924: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BB3928: CBZ x0, #0xbb398c          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB392C: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB3930: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB3934: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB3938: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB393C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3940: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3944: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB3948: B.LO #0xbb3964             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB394C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB3950: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB3954: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB3958: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB395C: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BB3960: B.EQ #0xbb398c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB3964: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB3968: ADD x8, sp, #8             | X8 = (1152921510034438256 + 8) = 1152921510034438264 (0x1000000143827878);
            // 0x00BB396C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB3970: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510034426352]
            // 0x00BB3974: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB3978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB397C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB3980: ADD x0, sp, #8             | X0 = (1152921510034438256 + 8) = 1152921510034438264 (0x1000000143827878);
            // 0x00BB3984: BL #0x299a140              | 
            // 0x00BB3988: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BB398C: CBNZ x20, #0xbb3994        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB3990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143827878, ????);
            label_11:
            // 0x00BB3994: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3998: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB399C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB39A0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB39A4: CBNZ x22, #0xbb39ac        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BB39A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB39AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB39B0: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB39B4: BL #0xb246f8               | X0 = val_11.TrySearchPath();            
            float val_9 = val_11.TrySearchPath();
            // 0x00BB39B8: CBZ x19, #0xbb3a18         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BB39BC: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BB39C0: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00BB39C4: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x00BB39C8: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB39CC: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BB39D0: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BB39D4: TBZ w9, #0, #0xbb39e4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BB39D8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BB39DC: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BB39E0: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BB39E4: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BB39E8: SUB sp, x29, #0x40         | SP = (1152921510034438336 - 64) = 1152921510034438272 (0x1000000143827880);
            // 0x00BB39EC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB39F0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB39F4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB39F8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB39FC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BB3A00: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB3A04: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BB3A08: ADD x0, sp, #8             | X0 = (1152921510034438352 + 8) = 1152921510034438360 (0x10000001438278D8);
            // 0x00BB3A0C: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001438278D8); //ERROR_TYPE
            // 0x00BB3A10: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BB3A14: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BB3A18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BB3A1C: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB3A20 (12270112), len: 556  VirtAddr: 0x00BB3A20 RVA: 0x00BB3A20 token: 100663693 methodIndex: 29738 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SearchPath_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            // 0x00BB3A20: STP x24, x23, [sp, #-0x40]! | stack[1152921510034607632] = ???;  stack[1152921510034607640] = ???;  //  dest_result_addr=1152921510034607632 |  dest_result_addr=1152921510034607640
            // 0x00BB3A24: STP x22, x21, [sp, #0x10]  | stack[1152921510034607648] = ???;  stack[1152921510034607656] = ???;  //  dest_result_addr=1152921510034607648 |  dest_result_addr=1152921510034607656
            // 0x00BB3A28: STP x20, x19, [sp, #0x20]  | stack[1152921510034607664] = ???;  stack[1152921510034607672] = ???;  //  dest_result_addr=1152921510034607664 |  dest_result_addr=1152921510034607672
            // 0x00BB3A2C: STP x29, x30, [sp, #0x30]  | stack[1152921510034607680] = ???;  stack[1152921510034607688] = ???;  //  dest_result_addr=1152921510034607680 |  dest_result_addr=1152921510034607688
            // 0x00BB3A30: ADD x29, sp, #0x30         | X29 = (1152921510034607632 + 48) = 1152921510034607680 (0x1000000143850E40);
            // 0x00BB3A34: SUB sp, sp, #0x10          | SP = (1152921510034607632 - 16) = 1152921510034607616 (0x1000000143850E00);
            // 0x00BB3A38: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB3A3C: LDRB w8, [x21, #0xb1e]     | W8 = (bool)static_value_03733B1E;       
            // 0x00BB3A40: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BB3A44: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BB3A48: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BB3A4C: TBNZ w8, #0, #0xbb3a68     | if (static_value_03733B1E == true) goto label_0;
            // 0x00BB3A50: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00BB3A54: LDR x8, [x8, #0xea0]       | X8 = 0x2B8AB78;                         
            // 0x00BB3A58: LDR w0, [x8]               | W0 = 0x19C;                             
            // 0x00BB3A5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x19C, ????);      
            // 0x00BB3A60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB3A64: STRB w8, [x21, #0xb1e]     | static_value_03733B1E = true;            //  dest_result_addr=57883422
            label_0:
            // 0x00BB3A68: CBNZ x20, #0xbb3a70        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB3A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19C, ????);      
            label_1:
            // 0x00BB3A70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3A74: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB3A78: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB3A7C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB3A80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3A84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3A88: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3A8C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB3A90: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3A94: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BB3A98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3A9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3AA0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3AA4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB3AA8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3AAC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB3AB0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB3AB4: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB3AB8: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BB3ABC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB3AC0: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB3AC4: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB3AC8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB3ACC: TBZ w9, #0, #0xbb3ae0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3AD0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3AD4: CBNZ w9, #0xbb3ae0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB3AD8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB3ADC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3AE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3AE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3AE8: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB3AEC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB3AF0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB3AF4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB3AF8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB3AFC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB3B00: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB3B04: TBZ w9, #0, #0xbb3b18      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB3B08: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3B0C: CBNZ w9, #0xbb3b18         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB3B10: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB3B14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB3B18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3B1C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB3B20: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BB3B24: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB3B28: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BB3B2C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB3B30: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB3B34: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB3B38: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BB3B3C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB3B40: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB3B44: TBZ w9, #0, #0xbb3b58      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB3B48: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3B4C: CBNZ w9, #0xbb3b58         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB3B50: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB3B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB3B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3B5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3B60: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB3B64: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BB3B68: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB3B6C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BB3B70: CBZ x0, #0xbb3bd4          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB3B74: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB3B78: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB3B7C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB3B80: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB3B84: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3B88: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3B8C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB3B90: B.LO #0xbb3bac             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB3B94: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB3B98: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB3B9C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB3BA0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB3BA4: MOV x23, x0                | X23 = val_6;//m1                        
            val_10 = val_6;
            // 0x00BB3BA8: B.EQ #0xbb3bd4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB3BAC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB3BB0: ADD x8, sp, #8             | X8 = (1152921510034607616 + 8) = 1152921510034607624 (0x1000000143850E08);
            // 0x00BB3BB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB3BB8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510034595696]
            // 0x00BB3BBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB3BC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3BC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB3BC8: ADD x0, sp, #8             | X0 = (1152921510034607616 + 8) = 1152921510034607624 (0x1000000143850E08);
            // 0x00BB3BCC: BL #0x299a140              | 
            // 0x00BB3BD0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_10:
            // 0x00BB3BD4: CBNZ x20, #0xbb3bdc        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB3BD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143850E08, ????);
            label_11:
            // 0x00BB3BDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3BE0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BB3BE4: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BB3BE8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB3BEC: CBNZ x23, #0xbb3bf4        | if (0x0 != 0) goto label_12;            
            if(val_10 != 0)
            {
                goto label_12;
            }
            // 0x00BB3BF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB3BF4: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x00BB3BF8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3BFC: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[282584257677087]; X1 = mem[282584257677095]; //  | 
            // 0x00BB3C00: BLR x9                     | X0 = mem[282584257677087]();            
            // 0x00BB3C04: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x00BB3C08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3C0C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BB3C10: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BB3C14: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BB3C18: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB3C1C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x00BB3C20: SUB sp, x29, #0x30         | SP = (1152921510034607680 - 48) = 1152921510034607632 (0x1000000143850E10);
            // 0x00BB3C24: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB3C28: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB3C2C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB3C30: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB3C34: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB3C38: MOV x19, x0                | 
            // 0x00BB3C3C: ADD x0, sp, #8             | 
            // 0x00BB3C40: BL #0x299a140              | 
            // 0x00BB3C44: MOV x0, x19                | 
            // 0x00BB3C48: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB3C4C (12270668), len: 532  VirtAddr: 0x00BB3C4C RVA: 0x00BB3C4C token: 100663694 methodIndex: 29739 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnTargetReached_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BB3C4C: STP x24, x23, [sp, #-0x40]! | stack[1152921510034776976] = ???;  stack[1152921510034776984] = ???;  //  dest_result_addr=1152921510034776976 |  dest_result_addr=1152921510034776984
            // 0x00BB3C50: STP x22, x21, [sp, #0x10]  | stack[1152921510034776992] = ???;  stack[1152921510034777000] = ???;  //  dest_result_addr=1152921510034776992 |  dest_result_addr=1152921510034777000
            // 0x00BB3C54: STP x20, x19, [sp, #0x20]  | stack[1152921510034777008] = ???;  stack[1152921510034777016] = ???;  //  dest_result_addr=1152921510034777008 |  dest_result_addr=1152921510034777016
            // 0x00BB3C58: STP x29, x30, [sp, #0x30]  | stack[1152921510034777024] = ???;  stack[1152921510034777032] = ???;  //  dest_result_addr=1152921510034777024 |  dest_result_addr=1152921510034777032
            // 0x00BB3C5C: ADD x29, sp, #0x30         | X29 = (1152921510034776976 + 48) = 1152921510034777024 (0x100000014387A3C0);
            // 0x00BB3C60: SUB sp, sp, #0x10          | SP = (1152921510034776976 - 16) = 1152921510034776960 (0x100000014387A380);
            // 0x00BB3C64: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB3C68: LDRB w8, [x20, #0xb1f]     | W8 = (bool)static_value_03733B1F;       
            // 0x00BB3C6C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB3C70: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB3C74: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB3C78: TBNZ w8, #0, #0xbb3c94     | if (static_value_03733B1F == true) goto label_0;
            // 0x00BB3C7C: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00BB3C80: LDR x8, [x8, #0x88]        | X8 = 0x2B8AB70;                         
            // 0x00BB3C84: LDR w0, [x8]               | W0 = 0x19A;                             
            // 0x00BB3C88: BL #0x2782188              | X0 = sub_2782188( ?? 0x19A, ????);      
            // 0x00BB3C8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB3C90: STRB w8, [x20, #0xb1f]     | static_value_03733B1F = true;            //  dest_result_addr=57883423
            label_0:
            // 0x00BB3C94: CBNZ x19, #0xbb3c9c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB3C98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19A, ????);      
            label_1:
            // 0x00BB3C9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3CA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB3CA4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB3CA8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB3CAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3CB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3CB4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3CB8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3CBC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3CC0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB3CC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3CC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3CCC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3CD0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB3CD4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3CD8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB3CDC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB3CE0: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB3CE4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB3CE8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB3CEC: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB3CF0: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB3CF4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB3CF8: TBZ w9, #0, #0xbb3d0c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3CFC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3D00: CBNZ w9, #0xbb3d0c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB3D04: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB3D08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3D10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3D14: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB3D18: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB3D1C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB3D20: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB3D24: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB3D28: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB3D2C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB3D30: TBZ w9, #0, #0xbb3d44      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB3D34: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3D38: CBNZ w9, #0xbb3d44         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB3D3C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB3D40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB3D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3D48: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB3D4C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB3D50: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB3D54: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB3D58: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB3D5C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB3D60: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB3D64: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB3D68: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB3D6C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB3D70: TBZ w9, #0, #0xbb3d84      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB3D74: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3D78: CBNZ w9, #0xbb3d84         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB3D7C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB3D80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB3D84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3D88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3D8C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB3D90: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB3D94: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB3D98: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BB3D9C: CBZ x0, #0xbb3e00          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB3DA0: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB3DA4: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB3DA8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB3DAC: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB3DB0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3DB4: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3DB8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB3DBC: B.LO #0xbb3dd8             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB3DC0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB3DC4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB3DC8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB3DCC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB3DD0: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BB3DD4: B.EQ #0xbb3e00             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB3DD8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB3DDC: ADD x8, sp, #8             | X8 = (1152921510034776960 + 8) = 1152921510034776968 (0x100000014387A388);
            // 0x00BB3DE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB3DE4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510034765040]
            // 0x00BB3DE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB3DEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3DF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB3DF4: ADD x0, sp, #8             | X0 = (1152921510034776960 + 8) = 1152921510034776968 (0x100000014387A388);
            // 0x00BB3DF8: BL #0x299a140              | 
            // 0x00BB3DFC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BB3E00: CBNZ x19, #0xbb3e08        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB3E04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014387A388, ????);
            label_11:
            // 0x00BB3E08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3E0C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB3E10: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB3E14: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB3E18: CBNZ x22, #0xbb3e20        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BB3E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB3E20: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BB3E24: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3E28: LDP x9, x1, [x8, #0x1b0]   | X9 = mem[282584257677103]; X1 = mem[282584257677111]; //  | 
            // 0x00BB3E2C: BLR x9                     | X0 = mem[282584257677103]();            
            // 0x00BB3E30: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB3E34: SUB sp, x29, #0x30         | SP = (1152921510034777024 - 48) = 1152921510034776976 (0x100000014387A390);
            // 0x00BB3E38: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB3E3C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB3E40: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB3E44: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB3E48: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB3E4C: MOV x19, x0                | 
            // 0x00BB3E50: ADD x0, sp, #8             | 
            // 0x00BB3E54: BL #0x299a140              | 
            // 0x00BB3E58: MOV x0, x19                | 
            // 0x00BB3E5C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB3E60 (12271200), len: 780  VirtAddr: 0x00BB3E60 RVA: 0x00BB3E60 token: 100663695 methodIndex: 29740 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnPathComplete_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            // 0x00BB3E60: STP x26, x25, [sp, #-0x50]! | stack[1152921510034958592] = ???;  stack[1152921510034958600] = ???;  //  dest_result_addr=1152921510034958592 |  dest_result_addr=1152921510034958600
            // 0x00BB3E64: STP x24, x23, [sp, #0x10]  | stack[1152921510034958608] = ???;  stack[1152921510034958616] = ???;  //  dest_result_addr=1152921510034958608 |  dest_result_addr=1152921510034958616
            // 0x00BB3E68: STP x22, x21, [sp, #0x20]  | stack[1152921510034958624] = ???;  stack[1152921510034958632] = ???;  //  dest_result_addr=1152921510034958624 |  dest_result_addr=1152921510034958632
            // 0x00BB3E6C: STP x20, x19, [sp, #0x30]  | stack[1152921510034958640] = ???;  stack[1152921510034958648] = ???;  //  dest_result_addr=1152921510034958640 |  dest_result_addr=1152921510034958648
            // 0x00BB3E70: STP x29, x30, [sp, #0x40]  | stack[1152921510034958656] = ???;  stack[1152921510034958664] = ???;  //  dest_result_addr=1152921510034958656 |  dest_result_addr=1152921510034958664
            // 0x00BB3E74: ADD x29, sp, #0x40         | X29 = (1152921510034958592 + 64) = 1152921510034958656 (0x10000001438A6940);
            // 0x00BB3E78: SUB sp, sp, #0x10          | SP = (1152921510034958592 - 16) = 1152921510034958576 (0x10000001438A68F0);
            // 0x00BB3E7C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB3E80: LDRB w8, [x20, #0xb20]     | W8 = (bool)static_value_03733B20;       
            // 0x00BB3E84: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BB3E88: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BB3E8C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB3E90: TBNZ w8, #0, #0xbb3eac     | if (static_value_03733B20 == true) goto label_0;
            // 0x00BB3E94: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00BB3E98: LDR x8, [x8, #0x248]       | X8 = 0x2B8AB6C;                         
            // 0x00BB3E9C: LDR w0, [x8]               | W0 = 0x199;                             
            // 0x00BB3EA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x199, ????);      
            // 0x00BB3EA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB3EA8: STRB w8, [x20, #0xb20]     | static_value_03733B20 = true;            //  dest_result_addr=57883424
            label_0:
            // 0x00BB3EAC: CBNZ x19, #0xbb3eb4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB3EB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x199, ????);      
            label_1:
            // 0x00BB3EB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB3EB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB3EBC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB3EC0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB3EC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3EC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3ECC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BB3ED0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB3ED4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3ED8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB3EDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3EE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3EE4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB3EE8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB3EEC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB3EF0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB3EF4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB3EF8: ADRP x9, #0x35e1000        | X9 = 56496128 (0x35E1000);              
            // 0x00BB3EFC: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BB3F00: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB3F04: LDR x9, [x9, #0x728]       | X9 = 1152921504840552448;               
            // 0x00BB3F08: LDR x25, [x9]              | X25 = typeof(Pathfinding.Path);         
            // 0x00BB3F0C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB3F10: TBZ w9, #0, #0xbb3f24      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB3F14: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3F18: CBNZ w9, #0xbb3f24         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB3F1C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB3F20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB3F24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB3F2C: MOV x1, x25                | X1 = 1152921504840552448 (0x100000000DEE1000);//ML01
            // 0x00BB3F30: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB3F34: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB3F38: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB3F3C: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BB3F40: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB3F44: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB3F48: TBZ w9, #0, #0xbb3f5c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB3F4C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3F50: CBNZ w9, #0xbb3f5c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB3F54: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB3F58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB3F5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3F60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB3F64: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BB3F68: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB3F6C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BB3F70: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB3F74: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB3F78: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB3F7C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BB3F80: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB3F84: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB3F88: TBZ w9, #0, #0xbb3f9c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB3F8C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB3F90: CBNZ w9, #0xbb3f9c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB3F94: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB3F98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB3F9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB3FA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB3FA4: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BB3FA8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BB3FAC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB3FB0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BB3FB4: CBZ x0, #0xbb4018          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB3FB8: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x00BB3FBC: LDR x9, [x9, #0x110]       | X9 = 1152921504840552448;               
            // 0x00BB3FC0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB3FC4: LDR x1, [x9]               | X1 = typeof(Pathfinding.Path);          
            // 0x00BB3FC8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3FCC: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB3FD0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB3FD4: B.LO #0xbb3ff0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB3FD8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB3FDC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Path.__il2cppRuntimeField_type
            // 0x00BB3FE0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB3FE4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.Path))
            // 0x00BB3FE8: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x00BB3FEC: B.EQ #0xbb4018             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Path.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB3FF0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB3FF4: MOV x8, sp                 | X8 = 1152921510034958576 (0x10000001438A68F0);//ML01
            // 0x00BB3FF8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB3FFC: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510034946672]
            // 0x00BB4000: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB4004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4008: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB400C: MOV x0, sp                 | X0 = 1152921510034958576 (0x10000001438A68F0);//ML01
            // 0x00BB4010: BL #0x299a140              | 
            // 0x00BB4014: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x00BB4018: CBNZ x19, #0xbb4020        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB401C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001438A68F0, ????);
            label_11:
            // 0x00BB4020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB4024: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB4028: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BB402C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB4030: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4034: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB4038: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BB403C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB4040: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB4044: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BB4048: LDR x8, [x8, #0x160]       | X8 = 1152921504835227648;               
            // 0x00BB404C: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BB4050: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4054: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB4058: LDR x1, [x8]               | X1 = typeof(AIPath);                    
            // 0x00BB405C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB4060: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x00BB4064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4068: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB406C: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BB4070: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB4074: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BB4078: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB407C: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BB4080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4084: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB4088: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x00BB408C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BB4090: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BB4094: CBZ x0, #0xbb40f8          | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x00BB4098: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB409C: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB40A0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB40A4: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB40A8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB40AC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB40B0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB40B4: B.LO #0xbb40d0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BB40B8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB40BC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB40C0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB40C4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB40C8: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x00BB40CC: B.EQ #0xbb40f8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BB40D0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB40D4: ADD x8, sp, #8             | X8 = (1152921510034958576 + 8) = 1152921510034958584 (0x10000001438A68F8);
            // 0x00BB40D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB40DC: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510034946672]
            // 0x00BB40E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BB40E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB40E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BB40EC: ADD x0, sp, #8             | X0 = (1152921510034958576 + 8) = 1152921510034958584 (0x10000001438A68F8);
            // 0x00BB40F0: BL #0x299a140              | 
            // 0x00BB40F4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x00BB40F8: CBNZ x19, #0xbb4100        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BB40FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001438A68F8, ????);
            label_15:
            // 0x00BB4100: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB4104: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB4108: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BB410C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB4110: CBNZ x21, #0xbb4118        | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x00BB4114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BB4118: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
            // 0x00BB411C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4120: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4124: LDP x9, x2, [x8, #0x1c0]   | X9 = mem[282584257677119]; X2 = mem[282584257677127]; //  | 
            // 0x00BB4128: BLR x9                     | X0 = mem[282584257677119]();            
            // 0x00BB412C: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB4130: SUB sp, x29, #0x40         | SP = (1152921510034958656 - 64) = 1152921510034958592 (0x10000001438A6900);
            // 0x00BB4134: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4138: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB413C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB4140: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BB4144: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BB4148: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB414C: MOV x19, x0                | 
            // 0x00BB4150: MOV x0, sp                 | 
            // 0x00BB4154: B #0xbb4160                | 
            // 0x00BB4158: MOV x19, x0                | 
            // 0x00BB415C: ADD x0, sp, #8             | 
            label_17:
            // 0x00BB4160: BL #0x299a140              | 
            // 0x00BB4164: MOV x0, x19                | 
            // 0x00BB4168: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB416C (12271980), len: 584  VirtAddr: 0x00BB416C RVA: 0x00BB416C token: 100663696 methodIndex: 29741 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetFeetPosition_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Stack.StackObject* val_8;
            //  | 
            var val_10;
            // 0x00BB416C: STP x24, x23, [sp, #-0x40]! | stack[1152921510035144336] = ???;  stack[1152921510035144344] = ???;  //  dest_result_addr=1152921510035144336 |  dest_result_addr=1152921510035144344
            // 0x00BB4170: STP x22, x21, [sp, #0x10]  | stack[1152921510035144352] = ???;  stack[1152921510035144360] = ???;  //  dest_result_addr=1152921510035144352 |  dest_result_addr=1152921510035144360
            // 0x00BB4174: STP x20, x19, [sp, #0x20]  | stack[1152921510035144368] = ???;  stack[1152921510035144376] = ???;  //  dest_result_addr=1152921510035144368 |  dest_result_addr=1152921510035144376
            // 0x00BB4178: STP x29, x30, [sp, #0x30]  | stack[1152921510035144384] = ???;  stack[1152921510035144392] = ???;  //  dest_result_addr=1152921510035144384 |  dest_result_addr=1152921510035144392
            // 0x00BB417C: ADD x29, sp, #0x30         | X29 = (1152921510035144336 + 48) = 1152921510035144384 (0x10000001438D3EC0);
            // 0x00BB4180: SUB sp, sp, #0x10          | SP = (1152921510035144336 - 16) = 1152921510035144320 (0x10000001438D3E80);
            // 0x00BB4184: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB4188: LDRB w8, [x20, #0xb21]     | W8 = (bool)static_value_03733B21;       
            // 0x00BB418C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BB4190: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BB4194: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BB4198: TBNZ w8, #0, #0xbb41b4     | if (static_value_03733B21 == true) goto label_0;
            // 0x00BB419C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x00BB41A0: LDR x8, [x8, #0x818]       | X8 = 0x2B8AB64;                         
            // 0x00BB41A4: LDR w0, [x8]               | W0 = 0x197;                             
            // 0x00BB41A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x197, ????);      
            // 0x00BB41AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB41B0: STRB w8, [x20, #0xb21]     | static_value_03733B21 = true;            //  dest_result_addr=57883425
            label_0:
            // 0x00BB41B4: CBNZ x21, #0xbb41bc        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB41B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x197, ????);      
            label_1:
            // 0x00BB41BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB41C0: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BB41C4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB41C8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB41CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB41D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB41D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB41D8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB41DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB41E0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB41E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB41E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB41EC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB41F0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BB41F4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB41F8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB41FC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB4200: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB4204: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BB4208: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB420C: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB4210: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB4214: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB4218: TBZ w9, #0, #0xbb422c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB421C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB4220: CBNZ w9, #0xbb422c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB4224: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB4228: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB422C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4230: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB4234: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB4238: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB423C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB4240: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB4244: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB4248: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB424C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB4250: TBZ w9, #0, #0xbb4264      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB4254: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB4258: CBNZ w9, #0xbb4264         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB425C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB4260: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB4264: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4268: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB426C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BB4270: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB4274: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00BB4278: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB427C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB4280: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB4284: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00BB4288: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB428C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB4290: TBZ w9, #0, #0xbb42a4      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB4294: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB4298: CBNZ w9, #0xbb42a4         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB429C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB42A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB42A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB42A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB42AC: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB42B0: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x00BB42B4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB42B8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BB42BC: CBZ x0, #0xbb4320          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB42C0: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB42C4: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB42C8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB42CC: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB42D0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB42D4: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB42D8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB42DC: B.LO #0xbb42f8             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB42E0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB42E4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB42E8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB42EC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB42F0: MOV x23, x0                | X23 = val_6;//m1                        
            val_10 = val_6;
            // 0x00BB42F4: B.EQ #0xbb4320             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB42F8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB42FC: MOV x8, sp                 | X8 = 1152921510035144320 (0x10000001438D3E80);//ML01
            // 0x00BB4300: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB4304: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510035132400]
            // 0x00BB4308: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB430C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4310: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB4314: MOV x0, sp                 | X0 = 1152921510035144320 (0x10000001438D3E80);//ML01
            // 0x00BB4318: BL #0x299a140              | 
            // 0x00BB431C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_10:
            // 0x00BB4320: CBNZ x21, #0xbb4328        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB4324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001438D3E80, ????);
            label_11:
            // 0x00BB4328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB432C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BB4330: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00BB4334: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB4338: CBNZ x23, #0xbb4340        | if (0x0 != 0) goto label_12;            
            if(val_10 != 0)
            {
                goto label_12;
            }
            // 0x00BB433C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB4340: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x00BB4344: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4348: LDP x9, x1, [x8, #0x1d0]   | X9 = mem[282584257677135]; X1 = mem[282584257677143]; //  | 
            // 0x00BB434C: BLR x9                     | X0 = mem[282584257677135]();            
            // 0x00BB4350: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00BB4354: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00BB4358: MOV x1, sp                 | X1 = 1152921510035144320 (0x10000001438D3E80);//ML01
            // 0x00BB435C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x00BB4360: STP s0, s1, [sp]           | val_8 = ???;  stack[1152921510035144324] = ???;  //  dest_result_addr=1152921510035144320 |  dest_result_addr=1152921510035144324
            val_8 = ???;
            // 0x00BB4364: STR s2, [sp, #8]           | stack[1152921510035144328] = ???;        //  dest_result_addr=1152921510035144328
            // 0x00BB4368: BL #0x27bc028              | X0 = 1152921510035217072 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), );
            // 0x00BB436C: MOV x3, x0                 | X3 = 1152921510035217072 (0x10000001438E5AB0);//ML01
            // 0x00BB4370: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4374: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BB4378: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BB437C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BB4380: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB4384: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  val_8 = ???, mStack:  ???, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  val_8, mStack:  ???, obj:  ???, isBox:  ???);
            // 0x00BB4388: SUB sp, x29, #0x30         | SP = (1152921510035144384 - 48) = 1152921510035144336 (0x10000001438D3E90);
            // 0x00BB438C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4390: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB4394: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB4398: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB439C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB43A0: MOV x19, x0                | 
            // 0x00BB43A4: MOV x0, sp                 | 
            // 0x00BB43A8: BL #0x299a140              | 
            // 0x00BB43AC: MOV x0, x19                | 
            // 0x00BB43B0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB43B4 (12272564), len: 532  VirtAddr: 0x00BB43B4 RVA: 0x00BB43B4 token: 100663697 methodIndex: 29742 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Update_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BB43B4: STP x24, x23, [sp, #-0x40]! | stack[1152921510035317776] = ???;  stack[1152921510035317784] = ???;  //  dest_result_addr=1152921510035317776 |  dest_result_addr=1152921510035317784
            // 0x00BB43B8: STP x22, x21, [sp, #0x10]  | stack[1152921510035317792] = ???;  stack[1152921510035317800] = ???;  //  dest_result_addr=1152921510035317792 |  dest_result_addr=1152921510035317800
            // 0x00BB43BC: STP x20, x19, [sp, #0x20]  | stack[1152921510035317808] = ???;  stack[1152921510035317816] = ???;  //  dest_result_addr=1152921510035317808 |  dest_result_addr=1152921510035317816
            // 0x00BB43C0: STP x29, x30, [sp, #0x30]  | stack[1152921510035317824] = ???;  stack[1152921510035317832] = ???;  //  dest_result_addr=1152921510035317824 |  dest_result_addr=1152921510035317832
            // 0x00BB43C4: ADD x29, sp, #0x30         | X29 = (1152921510035317776 + 48) = 1152921510035317824 (0x10000001438FE440);
            // 0x00BB43C8: SUB sp, sp, #0x10          | SP = (1152921510035317776 - 16) = 1152921510035317760 (0x10000001438FE400);
            // 0x00BB43CC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB43D0: LDRB w8, [x20, #0xb22]     | W8 = (bool)static_value_03733B22;       
            // 0x00BB43D4: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BB43D8: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BB43DC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB43E0: TBNZ w8, #0, #0xbb43fc     | if (static_value_03733B22 == true) goto label_0;
            // 0x00BB43E4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB43E8: LDR x8, [x8, #0x410]       | X8 = 0x2B8ABC4;                         
            // 0x00BB43EC: LDR w0, [x8]               | W0 = 0x1AF;                             
            // 0x00BB43F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1AF, ????);      
            // 0x00BB43F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB43F8: STRB w8, [x20, #0xb22]     | static_value_03733B22 = true;            //  dest_result_addr=57883426
            label_0:
            // 0x00BB43FC: CBNZ x19, #0xbb4404        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB4400: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AF, ????);      
            label_1:
            // 0x00BB4404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4408: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB440C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB4410: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BB4414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4418: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB441C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB4420: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB4424: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB4428: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB442C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4430: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB4434: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BB4438: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BB443C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BB4440: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB4444: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB4448: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BB444C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BB4450: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BB4454: LDR x9, [x9, #0x160]       | X9 = 1152921504835227648;               
            // 0x00BB4458: LDR x24, [x9]              | X24 = typeof(AIPath);                   
            // 0x00BB445C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB4460: TBZ w9, #0, #0xbb4474      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BB4464: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB4468: CBNZ w9, #0xbb4474         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BB446C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BB4470: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BB4474: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4478: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB447C: MOV x1, x24                | X1 = 1152921504835227648 (0x100000000D9CD000);//ML01
            // 0x00BB4480: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB4484: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BB4488: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BB448C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BB4490: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BB4494: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BB4498: TBZ w9, #0, #0xbb44ac      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BB449C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BB44A0: CBNZ w9, #0xbb44ac         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BB44A4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BB44A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BB44AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB44B0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB44B4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB44B8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BB44BC: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BB44C0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BB44C4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BB44C8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BB44CC: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BB44D0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BB44D4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BB44D8: TBZ w9, #0, #0xbb44ec      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BB44DC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BB44E0: CBNZ w9, #0xbb44ec         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BB44E4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BB44E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BB44EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB44F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB44F4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BB44F8: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BB44FC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BB4500: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BB4504: CBZ x0, #0xbb4568          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BB4508: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00BB450C: LDR x9, [x9, #0xf50]       | X9 = 1152921504835227648;               
            // 0x00BB4510: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BB4514: LDR x1, [x9]               | X1 = typeof(AIPath);                    
            // 0x00BB4518: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB451C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4520: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4524: B.LO #0xbb4540             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BB4528: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BB452C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyD
            // 0x00BB4530: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4534: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4538: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BB453C: B.EQ #0xbb4568             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BB4540: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BB4544: ADD x8, sp, #8             | X8 = (1152921510035317760 + 8) = 1152921510035317768 (0x10000001438FE408);
            // 0x00BB4548: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BB454C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510035305840]
            // 0x00BB4550: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BB4554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4558: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BB455C: ADD x0, sp, #8             | X0 = (1152921510035317760 + 8) = 1152921510035317768 (0x10000001438FE408);
            // 0x00BB4560: BL #0x299a140              | 
            // 0x00BB4564: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BB4568: CBNZ x19, #0xbb4570        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB456C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001438FE408, ????);
            label_11:
            // 0x00BB4570: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB4574: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB4578: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BB457C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BB4580: CBNZ x22, #0xbb4588        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BB4584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BB4588: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BB458C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BB4590: LDP x9, x1, [x8, #0x1e0]   | X9 = mem[282584257677151]; X1 = mem[282584257677159]; //  | 
            // 0x00BB4594: BLR x9                     | X0 = mem[282584257677151]();            
            // 0x00BB4598: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BB459C: SUB sp, x29, #0x30         | SP = (1152921510035317824 - 48) = 1152921510035317776 (0x10000001438FE410);
            // 0x00BB45A0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB45A4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB45A8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB45AC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB45B0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BB45B4: MOV x19, x0                | 
            // 0x00BB45B8: ADD x0, sp, #8             | 
            // 0x00BB45BC: BL #0x299a140              | 
            // 0x00BB45C0: MOV x0, x19                | 
            // 0x00BB45C4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB45C8 (12273096), len: 312  VirtAddr: 0x00BB45C8 RVA: 0x00BB45C8 token: 100663698 methodIndex: 29743 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_AIId_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB45C8: STP x20, x19, [sp, #-0x20]! | stack[1152921510035466592] = ???;  stack[1152921510035466600] = ???;  //  dest_result_addr=1152921510035466592 |  dest_result_addr=1152921510035466600
            // 0x00BB45CC: STP x29, x30, [sp, #0x10]  | stack[1152921510035466608] = ???;  stack[1152921510035466616] = ???;  //  dest_result_addr=1152921510035466608 |  dest_result_addr=1152921510035466616
            // 0x00BB45D0: ADD x29, sp, #0x10         | X29 = (1152921510035466592 + 16) = 1152921510035466608 (0x1000000143922970);
            // 0x00BB45D4: SUB sp, sp, #0x20          | SP = (1152921510035466592 - 32) = 1152921510035466560 (0x1000000143922940);
            // 0x00BB45D8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB45DC: LDRB w8, [x20, #0xb23]     | W8 = (bool)static_value_03733B23;       
            // 0x00BB45E0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB45E4: TBNZ w8, #0, #0xbb4600     | if (static_value_03733B23 == true) goto label_0;
            // 0x00BB45E8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB45EC: LDR x8, [x8, #0x9b0]       | X8 = 0x2B8AB20;                         
            // 0x00BB45F0: LDR w0, [x8]               | W0 = 0x186;                             
            // 0x00BB45F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x186, ????);      
            // 0x00BB45F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB45FC: STRB w8, [x20, #0xb23]     | static_value_03733B23 = true;            //  dest_result_addr=57883427
            label_0:
            // 0x00BB4600: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB4604: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB4608: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB460C: CBZ x19, #0xbb4660         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB4610: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB4614: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4618: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB461C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4620: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4624: B.LO #0xbb463c             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4628: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB462C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4630: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4634: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4638: B.EQ #0xbb4664             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB463C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4640: ADD x8, sp, #0x10          | X8 = (1152921510035466560 + 16) = 1152921510035466576 (0x1000000143922950);
            // 0x00BB4644: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB4648: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510035454624]
            // 0x00BB464C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4654: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB4658: ADD x0, sp, #0x10          | X0 = (1152921510035466560 + 16) = 1152921510035466576 (0x1000000143922950);
            // 0x00BB465C: BL #0x299a140              | 
            label_1:
            // 0x00BB4660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143922950, ????);
            label_3:
            // 0x00BB4664: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB4668: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB466C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB4670: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4674: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4678: B.LO #0xbb46bc             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB467C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4680: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4684: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4688: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB468C: B.NE #0xbb46bc             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB4690: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
            // 0x00BB4694: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x00BB4698: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
            // 0x00BB469C: ADD x1, sp, #0xc           | X1 = (1152921510035466560 + 12) = 1152921510035466572 (0x100000014392294C);
            // 0x00BB46A0: STR w8, [sp, #0xc]         | stack[1152921510035466572] = X1 + 24;    //  dest_result_addr=1152921510035466572
            // 0x00BB46A4: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
            // 0x00BB46A8: BL #0x27bc028              | X0 = 1152921510035514640 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), X1 + 24);
            // 0x00BB46AC: SUB sp, x29, #0x10         | SP = (1152921510035466608 - 16) = 1152921510035466592 (0x1000000143922960);
            // 0x00BB46B0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB46B4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB46B8: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB46BC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB46C0: ADD x8, sp, #0x18          | X8 = (1152921510035466560 + 24) = 1152921510035466584 (0x1000000143922958);
            // 0x00BB46C4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB46C8: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510035454624]
            // 0x00BB46CC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB46D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB46D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB46D8: ADD x0, sp, #0x18          | X0 = (1152921510035466560 + 24) = 1152921510035466584 (0x1000000143922958);
            // 0x00BB46DC: BL #0x299a140              | 
            // 0x00BB46E0: MOV x19, x0                | X19 = 1152921510035466584 (0x1000000143922958);//ML01
            // 0x00BB46E4: ADD x0, sp, #0x10          | X0 = (1152921510035466560 + 16) = 1152921510035466576 (0x1000000143922950);
            label_6:
            // 0x00BB46E8: BL #0x299a140              | 
            // 0x00BB46EC: MOV x0, x19                | X0 = 1152921510035466584 (0x1000000143922958);//ML01
            // 0x00BB46F0: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143922958, ????);
            // 0x00BB46F4: MOV x19, x0                | X19 = 1152921510035466584 (0x1000000143922958);//ML01
            // 0x00BB46F8: ADD x0, sp, #0x18          | X0 = (1152921510035466560 + 24) = 1152921510035466584 (0x1000000143922958);
            // 0x00BB46FC: B #0xbb46e8                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB4700 (12273408), len: 412  VirtAddr: 0x00BB4700 RVA: 0x00BB4700 token: 100663699 methodIndex: 29744 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_AIId_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB4700: STP x22, x21, [sp, #-0x30]! | stack[1152921510035594800] = ???;  stack[1152921510035594808] = ???;  //  dest_result_addr=1152921510035594800 |  dest_result_addr=1152921510035594808
            // 0x00BB4704: STP x20, x19, [sp, #0x10]  | stack[1152921510035594816] = ???;  stack[1152921510035594824] = ???;  //  dest_result_addr=1152921510035594816 |  dest_result_addr=1152921510035594824
            // 0x00BB4708: STP x29, x30, [sp, #0x20]  | stack[1152921510035594832] = ???;  stack[1152921510035594840] = ???;  //  dest_result_addr=1152921510035594832 |  dest_result_addr=1152921510035594840
            // 0x00BB470C: ADD x29, sp, #0x20         | X29 = (1152921510035594800 + 32) = 1152921510035594832 (0x1000000143941E50);
            // 0x00BB4710: SUB sp, sp, #0x20          | SP = (1152921510035594800 - 32) = 1152921510035594768 (0x1000000143941E10);
            // 0x00BB4714: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB4718: LDRB w8, [x21, #0xb24]     | W8 = (bool)static_value_03733B24;       
            // 0x00BB471C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB4720: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB4724: TBNZ w8, #0, #0xbb4740     | if (static_value_03733B24 == true) goto label_0;
            // 0x00BB4728: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00BB472C: LDR x8, [x8, #0x638]       | X8 = 0x2B8AB7C;                         
            // 0x00BB4730: LDR w0, [x8]               | W0 = 0x19D;                             
            // 0x00BB4734: BL #0x2782188              | X0 = sub_2782188( ?? 0x19D, ????);      
            // 0x00BB4738: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB473C: STRB w8, [x21, #0xb24]     | static_value_03733B24 = true;            //  dest_result_addr=57883428
            label_0:
            // 0x00BB4740: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB4744: CBZ x21, #0xbb47f8         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB4748: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB474C: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB4750: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB4754: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4758: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB475C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4760: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4764: B.LO #0xbb477c             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4768: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB476C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4770: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4774: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4778: B.EQ #0xbb47a4             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB477C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB4780: ADD x8, sp, #8             | X8 = (1152921510035594768 + 8) = 1152921510035594776 (0x1000000143941E18);
            // 0x00BB4784: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB4788: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510035582848]
            // 0x00BB478C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4790: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4794: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB4798: ADD x0, sp, #8             | X0 = (1152921510035594768 + 8) = 1152921510035594776 (0x1000000143941E18);
            // 0x00BB479C: BL #0x299a140              | 
            // 0x00BB47A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143941E18, ????);
            label_3:
            // 0x00BB47A4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB47A8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB47AC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB47B0: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB47B4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB47B8: B.LO #0xbb47d0             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB47BC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB47C0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB47C4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB47C8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB47CC: B.EQ #0xbb4800             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB47D0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB47D4: ADD x8, sp, #0x10          | X8 = (1152921510035594768 + 16) = 1152921510035594784 (0x1000000143941E20);
            // 0x00BB47D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB47DC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510035582848]
            // 0x00BB47E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB47E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB47E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB47EC: ADD x0, sp, #0x10          | X0 = (1152921510035594768 + 16) = 1152921510035594784 (0x1000000143941E20);
            // 0x00BB47F0: BL #0x299a140              | 
            // 0x00BB47F4: B #0xbb47fc                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB47F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19D, ????);      
            label_6:
            // 0x00BB47FC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB4800: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x00BB4804: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x00BB4808: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x00BB480C: CBNZ x19, #0xbb4814        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB4810: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19D, ????);      
            label_7:
            // 0x00BB4814: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB4818: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB481C: LDR x8, [x20, #0x30]       | X8 = System.UInt32.__il2cppRuntimeField_element_class;
            // 0x00BB4820: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.UInt32.__il2cppRuntimeField_element_class)
            // 0x00BB4824: B.NE #0xbb486c             | if (X2 + 48 != System.UInt32.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB4828: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB482C: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB4830: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB4834: STR w8, [x21, #0x18]       | mem[24] = X2;                            //  dest_result_addr=24
            mem[24] = X2;
            // 0x00BB4838: SUB sp, x29, #0x20         | SP = (1152921510035594832 - 32) = 1152921510035594800 (0x1000000143941E30);
            // 0x00BB483C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4840: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB4844: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB4848: RET                        |  return;                                
            return;
            // 0x00BB484C: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB4850: ADD x0, sp, #8             | X0 = (1152921510035594848 + 8) = 1152921510035594856 (0x1000000143941E68);
            // 0x00BB4854: B #0xbb4860                |  goto label_10;                         
            goto label_10;
            // 0x00BB4858: MOV x19, x0                | X19 = 1152921510035594856 (0x1000000143941E68);//ML01
            val_7;
            // 0x00BB485C: ADD x0, sp, #0x10          | X0 = (1152921510035594848 + 16) = 1152921510035594864 (0x1000000143941E70);
            label_10:
            // 0x00BB4860: BL #0x299a140              | 
            // 0x00BB4864: MOV x0, x19                | X0 = 1152921510035594856 (0x1000000143941E68);//ML01
            // 0x00BB4868: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143941E68, ????);
            label_8:
            // 0x00BB486C: ADD x8, sp, #0x18          | X8 = (1152921510035594848 + 24) = 1152921510035594872 (0x1000000143941E78);
            // 0x00BB4870: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB4874: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143941E68, ????);
            // 0x00BB4878: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510035582848]
            // 0x00BB487C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB4880: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4884: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB4888: ADD x0, sp, #0x18          | X0 = (1152921510035594848 + 24) = 1152921510035594872 (0x1000000143941E78);
            // 0x00BB488C: BL #0x299a140              | 
            // 0x00BB4890: MOV x19, x0                | X19 = 1152921510035594872 (0x1000000143941E78);//ML01
            // 0x00BB4894: ADD x0, sp, #0x18          | X0 = (1152921510035594848 + 24) = 1152921510035594872 (0x1000000143941E78);
            // 0x00BB4898: B #0xbb4860                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB489C (12273820), len: 312  VirtAddr: 0x00BB489C RVA: 0x00BB489C token: 100663700 methodIndex: 29745 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_repathRate_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB489C: STP x20, x19, [sp, #-0x20]! | stack[1152921510035723040] = ???;  stack[1152921510035723048] = ???;  //  dest_result_addr=1152921510035723040 |  dest_result_addr=1152921510035723048
            // 0x00BB48A0: STP x29, x30, [sp, #0x10]  | stack[1152921510035723056] = ???;  stack[1152921510035723064] = ???;  //  dest_result_addr=1152921510035723056 |  dest_result_addr=1152921510035723064
            // 0x00BB48A4: ADD x29, sp, #0x10         | X29 = (1152921510035723040 + 16) = 1152921510035723056 (0x1000000143961330);
            // 0x00BB48A8: SUB sp, sp, #0x20          | SP = (1152921510035723040 - 32) = 1152921510035723008 (0x1000000143961300);
            // 0x00BB48AC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB48B0: LDRB w8, [x20, #0xb25]     | W8 = (bool)static_value_03733B25;       
            // 0x00BB48B4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB48B8: TBNZ w8, #0, #0xbb48d4     | if (static_value_03733B25 == true) goto label_0;
            // 0x00BB48BC: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00BB48C0: LDR x8, [x8, #0x250]       | X8 = 0x2B8AB44;                         
            // 0x00BB48C4: LDR w0, [x8]               | W0 = 0x18F;                             
            // 0x00BB48C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x18F, ????);      
            // 0x00BB48CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB48D0: STRB w8, [x20, #0xb25]     | static_value_03733B25 = true;            //  dest_result_addr=57883429
            label_0:
            // 0x00BB48D4: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB48D8: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB48DC: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB48E0: CBZ x19, #0xbb4934         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB48E4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB48E8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB48EC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB48F0: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB48F4: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB48F8: B.LO #0xbb4910             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB48FC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4900: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4904: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4908: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB490C: B.EQ #0xbb4938             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB4910: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4914: ADD x8, sp, #0x10          | X8 = (1152921510035723008 + 16) = 1152921510035723024 (0x1000000143961310);
            // 0x00BB4918: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB491C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510035711072]
            // 0x00BB4920: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4924: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4928: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB492C: ADD x0, sp, #0x10          | X0 = (1152921510035723008 + 16) = 1152921510035723024 (0x1000000143961310);
            // 0x00BB4930: BL #0x299a140              | 
            label_1:
            // 0x00BB4934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143961310, ????);
            label_3:
            // 0x00BB4938: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB493C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4940: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB4944: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4948: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB494C: B.LO #0xbb4990             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB4950: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4954: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4958: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB495C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4960: B.NE #0xbb4990             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB4964: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB4968: LDR w8, [x19, #0x1c]       | W8 = X1 + 28;                           
            // 0x00BB496C: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB4970: ADD x1, sp, #0xc           | X1 = (1152921510035723008 + 12) = 1152921510035723020 (0x100000014396130C);
            // 0x00BB4974: STR w8, [sp, #0xc]         | stack[1152921510035723020] = X1 + 28;    //  dest_result_addr=1152921510035723020
            // 0x00BB4978: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB497C: BL #0x27bc028              | X0 = 1152921510035771088 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 28);
            // 0x00BB4980: SUB sp, x29, #0x10         | SP = (1152921510035723056 - 16) = 1152921510035723040 (0x1000000143961320);
            // 0x00BB4984: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4988: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB498C: RET                        |  return (System.Object)X1 + 28;         
            return (object)X1 + 28;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB4990: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4994: ADD x8, sp, #0x18          | X8 = (1152921510035723008 + 24) = 1152921510035723032 (0x1000000143961318);
            // 0x00BB4998: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB499C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510035711072]
            // 0x00BB49A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB49A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB49A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB49AC: ADD x0, sp, #0x18          | X0 = (1152921510035723008 + 24) = 1152921510035723032 (0x1000000143961318);
            // 0x00BB49B0: BL #0x299a140              | 
            // 0x00BB49B4: MOV x19, x0                | X19 = 1152921510035723032 (0x1000000143961318);//ML01
            // 0x00BB49B8: ADD x0, sp, #0x10          | X0 = (1152921510035723008 + 16) = 1152921510035723024 (0x1000000143961310);
            label_6:
            // 0x00BB49BC: BL #0x299a140              | 
            // 0x00BB49C0: MOV x0, x19                | X0 = 1152921510035723032 (0x1000000143961318);//ML01
            // 0x00BB49C4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143961318, ????);
            // 0x00BB49C8: MOV x19, x0                | X19 = 1152921510035723032 (0x1000000143961318);//ML01
            // 0x00BB49CC: ADD x0, sp, #0x18          | X0 = (1152921510035723008 + 24) = 1152921510035723032 (0x1000000143961318);
            // 0x00BB49D0: B #0xbb49bc                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB49D4 (12274132), len: 412  VirtAddr: 0x00BB49D4 RVA: 0x00BB49D4 token: 100663701 methodIndex: 29746 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_repathRate_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB49D4: STP x22, x21, [sp, #-0x30]! | stack[1152921510035851248] = ???;  stack[1152921510035851256] = ???;  //  dest_result_addr=1152921510035851248 |  dest_result_addr=1152921510035851256
            // 0x00BB49D8: STP x20, x19, [sp, #0x10]  | stack[1152921510035851264] = ???;  stack[1152921510035851272] = ???;  //  dest_result_addr=1152921510035851264 |  dest_result_addr=1152921510035851272
            // 0x00BB49DC: STP x29, x30, [sp, #0x20]  | stack[1152921510035851280] = ???;  stack[1152921510035851288] = ???;  //  dest_result_addr=1152921510035851280 |  dest_result_addr=1152921510035851288
            // 0x00BB49E0: ADD x29, sp, #0x20         | X29 = (1152921510035851248 + 32) = 1152921510035851280 (0x1000000143980810);
            // 0x00BB49E4: SUB sp, sp, #0x20          | SP = (1152921510035851248 - 32) = 1152921510035851216 (0x10000001439807D0);
            // 0x00BB49E8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB49EC: LDRB w8, [x21, #0xb26]     | W8 = (bool)static_value_03733B26;       
            // 0x00BB49F0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB49F4: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB49F8: TBNZ w8, #0, #0xbb4a14     | if (static_value_03733B26 == true) goto label_0;
            // 0x00BB49FC: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x00BB4A00: LDR x8, [x8, #0xcc8]       | X8 = 0x2B8ABA0;                         
            // 0x00BB4A04: LDR w0, [x8]               | W0 = 0x1A6;                             
            // 0x00BB4A08: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A6, ????);      
            // 0x00BB4A0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB4A10: STRB w8, [x21, #0xb26]     | static_value_03733B26 = true;            //  dest_result_addr=57883430
            label_0:
            // 0x00BB4A14: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB4A18: CBZ x21, #0xbb4acc         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB4A1C: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB4A20: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB4A24: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB4A28: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4A2C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB4A30: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4A34: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4A38: B.LO #0xbb4a50             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4A3C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB4A40: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4A44: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4A48: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4A4C: B.EQ #0xbb4a78             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB4A50: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB4A54: ADD x8, sp, #8             | X8 = (1152921510035851216 + 8) = 1152921510035851224 (0x10000001439807D8);
            // 0x00BB4A58: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB4A5C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510035839296]
            // 0x00BB4A60: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4A64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4A68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB4A6C: ADD x0, sp, #8             | X0 = (1152921510035851216 + 8) = 1152921510035851224 (0x10000001439807D8);
            // 0x00BB4A70: BL #0x299a140              | 
            // 0x00BB4A74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001439807D8, ????);
            label_3:
            // 0x00BB4A78: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB4A7C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4A80: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB4A84: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4A88: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4A8C: B.LO #0xbb4aa4             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB4A90: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB4A94: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4A98: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4A9C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4AA0: B.EQ #0xbb4ad4             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB4AA4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB4AA8: ADD x8, sp, #0x10          | X8 = (1152921510035851216 + 16) = 1152921510035851232 (0x10000001439807E0);
            // 0x00BB4AAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB4AB0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510035839296]
            // 0x00BB4AB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB4AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4ABC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB4AC0: ADD x0, sp, #0x10          | X0 = (1152921510035851216 + 16) = 1152921510035851232 (0x10000001439807E0);
            // 0x00BB4AC4: BL #0x299a140              | 
            // 0x00BB4AC8: B #0xbb4ad0                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB4ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A6, ????);      
            label_6:
            // 0x00BB4AD0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB4AD4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB4AD8: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB4ADC: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB4AE0: CBNZ x19, #0xbb4ae8        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB4AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A6, ????);      
            label_7:
            // 0x00BB4AE8: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB4AEC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB4AF0: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB4AF4: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB4AF8: B.NE #0xbb4b40             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB4AFC: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB4B00: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB4B04: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB4B08: STR w8, [x21, #0x1c]       | mem[28] = X2;                            //  dest_result_addr=28
            mem[28] = X2;
            // 0x00BB4B0C: SUB sp, x29, #0x20         | SP = (1152921510035851280 - 32) = 1152921510035851248 (0x10000001439807F0);
            // 0x00BB4B10: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4B14: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB4B18: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB4B1C: RET                        |  return;                                
            return;
            // 0x00BB4B20: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB4B24: ADD x0, sp, #8             | X0 = (1152921510035851296 + 8) = 1152921510035851304 (0x1000000143980828);
            // 0x00BB4B28: B #0xbb4b34                |  goto label_10;                         
            goto label_10;
            // 0x00BB4B2C: MOV x19, x0                | X19 = 1152921510035851304 (0x1000000143980828);//ML01
            val_7;
            // 0x00BB4B30: ADD x0, sp, #0x10          | X0 = (1152921510035851296 + 16) = 1152921510035851312 (0x1000000143980830);
            label_10:
            // 0x00BB4B34: BL #0x299a140              | 
            // 0x00BB4B38: MOV x0, x19                | X0 = 1152921510035851304 (0x1000000143980828);//ML01
            // 0x00BB4B3C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143980828, ????);
            label_8:
            // 0x00BB4B40: ADD x8, sp, #0x18          | X8 = (1152921510035851296 + 24) = 1152921510035851320 (0x1000000143980838);
            // 0x00BB4B44: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB4B48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143980828, ????);
            // 0x00BB4B4C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510035839296]
            // 0x00BB4B50: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB4B54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4B58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB4B5C: ADD x0, sp, #0x18          | X0 = (1152921510035851296 + 24) = 1152921510035851320 (0x1000000143980838);
            // 0x00BB4B60: BL #0x299a140              | 
            // 0x00BB4B64: MOV x19, x0                | X19 = 1152921510035851320 (0x1000000143980838);//ML01
            // 0x00BB4B68: ADD x0, sp, #0x18          | X0 = (1152921510035851296 + 24) = 1152921510035851320 (0x1000000143980838);
            // 0x00BB4B6C: B #0xbb4b34                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB4B70 (12274544), len: 288  VirtAddr: 0x00BB4B70 RVA: 0x00BB4B70 token: 100663702 methodIndex: 29747 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_target_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB4B70: STP x20, x19, [sp, #-0x20]! | stack[1152921510035975392] = ???;  stack[1152921510035975400] = ???;  //  dest_result_addr=1152921510035975392 |  dest_result_addr=1152921510035975400
            // 0x00BB4B74: STP x29, x30, [sp, #0x10]  | stack[1152921510035975408] = ???;  stack[1152921510035975416] = ???;  //  dest_result_addr=1152921510035975408 |  dest_result_addr=1152921510035975416
            // 0x00BB4B78: ADD x29, sp, #0x10         | X29 = (1152921510035975392 + 16) = 1152921510035975408 (0x100000014399ECF0);
            // 0x00BB4B7C: SUB sp, sp, #0x10          | SP = (1152921510035975392 - 16) = 1152921510035975376 (0x100000014399ECD0);
            // 0x00BB4B80: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB4B84: LDRB w8, [x20, #0xb27]     | W8 = (bool)static_value_03733B27;       
            // 0x00BB4B88: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB4B8C: TBNZ w8, #0, #0xbb4ba8     | if (static_value_03733B27 == true) goto label_0;
            // 0x00BB4B90: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00BB4B94: LDR x8, [x8, #0xcb8]       | X8 = 0x2B8AB50;                         
            // 0x00BB4B98: LDR w0, [x8]               | W0 = 0x192;                             
            // 0x00BB4B9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x192, ????);      
            // 0x00BB4BA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB4BA4: STRB w8, [x20, #0xb27]     | static_value_03733B27 = true;            //  dest_result_addr=57883431
            label_0:
            // 0x00BB4BA8: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB4BAC: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB4BB0: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB4BB4: CBZ x19, #0xbb4c08         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB4BB8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB4BBC: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4BC0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB4BC4: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4BC8: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4BCC: B.LO #0xbb4be4             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4BD0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4BD4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4BD8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4BDC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4BE0: B.EQ #0xbb4c0c             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB4BE4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4BE8: MOV x8, sp                 | X8 = 1152921510035975376 (0x100000014399ECD0);//ML01
            // 0x00BB4BEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB4BF0: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510035963424]
            // 0x00BB4BF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4BFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB4C00: MOV x0, sp                 | X0 = 1152921510035975376 (0x100000014399ECD0);//ML01
            // 0x00BB4C04: BL #0x299a140              | 
            label_1:
            // 0x00BB4C08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014399ECD0, ????);
            label_3:
            // 0x00BB4C0C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB4C10: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4C14: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB4C18: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4C1C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4C20: B.LO #0xbb4c4c             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB4C24: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4C28: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4C2C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4C30: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4C34: B.NE #0xbb4c4c             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB4C38: LDR x0, [x19, #0x20]       | X0 = X1 + 32;                           
            // 0x00BB4C3C: SUB sp, x29, #0x10         | SP = (1152921510035975408 - 16) = 1152921510035975392 (0x100000014399ECE0);
            // 0x00BB4C40: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4C44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB4C48: RET                        |  return (System.Object)X1 + 32;         
            return (object)X1 + 32;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB4C4C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4C50: ADD x8, sp, #8             | X8 = (1152921510035975376 + 8) = 1152921510035975384 (0x100000014399ECD8);
            // 0x00BB4C54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB4C58: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510035963424]
            // 0x00BB4C5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB4C60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4C64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB4C68: ADD x0, sp, #8             | X0 = (1152921510035975376 + 8) = 1152921510035975384 (0x100000014399ECD8);
            // 0x00BB4C6C: BL #0x299a140              | 
            // 0x00BB4C70: MOV x19, x0                | X19 = 1152921510035975384 (0x100000014399ECD8);//ML01
            // 0x00BB4C74: MOV x0, sp                 | X0 = 1152921510035975376 (0x100000014399ECD0);//ML01
            label_6:
            // 0x00BB4C78: BL #0x299a140              | 
            // 0x00BB4C7C: MOV x0, x19                | X0 = 1152921510035975384 (0x100000014399ECD8);//ML01
            // 0x00BB4C80: BL #0x980800               | X0 = sub_980800( ?? 0x100000014399ECD8, ????);
            // 0x00BB4C84: MOV x19, x0                | X19 = 1152921510035975384 (0x100000014399ECD8);//ML01
            // 0x00BB4C88: ADD x0, sp, #8             | X0 = (1152921510035975376 + 8) = 1152921510035975384 (0x100000014399ECD8);
            // 0x00BB4C8C: B #0xbb4c78                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB4C90 (12274832), len: 420  VirtAddr: 0x00BB4C90 RVA: 0x00BB4C90 token: 100663703 methodIndex: 29748 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_target_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BB4C90: STP x22, x21, [sp, #-0x30]! | stack[1152921510036099504] = ???;  stack[1152921510036099512] = ???;  //  dest_result_addr=1152921510036099504 |  dest_result_addr=1152921510036099512
            // 0x00BB4C94: STP x20, x19, [sp, #0x10]  | stack[1152921510036099520] = ???;  stack[1152921510036099528] = ???;  //  dest_result_addr=1152921510036099520 |  dest_result_addr=1152921510036099528
            // 0x00BB4C98: STP x29, x30, [sp, #0x20]  | stack[1152921510036099536] = ???;  stack[1152921510036099544] = ???;  //  dest_result_addr=1152921510036099536 |  dest_result_addr=1152921510036099544
            // 0x00BB4C9C: ADD x29, sp, #0x20         | X29 = (1152921510036099504 + 32) = 1152921510036099536 (0x10000001439BD1D0);
            // 0x00BB4CA0: SUB sp, sp, #0x20          | SP = (1152921510036099504 - 32) = 1152921510036099472 (0x10000001439BD190);
            // 0x00BB4CA4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB4CA8: LDRB w8, [x21, #0xb28]     | W8 = (bool)static_value_03733B28;       
            // 0x00BB4CAC: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00BB4CB0: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB4CB4: TBNZ w8, #0, #0xbb4cd0     | if (static_value_03733B28 == true) goto label_0;
            // 0x00BB4CB8: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00BB4CBC: LDR x8, [x8, #0x538]       | X8 = 0x2B8ABAC;                         
            // 0x00BB4CC0: LDR w0, [x8]               | W0 = 0x1A9;                             
            // 0x00BB4CC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A9, ????);      
            // 0x00BB4CC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB4CCC: STRB w8, [x21, #0xb28]     | static_value_03733B28 = true;            //  dest_result_addr=57883432
            label_0:
            // 0x00BB4CD0: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BB4CD4: CBZ x20, #0xbb4d88         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB4CD8: ADRP x21, #0x364f000       | X21 = 56946688 (0x364F000);             
            // 0x00BB4CDC: LDR x21, [x21, #0xf50]     | X21 = 1152921504835227648;              
            val_7 = 1152921504835227648;
            // 0x00BB4CE0: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BB4CE4: LDR x1, [x21]              | X1 = typeof(AIPath);                    
            // 0x00BB4CE8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB4CEC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4CF0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4CF4: B.LO #0xbb4d0c             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4CF8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB4CFC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4D00: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4D04: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4D08: B.EQ #0xbb4d34             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB4D0C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB4D10: ADD x8, sp, #8             | X8 = (1152921510036099472 + 8) = 1152921510036099480 (0x10000001439BD198);
            // 0x00BB4D14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB4D18: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510036087552]
            // 0x00BB4D1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4D20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4D24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB4D28: ADD x0, sp, #8             | X0 = (1152921510036099472 + 8) = 1152921510036099480 (0x10000001439BD198);
            // 0x00BB4D2C: BL #0x299a140              | 
            // 0x00BB4D30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001439BD198, ????);
            label_3:
            // 0x00BB4D34: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BB4D38: LDR x1, [x21]              | X1 = typeof(AIPath);                    
            // 0x00BB4D3C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB4D40: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4D44: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4D48: B.LO #0xbb4d60             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB4D4C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB4D50: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4D54: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4D58: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4D5C: B.EQ #0xbb4d90             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB4D60: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB4D64: ADD x8, sp, #0x10          | X8 = (1152921510036099472 + 16) = 1152921510036099488 (0x10000001439BD1A0);
            // 0x00BB4D68: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB4D6C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510036087552]
            // 0x00BB4D70: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB4D74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4D78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB4D7C: ADD x0, sp, #0x10          | X0 = (1152921510036099472 + 16) = 1152921510036099488 (0x10000001439BD1A0);
            // 0x00BB4D80: BL #0x299a140              | 
            // 0x00BB4D84: B #0xbb4d8c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB4D88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A9, ????);      
            label_6:
            // 0x00BB4D8C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x00BB4D90: CBZ x19, #0xbb4dec         | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00BB4D94: ADRP x9, #0x35e5000        | X9 = 56512512 (0x35E5000);              
            // 0x00BB4D98: LDR x9, [x9, #0xe58]       | X9 = 1152921504698060800;               
            // 0x00BB4D9C: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB4DA0: LDR x1, [x9]               | X1 = typeof(UnityEngine.Transform);     
            // 0x00BB4DA4: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x00BB4DA8: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4DAC: CMP w10, w9                | STATE = COMPARE(X2 + 260, UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4DB0: B.LO #0xbb4dc8             | if (X2 + 260 < UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00BB4DB4: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x00BB4DB8: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4DBC: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4DC0: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.Transform))
            // 0x00BB4DC4: B.EQ #0xbb4df0             | if ((X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00BB4DC8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB4DCC: ADD x8, sp, #0x18          | X8 = (1152921510036099472 + 24) = 1152921510036099496 (0x10000001439BD1A8);
            // 0x00BB4DD0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BB4DD4: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510036087552]
            // 0x00BB4DD8: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BB4DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4DE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BB4DE4: ADD x0, sp, #0x18          | X0 = (1152921510036099472 + 24) = 1152921510036099496 (0x10000001439BD1A8);
            // 0x00BB4DE8: BL #0x299a140              | 
            label_7:
            // 0x00BB4DEC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BB4DF0: STR x19, [x20, #0x20]      | mem[32] = 0x0;                           //  dest_result_addr=32
            mem[32] = val_8;
            // 0x00BB4DF4: SUB sp, x29, #0x20         | SP = (1152921510036099536 - 32) = 1152921510036099504 (0x10000001439BD1B0);
            // 0x00BB4DF8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4DFC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB4E00: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB4E04: RET                        |  return;                                
            return;
            // 0x00BB4E08: MOV x19, x0                | 
            // 0x00BB4E0C: ADD x0, sp, #8             | 
            // 0x00BB4E10: B #0xbb4e28                | 
            // 0x00BB4E14: MOV x19, x0                | 
            // 0x00BB4E18: ADD x0, sp, #0x10          | 
            // 0x00BB4E1C: B #0xbb4e28                | 
            // 0x00BB4E20: MOV x19, x0                | 
            // 0x00BB4E24: ADD x0, sp, #0x18          | 
            label_11:
            // 0x00BB4E28: BL #0x299a140              | 
            // 0x00BB4E2C: MOV x0, x19                | 
            // 0x00BB4E30: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB4E34 (12275252), len: 312  VirtAddr: 0x00BB4E34 RVA: 0x00BB4E34 token: 100663704 methodIndex: 29749 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_canSearch_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB4E34: STP x20, x19, [sp, #-0x20]! | stack[1152921510036227744] = ???;  stack[1152921510036227752] = ???;  //  dest_result_addr=1152921510036227744 |  dest_result_addr=1152921510036227752
            // 0x00BB4E38: STP x29, x30, [sp, #0x10]  | stack[1152921510036227760] = ???;  stack[1152921510036227768] = ???;  //  dest_result_addr=1152921510036227760 |  dest_result_addr=1152921510036227768
            // 0x00BB4E3C: ADD x29, sp, #0x10         | X29 = (1152921510036227744 + 16) = 1152921510036227760 (0x10000001439DC6B0);
            // 0x00BB4E40: SUB sp, sp, #0x20          | SP = (1152921510036227744 - 32) = 1152921510036227712 (0x10000001439DC680);
            // 0x00BB4E44: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB4E48: LDRB w8, [x20, #0xb29]     | W8 = (bool)static_value_03733B29;       
            // 0x00BB4E4C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB4E50: TBNZ w8, #0, #0xbb4e6c     | if (static_value_03733B29 == true) goto label_0;
            // 0x00BB4E54: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x00BB4E58: LDR x8, [x8, #0x28]        | X8 = 0x2B8AB2C;                         
            // 0x00BB4E5C: LDR w0, [x8]               | W0 = 0x189;                             
            // 0x00BB4E60: BL #0x2782188              | X0 = sub_2782188( ?? 0x189, ????);      
            // 0x00BB4E64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB4E68: STRB w8, [x20, #0xb29]     | static_value_03733B29 = true;            //  dest_result_addr=57883433
            label_0:
            // 0x00BB4E6C: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB4E70: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB4E74: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB4E78: CBZ x19, #0xbb4ecc         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB4E7C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB4E80: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4E84: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB4E88: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4E8C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4E90: B.LO #0xbb4ea8             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4E94: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4E98: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4E9C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4EA0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4EA4: B.EQ #0xbb4ed0             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB4EA8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4EAC: ADD x8, sp, #0x10          | X8 = (1152921510036227712 + 16) = 1152921510036227728 (0x10000001439DC690);
            // 0x00BB4EB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB4EB4: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510036215776]
            // 0x00BB4EB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4EC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB4EC4: ADD x0, sp, #0x10          | X0 = (1152921510036227712 + 16) = 1152921510036227728 (0x10000001439DC690);
            // 0x00BB4EC8: BL #0x299a140              | 
            label_1:
            // 0x00BB4ECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001439DC690, ????);
            label_3:
            // 0x00BB4ED0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB4ED4: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4ED8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB4EDC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4EE0: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4EE4: B.LO #0xbb4f28             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB4EE8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB4EEC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4EF0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4EF4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4EF8: B.NE #0xbb4f28             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB4EFC: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x00BB4F00: LDRB w8, [x19, #0x28]      | W8 = X1 + 40;                           
            // 0x00BB4F04: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x00BB4F08: ADD x1, sp, #0xf           | X1 = (1152921510036227712 + 15) = 1152921510036227727 (0x10000001439DC68F);
            // 0x00BB4F0C: STRB w8, [sp, #0xf]        | stack[1152921510036227727] = X1 + 40;    //  dest_result_addr=1152921510036227727
            // 0x00BB4F10: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x00BB4F14: BL #0x27bc028              | X0 = 1152921510036275792 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 40);
            // 0x00BB4F18: SUB sp, x29, #0x10         | SP = (1152921510036227760 - 16) = 1152921510036227744 (0x10000001439DC6A0);
            // 0x00BB4F1C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB4F20: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB4F24: RET                        |  return (System.Object)X1 + 40;         
            return (object)X1 + 40;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB4F28: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB4F2C: ADD x8, sp, #0x18          | X8 = (1152921510036227712 + 24) = 1152921510036227736 (0x10000001439DC698);
            // 0x00BB4F30: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB4F34: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510036215776]
            // 0x00BB4F38: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB4F3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB4F40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB4F44: ADD x0, sp, #0x18          | X0 = (1152921510036227712 + 24) = 1152921510036227736 (0x10000001439DC698);
            // 0x00BB4F48: BL #0x299a140              | 
            // 0x00BB4F4C: MOV x19, x0                | X19 = 1152921510036227736 (0x10000001439DC698);//ML01
            // 0x00BB4F50: ADD x0, sp, #0x10          | X0 = (1152921510036227712 + 16) = 1152921510036227728 (0x10000001439DC690);
            label_6:
            // 0x00BB4F54: BL #0x299a140              | 
            // 0x00BB4F58: MOV x0, x19                | X0 = 1152921510036227736 (0x10000001439DC698);//ML01
            // 0x00BB4F5C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001439DC698, ????);
            // 0x00BB4F60: MOV x19, x0                | X19 = 1152921510036227736 (0x10000001439DC698);//ML01
            // 0x00BB4F64: ADD x0, sp, #0x18          | X0 = (1152921510036227712 + 24) = 1152921510036227736 (0x10000001439DC698);
            // 0x00BB4F68: B #0xbb4f54                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB4F6C (12275564), len: 412  VirtAddr: 0x00BB4F6C RVA: 0x00BB4F6C token: 100663705 methodIndex: 29750 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_canSearch_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB4F6C: STP x22, x21, [sp, #-0x30]! | stack[1152921510036355952] = ???;  stack[1152921510036355960] = ???;  //  dest_result_addr=1152921510036355952 |  dest_result_addr=1152921510036355960
            // 0x00BB4F70: STP x20, x19, [sp, #0x10]  | stack[1152921510036355968] = ???;  stack[1152921510036355976] = ???;  //  dest_result_addr=1152921510036355968 |  dest_result_addr=1152921510036355976
            // 0x00BB4F74: STP x29, x30, [sp, #0x20]  | stack[1152921510036355984] = ???;  stack[1152921510036355992] = ???;  //  dest_result_addr=1152921510036355984 |  dest_result_addr=1152921510036355992
            // 0x00BB4F78: ADD x29, sp, #0x20         | X29 = (1152921510036355952 + 32) = 1152921510036355984 (0x10000001439FBB90);
            // 0x00BB4F7C: SUB sp, sp, #0x20          | SP = (1152921510036355952 - 32) = 1152921510036355920 (0x10000001439FBB50);
            // 0x00BB4F80: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB4F84: LDRB w8, [x21, #0xb2a]     | W8 = (bool)static_value_03733B2A;       
            // 0x00BB4F88: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB4F8C: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB4F90: TBNZ w8, #0, #0xbb4fac     | if (static_value_03733B2A == true) goto label_0;
            // 0x00BB4F94: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00BB4F98: LDR x8, [x8, #0xaf0]       | X8 = 0x2B8AB88;                         
            // 0x00BB4F9C: LDR w0, [x8]               | W0 = 0x1A0;                             
            // 0x00BB4FA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A0, ????);      
            // 0x00BB4FA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB4FA8: STRB w8, [x21, #0xb2a]     | static_value_03733B2A = true;            //  dest_result_addr=57883434
            label_0:
            // 0x00BB4FAC: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB4FB0: CBZ x21, #0xbb5064         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB4FB4: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB4FB8: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB4FBC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB4FC0: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB4FC4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB4FC8: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB4FCC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB4FD0: B.LO #0xbb4fe8             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB4FD4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB4FD8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB4FDC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB4FE0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB4FE4: B.EQ #0xbb5010             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB4FE8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB4FEC: ADD x8, sp, #8             | X8 = (1152921510036355920 + 8) = 1152921510036355928 (0x10000001439FBB58);
            // 0x00BB4FF0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB4FF4: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510036344000]
            // 0x00BB4FF8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB4FFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5000: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5004: ADD x0, sp, #8             | X0 = (1152921510036355920 + 8) = 1152921510036355928 (0x10000001439FBB58);
            // 0x00BB5008: BL #0x299a140              | 
            // 0x00BB500C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001439FBB58, ????);
            label_3:
            // 0x00BB5010: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5014: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5018: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB501C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5020: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5024: B.LO #0xbb503c             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB5028: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB502C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5030: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5034: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5038: B.EQ #0xbb506c             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB503C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5040: ADD x8, sp, #0x10          | X8 = (1152921510036355920 + 16) = 1152921510036355936 (0x10000001439FBB60);
            // 0x00BB5044: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB5048: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510036344000]
            // 0x00BB504C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5058: ADD x0, sp, #0x10          | X0 = (1152921510036355920 + 16) = 1152921510036355936 (0x10000001439FBB60);
            // 0x00BB505C: BL #0x299a140              | 
            // 0x00BB5060: B #0xbb5068                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB5064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A0, ????);      
            label_6:
            // 0x00BB5068: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB506C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BB5070: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00BB5074: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x00BB5078: CBNZ x19, #0xbb5080        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB507C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A0, ????);      
            label_7:
            // 0x00BB5080: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB5084: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB5088: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00BB508C: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00BB5090: B.NE #0xbb50d8             | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB5094: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB5098: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB509C: LDRB w8, [x0]              | W8 = X2;                                
            // 0x00BB50A0: STRB w8, [x21, #0x28]      | mem[40] = X2;                            //  dest_result_addr=40
            mem[40] = X2;
            // 0x00BB50A4: SUB sp, x29, #0x20         | SP = (1152921510036355984 - 32) = 1152921510036355952 (0x10000001439FBB70);
            // 0x00BB50A8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB50AC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB50B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB50B4: RET                        |  return;                                
            return;
            // 0x00BB50B8: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB50BC: ADD x0, sp, #8             | X0 = (1152921510036356000 + 8) = 1152921510036356008 (0x10000001439FBBA8);
            // 0x00BB50C0: B #0xbb50cc                |  goto label_10;                         
            goto label_10;
            // 0x00BB50C4: MOV x19, x0                | X19 = 1152921510036356008 (0x10000001439FBBA8);//ML01
            val_7;
            // 0x00BB50C8: ADD x0, sp, #0x10          | X0 = (1152921510036356000 + 16) = 1152921510036356016 (0x10000001439FBBB0);
            label_10:
            // 0x00BB50CC: BL #0x299a140              | 
            // 0x00BB50D0: MOV x0, x19                | X0 = 1152921510036356008 (0x10000001439FBBA8);//ML01
            // 0x00BB50D4: BL #0x980800               | X0 = sub_980800( ?? 0x10000001439FBBA8, ????);
            label_8:
            // 0x00BB50D8: ADD x8, sp, #0x18          | X8 = (1152921510036356000 + 24) = 1152921510036356024 (0x10000001439FBBB8);
            // 0x00BB50DC: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB50E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001439FBBA8, ????);
            // 0x00BB50E4: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510036344000]
            // 0x00BB50E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB50EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB50F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB50F4: ADD x0, sp, #0x18          | X0 = (1152921510036356000 + 24) = 1152921510036356024 (0x10000001439FBBB8);
            // 0x00BB50F8: BL #0x299a140              | 
            // 0x00BB50FC: MOV x19, x0                | X19 = 1152921510036356024 (0x10000001439FBBB8);//ML01
            // 0x00BB5100: ADD x0, sp, #0x18          | X0 = (1152921510036356000 + 24) = 1152921510036356024 (0x10000001439FBBB8);
            // 0x00BB5104: B #0xbb50cc                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5108 (12275976), len: 312  VirtAddr: 0x00BB5108 RVA: 0x00BB5108 token: 100663706 methodIndex: 29751 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_canMoveNextWaypoint_4(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB5108: STP x20, x19, [sp, #-0x20]! | stack[1152921510036484192] = ???;  stack[1152921510036484200] = ???;  //  dest_result_addr=1152921510036484192 |  dest_result_addr=1152921510036484200
            // 0x00BB510C: STP x29, x30, [sp, #0x10]  | stack[1152921510036484208] = ???;  stack[1152921510036484216] = ???;  //  dest_result_addr=1152921510036484208 |  dest_result_addr=1152921510036484216
            // 0x00BB5110: ADD x29, sp, #0x10         | X29 = (1152921510036484192 + 16) = 1152921510036484208 (0x1000000143A1B070);
            // 0x00BB5114: SUB sp, sp, #0x20          | SP = (1152921510036484192 - 32) = 1152921510036484160 (0x1000000143A1B040);
            // 0x00BB5118: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB511C: LDRB w8, [x20, #0xb2b]     | W8 = (bool)static_value_03733B2B;       
            // 0x00BB5120: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB5124: TBNZ w8, #0, #0xbb5140     | if (static_value_03733B2B == true) goto label_0;
            // 0x00BB5128: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00BB512C: LDR x8, [x8, #0xb90]       | X8 = 0x2B8AB28;                         
            // 0x00BB5130: LDR w0, [x8]               | W0 = 0x188;                             
            // 0x00BB5134: BL #0x2782188              | X0 = sub_2782188( ?? 0x188, ????);      
            // 0x00BB5138: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB513C: STRB w8, [x20, #0xb2b]     | static_value_03733B2B = true;            //  dest_result_addr=57883435
            label_0:
            // 0x00BB5140: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5144: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB5148: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB514C: CBZ x19, #0xbb51a0         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB5150: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5154: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5158: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB515C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5160: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5164: B.LO #0xbb517c             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5168: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB516C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5170: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5174: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5178: B.EQ #0xbb51a4             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB517C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5180: ADD x8, sp, #0x10          | X8 = (1152921510036484160 + 16) = 1152921510036484176 (0x1000000143A1B050);
            // 0x00BB5184: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5188: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510036472224]
            // 0x00BB518C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5194: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5198: ADD x0, sp, #0x10          | X0 = (1152921510036484160 + 16) = 1152921510036484176 (0x1000000143A1B050);
            // 0x00BB519C: BL #0x299a140              | 
            label_1:
            // 0x00BB51A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143A1B050, ????);
            label_3:
            // 0x00BB51A4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB51A8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB51AC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB51B0: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB51B4: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB51B8: B.LO #0xbb51fc             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB51BC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB51C0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB51C4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB51C8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB51CC: B.NE #0xbb51fc             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB51D0: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x00BB51D4: LDRB w8, [x19, #0x2a]      | W8 = X1 + 42;                           
            // 0x00BB51D8: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x00BB51DC: ADD x1, sp, #0xf           | X1 = (1152921510036484160 + 15) = 1152921510036484175 (0x1000000143A1B04F);
            // 0x00BB51E0: STRB w8, [sp, #0xf]        | stack[1152921510036484175] = X1 + 42;    //  dest_result_addr=1152921510036484175
            // 0x00BB51E4: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x00BB51E8: BL #0x27bc028              | X0 = 1152921510036532240 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 42);
            // 0x00BB51EC: SUB sp, x29, #0x10         | SP = (1152921510036484208 - 16) = 1152921510036484192 (0x1000000143A1B060);
            // 0x00BB51F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB51F4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB51F8: RET                        |  return (System.Object)X1 + 42;         
            return (object)X1 + 42;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB51FC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5200: ADD x8, sp, #0x18          | X8 = (1152921510036484160 + 24) = 1152921510036484184 (0x1000000143A1B058);
            // 0x00BB5204: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5208: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510036472224]
            // 0x00BB520C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5214: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5218: ADD x0, sp, #0x18          | X0 = (1152921510036484160 + 24) = 1152921510036484184 (0x1000000143A1B058);
            // 0x00BB521C: BL #0x299a140              | 
            // 0x00BB5220: MOV x19, x0                | X19 = 1152921510036484184 (0x1000000143A1B058);//ML01
            // 0x00BB5224: ADD x0, sp, #0x10          | X0 = (1152921510036484160 + 16) = 1152921510036484176 (0x1000000143A1B050);
            label_6:
            // 0x00BB5228: BL #0x299a140              | 
            // 0x00BB522C: MOV x0, x19                | X0 = 1152921510036484184 (0x1000000143A1B058);//ML01
            // 0x00BB5230: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143A1B058, ????);
            // 0x00BB5234: MOV x19, x0                | X19 = 1152921510036484184 (0x1000000143A1B058);//ML01
            // 0x00BB5238: ADD x0, sp, #0x18          | X0 = (1152921510036484160 + 24) = 1152921510036484184 (0x1000000143A1B058);
            // 0x00BB523C: B #0xbb5228                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5240 (12276288), len: 412  VirtAddr: 0x00BB5240 RVA: 0x00BB5240 token: 100663707 methodIndex: 29752 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_canMoveNextWaypoint_4(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB5240: STP x22, x21, [sp, #-0x30]! | stack[1152921510036612400] = ???;  stack[1152921510036612408] = ???;  //  dest_result_addr=1152921510036612400 |  dest_result_addr=1152921510036612408
            // 0x00BB5244: STP x20, x19, [sp, #0x10]  | stack[1152921510036612416] = ???;  stack[1152921510036612424] = ???;  //  dest_result_addr=1152921510036612416 |  dest_result_addr=1152921510036612424
            // 0x00BB5248: STP x29, x30, [sp, #0x20]  | stack[1152921510036612432] = ???;  stack[1152921510036612440] = ???;  //  dest_result_addr=1152921510036612432 |  dest_result_addr=1152921510036612440
            // 0x00BB524C: ADD x29, sp, #0x20         | X29 = (1152921510036612400 + 32) = 1152921510036612432 (0x1000000143A3A550);
            // 0x00BB5250: SUB sp, sp, #0x20          | SP = (1152921510036612400 - 32) = 1152921510036612368 (0x1000000143A3A510);
            // 0x00BB5254: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB5258: LDRB w8, [x21, #0xb2c]     | W8 = (bool)static_value_03733B2C;       
            // 0x00BB525C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB5260: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB5264: TBNZ w8, #0, #0xbb5280     | if (static_value_03733B2C == true) goto label_0;
            // 0x00BB5268: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x00BB526C: LDR x8, [x8, #0x50]        | X8 = 0x2B8AB84;                         
            // 0x00BB5270: LDR w0, [x8]               | W0 = 0x19F;                             
            // 0x00BB5274: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F, ????);      
            // 0x00BB5278: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB527C: STRB w8, [x21, #0xb2c]     | static_value_03733B2C = true;            //  dest_result_addr=57883436
            label_0:
            // 0x00BB5280: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB5284: CBZ x21, #0xbb5338         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB5288: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB528C: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5290: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5294: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5298: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB529C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB52A0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB52A4: B.LO #0xbb52bc             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB52A8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB52AC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB52B0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB52B4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB52B8: B.EQ #0xbb52e4             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB52BC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB52C0: ADD x8, sp, #8             | X8 = (1152921510036612368 + 8) = 1152921510036612376 (0x1000000143A3A518);
            // 0x00BB52C4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB52C8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510036600448]
            // 0x00BB52CC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB52D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB52D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB52D8: ADD x0, sp, #8             | X0 = (1152921510036612368 + 8) = 1152921510036612376 (0x1000000143A3A518);
            // 0x00BB52DC: BL #0x299a140              | 
            // 0x00BB52E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143A3A518, ????);
            label_3:
            // 0x00BB52E4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB52E8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB52EC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB52F0: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB52F4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB52F8: B.LO #0xbb5310             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB52FC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5300: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5304: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5308: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB530C: B.EQ #0xbb5340             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB5310: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5314: ADD x8, sp, #0x10          | X8 = (1152921510036612368 + 16) = 1152921510036612384 (0x1000000143A3A520);
            // 0x00BB5318: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB531C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510036600448]
            // 0x00BB5320: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5328: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB532C: ADD x0, sp, #0x10          | X0 = (1152921510036612368 + 16) = 1152921510036612384 (0x1000000143A3A520);
            // 0x00BB5330: BL #0x299a140              | 
            // 0x00BB5334: B #0xbb533c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB5338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19F, ????);      
            label_6:
            // 0x00BB533C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB5340: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BB5344: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00BB5348: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x00BB534C: CBNZ x19, #0xbb5354        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB5350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19F, ????);      
            label_7:
            // 0x00BB5354: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB5358: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB535C: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00BB5360: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00BB5364: B.NE #0xbb53ac             | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB5368: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB536C: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB5370: LDRB w8, [x0]              | W8 = X2;                                
            // 0x00BB5374: STRB w8, [x21, #0x2a]      | mem[42] = X2;                            //  dest_result_addr=42
            mem[42] = X2;
            // 0x00BB5378: SUB sp, x29, #0x20         | SP = (1152921510036612432 - 32) = 1152921510036612400 (0x1000000143A3A530);
            // 0x00BB537C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5380: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB5384: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB5388: RET                        |  return;                                
            return;
            // 0x00BB538C: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB5390: ADD x0, sp, #8             | X0 = (1152921510036612448 + 8) = 1152921510036612456 (0x1000000143A3A568);
            // 0x00BB5394: B #0xbb53a0                |  goto label_10;                         
            goto label_10;
            // 0x00BB5398: MOV x19, x0                | X19 = 1152921510036612456 (0x1000000143A3A568);//ML01
            val_7;
            // 0x00BB539C: ADD x0, sp, #0x10          | X0 = (1152921510036612448 + 16) = 1152921510036612464 (0x1000000143A3A570);
            label_10:
            // 0x00BB53A0: BL #0x299a140              | 
            // 0x00BB53A4: MOV x0, x19                | X0 = 1152921510036612456 (0x1000000143A3A568);//ML01
            // 0x00BB53A8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143A3A568, ????);
            label_8:
            // 0x00BB53AC: ADD x8, sp, #0x18          | X8 = (1152921510036612448 + 24) = 1152921510036612472 (0x1000000143A3A578);
            // 0x00BB53B0: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB53B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143A3A568, ????);
            // 0x00BB53B8: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510036600448]
            // 0x00BB53BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB53C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB53C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB53C8: ADD x0, sp, #0x18          | X0 = (1152921510036612448 + 24) = 1152921510036612472 (0x1000000143A3A578);
            // 0x00BB53CC: BL #0x299a140              | 
            // 0x00BB53D0: MOV x19, x0                | X19 = 1152921510036612472 (0x1000000143A3A578);//ML01
            // 0x00BB53D4: ADD x0, sp, #0x18          | X0 = (1152921510036612448 + 24) = 1152921510036612472 (0x1000000143A3A578);
            // 0x00BB53D8: B #0xbb53a0                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB53DC (12276700), len: 312  VirtAddr: 0x00BB53DC RVA: 0x00BB53DC token: 100663708 methodIndex: 29753 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_speed_5(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB53DC: STP x20, x19, [sp, #-0x20]! | stack[1152921510036740640] = ???;  stack[1152921510036740648] = ???;  //  dest_result_addr=1152921510036740640 |  dest_result_addr=1152921510036740648
            // 0x00BB53E0: STP x29, x30, [sp, #0x10]  | stack[1152921510036740656] = ???;  stack[1152921510036740664] = ???;  //  dest_result_addr=1152921510036740656 |  dest_result_addr=1152921510036740664
            // 0x00BB53E4: ADD x29, sp, #0x10         | X29 = (1152921510036740640 + 16) = 1152921510036740656 (0x1000000143A59A30);
            // 0x00BB53E8: SUB sp, sp, #0x20          | SP = (1152921510036740640 - 32) = 1152921510036740608 (0x1000000143A59A00);
            // 0x00BB53EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB53F0: LDRB w8, [x20, #0xb2d]     | W8 = (bool)static_value_03733B2D;       
            // 0x00BB53F4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB53F8: TBNZ w8, #0, #0xbb5414     | if (static_value_03733B2D == true) goto label_0;
            // 0x00BB53FC: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BB5400: LDR x8, [x8, #0x620]       | X8 = 0x2B8AB4C;                         
            // 0x00BB5404: LDR w0, [x8]               | W0 = 0x191;                             
            // 0x00BB5408: BL #0x2782188              | X0 = sub_2782188( ?? 0x191, ????);      
            // 0x00BB540C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5410: STRB w8, [x20, #0xb2d]     | static_value_03733B2D = true;            //  dest_result_addr=57883437
            label_0:
            // 0x00BB5414: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5418: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB541C: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5420: CBZ x19, #0xbb5474         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB5424: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5428: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB542C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5430: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5434: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5438: B.LO #0xbb5450             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB543C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5440: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5444: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5448: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB544C: B.EQ #0xbb5478             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5450: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5454: ADD x8, sp, #0x10          | X8 = (1152921510036740608 + 16) = 1152921510036740624 (0x1000000143A59A10);
            // 0x00BB5458: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB545C: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510036728672]
            // 0x00BB5460: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5468: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB546C: ADD x0, sp, #0x10          | X0 = (1152921510036740608 + 16) = 1152921510036740624 (0x1000000143A59A10);
            // 0x00BB5470: BL #0x299a140              | 
            label_1:
            // 0x00BB5474: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143A59A10, ????);
            label_3:
            // 0x00BB5478: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB547C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5480: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5484: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5488: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB548C: B.LO #0xbb54d0             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB5490: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5494: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5498: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB549C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB54A0: B.NE #0xbb54d0             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB54A4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB54A8: LDR w8, [x19, #0x2c]       | W8 = X1 + 44;                           
            // 0x00BB54AC: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB54B0: ADD x1, sp, #0xc           | X1 = (1152921510036740608 + 12) = 1152921510036740620 (0x1000000143A59A0C);
            // 0x00BB54B4: STR w8, [sp, #0xc]         | stack[1152921510036740620] = X1 + 44;    //  dest_result_addr=1152921510036740620
            // 0x00BB54B8: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB54BC: BL #0x27bc028              | X0 = 1152921510036788688 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 44);
            // 0x00BB54C0: SUB sp, x29, #0x10         | SP = (1152921510036740656 - 16) = 1152921510036740640 (0x1000000143A59A20);
            // 0x00BB54C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB54C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB54CC: RET                        |  return (System.Object)X1 + 44;         
            return (object)X1 + 44;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB54D0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB54D4: ADD x8, sp, #0x18          | X8 = (1152921510036740608 + 24) = 1152921510036740632 (0x1000000143A59A18);
            // 0x00BB54D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB54DC: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510036728672]
            // 0x00BB54E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB54E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB54E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB54EC: ADD x0, sp, #0x18          | X0 = (1152921510036740608 + 24) = 1152921510036740632 (0x1000000143A59A18);
            // 0x00BB54F0: BL #0x299a140              | 
            // 0x00BB54F4: MOV x19, x0                | X19 = 1152921510036740632 (0x1000000143A59A18);//ML01
            // 0x00BB54F8: ADD x0, sp, #0x10          | X0 = (1152921510036740608 + 16) = 1152921510036740624 (0x1000000143A59A10);
            label_6:
            // 0x00BB54FC: BL #0x299a140              | 
            // 0x00BB5500: MOV x0, x19                | X0 = 1152921510036740632 (0x1000000143A59A18);//ML01
            // 0x00BB5504: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143A59A18, ????);
            // 0x00BB5508: MOV x19, x0                | X19 = 1152921510036740632 (0x1000000143A59A18);//ML01
            // 0x00BB550C: ADD x0, sp, #0x18          | X0 = (1152921510036740608 + 24) = 1152921510036740632 (0x1000000143A59A18);
            // 0x00BB5510: B #0xbb54fc                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5514 (12277012), len: 412  VirtAddr: 0x00BB5514 RVA: 0x00BB5514 token: 100663709 methodIndex: 29754 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_speed_5(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB5514: STP x22, x21, [sp, #-0x30]! | stack[1152921510036868848] = ???;  stack[1152921510036868856] = ???;  //  dest_result_addr=1152921510036868848 |  dest_result_addr=1152921510036868856
            // 0x00BB5518: STP x20, x19, [sp, #0x10]  | stack[1152921510036868864] = ???;  stack[1152921510036868872] = ???;  //  dest_result_addr=1152921510036868864 |  dest_result_addr=1152921510036868872
            // 0x00BB551C: STP x29, x30, [sp, #0x20]  | stack[1152921510036868880] = ???;  stack[1152921510036868888] = ???;  //  dest_result_addr=1152921510036868880 |  dest_result_addr=1152921510036868888
            // 0x00BB5520: ADD x29, sp, #0x20         | X29 = (1152921510036868848 + 32) = 1152921510036868880 (0x1000000143A78F10);
            // 0x00BB5524: SUB sp, sp, #0x20          | SP = (1152921510036868848 - 32) = 1152921510036868816 (0x1000000143A78ED0);
            // 0x00BB5528: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB552C: LDRB w8, [x21, #0xb2e]     | W8 = (bool)static_value_03733B2E;       
            // 0x00BB5530: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB5534: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB5538: TBNZ w8, #0, #0xbb5554     | if (static_value_03733B2E == true) goto label_0;
            // 0x00BB553C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00BB5540: LDR x8, [x8, #0x38]        | X8 = 0x2B8ABA8;                         
            // 0x00BB5544: LDR w0, [x8]               | W0 = 0x1A8;                             
            // 0x00BB5548: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A8, ????);      
            // 0x00BB554C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5550: STRB w8, [x21, #0xb2e]     | static_value_03733B2E = true;            //  dest_result_addr=57883438
            label_0:
            // 0x00BB5554: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB5558: CBZ x21, #0xbb560c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB555C: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5560: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5564: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5568: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB556C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5570: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5574: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5578: B.LO #0xbb5590             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB557C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5580: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5584: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5588: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB558C: B.EQ #0xbb55b8             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5590: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5594: ADD x8, sp, #8             | X8 = (1152921510036868816 + 8) = 1152921510036868824 (0x1000000143A78ED8);
            // 0x00BB5598: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB559C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510036856896]
            // 0x00BB55A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB55A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB55A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB55AC: ADD x0, sp, #8             | X0 = (1152921510036868816 + 8) = 1152921510036868824 (0x1000000143A78ED8);
            // 0x00BB55B0: BL #0x299a140              | 
            // 0x00BB55B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143A78ED8, ????);
            label_3:
            // 0x00BB55B8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB55BC: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB55C0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB55C4: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB55C8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB55CC: B.LO #0xbb55e4             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB55D0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB55D4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB55D8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB55DC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB55E0: B.EQ #0xbb5614             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB55E4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB55E8: ADD x8, sp, #0x10          | X8 = (1152921510036868816 + 16) = 1152921510036868832 (0x1000000143A78EE0);
            // 0x00BB55EC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB55F0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510036856896]
            // 0x00BB55F4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB55F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB55FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5600: ADD x0, sp, #0x10          | X0 = (1152921510036868816 + 16) = 1152921510036868832 (0x1000000143A78EE0);
            // 0x00BB5604: BL #0x299a140              | 
            // 0x00BB5608: B #0xbb5610                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB560C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A8, ????);      
            label_6:
            // 0x00BB5610: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB5614: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB5618: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB561C: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB5620: CBNZ x19, #0xbb5628        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB5624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A8, ????);      
            label_7:
            // 0x00BB5628: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB562C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB5630: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB5634: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB5638: B.NE #0xbb5680             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB563C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB5640: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB5644: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB5648: STR w8, [x21, #0x2c]       | mem[44] = X2;                            //  dest_result_addr=44
            mem[44] = X2;
            // 0x00BB564C: SUB sp, x29, #0x20         | SP = (1152921510036868880 - 32) = 1152921510036868848 (0x1000000143A78EF0);
            // 0x00BB5650: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5654: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB5658: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB565C: RET                        |  return;                                
            return;
            // 0x00BB5660: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB5664: ADD x0, sp, #8             | X0 = (1152921510036868896 + 8) = 1152921510036868904 (0x1000000143A78F28);
            // 0x00BB5668: B #0xbb5674                |  goto label_10;                         
            goto label_10;
            // 0x00BB566C: MOV x19, x0                | X19 = 1152921510036868904 (0x1000000143A78F28);//ML01
            val_7;
            // 0x00BB5670: ADD x0, sp, #0x10          | X0 = (1152921510036868896 + 16) = 1152921510036868912 (0x1000000143A78F30);
            label_10:
            // 0x00BB5674: BL #0x299a140              | 
            // 0x00BB5678: MOV x0, x19                | X0 = 1152921510036868904 (0x1000000143A78F28);//ML01
            // 0x00BB567C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143A78F28, ????);
            label_8:
            // 0x00BB5680: ADD x8, sp, #0x18          | X8 = (1152921510036868896 + 24) = 1152921510036868920 (0x1000000143A78F38);
            // 0x00BB5684: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB5688: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143A78F28, ????);
            // 0x00BB568C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510036856896]
            // 0x00BB5690: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB5694: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5698: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB569C: ADD x0, sp, #0x18          | X0 = (1152921510036868896 + 24) = 1152921510036868920 (0x1000000143A78F38);
            // 0x00BB56A0: BL #0x299a140              | 
            // 0x00BB56A4: MOV x19, x0                | X19 = 1152921510036868920 (0x1000000143A78F38);//ML01
            // 0x00BB56A8: ADD x0, sp, #0x18          | X0 = (1152921510036868896 + 24) = 1152921510036868920 (0x1000000143A78F38);
            // 0x00BB56AC: B #0xbb5674                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB56B0 (12277424), len: 312  VirtAddr: 0x00BB56B0 RVA: 0x00BB56B0 token: 100663710 methodIndex: 29755 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_turningSpeed_6(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB56B0: STP x20, x19, [sp, #-0x20]! | stack[1152921510036997088] = ???;  stack[1152921510036997096] = ???;  //  dest_result_addr=1152921510036997088 |  dest_result_addr=1152921510036997096
            // 0x00BB56B4: STP x29, x30, [sp, #0x10]  | stack[1152921510036997104] = ???;  stack[1152921510036997112] = ???;  //  dest_result_addr=1152921510036997104 |  dest_result_addr=1152921510036997112
            // 0x00BB56B8: ADD x29, sp, #0x10         | X29 = (1152921510036997088 + 16) = 1152921510036997104 (0x1000000143A983F0);
            // 0x00BB56BC: SUB sp, sp, #0x20          | SP = (1152921510036997088 - 32) = 1152921510036997056 (0x1000000143A983C0);
            // 0x00BB56C0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB56C4: LDRB w8, [x20, #0xb2f]     | W8 = (bool)static_value_03733B2F;       
            // 0x00BB56C8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB56CC: TBNZ w8, #0, #0xbb56e8     | if (static_value_03733B2F == true) goto label_0;
            // 0x00BB56D0: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00BB56D4: LDR x8, [x8, #0x348]       | X8 = 0x2B8AB60;                         
            // 0x00BB56D8: LDR w0, [x8]               | W0 = 0x196;                             
            // 0x00BB56DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x196, ????);      
            // 0x00BB56E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB56E4: STRB w8, [x20, #0xb2f]     | static_value_03733B2F = true;            //  dest_result_addr=57883439
            label_0:
            // 0x00BB56E8: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB56EC: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB56F0: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB56F4: CBZ x19, #0xbb5748         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB56F8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB56FC: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5700: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5704: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5708: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB570C: B.LO #0xbb5724             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5710: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5714: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5718: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB571C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5720: B.EQ #0xbb574c             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5724: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5728: ADD x8, sp, #0x10          | X8 = (1152921510036997056 + 16) = 1152921510036997072 (0x1000000143A983D0);
            // 0x00BB572C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5730: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510036985120]
            // 0x00BB5734: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5738: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB573C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5740: ADD x0, sp, #0x10          | X0 = (1152921510036997056 + 16) = 1152921510036997072 (0x1000000143A983D0);
            // 0x00BB5744: BL #0x299a140              | 
            label_1:
            // 0x00BB5748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143A983D0, ????);
            label_3:
            // 0x00BB574C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5750: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5754: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5758: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB575C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5760: B.LO #0xbb57a4             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB5764: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5768: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB576C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5770: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5774: B.NE #0xbb57a4             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB5778: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB577C: LDR w8, [x19, #0x30]       | W8 = X1 + 48;                           
            // 0x00BB5780: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB5784: ADD x1, sp, #0xc           | X1 = (1152921510036997056 + 12) = 1152921510036997068 (0x1000000143A983CC);
            // 0x00BB5788: STR w8, [sp, #0xc]         | stack[1152921510036997068] = X1 + 48;    //  dest_result_addr=1152921510036997068
            // 0x00BB578C: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB5790: BL #0x27bc028              | X0 = 1152921510037045136 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 48);
            // 0x00BB5794: SUB sp, x29, #0x10         | SP = (1152921510036997104 - 16) = 1152921510036997088 (0x1000000143A983E0);
            // 0x00BB5798: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB579C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB57A0: RET                        |  return (System.Object)X1 + 48;         
            return (object)X1 + 48;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB57A4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB57A8: ADD x8, sp, #0x18          | X8 = (1152921510036997056 + 24) = 1152921510036997080 (0x1000000143A983D8);
            // 0x00BB57AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB57B0: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510036985120]
            // 0x00BB57B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB57B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB57BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB57C0: ADD x0, sp, #0x18          | X0 = (1152921510036997056 + 24) = 1152921510036997080 (0x1000000143A983D8);
            // 0x00BB57C4: BL #0x299a140              | 
            // 0x00BB57C8: MOV x19, x0                | X19 = 1152921510036997080 (0x1000000143A983D8);//ML01
            // 0x00BB57CC: ADD x0, sp, #0x10          | X0 = (1152921510036997056 + 16) = 1152921510036997072 (0x1000000143A983D0);
            label_6:
            // 0x00BB57D0: BL #0x299a140              | 
            // 0x00BB57D4: MOV x0, x19                | X0 = 1152921510036997080 (0x1000000143A983D8);//ML01
            // 0x00BB57D8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143A983D8, ????);
            // 0x00BB57DC: MOV x19, x0                | X19 = 1152921510036997080 (0x1000000143A983D8);//ML01
            // 0x00BB57E0: ADD x0, sp, #0x18          | X0 = (1152921510036997056 + 24) = 1152921510036997080 (0x1000000143A983D8);
            // 0x00BB57E4: B #0xbb57d0                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB57E8 (12277736), len: 412  VirtAddr: 0x00BB57E8 RVA: 0x00BB57E8 token: 100663711 methodIndex: 29756 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_turningSpeed_6(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB57E8: STP x22, x21, [sp, #-0x30]! | stack[1152921510037125296] = ???;  stack[1152921510037125304] = ???;  //  dest_result_addr=1152921510037125296 |  dest_result_addr=1152921510037125304
            // 0x00BB57EC: STP x20, x19, [sp, #0x10]  | stack[1152921510037125312] = ???;  stack[1152921510037125320] = ???;  //  dest_result_addr=1152921510037125312 |  dest_result_addr=1152921510037125320
            // 0x00BB57F0: STP x29, x30, [sp, #0x20]  | stack[1152921510037125328] = ???;  stack[1152921510037125336] = ???;  //  dest_result_addr=1152921510037125328 |  dest_result_addr=1152921510037125336
            // 0x00BB57F4: ADD x29, sp, #0x20         | X29 = (1152921510037125296 + 32) = 1152921510037125328 (0x1000000143AB78D0);
            // 0x00BB57F8: SUB sp, sp, #0x20          | SP = (1152921510037125296 - 32) = 1152921510037125264 (0x1000000143AB7890);
            // 0x00BB57FC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB5800: LDRB w8, [x21, #0xb30]     | W8 = (bool)static_value_03733B30;       
            // 0x00BB5804: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB5808: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB580C: TBNZ w8, #0, #0xbb5828     | if (static_value_03733B30 == true) goto label_0;
            // 0x00BB5810: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00BB5814: LDR x8, [x8, #0x148]       | X8 = 0x2B8ABB8;                         
            // 0x00BB5818: LDR w0, [x8]               | W0 = 0x1AC;                             
            // 0x00BB581C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1AC, ????);      
            // 0x00BB5820: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5824: STRB w8, [x21, #0xb30]     | static_value_03733B30 = true;            //  dest_result_addr=57883440
            label_0:
            // 0x00BB5828: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB582C: CBZ x21, #0xbb58e0         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB5830: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5834: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5838: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB583C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5840: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5844: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5848: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB584C: B.LO #0xbb5864             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5850: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5854: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5858: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB585C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5860: B.EQ #0xbb588c             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5864: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5868: ADD x8, sp, #8             | X8 = (1152921510037125264 + 8) = 1152921510037125272 (0x1000000143AB7898);
            // 0x00BB586C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB5870: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510037113344]
            // 0x00BB5874: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB587C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5880: ADD x0, sp, #8             | X0 = (1152921510037125264 + 8) = 1152921510037125272 (0x1000000143AB7898);
            // 0x00BB5884: BL #0x299a140              | 
            // 0x00BB5888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143AB7898, ????);
            label_3:
            // 0x00BB588C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5890: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5894: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5898: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB589C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB58A0: B.LO #0xbb58b8             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB58A4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB58A8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB58AC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB58B0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB58B4: B.EQ #0xbb58e8             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB58B8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB58BC: ADD x8, sp, #0x10          | X8 = (1152921510037125264 + 16) = 1152921510037125280 (0x1000000143AB78A0);
            // 0x00BB58C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB58C4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510037113344]
            // 0x00BB58C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB58CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB58D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB58D4: ADD x0, sp, #0x10          | X0 = (1152921510037125264 + 16) = 1152921510037125280 (0x1000000143AB78A0);
            // 0x00BB58D8: BL #0x299a140              | 
            // 0x00BB58DC: B #0xbb58e4                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB58E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AC, ????);      
            label_6:
            // 0x00BB58E4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB58E8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB58EC: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB58F0: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB58F4: CBNZ x19, #0xbb58fc        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB58F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AC, ????);      
            label_7:
            // 0x00BB58FC: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB5900: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB5904: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB5908: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB590C: B.NE #0xbb5954             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB5910: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB5914: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB5918: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB591C: STR w8, [x21, #0x30]       | mem[48] = X2;                            //  dest_result_addr=48
            mem[48] = X2;
            // 0x00BB5920: SUB sp, x29, #0x20         | SP = (1152921510037125328 - 32) = 1152921510037125296 (0x1000000143AB78B0);
            // 0x00BB5924: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5928: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB592C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB5930: RET                        |  return;                                
            return;
            // 0x00BB5934: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB5938: ADD x0, sp, #8             | X0 = (1152921510037125344 + 8) = 1152921510037125352 (0x1000000143AB78E8);
            // 0x00BB593C: B #0xbb5948                |  goto label_10;                         
            goto label_10;
            // 0x00BB5940: MOV x19, x0                | X19 = 1152921510037125352 (0x1000000143AB78E8);//ML01
            val_7;
            // 0x00BB5944: ADD x0, sp, #0x10          | X0 = (1152921510037125344 + 16) = 1152921510037125360 (0x1000000143AB78F0);
            label_10:
            // 0x00BB5948: BL #0x299a140              | 
            // 0x00BB594C: MOV x0, x19                | X0 = 1152921510037125352 (0x1000000143AB78E8);//ML01
            // 0x00BB5950: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143AB78E8, ????);
            label_8:
            // 0x00BB5954: ADD x8, sp, #0x18          | X8 = (1152921510037125344 + 24) = 1152921510037125368 (0x1000000143AB78F8);
            // 0x00BB5958: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB595C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143AB78E8, ????);
            // 0x00BB5960: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510037113344]
            // 0x00BB5964: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB5968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB596C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB5970: ADD x0, sp, #0x18          | X0 = (1152921510037125344 + 24) = 1152921510037125368 (0x1000000143AB78F8);
            // 0x00BB5974: BL #0x299a140              | 
            // 0x00BB5978: MOV x19, x0                | X19 = 1152921510037125368 (0x1000000143AB78F8);//ML01
            // 0x00BB597C: ADD x0, sp, #0x18          | X0 = (1152921510037125344 + 24) = 1152921510037125368 (0x1000000143AB78F8);
            // 0x00BB5980: B #0xbb5948                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5984 (12278148), len: 312  VirtAddr: 0x00BB5984 RVA: 0x00BB5984 token: 100663712 methodIndex: 29757 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_slowdownDistance_7(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB5984: STP x20, x19, [sp, #-0x20]! | stack[1152921510037253536] = ???;  stack[1152921510037253544] = ???;  //  dest_result_addr=1152921510037253536 |  dest_result_addr=1152921510037253544
            // 0x00BB5988: STP x29, x30, [sp, #0x10]  | stack[1152921510037253552] = ???;  stack[1152921510037253560] = ???;  //  dest_result_addr=1152921510037253552 |  dest_result_addr=1152921510037253560
            // 0x00BB598C: ADD x29, sp, #0x10         | X29 = (1152921510037253536 + 16) = 1152921510037253552 (0x1000000143AD6DB0);
            // 0x00BB5990: SUB sp, sp, #0x20          | SP = (1152921510037253536 - 32) = 1152921510037253504 (0x1000000143AD6D80);
            // 0x00BB5994: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB5998: LDRB w8, [x20, #0xb31]     | W8 = (bool)static_value_03733B31;       
            // 0x00BB599C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB59A0: TBNZ w8, #0, #0xbb59bc     | if (static_value_03733B31 == true) goto label_0;
            // 0x00BB59A4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00BB59A8: LDR x8, [x8, #0x1e0]       | X8 = 0x2B8AB48;                         
            // 0x00BB59AC: LDR w0, [x8]               | W0 = 0x190;                             
            // 0x00BB59B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x190, ????);      
            // 0x00BB59B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB59B8: STRB w8, [x20, #0xb31]     | static_value_03733B31 = true;            //  dest_result_addr=57883441
            label_0:
            // 0x00BB59BC: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB59C0: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB59C4: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB59C8: CBZ x19, #0xbb5a1c         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB59CC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB59D0: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB59D4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB59D8: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB59DC: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB59E0: B.LO #0xbb59f8             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB59E4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB59E8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB59EC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB59F0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB59F4: B.EQ #0xbb5a20             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB59F8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB59FC: ADD x8, sp, #0x10          | X8 = (1152921510037253504 + 16) = 1152921510037253520 (0x1000000143AD6D90);
            // 0x00BB5A00: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5A04: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510037241568]
            // 0x00BB5A08: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5A10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5A14: ADD x0, sp, #0x10          | X0 = (1152921510037253504 + 16) = 1152921510037253520 (0x1000000143AD6D90);
            // 0x00BB5A18: BL #0x299a140              | 
            label_1:
            // 0x00BB5A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143AD6D90, ????);
            label_3:
            // 0x00BB5A20: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5A24: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5A28: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5A2C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5A30: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5A34: B.LO #0xbb5a78             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB5A38: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5A3C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5A40: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5A44: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5A48: B.NE #0xbb5a78             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB5A4C: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB5A50: LDR w8, [x19, #0x34]       | W8 = X1 + 52;                           
            // 0x00BB5A54: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB5A58: ADD x1, sp, #0xc           | X1 = (1152921510037253504 + 12) = 1152921510037253516 (0x1000000143AD6D8C);
            // 0x00BB5A5C: STR w8, [sp, #0xc]         | stack[1152921510037253516] = X1 + 52;    //  dest_result_addr=1152921510037253516
            // 0x00BB5A60: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB5A64: BL #0x27bc028              | X0 = 1152921510037301584 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 52);
            // 0x00BB5A68: SUB sp, x29, #0x10         | SP = (1152921510037253552 - 16) = 1152921510037253536 (0x1000000143AD6DA0);
            // 0x00BB5A6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5A70: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB5A74: RET                        |  return (System.Object)X1 + 52;         
            return (object)X1 + 52;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB5A78: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5A7C: ADD x8, sp, #0x18          | X8 = (1152921510037253504 + 24) = 1152921510037253528 (0x1000000143AD6D98);
            // 0x00BB5A80: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5A84: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510037241568]
            // 0x00BB5A88: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5A90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5A94: ADD x0, sp, #0x18          | X0 = (1152921510037253504 + 24) = 1152921510037253528 (0x1000000143AD6D98);
            // 0x00BB5A98: BL #0x299a140              | 
            // 0x00BB5A9C: MOV x19, x0                | X19 = 1152921510037253528 (0x1000000143AD6D98);//ML01
            // 0x00BB5AA0: ADD x0, sp, #0x10          | X0 = (1152921510037253504 + 16) = 1152921510037253520 (0x1000000143AD6D90);
            label_6:
            // 0x00BB5AA4: BL #0x299a140              | 
            // 0x00BB5AA8: MOV x0, x19                | X0 = 1152921510037253528 (0x1000000143AD6D98);//ML01
            // 0x00BB5AAC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143AD6D98, ????);
            // 0x00BB5AB0: MOV x19, x0                | X19 = 1152921510037253528 (0x1000000143AD6D98);//ML01
            // 0x00BB5AB4: ADD x0, sp, #0x18          | X0 = (1152921510037253504 + 24) = 1152921510037253528 (0x1000000143AD6D98);
            // 0x00BB5AB8: B #0xbb5aa4                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5ABC (12278460), len: 412  VirtAddr: 0x00BB5ABC RVA: 0x00BB5ABC token: 100663713 methodIndex: 29758 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_slowdownDistance_7(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB5ABC: STP x22, x21, [sp, #-0x30]! | stack[1152921510037381744] = ???;  stack[1152921510037381752] = ???;  //  dest_result_addr=1152921510037381744 |  dest_result_addr=1152921510037381752
            // 0x00BB5AC0: STP x20, x19, [sp, #0x10]  | stack[1152921510037381760] = ???;  stack[1152921510037381768] = ???;  //  dest_result_addr=1152921510037381760 |  dest_result_addr=1152921510037381768
            // 0x00BB5AC4: STP x29, x30, [sp, #0x20]  | stack[1152921510037381776] = ???;  stack[1152921510037381784] = ???;  //  dest_result_addr=1152921510037381776 |  dest_result_addr=1152921510037381784
            // 0x00BB5AC8: ADD x29, sp, #0x20         | X29 = (1152921510037381744 + 32) = 1152921510037381776 (0x1000000143AF6290);
            // 0x00BB5ACC: SUB sp, sp, #0x20          | SP = (1152921510037381744 - 32) = 1152921510037381712 (0x1000000143AF6250);
            // 0x00BB5AD0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB5AD4: LDRB w8, [x21, #0xb32]     | W8 = (bool)static_value_03733B32;       
            // 0x00BB5AD8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB5ADC: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB5AE0: TBNZ w8, #0, #0xbb5afc     | if (static_value_03733B32 == true) goto label_0;
            // 0x00BB5AE4: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x00BB5AE8: LDR x8, [x8, #0x528]       | X8 = 0x2B8ABA4;                         
            // 0x00BB5AEC: LDR w0, [x8]               | W0 = 0x1A7;                             
            // 0x00BB5AF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A7, ????);      
            // 0x00BB5AF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5AF8: STRB w8, [x21, #0xb32]     | static_value_03733B32 = true;            //  dest_result_addr=57883442
            label_0:
            // 0x00BB5AFC: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB5B00: CBZ x21, #0xbb5bb4         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB5B04: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5B08: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5B0C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5B10: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5B14: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5B18: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5B1C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5B20: B.LO #0xbb5b38             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5B24: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5B28: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5B2C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5B30: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5B34: B.EQ #0xbb5b60             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5B38: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5B3C: ADD x8, sp, #8             | X8 = (1152921510037381712 + 8) = 1152921510037381720 (0x1000000143AF6258);
            // 0x00BB5B40: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB5B44: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510037369792]
            // 0x00BB5B48: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5B4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5B50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5B54: ADD x0, sp, #8             | X0 = (1152921510037381712 + 8) = 1152921510037381720 (0x1000000143AF6258);
            // 0x00BB5B58: BL #0x299a140              | 
            // 0x00BB5B5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143AF6258, ????);
            label_3:
            // 0x00BB5B60: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5B64: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5B68: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5B6C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5B70: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5B74: B.LO #0xbb5b8c             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB5B78: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5B7C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5B80: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5B84: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5B88: B.EQ #0xbb5bbc             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB5B8C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5B90: ADD x8, sp, #0x10          | X8 = (1152921510037381712 + 16) = 1152921510037381728 (0x1000000143AF6260);
            // 0x00BB5B94: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB5B98: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510037369792]
            // 0x00BB5B9C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5BA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5BA8: ADD x0, sp, #0x10          | X0 = (1152921510037381712 + 16) = 1152921510037381728 (0x1000000143AF6260);
            // 0x00BB5BAC: BL #0x299a140              | 
            // 0x00BB5BB0: B #0xbb5bb8                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB5BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A7, ????);      
            label_6:
            // 0x00BB5BB8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB5BBC: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB5BC0: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB5BC4: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB5BC8: CBNZ x19, #0xbb5bd0        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB5BCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A7, ????);      
            label_7:
            // 0x00BB5BD0: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB5BD4: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB5BD8: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB5BDC: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB5BE0: B.NE #0xbb5c28             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB5BE4: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB5BE8: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB5BEC: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB5BF0: STR w8, [x21, #0x34]       | mem[52] = X2;                            //  dest_result_addr=52
            mem[52] = X2;
            // 0x00BB5BF4: SUB sp, x29, #0x20         | SP = (1152921510037381776 - 32) = 1152921510037381744 (0x1000000143AF6270);
            // 0x00BB5BF8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5BFC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB5C00: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB5C04: RET                        |  return;                                
            return;
            // 0x00BB5C08: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB5C0C: ADD x0, sp, #8             | X0 = (1152921510037381792 + 8) = 1152921510037381800 (0x1000000143AF62A8);
            // 0x00BB5C10: B #0xbb5c1c                |  goto label_10;                         
            goto label_10;
            // 0x00BB5C14: MOV x19, x0                | X19 = 1152921510037381800 (0x1000000143AF62A8);//ML01
            val_7;
            // 0x00BB5C18: ADD x0, sp, #0x10          | X0 = (1152921510037381792 + 16) = 1152921510037381808 (0x1000000143AF62B0);
            label_10:
            // 0x00BB5C1C: BL #0x299a140              | 
            // 0x00BB5C20: MOV x0, x19                | X0 = 1152921510037381800 (0x1000000143AF62A8);//ML01
            // 0x00BB5C24: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143AF62A8, ????);
            label_8:
            // 0x00BB5C28: ADD x8, sp, #0x18          | X8 = (1152921510037381792 + 24) = 1152921510037381816 (0x1000000143AF62B8);
            // 0x00BB5C2C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB5C30: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143AF62A8, ????);
            // 0x00BB5C34: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510037369792]
            // 0x00BB5C38: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB5C3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5C40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB5C44: ADD x0, sp, #0x18          | X0 = (1152921510037381792 + 24) = 1152921510037381816 (0x1000000143AF62B8);
            // 0x00BB5C48: BL #0x299a140              | 
            // 0x00BB5C4C: MOV x19, x0                | X19 = 1152921510037381816 (0x1000000143AF62B8);//ML01
            // 0x00BB5C50: ADD x0, sp, #0x18          | X0 = (1152921510037381792 + 24) = 1152921510037381816 (0x1000000143AF62B8);
            // 0x00BB5C54: B #0xbb5c1c                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5C58 (12278872), len: 312  VirtAddr: 0x00BB5C58 RVA: 0x00BB5C58 token: 100663714 methodIndex: 29759 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_pickNextWaypointDist_8(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB5C58: STP x20, x19, [sp, #-0x20]! | stack[1152921510037509984] = ???;  stack[1152921510037509992] = ???;  //  dest_result_addr=1152921510037509984 |  dest_result_addr=1152921510037509992
            // 0x00BB5C5C: STP x29, x30, [sp, #0x10]  | stack[1152921510037510000] = ???;  stack[1152921510037510008] = ???;  //  dest_result_addr=1152921510037510000 |  dest_result_addr=1152921510037510008
            // 0x00BB5C60: ADD x29, sp, #0x10         | X29 = (1152921510037509984 + 16) = 1152921510037510000 (0x1000000143B15770);
            // 0x00BB5C64: SUB sp, sp, #0x20          | SP = (1152921510037509984 - 32) = 1152921510037509952 (0x1000000143B15740);
            // 0x00BB5C68: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB5C6C: LDRB w8, [x20, #0xb33]     | W8 = (bool)static_value_03733B33;       
            // 0x00BB5C70: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB5C74: TBNZ w8, #0, #0xbb5c90     | if (static_value_03733B33 == true) goto label_0;
            // 0x00BB5C78: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00BB5C7C: LDR x8, [x8, #0xc0]        | X8 = 0x2B8AB40;                         
            // 0x00BB5C80: LDR w0, [x8]               | W0 = 0x18E;                             
            // 0x00BB5C84: BL #0x2782188              | X0 = sub_2782188( ?? 0x18E, ????);      
            // 0x00BB5C88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5C8C: STRB w8, [x20, #0xb33]     | static_value_03733B33 = true;            //  dest_result_addr=57883443
            label_0:
            // 0x00BB5C90: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5C94: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB5C98: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5C9C: CBZ x19, #0xbb5cf0         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB5CA0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5CA4: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5CA8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5CAC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5CB0: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5CB4: B.LO #0xbb5ccc             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5CB8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5CBC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5CC0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5CC4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5CC8: B.EQ #0xbb5cf4             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5CCC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5CD0: ADD x8, sp, #0x10          | X8 = (1152921510037509952 + 16) = 1152921510037509968 (0x1000000143B15750);
            // 0x00BB5CD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5CD8: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510037498016]
            // 0x00BB5CDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5CE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5CE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5CE8: ADD x0, sp, #0x10          | X0 = (1152921510037509952 + 16) = 1152921510037509968 (0x1000000143B15750);
            // 0x00BB5CEC: BL #0x299a140              | 
            label_1:
            // 0x00BB5CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143B15750, ????);
            label_3:
            // 0x00BB5CF4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5CF8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5CFC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5D00: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5D04: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5D08: B.LO #0xbb5d4c             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB5D0C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5D10: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5D14: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5D18: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5D1C: B.NE #0xbb5d4c             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB5D20: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB5D24: LDR w8, [x19, #0x38]       | W8 = X1 + 56;                           
            // 0x00BB5D28: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB5D2C: ADD x1, sp, #0xc           | X1 = (1152921510037509952 + 12) = 1152921510037509964 (0x1000000143B1574C);
            // 0x00BB5D30: STR w8, [sp, #0xc]         | stack[1152921510037509964] = X1 + 56;    //  dest_result_addr=1152921510037509964
            // 0x00BB5D34: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB5D38: BL #0x27bc028              | X0 = 1152921510037558032 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 56);
            // 0x00BB5D3C: SUB sp, x29, #0x10         | SP = (1152921510037510000 - 16) = 1152921510037509984 (0x1000000143B15760);
            // 0x00BB5D40: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5D44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB5D48: RET                        |  return (System.Object)X1 + 56;         
            return (object)X1 + 56;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB5D4C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5D50: ADD x8, sp, #0x18          | X8 = (1152921510037509952 + 24) = 1152921510037509976 (0x1000000143B15758);
            // 0x00BB5D54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5D58: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510037498016]
            // 0x00BB5D5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5D60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5D64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5D68: ADD x0, sp, #0x18          | X0 = (1152921510037509952 + 24) = 1152921510037509976 (0x1000000143B15758);
            // 0x00BB5D6C: BL #0x299a140              | 
            // 0x00BB5D70: MOV x19, x0                | X19 = 1152921510037509976 (0x1000000143B15758);//ML01
            // 0x00BB5D74: ADD x0, sp, #0x10          | X0 = (1152921510037509952 + 16) = 1152921510037509968 (0x1000000143B15750);
            label_6:
            // 0x00BB5D78: BL #0x299a140              | 
            // 0x00BB5D7C: MOV x0, x19                | X0 = 1152921510037509976 (0x1000000143B15758);//ML01
            // 0x00BB5D80: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143B15758, ????);
            // 0x00BB5D84: MOV x19, x0                | X19 = 1152921510037509976 (0x1000000143B15758);//ML01
            // 0x00BB5D88: ADD x0, sp, #0x18          | X0 = (1152921510037509952 + 24) = 1152921510037509976 (0x1000000143B15758);
            // 0x00BB5D8C: B #0xbb5d78                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5D90 (12279184), len: 412  VirtAddr: 0x00BB5D90 RVA: 0x00BB5D90 token: 100663715 methodIndex: 29760 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_pickNextWaypointDist_8(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB5D90: STP x22, x21, [sp, #-0x30]! | stack[1152921510037638192] = ???;  stack[1152921510037638200] = ???;  //  dest_result_addr=1152921510037638192 |  dest_result_addr=1152921510037638200
            // 0x00BB5D94: STP x20, x19, [sp, #0x10]  | stack[1152921510037638208] = ???;  stack[1152921510037638216] = ???;  //  dest_result_addr=1152921510037638208 |  dest_result_addr=1152921510037638216
            // 0x00BB5D98: STP x29, x30, [sp, #0x20]  | stack[1152921510037638224] = ???;  stack[1152921510037638232] = ???;  //  dest_result_addr=1152921510037638224 |  dest_result_addr=1152921510037638232
            // 0x00BB5D9C: ADD x29, sp, #0x20         | X29 = (1152921510037638192 + 32) = 1152921510037638224 (0x1000000143B34C50);
            // 0x00BB5DA0: SUB sp, sp, #0x20          | SP = (1152921510037638192 - 32) = 1152921510037638160 (0x1000000143B34C10);
            // 0x00BB5DA4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB5DA8: LDRB w8, [x21, #0xb34]     | W8 = (bool)static_value_03733B34;       
            // 0x00BB5DAC: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB5DB0: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB5DB4: TBNZ w8, #0, #0xbb5dd0     | if (static_value_03733B34 == true) goto label_0;
            // 0x00BB5DB8: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x00BB5DBC: LDR x8, [x8, #0xf80]       | X8 = 0x2B8AB9C;                         
            // 0x00BB5DC0: LDR w0, [x8]               | W0 = 0x1A5;                             
            // 0x00BB5DC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A5, ????);      
            // 0x00BB5DC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5DCC: STRB w8, [x21, #0xb34]     | static_value_03733B34 = true;            //  dest_result_addr=57883444
            label_0:
            // 0x00BB5DD0: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB5DD4: CBZ x21, #0xbb5e88         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB5DD8: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5DDC: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5DE0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5DE4: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5DE8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5DEC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5DF0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5DF4: B.LO #0xbb5e0c             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5DF8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5DFC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5E00: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5E04: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5E08: B.EQ #0xbb5e34             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5E0C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5E10: ADD x8, sp, #8             | X8 = (1152921510037638160 + 8) = 1152921510037638168 (0x1000000143B34C18);
            // 0x00BB5E14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB5E18: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510037626240]
            // 0x00BB5E1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5E20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5E24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5E28: ADD x0, sp, #8             | X0 = (1152921510037638160 + 8) = 1152921510037638168 (0x1000000143B34C18);
            // 0x00BB5E2C: BL #0x299a140              | 
            // 0x00BB5E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143B34C18, ????);
            label_3:
            // 0x00BB5E34: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB5E38: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5E3C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB5E40: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5E44: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5E48: B.LO #0xbb5e60             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB5E4C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB5E50: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5E54: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5E58: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5E5C: B.EQ #0xbb5e90             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB5E60: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB5E64: ADD x8, sp, #0x10          | X8 = (1152921510037638160 + 16) = 1152921510037638176 (0x1000000143B34C20);
            // 0x00BB5E68: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB5E6C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510037626240]
            // 0x00BB5E70: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB5E74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5E78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB5E7C: ADD x0, sp, #0x10          | X0 = (1152921510037638160 + 16) = 1152921510037638176 (0x1000000143B34C20);
            // 0x00BB5E80: BL #0x299a140              | 
            // 0x00BB5E84: B #0xbb5e8c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB5E88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A5, ????);      
            label_6:
            // 0x00BB5E8C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB5E90: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB5E94: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB5E98: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB5E9C: CBNZ x19, #0xbb5ea4        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB5EA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A5, ????);      
            label_7:
            // 0x00BB5EA4: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB5EA8: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB5EAC: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB5EB0: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB5EB4: B.NE #0xbb5efc             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB5EB8: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB5EBC: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB5EC0: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB5EC4: STR w8, [x21, #0x38]       | mem[56] = X2;                            //  dest_result_addr=56
            mem[56] = X2;
            // 0x00BB5EC8: SUB sp, x29, #0x20         | SP = (1152921510037638224 - 32) = 1152921510037638192 (0x1000000143B34C30);
            // 0x00BB5ECC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB5ED0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB5ED4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB5ED8: RET                        |  return;                                
            return;
            // 0x00BB5EDC: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB5EE0: ADD x0, sp, #8             | X0 = (1152921510037638240 + 8) = 1152921510037638248 (0x1000000143B34C68);
            // 0x00BB5EE4: B #0xbb5ef0                |  goto label_10;                         
            goto label_10;
            // 0x00BB5EE8: MOV x19, x0                | X19 = 1152921510037638248 (0x1000000143B34C68);//ML01
            val_7;
            // 0x00BB5EEC: ADD x0, sp, #0x10          | X0 = (1152921510037638240 + 16) = 1152921510037638256 (0x1000000143B34C70);
            label_10:
            // 0x00BB5EF0: BL #0x299a140              | 
            // 0x00BB5EF4: MOV x0, x19                | X0 = 1152921510037638248 (0x1000000143B34C68);//ML01
            // 0x00BB5EF8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143B34C68, ????);
            label_8:
            // 0x00BB5EFC: ADD x8, sp, #0x18          | X8 = (1152921510037638240 + 24) = 1152921510037638264 (0x1000000143B34C78);
            // 0x00BB5F00: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB5F04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143B34C68, ????);
            // 0x00BB5F08: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510037626240]
            // 0x00BB5F0C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB5F10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5F14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB5F18: ADD x0, sp, #0x18          | X0 = (1152921510037638240 + 24) = 1152921510037638264 (0x1000000143B34C78);
            // 0x00BB5F1C: BL #0x299a140              | 
            // 0x00BB5F20: MOV x19, x0                | X19 = 1152921510037638264 (0x1000000143B34C78);//ML01
            // 0x00BB5F24: ADD x0, sp, #0x18          | X0 = (1152921510037638240 + 24) = 1152921510037638264 (0x1000000143B34C78);
            // 0x00BB5F28: B #0xbb5ef0                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB5F2C (12279596), len: 312  VirtAddr: 0x00BB5F2C RVA: 0x00BB5F2C token: 100663716 methodIndex: 29761 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_forwardLook_9(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB5F2C: STP x20, x19, [sp, #-0x20]! | stack[1152921510037766432] = ???;  stack[1152921510037766440] = ???;  //  dest_result_addr=1152921510037766432 |  dest_result_addr=1152921510037766440
            // 0x00BB5F30: STP x29, x30, [sp, #0x10]  | stack[1152921510037766448] = ???;  stack[1152921510037766456] = ???;  //  dest_result_addr=1152921510037766448 |  dest_result_addr=1152921510037766456
            // 0x00BB5F34: ADD x29, sp, #0x10         | X29 = (1152921510037766432 + 16) = 1152921510037766448 (0x1000000143B54130);
            // 0x00BB5F38: SUB sp, sp, #0x20          | SP = (1152921510037766432 - 32) = 1152921510037766400 (0x1000000143B54100);
            // 0x00BB5F3C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB5F40: LDRB w8, [x20, #0xb35]     | W8 = (bool)static_value_03733B35;       
            // 0x00BB5F44: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB5F48: TBNZ w8, #0, #0xbb5f64     | if (static_value_03733B35 == true) goto label_0;
            // 0x00BB5F4C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00BB5F50: LDR x8, [x8, #0x238]       | X8 = 0x2B8AB38;                         
            // 0x00BB5F54: LDR w0, [x8]               | W0 = 0x18C;                             
            // 0x00BB5F58: BL #0x2782188              | X0 = sub_2782188( ?? 0x18C, ????);      
            // 0x00BB5F5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB5F60: STRB w8, [x20, #0xb35]     | static_value_03733B35 = true;            //  dest_result_addr=57883445
            label_0:
            // 0x00BB5F64: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB5F68: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB5F6C: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB5F70: CBZ x19, #0xbb5fc4         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB5F74: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5F78: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5F7C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5F80: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5F84: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5F88: B.LO #0xbb5fa0             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB5F8C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5F90: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5F94: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5F98: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5F9C: B.EQ #0xbb5fc8             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB5FA0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB5FA4: ADD x8, sp, #0x10          | X8 = (1152921510037766400 + 16) = 1152921510037766416 (0x1000000143B54110);
            // 0x00BB5FA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB5FAC: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510037754464]
            // 0x00BB5FB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB5FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB5FB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB5FBC: ADD x0, sp, #0x10          | X0 = (1152921510037766400 + 16) = 1152921510037766416 (0x1000000143B54110);
            // 0x00BB5FC0: BL #0x299a140              | 
            label_1:
            // 0x00BB5FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143B54110, ????);
            label_3:
            // 0x00BB5FC8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB5FCC: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB5FD0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB5FD4: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB5FD8: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB5FDC: B.LO #0xbb6020             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB5FE0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB5FE4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB5FE8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB5FEC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB5FF0: B.NE #0xbb6020             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB5FF4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB5FF8: LDR w8, [x19, #0x3c]       | W8 = X1 + 60;                           
            // 0x00BB5FFC: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB6000: ADD x1, sp, #0xc           | X1 = (1152921510037766400 + 12) = 1152921510037766412 (0x1000000143B5410C);
            // 0x00BB6004: STR w8, [sp, #0xc]         | stack[1152921510037766412] = X1 + 60;    //  dest_result_addr=1152921510037766412
            // 0x00BB6008: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB600C: BL #0x27bc028              | X0 = 1152921510037814480 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 60);
            // 0x00BB6010: SUB sp, x29, #0x10         | SP = (1152921510037766448 - 16) = 1152921510037766432 (0x1000000143B54120);
            // 0x00BB6014: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6018: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB601C: RET                        |  return (System.Object)X1 + 60;         
            return (object)X1 + 60;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB6020: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6024: ADD x8, sp, #0x18          | X8 = (1152921510037766400 + 24) = 1152921510037766424 (0x1000000143B54118);
            // 0x00BB6028: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB602C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510037754464]
            // 0x00BB6030: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6038: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB603C: ADD x0, sp, #0x18          | X0 = (1152921510037766400 + 24) = 1152921510037766424 (0x1000000143B54118);
            // 0x00BB6040: BL #0x299a140              | 
            // 0x00BB6044: MOV x19, x0                | X19 = 1152921510037766424 (0x1000000143B54118);//ML01
            // 0x00BB6048: ADD x0, sp, #0x10          | X0 = (1152921510037766400 + 16) = 1152921510037766416 (0x1000000143B54110);
            label_6:
            // 0x00BB604C: BL #0x299a140              | 
            // 0x00BB6050: MOV x0, x19                | X0 = 1152921510037766424 (0x1000000143B54118);//ML01
            // 0x00BB6054: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143B54118, ????);
            // 0x00BB6058: MOV x19, x0                | X19 = 1152921510037766424 (0x1000000143B54118);//ML01
            // 0x00BB605C: ADD x0, sp, #0x18          | X0 = (1152921510037766400 + 24) = 1152921510037766424 (0x1000000143B54118);
            // 0x00BB6060: B #0xbb604c                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6064 (12279908), len: 412  VirtAddr: 0x00BB6064 RVA: 0x00BB6064 token: 100663717 methodIndex: 29762 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_forwardLook_9(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB6064: STP x22, x21, [sp, #-0x30]! | stack[1152921510037894640] = ???;  stack[1152921510037894648] = ???;  //  dest_result_addr=1152921510037894640 |  dest_result_addr=1152921510037894648
            // 0x00BB6068: STP x20, x19, [sp, #0x10]  | stack[1152921510037894656] = ???;  stack[1152921510037894664] = ???;  //  dest_result_addr=1152921510037894656 |  dest_result_addr=1152921510037894664
            // 0x00BB606C: STP x29, x30, [sp, #0x20]  | stack[1152921510037894672] = ???;  stack[1152921510037894680] = ???;  //  dest_result_addr=1152921510037894672 |  dest_result_addr=1152921510037894680
            // 0x00BB6070: ADD x29, sp, #0x20         | X29 = (1152921510037894640 + 32) = 1152921510037894672 (0x1000000143B73610);
            // 0x00BB6074: SUB sp, sp, #0x20          | SP = (1152921510037894640 - 32) = 1152921510037894608 (0x1000000143B735D0);
            // 0x00BB6078: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB607C: LDRB w8, [x21, #0xb36]     | W8 = (bool)static_value_03733B36;       
            // 0x00BB6080: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB6084: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB6088: TBNZ w8, #0, #0xbb60a4     | if (static_value_03733B36 == true) goto label_0;
            // 0x00BB608C: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x00BB6090: LDR x8, [x8, #0x138]       | X8 = 0x2B8AB94;                         
            // 0x00BB6094: LDR w0, [x8]               | W0 = 0x1A3;                             
            // 0x00BB6098: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A3, ????);      
            // 0x00BB609C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB60A0: STRB w8, [x21, #0xb36]     | static_value_03733B36 = true;            //  dest_result_addr=57883446
            label_0:
            // 0x00BB60A4: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB60A8: CBZ x21, #0xbb615c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB60AC: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB60B0: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB60B4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB60B8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB60BC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB60C0: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB60C4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB60C8: B.LO #0xbb60e0             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB60CC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB60D0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB60D4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB60D8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB60DC: B.EQ #0xbb6108             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB60E0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB60E4: ADD x8, sp, #8             | X8 = (1152921510037894608 + 8) = 1152921510037894616 (0x1000000143B735D8);
            // 0x00BB60E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB60EC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510037882688]
            // 0x00BB60F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB60F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB60F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB60FC: ADD x0, sp, #8             | X0 = (1152921510037894608 + 8) = 1152921510037894616 (0x1000000143B735D8);
            // 0x00BB6100: BL #0x299a140              | 
            // 0x00BB6104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143B735D8, ????);
            label_3:
            // 0x00BB6108: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB610C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6110: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6114: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6118: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB611C: B.LO #0xbb6134             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB6120: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6124: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6128: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB612C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6130: B.EQ #0xbb6164             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB6134: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB6138: ADD x8, sp, #0x10          | X8 = (1152921510037894608 + 16) = 1152921510037894624 (0x1000000143B735E0);
            // 0x00BB613C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6140: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510037882688]
            // 0x00BB6144: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB614C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6150: ADD x0, sp, #0x10          | X0 = (1152921510037894608 + 16) = 1152921510037894624 (0x1000000143B735E0);
            // 0x00BB6154: BL #0x299a140              | 
            // 0x00BB6158: B #0xbb6160                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB615C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3, ????);      
            label_6:
            // 0x00BB6160: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB6164: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB6168: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB616C: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB6170: CBNZ x19, #0xbb6178        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB6174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3, ????);      
            label_7:
            // 0x00BB6178: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB617C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB6180: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB6184: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB6188: B.NE #0xbb61d0             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB618C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB6190: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB6194: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB6198: STR w8, [x21, #0x3c]       | mem[60] = X2;                            //  dest_result_addr=60
            mem[60] = X2;
            // 0x00BB619C: SUB sp, x29, #0x20         | SP = (1152921510037894672 - 32) = 1152921510037894640 (0x1000000143B735F0);
            // 0x00BB61A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB61A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB61A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB61AC: RET                        |  return;                                
            return;
            // 0x00BB61B0: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB61B4: ADD x0, sp, #8             | X0 = (1152921510037894688 + 8) = 1152921510037894696 (0x1000000143B73628);
            // 0x00BB61B8: B #0xbb61c4                |  goto label_10;                         
            goto label_10;
            // 0x00BB61BC: MOV x19, x0                | X19 = 1152921510037894696 (0x1000000143B73628);//ML01
            val_7;
            // 0x00BB61C0: ADD x0, sp, #0x10          | X0 = (1152921510037894688 + 16) = 1152921510037894704 (0x1000000143B73630);
            label_10:
            // 0x00BB61C4: BL #0x299a140              | 
            // 0x00BB61C8: MOV x0, x19                | X0 = 1152921510037894696 (0x1000000143B73628);//ML01
            // 0x00BB61CC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143B73628, ????);
            label_8:
            // 0x00BB61D0: ADD x8, sp, #0x18          | X8 = (1152921510037894688 + 24) = 1152921510037894712 (0x1000000143B73638);
            // 0x00BB61D4: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB61D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143B73628, ????);
            // 0x00BB61DC: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510037882688]
            // 0x00BB61E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB61E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB61E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB61EC: ADD x0, sp, #0x18          | X0 = (1152921510037894688 + 24) = 1152921510037894712 (0x1000000143B73638);
            // 0x00BB61F0: BL #0x299a140              | 
            // 0x00BB61F4: MOV x19, x0                | X19 = 1152921510037894712 (0x1000000143B73638);//ML01
            // 0x00BB61F8: ADD x0, sp, #0x18          | X0 = (1152921510037894688 + 24) = 1152921510037894712 (0x1000000143B73638);
            // 0x00BB61FC: B #0xbb61c4                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6200 (12280320), len: 312  VirtAddr: 0x00BB6200 RVA: 0x00BB6200 token: 100663718 methodIndex: 29763 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_endReachedDistance_10(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB6200: STP x20, x19, [sp, #-0x20]! | stack[1152921510038022880] = ???;  stack[1152921510038022888] = ???;  //  dest_result_addr=1152921510038022880 |  dest_result_addr=1152921510038022888
            // 0x00BB6204: STP x29, x30, [sp, #0x10]  | stack[1152921510038022896] = ???;  stack[1152921510038022904] = ???;  //  dest_result_addr=1152921510038022896 |  dest_result_addr=1152921510038022904
            // 0x00BB6208: ADD x29, sp, #0x10         | X29 = (1152921510038022880 + 16) = 1152921510038022896 (0x1000000143B92AF0);
            // 0x00BB620C: SUB sp, sp, #0x20          | SP = (1152921510038022880 - 32) = 1152921510038022848 (0x1000000143B92AC0);
            // 0x00BB6210: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB6214: LDRB w8, [x20, #0xb37]     | W8 = (bool)static_value_03733B37;       
            // 0x00BB6218: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB621C: TBNZ w8, #0, #0xbb6238     | if (static_value_03733B37 == true) goto label_0;
            // 0x00BB6220: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00BB6224: LDR x8, [x8, #0xd00]       | X8 = 0x2B8AB34;                         
            // 0x00BB6228: LDR w0, [x8]               | W0 = 0x18B;                             
            // 0x00BB622C: BL #0x2782188              | X0 = sub_2782188( ?? 0x18B, ????);      
            // 0x00BB6230: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6234: STRB w8, [x20, #0xb37]     | static_value_03733B37 = true;            //  dest_result_addr=57883447
            label_0:
            // 0x00BB6238: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB623C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB6240: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6244: CBZ x19, #0xbb6298         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB6248: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB624C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6250: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6254: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6258: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB625C: B.LO #0xbb6274             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6260: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6264: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6268: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB626C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6270: B.EQ #0xbb629c             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6274: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6278: ADD x8, sp, #0x10          | X8 = (1152921510038022848 + 16) = 1152921510038022864 (0x1000000143B92AD0);
            // 0x00BB627C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6280: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510038010912]
            // 0x00BB6284: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB628C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6290: ADD x0, sp, #0x10          | X0 = (1152921510038022848 + 16) = 1152921510038022864 (0x1000000143B92AD0);
            // 0x00BB6294: BL #0x299a140              | 
            label_1:
            // 0x00BB6298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143B92AD0, ????);
            label_3:
            // 0x00BB629C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB62A0: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB62A4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB62A8: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB62AC: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB62B0: B.LO #0xbb62f4             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB62B4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB62B8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB62BC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB62C0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB62C4: B.NE #0xbb62f4             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB62C8: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB62CC: LDR w8, [x19, #0x40]       | W8 = X1 + 64;                           
            // 0x00BB62D0: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB62D4: ADD x1, sp, #0xc           | X1 = (1152921510038022848 + 12) = 1152921510038022860 (0x1000000143B92ACC);
            // 0x00BB62D8: STR w8, [sp, #0xc]         | stack[1152921510038022860] = X1 + 64;    //  dest_result_addr=1152921510038022860
            // 0x00BB62DC: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB62E0: BL #0x27bc028              | X0 = 1152921510038070928 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 64);
            // 0x00BB62E4: SUB sp, x29, #0x10         | SP = (1152921510038022896 - 16) = 1152921510038022880 (0x1000000143B92AE0);
            // 0x00BB62E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB62EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB62F0: RET                        |  return (System.Object)X1 + 64;         
            return (object)X1 + 64;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB62F4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB62F8: ADD x8, sp, #0x18          | X8 = (1152921510038022848 + 24) = 1152921510038022872 (0x1000000143B92AD8);
            // 0x00BB62FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6300: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510038010912]
            // 0x00BB6304: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB630C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6310: ADD x0, sp, #0x18          | X0 = (1152921510038022848 + 24) = 1152921510038022872 (0x1000000143B92AD8);
            // 0x00BB6314: BL #0x299a140              | 
            // 0x00BB6318: MOV x19, x0                | X19 = 1152921510038022872 (0x1000000143B92AD8);//ML01
            // 0x00BB631C: ADD x0, sp, #0x10          | X0 = (1152921510038022848 + 16) = 1152921510038022864 (0x1000000143B92AD0);
            label_6:
            // 0x00BB6320: BL #0x299a140              | 
            // 0x00BB6324: MOV x0, x19                | X0 = 1152921510038022872 (0x1000000143B92AD8);//ML01
            // 0x00BB6328: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143B92AD8, ????);
            // 0x00BB632C: MOV x19, x0                | X19 = 1152921510038022872 (0x1000000143B92AD8);//ML01
            // 0x00BB6330: ADD x0, sp, #0x18          | X0 = (1152921510038022848 + 24) = 1152921510038022872 (0x1000000143B92AD8);
            // 0x00BB6334: B #0xbb6320                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6338 (12280632), len: 412  VirtAddr: 0x00BB6338 RVA: 0x00BB6338 token: 100663719 methodIndex: 29764 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_endReachedDistance_10(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB6338: STP x22, x21, [sp, #-0x30]! | stack[1152921510038151088] = ???;  stack[1152921510038151096] = ???;  //  dest_result_addr=1152921510038151088 |  dest_result_addr=1152921510038151096
            // 0x00BB633C: STP x20, x19, [sp, #0x10]  | stack[1152921510038151104] = ???;  stack[1152921510038151112] = ???;  //  dest_result_addr=1152921510038151104 |  dest_result_addr=1152921510038151112
            // 0x00BB6340: STP x29, x30, [sp, #0x20]  | stack[1152921510038151120] = ???;  stack[1152921510038151128] = ???;  //  dest_result_addr=1152921510038151120 |  dest_result_addr=1152921510038151128
            // 0x00BB6344: ADD x29, sp, #0x20         | X29 = (1152921510038151088 + 32) = 1152921510038151120 (0x1000000143BB1FD0);
            // 0x00BB6348: SUB sp, sp, #0x20          | SP = (1152921510038151088 - 32) = 1152921510038151056 (0x1000000143BB1F90);
            // 0x00BB634C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB6350: LDRB w8, [x21, #0xb38]     | W8 = (bool)static_value_03733B38;       
            // 0x00BB6354: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB6358: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB635C: TBNZ w8, #0, #0xbb6378     | if (static_value_03733B38 == true) goto label_0;
            // 0x00BB6360: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BB6364: LDR x8, [x8, #0xdd0]       | X8 = 0x2B8AB90;                         
            // 0x00BB6368: LDR w0, [x8]               | W0 = 0x1A2;                             
            // 0x00BB636C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2, ????);      
            // 0x00BB6370: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6374: STRB w8, [x21, #0xb38]     | static_value_03733B38 = true;            //  dest_result_addr=57883448
            label_0:
            // 0x00BB6378: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB637C: CBZ x21, #0xbb6430         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB6380: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6384: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6388: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB638C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6390: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6394: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6398: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB639C: B.LO #0xbb63b4             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB63A0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB63A4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB63A8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB63AC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB63B0: B.EQ #0xbb63dc             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB63B4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB63B8: ADD x8, sp, #8             | X8 = (1152921510038151056 + 8) = 1152921510038151064 (0x1000000143BB1F98);
            // 0x00BB63BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB63C0: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510038139136]
            // 0x00BB63C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB63C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB63CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB63D0: ADD x0, sp, #8             | X0 = (1152921510038151056 + 8) = 1152921510038151064 (0x1000000143BB1F98);
            // 0x00BB63D4: BL #0x299a140              | 
            // 0x00BB63D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143BB1F98, ????);
            label_3:
            // 0x00BB63DC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB63E0: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB63E4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB63E8: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB63EC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB63F0: B.LO #0xbb6408             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB63F4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB63F8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB63FC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6400: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6404: B.EQ #0xbb6438             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB6408: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB640C: ADD x8, sp, #0x10          | X8 = (1152921510038151056 + 16) = 1152921510038151072 (0x1000000143BB1FA0);
            // 0x00BB6410: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6414: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510038139136]
            // 0x00BB6418: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB641C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6420: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6424: ADD x0, sp, #0x10          | X0 = (1152921510038151056 + 16) = 1152921510038151072 (0x1000000143BB1FA0);
            // 0x00BB6428: BL #0x299a140              | 
            // 0x00BB642C: B #0xbb6434                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB6430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2, ????);      
            label_6:
            // 0x00BB6434: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB6438: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB643C: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB6440: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB6444: CBNZ x19, #0xbb644c        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB6448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2, ????);      
            label_7:
            // 0x00BB644C: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB6450: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB6454: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB6458: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB645C: B.NE #0xbb64a4             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB6460: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB6464: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB6468: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB646C: STR w8, [x21, #0x40]       | mem[64] = X2;                            //  dest_result_addr=64
            mem[64] = X2;
            // 0x00BB6470: SUB sp, x29, #0x20         | SP = (1152921510038151120 - 32) = 1152921510038151088 (0x1000000143BB1FB0);
            // 0x00BB6474: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6478: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB647C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB6480: RET                        |  return;                                
            return;
            // 0x00BB6484: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB6488: ADD x0, sp, #8             | X0 = (1152921510038151136 + 8) = 1152921510038151144 (0x1000000143BB1FE8);
            // 0x00BB648C: B #0xbb6498                |  goto label_10;                         
            goto label_10;
            // 0x00BB6490: MOV x19, x0                | X19 = 1152921510038151144 (0x1000000143BB1FE8);//ML01
            val_7;
            // 0x00BB6494: ADD x0, sp, #0x10          | X0 = (1152921510038151136 + 16) = 1152921510038151152 (0x1000000143BB1FF0);
            label_10:
            // 0x00BB6498: BL #0x299a140              | 
            // 0x00BB649C: MOV x0, x19                | X0 = 1152921510038151144 (0x1000000143BB1FE8);//ML01
            // 0x00BB64A0: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143BB1FE8, ????);
            label_8:
            // 0x00BB64A4: ADD x8, sp, #0x18          | X8 = (1152921510038151136 + 24) = 1152921510038151160 (0x1000000143BB1FF8);
            // 0x00BB64A8: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB64AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143BB1FE8, ????);
            // 0x00BB64B0: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510038139136]
            // 0x00BB64B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB64B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB64BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB64C0: ADD x0, sp, #0x18          | X0 = (1152921510038151136 + 24) = 1152921510038151160 (0x1000000143BB1FF8);
            // 0x00BB64C4: BL #0x299a140              | 
            // 0x00BB64C8: MOV x19, x0                | X19 = 1152921510038151160 (0x1000000143BB1FF8);//ML01
            // 0x00BB64CC: ADD x0, sp, #0x18          | X0 = (1152921510038151136 + 24) = 1152921510038151160 (0x1000000143BB1FF8);
            // 0x00BB64D0: B #0xbb6498                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB64D4 (12281044), len: 312  VirtAddr: 0x00BB64D4 RVA: 0x00BB64D4 token: 100663720 methodIndex: 29765 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_closestOnPathCheck_11(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB64D4: STP x20, x19, [sp, #-0x20]! | stack[1152921510038279328] = ???;  stack[1152921510038279336] = ???;  //  dest_result_addr=1152921510038279328 |  dest_result_addr=1152921510038279336
            // 0x00BB64D8: STP x29, x30, [sp, #0x10]  | stack[1152921510038279344] = ???;  stack[1152921510038279352] = ???;  //  dest_result_addr=1152921510038279344 |  dest_result_addr=1152921510038279352
            // 0x00BB64DC: ADD x29, sp, #0x10         | X29 = (1152921510038279328 + 16) = 1152921510038279344 (0x1000000143BD14B0);
            // 0x00BB64E0: SUB sp, sp, #0x20          | SP = (1152921510038279328 - 32) = 1152921510038279296 (0x1000000143BD1480);
            // 0x00BB64E4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB64E8: LDRB w8, [x20, #0xb39]     | W8 = (bool)static_value_03733B39;       
            // 0x00BB64EC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB64F0: TBNZ w8, #0, #0xbb650c     | if (static_value_03733B39 == true) goto label_0;
            // 0x00BB64F4: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00BB64F8: LDR x8, [x8, #0xa38]       | X8 = 0x2B8AB30;                         
            // 0x00BB64FC: LDR w0, [x8]               | W0 = 0x18A;                             
            // 0x00BB6500: BL #0x2782188              | X0 = sub_2782188( ?? 0x18A, ????);      
            // 0x00BB6504: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6508: STRB w8, [x20, #0xb39]     | static_value_03733B39 = true;            //  dest_result_addr=57883449
            label_0:
            // 0x00BB650C: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6510: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB6514: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6518: CBZ x19, #0xbb656c         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB651C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6520: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6524: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6528: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB652C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6530: B.LO #0xbb6548             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6534: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6538: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB653C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6540: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6544: B.EQ #0xbb6570             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6548: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB654C: ADD x8, sp, #0x10          | X8 = (1152921510038279296 + 16) = 1152921510038279312 (0x1000000143BD1490);
            // 0x00BB6550: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6554: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510038267360]
            // 0x00BB6558: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB655C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6560: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6564: ADD x0, sp, #0x10          | X0 = (1152921510038279296 + 16) = 1152921510038279312 (0x1000000143BD1490);
            // 0x00BB6568: BL #0x299a140              | 
            label_1:
            // 0x00BB656C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143BD1490, ????);
            label_3:
            // 0x00BB6570: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6574: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6578: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB657C: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6580: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6584: B.LO #0xbb65c8             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB6588: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB658C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6590: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6594: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6598: B.NE #0xbb65c8             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB659C: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x00BB65A0: LDRB w8, [x19, #0x44]      | W8 = X1 + 68;                           
            // 0x00BB65A4: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x00BB65A8: ADD x1, sp, #0xf           | X1 = (1152921510038279296 + 15) = 1152921510038279311 (0x1000000143BD148F);
            // 0x00BB65AC: STRB w8, [sp, #0xf]        | stack[1152921510038279311] = X1 + 68;    //  dest_result_addr=1152921510038279311
            // 0x00BB65B0: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x00BB65B4: BL #0x27bc028              | X0 = 1152921510038327376 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 68);
            // 0x00BB65B8: SUB sp, x29, #0x10         | SP = (1152921510038279344 - 16) = 1152921510038279328 (0x1000000143BD14A0);
            // 0x00BB65BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB65C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB65C4: RET                        |  return (System.Object)X1 + 68;         
            return (object)X1 + 68;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB65C8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB65CC: ADD x8, sp, #0x18          | X8 = (1152921510038279296 + 24) = 1152921510038279320 (0x1000000143BD1498);
            // 0x00BB65D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB65D4: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510038267360]
            // 0x00BB65D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB65DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB65E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB65E4: ADD x0, sp, #0x18          | X0 = (1152921510038279296 + 24) = 1152921510038279320 (0x1000000143BD1498);
            // 0x00BB65E8: BL #0x299a140              | 
            // 0x00BB65EC: MOV x19, x0                | X19 = 1152921510038279320 (0x1000000143BD1498);//ML01
            // 0x00BB65F0: ADD x0, sp, #0x10          | X0 = (1152921510038279296 + 16) = 1152921510038279312 (0x1000000143BD1490);
            label_6:
            // 0x00BB65F4: BL #0x299a140              | 
            // 0x00BB65F8: MOV x0, x19                | X0 = 1152921510038279320 (0x1000000143BD1498);//ML01
            // 0x00BB65FC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143BD1498, ????);
            // 0x00BB6600: MOV x19, x0                | X19 = 1152921510038279320 (0x1000000143BD1498);//ML01
            // 0x00BB6604: ADD x0, sp, #0x18          | X0 = (1152921510038279296 + 24) = 1152921510038279320 (0x1000000143BD1498);
            // 0x00BB6608: B #0xbb65f4                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB660C (12281356), len: 412  VirtAddr: 0x00BB660C RVA: 0x00BB660C token: 100663721 methodIndex: 29766 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_closestOnPathCheck_11(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB660C: STP x22, x21, [sp, #-0x30]! | stack[1152921510038407536] = ???;  stack[1152921510038407544] = ???;  //  dest_result_addr=1152921510038407536 |  dest_result_addr=1152921510038407544
            // 0x00BB6610: STP x20, x19, [sp, #0x10]  | stack[1152921510038407552] = ???;  stack[1152921510038407560] = ???;  //  dest_result_addr=1152921510038407552 |  dest_result_addr=1152921510038407560
            // 0x00BB6614: STP x29, x30, [sp, #0x20]  | stack[1152921510038407568] = ???;  stack[1152921510038407576] = ???;  //  dest_result_addr=1152921510038407568 |  dest_result_addr=1152921510038407576
            // 0x00BB6618: ADD x29, sp, #0x20         | X29 = (1152921510038407536 + 32) = 1152921510038407568 (0x1000000143BF0990);
            // 0x00BB661C: SUB sp, sp, #0x20          | SP = (1152921510038407536 - 32) = 1152921510038407504 (0x1000000143BF0950);
            // 0x00BB6620: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB6624: LDRB w8, [x21, #0xb3a]     | W8 = (bool)static_value_03733B3A;       
            // 0x00BB6628: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB662C: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB6630: TBNZ w8, #0, #0xbb664c     | if (static_value_03733B3A == true) goto label_0;
            // 0x00BB6634: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x00BB6638: LDR x8, [x8, #0x668]       | X8 = 0x2B8AB8C;                         
            // 0x00BB663C: LDR w0, [x8]               | W0 = 0x1A1;                             
            // 0x00BB6640: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A1, ????);      
            // 0x00BB6644: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6648: STRB w8, [x21, #0xb3a]     | static_value_03733B3A = true;            //  dest_result_addr=57883450
            label_0:
            // 0x00BB664C: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB6650: CBZ x21, #0xbb6704         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB6654: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6658: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB665C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB6660: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6664: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6668: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB666C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6670: B.LO #0xbb6688             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6674: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6678: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB667C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6680: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6684: B.EQ #0xbb66b0             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6688: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB668C: ADD x8, sp, #8             | X8 = (1152921510038407504 + 8) = 1152921510038407512 (0x1000000143BF0958);
            // 0x00BB6690: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6694: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510038395584]
            // 0x00BB6698: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB669C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB66A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB66A4: ADD x0, sp, #8             | X0 = (1152921510038407504 + 8) = 1152921510038407512 (0x1000000143BF0958);
            // 0x00BB66A8: BL #0x299a140              | 
            // 0x00BB66AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143BF0958, ????);
            label_3:
            // 0x00BB66B0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB66B4: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB66B8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB66BC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB66C0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB66C4: B.LO #0xbb66dc             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB66C8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB66CC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB66D0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB66D4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB66D8: B.EQ #0xbb670c             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB66DC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB66E0: ADD x8, sp, #0x10          | X8 = (1152921510038407504 + 16) = 1152921510038407520 (0x1000000143BF0960);
            // 0x00BB66E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB66E8: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510038395584]
            // 0x00BB66EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB66F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB66F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB66F8: ADD x0, sp, #0x10          | X0 = (1152921510038407504 + 16) = 1152921510038407520 (0x1000000143BF0960);
            // 0x00BB66FC: BL #0x299a140              | 
            // 0x00BB6700: B #0xbb6708                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB6704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A1, ????);      
            label_6:
            // 0x00BB6708: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB670C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BB6710: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00BB6714: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x00BB6718: CBNZ x19, #0xbb6720        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB671C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A1, ????);      
            label_7:
            // 0x00BB6720: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB6724: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB6728: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00BB672C: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00BB6730: B.NE #0xbb6778             | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB6734: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB6738: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB673C: LDRB w8, [x0]              | W8 = X2;                                
            // 0x00BB6740: STRB w8, [x21, #0x44]      | mem[68] = X2;                            //  dest_result_addr=68
            mem[68] = X2;
            // 0x00BB6744: SUB sp, x29, #0x20         | SP = (1152921510038407568 - 32) = 1152921510038407536 (0x1000000143BF0970);
            // 0x00BB6748: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB674C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6750: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB6754: RET                        |  return;                                
            return;
            // 0x00BB6758: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB675C: ADD x0, sp, #8             | X0 = (1152921510038407584 + 8) = 1152921510038407592 (0x1000000143BF09A8);
            // 0x00BB6760: B #0xbb676c                |  goto label_10;                         
            goto label_10;
            // 0x00BB6764: MOV x19, x0                | X19 = 1152921510038407592 (0x1000000143BF09A8);//ML01
            val_7;
            // 0x00BB6768: ADD x0, sp, #0x10          | X0 = (1152921510038407584 + 16) = 1152921510038407600 (0x1000000143BF09B0);
            label_10:
            // 0x00BB676C: BL #0x299a140              | 
            // 0x00BB6770: MOV x0, x19                | X0 = 1152921510038407592 (0x1000000143BF09A8);//ML01
            // 0x00BB6774: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143BF09A8, ????);
            label_8:
            // 0x00BB6778: ADD x8, sp, #0x18          | X8 = (1152921510038407584 + 24) = 1152921510038407608 (0x1000000143BF09B8);
            // 0x00BB677C: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB6780: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143BF09A8, ????);
            // 0x00BB6784: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510038395584]
            // 0x00BB6788: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB678C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6790: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB6794: ADD x0, sp, #0x18          | X0 = (1152921510038407584 + 24) = 1152921510038407608 (0x1000000143BF09B8);
            // 0x00BB6798: BL #0x299a140              | 
            // 0x00BB679C: MOV x19, x0                | X19 = 1152921510038407608 (0x1000000143BF09B8);//ML01
            // 0x00BB67A0: ADD x0, sp, #0x18          | X0 = (1152921510038407584 + 24) = 1152921510038407608 (0x1000000143BF09B8);
            // 0x00BB67A4: B #0xbb676c                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB67A8 (12281768), len: 288  VirtAddr: 0x00BB67A8 RVA: 0x00BB67A8 token: 100663722 methodIndex: 29767 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_tr_12(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB67A8: STP x20, x19, [sp, #-0x20]! | stack[1152921510038531680] = ???;  stack[1152921510038531688] = ???;  //  dest_result_addr=1152921510038531680 |  dest_result_addr=1152921510038531688
            // 0x00BB67AC: STP x29, x30, [sp, #0x10]  | stack[1152921510038531696] = ???;  stack[1152921510038531704] = ???;  //  dest_result_addr=1152921510038531696 |  dest_result_addr=1152921510038531704
            // 0x00BB67B0: ADD x29, sp, #0x10         | X29 = (1152921510038531680 + 16) = 1152921510038531696 (0x1000000143C0EE70);
            // 0x00BB67B4: SUB sp, sp, #0x10          | SP = (1152921510038531680 - 16) = 1152921510038531664 (0x1000000143C0EE50);
            // 0x00BB67B8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB67BC: LDRB w8, [x20, #0xb3b]     | W8 = (bool)static_value_03733B3B;       
            // 0x00BB67C0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB67C4: TBNZ w8, #0, #0xbb67e0     | if (static_value_03733B3B == true) goto label_0;
            // 0x00BB67C8: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00BB67CC: LDR x8, [x8, #0x9e0]       | X8 = 0x2B8AB5C;                         
            // 0x00BB67D0: LDR w0, [x8]               | W0 = 0x195;                             
            // 0x00BB67D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x195, ????);      
            // 0x00BB67D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB67DC: STRB w8, [x20, #0xb3b]     | static_value_03733B3B = true;            //  dest_result_addr=57883451
            label_0:
            // 0x00BB67E0: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB67E4: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB67E8: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB67EC: CBZ x19, #0xbb6840         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB67F0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB67F4: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB67F8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB67FC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6800: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6804: B.LO #0xbb681c             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6808: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB680C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6810: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6814: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6818: B.EQ #0xbb6844             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB681C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6820: MOV x8, sp                 | X8 = 1152921510038531664 (0x1000000143C0EE50);//ML01
            // 0x00BB6824: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6828: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510038519712]
            // 0x00BB682C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6834: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6838: MOV x0, sp                 | X0 = 1152921510038531664 (0x1000000143C0EE50);//ML01
            // 0x00BB683C: BL #0x299a140              | 
            label_1:
            // 0x00BB6840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143C0EE50, ????);
            label_3:
            // 0x00BB6844: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6848: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB684C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6850: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6854: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6858: B.LO #0xbb6884             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB685C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6860: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6864: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6868: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB686C: B.NE #0xbb6884             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB6870: LDR x0, [x19, #0x58]       | X0 = X1 + 88;                           
            // 0x00BB6874: SUB sp, x29, #0x10         | SP = (1152921510038531696 - 16) = 1152921510038531680 (0x1000000143C0EE60);
            // 0x00BB6878: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB687C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6880: RET                        |  return (System.Object)X1 + 88;         
            return (object)X1 + 88;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB6884: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6888: ADD x8, sp, #8             | X8 = (1152921510038531664 + 8) = 1152921510038531672 (0x1000000143C0EE58);
            // 0x00BB688C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6890: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510038519712]
            // 0x00BB6894: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB689C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB68A0: ADD x0, sp, #8             | X0 = (1152921510038531664 + 8) = 1152921510038531672 (0x1000000143C0EE58);
            // 0x00BB68A4: BL #0x299a140              | 
            // 0x00BB68A8: MOV x19, x0                | X19 = 1152921510038531672 (0x1000000143C0EE58);//ML01
            // 0x00BB68AC: MOV x0, sp                 | X0 = 1152921510038531664 (0x1000000143C0EE50);//ML01
            label_6:
            // 0x00BB68B0: BL #0x299a140              | 
            // 0x00BB68B4: MOV x0, x19                | X0 = 1152921510038531672 (0x1000000143C0EE58);//ML01
            // 0x00BB68B8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143C0EE58, ????);
            // 0x00BB68BC: MOV x19, x0                | X19 = 1152921510038531672 (0x1000000143C0EE58);//ML01
            // 0x00BB68C0: ADD x0, sp, #8             | X0 = (1152921510038531664 + 8) = 1152921510038531672 (0x1000000143C0EE58);
            // 0x00BB68C4: B #0xbb68b0                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB68C8 (12282056), len: 420  VirtAddr: 0x00BB68C8 RVA: 0x00BB68C8 token: 100663723 methodIndex: 29768 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_tr_12(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BB68C8: STP x22, x21, [sp, #-0x30]! | stack[1152921510038655792] = ???;  stack[1152921510038655800] = ???;  //  dest_result_addr=1152921510038655792 |  dest_result_addr=1152921510038655800
            // 0x00BB68CC: STP x20, x19, [sp, #0x10]  | stack[1152921510038655808] = ???;  stack[1152921510038655816] = ???;  //  dest_result_addr=1152921510038655808 |  dest_result_addr=1152921510038655816
            // 0x00BB68D0: STP x29, x30, [sp, #0x20]  | stack[1152921510038655824] = ???;  stack[1152921510038655832] = ???;  //  dest_result_addr=1152921510038655824 |  dest_result_addr=1152921510038655832
            // 0x00BB68D4: ADD x29, sp, #0x20         | X29 = (1152921510038655792 + 32) = 1152921510038655824 (0x1000000143C2D350);
            // 0x00BB68D8: SUB sp, sp, #0x20          | SP = (1152921510038655792 - 32) = 1152921510038655760 (0x1000000143C2D310);
            // 0x00BB68DC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB68E0: LDRB w8, [x21, #0xb3c]     | W8 = (bool)static_value_03733B3C;       
            // 0x00BB68E4: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00BB68E8: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB68EC: TBNZ w8, #0, #0xbb6908     | if (static_value_03733B3C == true) goto label_0;
            // 0x00BB68F0: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00BB68F4: LDR x8, [x8, #0xf70]       | X8 = 0x2B8ABB4;                         
            // 0x00BB68F8: LDR w0, [x8]               | W0 = 0x1AB;                             
            // 0x00BB68FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1AB, ????);      
            // 0x00BB6900: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6904: STRB w8, [x21, #0xb3c]     | static_value_03733B3C = true;            //  dest_result_addr=57883452
            label_0:
            // 0x00BB6908: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BB690C: CBZ x20, #0xbb69c0         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB6910: ADRP x21, #0x364f000       | X21 = 56946688 (0x364F000);             
            // 0x00BB6914: LDR x21, [x21, #0xf50]     | X21 = 1152921504835227648;              
            val_7 = 1152921504835227648;
            // 0x00BB6918: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BB691C: LDR x1, [x21]              | X1 = typeof(AIPath);                    
            // 0x00BB6920: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6924: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6928: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB692C: B.LO #0xbb6944             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6930: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6934: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6938: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB693C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6940: B.EQ #0xbb696c             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6944: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB6948: ADD x8, sp, #8             | X8 = (1152921510038655760 + 8) = 1152921510038655768 (0x1000000143C2D318);
            // 0x00BB694C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6950: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510038643840]
            // 0x00BB6954: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB695C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6960: ADD x0, sp, #8             | X0 = (1152921510038655760 + 8) = 1152921510038655768 (0x1000000143C2D318);
            // 0x00BB6964: BL #0x299a140              | 
            // 0x00BB6968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143C2D318, ????);
            label_3:
            // 0x00BB696C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BB6970: LDR x1, [x21]              | X1 = typeof(AIPath);                    
            // 0x00BB6974: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6978: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB697C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6980: B.LO #0xbb6998             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB6984: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6988: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB698C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6990: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6994: B.EQ #0xbb69c8             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB6998: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB699C: ADD x8, sp, #0x10          | X8 = (1152921510038655760 + 16) = 1152921510038655776 (0x1000000143C2D320);
            // 0x00BB69A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB69A4: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510038643840]
            // 0x00BB69A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB69AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB69B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB69B4: ADD x0, sp, #0x10          | X0 = (1152921510038655760 + 16) = 1152921510038655776 (0x1000000143C2D320);
            // 0x00BB69B8: BL #0x299a140              | 
            // 0x00BB69BC: B #0xbb69c4                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB69C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AB, ????);      
            label_6:
            // 0x00BB69C4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x00BB69C8: CBZ x19, #0xbb6a24         | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00BB69CC: ADRP x9, #0x35e5000        | X9 = 56512512 (0x35E5000);              
            // 0x00BB69D0: LDR x9, [x9, #0xe58]       | X9 = 1152921504698060800;               
            // 0x00BB69D4: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB69D8: LDR x1, [x9]               | X1 = typeof(UnityEngine.Transform);     
            // 0x00BB69DC: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x00BB69E0: LDRB w9, [x1, #0x104]      | W9 = UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB69E4: CMP w10, w9                | STATE = COMPARE(X2 + 260, UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB69E8: B.LO #0xbb6a00             | if (X2 + 260 < UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00BB69EC: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x00BB69F0: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB69F4: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB69F8: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.Transform))
            // 0x00BB69FC: B.EQ #0xbb6a28             | if ((X2 + 176 + (UnityEngine.Transform.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00BB6A00: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB6A04: ADD x8, sp, #0x18          | X8 = (1152921510038655760 + 24) = 1152921510038655784 (0x1000000143C2D328);
            // 0x00BB6A08: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BB6A0C: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510038643840]
            // 0x00BB6A10: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BB6A14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6A18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BB6A1C: ADD x0, sp, #0x18          | X0 = (1152921510038655760 + 24) = 1152921510038655784 (0x1000000143C2D328);
            // 0x00BB6A20: BL #0x299a140              | 
            label_7:
            // 0x00BB6A24: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BB6A28: STR x19, [x20, #0x58]      | mem[88] = 0x0;                           //  dest_result_addr=88
            mem[88] = val_8;
            // 0x00BB6A2C: SUB sp, x29, #0x20         | SP = (1152921510038655824 - 32) = 1152921510038655792 (0x1000000143C2D330);
            // 0x00BB6A30: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6A34: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6A38: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB6A3C: RET                        |  return;                                
            return;
            // 0x00BB6A40: MOV x19, x0                | 
            // 0x00BB6A44: ADD x0, sp, #8             | 
            // 0x00BB6A48: B #0xbb6a60                | 
            // 0x00BB6A4C: MOV x19, x0                | 
            // 0x00BB6A50: ADD x0, sp, #0x10          | 
            // 0x00BB6A54: B #0xbb6a60                | 
            // 0x00BB6A58: MOV x19, x0                | 
            // 0x00BB6A5C: ADD x0, sp, #0x18          | 
            label_11:
            // 0x00BB6A60: BL #0x299a140              | 
            // 0x00BB6A64: MOV x0, x19                | 
            // 0x00BB6A68: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6A6C (12282476), len: 312  VirtAddr: 0x00BB6A6C RVA: 0x00BB6A6C token: 100663724 methodIndex: 29769 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_IsSearchPathing_13(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB6A6C: STP x20, x19, [sp, #-0x20]! | stack[1152921510038784032] = ???;  stack[1152921510038784040] = ???;  //  dest_result_addr=1152921510038784032 |  dest_result_addr=1152921510038784040
            // 0x00BB6A70: STP x29, x30, [sp, #0x10]  | stack[1152921510038784048] = ???;  stack[1152921510038784056] = ???;  //  dest_result_addr=1152921510038784048 |  dest_result_addr=1152921510038784056
            // 0x00BB6A74: ADD x29, sp, #0x10         | X29 = (1152921510038784032 + 16) = 1152921510038784048 (0x1000000143C4C830);
            // 0x00BB6A78: SUB sp, sp, #0x20          | SP = (1152921510038784032 - 32) = 1152921510038784000 (0x1000000143C4C800);
            // 0x00BB6A7C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB6A80: LDRB w8, [x20, #0xb3d]     | W8 = (bool)static_value_03733B3D;       
            // 0x00BB6A84: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB6A88: TBNZ w8, #0, #0xbb6aa4     | if (static_value_03733B3D == true) goto label_0;
            // 0x00BB6A8C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00BB6A90: LDR x8, [x8, #0xc48]       | X8 = 0x2B8AB3C;                         
            // 0x00BB6A94: LDR w0, [x8]               | W0 = 0x18D;                             
            // 0x00BB6A98: BL #0x2782188              | X0 = sub_2782188( ?? 0x18D, ????);      
            // 0x00BB6A9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6AA0: STRB w8, [x20, #0xb3d]     | static_value_03733B3D = true;            //  dest_result_addr=57883453
            label_0:
            // 0x00BB6AA4: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6AA8: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB6AAC: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6AB0: CBZ x19, #0xbb6b04         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB6AB4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6AB8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6ABC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6AC0: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6AC4: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6AC8: B.LO #0xbb6ae0             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6ACC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6AD0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6AD4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6AD8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6ADC: B.EQ #0xbb6b08             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6AE0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6AE4: ADD x8, sp, #0x10          | X8 = (1152921510038784000 + 16) = 1152921510038784016 (0x1000000143C4C810);
            // 0x00BB6AE8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6AEC: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510038772064]
            // 0x00BB6AF0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6AF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6AF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6AFC: ADD x0, sp, #0x10          | X0 = (1152921510038784000 + 16) = 1152921510038784016 (0x1000000143C4C810);
            // 0x00BB6B00: BL #0x299a140              | 
            label_1:
            // 0x00BB6B04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143C4C810, ????);
            label_3:
            // 0x00BB6B08: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6B0C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6B10: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6B14: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6B18: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6B1C: B.LO #0xbb6b60             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB6B20: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6B24: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6B28: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6B2C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6B30: B.NE #0xbb6b60             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB6B34: ADRP x9, #0x3626000        | X9 = 56778752 (0x3626000);              
            // 0x00BB6B38: LDRB w8, [x19, #0xa9]      | W8 = X1 + 169;                          
            // 0x00BB6B3C: LDR x9, [x9, #0x7d8]       | X9 = 1152921504608604160;               
            // 0x00BB6B40: ADD x1, sp, #0xf           | X1 = (1152921510038784000 + 15) = 1152921510038784015 (0x1000000143C4C80F);
            // 0x00BB6B44: STRB w8, [sp, #0xf]        | stack[1152921510038784015] = X1 + 169;   //  dest_result_addr=1152921510038784015
            // 0x00BB6B48: LDR x0, [x9]               | X0 = typeof(System.Boolean);            
            // 0x00BB6B4C: BL #0x27bc028              | X0 = 1152921510038832080 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), X1 + 169);
            // 0x00BB6B50: SUB sp, x29, #0x10         | SP = (1152921510038784048 - 16) = 1152921510038784032 (0x1000000143C4C820);
            // 0x00BB6B54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6B58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6B5C: RET                        |  return (System.Object)X1 + 169;        
            return (object)X1 + 169;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB6B60: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6B64: ADD x8, sp, #0x18          | X8 = (1152921510038784000 + 24) = 1152921510038784024 (0x1000000143C4C818);
            // 0x00BB6B68: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6B6C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510038772064]
            // 0x00BB6B70: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6B74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6B78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6B7C: ADD x0, sp, #0x18          | X0 = (1152921510038784000 + 24) = 1152921510038784024 (0x1000000143C4C818);
            // 0x00BB6B80: BL #0x299a140              | 
            // 0x00BB6B84: MOV x19, x0                | X19 = 1152921510038784024 (0x1000000143C4C818);//ML01
            // 0x00BB6B88: ADD x0, sp, #0x10          | X0 = (1152921510038784000 + 16) = 1152921510038784016 (0x1000000143C4C810);
            label_6:
            // 0x00BB6B8C: BL #0x299a140              | 
            // 0x00BB6B90: MOV x0, x19                | X0 = 1152921510038784024 (0x1000000143C4C818);//ML01
            // 0x00BB6B94: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143C4C818, ????);
            // 0x00BB6B98: MOV x19, x0                | X19 = 1152921510038784024 (0x1000000143C4C818);//ML01
            // 0x00BB6B9C: ADD x0, sp, #0x18          | X0 = (1152921510038784000 + 24) = 1152921510038784024 (0x1000000143C4C818);
            // 0x00BB6BA0: B #0xbb6b8c                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6BA4 (12282788), len: 412  VirtAddr: 0x00BB6BA4 RVA: 0x00BB6BA4 token: 100663725 methodIndex: 29770 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_IsSearchPathing_13(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB6BA4: STP x22, x21, [sp, #-0x30]! | stack[1152921510038912240] = ???;  stack[1152921510038912248] = ???;  //  dest_result_addr=1152921510038912240 |  dest_result_addr=1152921510038912248
            // 0x00BB6BA8: STP x20, x19, [sp, #0x10]  | stack[1152921510038912256] = ???;  stack[1152921510038912264] = ???;  //  dest_result_addr=1152921510038912256 |  dest_result_addr=1152921510038912264
            // 0x00BB6BAC: STP x29, x30, [sp, #0x20]  | stack[1152921510038912272] = ???;  stack[1152921510038912280] = ???;  //  dest_result_addr=1152921510038912272 |  dest_result_addr=1152921510038912280
            // 0x00BB6BB0: ADD x29, sp, #0x20         | X29 = (1152921510038912240 + 32) = 1152921510038912272 (0x1000000143C6BD10);
            // 0x00BB6BB4: SUB sp, sp, #0x20          | SP = (1152921510038912240 - 32) = 1152921510038912208 (0x1000000143C6BCD0);
            // 0x00BB6BB8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB6BBC: LDRB w8, [x21, #0xb3e]     | W8 = (bool)static_value_03733B3E;       
            // 0x00BB6BC0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB6BC4: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB6BC8: TBNZ w8, #0, #0xbb6be4     | if (static_value_03733B3E == true) goto label_0;
            // 0x00BB6BCC: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00BB6BD0: LDR x8, [x8, #0x698]       | X8 = 0x2B8AB98;                         
            // 0x00BB6BD4: LDR w0, [x8]               | W0 = 0x1A4;                             
            // 0x00BB6BD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A4, ????);      
            // 0x00BB6BDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6BE0: STRB w8, [x21, #0xb3e]     | static_value_03733B3E = true;            //  dest_result_addr=57883454
            label_0:
            // 0x00BB6BE4: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB6BE8: CBZ x21, #0xbb6c9c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB6BEC: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6BF0: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6BF4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB6BF8: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6BFC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6C00: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6C04: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6C08: B.LO #0xbb6c20             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6C0C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6C10: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6C14: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6C18: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6C1C: B.EQ #0xbb6c48             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6C20: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB6C24: ADD x8, sp, #8             | X8 = (1152921510038912208 + 8) = 1152921510038912216 (0x1000000143C6BCD8);
            // 0x00BB6C28: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6C2C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510038900288]
            // 0x00BB6C30: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6C34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6C38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6C3C: ADD x0, sp, #8             | X0 = (1152921510038912208 + 8) = 1152921510038912216 (0x1000000143C6BCD8);
            // 0x00BB6C40: BL #0x299a140              | 
            // 0x00BB6C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143C6BCD8, ????);
            label_3:
            // 0x00BB6C48: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB6C4C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6C50: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6C54: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6C58: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6C5C: B.LO #0xbb6c74             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB6C60: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6C64: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6C68: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6C6C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6C70: B.EQ #0xbb6ca4             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB6C74: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB6C78: ADD x8, sp, #0x10          | X8 = (1152921510038912208 + 16) = 1152921510038912224 (0x1000000143C6BCE0);
            // 0x00BB6C7C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6C80: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510038900288]
            // 0x00BB6C84: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6C8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6C90: ADD x0, sp, #0x10          | X0 = (1152921510038912208 + 16) = 1152921510038912224 (0x1000000143C6BCE0);
            // 0x00BB6C94: BL #0x299a140              | 
            // 0x00BB6C98: B #0xbb6ca0                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB6C9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A4, ????);      
            label_6:
            // 0x00BB6CA0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB6CA4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00BB6CA8: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00BB6CAC: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x00BB6CB0: CBNZ x19, #0xbb6cb8        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB6CB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A4, ????);      
            label_7:
            // 0x00BB6CB8: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB6CBC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB6CC0: LDR x8, [x20, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00BB6CC4: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00BB6CC8: B.NE #0xbb6d10             | if (X2 + 48 != System.Boolean.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB6CCC: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB6CD0: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB6CD4: LDRB w8, [x0]              | W8 = X2;                                
            // 0x00BB6CD8: STRB w8, [x21, #0xa9]      | mem[169] = X2;                           //  dest_result_addr=169
            mem[169] = X2;
            // 0x00BB6CDC: SUB sp, x29, #0x20         | SP = (1152921510038912272 - 32) = 1152921510038912240 (0x1000000143C6BCF0);
            // 0x00BB6CE0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6CE4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6CE8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB6CEC: RET                        |  return;                                
            return;
            // 0x00BB6CF0: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB6CF4: ADD x0, sp, #8             | X0 = (1152921510038912288 + 8) = 1152921510038912296 (0x1000000143C6BD28);
            // 0x00BB6CF8: B #0xbb6d04                |  goto label_10;                         
            goto label_10;
            // 0x00BB6CFC: MOV x19, x0                | X19 = 1152921510038912296 (0x1000000143C6BD28);//ML01
            val_7;
            // 0x00BB6D00: ADD x0, sp, #0x10          | X0 = (1152921510038912288 + 16) = 1152921510038912304 (0x1000000143C6BD30);
            label_10:
            // 0x00BB6D04: BL #0x299a140              | 
            // 0x00BB6D08: MOV x0, x19                | X0 = 1152921510038912296 (0x1000000143C6BD28);//ML01
            // 0x00BB6D0C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143C6BD28, ????);
            label_8:
            // 0x00BB6D10: ADD x8, sp, #0x18          | X8 = (1152921510038912288 + 24) = 1152921510038912312 (0x1000000143C6BD38);
            // 0x00BB6D14: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB6D18: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143C6BD28, ????);
            // 0x00BB6D1C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510038900288]
            // 0x00BB6D20: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB6D24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6D28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB6D2C: ADD x0, sp, #0x18          | X0 = (1152921510038912288 + 24) = 1152921510038912312 (0x1000000143C6BD38);
            // 0x00BB6D30: BL #0x299a140              | 
            // 0x00BB6D34: MOV x19, x0                | X19 = 1152921510038912312 (0x1000000143C6BD38);//ML01
            // 0x00BB6D38: ADD x0, sp, #0x18          | X0 = (1152921510038912288 + 24) = 1152921510038912312 (0x1000000143C6BD38);
            // 0x00BB6D3C: B #0xbb6d04                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6D40 (12283200), len: 320  VirtAddr: 0x00BB6D40 RVA: 0x00BB6D40 token: 100663726 methodIndex: 29771 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_targetPoint_14(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB6D40: STP x20, x19, [sp, #-0x20]! | stack[1152921510039040480] = ???;  stack[1152921510039040488] = ???;  //  dest_result_addr=1152921510039040480 |  dest_result_addr=1152921510039040488
            // 0x00BB6D44: STP x29, x30, [sp, #0x10]  | stack[1152921510039040496] = ???;  stack[1152921510039040504] = ???;  //  dest_result_addr=1152921510039040496 |  dest_result_addr=1152921510039040504
            // 0x00BB6D48: ADD x29, sp, #0x10         | X29 = (1152921510039040480 + 16) = 1152921510039040496 (0x1000000143C8B1F0);
            // 0x00BB6D4C: SUB sp, sp, #0x20          | SP = (1152921510039040480 - 32) = 1152921510039040448 (0x1000000143C8B1C0);
            // 0x00BB6D50: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB6D54: LDRB w8, [x20, #0xb3f]     | W8 = (bool)static_value_03733B3F;       
            // 0x00BB6D58: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB6D5C: TBNZ w8, #0, #0xbb6d78     | if (static_value_03733B3F == true) goto label_0;
            // 0x00BB6D60: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x00BB6D64: LDR x8, [x8, #0x970]       | X8 = 0x2B8AB54;                         
            // 0x00BB6D68: LDR w0, [x8]               | W0 = 0x193;                             
            // 0x00BB6D6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x193, ????);      
            // 0x00BB6D70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6D74: STRB w8, [x20, #0xb3f]     | static_value_03733B3F = true;            //  dest_result_addr=57883455
            label_0:
            // 0x00BB6D78: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6D7C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB6D80: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6D84: CBZ x19, #0xbb6dd8         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB6D88: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6D8C: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6D90: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6D94: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6D98: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6D9C: B.LO #0xbb6db4             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6DA0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6DA4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6DA8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6DAC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6DB0: B.EQ #0xbb6ddc             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6DB4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6DB8: ADD x8, sp, #0x10          | X8 = (1152921510039040448 + 16) = 1152921510039040464 (0x1000000143C8B1D0);
            // 0x00BB6DBC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6DC0: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510039028512]
            // 0x00BB6DC4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6DC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6DCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6DD0: ADD x0, sp, #0x10          | X0 = (1152921510039040448 + 16) = 1152921510039040464 (0x1000000143C8B1D0);
            // 0x00BB6DD4: BL #0x299a140              | 
            label_1:
            // 0x00BB6DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143C8B1D0, ????);
            label_3:
            // 0x00BB6DDC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB6DE0: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6DE4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB6DE8: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6DEC: CMP w10, w9                | STATE = COMPARE(X1 + 260, AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6DF0: B.LO #0xbb6e3c             | if (X1 + 260 < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB6DF4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB6DF8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6DFC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6E00: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6E04: B.NE #0xbb6e3c             | if ((X1 + 176 + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB6E08: ADRP x11, #0x3673000       | X11 = 57094144 (0x3673000);             
            // 0x00BB6E0C: LDP w8, w9, [x19, #0xac]   | W8 = X1 + 172; W9 = X1 + 172 + 4;        //  | 
            // 0x00BB6E10: LDR w10, [x19, #0xb4]      | W10 = X1 + 180;                         
            // 0x00BB6E14: LDR x11, [x11, #0x488]     | X11 = 1152921504695078912;              
            // 0x00BB6E18: MOV x1, sp                 | X1 = 1152921510039040448 (0x1000000143C8B1C0);//ML01
            // 0x00BB6E1C: LDR x0, [x11]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x00BB6E20: STP w8, w9, [sp]           | stack[1152921510039040448] = X1 + 172;  stack[1152921510039040452] = X1 + 172 + 4;  //  dest_result_addr=1152921510039040448 |  dest_result_addr=1152921510039040452
            // 0x00BB6E24: STR w10, [sp, #8]          | stack[1152921510039040456] = X1 + 180;   //  dest_result_addr=1152921510039040456
            // 0x00BB6E28: BL #0x27bc028              | X0 = 1152921510039088528 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), X1 + 172);
            // 0x00BB6E2C: SUB sp, x29, #0x10         | SP = (1152921510039040496 - 16) = 1152921510039040480 (0x1000000143C8B1E0);
            // 0x00BB6E30: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6E34: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6E38: RET                        |  return (System.Object)X1 + 172;        
            return (object)X1 + 172;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB6E3C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB6E40: ADD x8, sp, #0x18          | X8 = (1152921510039040448 + 24) = 1152921510039040472 (0x1000000143C8B1D8);
            // 0x00BB6E44: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB6E48: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510039028512]
            // 0x00BB6E4C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6E50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6E54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6E58: ADD x0, sp, #0x18          | X0 = (1152921510039040448 + 24) = 1152921510039040472 (0x1000000143C8B1D8);
            // 0x00BB6E5C: BL #0x299a140              | 
            // 0x00BB6E60: MOV x19, x0                | X19 = 1152921510039040472 (0x1000000143C8B1D8);//ML01
            // 0x00BB6E64: ADD x0, sp, #0x10          | X0 = (1152921510039040448 + 16) = 1152921510039040464 (0x1000000143C8B1D0);
            label_6:
            // 0x00BB6E68: BL #0x299a140              | 
            // 0x00BB6E6C: MOV x0, x19                | X0 = 1152921510039040472 (0x1000000143C8B1D8);//ML01
            // 0x00BB6E70: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143C8B1D8, ????);
            // 0x00BB6E74: MOV x19, x0                | X19 = 1152921510039040472 (0x1000000143C8B1D8);//ML01
            // 0x00BB6E78: ADD x0, sp, #0x18          | X0 = (1152921510039040448 + 24) = 1152921510039040472 (0x1000000143C8B1D8);
            // 0x00BB6E7C: B #0xbb6e68                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB6E80 (12283520), len: 420  VirtAddr: 0x00BB6E80 RVA: 0x00BB6E80 token: 100663727 methodIndex: 29772 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_targetPoint_14(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB6E80: STP x22, x21, [sp, #-0x30]! | stack[1152921510039168688] = ???;  stack[1152921510039168696] = ???;  //  dest_result_addr=1152921510039168688 |  dest_result_addr=1152921510039168696
            // 0x00BB6E84: STP x20, x19, [sp, #0x10]  | stack[1152921510039168704] = ???;  stack[1152921510039168712] = ???;  //  dest_result_addr=1152921510039168704 |  dest_result_addr=1152921510039168712
            // 0x00BB6E88: STP x29, x30, [sp, #0x20]  | stack[1152921510039168720] = ???;  stack[1152921510039168728] = ???;  //  dest_result_addr=1152921510039168720 |  dest_result_addr=1152921510039168728
            // 0x00BB6E8C: ADD x29, sp, #0x20         | X29 = (1152921510039168688 + 32) = 1152921510039168720 (0x1000000143CAA6D0);
            // 0x00BB6E90: SUB sp, sp, #0x20          | SP = (1152921510039168688 - 32) = 1152921510039168656 (0x1000000143CAA690);
            // 0x00BB6E94: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB6E98: LDRB w8, [x21, #0xb40]     | W8 = (bool)static_value_03733B40;       
            // 0x00BB6E9C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB6EA0: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB6EA4: TBNZ w8, #0, #0xbb6ec0     | if (static_value_03733B40 == true) goto label_0;
            // 0x00BB6EA8: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x00BB6EAC: LDR x8, [x8, #0x10]        | X8 = 0x2B8ABB0;                         
            // 0x00BB6EB0: LDR w0, [x8]               | W0 = 0x1AA;                             
            // 0x00BB6EB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1AA, ????);      
            // 0x00BB6EB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB6EBC: STRB w8, [x21, #0xb40]     | static_value_03733B40 = true;            //  dest_result_addr=57883456
            label_0:
            // 0x00BB6EC0: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB6EC4: CBZ x21, #0xbb6f78         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB6EC8: ADRP x20, #0x364f000       | X20 = 56946688 (0x364F000);             
            // 0x00BB6ECC: LDR x20, [x20, #0xf50]     | X20 = 1152921504835227648;              
            // 0x00BB6ED0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB6ED4: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6ED8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6EDC: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6EE0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6EE4: B.LO #0xbb6efc             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB6EE8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6EEC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6EF0: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6EF4: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6EF8: B.EQ #0xbb6f24             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB6EFC: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB6F00: ADD x8, sp, #8             | X8 = (1152921510039168656 + 8) = 1152921510039168664 (0x1000000143CAA698);
            // 0x00BB6F04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6F08: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510039156736]
            // 0x00BB6F0C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB6F10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6F14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB6F18: ADD x0, sp, #8             | X0 = (1152921510039168656 + 8) = 1152921510039168664 (0x1000000143CAA698);
            // 0x00BB6F1C: BL #0x299a140              | 
            // 0x00BB6F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143CAA698, ????);
            label_3:
            // 0x00BB6F24: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB6F28: LDR x1, [x20]              | X1 = typeof(AIPath);                    
            // 0x00BB6F2C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB6F30: LDRB w9, [x1, #0x104]      | W9 = AIPath.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB6F34: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AIPath.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB6F38: B.LO #0xbb6f50             | if (mem[null + 260] < AIPath.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB6F3C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB6F40: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB6F44: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB6F48: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AIPath))
            // 0x00BB6F4C: B.EQ #0xbb6f80             | if ((mem[null + 176] + (AIPath.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB6F50: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB6F54: ADD x8, sp, #0x10          | X8 = (1152921510039168656 + 16) = 1152921510039168672 (0x1000000143CAA6A0);
            // 0x00BB6F58: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB6F5C: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510039156736]
            // 0x00BB6F60: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB6F64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB6F68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB6F6C: ADD x0, sp, #0x10          | X0 = (1152921510039168656 + 16) = 1152921510039168672 (0x1000000143CAA6A0);
            // 0x00BB6F70: BL #0x299a140              | 
            // 0x00BB6F74: B #0xbb6f7c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB6F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AA, ????);      
            label_6:
            // 0x00BB6F7C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB6F80: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00BB6F84: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00BB6F88: LDR x20, [x8]              | X20 = typeof(UnityEngine.Vector3);      
            // 0x00BB6F8C: CBNZ x19, #0xbb6f94        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB6F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1AA, ????);      
            label_7:
            // 0x00BB6F94: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB6F98: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB6F9C: LDR x8, [x20, #0x30]       | X8 = UnityEngine.Vector3.__il2cppRuntimeField_element_class;
            // 0x00BB6FA0: CMP x0, x8                 | STATE = COMPARE(X2 + 48, UnityEngine.Vector3.__il2cppRuntimeField_element_class)
            // 0x00BB6FA4: B.NE #0xbb6ff4             | if (X2 + 48 != UnityEngine.Vector3.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB6FA8: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB6FAC: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB6FB0: LDR x8, [x0]               | X8 = X2;                                
            // 0x00BB6FB4: LDR w9, [x0, #8]           | W9 = X2 + 8;                            
            // 0x00BB6FB8: STUR x8, [x21, #0xac]      | mem[172] = X2;                           //  dest_result_addr=172
            mem[172] = X2;
            // 0x00BB6FBC: STR w9, [x21, #0xb4]       | mem[180] = X2 + 8;                       //  dest_result_addr=180
            mem[180] = X2 + 8;
            // 0x00BB6FC0: SUB sp, x29, #0x20         | SP = (1152921510039168720 - 32) = 1152921510039168688 (0x1000000143CAA6B0);
            // 0x00BB6FC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB6FC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB6FCC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB6FD0: RET                        |  return;                                
            return;
            // 0x00BB6FD4: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB6FD8: ADD x0, sp, #8             | X0 = (1152921510039168736 + 8) = 1152921510039168744 (0x1000000143CAA6E8);
            // 0x00BB6FDC: B #0xbb6fe8                |  goto label_10;                         
            goto label_10;
            // 0x00BB6FE0: MOV x19, x0                | X19 = 1152921510039168744 (0x1000000143CAA6E8);//ML01
            val_7;
            // 0x00BB6FE4: ADD x0, sp, #0x10          | X0 = (1152921510039168736 + 16) = 1152921510039168752 (0x1000000143CAA6F0);
            label_10:
            // 0x00BB6FE8: BL #0x299a140              | 
            // 0x00BB6FEC: MOV x0, x19                | X0 = 1152921510039168744 (0x1000000143CAA6E8);//ML01
            // 0x00BB6FF0: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143CAA6E8, ????);
            label_8:
            // 0x00BB6FF4: ADD x8, sp, #0x18          | X8 = (1152921510039168736 + 24) = 1152921510039168760 (0x1000000143CAA6F8);
            // 0x00BB6FF8: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB6FFC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143CAA6E8, ????);
            // 0x00BB7000: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510039156736]
            // 0x00BB7004: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB7008: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB700C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB7010: ADD x0, sp, #0x18          | X0 = (1152921510039168736 + 24) = 1152921510039168760 (0x1000000143CAA6F8);
            // 0x00BB7014: BL #0x299a140              | 
            // 0x00BB7018: MOV x19, x0                | X19 = 1152921510039168760 (0x1000000143CAA6F8);//ML01
            // 0x00BB701C: ADD x0, sp, #0x18          | X0 = (1152921510039168736 + 24) = 1152921510039168760 (0x1000000143CAA6F8);
            // 0x00BB7020: B #0xbb6fe8                |  goto label_10;                         
            goto label_10;
        
        }
    
    }

}
