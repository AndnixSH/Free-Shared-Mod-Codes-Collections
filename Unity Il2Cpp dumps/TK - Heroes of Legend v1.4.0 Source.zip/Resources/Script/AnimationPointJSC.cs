using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286AE7C
[Serializable]
public class AnimationPointJSC : IExtensible
{
    // Fields
    private string _aniType; //  0x00000010
    private float _aniTime; //  0x00000018
    private float _px; //  0x0000001C
    private float _py; //  0x00000020
    private float _pz; //  0x00000024
    private float _rx; //  0x00000028
    private float _ry; //  0x0000002C
    private float _rz; //  0x00000030
    private float _delay; //  0x00000034
    private float _time; //  0x00000038
    private string _fun; //  0x00000040
    private float _vx; //  0x00000048
    private float _vy; //  0x0000004C
    private float _vz; //  0x00000050
    private float _vibrationTime; //  0x00000054
    private float _vibrationDelay; //  0x00000058
    private ProtoBuf.IExtension extensionObject; //  0x00000060
    
    // Properties
    public UnityEngine.Vector3 Pos { get; }
    public UnityEngine.Vector3 Rot { get; }
    public UnityEngine.Vector3 VibrationV3 { get; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AEC0
    [System.ComponentModel.DefaultValueAttribute] // 0x286AEC0
    public string aniType { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AF50
    [System.ComponentModel.DefaultValueAttribute] // 0x286AF50
    public float aniTime { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286AFD0
    [System.ComponentModel.DefaultValueAttribute] // 0x286AFD0
    public float px { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B050
    [System.ComponentModel.DefaultValueAttribute] // 0x286B050
    public float py { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B0D0
    [System.ComponentModel.DefaultValueAttribute] // 0x286B0D0
    public float pz { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B150
    [System.ComponentModel.DefaultValueAttribute] // 0x286B150
    public float rx { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B1D0
    [System.ComponentModel.DefaultValueAttribute] // 0x286B1D0
    public float ry { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B250
    [System.ComponentModel.DefaultValueAttribute] // 0x286B250
    public float rz { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B2D0
    [System.ComponentModel.DefaultValueAttribute] // 0x286B2D0
    public float delay { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B350
    [System.ComponentModel.DefaultValueAttribute] // 0x286B350
    public float time { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B3D0
    [System.ComponentModel.DefaultValueAttribute] // 0x286B3D0
    public string fun { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B460
    [System.ComponentModel.DefaultValueAttribute] // 0x286B460
    public float vx { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B4E0
    [System.ComponentModel.DefaultValueAttribute] // 0x286B4E0
    public float vy { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B560
    [System.ComponentModel.DefaultValueAttribute] // 0x286B560
    public float vz { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B5E0
    [System.ComponentModel.DefaultValueAttribute] // 0x286B5E0
    public float vibrationTime { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286B660
    [System.ComponentModel.DefaultValueAttribute] // 0x286B660
    public float vibrationDelay { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B27A54 (11696724), len: 136  VirtAddr: 0x00B27A54 RVA: 0x00B27A54 token: 100690145 methodIndex: 24790 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimationPointJSC()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00B27A54: STP x20, x19, [sp, #-0x20]! | stack[1152921514478218304] = ???;  stack[1152921514478218312] = ???;  //  dest_result_addr=1152921514478218304 |  dest_result_addr=1152921514478218312
        // 0x00B27A58: STP x29, x30, [sp, #0x10]  | stack[1152921514478218320] = ???;  stack[1152921514478218328] = ???;  //  dest_result_addr=1152921514478218320 |  dest_result_addr=1152921514478218328
        // 0x00B27A5C: ADD x29, sp, #0x10         | X29 = (1152921514478218304 + 16) = 1152921514478218320 (0x100000024C612C50);
        // 0x00B27A60: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B27A64: LDRB w8, [x20, #0x74f]     | W8 = (bool)static_value_0373374F;       
        // 0x00B27A68: MOV x19, x0                | X19 = 1152921514478230336 (0x100000024C615B40);//ML01
        // 0x00B27A6C: TBNZ w8, #0, #0xb27a88     | if (static_value_0373374F == true) goto label_0;
        // 0x00B27A70: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B27A74: LDR x8, [x8, #0x448]       | X8 = 0x2B8AE10;                         
        // 0x00B27A78: LDR w0, [x8]               | W0 = 0x242;                             
        // 0x00B27A7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x242, ????);      
        // 0x00B27A80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27A84: STRB w8, [x20, #0x74f]     | static_value_0373374F = true;            //  dest_result_addr=57882447
        label_0:
        // 0x00B27A88: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00B27A8C: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00B27A90: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_1 = null;
        // 0x00B27A94: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B27A98: TBZ w8, #0, #0xb27aac      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B27A9C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B27AA0: CBNZ w8, #0xb27aac         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B27AA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B27AA8: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_1 = null;
        label_2:
        // 0x00B27AAC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B27AB0: MOV x0, x19                | X0 = 1152921514478230336 (0x100000024C615B40);//ML01
        // 0x00B27AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27AB8: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00B27ABC: STR x8, [x19, #0x10]       | this._aniType = System.String.Empty;     //  dest_result_addr=1152921514478230352
        this._aniType = System.String.Empty;
        // 0x00B27AC0: LDR x8, [x20]              | X8 = typeof(System.String);             
        // 0x00B27AC4: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B27AC8: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00B27ACC: STR x8, [x19, #0x40]       | this._fun = System.String.Empty;         //  dest_result_addr=1152921514478230400
        this._fun = System.String.Empty;
        // 0x00B27AD0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27AD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B27AD8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27ADC (11696860), len: 60  VirtAddr: 0x00B27ADC RVA: 0x00B27ADC token: 100690146 methodIndex: 24791 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 get_Pos()
    {
        //
        // Disasemble & Code
        // 0x00B27ADC: STP x29, x30, [sp, #-0x10]! | stack[1152921514478330320] = ???;  stack[1152921514478330328] = ???;  //  dest_result_addr=1152921514478330320 |  dest_result_addr=1152921514478330328
        // 0x00B27AE0: MOV x29, sp                | X29 = 1152921514478330320 (0x100000024C62E1D0);//ML01
        // 0x00B27AE4: SUB sp, sp, #0x10          | SP = (1152921514478330320 - 16) = 1152921514478330304 (0x100000024C62E1C0);
        // 0x00B27AE8: LDP s0, s1, [x0, #0x1c]    | S0 = this._px; //P2  S1 = this._py; //P2  //  | 
        // 0x00B27AEC: LDR s2, [x0, #0x24]        | S2 = this._pz; //P2                     
        // 0x00B27AF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27AF4: MOV x0, sp                 | X0 = 1152921514478330304 (0x100000024C62E1C0);//ML01
        // 0x00B27AF8: STR wzr, [sp, #8]          | stack[1152921514478330312] = 0x0;        //  dest_result_addr=1152921514478330312
        // 0x00B27AFC: STR xzr, [sp]              | stack[1152921514478330304] = 0x0;        //  dest_result_addr=1152921514478330304
        // 0x00B27B00: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B27B04: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B27B08: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00B27B0C: MOV sp, x29                | SP = 1152921514478330320 (0x100000024C62E1D0);//ML01
        // 0x00B27B10: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00B27B14: RET                        |  return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B30 (11696944), len: 60  VirtAddr: 0x00B27B30 RVA: 0x00B27B30 token: 100690147 methodIndex: 24792 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 get_Rot()
    {
        //
        // Disasemble & Code
        // 0x00B27B30: STP x29, x30, [sp, #-0x10]! | stack[1152921514478442320] = ???;  stack[1152921514478442328] = ???;  //  dest_result_addr=1152921514478442320 |  dest_result_addr=1152921514478442328
        // 0x00B27B34: MOV x29, sp                | X29 = 1152921514478442320 (0x100000024C649750);//ML01
        // 0x00B27B38: SUB sp, sp, #0x10          | SP = (1152921514478442320 - 16) = 1152921514478442304 (0x100000024C649740);
        // 0x00B27B3C: LDP s0, s1, [x0, #0x28]    | S0 = this._rx; //P2  S1 = this._ry; //P2  //  | 
        // 0x00B27B40: LDR s2, [x0, #0x30]        | S2 = this._rz; //P2                     
        // 0x00B27B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27B48: MOV x0, sp                 | X0 = 1152921514478442304 (0x100000024C649740);//ML01
        // 0x00B27B4C: STR wzr, [sp, #8]          | stack[1152921514478442312] = 0x0;        //  dest_result_addr=1152921514478442312
        // 0x00B27B50: STR xzr, [sp]              | stack[1152921514478442304] = 0x0;        //  dest_result_addr=1152921514478442304
        // 0x00B27B54: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B27B58: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B27B5C: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00B27B60: MOV sp, x29                | SP = 1152921514478442320 (0x100000024C649750);//ML01
        // 0x00B27B64: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00B27B68: RET                        |  return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B84 (11697028), len: 60  VirtAddr: 0x00B27B84 RVA: 0x00B27B84 token: 100690148 methodIndex: 24793 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3 get_VibrationV3()
    {
        //
        // Disasemble & Code
        // 0x00B27B84: STP x29, x30, [sp, #-0x10]! | stack[1152921514478554320] = ???;  stack[1152921514478554328] = ???;  //  dest_result_addr=1152921514478554320 |  dest_result_addr=1152921514478554328
        // 0x00B27B88: MOV x29, sp                | X29 = 1152921514478554320 (0x100000024C664CD0);//ML01
        // 0x00B27B8C: SUB sp, sp, #0x10          | SP = (1152921514478554320 - 16) = 1152921514478554304 (0x100000024C664CC0);
        // 0x00B27B90: LDP s0, s1, [x0, #0x48]    | S0 = this._vx; //P2  S1 = this._vy; //P2  //  | 
        // 0x00B27B94: LDR s2, [x0, #0x50]        | S2 = this._vz; //P2                     
        // 0x00B27B98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27B9C: MOV x0, sp                 | X0 = 1152921514478554304 (0x100000024C664CC0);//ML01
        // 0x00B27BA0: STR wzr, [sp, #8]          | stack[1152921514478554312] = 0x0;        //  dest_result_addr=1152921514478554312
        // 0x00B27BA4: STR xzr, [sp]              | stack[1152921514478554304] = 0x0;        //  dest_result_addr=1152921514478554304
        // 0x00B27BA8: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B27BAC: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B27BB0: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x00B27BB4: MOV sp, x29                | SP = 1152921514478554320 (0x100000024C664CD0);//ML01
        // 0x00B27BB8: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00B27BBC: RET                        |  return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        return new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BD8 (11697112), len: 8  VirtAddr: 0x00B27BD8 RVA: 0x00B27BD8 token: 100690149 methodIndex: 24794 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_aniType()
    {
        //
        // Disasemble & Code
        // 0x00B27BD8: LDR x0, [x0, #0x10]        | X0 = this._aniType; //P2                
        // 0x00B27BDC: RET                        |  return (System.String)this._aniType;   
        return this._aniType;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BE0 (11697120), len: 8  VirtAddr: 0x00B27BE0 RVA: 0x00B27BE0 token: 100690150 methodIndex: 24795 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_aniType(string value)
    {
        //
        // Disasemble & Code
        // 0x00B27BE0: STR x1, [x0, #0x10]        | this._aniType = value;                   //  dest_result_addr=1152921514478802640
        this._aniType = value;
        // 0x00B27BE4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BE8 (11697128), len: 8  VirtAddr: 0x00B27BE8 RVA: 0x00B27BE8 token: 100690151 methodIndex: 24796 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_aniTime()
    {
        //
        // Disasemble & Code
        // 0x00B27BE8: LDR s0, [x0, #0x18]        | S0 = this._aniTime; //P2                
        // 0x00B27BEC: RET                        |  return (System.Single)this._aniTime;   
        return this._aniTime;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BF0 (11697136), len: 8  VirtAddr: 0x00B27BF0 RVA: 0x00B27BF0 token: 100690152 methodIndex: 24797 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_aniTime(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27BF0: STR s0, [x0, #0x18]        | this._aniTime = value;                   //  dest_result_addr=1152921514479030744
        this._aniTime = value;
        // 0x00B27BF4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B18 (11696920), len: 8  VirtAddr: 0x00B27B18 RVA: 0x00B27B18 token: 100690153 methodIndex: 24798 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_px()
    {
        //
        // Disasemble & Code
        // 0x00B27B18: LDR s0, [x0, #0x1c]        | S0 = this._px; //P2                     
        // 0x00B27B1C: RET                        |  return (System.Single)this._px;        
        return this._px;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BF8 (11697144), len: 8  VirtAddr: 0x00B27BF8 RVA: 0x00B27BF8 token: 100690154 methodIndex: 24799 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_px(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27BF8: STR s0, [x0, #0x1c]        | this._px = value;                        //  dest_result_addr=1152921514479254748
        this._px = value;
        // 0x00B27BFC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B20 (11696928), len: 8  VirtAddr: 0x00B27B20 RVA: 0x00B27B20 token: 100690155 methodIndex: 24800 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_py()
    {
        //
        // Disasemble & Code
        // 0x00B27B20: LDR s0, [x0, #0x20]        | S0 = this._py; //P2                     
        // 0x00B27B24: RET                        |  return (System.Single)this._py;        
        return this._py;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C00 (11697152), len: 8  VirtAddr: 0x00B27C00 RVA: 0x00B27C00 token: 100690156 methodIndex: 24801 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_py(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C00: STR s0, [x0, #0x20]        | this._py = value;                        //  dest_result_addr=1152921514479478752
        this._py = value;
        // 0x00B27C04: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B28 (11696936), len: 8  VirtAddr: 0x00B27B28 RVA: 0x00B27B28 token: 100690157 methodIndex: 24802 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_pz()
    {
        //
        // Disasemble & Code
        // 0x00B27B28: LDR s0, [x0, #0x24]        | S0 = this._pz; //P2                     
        // 0x00B27B2C: RET                        |  return (System.Single)this._pz;        
        return this._pz;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C08 (11697160), len: 8  VirtAddr: 0x00B27C08 RVA: 0x00B27C08 token: 100690158 methodIndex: 24803 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_pz(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C08: STR s0, [x0, #0x24]        | this._pz = value;                        //  dest_result_addr=1152921514479702756
        this._pz = value;
        // 0x00B27C0C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B6C (11697004), len: 8  VirtAddr: 0x00B27B6C RVA: 0x00B27B6C token: 100690159 methodIndex: 24804 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_rx()
    {
        //
        // Disasemble & Code
        // 0x00B27B6C: LDR s0, [x0, #0x28]        | S0 = this._rx; //P2                     
        // 0x00B27B70: RET                        |  return (System.Single)this._rx;        
        return this._rx;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C10 (11697168), len: 8  VirtAddr: 0x00B27C10 RVA: 0x00B27C10 token: 100690160 methodIndex: 24805 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_rx(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C10: STR s0, [x0, #0x28]        | this._rx = value;                        //  dest_result_addr=1152921514479926760
        this._rx = value;
        // 0x00B27C14: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B74 (11697012), len: 8  VirtAddr: 0x00B27B74 RVA: 0x00B27B74 token: 100690161 methodIndex: 24806 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_ry()
    {
        //
        // Disasemble & Code
        // 0x00B27B74: LDR s0, [x0, #0x2c]        | S0 = this._ry; //P2                     
        // 0x00B27B78: RET                        |  return (System.Single)this._ry;        
        return this._ry;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C18 (11697176), len: 8  VirtAddr: 0x00B27C18 RVA: 0x00B27C18 token: 100690162 methodIndex: 24807 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_ry(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C18: STR s0, [x0, #0x2c]        | this._ry = value;                        //  dest_result_addr=1152921514480150764
        this._ry = value;
        // 0x00B27C1C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27B7C (11697020), len: 8  VirtAddr: 0x00B27B7C RVA: 0x00B27B7C token: 100690163 methodIndex: 24808 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_rz()
    {
        //
        // Disasemble & Code
        // 0x00B27B7C: LDR s0, [x0, #0x30]        | S0 = this._rz; //P2                     
        // 0x00B27B80: RET                        |  return (System.Single)this._rz;        
        return this._rz;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C20 (11697184), len: 8  VirtAddr: 0x00B27C20 RVA: 0x00B27C20 token: 100690164 methodIndex: 24809 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_rz(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C20: STR s0, [x0, #0x30]        | this._rz = value;                        //  dest_result_addr=1152921514480374768
        this._rz = value;
        // 0x00B27C24: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C28 (11697192), len: 8  VirtAddr: 0x00B27C28 RVA: 0x00B27C28 token: 100690165 methodIndex: 24810 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_delay()
    {
        //
        // Disasemble & Code
        // 0x00B27C28: LDR s0, [x0, #0x34]        | S0 = this._delay; //P2                  
        // 0x00B27C2C: RET                        |  return (System.Single)this._delay;     
        return this._delay;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C30 (11697200), len: 8  VirtAddr: 0x00B27C30 RVA: 0x00B27C30 token: 100690166 methodIndex: 24811 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_delay(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C30: STR s0, [x0, #0x34]        | this._delay = value;                     //  dest_result_addr=1152921514480598772
        this._delay = value;
        // 0x00B27C34: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C38 (11697208), len: 8  VirtAddr: 0x00B27C38 RVA: 0x00B27C38 token: 100690167 methodIndex: 24812 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_time()
    {
        //
        // Disasemble & Code
        // 0x00B27C38: LDR s0, [x0, #0x38]        | S0 = this._time; //P2                   
        // 0x00B27C3C: RET                        |  return (System.Single)this._time;      
        return this._time;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C40 (11697216), len: 8  VirtAddr: 0x00B27C40 RVA: 0x00B27C40 token: 100690168 methodIndex: 24813 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_time(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C40: STR s0, [x0, #0x38]        | this._time = value;                      //  dest_result_addr=1152921514480822776
        this._time = value;
        // 0x00B27C44: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C48 (11697224), len: 8  VirtAddr: 0x00B27C48 RVA: 0x00B27C48 token: 100690169 methodIndex: 24814 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_fun()
    {
        //
        // Disasemble & Code
        // 0x00B27C48: LDR x0, [x0, #0x40]        | X0 = this._fun; //P2                    
        // 0x00B27C4C: RET                        |  return (System.String)this._fun;       
        return this._fun;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C50 (11697232), len: 8  VirtAddr: 0x00B27C50 RVA: 0x00B27C50 token: 100690170 methodIndex: 24815 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_fun(string value)
    {
        //
        // Disasemble & Code
        // 0x00B27C50: STR x1, [x0, #0x40]        | this._fun = value;                       //  dest_result_addr=1152921514481059072
        this._fun = value;
        // 0x00B27C54: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BC0 (11697088), len: 8  VirtAddr: 0x00B27BC0 RVA: 0x00B27BC0 token: 100690171 methodIndex: 24816 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_vx()
    {
        //
        // Disasemble & Code
        // 0x00B27BC0: LDR s0, [x0, #0x48]        | S0 = this._vx; //P2                     
        // 0x00B27BC4: RET                        |  return (System.Single)this._vx;        
        return this._vx;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C58 (11697240), len: 8  VirtAddr: 0x00B27C58 RVA: 0x00B27C58 token: 100690172 methodIndex: 24817 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_vx(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C58: STR s0, [x0, #0x48]        | this._vx = value;                        //  dest_result_addr=1152921514481287176
        this._vx = value;
        // 0x00B27C5C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BC8 (11697096), len: 8  VirtAddr: 0x00B27BC8 RVA: 0x00B27BC8 token: 100690173 methodIndex: 24818 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_vy()
    {
        //
        // Disasemble & Code
        // 0x00B27BC8: LDR s0, [x0, #0x4c]        | S0 = this._vy; //P2                     
        // 0x00B27BCC: RET                        |  return (System.Single)this._vy;        
        return this._vy;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C60 (11697248), len: 8  VirtAddr: 0x00B27C60 RVA: 0x00B27C60 token: 100690174 methodIndex: 24819 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_vy(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C60: STR s0, [x0, #0x4c]        | this._vy = value;                        //  dest_result_addr=1152921514481511180
        this._vy = value;
        // 0x00B27C64: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27BD0 (11697104), len: 8  VirtAddr: 0x00B27BD0 RVA: 0x00B27BD0 token: 100690175 methodIndex: 24820 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_vz()
    {
        //
        // Disasemble & Code
        // 0x00B27BD0: LDR s0, [x0, #0x50]        | S0 = this._vz; //P2                     
        // 0x00B27BD4: RET                        |  return (System.Single)this._vz;        
        return this._vz;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C68 (11697256), len: 8  VirtAddr: 0x00B27C68 RVA: 0x00B27C68 token: 100690176 methodIndex: 24821 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_vz(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C68: STR s0, [x0, #0x50]        | this._vz = value;                        //  dest_result_addr=1152921514481735184
        this._vz = value;
        // 0x00B27C6C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C70 (11697264), len: 8  VirtAddr: 0x00B27C70 RVA: 0x00B27C70 token: 100690177 methodIndex: 24822 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_vibrationTime()
    {
        //
        // Disasemble & Code
        // 0x00B27C70: LDR s0, [x0, #0x54]        | S0 = this._vibrationTime; //P2          
        // 0x00B27C74: RET                        |  return (System.Single)this._vibrationTime;
        return this._vibrationTime;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C78 (11697272), len: 8  VirtAddr: 0x00B27C78 RVA: 0x00B27C78 token: 100690178 methodIndex: 24823 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_vibrationTime(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C78: STR s0, [x0, #0x54]        | this._vibrationTime = value;             //  dest_result_addr=1152921514481959188
        this._vibrationTime = value;
        // 0x00B27C7C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C80 (11697280), len: 8  VirtAddr: 0x00B27C80 RVA: 0x00B27C80 token: 100690179 methodIndex: 24824 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_vibrationDelay()
    {
        //
        // Disasemble & Code
        // 0x00B27C80: LDR s0, [x0, #0x58]        | S0 = this._vibrationDelay; //P2         
        // 0x00B27C84: RET                        |  return (System.Single)this._vibrationDelay;
        return this._vibrationDelay;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C88 (11697288), len: 8  VirtAddr: 0x00B27C88 RVA: 0x00B27C88 token: 100690180 methodIndex: 24825 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_vibrationDelay(float value)
    {
        //
        // Disasemble & Code
        // 0x00B27C88: STR s0, [x0, #0x58]        | this._vibrationDelay = value;            //  dest_result_addr=1152921514482183192
        this._vibrationDelay = value;
        // 0x00B27C8C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27C90 (11697296), len: 24  VirtAddr: 0x00B27C90 RVA: 0x00B27C90 token: 100690181 methodIndex: 24826 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00B27C90: ADD x8, x0, #0x60          | X8 = this.extensionObject;//AP2 res_addr=1152921514482295200
        // 0x00B27C94: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00B27C98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00B27C9C: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00B27CA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27CA4: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
