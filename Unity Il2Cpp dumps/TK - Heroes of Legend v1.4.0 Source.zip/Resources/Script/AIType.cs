using UnityEngine;
public enum AIType
{
    // Fields
    AT_limit = 1
    ,AT_free = 2
    

}
