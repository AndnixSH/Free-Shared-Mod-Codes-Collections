using UnityEngine;

namespace ILRuntime.Runtime.CLRBinding
{
    [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857200
    internal static class BindingGeneratorExtensions
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x011083D8 (17859544), len: 248  VirtAddr: 0x011083D8 RVA: 0x011083D8 token: 100679919 methodIndex: 29206 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857210
        internal static bool ShouldSkipField(System.Type type, System.Reflection.FieldInfo i)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x011083D8: STP x20, x19, [sp, #-0x20]! | stack[1152921512829832448] = ???;  stack[1152921512829832456] = ???;  //  dest_result_addr=1152921512829832448 |  dest_result_addr=1152921512829832456
            // 0x011083DC: STP x29, x30, [sp, #0x10]  | stack[1152921512829832464] = ???;  stack[1152921512829832472] = ???;  //  dest_result_addr=1152921512829832464 |  dest_result_addr=1152921512829832472
            // 0x011083E0: ADD x29, sp, #0x10         | X29 = (1152921512829832448 + 16) = 1152921512829832464 (0x10000001EA20CD10);
            // 0x011083E4: ADRP x20, #0x3735000       | X20 = 57888768 (0x3735000);             
            // 0x011083E8: LDRB w8, [x20, #0xb95]     | W8 = (bool)static_value_03735B95;       
            // 0x011083EC: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x011083F0: TBNZ w8, #0, #0x110840c    | if (static_value_03735B95 == true) goto label_0;
            // 0x011083F4: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x011083F8: LDR x8, [x8, #0x20]        | X8 = 0x2B8F55C;                         
            // 0x011083FC: LDR w0, [x8]               | W0 = 0x1419;                            
            // 0x01108400: BL #0x2782188              | X0 = sub_2782188( ?? 0x1419, ????);     
            // 0x01108404: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01108408: STRB w8, [x20, #0xb95]     | static_value_03735B95 = true;            //  dest_result_addr=57891733
            label_0:
            // 0x0110840C: CBNZ x19, #0x1108414       | if (X2 != 0) goto label_1;              
            if(val_7 != 0)
            {
                goto label_1;
            }
            // 0x01108410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1419, ????);     
            label_1:
            // 0x01108414: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108418: MOV x0, x19                | X0 = X2;//m1                            
            // 0x0110841C: BL #0x13bcff8              | X0 = X2.get_IsPrivate();                
            bool val_1 = val_7.IsPrivate;
            // 0x01108420: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x01108424: TBNZ w8, #0, #0x1108444    | if ((val_1 & 1) == true) goto label_2;  
            if(val_2 == true)
            {
                goto label_2;
            }
            // 0x01108428: CBNZ x19, #0x1108430       | if (X2 != 0) goto label_3;              
            if(val_7 != 0)
            {
                goto label_3;
            }
            // 0x0110842C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x01108430: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108434: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108438: BL #0x13bd048              | X0 = X2.get_IsSpecialName();            
            bool val_3 = val_7.IsSpecialName;
            // 0x0110843C: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x01108440: TBZ w8, #0, #0x110844c     | if ((val_3 & 1) == false) goto label_4; 
            if(val_4 == false)
            {
                goto label_4;
            }
            label_2:
            // 0x01108444: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_8 = 1;
            // 0x01108448: B #0x11084c4               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x0110844C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01108450: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01108454: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x01108458: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x0110845C: LDR x8, [x8, #0xa28]       | X8 = 1152921504610201600;               
            // 0x01108460: LDR x20, [x8]              | X20 = typeof(System.ObsoleteAttribute); 
            // 0x01108464: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01108468: TBZ w8, #0, #0x1108478     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0110846C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01108470: CBNZ w8, #0x1108478        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01108474: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x01108478: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110847C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108480: MOV x1, x20                | X1 = 1152921504610201600 (0x1000000000333000);//ML01
            // 0x01108484: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01108488: MOV x20, x0                | X20 = val_5;//m1                        
            // 0x0110848C: CBNZ x19, #0x1108494       | if (X2 != 0) goto label_8;              
            if(val_7 != 0)
            {
                goto label_8;
            }
            // 0x01108490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_8:
            // 0x01108494: LDR x8, [x19]              | X8 = X2;                                
            // 0x01108498: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0110849C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x011084A0: MOV x1, x20                | X1 = val_5;//m1                         
            // 0x011084A4: LDP x9, x3, [x8, #0x1e0]   | X9 = X2 + 480; X3 = X2 + 480 + 8;        //  | 
            // 0x011084A8: BLR x9                     | X0 = X2 + 480();                        
            // 0x011084AC: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = val_7;
            // 0x011084B0: CBNZ x19, #0x11084b8       | if (X2 != 0) goto label_9;              
            if(val_7 != 0)
            {
                goto label_9;
            }
            // 0x011084B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_9:
            // 0x011084B8: LDR w8, [x19, #0x18]       | W8 = X2 + 24;                           
            // 0x011084BC: CMP w8, #0                 | STATE = COMPARE(X2 + 24, 0x0)           
            // 0x011084C0: CSET w0, gt                | W0 = X2 + 24 > 0x0 ? 1 : 0;             
            var val_6 = ((X2 + 24) > 0) ? 1 : 0;
            label_5:
            // 0x011084C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011084C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011084CC: RET                        |  return (System.Boolean)X2 + 24 > 0x0 ? 1 : 0;
            return (bool)val_6;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x011084D0 (17859792), len: 2080  VirtAddr: 0x011084D0 RVA: 0x011084D0 token: 100679920 methodIndex: 29207 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857220
        internal static bool ShouldSkipMethod(System.Type type, System.Reflection.MethodBase i)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_12;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            string val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            // 0x011084D0: STP x28, x27, [sp, #-0x60]! | stack[1152921512830047104] = ???;  stack[1152921512830047112] = ???;  //  dest_result_addr=1152921512830047104 |  dest_result_addr=1152921512830047112
            // 0x011084D4: STP x26, x25, [sp, #0x10]  | stack[1152921512830047120] = ???;  stack[1152921512830047128] = ???;  //  dest_result_addr=1152921512830047120 |  dest_result_addr=1152921512830047128
            // 0x011084D8: STP x24, x23, [sp, #0x20]  | stack[1152921512830047136] = ???;  stack[1152921512830047144] = ???;  //  dest_result_addr=1152921512830047136 |  dest_result_addr=1152921512830047144
            // 0x011084DC: STP x22, x21, [sp, #0x30]  | stack[1152921512830047152] = ???;  stack[1152921512830047160] = ???;  //  dest_result_addr=1152921512830047152 |  dest_result_addr=1152921512830047160
            // 0x011084E0: STP x20, x19, [sp, #0x40]  | stack[1152921512830047168] = ???;  stack[1152921512830047176] = ???;  //  dest_result_addr=1152921512830047168 |  dest_result_addr=1152921512830047176
            // 0x011084E4: STP x29, x30, [sp, #0x50]  | stack[1152921512830047184] = ???;  stack[1152921512830047192] = ???;  //  dest_result_addr=1152921512830047184 |  dest_result_addr=1152921512830047192
            // 0x011084E8: ADD x29, sp, #0x50         | X29 = (1152921512830047104 + 80) = 1152921512830047184 (0x10000001EA2413D0);
            // 0x011084EC: SUB sp, sp, #0x10          | SP = (1152921512830047104 - 16) = 1152921512830047088 (0x10000001EA241370);
            // 0x011084F0: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x011084F4: LDRB w8, [x21, #0xb96]     | W8 = (bool)static_value_03735B96;       
            // 0x011084F8: MOV x19, x2                | X19 = X2;//m1                           
            val_35 = X2;
            // 0x011084FC: MOV x20, x1                | X20 = i;//m1                            
            // 0x01108500: TBNZ w8, #0, #0x110851c    | if (static_value_03735B96 == true) goto label_0;
            // 0x01108504: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x01108508: LDR x8, [x8, #0x680]       | X8 = 0x2B8F560;                         
            // 0x0110850C: LDR w0, [x8]               | W0 = 0x141A;                            
            // 0x01108510: BL #0x2782188              | X0 = sub_2782188( ?? 0x141A, ????);     
            // 0x01108514: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01108518: STRB w8, [x21, #0xb96]     | static_value_03735B96 = true;            //  dest_result_addr=57891734
            label_0:
            // 0x0110851C: CBNZ x19, #0x1108524       | if (X2 != 0) goto label_1;              
            if(val_35 != 0)
            {
                goto label_1;
            }
            // 0x01108520: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x141A, ????);     
            label_1:
            // 0x01108524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108528: MOV x0, x19                | X0 = X2;//m1                            
            // 0x0110852C: BL #0x13be7c0              | X0 = X2.get_IsPrivate();                
            bool val_1 = val_35.IsPrivate;
            // 0x01108530: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x01108534: TBNZ w8, #0, #0x1108ca4    | if ((val_1 & 1) == true) goto label_82; 
            if(val_2 == true)
            {
                goto label_82;
            }
            // 0x01108538: CBNZ x19, #0x1108540       | if (X2 != 0) goto label_3;              
            if(val_35 != 0)
            {
                goto label_3;
            }
            // 0x0110853C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x01108540: LDR x8, [x19]              | X8 = X2;                                
            // 0x01108544: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108548: LDR x9, [x8, #0x350]       | X9 = X2 + 848;                          
            // 0x0110854C: LDR x1, [x8, #0x358]       | X1 = X2 + 856;                          
            // 0x01108550: BLR x9                     | X0 = X2 + 848();                        
            // 0x01108554: AND w8, w0, #1             | W8 = (X2 & 1);                          
            var val_3 = val_35 & 1;
            // 0x01108558: TBNZ w8, #0, #0x1108ca4    | if (((X2 & 1) & 0x1) != 0) goto label_82;
            if((val_3 & 1) != 0)
            {
                goto label_82;
            }
            // 0x0110855C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108560: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108564: BL #0x13be8b8              | X0 = X2.get_IsConstructor();            
            bool val_4 = val_35.IsConstructor;
            // 0x01108568: TBZ w0, #0, #0x1108588     | if (val_4 == false) goto label_5;       
            if(val_4 == false)
            {
                goto label_5;
            }
            // 0x0110856C: CBNZ x20, #0x1108574       | if (i != null) goto label_6;            
            if(i != null)
            {
                goto label_6;
            }
            // 0x01108570: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x01108574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108578: MOV x0, x20                | X0 = i;//m1                             
            // 0x0110857C: BL #0x1b6d1a8              | X0 = i.get_IsAbstract();                
            bool val_5 = i.IsAbstract;
            // 0x01108580: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x01108584: TBNZ w8, #0, #0x1108ca4    | if ((val_5 & 1) == true) goto label_82; 
            if(val_6 == true)
            {
                goto label_82;
            }
            label_5:
            // 0x01108588: CBZ x19, #0x1108724        | if (X2 == 0) goto label_8;              
            if(val_35 == 0)
            {
                goto label_8;
            }
            // 0x0110858C: ADRP x22, #0x35b8000       | X22 = 56328192 (0x35B8000);             
            // 0x01108590: LDR x22, [x22, #0x408]     | X22 = 1152921504627560448;              
            // 0x01108594: LDR x8, [x19]              | X8 = X2;                                
            val_36 = mem[X2];
            val_36 = val_35;
            // 0x01108598: LDR x1, [x22]              | X1 = typeof(System.Reflection.MethodInfo);
            val_37 = null;
            // 0x0110859C: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            val_38 = mem[X2 + 260];
            val_38 = X2 + 260;
            // 0x011085A0: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x011085A4: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x011085A8: B.LO #0x1108654            | if (val_38 < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x011085AC: LDR x11, [x8, #0xb0]       | X11 = X2 + 176;                         
            // 0x011085B0: ADD x11, x11, x9, lsl #3   | X11 = (X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x011085B4: LDUR x11, [x11, #-8]       | X11 = (X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x011085B8: CMP x11, x1                | STATE = COMPARE((X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.MethodInfo))
            // 0x011085BC: B.NE #0x1108654            | if ((X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != val_37) goto label_10;
            // 0x011085C0: LDR x8, [x19]              | X8 = X2;                                
            // 0x011085C4: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x011085C8: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x011085CC: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x011085D0: B.LO #0x11085ec            | if (X2 + 260 < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x011085D4: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x011085D8: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x011085DC: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x011085E0: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.MethodInfo))
            // 0x011085E4: MOV x0, x19                | X0 = X2;//m1                            
            val_40 = val_35;
            // 0x011085E8: B.EQ #0x1108614            | if ((X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_37) goto label_12;
            label_11:
            // 0x011085EC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x011085F0: MOV x8, sp                 | X8 = 1152921512830047088 (0x10000001EA241370);//ML01
            // 0x011085F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x011085F8: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921512830035200]
            // 0x011085FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x01108600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108604: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x01108608: MOV x0, sp                 | X0 = 1152921512830047088 (0x10000001EA241370);//ML01
            // 0x0110860C: BL #0x299a140              | 
            // 0x01108610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_40 = 0;
            label_12:
            // 0x01108614: LDR x8, [x0]               | X8 = 0x10102464C457F;                   
            // 0x01108618: LDR x9, [x8, #0x380]       | X9 = mem[282584257677567];              
            // 0x0110861C: LDR x1, [x8, #0x388]       | X1 = mem[282584257677575];              
            // 0x01108620: BLR x9                     | X0 = mem[282584257677567]();            
            // 0x01108624: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            val_34 = val_40;
            // 0x01108628: CBNZ x21, #0x1108630       | if (0x0 != 0) goto label_13;            
            if(val_34 != 0)
            {
                goto label_13;
            }
            // 0x0110862C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_13:
            // 0x01108630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108634: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01108638: BL #0x1b6d1dc              | X0 = val_34.get_IsByRef();              
            bool val_9 = val_34.IsByRef;
            // 0x0110863C: AND w8, w0, #1             | W8 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x01108640: TBNZ w8, #0, #0x1108ca4    | if ((val_9 & 1) == true) goto label_82; 
            if(val_10 == true)
            {
                goto label_82;
            }
            // 0x01108644: LDR x8, [x19]              | X8 = X2;                                
            val_36 = mem[X2];
            val_36 = val_35;
            // 0x01108648: LDR x1, [x22]              | X1 = typeof(System.Reflection.MethodInfo);
            val_37 = null;
            // 0x0110864C: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            val_38 = mem[X2 + 260];
            val_38 = X2 + 260;
            // 0x01108650: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            label_10:
            // 0x01108654: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01108658: B.LO #0x1108720            | if (val_38 < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x0110865C: LDR x8, [x8, #0xb0]        | X8 = X2 + 176;                          
            // 0x01108660: ADD x8, x8, w9, uxtw #3    | X8 = (X2 + 176 + System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth);
            // 0x01108664: LDUR x8, [x8, #-8]         | X8 = (X2 + 176 + System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) + -8;
            // 0x01108668: CMP x8, x1                 | STATE = COMPARE((X2 + 176 + System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) + -8, typeof(System.Reflection.MethodInfo))
            // 0x0110866C: B.NE #0x1108720            | if ((X2 + 176 + System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) + -8 != val_37) goto label_16;
            // 0x01108670: LDR x8, [x19]              | X8 = X2;                                
            // 0x01108674: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01108678: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x0110867C: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01108680: B.LO #0x110869c            | if (X2 + 260 < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x01108684: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x01108688: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0110868C: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01108690: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.MethodInfo))
            // 0x01108694: MOV x0, x19                | X0 = X2;//m1                            
            val_41 = val_35;
            // 0x01108698: B.EQ #0x11086c4            | if ((X2 + 176 + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_37) goto label_18;
            label_17:
            // 0x0110869C: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x011086A0: ADD x8, sp, #8             | X8 = (1152921512830047088 + 8) = 1152921512830047096 (0x10000001EA241378);
            // 0x011086A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x011086A8: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921512830035200]
            // 0x011086AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x011086B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011086B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x011086B8: ADD x0, sp, #8             | X0 = (1152921512830047088 + 8) = 1152921512830047096 (0x10000001EA241378);
            // 0x011086BC: BL #0x299a140              | 
            // 0x011086C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_41 = 0;
            label_18:
            // 0x011086C4: LDR x8, [x0]               | X8 = 0x10102464C457F;                   
            // 0x011086C8: LDR x9, [x8, #0x380]       | X9 = mem[282584257677567];              
            // 0x011086CC: LDR x1, [x8, #0x388]       | X1 = mem[282584257677575];              
            // 0x011086D0: BLR x9                     | X0 = mem[282584257677567]();            
            // 0x011086D4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x011086D8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x011086DC: ADRP x9, #0x3619000        | X9 = 56725504 (0x3619000);              
            // 0x011086E0: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            val_34 = val_41;
            // 0x011086E4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x011086E8: LDR x9, [x9, #0xe10]       | X9 = 1152921504608657408;               
            // 0x011086EC: LDR x22, [x9]              | X22 = typeof(System.IntPtr);            
            // 0x011086F0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x011086F4: TBZ w9, #0, #0x1108708     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x011086F8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011086FC: CBNZ w9, #0x1108708        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x01108700: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01108704: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_20:
            // 0x01108708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110870C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108710: MOV x1, x22                | X1 = 1152921504608657408 (0x10000000001BA000);//ML01
            // 0x01108714: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01108718: CMP x21, x0                | STATE = COMPARE(0x0, val_13)            
            // 0x0110871C: B.EQ #0x1108ca4            | if (val_34 == val_13) goto label_82;    
            if(val_34 == val_13)
            {
                goto label_82;
            }
            label_16:
            // 0x01108720: CBNZ x19, #0x1108728       | if (X2 != 0) goto label_22;             
            if(val_35 != 0)
            {
                goto label_22;
            }
            label_8:
            // 0x01108724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_22:
            // 0x01108728: LDR x8, [x19]              | X8 = X2;                                
            // 0x0110872C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108730: LDR x9, [x8, #0x200]       | X9 = X2 + 512;                          
            // 0x01108734: LDR x1, [x8, #0x208]       | X1 = X2 + 520;                          
            // 0x01108738: BLR x9                     | X0 = X2 + 512();                        
            // 0x0110873C: MOV x21, x0                | X21 = X2;//m1                           
            val_34 = val_35;
            // 0x01108740: CBNZ x19, #0x1108748       | if (X2 != 0) goto label_23;             
            if(val_35 != 0)
            {
                goto label_23;
            }
            // 0x01108744: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_23:
            // 0x01108748: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110874C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108750: BL #0x13be894              | X0 = X2.get_IsSpecialName();            
            bool val_14 = val_35.IsSpecialName;
            // 0x01108754: TBZ w0, #0, #0x1108b50     | if (val_14 == false) goto label_48;     
            if(val_14 == false)
            {
                goto label_48;
            }
            // 0x01108758: CBNZ x19, #0x1108760       | if (X2 != 0) goto label_25;             
            if(val_35 != 0)
            {
                goto label_25;
            }
            // 0x0110875C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_25:
            // 0x01108760: LDR x8, [x19]              | X8 = X2;                                
            // 0x01108764: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108768: LDP x9, x1, [x8, #0x190]   | X9 = X2 + 400; X1 = X2 + 400 + 8;        //  | 
            // 0x0110876C: BLR x9                     | X0 = X2 + 400();                        
            // 0x01108770: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x01108774: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x01108778: MOV x22, x0                | X22 = X2;//m1                           
            // 0x0110877C: LDR x23, [x8]              | X23 = typeof(System.Char[]);            
            // 0x01108780: MOV x0, x23                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x01108784: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x01108788: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0110878C: MOV x0, x23                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x01108790: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x01108794: MOV x23, x0                | X23 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x01108798: CBNZ x23, #0x11087a0       | if ( != null) goto label_26;            
            if(null != null)
            {
                goto label_26;
            }
            // 0x0110879C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
            label_26:
            // 0x011087A0: LDR w8, [x23, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
            // 0x011087A4: CBNZ w8, #0x11087b4        | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_27;
            // 0x011087A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Char[]), ????);
            // 0x011087AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011087B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Char[]), ????);
            label_27:
            // 0x011087B4: MOVZ w8, #0x5f             | W8 = 95 (0x5F);//ML01                   
            // 0x011087B8: STRH w8, [x23, #0x20]      | typeof(System.Char[]).__il2cppRuntimeField_20 = 0x5F;  //  dest_result_addr=1152921504947213104
            typeof(System.Char[]).__il2cppRuntimeField_20 = 95;
            // 0x011087BC: CBNZ x22, #0x11087c4       | if (X2 != 0) goto label_28;             
            if(val_35 != 0)
            {
                goto label_28;
            }
            // 0x011087C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Char[]), ????);
            label_28:
            // 0x011087C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011087C8: MOV x0, x22                | X0 = X2;//m1                            
            // 0x011087CC: MOV x1, x23                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x011087D0: BL #0x18a881c              | X0 = X2.Split(separator:  null);        
            System.String[] val_15 = val_35.Split(separator:  null);
            // 0x011087D4: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x011087D8: CBNZ x22, #0x11087e0       | if (val_15 != null) goto label_29;      
            if(val_15 != null)
            {
                goto label_29;
            }
            // 0x011087DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_29:
            // 0x011087E0: LDR w8, [x22, #0x18]       | W8 = val_15.Length; //P2                
            // 0x011087E4: CBNZ w8, #0x11087f4        | if (val_15.Length != 0) goto label_30;  
            if(val_15.Length != 0)
            {
                goto label_30;
            }
            // 0x011087E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x011087EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011087F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_30:
            // 0x011087F4: ADRP x24, #0x35d6000       | X24 = 56451072 (0x35D6000);             
            // 0x011087F8: LDR x24, [x24, #0xe38]     | X24 = 1152921504608284672;              
            // 0x011087FC: LDR x23, [x22, #0x20]      | X23 = val_15[0]                         
            val_42 = val_15[0];
            // 0x01108800: LDR x0, [x24]              | X0 = typeof(System.String);             
            // 0x01108804: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01108808: TBZ w8, #0, #0x1108818     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x0110880C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01108810: CBNZ w8, #0x1108818        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x01108814: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_32:
            // 0x01108818: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x0110881C: LDR x8, [x8, #0x3c8]       | X8 = (string**)(1152921512829998016)("add");
            // 0x01108820: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108824: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01108828: MOV x1, x23                | X1 = val_15[0];//m1                     
            // 0x0110882C: LDR x2, [x8]               | X2 = "add";                             
            // 0x01108830: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_42);
            bool val_16 = System.String.op_Equality(a:  0, b:  val_42);
            // 0x01108834: AND w8, w0, #1             | W8 = (val_16 & 1);                      
            bool val_17 = val_16;
            // 0x01108838: TBNZ w8, #0, #0x1108ca4    | if ((val_16 & 1) == true) goto label_82;
            if(val_17 == true)
            {
                goto label_82;
            }
            // 0x0110883C: CBNZ x22, #0x1108844       | if (val_15 != null) goto label_34;      
            if(val_15 != null)
            {
                goto label_34;
            }
            // 0x01108840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_34:
            // 0x01108844: LDR w8, [x22, #0x18]       | W8 = val_15.Length; //P2                
            // 0x01108848: CBNZ w8, #0x1108858        | if (val_15.Length != 0) goto label_35;  
            if(val_15.Length != 0)
            {
                goto label_35;
            }
            // 0x0110884C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x01108850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108854: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_35:
            // 0x01108858: LDR x0, [x24]              | X0 = typeof(System.String);             
            // 0x0110885C: LDR x23, [x22, #0x20]      | X23 = val_15[0]                         
            val_42 = val_15[0];
            // 0x01108860: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01108864: TBZ w8, #0, #0x1108874     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x01108868: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110886C: CBNZ w8, #0x1108874        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x01108870: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_37:
            // 0x01108874: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01108878: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921512830002192)("remove");
            // 0x0110887C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108880: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01108884: MOV x1, x23                | X1 = val_15[0];//m1                     
            // 0x01108888: LDR x2, [x8]               | X2 = "remove";                          
            // 0x0110888C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_42);
            bool val_18 = System.String.op_Equality(a:  0, b:  val_42);
            // 0x01108890: AND w8, w0, #1             | W8 = (val_18 & 1);                      
            bool val_19 = val_18;
            // 0x01108894: TBNZ w8, #0, #0x1108ca4    | if ((val_18 & 1) == true) goto label_82;
            if(val_19 == true)
            {
                goto label_82;
            }
            // 0x01108898: CBNZ x22, #0x11088a0       | if (val_15 != null) goto label_39;      
            if(val_15 != null)
            {
                goto label_39;
            }
            // 0x0110889C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_39:
            // 0x011088A0: LDR w8, [x22, #0x18]       | W8 = val_15.Length; //P2                
            // 0x011088A4: CBNZ w8, #0x11088b4        | if (val_15.Length != 0) goto label_40;  
            if(val_15.Length != 0)
            {
                goto label_40;
            }
            // 0x011088A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x011088AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011088B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_40:
            // 0x011088B4: LDR x0, [x24]              | X0 = typeof(System.String);             
            // 0x011088B8: LDR x23, [x22, #0x20]      | X23 = val_15[0]                         
            string val_33 = val_15[0];
            // 0x011088BC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x011088C0: TBZ w8, #0, #0x11088d0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_42;
            // 0x011088C4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x011088C8: CBNZ w8, #0x11088d0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
            // 0x011088CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_42:
            // 0x011088D0: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x011088D4: LDR x8, [x8, #0x318]       | X8 = (string**)(1152921512830006368)("get");
            // 0x011088D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011088DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x011088E0: MOV x1, x23                | X1 = val_15[0];//m1                     
            // 0x011088E4: LDR x2, [x8]               | X2 = "get";                             
            // 0x011088E8: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_15[0]);
            bool val_20 = System.String.op_Equality(a:  0, b:  val_33);
            // 0x011088EC: AND w8, w0, #1             | W8 = (val_20 & 1);                      
            bool val_21 = val_20;
            // 0x011088F0: TBNZ w8, #0, #0x110894c    | if ((val_20 & 1) == true) goto label_43;
            if(val_21 == true)
            {
                goto label_43;
            }
            // 0x011088F4: CBNZ x22, #0x11088fc       | if (val_15 != null) goto label_44;      
            if(val_15 != null)
            {
                goto label_44;
            }
            // 0x011088F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_44:
            // 0x011088FC: LDR w8, [x22, #0x18]       | W8 = val_15.Length; //P2                
            // 0x01108900: CBNZ w8, #0x1108910        | if (val_15.Length != 0) goto label_45;  
            if(val_15.Length != 0)
            {
                goto label_45;
            }
            // 0x01108904: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
            // 0x01108908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110890C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_45:
            // 0x01108910: LDR x0, [x24]              | X0 = typeof(System.String);             
            // 0x01108914: LDR x23, [x22, #0x20]      | X23 = val_15[0]                         
            val_42 = val_15[0];
            // 0x01108918: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110891C: TBZ w8, #0, #0x110892c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x01108920: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01108924: CBNZ w8, #0x110892c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x01108928: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_47:
            // 0x0110892C: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x01108930: LDR x8, [x8, #0x70]        | X8 = (string**)(1152921512830010544)("set");
            // 0x01108934: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108938: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            val_43 = 0;
            // 0x0110893C: MOV x1, x23                | X1 = val_15[0];//m1                     
            // 0x01108940: LDR x2, [x8]               | X2 = "set";                             
            // 0x01108944: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_42);
            bool val_22 = System.String.op_Equality(a:  0, b:  val_42);
            // 0x01108948: TBZ w0, #0, #0x1108b50     | if (val_22 == false) goto label_48;     
            if(val_22 == false)
            {
                goto label_48;
            }
            label_43:
            // 0x0110894C: CBNZ x22, #0x1108954       | if (val_15 != null) goto label_49;      
            if(val_15 != null)
            {
                goto label_49;
            }
            // 0x01108950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_49:
            // 0x01108954: LDR w8, [x22, #0x18]       | W8 = val_15.Length; //P2                
            // 0x01108958: CBNZ w8, #0x1108968        | if (val_15.Length != 0) goto label_50;  
            if(val_15.Length != 0)
            {
                goto label_50;
            }
            // 0x0110895C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_22, ????);     
            // 0x01108960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_50:
            // 0x01108968: LDR x0, [x24]              | X0 = typeof(System.String);             
            // 0x0110896C: LDR x23, [x22, #0x20]      | X23 = val_15[0]                         
            string val_34 = val_15[0];
            // 0x01108970: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01108974: TBZ w8, #0, #0x1108984     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_52;
            // 0x01108978: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110897C: CBNZ w8, #0x1108984        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
            // 0x01108980: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_52:
            // 0x01108984: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x01108988: LDR x8, [x8, #0x70]        | X8 = (string**)(1152921512830010544)("set");
            // 0x0110898C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108990: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01108994: MOV x1, x23                | X1 = val_15[0];//m1                     
            // 0x01108998: LDR x2, [x8]               | X2 = "set";                             
            // 0x0110899C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_15[0]);
            bool val_23 = System.String.op_Equality(a:  0, b:  val_34);
            // 0x011089A0: MOV w24, w0                | W24 = val_23;//m1                       
            // 0x011089A4: CBNZ x21, #0x11089ac       | if (X2 != 0) goto label_53;             
            if(val_34 != 0)
            {
                goto label_53;
            }
            // 0x011089A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_53:
            // 0x011089AC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x011089B0: LDR x28, [x21, #0x18]      | X28 = X2 + 24;                          
            var val_35 = X2 + 24;
            // 0x011089B4: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x011089B8: AND w24, w24, #1           | W24 = (val_23 & 1);                     
            bool val_24 = val_23;
            // 0x011089BC: SUB w25, w28, w24          | W25 = (X2 + 24 - (val_23 & 1));         
            val_44 = val_35 - val_24;
            // 0x011089C0: LDR x23, [x8]              | X23 = typeof(System.Type[]);            
            // 0x011089C4: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x011089C8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x011089CC: CMP w25, #1                | STATE = COMPARE((X2 + 24 - (val_23 & 1)), 0x1)
            // 0x011089D0: B.LT #0x1108a8c            | if (val_44 < true) goto label_54;       
            if(val_44 < true)
            {
                goto label_54;
            }
            // 0x011089D4: MOV w1, w25                | W1 = (X2 + 24 - (val_23 & 1));//m1      
            val_45 = val_44;
            // 0x011089D8: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x011089DC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x011089E0: MOV x23, x0                | X23 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_42 = null;
            // 0x011089E4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            // 0x011089E8: ADD x26, x21, #0x20        | X26 = (X2 + 32);                        
            var val_25 = val_34 + 32;
            // 0x011089EC: ADD x27, x23, #0x20        | X27 = (val_42 + 32) = 1152921504987155088 (0x1000000016AB0A90);
            // 0x011089F0: SUB w28, w28, w24          | W28 = (X2 + 24 - (val_23 & 1));         
            val_35 = val_35 - val_24;
            label_62:
            // 0x011089F4: CBNZ x21, #0x11089fc       | if (X2 != 0) goto label_55;             
            if(val_34 != 0)
            {
                goto label_55;
            }
            // 0x011089F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_55:
            // 0x011089FC: LDR w8, [x21, #0x18]       | W8 = X2 + 24;                           
            // 0x01108A00: CMP x25, x8                | STATE = COMPARE(0x0, X2 + 24)           
            // 0x01108A04: B.LO #0x1108a14            | if (0 < X2 + 24) goto label_56;         
            if(0 < (X2 + 24))
            {
                goto label_56;
            }
            // 0x01108A08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Type[]), ????);
            // 0x01108A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_45 = 0;
            // 0x01108A10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Type[]), ????);
            label_56:
            // 0x01108A14: LDR x24, [x26, x25, lsl #3] | X24 = (X2 + 32) + 0;                    
            // 0x01108A18: CBNZ x24, #0x1108a20       | if ((X2 + 32) + 0 != 0) goto label_57;  
            if(((X2 + 32) + 0) != 0)
            {
                goto label_57;
            }
            // 0x01108A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_57:
            // 0x01108A20: LDR x8, [x24]              | X8 = (X2 + 32) + 0;                     
            // 0x01108A24: MOV x0, x24                | X0 = (X2 + 32) + 0;//m1                 
            // 0x01108A28: LDP x9, x1, [x8, #0x170]   | X9 = (X2 + 32) + 0 + 368; X1 = (X2 + 32) + 0 + 368 + 8; //  | 
            // 0x01108A2C: BLR x9                     | X0 = (X2 + 32) + 0 + 368();             
            // 0x01108A30: MOV x24, x0                | X24 = (X2 + 32) + 0;//m1                
            // 0x01108A34: CBNZ x23, #0x1108a3c       | if ( != null) goto label_58;            
            if(null != null)
            {
                goto label_58;
            }
            // 0x01108A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X2 + 32) + 0, ????);
            label_58:
            // 0x01108A3C: CBZ x24, #0x1108a60        | if ((X2 + 32) + 0 == 0) goto label_60;  
            if(((X2 + 32) + 0) == 0)
            {
                goto label_60;
            }
            // 0x01108A40: LDR x8, [x23]              | X8 = ;                                  
            // 0x01108A44: MOV x0, x24                | X0 = (X2 + 32) + 0;//m1                 
            // 0x01108A48: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01108A4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (X2 + 32) + 0, ????);
            // 0x01108A50: CBNZ x0, #0x1108a60        | if ((X2 + 32) + 0 != 0) goto label_60;  
            if(((X2 + 32) + 0) != 0)
            {
                goto label_60;
            }
            // 0x01108A54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (X2 + 32) + 0, ????);
            // 0x01108A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108A5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (X2 + 32) + 0, ????);
            label_60:
            // 0x01108A60: LDR w8, [x23, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01108A64: CMP x25, x8                | STATE = COMPARE(0x0, System.Type[].__il2cppRuntimeField_namespaze)
            // 0x01108A68: B.LO #0x1108a78            | if (0 < System.Type[].__il2cppRuntimeField_namespaze) goto label_61;
            // 0x01108A6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (X2 + 32) + 0, ????);
            // 0x01108A70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108A74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (X2 + 32) + 0, ????);
            label_61:
            // 0x01108A78: STR x24, [x27, x25, lsl #3] | System.Type[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = (X2 + 32) + 0;  //  dest_result_addr=1152921504987155088
            System.Type[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = (X2 + 32) + 0;
            // 0x01108A7C: ADD x25, x25, #1           | X25 = (0 + 1);                          
            val_44 = 0 + 1;
            // 0x01108A80: CMP w28, w25               | STATE = COMPARE((X2 + 24 - (val_23 & 1)), (0 + 1))
            // 0x01108A84: B.NE #0x11089f4            | if (X2 + 24 != val_44) goto label_62;   
            if(val_35 != val_44)
            {
                goto label_62;
            }
            // 0x01108A88: B #0x1108a9c               |  goto label_63;                         
            goto label_63;
            label_54:
            // 0x01108A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108A90: MOV x0, x23                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01108A94: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01108A98: MOV x23, x0                | X23 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            val_42 = null;
            label_63:
            // 0x01108A9C: CBNZ x22, #0x1108aa4       | if (val_15 != null) goto label_64;      
            if(val_15 != null)
            {
                goto label_64;
            }
            // 0x01108AA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_64:
            // 0x01108AA4: LDR w8, [x22, #0x18]       | W8 = val_15.Length; //P2                
            // 0x01108AA8: CMP w8, #1                 | STATE = COMPARE(val_15.Length, 0x1)     
            // 0x01108AAC: B.HI #0x1108abc            | if (val_15.Length > 1) goto label_65;   
            if(val_15.Length > 1)
            {
                goto label_65;
            }
            // 0x01108AB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Type[]), ????);
            // 0x01108AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108AB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Type[]), ????);
            label_65:
            // 0x01108ABC: LDR x22, [x22, #0x28]      | X22 = val_15[1]                         
            string val_36 = val_15[1];
            // 0x01108AC0: CBNZ x20, #0x1108ac8       | if (i != null) goto label_66;           
            if(i != null)
            {
                goto label_66;
            }
            // 0x01108AC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_66:
            // 0x01108AC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01108ACC: MOV x0, x20                | X0 = i;//m1                             
            // 0x01108AD0: MOV x1, x22                | X1 = val_15[1];//m1                     
            // 0x01108AD4: MOV x2, x23                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01108AD8: BL #0x1b6e52c              | X0 = i.GetProperty(name:  val_15[1], types:  val_42);
            System.Reflection.PropertyInfo val_26 = i.GetProperty(name:  val_36, types:  val_42);
            // 0x01108ADC: MOV x20, x0                | X20 = val_26;//m1                       
            // 0x01108AE0: CBZ x20, #0x1108ca4        | if (val_26 == null) goto label_82;      
            if(val_26 == null)
            {
                goto label_82;
            }
            // 0x01108AE4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01108AE8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01108AEC: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x01108AF0: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x01108AF4: LDR x8, [x8, #0xa28]       | X8 = 1152921504610201600;               
            // 0x01108AF8: LDR x22, [x8]              | X22 = typeof(System.ObsoleteAttribute); 
            // 0x01108AFC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01108B00: TBZ w8, #0, #0x1108b10     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_69;
            // 0x01108B04: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01108B08: CBNZ w8, #0x1108b10        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
            // 0x01108B0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_69:
            // 0x01108B10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108B14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108B18: MOV x1, x22                | X1 = 1152921504610201600 (0x1000000000333000);//ML01
            // 0x01108B1C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_27 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01108B20: LDR x8, [x20]              | X8 = typeof(System.Reflection.PropertyInfo);
            // 0x01108B24: MOV x1, x0                 | X1 = val_27;//m1                        
            // 0x01108B28: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01108B2C: MOV x0, x20                | X0 = val_26;//m1                        
            // 0x01108B30: LDP x9, x3, [x8, #0x1e0]   | X9 = typeof(System.Reflection.PropertyInfo).__il2cppRuntimeField_1E0; X3 = typeof(System.Reflection.PropertyInfo).__il2cppRuntimeField_1E8; //  | 
            // 0x01108B34: BLR x9                     | X0 = typeof(System.Reflection.PropertyInfo).__il2cppRuntimeField_1E0();
            // 0x01108B38: MOV x20, x0                | X20 = val_26;//m1                       
            // 0x01108B3C: CBNZ x20, #0x1108b44       | if (val_26 != null) goto label_70;      
            if(val_26 != null)
            {
                goto label_70;
            }
            // 0x01108B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_70:
            // 0x01108B44: LDR w8, [x20, #0x18]       | 
            // 0x01108B48: CMP w8, #0                 | STATE = COMPARE(typeof(System.Reflection.PropertyInfo), 0x0)
            // 0x01108B4C: B.GT #0x1108ca4            | if (typeof(System.Reflection.PropertyInfo) > null) goto label_82;
            if(null > 0)
            {
                goto label_82;
            }
            label_48:
            // 0x01108B50: ADRP x22, #0x3620000       | X22 = 56754176 (0x3620000);             
            // 0x01108B54: LDR x22, [x22, #0x340]     | X22 = 1152921504609562624;              
            // 0x01108B58: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x01108B5C: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01108B60: LDR x8, [x8, #0xa28]       | X8 = 1152921504610201600;               
            // 0x01108B64: LDR x20, [x8]              | X20 = typeof(System.ObsoleteAttribute); 
            // 0x01108B68: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01108B6C: TBZ w8, #0, #0x1108b7c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_73;
            // 0x01108B70: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01108B74: CBNZ w8, #0x1108b7c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
            // 0x01108B78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_73:
            // 0x01108B7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108B80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108B84: MOV x1, x20                | X1 = 1152921504610201600 (0x1000000000333000);//ML01
            // 0x01108B88: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01108B8C: MOV x20, x0                | X20 = val_28;//m1                       
            // 0x01108B90: CBNZ x19, #0x1108b98       | if (X2 != 0) goto label_74;             
            if(val_35 != 0)
            {
                goto label_74;
            }
            // 0x01108B94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_74:
            // 0x01108B98: LDR x8, [x19]              | X8 = X2;                                
            // 0x01108B9C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01108BA0: MOV x0, x19                | X0 = X2;//m1                            
            // 0x01108BA4: MOV x1, x20                | X1 = val_28;//m1                        
            val_46 = val_28;
            // 0x01108BA8: LDP x9, x3, [x8, #0x1e0]   | X9 = X2 + 480; X3 = X2 + 480 + 8;        //  | 
            // 0x01108BAC: BLR x9                     | X0 = X2 + 480();                        
            // 0x01108BB0: MOV x19, x0                | X19 = X2;//m1                           
            val_35 = val_35;
            // 0x01108BB4: CBNZ x19, #0x1108bbc       | if (X2 != 0) goto label_75;             
            if(val_35 != 0)
            {
                goto label_75;
            }
            // 0x01108BB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_75:
            // 0x01108BBC: LDR w8, [x19, #0x18]       | W8 = X2 + 24;                           
            // 0x01108BC0: CMP w8, #0                 | STATE = COMPARE(X2 + 24, 0x0)           
            // 0x01108BC4: B.GT #0x1108ca4            | if (X2 + 24 > 0x0) goto label_82;       
            if((X2 + 24) > 0)
            {
                goto label_82;
            }
            // 0x01108BC8: ADRP x24, #0x3619000       | X24 = 56725504 (0x3619000);             
            // 0x01108BCC: LDR x24, [x24, #0xe10]     | X24 = 1152921504608657408;              
            // 0x01108BD0: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_42 = 0;
            label_86:
            // 0x01108BD4: CBNZ x21, #0x1108bdc       | if (X2 != 0) goto label_77;             
            if(val_34 != 0)
            {
                goto label_77;
            }
            // 0x01108BD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_77:
            // 0x01108BDC: LDR w8, [x21, #0x18]       | W8 = X2 + 24;                           
            // 0x01108BE0: CMP w23, w8                | STATE = COMPARE(0x0, X2 + 24)           
            // 0x01108BE4: B.GE #0x1108cc8            | if (val_42 >= X2 + 24) goto label_78;   
            if(val_42 >= (X2 + 24))
            {
                goto label_78;
            }
            // 0x01108BE8: SXTW x19, w23              | X19 = 0 (0x00000000);                   
            // 0x01108BEC: CMP w23, w8                | STATE = COMPARE(0x0, X2 + 24)           
            // 0x01108BF0: B.LO #0x1108c00            | if (val_42 < X2 + 24) goto label_79;    
            if(val_42 < (X2 + 24))
            {
                goto label_79;
            }
            // 0x01108BF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
            // 0x01108BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_46 = 0;
            // 0x01108BFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
            label_79:
            // 0x01108C00: ADD x8, x21, x19, lsl #3   | X8 = (X2 + 0);                          
            var val_29 = val_34 + 0;
            // 0x01108C04: LDR x19, [x8, #0x20]       | X19 = (X2 + 0) + 32;                    
            val_35 = mem[(X2 + 0) + 32];
            val_35 = (X2 + 0) + 32;
            // 0x01108C08: CBNZ x19, #0x1108c10       | if ((X2 + 0) + 32 != 0) goto label_80;  
            if(val_35 != 0)
            {
                goto label_80;
            }
            // 0x01108C0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_80:
            // 0x01108C10: LDR x8, [x19]              | X8 = (X2 + 0) + 32;                     
            // 0x01108C14: MOV x0, x19                | X0 = (X2 + 0) + 32;//m1                 
            // 0x01108C18: LDP x9, x1, [x8, #0x170]   | X9 = (X2 + 0) + 32 + 368; X1 = (X2 + 0) + 32 + 368 + 8; //  | 
            // 0x01108C1C: BLR x9                     | X0 = (X2 + 0) + 32 + 368();             
            // 0x01108C20: MOV x20, x0                | X20 = (X2 + 0) + 32;//m1                
            // 0x01108C24: CBNZ x20, #0x1108c2c       | if ((X2 + 0) + 32 != 0) goto label_81;  
            if(val_35 != 0)
            {
                goto label_81;
            }
            // 0x01108C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X2 + 0) + 32, ????);
            label_81:
            // 0x01108C2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108C30: MOV x0, x20                | X0 = (X2 + 0) + 32;//m1                 
            // 0x01108C34: BL #0x1b6d40c              | X0 = (X2 + 0) + 32.get_IsPointer();     
            bool val_30 = val_35.IsPointer;
            // 0x01108C38: AND w8, w0, #1             | W8 = (val_30 & 1);                      
            bool val_31 = val_30;
            // 0x01108C3C: TBNZ w8, #0, #0x1108ca4    | if ((val_30 & 1) == true) goto label_82;
            if(val_31 == true)
            {
                goto label_82;
            }
            // 0x01108C40: CBNZ x19, #0x1108c48       | if ((X2 + 0) + 32 != 0) goto label_83;  
            if(val_35 != 0)
            {
                goto label_83;
            }
            // 0x01108C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_83:
            // 0x01108C48: LDR x8, [x19]              | X8 = (X2 + 0) + 32;                     
            // 0x01108C4C: MOV x0, x19                | X0 = (X2 + 0) + 32;//m1                 
            // 0x01108C50: LDP x9, x1, [x8, #0x170]   | X9 = (X2 + 0) + 32 + 368; X1 = (X2 + 0) + 32 + 368 + 8; //  | 
            // 0x01108C54: BLR x9                     | X0 = (X2 + 0) + 32 + 368();             
            // 0x01108C58: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x01108C5C: LDR x20, [x24]             | X20 = typeof(System.IntPtr);            
            // 0x01108C60: MOV x19, x0                | X19 = (X2 + 0) + 32;//m1                
            val_35 = val_35;
            // 0x01108C64: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01108C68: TBZ w9, #0, #0x1108c7c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_85;
            // 0x01108C6C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01108C70: CBNZ w9, #0x1108c7c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_85;
            // 0x01108C74: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01108C78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_85:
            // 0x01108C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108C84: MOV x1, x20                | X1 = 1152921504608657408 (0x10000000001BA000);//ML01
            // 0x01108C88: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_32 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01108C8C: MOV x8, x0                 | X8 = val_32;//m1                        
            // 0x01108C90: ADD w23, w23, #1           | W23 = (val_42 + 1);                     
            val_42 = val_42 + 1;
            // 0x01108C94: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_47 = 1;
            // 0x01108C98: CMP x19, x8                | STATE = COMPARE((X2 + 0) + 32, val_32)  
            // 0x01108C9C: B.NE #0x1108bd4            | if (val_35 != val_32) goto label_86;    
            if(val_35 != val_32)
            {
                goto label_86;
            }
            // 0x01108CA0: B #0x1108ca8               |  goto label_88;                         
            goto label_88;
            label_82:
            // 0x01108CA4: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_47 = 1;
            label_88:
            // 0x01108CA8: SUB sp, x29, #0x50         | SP = (1152921512830047184 - 80) = 1152921512830047104 (0x10000001EA241380);
            // 0x01108CAC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01108CB0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01108CB4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01108CB8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01108CBC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01108CC0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01108CC4: RET                        |  return (System.Boolean)true;           
            return (bool)val_47;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_78:
            // 0x01108CC8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x01108CCC: B #0x1108ca8               |  goto label_88;                         
            goto label_88;
            // 0x01108CD0: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x01108CD4: MOV x0, sp                 | X0 = 1152921512830047088 (0x10000001EA241370);//ML01
            val_49;
            // 0x01108CD8: B #0x1108ce4               |  goto label_89;                         
            goto label_89;
            // 0x01108CDC: MOV x19, x0                | X19 = 1152921512830047088 (0x10000001EA241370);//ML01
            val_48 = val_49;
            // 0x01108CE0: ADD x0, sp, #8             | X0 = (1152921512830047088 + 8) = 1152921512830047096 (0x10000001EA241378);
            label_89:
            // 0x01108CE4: BL #0x299a140              | 
            // 0x01108CE8: MOV x0, x19                | X0 = 1152921512830047088 (0x10000001EA241370);//ML01
            // 0x01108CEC: BL #0x980800               | X0 = sub_980800( ?? 0x10000001EA241370, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x01108CF0 (17861872), len: 572  VirtAddr: 0x01108CF0 RVA: 0x01108CF0 token: 100679921 methodIndex: 29208 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857230
        internal static void AppendParameters(System.Reflection.ParameterInfo[] param, System.Text.StringBuilder sb, bool isMultiArr = False, int skipLast = 0)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            string val_14;
            // 0x01108CF0: STP x28, x27, [sp, #-0x60]! | stack[1152921512830327280] = ???;  stack[1152921512830327288] = ???;  //  dest_result_addr=1152921512830327280 |  dest_result_addr=1152921512830327288
            // 0x01108CF4: STP x26, x25, [sp, #0x10]  | stack[1152921512830327296] = ???;  stack[1152921512830327304] = ???;  //  dest_result_addr=1152921512830327296 |  dest_result_addr=1152921512830327304
            // 0x01108CF8: STP x24, x23, [sp, #0x20]  | stack[1152921512830327312] = ???;  stack[1152921512830327320] = ???;  //  dest_result_addr=1152921512830327312 |  dest_result_addr=1152921512830327320
            // 0x01108CFC: STP x22, x21, [sp, #0x30]  | stack[1152921512830327328] = ???;  stack[1152921512830327336] = ???;  //  dest_result_addr=1152921512830327328 |  dest_result_addr=1152921512830327336
            // 0x01108D00: STP x20, x19, [sp, #0x40]  | stack[1152921512830327344] = ???;  stack[1152921512830327352] = ???;  //  dest_result_addr=1152921512830327344 |  dest_result_addr=1152921512830327352
            // 0x01108D04: STP x29, x30, [sp, #0x50]  | stack[1152921512830327360] = ???;  stack[1152921512830327368] = ???;  //  dest_result_addr=1152921512830327360 |  dest_result_addr=1152921512830327368
            // 0x01108D08: ADD x29, sp, #0x50         | X29 = (1152921512830327280 + 80) = 1152921512830327360 (0x10000001EA285A40);
            // 0x01108D0C: ADRP x23, #0x3735000       | X23 = 57888768 (0x3735000);             
            // 0x01108D10: LDRB w8, [x23, #0xb97]     | W8 = (bool)static_value_03735B97;       
            // 0x01108D14: MOV w19, w4                | W19 = W4;//m1                           
            // 0x01108D18: MOV w20, w3                | W20 = skipLast;//m1                     
            // 0x01108D1C: MOV x21, x2                | X21 = isMultiArr;//m1                   
            // 0x01108D20: MOV x22, x1                | X22 = sb;//m1                           
            // 0x01108D24: TBNZ w8, #0, #0x1108d40    | if (static_value_03735B97 == true) goto label_0;
            // 0x01108D28: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01108D2C: LDR x8, [x8, #0x8f0]       | X8 = 0x2B8F548;                         
            // 0x01108D30: LDR w0, [x8]               | W0 = 0x1414;                            
            // 0x01108D34: BL #0x2782188              | X0 = sub_2782188( ?? 0x1414, ????);     
            // 0x01108D38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01108D3C: STRB w8, [x23, #0xb97]     | static_value_03735B97 = true;            //  dest_result_addr=57891735
            label_0:
            // 0x01108D40: ADRP x27, #0x3625000       | X27 = 56774656 (0x3625000);             
            // 0x01108D44: ADRP x28, #0x35e7000       | X28 = 56520704 (0x35E7000);             
            // 0x01108D48: ADRP x26, #0x367c000       | X26 = 57131008 (0x367C000);             
            // 0x01108D4C: LDR x27, [x27, #0xd38]     | X27 = (string**)(1152921511700096048)("a");
            // 0x01108D50: LDR x28, [x28, #0xf68]     | X28 = (string**)(1152921512830278272)("@");
            // 0x01108D54: LDR x26, [x26, #0xef8]     | X26 = (string**)(1152921509424793408)(", ");
            // 0x01108D58: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x01108D5C: ORR w24, wzr, #1           | W24 = 1(0x1);                           
            // 0x01108D60: B #0x1108ebc               |  goto label_2;                          
            goto label_2;
            label_26:
            // 0x01108D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108D68: MOV x0, x21                | X0 = isMultiArr;//m1                    
            // 0x01108D6C: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x01108D70: BL #0x1b5b818              | X0 = isMultiArr.Append(value:  1);      
            System.Text.StringBuilder val_1 = isMultiArr.Append(value:  1);
            // 0x01108D74: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            // 0x01108D78: ADD w23, w23, #1           | W23 = (val_11 + 1) = val_11 (0x00000001);
            val_11 = 1;
            // 0x01108D7C: B #0x1108ebc               |  goto label_2;                          
            goto label_2;
            label_22:
            // 0x01108D80: AND w8, w24, #1            | W8 = (0 & 1) = 0 (0x00000000);          
            // 0x01108D84: TBNZ w8, #0, #0x1108da0    | if ((0x0 & 0x1) != 0) goto label_3;     
            if((0 & 1) != 0)
            {
                goto label_3;
            }
            // 0x01108D88: CBNZ x21, #0x1108d90       | if (isMultiArr == true) goto label_4;   
            if(isMultiArr == true)
            {
                goto label_4;
            }
            // 0x01108D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x01108D90: LDR x1, [x26]              | X1 = ", ";                              
            // 0x01108D94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108D98: MOV x0, x21                | X0 = isMultiArr;//m1                    
            // 0x01108D9C: BL #0x1b5b818              | X0 = isMultiArr.Append(value:  ", ");   
            System.Text.StringBuilder val_2 = isMultiArr.Append(value:  ", ");
            label_3:
            // 0x01108DA0: CBNZ x22, #0x1108da8       | if (sb != null) goto label_5;           
            if(sb != null)
            {
                goto label_5;
            }
            // 0x01108DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x01108DA8: LDR w8, [x22, #0x18]       | W8 = sb._str; //P2                      
            // 0x01108DAC: SXTW x24, w23              | X24 = 1 (0x00000001);                   
            // 0x01108DB0: CMP w23, w8                | STATE = COMPARE(0x1, sb._str)           
            // 0x01108DB4: B.LO #0x1108dc4            | if (val_11 < sb._str) goto label_6;     
            if(val_11 < sb._str)
            {
                goto label_6;
            }
            // 0x01108DB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x01108DBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108DC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x01108DC4: ADD x8, x22, x24, lsl #3   | X8 = (sb + 8);                          
            System.Text.StringBuilder val_3 = sb + 8;
            // 0x01108DC8: LDR x24, [x8, #0x20]       | X24 = (sb + 8)._cached_str; //P2        
            // 0x01108DCC: CBNZ x24, #0x1108dd4       | if ((sb + 8)._cached_str != null) goto label_7;
            if(((sb + 8)._cached_str) != null)
            {
                goto label_7;
            }
            // 0x01108DD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x01108DD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x01108DD8: MOV x0, x24                | X0 = (sb + 8)._cached_str;//m1          
            // 0x01108DDC: BL #0x13c43b4              | X0 = (sb + 8)._cached_str.get_IsOut();  
            bool val_4 = (sb + 8)._cached_str.IsOut;
            // 0x01108DE0: TBZ w0, #0, #0x1108e2c     | if (val_4 == false) goto label_11;      
            if(val_4 == false)
            {
                goto label_11;
            }
            // 0x01108DE4: CBNZ x24, #0x1108dec       | if ((sb + 8)._cached_str != null) goto label_9;
            if(((sb + 8)._cached_str) != null)
            {
                goto label_9;
            }
            // 0x01108DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_9:
            // 0x01108DEC: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x01108DF0: MOV x0, x24                | X0 = (sb + 8)._cached_str;//m1          
            // 0x01108DF4: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.String).__il2cppRuntimeField_170; X1 = typeof(System.String).__il2cppRuntimeField_178; //  | 
            // 0x01108DF8: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_170();
            // 0x01108DFC: MOV x25, x0                | X25 = (sb + 8)._cached_str;//m1         
            val_13 = (sb + 8)._cached_str;
            // 0x01108E00: CBNZ x25, #0x1108e08       | if ((sb + 8)._cached_str != null) goto label_10;
            if(val_13 != null)
            {
                goto label_10;
            }
            // 0x01108E04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (sb + 8)._cached_str, ????);
            label_10:
            // 0x01108E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x01108E0C: MOV x0, x25                | X0 = (sb + 8)._cached_str;//m1          
            // 0x01108E10: BL #0x1b6d1dc              | X0 = (sb + 8)._cached_str.get_IsByRef();
            bool val_5 = val_13.IsByRef;
            // 0x01108E14: TBZ w0, #0, #0x1108e2c     | if (val_5 == false) goto label_11;      
            if(val_5 == false)
            {
                goto label_11;
            }
            // 0x01108E18: CBNZ x21, #0x1108e20       | if (isMultiArr == true) goto label_12;  
            if(isMultiArr == true)
            {
                goto label_12;
            }
            // 0x01108E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x01108E20: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x01108E24: LDR x8, [x8, #0x148]       | X8 = (string**)(1152921512830294736)("out ");
            val_14 = "out ";
            // 0x01108E28: B #0x1108e70               |  goto label_13;                         
            goto label_13;
            label_11:
            // 0x01108E2C: CBNZ x24, #0x1108e34       | if ((sb + 8)._cached_str != null) goto label_14;
            if(((sb + 8)._cached_str) != null)
            {
                goto label_14;
            }
            // 0x01108E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_14:
            // 0x01108E34: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x01108E38: MOV x0, x24                | X0 = (sb + 8)._cached_str;//m1          
            // 0x01108E3C: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.String).__il2cppRuntimeField_170; X1 = typeof(System.String).__il2cppRuntimeField_178; //  | 
            // 0x01108E40: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_170();
            // 0x01108E44: MOV x25, x0                | X25 = (sb + 8)._cached_str;//m1         
            val_13 = (sb + 8)._cached_str;
            // 0x01108E48: CBNZ x25, #0x1108e50       | if ((sb + 8)._cached_str != null) goto label_15;
            if(val_13 != null)
            {
                goto label_15;
            }
            // 0x01108E4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (sb + 8)._cached_str, ????);
            label_15:
            // 0x01108E50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108E54: MOV x0, x25                | X0 = (sb + 8)._cached_str;//m1          
            // 0x01108E58: BL #0x1b6d1dc              | X0 = (sb + 8)._cached_str.get_IsByRef();
            bool val_6 = val_13.IsByRef;
            // 0x01108E5C: TBZ w0, #0, #0x1108e80     | if (val_6 == false) goto label_16;      
            if(val_6 == false)
            {
                goto label_16;
            }
            // 0x01108E60: CBNZ x21, #0x1108e68       | if (isMultiArr == true) goto label_17;  
            if(isMultiArr == true)
            {
                goto label_17;
            }
            // 0x01108E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_17:
            // 0x01108E68: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x01108E6C: LDR x8, [x8, #0xc70]       | X8 = (string**)(1152921512830294816)("ref ");
            val_14 = "ref ";
            label_13:
            // 0x01108E70: LDR x1, [x8]               | X1 = "ref ";                            
            // 0x01108E74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108E78: MOV x0, x21                | X0 = isMultiArr;//m1                    
            // 0x01108E7C: BL #0x1b5b818              | X0 = isMultiArr.Append(value:  val_14 = "ref ");
            System.Text.StringBuilder val_7 = isMultiArr.Append(value:  val_14);
            label_16:
            // 0x01108E80: CBNZ x21, #0x1108e88       | if (isMultiArr == true) goto label_18;  
            if(isMultiArr == true)
            {
                goto label_18;
            }
            // 0x01108E84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_18:
            // 0x01108E88: TBZ w20, #0, #0x1108ed8    | if ((skipLast & 0x1) == 0) goto label_19;
            if((skipLast & 1) == 0)
            {
                goto label_19;
            }
            // 0x01108E8C: LDR x1, [x27]              | X1 = "a";                               
            // 0x01108E90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108E94: MOV x0, x21                | X0 = isMultiArr;//m1                    
            // 0x01108E98: BL #0x1b5b818              | X0 = isMultiArr.Append(value:  "a");    
            System.Text.StringBuilder val_8 = isMultiArr.Append(value:  "a");
            // 0x01108E9C: CBNZ x21, #0x1108ea4       | if (isMultiArr == true) goto label_20;  
            if(isMultiArr == true)
            {
                goto label_20;
            }
            // 0x01108EA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_20:
            // 0x01108EA4: ADD w23, w23, #1           | W23 = (val_11 + 1) = val_11 (0x00000002);
            val_11 = 2;
            // 0x01108EA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108EAC: MOV x0, x21                | X0 = isMultiArr;//m1                    
            // 0x01108EB0: MOV w1, w23                | W1 = 2 (0x2);//ML01                     
            // 0x01108EB4: BL #0x1b5bac4              | X0 = isMultiArr.Append(value:  2);      
            System.Text.StringBuilder val_9 = isMultiArr.Append(value:  2);
            // 0x01108EB8: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            label_2:
            // 0x01108EBC: CBNZ x22, #0x1108ec4       | if (sb != null) goto label_21;          
            if(sb != null)
            {
                goto label_21;
            }
            // 0x01108EC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_21:
            // 0x01108EC4: LDR w8, [x22, #0x18]       | W8 = sb._str; //P2                      
            string val_11 = sb._str;
            // 0x01108EC8: SUB w8, w8, w19            | W8 = (sb._str - W4);                    
            val_11 = val_11 - W4;
            // 0x01108ECC: CMP w23, w8                | STATE = COMPARE(0x2, (sb._str - W4))    
            // 0x01108ED0: B.LT #0x1108d80            | if (val_11 < sb._str) goto label_22;    
            if(val_11 < val_11)
            {
                goto label_22;
            }
            // 0x01108ED4: B #0x1108f10               |  goto label_23;                         
            goto label_23;
            label_19:
            // 0x01108ED8: LDR x1, [x28]              | X1 = "@";                               
            // 0x01108EDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108EE0: MOV x0, x21                | X0 = isMultiArr;//m1                    
            // 0x01108EE4: BL #0x1b5b818              | X0 = isMultiArr.Append(value:  "@");    
            System.Text.StringBuilder val_10 = isMultiArr.Append(value:  "@");
            // 0x01108EE8: CBNZ x24, #0x1108ef0       | if ((sb + 8)._cached_str != null) goto label_24;
            if(((sb + 8)._cached_str) != null)
            {
                goto label_24;
            }
            // 0x01108EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_24:
            // 0x01108EF0: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x01108EF4: MOV x0, x24                | X0 = (sb + 8)._cached_str;//m1          
            // 0x01108EF8: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(System.String).__il2cppRuntimeField_1A0; X1 = typeof(System.String).__il2cppRuntimeField_1A8; //  | 
            // 0x01108EFC: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_1A0();
            // 0x01108F00: MOV x24, x0                | X24 = (sb + 8)._cached_str;//m1         
            // 0x01108F04: CBNZ x21, #0x1108d64       | if (isMultiArr == true) goto label_26;  
            if(isMultiArr == true)
            {
                goto label_26;
            }
            // 0x01108F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (sb + 8)._cached_str, ????);
            // 0x01108F0C: B #0x1108d64               |  goto label_26;                         
            goto label_26;
            label_23:
            // 0x01108F10: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01108F14: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01108F18: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01108F1C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01108F20: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01108F24: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01108F28: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01108F2C (17862444), len: 1152  VirtAddr: 0x01108F2C RVA: 0x01108F2C token: 100679922 methodIndex: 29209 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857240
        internal static string GetRetrieveValueCode(System.Type type, string realClsName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_17;
            //  | 
            var val_18;
            // 0x01108F2C: STP x22, x21, [sp, #-0x30]! | stack[1152921512830577472] = ???;  stack[1152921512830577480] = ???;  //  dest_result_addr=1152921512830577472 |  dest_result_addr=1152921512830577480
            // 0x01108F30: STP x20, x19, [sp, #0x10]  | stack[1152921512830577488] = ???;  stack[1152921512830577496] = ???;  //  dest_result_addr=1152921512830577488 |  dest_result_addr=1152921512830577496
            // 0x01108F34: STP x29, x30, [sp, #0x20]  | stack[1152921512830577504] = ???;  stack[1152921512830577512] = ???;  //  dest_result_addr=1152921512830577504 |  dest_result_addr=1152921512830577512
            // 0x01108F38: ADD x29, sp, #0x20         | X29 = (1152921512830577472 + 32) = 1152921512830577504 (0x10000001EA2C2B60);
            // 0x01108F3C: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x01108F40: LDRB w8, [x21, #0xb98]     | W8 = (bool)static_value_03735B98;       
            // 0x01108F44: MOV x20, x2                | X20 = X2;//m1                           
            // 0x01108F48: MOV x19, x1                | X19 = realClsName;//m1                  
            val_17 = realClsName;
            // 0x01108F4C: TBNZ w8, #0, #0x1108f68    | if (static_value_03735B98 == true) goto label_0;
            // 0x01108F50: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x01108F54: LDR x8, [x8, #0x1b8]       | X8 = 0x2B8F554;                         
            // 0x01108F58: LDR w0, [x8]               | W0 = 0x1417;                            
            // 0x01108F5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1417, ????);     
            // 0x01108F60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01108F64: STRB w8, [x21, #0xb98]     | static_value_03735B98 = true;            //  dest_result_addr=57891736
            label_0:
            // 0x01108F68: CBNZ x19, #0x1108f70       | if (realClsName != null) goto label_1;  
            if(val_17 != null)
            {
                goto label_1;
            }
            // 0x01108F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1417, ????);     
            label_1:
            // 0x01108F70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108F74: MOV x0, x19                | X0 = realClsName;//m1                   
            // 0x01108F78: BL #0x1b6d1dc              | X0 = realClsName.get_IsByRef();         
            bool val_1 = val_17.IsByRef;
            // 0x01108F7C: TBZ w0, #0, #0x1108fa0     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x01108F80: CBNZ x19, #0x1108f88       | if (realClsName != null) goto label_3;  
            if(val_17 != null)
            {
                goto label_3;
            }
            // 0x01108F84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x01108F88: LDR x8, [x19]              | X8 = typeof(System.String);             
            // 0x01108F8C: MOV x0, x19                | X0 = realClsName;//m1                   
            // 0x01108F90: LDR x9, [x8, #0x410]       | X9 = typeof(System.String).__il2cppRuntimeField_410;
            // 0x01108F94: LDR x1, [x8, #0x418]       | X1 = typeof(System.String).__il2cppRuntimeField_418;
            // 0x01108F98: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_410();
            // 0x01108F9C: MOV x19, x0                | X19 = realClsName;//m1                  
            val_17 = val_17;
            label_2:
            // 0x01108FA0: CBNZ x19, #0x1108fa8       | if (realClsName != null) goto label_4;  
            if(val_17 != null)
            {
                goto label_4;
            }
            // 0x01108FA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? realClsName, ????);
            label_4:
            // 0x01108FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108FAC: MOV x0, x19                | X0 = realClsName;//m1                   
            // 0x01108FB0: BL #0x1b6d41c              | X0 = realClsName.get_IsPrimitive();     
            bool val_2 = val_17.IsPrimitive;
            // 0x01108FB4: TBZ w0, #0, #0x110929c     | if (val_2 == false) goto label_5;       
            if(val_2 == false)
            {
                goto label_5;
            }
            // 0x01108FB8: ADRP x21, #0x3620000       | X21 = 56754176 (0x3620000);             
            // 0x01108FBC: LDR x21, [x21, #0x340]     | X21 = 1152921504609562624;              
            // 0x01108FC0: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x01108FC4: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x01108FC8: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x01108FCC: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x01108FD0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01108FD4: TBZ w8, #0, #0x1108fe4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01108FD8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01108FDC: CBNZ w8, #0x1108fe4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01108FE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x01108FE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108FE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108FEC: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x01108FF0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01108FF4: CMP x19, x0                | STATE = COMPARE(realClsName, val_3)     
            // 0x01108FF8: B.EQ #0x11092e4            | if (val_17 == val_3) goto label_8;      
            if(val_17 == val_3)
            {
                goto label_8;
            }
            // 0x01108FFC: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x01109000: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x01109004: LDR x8, [x8, #0xc08]       | X8 = 1152921504607592448;               
            // 0x01109008: LDR x20, [x8]              | X20 = typeof(System.Int64);             
            // 0x0110900C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109010: TBZ w8, #0, #0x1109020     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01109014: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109018: CBNZ w8, #0x1109020        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x0110901C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x01109020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109024: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109028: MOV x1, x20                | X1 = 1152921504607592448 (0x10000000000B6000);//ML01
            // 0x0110902C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109030: CMP x19, x0                | STATE = COMPARE(realClsName, val_4)     
            // 0x01109034: B.EQ #0x11092f0            | if (val_17 == val_4) goto label_11;     
            if(val_17 == val_4)
            {
                goto label_11;
            }
            // 0x01109038: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0110903C: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x01109040: LDR x8, [x8, #0x908]       | X8 = 1152921504607911936;               
            // 0x01109044: LDR x20, [x8]              | X20 = typeof(System.Int16);             
            // 0x01109048: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110904C: TBZ w8, #0, #0x110905c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x01109050: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109054: CBNZ w8, #0x110905c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x01109058: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x0110905C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109060: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109064: MOV x1, x20                | X1 = 1152921504607911936 (0x1000000000104000);//ML01
            // 0x01109068: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110906C: CMP x19, x0                | STATE = COMPARE(realClsName, val_5)     
            // 0x01109070: B.EQ #0x11092fc            | if (val_17 == val_5) goto label_14;     
            if(val_17 == val_5)
            {
                goto label_14;
            }
            // 0x01109074: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x01109078: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x0110907C: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x01109080: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x01109084: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109088: TBZ w8, #0, #0x1109098     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x0110908C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109090: CBNZ w8, #0x1109098        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x01109094: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_16:
            // 0x01109098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110909C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011090A0: MOV x1, x20                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x011090A4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011090A8: CMP x19, x0                | STATE = COMPARE(realClsName, val_6)     
            // 0x011090AC: B.EQ #0x1109308            | if (val_17 == val_6) goto label_17;     
            if(val_17 == val_6)
            {
                goto label_17;
            }
            // 0x011090B0: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x011090B4: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x011090B8: LDR x8, [x8, #0x540]       | X8 = 1152921504607965184;               
            // 0x011090BC: LDR x20, [x8]              | X20 = typeof(System.UInt16);            
            // 0x011090C0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011090C4: TBZ w8, #0, #0x11090d4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x011090C8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011090CC: CBNZ w8, #0x11090d4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x011090D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_19:
            // 0x011090D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011090D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011090DC: MOV x1, x20                | X1 = 1152921504607965184 (0x1000000000111000);//ML01
            // 0x011090E0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011090E4: CMP x19, x0                | STATE = COMPARE(realClsName, val_7)     
            // 0x011090E8: B.EQ #0x1109314            | if (val_17 == val_7) goto label_20;     
            if(val_17 == val_7)
            {
                goto label_20;
            }
            // 0x011090EC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x011090F0: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x011090F4: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x011090F8: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x011090FC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109100: TBZ w8, #0, #0x1109110     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x01109104: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109108: CBNZ w8, #0x1109110        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x0110910C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_22:
            // 0x01109110: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109114: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109118: MOV x1, x20                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x0110911C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109120: CMP x19, x0                | STATE = COMPARE(realClsName, val_8)     
            // 0x01109124: B.EQ #0x1109320            | if (val_17 == val_8) goto label_23;     
            if(val_17 == val_8)
            {
                goto label_23;
            }
            // 0x01109128: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110912C: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x01109130: LDR x8, [x8, #0x710]       | X8 = 1152921504608497664;               
            // 0x01109134: LDR x20, [x8]              | X20 = typeof(System.Double);            
            // 0x01109138: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110913C: TBZ w8, #0, #0x110914c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x01109140: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109144: CBNZ w8, #0x110914c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x01109148: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_25:
            // 0x0110914C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109154: MOV x1, x20                | X1 = 1152921504608497664 (0x1000000000193000);//ML01
            // 0x01109158: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110915C: CMP x19, x0                | STATE = COMPARE(realClsName, val_9)     
            // 0x01109160: B.EQ #0x110932c            | if (val_17 == val_9) goto label_26;     
            if(val_17 == val_9)
            {
                goto label_26;
            }
            // 0x01109164: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x01109168: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x0110916C: LDR x8, [x8, #0x468]       | X8 = 1152921504607805440;               
            // 0x01109170: LDR x20, [x8]              | X20 = typeof(System.Byte);              
            // 0x01109174: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109178: TBZ w8, #0, #0x1109188     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x0110917C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109180: CBNZ w8, #0x1109188        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x01109184: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x01109188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110918C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109190: MOV x1, x20                | X1 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x01109194: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109198: CMP x19, x0                | STATE = COMPARE(realClsName, val_10)    
            // 0x0110919C: B.EQ #0x1109338            | if (val_17 == val_10) goto label_29;    
            if(val_17 == val_10)
            {
                goto label_29;
            }
            // 0x011091A0: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x011091A4: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x011091A8: LDR x8, [x8, #0xa40]       | X8 = 1152921504607858688;               
            // 0x011091AC: LDR x20, [x8]              | X20 = typeof(System.SByte);             
            // 0x011091B0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011091B4: TBZ w8, #0, #0x11091c4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x011091B8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011091BC: CBNZ w8, #0x11091c4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x011091C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_31:
            // 0x011091C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011091C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011091CC: MOV x1, x20                | X1 = 1152921504607858688 (0x10000000000F7000);//ML01
            // 0x011091D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011091D4: CMP x19, x0                | STATE = COMPARE(realClsName, val_11)    
            // 0x011091D8: B.EQ #0x1109344            | if (val_17 == val_11) goto label_32;    
            if(val_17 == val_11)
            {
                goto label_32;
            }
            // 0x011091DC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x011091E0: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x011091E4: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x011091E8: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x011091EC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011091F0: TBZ w8, #0, #0x1109200     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x011091F4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011091F8: CBNZ w8, #0x1109200        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x011091FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x01109200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109204: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109208: MOV x1, x20                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x0110920C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109210: CMP x19, x0                | STATE = COMPARE(realClsName, val_12)    
            // 0x01109214: B.EQ #0x1109350            | if (val_17 == val_12) goto label_35;    
            if(val_17 == val_12)
            {
                goto label_35;
            }
            // 0x01109218: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0110921C: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x01109220: LDR x8, [x8, #0xcc8]       | X8 = 1152921504608231424;               
            // 0x01109224: LDR x20, [x8]              | X20 = typeof(System.Char);              
            // 0x01109228: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110922C: TBZ w8, #0, #0x110923c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x01109230: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109234: CBNZ w8, #0x110923c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x01109238: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_37:
            // 0x0110923C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109240: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109244: MOV x1, x20                | X1 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x01109248: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110924C: CMP x19, x0                | STATE = COMPARE(realClsName, val_13)    
            // 0x01109250: B.EQ #0x110935c            | if (val_17 == val_13) goto label_38;    
            if(val_17 == val_13)
            {
                goto label_38;
            }
            // 0x01109254: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x01109258: LDR x0, [x21]              | X0 = typeof(System.Type);               
            // 0x0110925C: LDR x8, [x8, #0x6a0]       | X8 = 1152921504607752192;               
            // 0x01109260: LDR x20, [x8]              | X20 = typeof(System.UInt64);            
            // 0x01109264: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109268: TBZ w8, #0, #0x1109278     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_40;
            // 0x0110926C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109270: CBNZ w8, #0x1109278        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
            // 0x01109274: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_40:
            // 0x01109278: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110927C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109280: MOV x1, x20                | X1 = 1152921504607752192 (0x10000000000DD000);//ML01
            // 0x01109284: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109288: CMP x19, x0                | STATE = COMPARE(realClsName, val_14)    
            // 0x0110928C: B.NE #0x1109378            | if (val_17 != val_14) goto label_41;    
            if(val_17 != val_14)
            {
                goto label_41;
            }
            // 0x01109290: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x01109294: LDR x8, [x8, #0x6d8]       | X8 = (string**)(1152921512830562544)("*(ulong*)&ptr_of_this_method->Value");
            val_18 = "*(ulong*)&ptr_of_this_method->Value";
            // 0x01109298: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_5:
            // 0x0110929C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x011092A0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x011092A4: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x011092A8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x011092AC: TBZ w8, #0, #0x11092bc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_44;
            // 0x011092B0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x011092B4: CBNZ w8, #0x11092bc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
            // 0x011092B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_44:
            // 0x011092BC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x011092C0: LDR x8, [x8, #0x668]       | X8 = (string**)(1152921512830562688)("({0})typeof({0}).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack))");
            // 0x011092C4: MOV x2, x20                | X2 = X2;//m1                            
            // 0x011092C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011092CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x011092D0: LDR x1, [x8]               | X1 = "({0})typeof({0}).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack))";
            // 0x011092D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011092D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011092DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011092E0: B #0x18a01bc               | return System.String.Format(format:  0, arg0:  "({0})typeof({0}).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack))");
            return System.String.Format(format:  0, arg0:  "({0})typeof({0}).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack))");
            label_8:
            // 0x011092E4: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x011092E8: LDR x8, [x8, #0xa90]       | X8 = (string**)(1152921512830562944)("ptr_of_this_method->Value");
            val_18 = "ptr_of_this_method->Value";
            // 0x011092EC: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_11:
            // 0x011092F0: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x011092F4: LDR x8, [x8, #0xc70]       | X8 = (string**)(1152921512830563072)("*(long*)&ptr_of_this_method->Value");
            val_18 = "*(long*)&ptr_of_this_method->Value";
            // 0x011092F8: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_14:
            // 0x011092FC: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x01109300: LDR x8, [x8, #0x7d0]       | X8 = (string**)(1152921512830563216)("(short)ptr_of_this_method->Value");
            val_18 = "(short)ptr_of_this_method->Value";
            // 0x01109304: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_17:
            // 0x01109308: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x0110930C: LDR x8, [x8, #0xbb8]       | X8 = (string**)(1152921512830563360)("ptr_of_this_method->Value == 1");
            val_18 = "ptr_of_this_method->Value == 1";
            // 0x01109310: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_20:
            // 0x01109314: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x01109318: LDR x8, [x8, #0xeb0]       | X8 = (string**)(1152921512830563488)("(ushort)ptr_of_this_method->Value");
            val_18 = "(ushort)ptr_of_this_method->Value";
            // 0x0110931C: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_23:
            // 0x01109320: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01109324: LDR x8, [x8, #0xe88]       | X8 = (string**)(1152921512830563632)("*(float*)&ptr_of_this_method->Value");
            val_18 = "*(float*)&ptr_of_this_method->Value";
            // 0x01109328: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_26:
            // 0x0110932C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01109330: LDR x8, [x8, #0xa18]       | X8 = (string**)(1152921512830563776)("*(double*)&ptr_of_this_method->Value");
            val_18 = "*(double*)&ptr_of_this_method->Value";
            // 0x01109334: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_29:
            // 0x01109338: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x0110933C: LDR x8, [x8, #0x320]       | X8 = (string**)(1152921512830563920)("(byte)ptr_of_this_method->Value");
            val_18 = "(byte)ptr_of_this_method->Value";
            // 0x01109340: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_32:
            // 0x01109344: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x01109348: LDR x8, [x8, #0xae8]       | X8 = (string**)(1152921512830564064)("(sbyte)ptr_of_this_method->Value");
            val_18 = "(sbyte)ptr_of_this_method->Value";
            // 0x0110934C: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_35:
            // 0x01109350: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x01109354: LDR x8, [x8, #0x248]       | X8 = (string**)(1152921512830564208)("(uint)ptr_of_this_method->Value");
            val_18 = "(uint)ptr_of_this_method->Value";
            // 0x01109358: B #0x1109364               |  goto label_54;                         
            goto label_54;
            label_38:
            // 0x0110935C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x01109360: LDR x8, [x8, #0x938]       | X8 = (string**)(1152921512830564352)("(char)ptr_of_this_method->Value");
            val_18 = "(char)ptr_of_this_method->Value";
            label_54:
            // 0x01109364: LDR x0, [x8]               | X0 = "(char)ptr_of_this_method->Value"; 
            // 0x01109368: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0110936C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01109370: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01109374: RET                        |  return (System.String)"(char)ptr_of_this_method->Value";
            return (string)val_18;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_41:
            // 0x01109378: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0110937C: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x01109380: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_15 = null;
            // 0x01109384: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x01109388: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110938C: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x01109390: BL #0x17014c0              | .ctor();                                
            val_15 = new System.NotImplementedException();
            // 0x01109394: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x01109398: LDR x8, [x8, #0x838]       | X8 = 1152921512830564496;               
            // 0x0110939C: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_16 = val_15;
            // 0x011093A0: LDR x1, [x8]               | X1 = static System.String ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetRetrieveValueCode(System.Type type, string realClsName);
            // 0x011093A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x011093A8: BL #0x10ec5ac              | .ctor(def:  static System.String ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetRetrieveValueCode(System.Type type, string realClsName), type:  0, domain:  null);
            val_16 = new ILRuntime.CLR.Method.CLRMethod(def:  static System.String ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetRetrieveValueCode(System.Type type, string realClsName), type:  0, domain:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x011093AC (17863596), len: 1712  VirtAddr: 0x011093AC RVA: 0x011093AC token: 100679923 methodIndex: 29210 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857250
        internal static void GetRefWriteBackValueCode(System.Type type, System.Text.StringBuilder sb, string paramName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_34;
            //  | 
            string val_35;
            // 0x011093AC: STP x24, x23, [sp, #-0x40]! | stack[1152921512830886272] = ???;  stack[1152921512830886280] = ???;  //  dest_result_addr=1152921512830886272 |  dest_result_addr=1152921512830886280
            // 0x011093B0: STP x22, x21, [sp, #0x10]  | stack[1152921512830886288] = ???;  stack[1152921512830886296] = ???;  //  dest_result_addr=1152921512830886288 |  dest_result_addr=1152921512830886296
            // 0x011093B4: STP x20, x19, [sp, #0x20]  | stack[1152921512830886304] = ???;  stack[1152921512830886312] = ???;  //  dest_result_addr=1152921512830886304 |  dest_result_addr=1152921512830886312
            // 0x011093B8: STP x29, x30, [sp, #0x30]  | stack[1152921512830886320] = ???;  stack[1152921512830886328] = ???;  //  dest_result_addr=1152921512830886320 |  dest_result_addr=1152921512830886328
            // 0x011093BC: ADD x29, sp, #0x30         | X29 = (1152921512830886272 + 48) = 1152921512830886320 (0x10000001EA30E1B0);
            // 0x011093C0: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x011093C4: LDRB w8, [x22, #0xb99]     | W8 = (bool)static_value_03735B99;       
            // 0x011093C8: MOV x20, x3                | X20 = X3;//m1                           
            // 0x011093CC: MOV x19, x2                | X19 = paramName;//m1                    
            // 0x011093D0: MOV x21, x1                | X21 = sb;//m1                           
            // 0x011093D4: TBNZ w8, #0, #0x11093f0    | if (static_value_03735B99 == true) goto label_0;
            // 0x011093D8: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x011093DC: LDR x8, [x8, #0x520]       | X8 = 0x2B8F550;                         
            // 0x011093E0: LDR w0, [x8]               | W0 = 0x1416;                            
            // 0x011093E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1416, ????);     
            // 0x011093E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x011093EC: STRB w8, [x22, #0xb99]     | static_value_03735B99 = true;            //  dest_result_addr=57891737
            label_0:
            // 0x011093F0: CBNZ x21, #0x11093f8       | if (sb != null) goto label_1;           
            if(sb != null)
            {
                goto label_1;
            }
            // 0x011093F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1416, ????);     
            label_1:
            // 0x011093F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011093FC: MOV x0, x21                | X0 = sb;//m1                            
            // 0x01109400: BL #0x1b6d41c              | X0 = sb.get_IsPrimitive();              
            bool val_1 = sb.IsPrimitive;
            // 0x01109404: TBZ w0, #0, #0x110972c     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x01109408: ADRP x23, #0x3620000       | X23 = 56754176 (0x3620000);             
            // 0x0110940C: LDR x23, [x23, #0x340]     | X23 = 1152921504609562624;              
            // 0x01109410: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x01109414: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109418: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x0110941C: LDR x22, [x8]              | X22 = typeof(System.Int32);             
            // 0x01109420: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109424: TBZ w8, #0, #0x1109434     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01109428: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110942C: CBNZ w8, #0x1109434        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01109430: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01109434: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110943C: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x01109440: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109444: CMP x0, x21                | STATE = COMPARE(val_2, sb)              
            // 0x01109448: B.EQ #0x1109774            | if (val_2 == sb) goto label_29;         
            if(val_2 == sb)
            {
                goto label_29;
            }
            // 0x0110944C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x01109450: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109454: LDR x8, [x8, #0xc08]       | X8 = 1152921504607592448;               
            // 0x01109458: LDR x22, [x8]              | X22 = typeof(System.Int64);             
            // 0x0110945C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109460: TBZ w8, #0, #0x1109470     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01109464: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109468: CBNZ w8, #0x1109470        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0110946C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x01109470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109478: MOV x1, x22                | X1 = 1152921504607592448 (0x10000000000B6000);//ML01
            // 0x0110947C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109480: CMP x0, x21                | STATE = COMPARE(val_3, sb)              
            // 0x01109484: B.EQ #0x1109820            | if (val_3 == sb) goto label_8;          
            if(val_3 == sb)
            {
                goto label_8;
            }
            // 0x01109488: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0110948C: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109490: LDR x8, [x8, #0x908]       | X8 = 1152921504607911936;               
            // 0x01109494: LDR x22, [x8]              | X22 = typeof(System.Int16);             
            // 0x01109498: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110949C: TBZ w8, #0, #0x11094ac     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x011094A0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011094A4: CBNZ w8, #0x11094ac        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x011094A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x011094AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011094B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011094B4: MOV x1, x22                | X1 = 1152921504607911936 (0x1000000000104000);//ML01
            // 0x011094B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011094BC: CMP x0, x21                | STATE = COMPARE(val_4, sb)              
            // 0x011094C0: B.EQ #0x1109774            | if (val_4 == sb) goto label_29;         
            if(val_4 == sb)
            {
                goto label_29;
            }
            // 0x011094C4: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x011094C8: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x011094CC: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x011094D0: LDR x22, [x8]              | X22 = typeof(System.Boolean);           
            // 0x011094D4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011094D8: TBZ w8, #0, #0x11094e8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x011094DC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011094E0: CBNZ w8, #0x11094e8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x011094E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x011094E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011094EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011094F0: MOV x1, x22                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x011094F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011094F8: CMP x0, x21                | STATE = COMPARE(val_5, sb)              
            // 0x011094FC: B.EQ #0x11098d8            | if (val_5 == sb) goto label_14;         
            if(val_5 == sb)
            {
                goto label_14;
            }
            // 0x01109500: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x01109504: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109508: LDR x8, [x8, #0x540]       | X8 = 1152921504607965184;               
            // 0x0110950C: LDR x22, [x8]              | X22 = typeof(System.UInt16);            
            // 0x01109510: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109514: TBZ w8, #0, #0x1109524     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x01109518: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110951C: CBNZ w8, #0x1109524        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x01109520: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_16:
            // 0x01109524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109528: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110952C: MOV x1, x22                | X1 = 1152921504607965184 (0x1000000000111000);//ML01
            // 0x01109530: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109534: CMP x0, x21                | STATE = COMPARE(val_6, sb)              
            // 0x01109538: B.EQ #0x1109774            | if (val_6 == sb) goto label_29;         
            if(val_6 == sb)
            {
                goto label_29;
            }
            // 0x0110953C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x01109540: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109544: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x01109548: LDR x22, [x8]              | X22 = typeof(System.Single);            
            // 0x0110954C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109550: TBZ w8, #0, #0x1109560     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x01109554: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109558: CBNZ w8, #0x1109560        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x0110955C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_19:
            // 0x01109560: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109564: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109568: MOV x1, x22                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x0110956C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109570: CMP x0, x21                | STATE = COMPARE(val_7, sb)              
            // 0x01109574: B.EQ #0x1109944            | if (val_7 == sb) goto label_20;         
            if(val_7 == sb)
            {
                goto label_20;
            }
            // 0x01109578: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110957C: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109580: LDR x8, [x8, #0x710]       | X8 = 1152921504608497664;               
            // 0x01109584: LDR x22, [x8]              | X22 = typeof(System.Double);            
            // 0x01109588: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110958C: TBZ w8, #0, #0x110959c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x01109590: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109594: CBNZ w8, #0x110959c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x01109598: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_22:
            // 0x0110959C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011095A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011095A4: MOV x1, x22                | X1 = 1152921504608497664 (0x1000000000193000);//ML01
            // 0x011095A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011095AC: CMP x0, x21                | STATE = COMPARE(val_8, sb)              
            // 0x011095B0: B.EQ #0x1109990            | if (val_8 == sb) goto label_23;         
            if(val_8 == sb)
            {
                goto label_23;
            }
            // 0x011095B4: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x011095B8: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x011095BC: LDR x8, [x8, #0x468]       | X8 = 1152921504607805440;               
            // 0x011095C0: LDR x22, [x8]              | X22 = typeof(System.Byte);              
            // 0x011095C4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011095C8: TBZ w8, #0, #0x11095d8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x011095CC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011095D0: CBNZ w8, #0x11095d8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x011095D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_25:
            // 0x011095D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011095DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011095E0: MOV x1, x22                | X1 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x011095E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011095E8: CMP x0, x21                | STATE = COMPARE(val_9, sb)              
            // 0x011095EC: B.EQ #0x1109774            | if (val_9 == sb) goto label_29;         
            if(val_9 == sb)
            {
                goto label_29;
            }
            // 0x011095F0: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x011095F4: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x011095F8: LDR x8, [x8, #0xa40]       | X8 = 1152921504607858688;               
            // 0x011095FC: LDR x22, [x8]              | X22 = typeof(System.SByte);             
            // 0x01109600: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109604: TBZ w8, #0, #0x1109614     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x01109608: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110960C: CBNZ w8, #0x1109614        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x01109610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x01109614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110961C: MOV x1, x22                | X1 = 1152921504607858688 (0x10000000000F7000);//ML01
            // 0x01109620: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109624: CMP x0, x21                | STATE = COMPARE(val_10, sb)             
            // 0x01109628: B.EQ #0x1109774            | if (val_10 == sb) goto label_29;        
            if(val_10 == sb)
            {
                goto label_29;
            }
            // 0x0110962C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x01109630: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109634: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x01109638: LDR x22, [x8]              | X22 = typeof(System.UInt32);            
            // 0x0110963C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109640: TBZ w8, #0, #0x1109650     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x01109644: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109648: CBNZ w8, #0x1109650        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x0110964C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_31:
            // 0x01109650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109654: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109658: MOV x1, x22                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x0110965C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109660: CMP x0, x21                | STATE = COMPARE(val_11, sb)             
            // 0x01109664: B.EQ #0x11099dc            | if (val_11 == sb) goto label_35;        
            if(val_11 == sb)
            {
                goto label_35;
            }
            // 0x01109668: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0110966C: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x01109670: LDR x8, [x8, #0xcc8]       | X8 = 1152921504608231424;               
            // 0x01109674: LDR x22, [x8]              | X22 = typeof(System.Char);              
            // 0x01109678: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110967C: TBZ w8, #0, #0x110968c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x01109680: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109684: CBNZ w8, #0x110968c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x01109688: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x0110968C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109694: MOV x1, x22                | X1 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x01109698: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110969C: CMP x0, x21                | STATE = COMPARE(val_12, sb)             
            // 0x011096A0: B.EQ #0x11099dc            | if (val_12 == sb) goto label_35;        
            if(val_12 == sb)
            {
                goto label_35;
            }
            // 0x011096A4: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x011096A8: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x011096AC: LDR x8, [x8, #0x6a0]       | X8 = 1152921504607752192;               
            // 0x011096B0: LDR x22, [x8]              | X22 = typeof(System.UInt64);            
            // 0x011096B4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011096B8: TBZ w8, #0, #0x11096c8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x011096BC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011096C0: CBNZ w8, #0x11096c8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x011096C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_37:
            // 0x011096C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011096CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011096D0: MOV x1, x22                | X1 = 1152921504607752192 (0x10000000000DD000);//ML01
            // 0x011096D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x011096D8: CMP x0, x21                | STATE = COMPARE(val_13, sb)             
            // 0x011096DC: B.NE #0x1109a28            | if (val_13 != sb) goto label_38;        
            if(val_13 != sb)
            {
                goto label_38;
            }
            // 0x011096E0: CBNZ x19, #0x11096e8       | if (paramName != null) goto label_39;   
            if(paramName != null)
            {
                goto label_39;
            }
            // 0x011096E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_39:
            // 0x011096E8: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x011096EC: LDR x8, [x8, #0xb88]       | X8 = (string**)(1152921512830796304)("                        ___dst->ObjectType = ObjectTypes.Long;");
            // 0x011096F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011096F4: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x011096F8: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Long;";
            // 0x011096FC: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Long;");
            System.Text.StringBuilder val_14 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Long;");
            // 0x01109700: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01109704: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01109708: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110970C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109710: TBZ w8, #0, #0x1109720     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_41;
            // 0x01109714: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01109718: CBNZ w8, #0x1109720        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x0110971C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_41:
            // 0x01109720: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x01109724: LDR x8, [x8, #0xf60]       | X8 = (string**)(1152921512830800592)("                        *(ulong*)&___dst->Value = @");
            val_34 = "                        *(ulong*)&___dst->Value = @";
            // 0x01109728: B #0x1109868               |  goto label_70;                         
            goto label_70;
            label_2:
            // 0x0110972C: CBZ x19, #0x11097c0        | if (paramName == null) goto label_43;   
            if(paramName == null)
            {
                goto label_43;
            }
            // 0x01109730: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x01109734: LDR x8, [x8, #0xcb8]       | X8 = (string**)(1152921512830800768)("                        object ___obj = @");
            // 0x01109738: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110973C: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x01109740: LDR x1, [x8]               | X1 = "                        object ___obj = @";
            // 0x01109744: BL #0x1b5b818              | X0 = paramName.Append(value:  "                        object ___obj = @");
            System.Text.StringBuilder val_15 = paramName.Append(value:  "                        object ___obj = @");
            // 0x01109748: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110974C: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x01109750: MOV x1, x20                | X1 = X3;//m1                            
            // 0x01109754: BL #0x1b5b818              | X0 = paramName.Append(value:  X3);      
            System.Text.StringBuilder val_16 = paramName.Append(value:  X3);
            // 0x01109758: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x0110975C: LDR x8, [x8, #0x608]       | X8 = (string**)(1152921512830809120)(";");
            // 0x01109760: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109764: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x01109768: LDR x1, [x8]               | X1 = ";";                               
            // 0x0110976C: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  ";"); 
            System.Text.StringBuilder val_17 = paramName.AppendLine(value:  ";");
            // 0x01109770: B #0x1109810               |  goto label_44;                         
            goto label_44;
            label_29:
            // 0x01109774: CBNZ x19, #0x110977c       | if (paramName != null) goto label_45;   
            if(paramName != null)
            {
                goto label_45;
            }
            // 0x01109778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_45:
            // 0x0110977C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x01109780: LDR x8, [x8, #0x5e0]       | X8 = (string**)(1152921512830813296)("                        ___dst->ObjectType = ObjectTypes.Integer;");
            // 0x01109784: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109788: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x0110978C: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Integer;";
            // 0x01109790: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_18 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Integer;");
            // 0x01109794: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01109798: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110979C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x011097A0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x011097A4: TBZ w8, #0, #0x11097b4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x011097A8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x011097AC: CBNZ w8, #0x11097b4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x011097B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_47:
            // 0x011097B4: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x011097B8: LDR x8, [x8, #0x830]       | X8 = (string**)(1152921512830817600)("                        ___dst->Value = @");
            val_34 = "                        ___dst->Value = @";
            // 0x011097BC: B #0x1109868               |  goto label_70;                         
            goto label_70;
            label_43:
            // 0x011097C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x011097C4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x011097C8: LDR x8, [x8, #0xcb8]       | X8 = (string**)(1152921512830800768)("                        object ___obj = @");
            // 0x011097CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011097D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011097D4: LDR x1, [x8]               | X1 = "                        object ___obj = @";
            // 0x011097D8: BL #0x1b5b818              | X0 = 0.Append(value:  "                        object ___obj = @");
            System.Text.StringBuilder val_19 = 0.Append(value:  "                        object ___obj = @");
            // 0x011097DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            // 0x011097E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011097E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011097E8: MOV x1, x20                | X1 = X3;//m1                            
            // 0x011097EC: BL #0x1b5b818              | X0 = 0.Append(value:  X3);              
            System.Text.StringBuilder val_20 = 0.Append(value:  X3);
            // 0x011097F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            // 0x011097F4: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x011097F8: LDR x8, [x8, #0x608]       | X8 = (string**)(1152921512830809120)(";");
            // 0x011097FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109800: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109804: LDR x1, [x8]               | X1 = ";";                               
            // 0x01109808: BL #0x1b5c068              | X0 = 0.AppendLine(value:  ";");         
            System.Text.StringBuilder val_21 = 0.AppendLine(value:  ";");
            // 0x0110980C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_44:
            // 0x01109810: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x01109814: LDR x8, [x8, #0xc08]       | X8 = (string**)(1152921512830830048)("                        if (___dst->ObjectType >= ObjectTypes.Object)\n                        {\n                            if (___obj is CrossBindingAdaptorType)\n                                ___obj = ((CrossBindingAdaptorType)___obj).ILInstance;\n                            __mStack[___dst->Value] = ___obj;\n                        }\n                        else\n                        {\n                            ILIntepreter.UnboxObject(___dst, 
            val_35 = "                        if (___dst->ObjectType >= ObjectTypes.Object)\n                        {\n                            if (___obj is CrossBindingAdaptorType)\n                                ___obj = ((CrossBindingAdaptorType)___obj).ILInstance;\n                            __mStack[___dst->Value] = ___obj;\n                        }\n                        else\n                        {\n                            ILIntepreter.UnboxObject(___dst, ___obj, __mStack, __domain);\n                        }";
            // 0x01109818: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110981C: B #0x11098bc               |  goto label_49;                         
            goto label_49;
            label_8:
            // 0x01109820: CBNZ x19, #0x1109828       | if (paramName != null) goto label_50;   
            if(paramName != null)
            {
                goto label_50;
            }
            // 0x01109824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_50:
            // 0x01109828: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x0110982C: LDR x8, [x8, #0xb88]       | X8 = (string**)(1152921512830796304)("                        ___dst->ObjectType = ObjectTypes.Long;");
            // 0x01109830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109834: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x01109838: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Long;";
            // 0x0110983C: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Long;");
            System.Text.StringBuilder val_22 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Long;");
            // 0x01109840: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01109844: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01109848: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110984C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109850: TBZ w8, #0, #0x1109860     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_52;
            // 0x01109854: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01109858: CBNZ w8, #0x1109860        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
            // 0x0110985C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_52:
            // 0x01109860: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x01109864: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921512830835248)("                        *(long*)&___dst->Value = @");
            val_34 = "                        *(long*)&___dst->Value = @";
            label_70:
            // 0x01109868: LDR x1, [x8]               | X1 = "                        *(long*)&___dst->Value = @";
            // 0x0110986C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109870: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01109874: MOV x2, x20                | X2 = X3;//m1                            
            // 0x01109878: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_34 = "                        *(long*)&___dst->Value = @");
            string val_23 = System.String.Concat(str0:  0, str1:  val_34);
            label_58:
            // 0x0110987C: MOV x20, x0                | X20 = val_23;//m1                       
            // 0x01109880: CBZ x19, #0x1109898        | if (paramName == null) goto label_53;   
            if(paramName == null)
            {
                goto label_53;
            }
            // 0x01109884: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109888: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x0110988C: MOV x1, x20                | X1 = val_23;//m1                        
            // 0x01109890: BL #0x1b5b818              | X0 = paramName.Append(value:  val_23);  
            System.Text.StringBuilder val_24 = paramName.Append(value:  val_23);
            // 0x01109894: B #0x11098b0               |  goto label_54;                         
            goto label_54;
            label_53:
            // 0x01109898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            // 0x0110989C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011098A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011098A4: MOV x1, x20                | X1 = val_23;//m1                        
            // 0x011098A8: BL #0x1b5b818              | X0 = 0.Append(value:  val_23);          
            System.Text.StringBuilder val_25 = 0.Append(value:  val_23);
            // 0x011098AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_54:
            // 0x011098B0: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x011098B4: LDR x8, [x8, #0x608]       | X8 = (string**)(1152921512830809120)(";");
            val_35 = ";";
            // 0x011098B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            label_49:
            // 0x011098BC: LDR x1, [x8]               | X1 = ";";                               
            // 0x011098C0: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x011098C4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x011098C8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x011098CC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x011098D0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x011098D4: B #0x1b5c068               | X0 = paramName.AppendLine(value:  val_35 = ";"); return;
            System.Text.StringBuilder val_26 = paramName.AppendLine(value:  val_35);
            return;
            label_14:
            // 0x011098D8: CBNZ x19, #0x11098e0       | if (paramName != null) goto label_55;   
            if(paramName != null)
            {
                goto label_55;
            }
            // 0x011098DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_55:
            // 0x011098E0: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x011098E4: LDR x8, [x8, #0x5e0]       | X8 = (string**)(1152921512830813296)("                        ___dst->ObjectType = ObjectTypes.Integer;");
            // 0x011098E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011098EC: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x011098F0: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Integer;";
            // 0x011098F4: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_27 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Integer;");
            // 0x011098F8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x011098FC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01109900: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01109904: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109908: TBZ w8, #0, #0x1109918     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_57;
            // 0x0110990C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01109910: CBNZ w8, #0x1109918        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
            // 0x01109914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_57:
            // 0x01109918: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x0110991C: ADRP x9, #0x35bc000        | X9 = 56344576 (0x35BC000);              
            // 0x01109920: LDR x8, [x8, #0x830]       | X8 = (string**)(1152921512830817600)("                        ___dst->Value = @");
            // 0x01109924: LDR x9, [x9, #0x550]       | X9 = (string**)(1152921512830855904)(" ? 1 : 0;");
            // 0x01109928: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110992C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01109930: LDR x1, [x8]               | X1 = "                        ___dst->Value = @";
            // 0x01109934: LDR x3, [x9]               | X3 = " ? 1 : 0;";                       
            // 0x01109938: MOV x2, x20                | X2 = X3;//m1                            
            // 0x0110993C: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "                        ___dst->Value = @", str2:  X3);
            string val_28 = System.String.Concat(str0:  0, str1:  "                        ___dst->Value = @", str2:  X3);
            // 0x01109940: B #0x110987c               |  goto label_58;                         
            goto label_58;
            label_20:
            // 0x01109944: CBNZ x19, #0x110994c       | if (paramName != null) goto label_59;   
            if(paramName != null)
            {
                goto label_59;
            }
            // 0x01109948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_59:
            // 0x0110994C: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x01109950: LDR x8, [x8, #0xe60]       | X8 = (string**)(1152921512830860096)("                        ___dst->ObjectType = ObjectTypes.Float;");
            // 0x01109954: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109958: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x0110995C: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Float;";
            // 0x01109960: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Float;");
            System.Text.StringBuilder val_29 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Float;");
            // 0x01109964: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01109968: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110996C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01109970: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109974: TBZ w8, #0, #0x1109984     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_61;
            // 0x01109978: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110997C: CBNZ w8, #0x1109984        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x01109980: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_61:
            // 0x01109984: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x01109988: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921512830864400)("                        *(float*)&___dst->Value = @");
            // 0x0110998C: B #0x1109868               |  goto label_70;                         
            goto label_70;
            label_23:
            // 0x01109990: CBNZ x19, #0x1109998       | if (paramName != null) goto label_63;   
            if(paramName != null)
            {
                goto label_63;
            }
            // 0x01109994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_63:
            // 0x01109998: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x0110999C: LDR x8, [x8, #0x970]       | X8 = (string**)(1152921512830864576)("                        ___dst->ObjectType = ObjectTypes.Double;");
            // 0x011099A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011099A4: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x011099A8: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Double;";
            // 0x011099AC: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Double;");
            System.Text.StringBuilder val_30 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Double;");
            // 0x011099B0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x011099B4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x011099B8: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x011099BC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x011099C0: TBZ w8, #0, #0x11099d0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
            // 0x011099C4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x011099C8: CBNZ w8, #0x11099d0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
            // 0x011099CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_65:
            // 0x011099D0: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x011099D4: LDR x8, [x8, #0x6b0]       | X8 = (string**)(1152921512830868880)("                        *(double*)&___dst->Value = @");
            // 0x011099D8: B #0x1109868               |  goto label_70;                         
            goto label_70;
            label_35:
            // 0x011099DC: CBNZ x19, #0x11099e4       | if (paramName != null) goto label_67;   
            if(paramName != null)
            {
                goto label_67;
            }
            // 0x011099E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_67:
            // 0x011099E4: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x011099E8: LDR x8, [x8, #0x5e0]       | X8 = (string**)(1152921512830813296)("                        ___dst->ObjectType = ObjectTypes.Integer;");
            // 0x011099EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011099F0: MOV x0, x19                | X0 = paramName;//m1                     
            // 0x011099F4: LDR x1, [x8]               | X1 = "                        ___dst->ObjectType = ObjectTypes.Integer;";
            // 0x011099F8: BL #0x1b5c068              | X0 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_31 = paramName.AppendLine(value:  "                        ___dst->ObjectType = ObjectTypes.Integer;");
            // 0x011099FC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01109A00: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01109A04: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01109A08: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109A0C: TBZ w8, #0, #0x1109a1c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_69;
            // 0x01109A10: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01109A14: CBNZ w8, #0x1109a1c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
            // 0x01109A18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_69:
            // 0x01109A1C: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x01109A20: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921512830873152)("                        ___dst->Value = (int)@");
            // 0x01109A24: B #0x1109868               |  goto label_70;                         
            goto label_70;
            label_38:
            // 0x01109A28: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01109A2C: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x01109A30: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_32 = null;
            // 0x01109A34: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x01109A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01109A3C: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x01109A40: BL #0x17014c0              | .ctor();                                
            val_32 = new System.NotImplementedException();
            // 0x01109A44: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x01109A48: LDR x8, [x8, #0x508]       | X8 = 1152921512830873312;               
            // 0x01109A4C: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_33 = val_32;
            // 0x01109A50: LDR x1, [x8]               | X1 = static System.Void ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetRefWriteBackValueCode(System.Type type, System.Text.StringBuilder sb, string paramName);
            // 0x01109A54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x01109A58: BL #0x10ec5ac              | .ctor(def:  static System.Void ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetRefWriteBackValueCode(System.Type type, System.Text.StringBuilder sb, string paramName), type:  0, domain:  null);
            val_33 = new ILRuntime.CLR.Method.CLRMethod(def:  static System.Void ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetRefWriteBackValueCode(System.Type type, System.Text.StringBuilder sb, string paramName), type:  0, domain:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x01109A5C (17865308), len: 2080  VirtAddr: 0x01109A5C RVA: 0x01109A5C token: 100679924 methodIndex: 29211 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857260
        internal static void GetReturnValueCode(System.Type type, System.Text.StringBuilder sb, ILRuntime.Runtime.Enviorment.AppDomain domain)
        {
            //
            // Disasemble & Code
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            string val_46;
            //  | 
            string val_47;
            //  | 
            object val_48;
            //  | 
            string val_49;
            // 0x01109A5C: STP x24, x23, [sp, #-0x40]! | stack[1152921512831301808] = ???;  stack[1152921512831301816] = ???;  //  dest_result_addr=1152921512831301808 |  dest_result_addr=1152921512831301816
            // 0x01109A60: STP x22, x21, [sp, #0x10]  | stack[1152921512831301824] = ???;  stack[1152921512831301832] = ???;  //  dest_result_addr=1152921512831301824 |  dest_result_addr=1152921512831301832
            // 0x01109A64: STP x20, x19, [sp, #0x20]  | stack[1152921512831301840] = ???;  stack[1152921512831301848] = ???;  //  dest_result_addr=1152921512831301840 |  dest_result_addr=1152921512831301848
            // 0x01109A68: STP x29, x30, [sp, #0x30]  | stack[1152921512831301856] = ???;  stack[1152921512831301864] = ???;  //  dest_result_addr=1152921512831301856 |  dest_result_addr=1152921512831301864
            // 0x01109A6C: ADD x29, sp, #0x30         | X29 = (1152921512831301808 + 48) = 1152921512831301856 (0x10000001EA3738E0);
            // 0x01109A70: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x01109A74: LDRB w8, [x21, #0xb9a]     | W8 = (bool)static_value_03735B9A;       
            // 0x01109A78: MOV x22, x3                | X22 = X3;//m1                           
            // 0x01109A7C: MOV x19, x2                | X19 = domain;//m1                       
            // 0x01109A80: MOV x20, x1                | X20 = sb;//m1                           
            // 0x01109A84: TBNZ w8, #0, #0x1109aa0    | if (static_value_03735B9A == true) goto label_0;
            // 0x01109A88: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01109A8C: LDR x8, [x8, #0x978]       | X8 = 0x2B8F558;                         
            // 0x01109A90: LDR w0, [x8]               | W0 = 0x1418;                            
            // 0x01109A94: BL #0x2782188              | X0 = sub_2782188( ?? 0x1418, ????);     
            // 0x01109A98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01109A9C: STRB w8, [x21, #0xb9a]     | static_value_03735B9A = true;            //  dest_result_addr=57891738
            label_0:
            // 0x01109AA0: CBNZ x20, #0x1109aa8       | if (sb != null) goto label_1;           
            if(sb != null)
            {
                goto label_1;
            }
            // 0x01109AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1418, ????);     
            label_1:
            // 0x01109AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01109AAC: MOV x0, x20                | X0 = sb;//m1                            
            // 0x01109AB0: BL #0x1b6d41c              | X0 = sb.get_IsPrimitive();              
            bool val_1 = sb.IsPrimitive;
            // 0x01109AB4: TBZ w0, #0, #0x1109db0     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x01109AB8: ADRP x22, #0x3620000       | X22 = 56754176 (0x3620000);             
            // 0x01109ABC: LDR x22, [x22, #0x340]     | X22 = 1152921504609562624;              
            // 0x01109AC0: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x01109AC4: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109AC8: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x01109ACC: LDR x21, [x8]              | X21 = typeof(System.Int32);             
            val_44 = null;
            // 0x01109AD0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109AD4: TBZ w8, #0, #0x1109ae4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01109AD8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109ADC: CBNZ w8, #0x1109ae4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01109AE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x01109AE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109AE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109AEC: MOV x1, x21                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x01109AF0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109AF4: CMP x0, x20                | STATE = COMPARE(val_2, sb)              
            // 0x01109AF8: B.EQ #0x1109e20            | if (val_2 == sb) goto label_29;         
            if(val_2 == sb)
            {
                goto label_29;
            }
            // 0x01109AFC: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x01109B00: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109B04: LDR x8, [x8, #0xc08]       | X8 = 1152921504607592448;               
            // 0x01109B08: LDR x21, [x8]              | X21 = typeof(System.Int64);             
            val_44 = null;
            // 0x01109B0C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109B10: TBZ w8, #0, #0x1109b20     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01109B14: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109B18: CBNZ w8, #0x1109b20        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01109B1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x01109B20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109B24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109B28: MOV x1, x21                | X1 = 1152921504607592448 (0x10000000000B6000);//ML01
            // 0x01109B2C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109B30: CMP x0, x20                | STATE = COMPARE(val_3, sb)              
            // 0x01109B34: B.EQ #0x1109ee8            | if (val_3 == sb) goto label_8;          
            if(val_3 == sb)
            {
                goto label_8;
            }
            // 0x01109B38: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x01109B3C: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109B40: LDR x8, [x8, #0x908]       | X8 = 1152921504607911936;               
            // 0x01109B44: LDR x21, [x8]              | X21 = typeof(System.Int16);             
            val_44 = null;
            // 0x01109B48: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109B4C: TBZ w8, #0, #0x1109b5c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01109B50: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109B54: CBNZ w8, #0x1109b5c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x01109B58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x01109B5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109B60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109B64: MOV x1, x21                | X1 = 1152921504607911936 (0x1000000000104000);//ML01
            // 0x01109B68: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109B6C: CMP x0, x20                | STATE = COMPARE(val_4, sb)              
            // 0x01109B70: B.EQ #0x1109e20            | if (val_4 == sb) goto label_29;         
            if(val_4 == sb)
            {
                goto label_29;
            }
            // 0x01109B74: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x01109B78: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109B7C: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x01109B80: LDR x21, [x8]              | X21 = typeof(System.Boolean);           
            val_44 = null;
            // 0x01109B84: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109B88: TBZ w8, #0, #0x1109b98     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x01109B8C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109B90: CBNZ w8, #0x1109b98        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x01109B94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x01109B98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109B9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109BA0: MOV x1, x21                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x01109BA4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109BA8: CMP x0, x20                | STATE = COMPARE(val_5, sb)              
            // 0x01109BAC: B.EQ #0x1109fbc            | if (val_5 == sb) goto label_14;         
            if(val_5 == sb)
            {
                goto label_14;
            }
            // 0x01109BB0: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x01109BB4: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109BB8: LDR x8, [x8, #0x540]       | X8 = 1152921504607965184;               
            // 0x01109BBC: LDR x21, [x8]              | X21 = typeof(System.UInt16);            
            val_44 = null;
            // 0x01109BC0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109BC4: TBZ w8, #0, #0x1109bd4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x01109BC8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109BCC: CBNZ w8, #0x1109bd4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x01109BD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_16:
            // 0x01109BD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109BD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109BDC: MOV x1, x21                | X1 = 1152921504607965184 (0x1000000000111000);//ML01
            // 0x01109BE0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109BE4: CMP x0, x20                | STATE = COMPARE(val_6, sb)              
            // 0x01109BE8: B.EQ #0x1109e20            | if (val_6 == sb) goto label_29;         
            if(val_6 == sb)
            {
                goto label_29;
            }
            // 0x01109BEC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x01109BF0: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109BF4: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x01109BF8: LDR x21, [x8]              | X21 = typeof(System.Single);            
            val_44 = null;
            // 0x01109BFC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109C00: TBZ w8, #0, #0x1109c10     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x01109C04: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109C08: CBNZ w8, #0x1109c10        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x01109C0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_19:
            // 0x01109C10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109C14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109C18: MOV x1, x21                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x01109C1C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109C20: CMP x0, x20                | STATE = COMPARE(val_7, sb)              
            // 0x01109C24: B.EQ #0x110a0ac            | if (val_7 == sb) goto label_20;         
            if(val_7 == sb)
            {
                goto label_20;
            }
            // 0x01109C28: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01109C2C: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109C30: LDR x8, [x8, #0x710]       | X8 = 1152921504608497664;               
            // 0x01109C34: LDR x21, [x8]              | X21 = typeof(System.Double);            
            val_44 = null;
            // 0x01109C38: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109C3C: TBZ w8, #0, #0x1109c4c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x01109C40: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109C44: CBNZ w8, #0x1109c4c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x01109C48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_22:
            // 0x01109C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109C54: MOV x1, x21                | X1 = 1152921504608497664 (0x1000000000193000);//ML01
            // 0x01109C58: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109C5C: CMP x0, x20                | STATE = COMPARE(val_8, sb)              
            // 0x01109C60: B.EQ #0x110a0f8            | if (val_8 == sb) goto label_23;         
            if(val_8 == sb)
            {
                goto label_23;
            }
            // 0x01109C64: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x01109C68: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109C6C: LDR x8, [x8, #0x468]       | X8 = 1152921504607805440;               
            // 0x01109C70: LDR x21, [x8]              | X21 = typeof(System.Byte);              
            val_44 = null;
            // 0x01109C74: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109C78: TBZ w8, #0, #0x1109c88     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x01109C7C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109C80: CBNZ w8, #0x1109c88        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x01109C84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_25:
            // 0x01109C88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109C8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109C90: MOV x1, x21                | X1 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x01109C94: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109C98: CMP x0, x20                | STATE = COMPARE(val_9, sb)              
            // 0x01109C9C: B.EQ #0x1109e20            | if (val_9 == sb) goto label_29;         
            if(val_9 == sb)
            {
                goto label_29;
            }
            // 0x01109CA0: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x01109CA4: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109CA8: LDR x8, [x8, #0xa40]       | X8 = 1152921504607858688;               
            // 0x01109CAC: LDR x21, [x8]              | X21 = typeof(System.SByte);             
            val_44 = null;
            // 0x01109CB0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109CB4: TBZ w8, #0, #0x1109cc4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x01109CB8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109CBC: CBNZ w8, #0x1109cc4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x01109CC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_28:
            // 0x01109CC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109CC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109CCC: MOV x1, x21                | X1 = 1152921504607858688 (0x10000000000F7000);//ML01
            // 0x01109CD0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109CD4: CMP x0, x20                | STATE = COMPARE(val_10, sb)             
            // 0x01109CD8: B.EQ #0x1109e20            | if (val_10 == sb) goto label_29;        
            if(val_10 == sb)
            {
                goto label_29;
            }
            // 0x01109CDC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x01109CE0: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109CE4: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x01109CE8: LDR x21, [x8]              | X21 = typeof(System.UInt32);            
            val_44 = null;
            // 0x01109CEC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109CF0: TBZ w8, #0, #0x1109d00     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x01109CF4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109CF8: CBNZ w8, #0x1109d00        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x01109CFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_31:
            // 0x01109D00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109D08: MOV x1, x21                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x01109D0C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109D10: CMP x0, x20                | STATE = COMPARE(val_11, sb)             
            // 0x01109D14: B.EQ #0x110a144            | if (val_11 == sb) goto label_35;        
            if(val_11 == sb)
            {
                goto label_35;
            }
            // 0x01109D18: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01109D1C: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109D20: LDR x8, [x8, #0xcc8]       | X8 = 1152921504608231424;               
            // 0x01109D24: LDR x21, [x8]              | X21 = typeof(System.Char);              
            val_44 = null;
            // 0x01109D28: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109D2C: TBZ w8, #0, #0x1109d3c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x01109D30: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109D34: CBNZ w8, #0x1109d3c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x01109D38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x01109D3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109D40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109D44: MOV x1, x21                | X1 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x01109D48: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109D4C: CMP x0, x20                | STATE = COMPARE(val_12, sb)             
            // 0x01109D50: B.EQ #0x110a144            | if (val_12 == sb) goto label_35;        
            if(val_12 == sb)
            {
                goto label_35;
            }
            // 0x01109D54: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x01109D58: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x01109D5C: LDR x8, [x8, #0x6a0]       | X8 = 1152921504607752192;               
            // 0x01109D60: LDR x21, [x8]              | X21 = typeof(System.UInt64);            
            val_44 = null;
            // 0x01109D64: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109D68: TBZ w8, #0, #0x1109d78     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x01109D6C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109D70: CBNZ w8, #0x1109d78        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x01109D74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_37:
            // 0x01109D78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109D7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109D80: MOV x1, x21                | X1 = 1152921504607752192 (0x10000000000DD000);//ML01
            // 0x01109D84: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109D88: CMP x0, x20                | STATE = COMPARE(val_13, sb)             
            // 0x01109D8C: B.NE #0x110a224            | if (val_13 != sb) goto label_38;        
            if(val_13 != sb)
            {
                goto label_38;
            }
            // 0x01109D90: CBZ x19, #0x110a1bc        | if (domain == null) goto label_39;      
            if(domain == null)
            {
                goto label_39;
            }
            // 0x01109D94: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x01109D98: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921512831182944)("            __ret->ObjectType = ObjectTypes.Long;");
            // 0x01109D9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109DA0: MOV x0, x19                | X0 = domain;//m1                        
            // 0x01109DA4: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Long;";
            // 0x01109DA8: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            System.Text.StringBuilder val_14 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            // 0x01109DAC: B #0x110a1dc               |  goto label_40;                         
            goto label_40;
            label_2:
            // 0x01109DB0: ADRP x24, #0x3620000       | X24 = 56754176 (0x3620000);             
            // 0x01109DB4: LDR x24, [x24, #0x340]     | X24 = 1152921504609562624;              
            // 0x01109DB8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x01109DBC: LDR x0, [x24]              | X0 = typeof(System.Type);               
            // 0x01109DC0: LDR x8, [x8, #0xa88]       | X8 = 1152921504606900224;               
            // 0x01109DC4: LDR x21, [x8]              | X21 = typeof(System.Object);            
            // 0x01109DC8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109DCC: TBZ w8, #0, #0x1109ddc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_42;
            // 0x01109DD0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109DD4: CBNZ w8, #0x1109ddc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
            // 0x01109DD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_42:
            // 0x01109DDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109DE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109DE4: MOV x1, x21                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x01109DE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109DEC: CMP x0, x20                | STATE = COMPARE(val_15, sb)             
            // 0x01109DF0: B.EQ #0x1109e40            | if (val_15 == sb) goto label_43;        
            if(val_15 == sb)
            {
                goto label_43;
            }
            // 0x01109DF4: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
            // 0x01109DF8: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
            // 0x01109DFC: LDR x0, [x21]              | X0 = typeof(System.String);             
            val_45 = null;
            // 0x01109E00: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109E04: TBZ w8, #0, #0x1109e18     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x01109E08: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01109E0C: CBNZ w8, #0x1109e18        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x01109E10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x01109E14: LDR x0, [x21]              | X0 = typeof(System.String);             
            val_45 = null;
            label_45:
            // 0x01109E18: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x01109E1C: B #0x1109e48               |  goto label_46;                         
            goto label_46;
            label_29:
            // 0x01109E20: CBZ x19, #0x1109f08        | if (domain == null) goto label_47;      
            if(domain == null)
            {
                goto label_47;
            }
            // 0x01109E24: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x01109E28: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921512831191312)("            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x01109E2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109E30: MOV x0, x19                | X0 = domain;//m1                        
            // 0x01109E34: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Integer;";
            // 0x01109E38: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_16 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x01109E3C: B #0x1109f28               |  goto label_48;                         
            goto label_48;
            label_43:
            // 0x01109E40: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x01109E44: LDR x8, [x8, #0x808]       | X8 = (string**)(1152921512831195584)(", true");
            val_46 = ", true";
            label_46:
            // 0x01109E48: LDR x21, [x8]              | X21 = ", true";                         
            // 0x01109E4C: CBNZ x20, #0x1109e54       | if (sb != null) goto label_49;          
            if(sb != null)
            {
                goto label_49;
            }
            // 0x01109E50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_49:
            // 0x01109E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01109E58: MOV x0, x20                | X0 = sb;//m1                            
            // 0x01109E5C: BL #0x1b6d42c              | X0 = sb.get_IsSealed();                 
            bool val_17 = sb.IsSealed;
            // 0x01109E60: AND w8, w0, #1             | W8 = (val_17 & 1);                      
            bool val_18 = val_17;
            // 0x01109E64: TBNZ w8, #0, #0x110a054    | if ((val_17 & 1) == true) goto label_64;
            if(val_18 == true)
            {
                goto label_64;
            }
            // 0x01109E68: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x01109E6C: LDR x0, [x24]              | X0 = typeof(System.Type);               
            // 0x01109E70: LDR x8, [x8, #0xd20]       | X8 = 1152921504825909248;               
            // 0x01109E74: LDR x23, [x8]              | X23 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x01109E78: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109E7C: TBZ w8, #0, #0x1109e8c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_52;
            // 0x01109E80: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109E84: CBNZ w8, #0x1109e8c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
            // 0x01109E88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_52:
            // 0x01109E8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109E90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109E94: MOV x1, x23                | X1 = 1152921504825909248 (0x100000000D0EA000);//ML01
            // 0x01109E98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109E9C: CMP x0, x20                | STATE = COMPARE(val_19, sb)             
            // 0x01109EA0: B.EQ #0x110a054            | if (val_19 == sb) goto label_64;        
            if(val_19 == sb)
            {
                goto label_64;
            }
            // 0x01109EA4: CBZ x22, #0x1109eb8        | if (X3 == 0) goto label_54;             
            if(X3 == 0)
            {
                goto label_54;
            }
            // 0x01109EA8: MOV x1, x22                | X1 = X3;//m1                            
            // 0x01109EAC: MOV x2, x20                | X2 = sb;//m1                            
            // 0x01109EB0: BL #0x110a27c              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.CheckAssignableToCrossBindingAdapters(domain:  System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()), type:  X3);
            bool val_20 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.CheckAssignableToCrossBindingAdapters(domain:  val_19, type:  X3);
            // 0x01109EB4: TBZ w0, #0, #0x1109f34     | if (val_20 == false) goto label_55;     
            if(val_20 == false)
            {
                goto label_55;
            }
            label_54:
            // 0x01109EB8: CBZ x19, #0x110a008        | if (domain == null) goto label_56;      
            if(domain == null)
            {
                goto label_56;
            }
            // 0x01109EBC: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x01109EC0: LDR x8, [x8, #0x290]       | X8 = (string**)(1152921512831199760)("            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance");
            // 0x01109EC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109EC8: MOV x0, x19                | X0 = domain;//m1                        
            // 0x01109ECC: LDR x1, [x8]               | X1 = "            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance";
            // 0x01109ED0: BL #0x1b5b818              | X0 = domain.Append(value:  "            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance");
            System.Text.StringBuilder val_21 = domain.Append(value:  "            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance");
            // 0x01109ED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109ED8: MOV x0, x19                | X0 = domain;//m1                        
            // 0x01109EDC: MOV x1, x21                | X1 = 1152921512831195584 (0x10000001EA3599C0);//ML01
            // 0x01109EE0: BL #0x1b5b818              | X0 = domain.Append(value:  val_46);     
            System.Text.StringBuilder val_22 = domain.Append(value:  val_46);
            // 0x01109EE4: B #0x110a03c               |  goto label_57;                         
            goto label_57;
            label_8:
            // 0x01109EE8: CBZ x19, #0x1109fdc        | if (domain == null) goto label_58;      
            if(domain == null)
            {
                goto label_58;
            }
            // 0x01109EEC: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x01109EF0: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921512831182944)("            __ret->ObjectType = ObjectTypes.Long;");
            // 0x01109EF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109EF8: MOV x0, x19                | X0 = domain;//m1                        
            // 0x01109EFC: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Long;";
            // 0x01109F00: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            System.Text.StringBuilder val_23 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            // 0x01109F04: B #0x1109ffc               |  goto label_59;                         
            goto label_59;
            label_47:
            // 0x01109F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x01109F0C: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x01109F10: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921512831191312)("            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x01109F14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109F18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109F1C: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Integer;";
            // 0x01109F20: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_24 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x01109F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_48:
            // 0x01109F28: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x01109F2C: LDR x8, [x8, #0x910]       | X8 = (string**)(1152921512831216800)("            __ret->Value = result_of_this_method;");
            val_47 = "            __ret->Value = result_of_this_method;";
            // 0x01109F30: B #0x110a1e4               |  goto label_84;                         
            goto label_84;
            label_55:
            // 0x01109F34: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x01109F38: LDR x0, [x24]              | X0 = typeof(System.Type);               
            // 0x01109F3C: LDR x8, [x8, #0x6d8]       | X8 = 1152921504824418304;               
            // 0x01109F40: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x01109F44: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01109F48: TBZ w8, #0, #0x1109f58     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_62;
            // 0x01109F4C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01109F50: CBNZ w8, #0x1109f58        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
            // 0x01109F54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_62:
            // 0x01109F58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109F5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109F60: MOV x1, x22                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x01109F64: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_25 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01109F68: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x01109F6C: CBNZ x22, #0x1109f74       | if (val_25 != null) goto label_63;      
            if(val_25 != null)
            {
                goto label_63;
            }
            // 0x01109F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_63:
            // 0x01109F74: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x01109F78: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x01109F7C: MOV x1, x20                | X1 = sb;//m1                            
            // 0x01109F80: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x01109F84: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x01109F88: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x01109F8C: TBZ w0, #0, #0x110a054     | if ((val_25 & 0x1) == 0) goto label_64; 
            if((val_25 & 1) == 0)
            {
                goto label_64;
            }
            // 0x01109F90: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01109F94: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01109F98: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01109F9C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01109FA0: TBZ w8, #0, #0x1109fb0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_66;
            // 0x01109FA4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01109FA8: CBNZ w8, #0x1109fb0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_66;
            // 0x01109FAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_66:
            // 0x01109FB0: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x01109FB4: LDR x8, [x8, #0x1b0]       | X8 = (string**)(1152921512831221072)("            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method.ILInstance{0});");
            val_48 = "            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method.ILInstance{0});";
            // 0x01109FB8: B #0x110a07c               |  goto label_67;                         
            goto label_67;
            label_14:
            // 0x01109FBC: CBZ x19, #0x110a0cc        | if (domain == null) goto label_68;      
            if(domain == null)
            {
                goto label_68;
            }
            // 0x01109FC0: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x01109FC4: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921512831191312)("            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x01109FC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109FCC: MOV x0, x19                | X0 = domain;//m1                        
            // 0x01109FD0: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Integer;";
            // 0x01109FD4: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_26 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x01109FD8: B #0x110a0ec               |  goto label_69;                         
            goto label_69;
            label_58:
            // 0x01109FDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x01109FE0: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x01109FE4: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921512831182944)("            __ret->ObjectType = ObjectTypes.Long;");
            // 0x01109FE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01109FEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01109FF0: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Long;";
            // 0x01109FF4: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            System.Text.StringBuilder val_27 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            // 0x01109FF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_59:
            // 0x01109FFC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0110A000: LDR x8, [x8, #0xa28]       | X8 = (string**)(1152921512831229536)("            *(long*)&__ret->Value = result_of_this_method;");
            val_47 = "            *(long*)&__ret->Value = result_of_this_method;";
            // 0x0110A004: B #0x110a1e4               |  goto label_84;                         
            goto label_84;
            label_56:
            // 0x0110A008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            // 0x0110A00C: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x0110A010: LDR x8, [x8, #0x290]       | X8 = (string**)(1152921512831199760)("            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance");
            // 0x0110A014: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A018: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A01C: LDR x1, [x8]               | X1 = "            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance";
            // 0x0110A020: BL #0x1b5b818              | X0 = 0.Append(value:  "            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance");
            System.Text.StringBuilder val_28 = 0.Append(value:  "            object obj_result_of_this_method = result_of_this_method;\n            if(obj_result_of_this_method is CrossBindingAdaptorType)\n            {    \n                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance");
            // 0x0110A024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            // 0x0110A028: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A02C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A030: MOV x1, x21                | X1 = 1152921512831195584 (0x10000001EA3599C0);//ML01
            // 0x0110A034: BL #0x1b5b818              | X0 = 0.Append(value:  val_46);          
            System.Text.StringBuilder val_29 = 0.Append(value:  val_46);
            // 0x0110A038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_57:
            // 0x0110A03C: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x0110A040: LDR x8, [x8, #0xea0]       | X8 = (string**)(1152921512831237920)(");\n            }");
            // 0x0110A044: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A048: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A04C: LDR x1, [x8]               | X1 = ");\n            }";               
            // 0x0110A050: BL #0x1b5c068              | X0 = domain.AppendLine(value:  ");\n            }");
            System.Text.StringBuilder val_30 = domain.AppendLine(value:  ");\n            }");
            label_64:
            // 0x0110A054: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0110A058: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110A05C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110A060: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110A064: TBZ w8, #0, #0x110a074     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_72;
            // 0x0110A068: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110A06C: CBNZ w8, #0x110a074        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x0110A070: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_72:
            // 0x0110A074: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x0110A078: LDR x8, [x8, #0xb60]       | X8 = (string**)(1152921512831242128)("            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method{0});");
            val_48 = "            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method{0});";
            label_67:
            // 0x0110A07C: LDR x1, [x8]               | X1 = "            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method{0});";
            // 0x0110A080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A084: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110A088: MOV x2, x21                | X2 = 1152921512831195584 (0x10000001EA3599C0);//ML01
            // 0x0110A08C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  val_48 = "            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method{0});");
            string val_31 = System.String.Format(format:  0, arg0:  val_48);
            // 0x0110A090: MOV x20, x0                | X20 = val_31;//m1                       
            // 0x0110A094: CBNZ x19, #0x110a09c       | if (domain != null) goto label_73;      
            if(domain != null)
            {
                goto label_73;
            }
            // 0x0110A098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_73:
            // 0x0110A09C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A0A0: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A0A4: MOV x1, x20                | X1 = val_31;//m1                        
            val_49 = val_31;
            // 0x0110A0A8: B #0x110a210               |  goto label_74;                         
            goto label_74;
            label_20:
            // 0x0110A0AC: CBZ x19, #0x110a118        | if (domain == null) goto label_75;      
            if(domain == null)
            {
                goto label_75;
            }
            // 0x0110A0B0: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x0110A0B4: LDR x8, [x8, #0x608]       | X8 = (string**)(1152921512831246464)("            __ret->ObjectType = ObjectTypes.Float;");
            // 0x0110A0B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A0BC: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A0C0: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Float;";
            // 0x0110A0C4: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Float;");
            System.Text.StringBuilder val_32 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Float;");
            // 0x0110A0C8: B #0x110a138               |  goto label_76;                         
            goto label_76;
            label_68:
            // 0x0110A0CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x0110A0D0: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x0110A0D4: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921512831191312)("            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x0110A0D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A0DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A0E0: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Integer;";
            // 0x0110A0E4: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_33 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x0110A0E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_69:
            // 0x0110A0EC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0110A0F0: LDR x8, [x8, #0x920]       | X8 = (string**)(1152921512831254832)("            __ret->Value = result_of_this_method ? 1 : 0;");
            val_47 = "            __ret->Value = result_of_this_method ? 1 : 0;";
            // 0x0110A0F4: B #0x110a1e4               |  goto label_84;                         
            goto label_84;
            label_23:
            // 0x0110A0F8: CBZ x19, #0x110a164        | if (domain == null) goto label_78;      
            if(domain == null)
            {
                goto label_78;
            }
            // 0x0110A0FC: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x0110A100: LDR x8, [x8, #0xf30]       | X8 = (string**)(1152921512831255024)("            __ret->ObjectType = ObjectTypes.Double;");
            // 0x0110A104: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A108: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A10C: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Double;";
            // 0x0110A110: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Double;");
            System.Text.StringBuilder val_34 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Double;");
            // 0x0110A114: B #0x110a184               |  goto label_79;                         
            goto label_79;
            label_75:
            // 0x0110A118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            // 0x0110A11C: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x0110A120: LDR x8, [x8, #0x608]       | X8 = (string**)(1152921512831246464)("            __ret->ObjectType = ObjectTypes.Float;");
            // 0x0110A124: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A128: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A12C: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Float;";
            // 0x0110A130: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Float;");
            System.Text.StringBuilder val_35 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Float;");
            // 0x0110A134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_76:
            // 0x0110A138: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x0110A13C: LDR x8, [x8, #0x470]       | X8 = (string**)(1152921512831263392)("            *(float*)&__ret->Value = result_of_this_method;");
            val_47 = "            *(float*)&__ret->Value = result_of_this_method;";
            // 0x0110A140: B #0x110a1e4               |  goto label_84;                         
            goto label_84;
            label_35:
            // 0x0110A144: CBZ x19, #0x110a190        | if (domain == null) goto label_81;      
            if(domain == null)
            {
                goto label_81;
            }
            // 0x0110A148: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x0110A14C: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921512831191312)("            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x0110A150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A154: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A158: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Integer;";
            // 0x0110A15C: BL #0x1b5c068              | X0 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_36 = domain.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x0110A160: B #0x110a1b0               |  goto label_82;                         
            goto label_82;
            label_78:
            // 0x0110A164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            // 0x0110A168: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x0110A16C: LDR x8, [x8, #0xf30]       | X8 = (string**)(1152921512831255024)("            __ret->ObjectType = ObjectTypes.Double;");
            // 0x0110A170: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A174: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A178: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Double;";
            // 0x0110A17C: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Double;");
            System.Text.StringBuilder val_37 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Double;");
            // 0x0110A180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_79:
            // 0x0110A184: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x0110A188: LDR x8, [x8, #0xda0]       | X8 = (string**)(1152921512831271776)("            *(double*)&__ret->Value = result_of_this_method;");
            val_47 = "            *(double*)&__ret->Value = result_of_this_method;";
            // 0x0110A18C: B #0x110a1e4               |  goto label_84;                         
            goto label_84;
            label_81:
            // 0x0110A190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x0110A194: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x0110A198: LDR x8, [x8, #0xba0]       | X8 = (string**)(1152921512831191312)("            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x0110A19C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A1A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A1A4: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Integer;";
            // 0x0110A1A8: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            System.Text.StringBuilder val_38 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Integer;");
            // 0x0110A1AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_82:
            // 0x0110A1B0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x0110A1B4: LDR x8, [x8, #0x9f0]       | X8 = (string**)(1152921512831276064)("            __ret->Value = (int)result_of_this_method;");
            val_47 = "            __ret->Value = (int)result_of_this_method;";
            // 0x0110A1B8: B #0x110a1e4               |  goto label_84;                         
            goto label_84;
            label_39:
            // 0x0110A1BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            // 0x0110A1C0: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
            // 0x0110A1C4: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921512831182944)("            __ret->ObjectType = ObjectTypes.Long;");
            // 0x0110A1C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A1CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A1D0: LDR x1, [x8]               | X1 = "            __ret->ObjectType = ObjectTypes.Long;";
            // 0x0110A1D4: BL #0x1b5c068              | X0 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            System.Text.StringBuilder val_39 = 0.AppendLine(value:  "            __ret->ObjectType = ObjectTypes.Long;");
            // 0x0110A1D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_40:
            // 0x0110A1DC: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x0110A1E0: LDR x8, [x8, #0x788]       | X8 = (string**)(1152921512831280336)("            *(ulong*)&__ret->Value = result_of_this_method;");
            val_47 = "            *(ulong*)&__ret->Value = result_of_this_method;";
            label_84:
            // 0x0110A1E4: LDR x1, [x8]               | X1 = "            *(ulong*)&__ret->Value = result_of_this_method;";
            // 0x0110A1E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A1EC: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A1F0: BL #0x1b5c068              | X0 = domain.AppendLine(value:  val_47 = "            *(ulong*)&__ret->Value = result_of_this_method;");
            System.Text.StringBuilder val_40 = domain.AppendLine(value:  val_47);
            // 0x0110A1F4: CBNZ x19, #0x110a1fc       | if (domain != null) goto label_85;      
            if(domain != null)
            {
                goto label_85;
            }
            // 0x0110A1F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_85:
            // 0x0110A1FC: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x0110A200: LDR x8, [x8, #0xb48]       | X8 = (string**)(1152921512831284624)("            return __ret + 1;");
            // 0x0110A204: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A208: MOV x0, x19                | X0 = domain;//m1                        
            // 0x0110A20C: LDR x1, [x8]               | X1 = "            return __ret + 1;";   
            val_49 = "            return __ret + 1;";
            label_74:
            // 0x0110A210: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0110A214: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0110A218: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0110A21C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0110A220: B #0x1b5c068               | X0 = domain.AppendLine(value:  val_49 = "            return __ret + 1;"); return;
            System.Text.StringBuilder val_41 = domain.AppendLine(value:  val_49);
            return;
            label_38:
            // 0x0110A224: CBNZ x20, #0x110a22c       | if (sb != null) goto label_86;          
            if(sb != null)
            {
                goto label_86;
            }
            // 0x0110A228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_86:
            // 0x0110A22C: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x0110A230: MOV x0, x20                | X0 = sb;//m1                            
            // 0x0110A234: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x0110A238: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x0110A23C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0110A240: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x0110A244: MOV x19, x0                | X19 = sb;//m1                           
            // 0x0110A248: LDR x8, [x8]               | X8 = typeof(System.NotImplementedException);
            // 0x0110A24C: MOV x0, x8                 | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            System.NotImplementedException val_42 = null;
            // 0x0110A250: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x0110A254: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A258: MOV x1, x19                | X1 = sb;//m1                            
            // 0x0110A25C: MOV x20, x0                | X20 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x0110A260: BL #0x1701538              | .ctor(message:  sb);                    
            val_42 = new System.NotImplementedException(message:  sb);
            // 0x0110A264: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x0110A268: LDR x8, [x8, #0x238]       | X8 = 1152921512831288848;               
            // 0x0110A26C: MOV x0, x20                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_43 = val_42;
            // 0x0110A270: LDR x1, [x8]               | X1 = static System.Void ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetReturnValueCode(System.Type type, System.Text.StringBuilder sb, ILRuntime.Runtime.Enviorment.AppDomain domain);
            // 0x0110A274: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x0110A278: BL #0x10ec5ac              | .ctor(def:  static System.Void ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetReturnValueCode(System.Type type, System.Text.StringBuilder sb, ILRuntime.Runtime.Enviorment.AppDomain domain), type:  0, domain:  null);
            val_43 = new ILRuntime.CLR.Method.CLRMethod(def:  static System.Void ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions::GetReturnValueCode(System.Type type, System.Text.StringBuilder sb, ILRuntime.Runtime.Enviorment.AppDomain domain), type:  0, domain:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x0110A27C (17867388), len: 444  VirtAddr: 0x0110A27C RVA: 0x0110A27C token: 100679925 methodIndex: 29212 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool CheckAssignableToCrossBindingAdapters(ILRuntime.Runtime.Enviorment.AppDomain domain, System.Type type)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            label_18:
            // 0x0110A27C: STP x24, x23, [sp, #-0x40]! | stack[1152921512831599152] = ???;  stack[1152921512831599160] = ???;  //  dest_result_addr=1152921512831599152 |  dest_result_addr=1152921512831599160
            // 0x0110A280: STP x22, x21, [sp, #0x10]  | stack[1152921512831599168] = ???;  stack[1152921512831599176] = ???;  //  dest_result_addr=1152921512831599168 |  dest_result_addr=1152921512831599176
            // 0x0110A284: STP x20, x19, [sp, #0x20]  | stack[1152921512831599184] = ???;  stack[1152921512831599192] = ???;  //  dest_result_addr=1152921512831599184 |  dest_result_addr=1152921512831599192
            // 0x0110A288: STP x29, x30, [sp, #0x30]  | stack[1152921512831599200] = ???;  stack[1152921512831599208] = ???;  //  dest_result_addr=1152921512831599200 |  dest_result_addr=1152921512831599208
            // 0x0110A28C: ADD x29, sp, #0x30         | X29 = (1152921512831599152 + 48) = 1152921512831599200 (0x10000001EA3BC260);
            // 0x0110A290: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x0110A294: LDRB w8, [x21, #0xb9b]     | W8 = (bool)static_value_03735B9B;       
            // 0x0110A298: MOV x20, x2                | X20 = X2;//m1                           
            // 0x0110A29C: MOV x19, x1                | X19 = type;//m1                         
            // 0x0110A2A0: TBNZ w8, #0, #0x110a2bc    | if (static_value_03735B9B == true) goto label_0;
            // 0x0110A2A4: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x0110A2A8: LDR x8, [x8, #0xd88]       | X8 = 0x2B8F54C;                         
            // 0x0110A2AC: LDR w0, [x8]               | W0 = 0x1415;                            
            // 0x0110A2B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1415, ????);     
            // 0x0110A2B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0110A2B8: STRB w8, [x21, #0xb9b]     | static_value_03735B9B = true;            //  dest_result_addr=57891739
            label_0:
            // 0x0110A2BC: ADRP x22, #0x3620000       | X22 = 56754176 (0x3620000);             
            // 0x0110A2C0: LDR x22, [x22, #0x340]     | X22 = 1152921504609562624;              
            // 0x0110A2C4: ADRP x23, #0x363f000       | X23 = 56881152 (0x363F000);             
            // 0x0110A2C8: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x0110A2CC: LDR x23, [x23, #0xa88]     | X23 = 1152921504606900224;              
            // 0x0110A2D0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110A2D4: LDR x21, [x23]             | X21 = typeof(System.Object);            
            val_9 = null;
            // 0x0110A2D8: TBZ w8, #0, #0x110a2e8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0110A2DC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110A2E0: CBNZ w8, #0x110a2e8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0110A2E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0110A2E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A2EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A2F0: MOV x1, x21                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x0110A2F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110A2F8: CMP x0, x20                | STATE = COMPARE(val_1, X2)              
            // 0x0110A2FC: B.EQ #0x110a418            | if (val_1 == X2) goto label_13;         
            if(val_1 == X2)
            {
                goto label_13;
            }
            // 0x0110A300: CBNZ x19, #0x110a308       | if (type != null) goto label_4;         
            if(type != null)
            {
                goto label_4;
            }
            // 0x0110A304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x0110A308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A30C: MOV x0, x19                | X0 = type;//m1                          
            // 0x0110A310: BL #0x28e4368              | X0 = type.get_CrossBindingAdaptors();   
            System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CrossBindingAdaptor> val_2 = type.CrossBindingAdaptors;
            // 0x0110A314: MOV x21, x0                | X21 = val_2;//m1                        
            val_9 = val_2;
            // 0x0110A318: CBNZ x21, #0x110a320       | if (val_2 != null) goto label_5;        
            if(val_9 != null)
            {
                goto label_5;
            }
            // 0x0110A31C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x0110A320: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x0110A324: LDR x8, [x8, #0x1d8]       | X8 = 1152921512831582096;               
            // 0x0110A328: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0110A32C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0110A330: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Type, ILRuntime.Runtime.Enviorment.CrossBindingAdaptor>::ContainsKey(System.Type key);
            // 0x0110A334: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  X2);       
            bool val_3 = val_9.ContainsKey(key:  X2);
            // 0x0110A338: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x0110A33C: TBNZ w8, #0, #0x110a418    | if ((val_3 & 1) == true) goto label_13; 
            if(val_4 == true)
            {
                goto label_13;
            }
            // 0x0110A340: CBNZ x20, #0x110a348       | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x0110A344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x0110A348: LDR x8, [x20]              | X8 = X2;                                
            // 0x0110A34C: MOV x0, x20                | X0 = X2;//m1                            
            // 0x0110A350: LDR x9, [x8, #0x220]       | X9 = X2 + 544;                          
            // 0x0110A354: LDR x1, [x8, #0x228]       | X1 = X2 + 552;                          
            // 0x0110A358: BLR x9                     | X0 = X2 + 544();                        
            // 0x0110A35C: MOV x21, x0                | X21 = X2;//m1                           
            val_9 = X2;
            // 0x0110A360: CBZ x21, #0x110a3ac        | if (X2 == 0) goto label_11;             
            if(val_9 == 0)
            {
                goto label_11;
            }
            // 0x0110A364: LDR x0, [x22]              | X0 = typeof(System.Type);               
            // 0x0110A368: LDR x22, [x23]             | X22 = typeof(System.Object);            
            // 0x0110A36C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110A370: TBZ w8, #0, #0x110a380     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x0110A374: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110A378: CBNZ w8, #0x110a380        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x0110A37C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x0110A380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110A384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110A388: MOV x1, x22                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x0110A38C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110A390: CMP x21, x0                | STATE = COMPARE(X2, val_5)              
            // 0x0110A394: B.EQ #0x110a3ac            | if (val_9 == val_5) goto label_11;      
            if(val_9 == val_5)
            {
                goto label_11;
            }
            // 0x0110A398: MOV x1, x19                | X1 = type;//m1                          
            // 0x0110A39C: MOV x2, x21                | X2 = X2;//m1                            
            // 0x0110A3A0: BL #0x110a27c              |  R0 = label_18();                       
            // 0x0110A3A4: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            System.Type val_6 = val_5 & 1;
            // 0x0110A3A8: TBNZ w8, #0, #0x110a418    | if (((val_5 & 1) & 0x1) != 0) goto label_13;
            if((val_6 & 1) != 0)
            {
                goto label_13;
            }
            label_11:
            // 0x0110A3AC: CBNZ x20, #0x110a3b4       | if (X2 != 0) goto label_14;             
            if(X2 != 0)
            {
                goto label_14;
            }
            // 0x0110A3B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_14:
            // 0x0110A3B4: LDR x8, [x20]              | X8 = X2;                                
            // 0x0110A3B8: MOV x0, x20                | X0 = X2;//m1                            
            // 0x0110A3BC: LDR x9, [x8, #0x3d0]       | X9 = X2 + 976;                          
            // 0x0110A3C0: LDR x1, [x8, #0x3d8]       | X1 = X2 + 984;                          
            // 0x0110A3C4: BLR x9                     | X0 = X2 + 976();                        
            // 0x0110A3C8: MOV x20, x0                | X20 = X2;//m1                           
            // 0x0110A3CC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_19:
            // 0x0110A3D0: CBNZ x20, #0x110a3d8       | if (X2 != 0) goto label_15;             
            if(X2 != 0)
            {
                goto label_15;
            }
            // 0x0110A3D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X2, ????);         
            label_15:
            // 0x0110A3D8: LDR w8, [x20, #0x18]       | W8 = X2 + 24;                           
            // 0x0110A3DC: CMP w21, w8                | STATE = COMPARE(0x0, X2 + 24)           
            // 0x0110A3E0: B.GE #0x110a430            | if (0 >= X2 + 24) goto label_16;        
            if(0 >= (X2 + 24))
            {
                goto label_16;
            }
            // 0x0110A3E4: SXTW x22, w21              | X22 = 0 (0x00000000);                   
            // 0x0110A3E8: CMP w21, w8                | STATE = COMPARE(0x0, X2 + 24)           
            // 0x0110A3EC: B.LO #0x110a3fc            | if (0 < X2 + 24) goto label_17;         
            if(0 < (X2 + 24))
            {
                goto label_17;
            }
            // 0x0110A3F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X2, ????);         
            // 0x0110A3F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A3F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X2, ????);         
            label_17:
            // 0x0110A3FC: ADD x8, x20, x22, lsl #3   | X8 = (X2 + 0);                          
            var val_7 = X2 + 0;
            // 0x0110A400: LDR x2, [x8, #0x20]        | X2 = (X2 + 0) + 32;                     
            // 0x0110A404: MOV x1, x19                | X1 = type;//m1                          
            // 0x0110A408: BL #0x110a27c              |  R0 = label_18();                       
            // 0x0110A40C: ADD w21, w21, #1           | W21 = (0 + 1);                          
            val_9 = 0 + 1;
            // 0x0110A410: AND w8, w0, #1             | W8 = (X2 & 1);                          
            var val_8 = X2 & 1;
            // 0x0110A414: TBZ w8, #0, #0x110a3d0     | if (((X2 & 1) & 0x1) == 0) goto label_19;
            if((val_8 & 1) == 0)
            {
                goto label_19;
            }
            label_13:
            // 0x0110A418: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            label_20:
            // 0x0110A41C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0110A420: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0110A424: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0110A428: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0110A42C: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_16:
            // 0x0110A430: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x0110A434: B #0x110a41c               |  goto label_20;                         
            goto label_20;
        
        }
        //
        // Offset in libil2cpp.so: 0x0110A438 (17867832), len: 184  VirtAddr: 0x0110A438 RVA: 0x0110A438 token: 100679926 methodIndex: 29213 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x2857270
        internal static bool HasByRefParam(System.Reflection.ParameterInfo[] param)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x0110A438: STP x22, x21, [sp, #-0x30]! | stack[1152921512831768512] = ???;  stack[1152921512831768520] = ???;  //  dest_result_addr=1152921512831768512 |  dest_result_addr=1152921512831768520
            // 0x0110A43C: STP x20, x19, [sp, #0x10]  | stack[1152921512831768528] = ???;  stack[1152921512831768536] = ???;  //  dest_result_addr=1152921512831768528 |  dest_result_addr=1152921512831768536
            // 0x0110A440: STP x29, x30, [sp, #0x20]  | stack[1152921512831768544] = ???;  stack[1152921512831768552] = ???;  //  dest_result_addr=1152921512831768544 |  dest_result_addr=1152921512831768552
            // 0x0110A444: ADD x29, sp, #0x20         | X29 = (1152921512831768512 + 32) = 1152921512831768544 (0x10000001EA3E57E0);
            // 0x0110A448: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0110A44C: CBNZ x19, #0x110a454       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x0110A450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? param, ????);      
            label_0:
            // 0x0110A454: LDR x8, [x19, #0x18]       | X8 = X1 + 24;                           
            // 0x0110A458: SXTW x21, w8               | X21 = (long)(int)(X1 + 24);             
            val_5 = (long)X1 + 24;
            // 0x0110A45C: SUB w22, w21, #1           | W22 = ((long)(int)(X1 + 24) - 1);       
            var val_1 = val_5 - 1;
            label_6:
            // 0x0110A460: CMP x21, #0                | STATE = COMPARE((long)(int)(X1 + 24), 0x0)
            // 0x0110A464: B.LE #0x110a4dc            | if (val_5 <= 0x0) goto label_1;         
            if(val_5 <= 0)
            {
                goto label_1;
            }
            // 0x0110A468: CBNZ x19, #0x110a470       | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x0110A46C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? param, ????);      
            label_2:
            // 0x0110A470: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x0110A474: SXTW x20, w22              | X20 = (long)(int)(((long)(int)(X1 + 24) - 1));
            // 0x0110A478: CMP w22, w8                | STATE = COMPARE(((long)(int)(X1 + 24) - 1), X1 + 24)
            // 0x0110A47C: B.LO #0x110a48c            | if (val_1 < X1 + 24) goto label_3;      
            if(val_1 < (X1 + 24))
            {
                goto label_3;
            }
            // 0x0110A480: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? param, ????);      
            // 0x0110A484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A488: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? param, ????);      
            label_3:
            // 0x0110A48C: ADD x8, x19, x20, lsl #3   | X8 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3);
            var val_2 = X1 + (((long)(int)(((long)(int)(X1 + 24) - 1))) << 3);
            // 0x0110A490: LDR x20, [x8, #0x20]       | X20 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32;
            // 0x0110A494: CBNZ x20, #0x110a49c       | if ((X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32 != 0) goto label_4;
            if(((X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32) != 0)
            {
                goto label_4;
            }
            // 0x0110A498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? param, ????);      
            label_4:
            // 0x0110A49C: LDR x8, [x20]              | X8 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32;
            // 0x0110A4A0: MOV x0, x20                | X0 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32;//m1
            // 0x0110A4A4: LDP x9, x1, [x8, #0x170]   | X9 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32 + 368; X1 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32 + 368 + 8; //  | 
            // 0x0110A4A8: BLR x9                     | X0 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32 + 368();
            // 0x0110A4AC: MOV x20, x0                | X20 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32;//m1
            // 0x0110A4B0: CBNZ x20, #0x110a4b8       | if ((X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32 != 0) goto label_5;
            if(((X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32) != 0)
            {
                goto label_5;
            }
            // 0x0110A4B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32, ????);
            label_5:
            // 0x0110A4B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110A4BC: MOV x0, x20                | X0 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32;//m1
            // 0x0110A4C0: BL #0x1b6d1dc              | X0 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32.get_IsByRef();
            bool val_3 = (X1 + ((long)(int)(((long)(int)(X1 + 24) - 1))) << 3) + 32.IsByRef;
            // 0x0110A4C4: SUB x21, x21, #1           | X21 = ((long)(int)(X1 + 24) - 1);       
            val_5 = val_5 - 1;
            // 0x0110A4C8: SUB w22, w22, #1           | W22 = (((long)(int)(X1 + 24) - 1) - 1); 
            val_1 = val_1 - 1;
            // 0x0110A4CC: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x0110A4D0: TBZ w8, #0, #0x110a460     | if ((val_3 & 1) == false) goto label_6; 
            if(val_4 == false)
            {
                goto label_6;
            }
            // 0x0110A4D4: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_6 = 1;
            // 0x0110A4D8: B #0x110a4e0               |  goto label_7;                          
            goto label_7;
            label_1:
            // 0x0110A4DC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_7:
            // 0x0110A4E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0110A4E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0110A4E8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0110A4EC: RET                        |  return (System.Boolean)false;          
            return (bool)val_6;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
