using UnityEngine;
public enum AnimationRunner.AniState
{
    // Fields
    fighting = 0
    ,show = 1
    

}
