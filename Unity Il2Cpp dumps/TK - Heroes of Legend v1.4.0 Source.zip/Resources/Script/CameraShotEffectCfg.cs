using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286E420
[Serializable]
public class CameraShotEffectCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private int _heroOrNpcId; //  0x00000014
    private int _isHero; //  0x00000018
    private float _lifeTime; //  0x0000001C
    private float _posX; //  0x00000020
    private float _posY; //  0x00000024
    private float _posZ; //  0x00000028
    private int _hostId; //  0x0000002C
    private int _isShowInBlack; //  0x00000030
    private float _playSpeed; //  0x00000034
    private ProtoBuf.IExtension extensionObject; //  0x00000038
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286E464
    [System.ComponentModel.DefaultValueAttribute] // 0x286E464
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E4E4
    [System.ComponentModel.DefaultValueAttribute] // 0x286E4E4
    public int heroOrNpcId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E564
    [System.ComponentModel.DefaultValueAttribute] // 0x286E564
    public int isHero { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E5E4
    [System.ComponentModel.DefaultValueAttribute] // 0x286E5E4
    public float lifeTime { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E664
    [System.ComponentModel.DefaultValueAttribute] // 0x286E664
    public float posX { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E6E4
    [System.ComponentModel.DefaultValueAttribute] // 0x286E6E4
    public float posY { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E764
    [System.ComponentModel.DefaultValueAttribute] // 0x286E764
    public float posZ { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E7E4
    [System.ComponentModel.DefaultValueAttribute] // 0x286E7E4
    public int hostId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E864
    [System.ComponentModel.DefaultValueAttribute] // 0x286E864
    public int isShowInBlack { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286E8E4
    [System.ComponentModel.DefaultValueAttribute] // 0x286E8E4
    public float playSpeed { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BADCB4 (12246196), len: 8  VirtAddr: 0x00BADCB4 RVA: 0x00BADCB4 token: 100690480 methodIndex: 25752 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotEffectCfg()
    {
        //
        // Disasemble & Code
        // 0x00BADCB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BADCB8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCBC (12246204), len: 8  VirtAddr: 0x00BADCBC RVA: 0x00BADCBC token: 100690481 methodIndex: 25753 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00BADCBC: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00BADCC0: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCC4 (12246212), len: 8  VirtAddr: 0x00BADCC4 RVA: 0x00BADCC4 token: 100690482 methodIndex: 25754 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADCC4: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514526125744
        this._id = value;
        // 0x00BADCC8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCCC (12246220), len: 8  VirtAddr: 0x00BADCCC RVA: 0x00BADCCC token: 100690483 methodIndex: 25755 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_heroOrNpcId()
    {
        //
        // Disasemble & Code
        // 0x00BADCCC: LDR w0, [x0, #0x14]        | W0 = this._heroOrNpcId; //P2            
        // 0x00BADCD0: RET                        |  return (System.Int32)this._heroOrNpcId;
        return this._heroOrNpcId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCD4 (12246228), len: 8  VirtAddr: 0x00BADCD4 RVA: 0x00BADCD4 token: 100690484 methodIndex: 25756 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_heroOrNpcId(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADCD4: STR w1, [x0, #0x14]        | this._heroOrNpcId = value;               //  dest_result_addr=1152921514526349748
        this._heroOrNpcId = value;
        // 0x00BADCD8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCDC (12246236), len: 8  VirtAddr: 0x00BADCDC RVA: 0x00BADCDC token: 100690485 methodIndex: 25757 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isHero()
    {
        //
        // Disasemble & Code
        // 0x00BADCDC: LDR w0, [x0, #0x18]        | W0 = this._isHero; //P2                 
        // 0x00BADCE0: RET                        |  return (System.Int32)this._isHero;     
        return this._isHero;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCE4 (12246244), len: 8  VirtAddr: 0x00BADCE4 RVA: 0x00BADCE4 token: 100690486 methodIndex: 25758 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isHero(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADCE4: STR w1, [x0, #0x18]        | this._isHero = value;                    //  dest_result_addr=1152921514526573752
        this._isHero = value;
        // 0x00BADCE8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCEC (12246252), len: 8  VirtAddr: 0x00BADCEC RVA: 0x00BADCEC token: 100690487 methodIndex: 25759 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_lifeTime()
    {
        //
        // Disasemble & Code
        // 0x00BADCEC: LDR s0, [x0, #0x1c]        | S0 = this._lifeTime; //P2               
        // 0x00BADCF0: RET                        |  return (System.Single)this._lifeTime;  
        return this._lifeTime;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCF4 (12246260), len: 8  VirtAddr: 0x00BADCF4 RVA: 0x00BADCF4 token: 100690488 methodIndex: 25760 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_lifeTime(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADCF4: STR s0, [x0, #0x1c]        | this._lifeTime = value;                  //  dest_result_addr=1152921514526797756
        this._lifeTime = value;
        // 0x00BADCF8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADCFC (12246268), len: 8  VirtAddr: 0x00BADCFC RVA: 0x00BADCFC token: 100690489 methodIndex: 25761 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posX()
    {
        //
        // Disasemble & Code
        // 0x00BADCFC: LDR s0, [x0, #0x20]        | S0 = this._posX; //P2                   
        // 0x00BADD00: RET                        |  return (System.Single)this._posX;      
        return this._posX;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD04 (12246276), len: 8  VirtAddr: 0x00BADD04 RVA: 0x00BADD04 token: 100690490 methodIndex: 25762 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posX(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADD04: STR s0, [x0, #0x20]        | this._posX = value;                      //  dest_result_addr=1152921514527021760
        this._posX = value;
        // 0x00BADD08: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD0C (12246284), len: 8  VirtAddr: 0x00BADD0C RVA: 0x00BADD0C token: 100690491 methodIndex: 25763 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posY()
    {
        //
        // Disasemble & Code
        // 0x00BADD0C: LDR s0, [x0, #0x24]        | S0 = this._posY; //P2                   
        // 0x00BADD10: RET                        |  return (System.Single)this._posY;      
        return this._posY;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD14 (12246292), len: 8  VirtAddr: 0x00BADD14 RVA: 0x00BADD14 token: 100690492 methodIndex: 25764 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posY(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADD14: STR s0, [x0, #0x24]        | this._posY = value;                      //  dest_result_addr=1152921514527245764
        this._posY = value;
        // 0x00BADD18: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD1C (12246300), len: 8  VirtAddr: 0x00BADD1C RVA: 0x00BADD1C token: 100690493 methodIndex: 25765 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posZ()
    {
        //
        // Disasemble & Code
        // 0x00BADD1C: LDR s0, [x0, #0x28]        | S0 = this._posZ; //P2                   
        // 0x00BADD20: RET                        |  return (System.Single)this._posZ;      
        return this._posZ;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD24 (12246308), len: 8  VirtAddr: 0x00BADD24 RVA: 0x00BADD24 token: 100690494 methodIndex: 25766 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posZ(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADD24: STR s0, [x0, #0x28]        | this._posZ = value;                      //  dest_result_addr=1152921514527469768
        this._posZ = value;
        // 0x00BADD28: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD2C (12246316), len: 8  VirtAddr: 0x00BADD2C RVA: 0x00BADD2C token: 100690495 methodIndex: 25767 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_hostId()
    {
        //
        // Disasemble & Code
        // 0x00BADD2C: LDR w0, [x0, #0x2c]        | W0 = this._hostId; //P2                 
        // 0x00BADD30: RET                        |  return (System.Int32)this._hostId;     
        return this._hostId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD34 (12246324), len: 8  VirtAddr: 0x00BADD34 RVA: 0x00BADD34 token: 100690496 methodIndex: 25768 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_hostId(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADD34: STR w1, [x0, #0x2c]        | this._hostId = value;                    //  dest_result_addr=1152921514527693772
        this._hostId = value;
        // 0x00BADD38: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD3C (12246332), len: 8  VirtAddr: 0x00BADD3C RVA: 0x00BADD3C token: 100690497 methodIndex: 25769 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isShowInBlack()
    {
        //
        // Disasemble & Code
        // 0x00BADD3C: LDR w0, [x0, #0x30]        | W0 = this._isShowInBlack; //P2          
        // 0x00BADD40: RET                        |  return (System.Int32)this._isShowInBlack;
        return this._isShowInBlack;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD44 (12246340), len: 8  VirtAddr: 0x00BADD44 RVA: 0x00BADD44 token: 100690498 methodIndex: 25770 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isShowInBlack(int value)
    {
        //
        // Disasemble & Code
        // 0x00BADD44: STR w1, [x0, #0x30]        | this._isShowInBlack = value;             //  dest_result_addr=1152921514527917776
        this._isShowInBlack = value;
        // 0x00BADD48: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD4C (12246348), len: 8  VirtAddr: 0x00BADD4C RVA: 0x00BADD4C token: 100690499 methodIndex: 25771 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_playSpeed()
    {
        //
        // Disasemble & Code
        // 0x00BADD4C: LDR s0, [x0, #0x34]        | S0 = this._playSpeed; //P2              
        // 0x00BADD50: RET                        |  return (System.Single)this._playSpeed; 
        return this._playSpeed;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD54 (12246356), len: 8  VirtAddr: 0x00BADD54 RVA: 0x00BADD54 token: 100690500 methodIndex: 25772 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_playSpeed(float value)
    {
        //
        // Disasemble & Code
        // 0x00BADD54: STR s0, [x0, #0x34]        | this._playSpeed = value;                 //  dest_result_addr=1152921514528141780
        this._playSpeed = value;
        // 0x00BADD58: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BADD5C (12246364), len: 24  VirtAddr: 0x00BADD5C RVA: 0x00BADD5C token: 100690501 methodIndex: 25773 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BADD5C: ADD x8, x0, #0x38          | X8 = this.extensionObject;//AP2 res_addr=1152921514528253784
        // 0x00BADD60: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BADD64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BADD68: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BADD6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BADD70: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
