using UnityEngine;
private class LzmaBench.CRandomGenerator
{
    // Fields
    private uint A1; //  0x00000010
    private uint A2; //  0x00000014
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00ADBABC (11385532), len: 56  VirtAddr: 0x00ADBABC RVA: 0x00ADBABC token: 100681605 methodIndex: 54792 delegateWrapperIndex: 0 methodInvoker: 0
    public LzmaBench.CRandomGenerator()
    {
        //
        // Disasemble & Code
        // 0x00ADBABC: STP x20, x19, [sp, #-0x20]! | stack[1152921513101204016] = ???;  stack[1152921513101204024] = ???;  //  dest_result_addr=1152921513101204016 |  dest_result_addr=1152921513101204024
        // 0x00ADBAC0: STP x29, x30, [sp, #0x10]  | stack[1152921513101204032] = ???;  stack[1152921513101204040] = ???;  //  dest_result_addr=1152921513101204032 |  dest_result_addr=1152921513101204040
        // 0x00ADBAC4: ADD x29, sp, #0x10         | X29 = (1152921513101204016 + 16) = 1152921513101204032 (0x10000001FA4D9A40);
        // 0x00ADBAC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADBACC: MOV x19, x0                | X19 = 1152921513101216048 (0x10000001FA4DC930);//ML01
        // 0x00ADBAD0: BL #0x16f59f0              | this..ctor();                           
        // 0x00ADBAD4: MOVZ x8, #0x1f12, lsl #48  | X8 = 2238851964756557824 (0x1F12000000000000);//ML01
        // 0x00ADBAD8: MOVK x8, #0x3bb5, lsl #32  | X8 = 2238917613331677184 (0x1F123BB500000000);
        // 0x00ADBADC: MOVK x8, #0x159a, lsl #16  | X8 = 2238917613694091264 (0x1F123BB5159A0000);
        // 0x00ADBAE0: MOVK x8, #0x55e5           | X8 = 2238917613694113253 (0x1F123BB5159A55E5);
        // 0x00ADBAE4: STR x8, [x19, #0x10]       | this.A1 = 0x159A55E5; this.A2 = 0x3BB5;  //  dest_result_addr=1152921513101216064 dest_result_addr=1152921513101216068
        this.A1 = 362436069;
        this.A2 = 15285;
        // 0x00ADBAE8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBAEC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBAF0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBC0 (11385792), len: 24  VirtAddr: 0x00ADBBC0 RVA: 0x00ADBBC0 token: 100681606 methodIndex: 54793 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        // 0x00ADBBC0: MOVZ x8, #0x1f12, lsl #48  | X8 = 2238851964756557824 (0x1F12000000000000);//ML01
        // 0x00ADBBC4: MOVK x8, #0x3bb5, lsl #32  | X8 = 2238917613331677184 (0x1F123BB500000000);
        // 0x00ADBBC8: MOVK x8, #0x159a, lsl #16  | X8 = 2238917613694091264 (0x1F123BB5159A0000);
        // 0x00ADBBCC: MOVK x8, #0x55e5           | X8 = 2238917613694113253 (0x1F123BB5159A55E5);
        // 0x00ADBBD0: STR x8, [x0, #0x10]        | this.A1 = 0x159A55E5; this.A2 = 0x3BB5;  //  dest_result_addr=1152921513101328064 dest_result_addr=1152921513101328068
        this.A1 = 362436069;
        this.A2 = 15285;
        // 0x00ADBBD4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBAF4 (11385588), len: 52  VirtAddr: 0x00ADBAF4 RVA: 0x00ADBAF4 token: 100681607 methodIndex: 54794 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetRnd()
    {
        //
        // Disasemble & Code
        // 0x00ADBAF4: LDR x8, [x0, #0x10]        | X8 = this.A1; //P2                      
        uint val_5 = this.A1;
        // 0x00ADBAF8: MOVZ w9, #0x9069           | W9 = 36969 (0x9069);//ML01              
        // 0x00ADBAFC: MOVZ w10, #0x4650          | W10 = 18000 (0x4650);//ML01             
        // 0x00ADBB00: AND w11, w8, #0xffff       | W11 = (this.A1 & 65535);                
        uint val_1 = val_5 & 65535;
        // 0x00ADBB04: UBFX x12, x8, #0x20, #0x10 | X12 = (ulong)((this.A1>>32) & 0xFFFF);  
        // 0x00ADBB08: LSR x13, x8, #0x30         | X13 = (this.A1 >> 48);                  
        uint val_2 = val_5 >> 48;
        // 0x00ADBB0C: MUL w9, w11, w9            | W9 = ((this.A1 & 65535) * 36969);       
        uint val_3 = val_1 * 36969;
        // 0x00ADBB10: MADD w10, w12, w10, w13    | W10 = ((ulong)((this.A1>>32) & 0xFFFF) * 18000) + (this.A1 >> 48);
        uint val_4 = val_2 + (((ulong)(val_5 >> 32) & 65535) * 18000);
        // 0x00ADBB14: ADD w8, w9, w8, lsr #16    | W8 = (((this.A1 & 65535) * 36969) + (this.A1) >> 16);
        val_5 = val_3 + (val_5 >> 16);
        // 0x00ADBB18: STP w8, w10, [x0, #0x10]   | this.A1 = (((this.A1 & 65535) * 36969) + (this.A1) >> 16);  this.A2 = ((ulong)((this.A1>>32) & 0xFFFF) * 18000) + (this.A1 >> 48);  //  dest_result_addr=1152921513101440064 |  dest_result_addr=1152921513101440068
        this.A1 = val_5;
        this.A2 = val_4;
        // 0x00ADBB1C: EOR w8, w10, w8, lsl #16   | W8 = (((ulong)((this.A1>>32) & 0xFFFF) * 18000) + (this.A1 >> 48) ^ ((((this.A1 & 65535) * 36969) + 
        val_5 = val_4 ^ (val_5 << 16);
        // 0x00ADBB20: MOV w0, w8                 | W0 = (((ulong)((this.A1>>32) & 0xFFFF) * 18000) + (this.A1 >> 48) ^ ((((this.A1 & 65535) * 36969) + (this.A1) >> 16)) << 16);//m1
        // 0x00ADBB24: RET                        |  return (System.UInt32)(((ulong)((this.A1>>32) & 0xFFFF) * 18000) + (this.A1 >> 48) ^ ((((this.A1 & 65535) * 36969) + (this.A1) >> 16)) << 16);
        return (uint)val_5;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }

}
