using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x285AA14
[UnityEngine.ExecuteInEditMode] // 0x285AA14
public class AstarDebugger : MonoBehaviour
{
    // Fields
    public int yOffset; //  0x00000018
    public bool show; //  0x0000001C
    public bool showInEditor; //  0x0000001D
    public bool showFPS; //  0x0000001E
    public bool showPathProfile; //  0x0000001F
    public bool showMemProfile; //  0x00000020
    public bool showGraph; //  0x00000021
    public int graphBufferSize; //  0x00000024
    public UnityEngine.Font font; //  0x00000028
    public int fontSize; //  0x00000030
    private System.Text.StringBuilder text; //  0x00000038
    private string cachedText; //  0x00000040
    private float lastUpdate; //  0x00000048
    private AstarDebugger.GraphPoint[] graph; //  0x00000050
    private float delayedDeltaTime; //  0x00000058
    private float lastCollect; //  0x0000005C
    private float lastCollectNum; //  0x00000060
    private float delta; //  0x00000064
    private float lastDeltaTime; //  0x00000068
    private int allocRate; //  0x0000006C
    private int lastAllocMemory; //  0x00000070
    private float lastAllocSet; //  0x00000074
    private int allocMem; //  0x00000078
    private int collectAlloc; //  0x0000007C
    private int peakAlloc; //  0x00000080
    private int fpsDropCounterSize; //  0x00000084
    private float[] fpsDrops; //  0x00000088
    private UnityEngine.Rect boxRect; //  0x00000090
    private UnityEngine.GUIStyle style; //  0x000000A0
    private UnityEngine.Camera cam; //  0x000000A8
    private UnityEngine.LineRenderer lineRend; //  0x000000B0
    private float graphWidth; //  0x000000B8
    private float graphHeight; //  0x000000BC
    private float graphOffset; //  0x000000C0
    private int maxVecPool; //  0x000000C4
    private int maxNodePool; //  0x000000C8
    private AstarDebugger.PathTypeDebug[] debugTypes; //  0x000000D0
    private static System.Func<int> <>f__mg$cache0; // static_offset: 0x00000000
    private static System.Func<int> <>f__mg$cache1; // static_offset: 0x00000008
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B34890 (11749520), len: 528  VirtAddr: 0x00B34890 RVA: 0x00B34890 token: 100682128 methodIndex: 24959 delegateWrapperIndex: 0 methodInvoker: 0
    public AstarDebugger()
    {
        //
        // Disasemble & Code
        //  | 
        float val_4;
        //  | 
        IntPtr val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x00B34890: STP x26, x25, [sp, #-0x50]! | stack[1152921513194318064] = ???;  stack[1152921513194318072] = ???;  //  dest_result_addr=1152921513194318064 |  dest_result_addr=1152921513194318072
        // 0x00B34894: STP x24, x23, [sp, #0x10]  | stack[1152921513194318080] = ???;  stack[1152921513194318088] = ???;  //  dest_result_addr=1152921513194318080 |  dest_result_addr=1152921513194318088
        // 0x00B34898: STP x22, x21, [sp, #0x20]  | stack[1152921513194318096] = ???;  stack[1152921513194318104] = ???;  //  dest_result_addr=1152921513194318096 |  dest_result_addr=1152921513194318104
        // 0x00B3489C: STP x20, x19, [sp, #0x30]  | stack[1152921513194318112] = ???;  stack[1152921513194318120] = ???;  //  dest_result_addr=1152921513194318112 |  dest_result_addr=1152921513194318120
        // 0x00B348A0: STP x29, x30, [sp, #0x40]  | stack[1152921513194318128] = ???;  stack[1152921513194318136] = ???;  //  dest_result_addr=1152921513194318128 |  dest_result_addr=1152921513194318136
        // 0x00B348A4: ADD x29, sp, #0x40         | X29 = (1152921513194318064 + 64) = 1152921513194318128 (0x10000001FFDA6930);
        // 0x00B348A8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B348AC: LDRB w8, [x20, #0x7a5]     | W8 = (bool)static_value_037337A5;       
        // 0x00B348B0: MOV x19, x0                | X19 = 1152921513194330144 (0x10000001FFDA9820);//ML01
        // 0x00B348B4: TBNZ w8, #0, #0xb348d0     | if (static_value_037337A5 == true) goto label_0;
        // 0x00B348B8: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00B348BC: LDR x8, [x8, #0x8c8]       | X8 = 0x2B8EC4C;                         
        // 0x00B348C0: LDR w0, [x8]               | W0 = 0x11D3;                            
        // 0x00B348C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D3, ????);     
        // 0x00B348C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B348CC: STRB w8, [x20, #0x7a5]     | static_value_037337A5 = true;            //  dest_result_addr=57882533
        label_0:
        // 0x00B348D0: MOVZ w8, #0x5              | W8 = 5 (0x5);//ML01                     
        // 0x00B348D4: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00B348D8: ORR w10, wzr, #0xc         | W10 = 12(0xC);                          
        // 0x00B348DC: MOVZ w21, #0xc8            | W21 = 200 (0xC8);//ML01                 
        // 0x00B348E0: STR w8, [x19, #0x18]       | this.yOffset = 5;                        //  dest_result_addr=1152921513194330168
        this.yOffset = 5;
        // 0x00B348E4: STRB w9, [x19, #0x1c]      | this.show = true;                        //  dest_result_addr=1152921513194330172
        this.show = true;
        // 0x00B348E8: STR w10, [x19, #0x30]      | this.fontSize = 12;                      //  dest_result_addr=1152921513194330192
        this.fontSize = 12;
        // 0x00B348EC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B348F0: STR w21, [x19, #0x24]      | this.graphBufferSize = 200;              //  dest_result_addr=1152921513194330180
        this.graphBufferSize = 200;
        // 0x00B348F4: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x00B348F8: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_1 = null;
        // 0x00B348FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00B34900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34904: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00B34908: BL #0x1b5a30c              | .ctor();                                
        val_1 = new System.Text.StringBuilder();
        // 0x00B3490C: MOVZ w8, #0xc479, lsl #16  | W8 = 3296264192 (0xC4790000);//ML01     
        // 0x00B34910: MOVK w8, #0xc000           | W8 = 3296313344 (0xC479C000);           
        // 0x00B34914: MOVZ w10, #0xc61c, lsl #16 | W10 = 3323723776 (0xC61C0000);//ML01    
        // 0x00B34918: MOVZ x11, #0x42c8, lsl #48 | X11 = 4812096201845374976 (0x42C8000000000000);//ML01
        // 0x00B3491C: MOVZ w12, #0x4248, lsl #16 | W12 = 1112014848 (0x42480000);//ML01    
        // 0x00B34920: ORR w9, wzr, #0x3f800000   | W9 = 1065353216(0x3F800000);            
        val_4 = 1f;
        // 0x00B34924: MOVK w10, #0x3c00          | W10 = 3323739136 (0xC61C3C00);          
        // 0x00B34928: MOVK x11, #0x42c8, lsl #16 | X11 = 4812096202965778432 (0x42C8000042C80000);
        // 0x00B3492C: STR w8, [x19, #0x48]       | this.lastUpdate = -999;                  //  dest_result_addr=1152921513194330216
        this.lastUpdate = -999f;
        // 0x00B34930: STR w12, [x19, #0xc0]      | this.graphOffset = 50;                   //  dest_result_addr=1152921513194330336
        this.graphOffset = 50f;
        // 0x00B34934: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B34938: STR x20, [x19, #0x38]      | this.text = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921513194330200
        this.text = val_1;
        // 0x00B3493C: STR w21, [x19, #0x84]      | this.fpsDropCounterSize = 200;           //  dest_result_addr=1152921513194330276
        this.fpsDropCounterSize = 200;
        // 0x00B34940: STR w9, [x19, #0x58]       | this.delayedDeltaTime = 1;               //  dest_result_addr=1152921513194330232
        this.delayedDeltaTime = val_4;
        // 0x00B34944: STR w10, [x19, #0x74]      | this.lastAllocSet = -9999;               //  dest_result_addr=1152921513194330260
        this.lastAllocSet = -9999f;
        // 0x00B34948: STR x11, [x19, #0xb8]      | this.graphWidth = 100; this.graphHeight = 100;  //  dest_result_addr=1152921513194330328 dest_result_addr=1152921513194330332
        this.graphWidth = 100f;
        this.graphHeight = 100f;
        // 0x00B3494C: LDR x8, [x8, #0x8e8]       | X8 = 1152921513194299920;               
        // 0x00B34950: LDR x20, [x8]              | X20 = typeof(PathTypeDebug[]);          
        // 0x00B34954: MOV x0, x20                | X0 = 1152921513194299920 (0x10000001FFDA2210);//ML01
        // 0x00B34958: BL #0x277461c              | X0 = sub_277461C( ?? typeof(PathTypeDebug[]), ????);
        // 0x00B3495C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B34960: MOV x0, x20                | X0 = 1152921513194299920 (0x10000001FFDA2210);//ML01
        // 0x00B34964: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(PathTypeDebug[]), ????);
        // 0x00B34968: MOV x20, x0                | X20 = 1152921513194299920 (0x10000001FFDA2210);//ML01
        // 0x00B3496C: CBNZ x20, #0xb34974        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00B34970: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(PathTypeDebug[]), ????);
        label_1:
        // 0x00B34974: ADRP x24, #0x364e000       | X24 = 56942592 (0x364E000);             
        // 0x00B34978: LDR x24, [x24, #0xd38]     | X24 = 1152921504838901760;              
        // 0x00B3497C: ADRP x21, #0x35c9000       | X21 = 56397824 (0x35C9000);             
        // 0x00B34980: LDR x8, [x24]              | X8 = typeof(AstarDebugger);             
        // 0x00B34984: LDR x8, [x8, #0xa0]        | X8 = AstarDebugger.__il2cppRuntimeField_static_fields;
        // 0x00B34988: LDR x21, [x21, #0xcd0]     | X21 = (string**)(1152921513194304016)("ABPath");
        val_5 = "ABPath";
        // 0x00B3498C: LDR x22, [x8]              | X22 = AstarDebugger.<>f__mg$cache0;     
        // 0x00B34990: LDR x23, [x21]             | X23 = "ABPath";                         
        val_6 = "ABPath";
        // 0x00B34994: LDR w8, [x20, #0x18]       | W8 = PathTypeDebug[].__il2cppRuntimeField_namespaze;
        // 0x00B34998: CBNZ w8, #0xb349a8         | if (PathTypeDebug[].__il2cppRuntimeField_namespaze != 0) goto label_2;
        // 0x00B3499C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(PathTypeDebug[]), ????);
        // 0x00B349A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B349A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(PathTypeDebug[]), ????);
        label_2:
        // 0x00B349A8: CBZ x22, #0xb349c8         | if (AstarDebugger.<>f__mg$cache0 == null) goto label_3;
        if((AstarDebugger.<>f__mg$cache0) == null)
        {
            goto label_3;
        }
        // 0x00B349AC: LDR x23, [x21]             | X23 = "ABPath";                         
        val_6 = "ABPath";
        // 0x00B349B0: LDR w8, [x20, #0x18]       | W8 = PathTypeDebug[].__il2cppRuntimeField_namespaze;
        // 0x00B349B4: CBNZ w8, #0xb34a0c         | if (PathTypeDebug[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B349B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(PathTypeDebug[]), ????);
        // 0x00B349BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B349C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(PathTypeDebug[]), ????);
        // 0x00B349C4: B #0xb34a0c                |  goto label_5;                          
        goto label_5;
        label_3:
        // 0x00B349C8: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B349CC: ADRP x9, #0x360d000        | X9 = 56676352 (0x360D000);              
        // 0x00B349D0: LDR x8, [x8, #0x1a0]       | X8 = 1152921513194304096;               
        // 0x00B349D4: LDR x9, [x9, #0x7f0]       | X9 = 1152921504688050176;               
        val_4 = 1152921504688050176;
        // 0x00B349D8: LDR x21, [x8]              | X21 = public static System.Int32 Pathfinding.PathPool<Pathfinding.ABPath>::GetSize();
        val_5 = public static System.Int32 Pathfinding.PathPool<Pathfinding.ABPath>::GetSize();
        // 0x00B349DC: LDR x0, [x9]               | X0 = typeof(System.Func<TResult>);      
        System.Func<System.Int32> val_2 = null;
        // 0x00B349E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
        // 0x00B349E4: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00B349E8: LDR x8, [x8, #0x6c8]       | X8 = 1152921509576714080;               
        // 0x00B349EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B349F0: MOV x2, x21                | X2 = 1152921513194304096 (0x10000001FFDA3260);//ML01
        // 0x00B349F4: MOV x22, x0                | X22 = 1152921504688050176 (0x1000000004D71000);//ML01
        // 0x00B349F8: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Int32>::.ctor(object object, IntPtr method);
        // 0x00B349FC: BL #0x2258fe8              | .ctor(object:  0, method:  val_5);      
        val_2 = new System.Func<System.Int32>(object:  0, method:  val_5);
        // 0x00B34A00: LDR x8, [x24]              | X8 = typeof(AstarDebugger);             
        // 0x00B34A04: LDR x8, [x8, #0xa0]        | X8 = AstarDebugger.__il2cppRuntimeField_static_fields;
        // 0x00B34A08: STR x22, [x8]              | AstarDebugger.<>f__mg$cache0 = typeof(System.Func<TResult>);  //  dest_result_addr=1152921504838905856
        AstarDebugger.<>f__mg$cache0 = val_2;
        label_5:
        // 0x00B34A0C: LDR x8, [x24]              | X8 = typeof(AstarDebugger);             
        // 0x00B34A10: LDR x8, [x8, #0xa0]        | X8 = AstarDebugger.__il2cppRuntimeField_static_fields;
        // 0x00B34A14: LDP x25, x9, [x8]          | X25 = typeof(System.Func<TResult>); X9 = AstarDebugger.<>f__mg$cache1; //  | 
        // 0x00B34A18: CBNZ x9, #0xb34a68         | if (AstarDebugger.<>f__mg$cache1 != null) goto label_6;
        if((AstarDebugger.<>f__mg$cache1) != null)
        {
            goto label_6;
        }
        // 0x00B34A1C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00B34A20: ADRP x9, #0x360d000        | X9 = 56676352 (0x360D000);              
        // 0x00B34A24: LDR x8, [x8, #0x108]       | X8 = 1152921513194305120;               
        // 0x00B34A28: LDR x9, [x9, #0x7f0]       | X9 = 1152921504688050176;               
        // 0x00B34A2C: LDR x21, [x8]              | X21 = public static System.Int32 Pathfinding.PathPool<Pathfinding.ABPath>::GetTotalCreated();
        val_5 = public static System.Int32 Pathfinding.PathPool<Pathfinding.ABPath>::GetTotalCreated();
        // 0x00B34A30: LDR x0, [x9]               | X0 = typeof(System.Func<TResult>);      
        System.Func<System.Int32> val_3 = null;
        // 0x00B34A34: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
        // 0x00B34A38: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00B34A3C: LDR x8, [x8, #0x6c8]       | X8 = 1152921509576714080;               
        // 0x00B34A40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34A44: MOV x2, x21                | X2 = 1152921513194305120 (0x10000001FFDA3660);//ML01
        // 0x00B34A48: MOV x22, x0                | X22 = 1152921504688050176 (0x1000000004D71000);//ML01
        // 0x00B34A4C: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Int32>::.ctor(object object, IntPtr method);
        // 0x00B34A50: BL #0x2258fe8              | .ctor(object:  0, method:  val_5);      
        val_3 = new System.Func<System.Int32>(object:  0, method:  val_5);
        // 0x00B34A54: LDR x8, [x24]              | X8 = typeof(AstarDebugger);             
        // 0x00B34A58: LDR x8, [x8, #0xa0]        | X8 = AstarDebugger.__il2cppRuntimeField_static_fields;
        // 0x00B34A5C: STR x22, [x8, #8]          | AstarDebugger.<>f__mg$cache1 = typeof(System.Func<TResult>);  //  dest_result_addr=1152921504838905864
        AstarDebugger.<>f__mg$cache1 = val_3;
        // 0x00B34A60: LDR x8, [x24]              | X8 = typeof(AstarDebugger);             
        // 0x00B34A64: LDR x8, [x8, #0xa0]        | X8 = AstarDebugger.__il2cppRuntimeField_static_fields;
        label_6:
        // 0x00B34A68: LDR x8, [x8, #8]           | X8 = typeof(System.Func<TResult>);      
        // 0x00B34A6C: STP x23, x25, [x20, #0x20] | typeof(PathTypeDebug[]).__il2cppRuntimeField_20 = "ABPath";  typeof(PathTypeDebug[]).__il2cppRuntimeField_28 = typeof(System.Func<TResult>);  //  dest_result_addr=1152921513194299952 |  dest_result_addr=1152921513194299960
        typeof(PathTypeDebug[]).__il2cppRuntimeField_20 = val_6;
        typeof(PathTypeDebug[]).__il2cppRuntimeField_28 = AstarDebugger.<>f__mg$cache0;
        // 0x00B34A70: STR x8, [x20, #0x30]       | typeof(PathTypeDebug[]).__il2cppRuntimeField_30 = typeof(System.Func<TResult>);  //  dest_result_addr=1152921513194299968
        typeof(PathTypeDebug[]).__il2cppRuntimeField_30 = AstarDebugger.<>f__mg$cache1;
        // 0x00B34A74: CBNZ x19, #0xb34a7c        | if (this != null) goto label_7;         
        if(this != null)
        {
            goto label_7;
        }
        // 0x00B34A78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  val_5), ????);
        label_7:
        // 0x00B34A7C: STR x20, [x19, #0xd0]      | this.debugTypes = typeof(PathTypeDebug[]);  //  dest_result_addr=1152921513194330352
        this.debugTypes = null;
        // 0x00B34A80: MOV x0, x19                | X0 = 1152921513194330144 (0x10000001FFDA9820);//ML01
        // 0x00B34A84: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B34A88: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B34A8C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B34A90: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B34A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34A98: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B34A9C: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B34AA0 (11750048), len: 404  VirtAddr: 0x00B34AA0 RVA: 0x00B34AA0 token: 100682129 methodIndex: 24960 delegateWrapperIndex: 0 methodInvoker: 0
    public void Start()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        // 0x00B34AA0: STP d9, d8, [sp, #-0x40]!  | stack[1152921513194520192] = ???;  stack[1152921513194520200] = ???;  //  dest_result_addr=1152921513194520192 |  dest_result_addr=1152921513194520200
        // 0x00B34AA4: STP x22, x21, [sp, #0x10]  | stack[1152921513194520208] = ???;  stack[1152921513194520216] = ???;  //  dest_result_addr=1152921513194520208 |  dest_result_addr=1152921513194520216
        // 0x00B34AA8: STP x20, x19, [sp, #0x20]  | stack[1152921513194520224] = ???;  stack[1152921513194520232] = ???;  //  dest_result_addr=1152921513194520224 |  dest_result_addr=1152921513194520232
        // 0x00B34AAC: STP x29, x30, [sp, #0x30]  | stack[1152921513194520240] = ???;  stack[1152921513194520248] = ???;  //  dest_result_addr=1152921513194520240 |  dest_result_addr=1152921513194520248
        // 0x00B34AB0: ADD x29, sp, #0x30         | X29 = (1152921513194520192 + 48) = 1152921513194520240 (0x10000001FFDD7EB0);
        // 0x00B34AB4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B34AB8: LDRB w8, [x20, #0x7a6]     | W8 = (bool)static_value_037337A6;       
        // 0x00B34ABC: MOV x19, x0                | X19 = 1152921513194532256 (0x10000001FFDDADA0);//ML01
        // 0x00B34AC0: TBNZ w8, #0, #0xb34adc     | if (static_value_037337A6 == true) goto label_0;
        // 0x00B34AC4: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
        // 0x00B34AC8: LDR x8, [x8, #0xf20]       | X8 = 0x2B8EC5C;                         
        // 0x00B34ACC: LDR w0, [x8]               | W0 = 0x11D7;                            
        // 0x00B34AD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D7, ????);     
        // 0x00B34AD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B34AD8: STRB w8, [x20, #0x7a6]     | static_value_037337A6 = true;            //  dest_result_addr=57882534
        label_0:
        // 0x00B34ADC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B34AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B34AE4: MOV x0, x19                | X0 = 1152921513194532256 (0x10000001FFDDADA0);//ML01
        // 0x00B34AE8: BL #0x1b7766c              | this.set_useGUILayout(value:  false);   
        this.useGUILayout = false;
        // 0x00B34AEC: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00B34AF0: LDR x8, [x8, #0x4a0]       | X8 = 1152921505550193520;               
        // 0x00B34AF4: LDR w21, [x19, #0x84]      | W21 = this.fpsDropCounterSize; //P2     
        // 0x00B34AF8: LDR x20, [x8]              | X20 = typeof(System.Single[]);          
        // 0x00B34AFC: MOV x0, x20                | X0 = 1152921505550193520 (0x10000000383A5370);//ML01
        // 0x00B34B00: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Single[]), ????);
        // 0x00B34B04: MOV x0, x20                | X0 = 1152921505550193520 (0x10000000383A5370);//ML01
        // 0x00B34B08: MOV x1, x21                | X1 = this.fpsDropCounterSize;//m1       
        // 0x00B34B0C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Single[]), ????);
        // 0x00B34B10: STR x0, [x19, #0x88]       | this.fpsDrops = typeof(System.Single[]);  //  dest_result_addr=1152921513194532392
        this.fpsDrops = null;
        // 0x00B34B14: ADRP x21, #0x3668000       | X21 = 57049088 (0x3668000);             
        // 0x00B34B18: LDR x21, [x21, #0x338]     | X21 = 1152921509941328016;              
        // 0x00B34B1C: MOV x0, x19                | X0 = 1152921513194532256 (0x10000001FFDDADA0);//ML01
        // 0x00B34B20: LDR x1, [x21]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x00B34B24: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_1 = this.GetComponent<UnityEngine.Camera>();
        // 0x00B34B28: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B34B2C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B34B30: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B34B34: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B34B38: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B34B3C: TBZ w9, #0, #0xb34b50      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B34B40: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B34B44: CBNZ w9, #0xb34b50         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B34B48: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B34B4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B34B50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34B54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B34B58: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B34B5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B34B60: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        // 0x00B34B64: TBZ w0, #0, #0xb34b78      | if (val_2 == false) goto label_3;       
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B34B68: LDR x1, [x21]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x00B34B6C: MOV x0, x19                | X0 = 1152921513194532256 (0x10000001FFDDADA0);//ML01
        // 0x00B34B70: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_3 = this.GetComponent<UnityEngine.Camera>();
        // 0x00B34B74: B #0xb34b84                |  goto label_4;                          
        goto label_4;
        label_3:
        // 0x00B34B78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34B7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34B80: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_4 = UnityEngine.Camera.main;
        label_4:
        // 0x00B34B84: STR x0, [x19, #0xa8]       | this.cam = val_4;                        //  dest_result_addr=1152921513194532424
        this.cam = val_4;
        // 0x00B34B88: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00B34B8C: LDR x8, [x8, #0x610]       | X8 = 1152921513194430432;               
        // 0x00B34B90: LDR w21, [x19, #0x24]      | W21 = this.graphBufferSize; //P2        
        // 0x00B34B94: LDR x20, [x8]              | X20 = typeof(GraphPoint[]);             
        // 0x00B34B98: MOV x0, x20                | X0 = 1152921513194430432 (0x10000001FFDC1FE0);//ML01
        // 0x00B34B9C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(GraphPoint[]), ????);
        // 0x00B34BA0: MOV x0, x20                | X0 = 1152921513194430432 (0x10000001FFDC1FE0);//ML01
        // 0x00B34BA4: MOV x1, x21                | X1 = this.graphBufferSize;//m1          
        // 0x00B34BA8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(GraphPoint[]), ????);
        // 0x00B34BAC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_8 = 0;
        // 0x00B34BB0: STR x0, [x19, #0x50]       | this.graph = typeof(GraphPoint[]);       //  dest_result_addr=1152921513194532336
        this.graph = null;
        // 0x00B34BB4: FMOV s9, #1.00000000       | S9 = 1;                                 
        // 0x00B34BB8: B #0xb34bc8                |  goto label_5;                          
        goto label_5;
        label_10:
        // 0x00B34BBC: ADD x8, x21, x22, lsl #2   | X8 = (this.graphBufferSize + (X22) << 2);
        int val_5 = this.graphBufferSize + ((X22) << 2);
        // 0x00B34BC0: ADD w20, w20, #1           | W20 = (val_8 + 1) = val_8 (0x00000001); 
        val_8 = 1;
        // 0x00B34BC4: STR s8, [x8, #0x20]        | mem2[0] = ???;                           //  dest_result_addr=0
        mem2[0] = ???;
        label_5:
        // 0x00B34BC8: LDR x21, [x19, #0x88]      | X21 = this.fpsDrops; //P2               
        // 0x00B34BCC: CBNZ x21, #0xb34bd4        | if (this.fpsDrops != null) goto label_6;
        if(this.fpsDrops != null)
        {
            goto label_6;
        }
        // 0x00B34BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(GraphPoint[]), ????);
        label_6:
        // 0x00B34BD4: LDR w8, [x21, #0x18]       | W8 = this.fpsDrops.Length; //P2         
        // 0x00B34BD8: CMP w20, w8                | STATE = COMPARE(0x1, this.fpsDrops.Length)
        // 0x00B34BDC: B.GE #0xb34c20             | if (val_8 >= this.fpsDrops.Length) goto label_7;
        if(val_8 >= this.fpsDrops.Length)
        {
            goto label_7;
        }
        // 0x00B34BE0: LDR x21, [x19, #0x88]      | X21 = this.fpsDrops; //P2               
        // 0x00B34BE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34BE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34BEC: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_6 = UnityEngine.Time.deltaTime;
        // 0x00B34BF0: MOV v8.16b, v0.16b         | V8 = val_6;//m1                         
        float val_7 = val_6;
        // 0x00B34BF4: CBNZ x21, #0xb34bfc        | if (this.fpsDrops != null) goto label_8;
        if(this.fpsDrops != null)
        {
            goto label_8;
        }
        // 0x00B34BF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_8:
        // 0x00B34BFC: LDR w8, [x21, #0x18]       | W8 = this.fpsDrops.Length; //P2         
        // 0x00B34C00: SXTW x22, w20              | X22 = 1 (0x00000001);                   
        // 0x00B34C04: FDIV s8, s9, s8            | S8 = (1f / val_6);                      
        val_7 = 1f / val_7;
        // 0x00B34C08: CMP w20, w8                | STATE = COMPARE(0x1, this.fpsDrops.Length)
        // 0x00B34C0C: B.LO #0xb34bbc             | if (val_8 < this.fpsDrops.Length) goto label_10;
        if(val_8 < this.fpsDrops.Length)
        {
            goto label_10;
        }
        // 0x00B34C10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B34C14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34C18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B34C1C: B #0xb34bbc                |  goto label_10;                         
        goto label_10;
        label_7:
        // 0x00B34C20: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B34C24: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B34C28: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B34C2C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B34C30: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B34C34 (11750452), len: 2384  VirtAddr: 0x00B34C34 RVA: 0x00B34C34 token: 100682130 methodIndex: 24961 delegateWrapperIndex: 0 methodInvoker: 0
    public void Update()
    {
        //
        // Disasemble & Code
        //  | 
        float val_41;
        //  | 
        float val_42;
        //  | 
        float val_43;
        //  | 
        float val_44;
        //  | 
        var val_50;
        //  | 
        float val_51;
        //  | 
        int val_52;
        //  | 
        int val_53;
        //  | 
        var val_54;
        //  | 
        int val_55;
        //  | 
        float val_56;
        //  | 
        GraphPoint[] val_57;
        //  | 
        float val_58;
        //  | 
        var val_59;
        //  | 
        var val_60;
        //  | 
        float val_61;
        //  | 
        var val_62;
        //  | 
        float val_63;
        //  | 
        float val_64;
        //  | 
        var val_65;
        //  | 
        GraphPoint[] val_66;
        //  | 
        var val_67;
        //  | 
        GraphPoint[] val_68;
        //  | 
        var val_69;
        // 0x00B34C34: STP d15, d14, [sp, #-0xa0]! | stack[1152921513195508688] = ???;  stack[1152921513195508696] = ???;  //  dest_result_addr=1152921513195508688 |  dest_result_addr=1152921513195508696
        // 0x00B34C38: STP d13, d12, [sp, #0x10]  | stack[1152921513195508704] = ???;  stack[1152921513195508712] = ???;  //  dest_result_addr=1152921513195508704 |  dest_result_addr=1152921513195508712
        // 0x00B34C3C: STP d11, d10, [sp, #0x20]  | stack[1152921513195508720] = ???;  stack[1152921513195508728] = ???;  //  dest_result_addr=1152921513195508720 |  dest_result_addr=1152921513195508728
        // 0x00B34C40: STP d9, d8, [sp, #0x30]    | stack[1152921513195508736] = ???;  stack[1152921513195508744] = ???;  //  dest_result_addr=1152921513195508736 |  dest_result_addr=1152921513195508744
        // 0x00B34C44: STP x28, x27, [sp, #0x40]  | stack[1152921513195508752] = ???;  stack[1152921513195508760] = ???;  //  dest_result_addr=1152921513195508752 |  dest_result_addr=1152921513195508760
        // 0x00B34C48: STP x26, x25, [sp, #0x50]  | stack[1152921513195508768] = ???;  stack[1152921513195508776] = ???;  //  dest_result_addr=1152921513195508768 |  dest_result_addr=1152921513195508776
        // 0x00B34C4C: STP x24, x23, [sp, #0x60]  | stack[1152921513195508784] = ???;  stack[1152921513195508792] = ???;  //  dest_result_addr=1152921513195508784 |  dest_result_addr=1152921513195508792
        // 0x00B34C50: STP x22, x21, [sp, #0x70]  | stack[1152921513195508800] = ???;  stack[1152921513195508808] = ???;  //  dest_result_addr=1152921513195508800 |  dest_result_addr=1152921513195508808
        // 0x00B34C54: STP x20, x19, [sp, #0x80]  | stack[1152921513195508816] = ???;  stack[1152921513195508824] = ???;  //  dest_result_addr=1152921513195508816 |  dest_result_addr=1152921513195508824
        // 0x00B34C58: STP x29, x30, [sp, #0x90]  | stack[1152921513195508832] = ???;  stack[1152921513195508840] = ???;  //  dest_result_addr=1152921513195508832 |  dest_result_addr=1152921513195508840
        // 0x00B34C5C: ADD x29, sp, #0x90         | X29 = (1152921513195508688 + 144) = 1152921513195508832 (0x10000001FFEC9460);
        // 0x00B34C60: SUB sp, sp, #0x170         | SP = (1152921513195508688 - 368) = 1152921513195508320 (0x10000001FFEC9260);
        // 0x00B34C64: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B34C68: LDRB w8, [x20, #0x7a7]     | W8 = (bool)static_value_037337A7;       
        // 0x00B34C6C: MOV x19, x0                | X19 = 1152921513195520848 (0x10000001FFECC350);//ML01
        // 0x00B34C70: TBNZ w8, #0, #0xb34c8c     | if (static_value_037337A7 == true) goto label_0;
        // 0x00B34C74: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00B34C78: LDR x8, [x8, #0xb78]       | X8 = 0x2B8EC60;                         
        // 0x00B34C7C: LDR w0, [x8]               | W0 = 0x11D8;                            
        // 0x00B34C80: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D8, ????);     
        // 0x00B34C84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B34C88: STRB w8, [x20, #0x7a7]     | static_value_037337A7 = true;            //  dest_result_addr=57882535
        label_0:
        // 0x00B34C8C: STP xzr, xzr, [x29, #-0xa0] | stack[1152921513195508672] = 0x0;  stack[1152921513195508680] = 0x0;  //  dest_result_addr=1152921513195508672 |  dest_result_addr=1152921513195508680
        // 0x00B34C90: STP xzr, xzr, [x29, #-0xb0] | stack[1152921513195508656] = 0x0;  stack[1152921513195508664] = 0x0;  //  dest_result_addr=1152921513195508656 |  dest_result_addr=1152921513195508664
        // 0x00B34C94: STP xzr, xzr, [x29, #-0xc0] | stack[1152921513195508640] = 0x0;  stack[1152921513195508648] = 0x0;  //  dest_result_addr=1152921513195508640 |  dest_result_addr=1152921513195508648
        // 0x00B34C98: STP xzr, xzr, [x29, #-0xd0] | stack[1152921513195508624] = 0x0;  stack[1152921513195508632] = 0x0;  //  dest_result_addr=1152921513195508624 |  dest_result_addr=1152921513195508632
        // 0x00B34C9C: LDRB w8, [x19, #0x1c]      | W8 = this.show; //P2                    
        // 0x00B34CA0: CBZ w8, #0xb35550          | if (this.show == false) goto label_32;  
        if(this.show == false)
        {
            goto label_32;
        }
        // 0x00B34CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34CA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34CAC: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_1 = UnityEngine.Application.isPlaying;
        // 0x00B34CB0: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B34CB4: TBNZ w8, #0, #0xb34cc0     | if ((val_1 & 1) == true) goto label_2;  
        if(val_2 == true)
        {
            goto label_2;
        }
        // 0x00B34CB8: LDRB w8, [x19, #0x1d]      | W8 = this.showInEditor; //P2            
        // 0x00B34CBC: CBZ w8, #0xb35550          | if (this.showInEditor == false) goto label_32;
        if(this.showInEditor == false)
        {
            goto label_32;
        }
        label_2:
        // 0x00B34CC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34CC4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B34CC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B34CCC: BL #0x1c3f8c8              | X0 = System.GC.CollectionCount(generation:  0);
        int val_3 = System.GC.CollectionCount(generation:  0);
        // 0x00B34CD0: LDR s1, [x19, #0x60]       | S1 = this.lastCollectNum; //P2          
        // 0x00B34CD4: SCVTF s0, w0               | S0 = (float)(val_3);                    
        val_51 = (float)val_3;
        // 0x00B34CD8: FCMP s1, s0                | STATE = COMPARE(this.lastCollectNum, val_3)
        // 0x00B34CDC: B.NE #0xb34ce8             | if (this.lastCollectNum != val_51) goto label_4;
        if(this.lastCollectNum != val_51)
        {
            goto label_4;
        }
        // 0x00B34CE0: ADD x22, x19, #0x78        | X22 = this.allocMem;//AP2 res_addr=1152921513195520968
        val_52 = this.allocMem;
        // 0x00B34CE4: B #0xb34d30                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00B34CE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34CEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34CF0: STR s0, [x19, #0x60]       | this.lastCollectNum = val_3;             //  dest_result_addr=1152921513195520944
        this.lastCollectNum = val_51;
        // 0x00B34CF4: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_4 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B34CF8: LDR s1, [x19, #0x5c]       | S1 = this.lastCollect; //P2             
        // 0x00B34CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34D00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34D04: FSUB s0, s0, s1            | S0 = (val_4 - this.lastCollect);        
        val_51 = val_4 - this.lastCollect;
        // 0x00B34D08: STR s0, [x19, #0x64]       | this.delta = (val_4 - this.lastCollect);  //  dest_result_addr=1152921513195520948
        this.delta = val_51;
        // 0x00B34D0C: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_5 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B34D10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34D14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34D18: STR s0, [x19, #0x5c]       | this.lastCollect = val_5;                //  dest_result_addr=1152921513195520940
        this.lastCollect = val_5;
        // 0x00B34D1C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_6 = UnityEngine.Time.deltaTime;
        // 0x00B34D20: STR s0, [x19, #0x68]       | this.lastDeltaTime = val_6;              //  dest_result_addr=1152921513195520952
        this.lastDeltaTime = val_6;
        // 0x00B34D24: MOV x22, x19               | X22 = 1152921513195520848 (0x10000001FFECC350);//ML01
        val_52 = this;
        // 0x00B34D28: LDR w8, [x22, #0x78]!      | W8 = this.allocMem; //P2                
        // 0x00B34D2C: STR w8, [x22, #4]          | mem[1152921513195520972] = this.allocMem;  //  dest_result_addr=1152921513195520972
        mem[1152921513195520972] = this.allocMem;
        label_5:
        // 0x00B34D30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34D34: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B34D38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B34D3C: BL #0x1c3f8b0              | X0 = System.GC.GetTotalMemory(forceFullCollection:  false);
        long val_7 = System.GC.GetTotalMemory(forceFullCollection:  false);
        // 0x00B34D40: LDR w23, [x19, #0x80]      | W23 = this.peakAlloc; //P2              
        val_53 = this.peakAlloc;
        // 0x00B34D44: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B34D48: STR w20, [x19, #0x78]      | this.allocMem = val_7;                   //  dest_result_addr=1152921513195520968
        this.allocMem = val_7;
        // 0x00B34D4C: CMP w20, w23               | STATE = COMPARE(val_7, this.peakAlloc)  
        // 0x00B34D50: CSEL w8, w23, w20, lt      | W8 = val_7 < val_53 ? this.peakAlloc : val_7;
        int val_8 = (val_7 < val_53) ? (val_53) : (val_7);
        // 0x00B34D54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34D58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34D5C: STR w8, [x19, #0x80]       | this.peakAlloc = val_7 < val_53 ? this.peakAlloc : val_7;  //  dest_result_addr=1152921513195520976
        this.peakAlloc = val_8;
        // 0x00B34D60: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_9 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B34D64: LDR s1, [x19, #0x74]       | S1 = this.lastAllocSet; //P2            
        // 0x00B34D68: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B34D6C: LDR s2, [x8, #0x934]       | S2 = 0.3;                               
        // 0x00B34D70: FSUB s0, s0, s1            | S0 = (val_9 - this.lastAllocSet);       
        val_9 = val_9 - this.lastAllocSet;
        // 0x00B34D74: FCMP s0, s2                | STATE = COMPARE((val_9 - this.lastAllocSet), 0.300000011920929)
        // 0x00B34D78: B.GT #0xb34d90             | if (val_9 > 0.3f) goto label_6;         
        if(val_9 > 0.3f)
        {
            goto label_6;
        }
        // 0x00B34D7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34D80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34D84: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_10 = UnityEngine.Application.isPlaying;
        // 0x00B34D88: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        bool val_11 = val_10;
        // 0x00B34D8C: TBNZ w8, #0, #0xb34dc8     | if ((val_10 & 1) == true) goto label_8; 
        if(val_11 == true)
        {
            goto label_8;
        }
        label_6:
        // 0x00B34D90: LDR w8, [x19, #0x78]       | W8 = this.allocMem; //P2                
        // 0x00B34D94: LDR w9, [x19, #0x70]       | W9 = this.lastAllocMemory; //P2         
        // 0x00B34D98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34DA0: STR w8, [x19, #0x70]       | this.lastAllocMemory = this.allocMem;    //  dest_result_addr=1152921513195520960
        this.lastAllocMemory = this.allocMem;
        // 0x00B34DA4: SUB w21, w8, w9            | W21 = (this.allocMem - this.lastAllocMemory);
        val_55 = this.allocMem - this.lastAllocMemory;
        // 0x00B34DA8: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_12 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B34DAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34DB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34DB4: STR s0, [x19, #0x74]       | this.lastAllocSet = val_12;              //  dest_result_addr=1152921513195520964
        this.lastAllocSet = val_12;
        // 0x00B34DB8: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_13 = UnityEngine.Time.deltaTime;
        // 0x00B34DBC: STR s0, [x19, #0x58]       | this.delayedDeltaTime = val_13;          //  dest_result_addr=1152921513195520936
        this.delayedDeltaTime = val_13;
        // 0x00B34DC0: TBNZ w21, #0x1f, #0xb34dc8 | if (((this.allocMem - this.lastAllocMemory) & 0x80000000) != 0) goto label_8;
        if((val_55 & 2147483648) != 0)
        {
            goto label_8;
        }
        // 0x00B34DC4: STR w21, [x19, #0x6c]      | this.allocRate = (this.allocMem - this.lastAllocMemory);  //  dest_result_addr=1152921513195520956
        this.allocRate = val_55;
        label_8:
        // 0x00B34DC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34DCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34DD0: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_14 = UnityEngine.Application.isPlaying;
        // 0x00B34DD4: TBZ w0, #0, #0xb34fbc      | if (val_14 == false) goto label_9;      
        if(val_14 == false)
        {
            goto label_9;
        }
        // 0x00B34DD8: LDR x24, [x19, #0x88]      | X24 = this.fpsDrops; //P2               
        // 0x00B34DDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34DE4: BL #0x269115c              | X0 = UnityEngine.Time.get_frameCount(); 
        int val_15 = UnityEngine.Time.frameCount;
        // 0x00B34DE8: LDR x25, [x19, #0x88]      | X25 = this.fpsDrops; //P2               
        // 0x00B34DEC: MOV w21, w0                | W21 = val_15;//m1                       
        // 0x00B34DF0: CBNZ x25, #0xb34df8        | if (this.fpsDrops != null) goto label_10;
        if(this.fpsDrops != null)
        {
            goto label_10;
        }
        // 0x00B34DF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_10:
        // 0x00B34DF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34DFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34E00: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_16 = UnityEngine.Time.deltaTime;
        // 0x00B34E04: LDR w25, [x25, #0x18]      | W25 = this.fpsDrops.Length; //P2        
        int val_53 = this.fpsDrops.Length;
        // 0x00B34E08: FCMP s0, #0.0              | STATE = COMPARE(val_16, 0)              
        // 0x00B34E0C: SDIV w26, w21, w25         | W26 = (val_15 / this.fpsDrops.Length);  
        int val_17 = val_15 / val_53;
        // 0x00B34E10: B.NE #0xb34e20             | if (val_16 != 0) goto label_11;         
        if(val_16 != 0f)
        {
            goto label_11;
        }
        // 0x00B34E14: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B34E18: LDR s8, [x8, #0x930]       | S8 = Infinity;                          
        val_56 = Infinityf;
        // 0x00B34E1C: B #0xb34e34                |  goto label_12;                         
        goto label_12;
        label_11:
        // 0x00B34E20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34E24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34E28: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_18 = UnityEngine.Time.deltaTime;
        // 0x00B34E2C: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B34E30: FDIV s8, s1, s0            | S8 = (1f / val_18);                     
        val_56 = 1f / val_18;
        label_12:
        // 0x00B34E34: MSUB w25, w26, w25, w21    | W25 = val_15 - ((val_15 / this.fpsDrops.Length) * this.fpsDrops.Length);
        val_53 = val_15 - (val_17 * val_53);
        // 0x00B34E38: CBNZ x24, #0xb34e40        | if (this.fpsDrops != null) goto label_13;
        if(this.fpsDrops != null)
        {
            goto label_13;
        }
        // 0x00B34E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_13:
        // 0x00B34E40: LDR w8, [x24, #0x18]       | W8 = this.fpsDrops.Length; //P2         
        // 0x00B34E44: SXTW x21, w25              | X21 = (long)(int)(val_15 - ((val_15 / this.fpsDrops.Length) * this.fpsDrops.Length));
        // 0x00B34E48: CMP w25, w8                | STATE = COMPARE(val_15 - ((val_15 / this.fpsDrops.Length) * this.fpsDrops.Length), this.fpsDrops.Length)
        // 0x00B34E4C: B.LO #0xb34e5c             | if (this.fpsDrops.Length < this.fpsDrops.Length) goto label_14;
        if(val_53 < this.fpsDrops.Length)
        {
            goto label_14;
        }
        // 0x00B34E50: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B34E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34E58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_14:
        // 0x00B34E5C: ADD x8, x24, x21, lsl #2   | X8 = this.fpsDrops[(long)(int)(val_15 - ((val_15 / this.fpsDrops.Length) * this.fpsDrops.Length))]; //PARR1 
        // 0x00B34E60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34E68: STR s8, [x8, #0x20]        | this.fpsDrops[(long)(int)(val_15 - ((val_15 / this.fpsDrops.Length) * this.fpsDrops.Length))][0] = (1f / val_18);  //  dest_result_addr=0
        this.fpsDrops[(long)val_53] = val_56;
        // 0x00B34E6C: BL #0x269115c              | X0 = UnityEngine.Time.get_frameCount(); 
        int val_19 = UnityEngine.Time.frameCount;
        // 0x00B34E70: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        val_57 = this.graph;
        // 0x00B34E74: MOV w21, w0                | W21 = val_19;//m1                       
        // 0x00B34E78: CBZ x24, #0xb34e8c         | if (this.graph == null) goto label_15;  
        if(val_57 == null)
        {
            goto label_15;
        }
        // 0x00B34E7C: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B34E80: SDIV w9, w21, w8           | W9 = (val_19 / this.graph.Length);      
        int val_20 = val_19 / this.graph.Length;
        // 0x00B34E84: MSUB w21, w9, w8, w21      | W21 = val_19 - ((val_19 / this.graph.Length) * this.graph.Length);
        val_55 = val_19 - (val_20 * this.graph.Length);
        // 0x00B34E88: B #0xb34eac                |  goto label_17;                         
        goto label_17;
        label_15:
        // 0x00B34E8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        // 0x00B34E90: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B34E94: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        val_57 = this.graph;
        // 0x00B34E98: SDIV w9, w21, w8           | W9 = (val_19 / this.graph.Length);      
        int val_21 = val_19 / this.graph.Length;
        // 0x00B34E9C: MSUB w21, w9, w8, w21      | W21 = val_19 - ((val_19 / this.graph.Length) * this.graph.Length);
        val_55 = val_19 - (val_21 * this.graph.Length);
        // 0x00B34EA0: CBNZ x24, #0xb34eac        | if (this.graph != null) goto label_17;  
        if(val_57 != null)
        {
            goto label_17;
        }
        // 0x00B34EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        // 0x00B34EA8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
        val_57 = 0;
        label_17:
        // 0x00B34EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34EB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34EB4: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_22 = UnityEngine.Time.deltaTime;
        // 0x00B34EB8: ADRP x25, #0x363f000       | X25 = 56881152 (0x363F000);             
        // 0x00B34EBC: LDR x25, [x25, #0x3b0]     | X25 = 1152921504695345152;              
        // 0x00B34EC0: MOV v8.16b, v0.16b         | V8 = val_22;//m1                        
        val_58 = val_22;
        // 0x00B34EC4: LDR x0, [x25]              | X0 = typeof(UnityEngine.Mathf);         
        val_59 = null;
        // 0x00B34EC8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B34ECC: TBZ w8, #0, #0xb34ee0      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B34ED0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B34ED4: CBNZ w8, #0xb34ee0         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B34ED8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00B34EDC: LDR x0, [x25]              | X0 = typeof(UnityEngine.Mathf);         
        val_59 = null;
        label_19:
        // 0x00B34EE0: LDR x8, [x0, #0xa0]        | X8 = UnityEngine.Mathf.__il2cppRuntimeField_static_fields;
        // 0x00B34EE4: LDR w9, [x24, #0x18]       | W9 = 0x9814C0;                          
        // 0x00B34EE8: LDR s9, [x8]               | S9 = UnityEngine.Mathf.Epsilon;         
        // 0x00B34EEC: CMP w21, w9                | STATE = COMPARE(val_19 - ((val_19 / this.graph.Length) * this.graph.Length), 0x9814C0)
        // 0x00B34EF0: B.LO #0xb34f00             | if (val_55 < 9966784) goto label_20;    
        if(val_55 < 9966784)
        {
            goto label_20;
        }
        // 0x00B34EF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00B34EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34EFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Mathf), ????);
        label_20:
        // 0x00B34F00: SXTW x25, w21              | X25 = (long)(int)(val_19 - ((val_19 / this.graph.Length) * this.graph.Length));
        val_60 = (long)val_55;
        // 0x00B34F04: FCMP s8, s9                | STATE = COMPARE(val_22, UnityEngine.Mathf.Epsilon)
        // 0x00B34F08: B.PL #0xb34f14             | if (val_58 >= 0) goto label_21;         
        if(val_58 >= 0)
        {
            goto label_21;
        }
        // 0x00B34F0C: FMOV s0, wzr               | S0 = 0f;                                
        val_61 = 0f;
        // 0x00B34F10: B #0xb34f40                |  goto label_22;                         
        goto label_22;
        label_21:
        // 0x00B34F14: LDR w8, [x24, #0x18]       | W8 = 0x9814C0;                          
        // 0x00B34F18: CMP w21, w8                | STATE = COMPARE(val_19 - ((val_19 / this.graph.Length) * this.graph.Length), 0x9814C0)
        // 0x00B34F1C: B.LO #0xb34f2c             | if (val_55 < 9966784) goto label_23;    
        if(val_55 < 9966784)
        {
            goto label_23;
        }
        // 0x00B34F20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00B34F24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34F28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Mathf), ????);
        label_23:
        // 0x00B34F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34F34: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_23 = UnityEngine.Time.deltaTime;
        // 0x00B34F38: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B34F3C: FDIV s0, s1, s0            | S0 = (1f / val_23);                     
        val_61 = 1f / val_23;
        label_22:
        // 0x00B34F40: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_54 = 12;
        // 0x00B34F44: MADD x8, x25, x8, x24      | X8 = ((long)(int)(val_19 - ((val_19 / this.graph.Length) * this.graph.Length)) * 12) + val_57;
        val_54 = val_57 + (val_60 * val_54);
        // 0x00B34F48: STR s0, [x8, #0x20]        | mem2[0] = (1f / val_23);                 //  dest_result_addr=0
        mem2[0] = val_61;
        // 0x00B34F4C: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        // 0x00B34F50: CBNZ x24, #0xb34f58        | if (this.graph != null) goto label_24;  
        if(this.graph != null)
        {
            goto label_24;
        }
        // 0x00B34F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_24:
        // 0x00B34F58: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B34F5C: CMP w21, w8                | STATE = COMPARE(val_19 - ((val_19 / this.graph.Length) * this.graph.Length), this.graph.Length)
        // 0x00B34F60: B.LO #0xb34f70             | if (val_55 < this.graph.Length) goto label_25;
        if(val_55 < this.graph.Length)
        {
            goto label_25;
        }
        // 0x00B34F64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B34F68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34F6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_25:
        // 0x00B34F70: CMP w20, w23               | STATE = COMPARE(val_7, this.peakAlloc)  
        // 0x00B34F74: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_55 = 12;
        // 0x00B34F78: CSET w9, lt                | W9 = val_7 < val_53 ? 1 : 0;            
        var val_24 = (val_7 < val_53) ? 1 : 0;
        // 0x00B34F7C: MADD x8, x25, x8, x24      | X8 = ((long)(int)(val_19 - ((val_19 / this.graph.Length) * this.graph.Length)) * 12) + this.graph;
        val_55 = this.graph + (val_60 * val_55);
        // 0x00B34F80: STRB w9, [x8, #0x28]       | mem2[0] = val_7 < val_53 ? 1 : 0;        //  dest_result_addr=0
        mem2[0] = val_24;
        // 0x00B34F84: LDR x20, [x19, #0x50]      | X20 = this.graph; //P2                  
        // 0x00B34F88: CBNZ x20, #0xb34f90        | if (this.graph != null) goto label_26;  
        if(this.graph != null)
        {
            goto label_26;
        }
        // 0x00B34F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_26:
        // 0x00B34F90: LDR w8, [x20, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B34F94: LDR w22, [x22]             | W22 = val_7;                            
        // 0x00B34F98: CMP w21, w8                | STATE = COMPARE(val_19 - ((val_19 / this.graph.Length) * this.graph.Length), this.graph.Length)
        // 0x00B34F9C: B.LO #0xb34fac             | if (val_55 < this.graph.Length) goto label_27;
        if(val_55 < this.graph.Length)
        {
            goto label_27;
        }
        // 0x00B34FA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B34FA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34FA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_27:
        // 0x00B34FAC: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_56 = 12;
        // 0x00B34FB0: SCVTF s0, w22              | S0 = (float)(val_7);                    
        // 0x00B34FB4: MADD x8, x25, x8, x20      | X8 = ((long)(int)(val_19 - ((val_19 / this.graph.Length) * this.graph.Length)) * 12) + this.graph;
        val_56 = this.graph + (val_60 * val_56);
        // 0x00B34FB8: STR s0, [x8, #0x24]        | mem2[0] = val_7;                         //  dest_result_addr=0
        mem2[0] = (float)this.allocMem;
        label_9:
        // 0x00B34FBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34FC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B34FC4: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_25 = UnityEngine.Application.isPlaying;
        // 0x00B34FC8: TBZ w0, #0, #0xb35550      | if (val_25 == false) goto label_32;     
        if(val_25 == false)
        {
            goto label_32;
        }
        // 0x00B34FCC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B34FD0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B34FD4: LDR x20, [x19, #0xa8]      | X20 = this.cam; //P2                    
        // 0x00B34FD8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B34FDC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B34FE0: TBZ w8, #0, #0xb34ff0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00B34FE4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B34FE8: CBNZ w8, #0xb34ff0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00B34FEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_30:
        // 0x00B34FF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B34FF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B34FF8: MOV x1, x20                | X1 = this.cam;//m1                      
        // 0x00B34FFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B35000: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.cam);
        bool val_26 = UnityEngine.Object.op_Inequality(x:  0, y:  this.cam);
        // 0x00B35004: TBZ w0, #0, #0xb35550      | if (val_26 == false) goto label_32;     
        if(val_26 == false)
        {
            goto label_32;
        }
        // 0x00B35008: LDRB w8, [x19, #0x21]      | W8 = this.showGraph; //P2               
        // 0x00B3500C: CBZ w8, #0xb35550          | if (this.showGraph == false) goto label_32;
        if(this.showGraph == false)
        {
            goto label_32;
        }
        // 0x00B35010: LDR x20, [x19, #0xa8]      | X20 = this.cam; //P2                    
        // 0x00B35014: CBNZ x20, #0xb3501c        | if (this.cam != null) goto label_33;    
        if(this.cam != null)
        {
            goto label_33;
        }
        // 0x00B35018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_33:
        // 0x00B3501C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35020: MOV x0, x20                | X0 = this.cam;//m1                      
        // 0x00B35024: BL #0x20cff54              | X0 = this.cam.get_pixelWidth();         
        int val_27 = this.cam.pixelWidth;
        // 0x00B35028: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B3502C: LDR s1, [x8, #0x918]       | S1 = 0.8;                               
        // 0x00B35030: SCVTF s0, w0               | S0 = (float)(val_27);                   
        float val_57 = (float)val_27;
        // 0x00B35034: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B35038: LDR s9, [x8, #0x930]       | S9 = Infinity;                          
        // 0x00B3503C: FMUL s0, s0, s1            | S0 = (val_27 * 0.8f);                   
        val_57 = val_57 * 0.8f;
        // 0x00B35040: STR s0, [x19, #0xb8]       | this.graphWidth = (val_27 * 0.8f);       //  dest_result_addr=1152921513195521032
        this.graphWidth = val_57;
        // 0x00B35044: ADRP x22, #0x363f000       | X22 = 56881152 (0x363F000);             
        // 0x00B35048: LDR x22, [x22, #0x3b0]     | X22 = 1152921504695345152;              
        // 0x00B3504C: FMOV s8, wzr               | S8 = 0f;                                
        val_58 = 0f;
        // 0x00B35050: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_62 = 0;
        // 0x00B35054: ORR w21, wzr, #0xc         | W21 = 12(0xC);                          
        // 0x00B35058: MOV v10.16b, v8.16b        | V10 = 0;//m1                            
        // 0x00B3505C: MOV v11.16b, v9.16b        | V11 = 2139095040 (0x7F800000);//ML01    
        // 0x00B35060: B #0xb35084                |  goto label_34;                         
        goto label_34;
        label_47:
        // 0x00B35064: MADD x8, x23, x21, x24     | X8 = (this.peakAlloc * 12) + this.graph;
        int val_28 = this.graph + (val_53 * 12);
        // 0x00B35068: LDR s0, [x8, #0x20]        | S0 = (this.peakAlloc * 12) + this.graph + 32;
        // 0x00B3506C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35070: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35074: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x00B35078: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  (this.peakAlloc * 12) + this.graph + 32, b:  val_58);
        float val_29 = UnityEngine.Mathf.Max(a:  (this.peakAlloc * 12) + this.graph + 32, b:  val_58);
        // 0x00B3507C: MOV v8.16b, v0.16b         | V8 = val_29;//m1                        
        val_58 = val_29;
        // 0x00B35080: ADD w20, w20, #1           | W20 = (val_62 + 1) = val_62 (0x00000001);
        val_62 = 1;
        label_34:
        // 0x00B35084: LDR x23, [x19, #0x50]      | X23 = this.graph; //P2                  
        // 0x00B35088: CBNZ x23, #0xb35090        | if (this.graph != null) goto label_35;  
        if(this.graph != null)
        {
            goto label_35;
        }
        // 0x00B3508C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_35:
        // 0x00B35090: LDR w8, [x23, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35094: CMP w20, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B35098: B.GE #0xb351a8             | if (val_62 >= this.graph.Length) goto label_36;
        if(val_62 >= this.graph.Length)
        {
            goto label_36;
        }
        // 0x00B3509C: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        // 0x00B350A0: CBNZ x24, #0xb350a8        | if (this.graph != null) goto label_37;  
        if(this.graph != null)
        {
            goto label_37;
        }
        // 0x00B350A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_37:
        // 0x00B350A8: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B350AC: SXTW x23, w20              | X23 = 1 (0x00000001);                   
        // 0x00B350B0: CMP w20, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B350B4: B.LO #0xb350c4             | if (val_62 < this.graph.Length) goto label_38;
        if(val_62 < this.graph.Length)
        {
            goto label_38;
        }
        // 0x00B350B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B350BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B350C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_38:
        // 0x00B350C4: LDR x0, [x22]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B350C8: NOP                        | 
        // 0x00B350CC: MADD x8, x23, x21, x24     | X8 = (1 * 12) + this.graph;             
        var val_30 = this.graph + (1 * 12);
        // 0x00B350D0: LDR s12, [x8, #0x24]       | S12 = (1 * 12) + this.graph + 36;       
        // 0x00B350D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B350D8: TBZ w8, #0, #0xb350e8      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00B350DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B350E0: CBNZ w8, #0xb350e8         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00B350E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_40:
        // 0x00B350E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B350EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B350F0: MOV v0.16b, v12.16b        | V0 = (1 * 12) + this.graph + 36;//m1    
        // 0x00B350F4: MOV v1.16b, v11.16b        | V1 = 2139095040 (0x7F800000);//ML01     
        // 0x00B350F8: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  (1 * 12) + this.graph + 36, b:  Infinityf);
        float val_31 = UnityEngine.Mathf.Min(a:  (1 * 12) + this.graph + 36, b:  Infinityf);
        // 0x00B350FC: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        // 0x00B35100: MOV v11.16b, v0.16b        | V11 = val_31;//m1                       
        // 0x00B35104: CBNZ x24, #0xb3510c        | if (this.graph != null) goto label_41;  
        if(this.graph != null)
        {
            goto label_41;
        }
        // 0x00B35108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_41:
        // 0x00B3510C: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35110: CMP w20, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B35114: B.LO #0xb35124             | if (val_62 < this.graph.Length) goto label_42;
        if(val_62 < this.graph.Length)
        {
            goto label_42;
        }
        // 0x00B35118: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B3511C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35120: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_42:
        // 0x00B35124: MADD x8, x23, x21, x24     | X8 = (1 * 12) + this.graph;             
        var val_32 = this.graph + (1 * 12);
        // 0x00B35128: LDR s0, [x8, #0x24]        | S0 = (1 * 12) + this.graph + 36;        
        // 0x00B3512C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35134: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B35138: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  (1 * 12) + this.graph + 36, b:  val_58);
        float val_33 = UnityEngine.Mathf.Max(a:  (1 * 12) + this.graph + 36, b:  val_58);
        // 0x00B3513C: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        // 0x00B35140: MOV v10.16b, v0.16b        | V10 = val_33;//m1                       
        // 0x00B35144: CBNZ x24, #0xb3514c        | if (this.graph != null) goto label_43;  
        if(this.graph != null)
        {
            goto label_43;
        }
        // 0x00B35148: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_43:
        // 0x00B3514C: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35150: CMP w20, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B35154: B.LO #0xb35164             | if (val_62 < this.graph.Length) goto label_44;
        if(val_62 < this.graph.Length)
        {
            goto label_44;
        }
        // 0x00B35158: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B3515C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35160: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_44:
        // 0x00B35164: MADD x8, x23, x21, x24     | X8 = (1 * 12) + this.graph;             
        var val_34 = this.graph + (1 * 12);
        // 0x00B35168: LDR s0, [x8, #0x20]        | S0 = (1 * 12) + this.graph + 32;        
        // 0x00B3516C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35170: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35174: MOV v1.16b, v9.16b         | V1 = 2139095040 (0x7F800000);//ML01     
        // 0x00B35178: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  (1 * 12) + this.graph + 32, b:  Infinityf);
        float val_35 = UnityEngine.Mathf.Min(a:  (1 * 12) + this.graph + 32, b:  Infinityf);
        // 0x00B3517C: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        // 0x00B35180: MOV v9.16b, v0.16b         | V9 = val_35;//m1                        
        // 0x00B35184: CBNZ x24, #0xb3518c        | if (this.graph != null) goto label_45;  
        if(this.graph != null)
        {
            goto label_45;
        }
        // 0x00B35188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_45:
        // 0x00B3518C: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35190: CMP w20, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B35194: B.LO #0xb35064             | if (val_62 < this.graph.Length) goto label_47;
        if(val_62 < this.graph.Length)
        {
            goto label_47;
        }
        // 0x00B35198: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B3519C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B351A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B351A4: B #0xb35064                |  goto label_47;                         
        goto label_47;
        label_36:
        // 0x00B351A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B351AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B351B0: BL #0x269115c              | X0 = UnityEngine.Time.get_frameCount(); 
        int val_36 = UnityEngine.Time.frameCount;
        // 0x00B351B4: LDR x21, [x19, #0x50]      | X21 = this.graph; //P2                  
        // 0x00B351B8: MOV w20, w0                | W20 = val_36;//m1                       
        var val_59 = val_36;
        // 0x00B351BC: CBNZ x21, #0xb351c4        | if (this.graph != null) goto label_48;  
        if(this.graph != null)
        {
            goto label_48;
        }
        // 0x00B351C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_48:
        // 0x00B351C4: LDR w22, [x21, #0x18]      | W22 = this.graph.Length; //P2           
        // 0x00B351C8: LDR x21, [x19, #0xa8]      | X21 = this.cam; //P2                    
        // 0x00B351CC: CBNZ x21, #0xb351d4        | if (this.cam != null) goto label_49;    
        if(this.cam != null)
        {
            goto label_49;
        }
        // 0x00B351D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_49:
        // 0x00B351D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B351D8: MOV x0, x21                | X0 = this.cam;//m1                      
        // 0x00B351DC: BL #0x20cff54              | X0 = this.cam.get_pixelWidth();         
        int val_37 = this.cam.pixelWidth;
        // 0x00B351E0: LDR s0, [x19, #0xb8]       | S0 = this.graphWidth; //P2              
        float val_58 = this.graphWidth;
        // 0x00B351E4: LDR s1, [x19, #0xc0]       | S1 = this.graphOffset; //P2             
        // 0x00B351E8: SCVTF s2, w0               | S2 = (float)(val_37);                   
        // 0x00B351EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B351F0: FSUB s0, s2, s0            | S0 = (val_37 - this.graphWidth);        
        val_58 = (float)val_37 - val_58;
        // 0x00B351F4: FMOV s2, #0.50000000       | S2 = 0.5;                               
        // 0x00B351F8: FMUL s0, s0, s2            | S0 = ((val_37 - this.graphWidth) * 0.5f);
        val_58 = val_58 * 0.5f;
        // 0x00B351FC: FMOV s2, #1.00000000       | S2 = 1;                                 
        // 0x00B35200: ADD x0, sp, #0x60          | X0 = (1152921513195508320 + 96) = 1152921513195508416 (0x10000001FFEC92C0);
        // 0x00B35204: STR wzr, [sp, #0x68]       | stack[1152921513195508424] = 0x0;        //  dest_result_addr=1152921513195508424
        // 0x00B35208: STR xzr, [sp, #0x60]       | stack[1152921513195508416] = 0x0;        //  dest_result_addr=1152921513195508416
        // 0x00B3520C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B35210: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B35214: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B35218: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00B3521C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B35220: TBZ w8, #0, #0xb35230      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_51;
        // 0x00B35224: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B35228: CBNZ w8, #0xb35230         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
        // 0x00B3522C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_51:
        // 0x00B35230: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35234: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35238: SDIV w21, w20, w22         | W21 = (val_36 / this.graph.Length);     
        int val_38 = val_59 / this.graph.Length;
        // 0x00B3523C: BL #0x1b7fb20              | X0 = UnityEngine.Quaternion.get_identity();
        UnityEngine.Quaternion val_39 = UnityEngine.Quaternion.identity;
        // 0x00B35240: MOV v12.16b, v0.16b        | V12 = val_39.x;//m1                     
        val_63 = val_39.x;
        // 0x00B35244: MOV v13.16b, v1.16b        | V13 = val_39.y;//m1                     
        // 0x00B35248: LDP s0, s1, [x19, #0xb8]   | S0 = this.graphWidth; //P2  S1 = this.graphHeight; //P2  //  | 
        // 0x00B3524C: MOV v14.16b, v2.16b        | V14 = val_39.z;//m1                     
        val_64 = val_39.z;
        // 0x00B35250: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35254: FMOV s2, #1.00000000       | S2 = 1;                                 
        // 0x00B35258: SUB x0, x29, #0xe0         | X0 = (1152921513195508832 - 224) = 1152921513195508608 (0x10000001FFEC9380);
        // 0x00B3525C: MOV v15.16b, v3.16b        | V15 = val_39.w;//m1                     
        // 0x00B35260: STUR wzr, [x29, #-0xd8]    | stack[1152921513195508616] = 0x0;        //  dest_result_addr=1152921513195508616
        // 0x00B35264: STUR xzr, [x29, #-0xe0]    | stack[1152921513195508608] = 0x0;        //  dest_result_addr=1152921513195508608
        // 0x00B35268: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B3526C: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
        // 0x00B35270: LDR x8, [x8, #0x778]       | X8 = 1152921504695238656;               
        // 0x00B35274: LDR x0, [x8]               | X0 = typeof(UnityEngine.Matrix4x4);     
        // 0x00B35278: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_10A;
        // 0x00B3527C: TBZ w8, #0, #0xb3528c      | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_has_cctor == 0) goto label_53;
        // 0x00B35280: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished;
        // 0x00B35284: CBNZ w8, #0xb3528c         | if (UnityEngine.Matrix4x4.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
        // 0x00B35288: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Matrix4x4), ????);
        label_53:
        // 0x00B3528C: LDP s0, s1, [sp, #0x60]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B35290: LDR s2, [sp, #0x68]        | S2 = 0;                                 
        // 0x00B35294: LDP s3, s4, [x29, #-0xe0]  | S3 = 0; S4 = 0;                          //  | 
        // 0x00B35298: LDUR s5, [x29, #-0xd8]     | S5 = 0;                                 
        // 0x00B3529C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B352A0: ADD x8, sp, #0xe0          | X8 = (1152921513195508320 + 224) = 1152921513195508544 (0x10000001FFEC9340);
        // 0x00B352A4: MOV v6.16b, v15.16b        | V6 = val_39.w;//m1                      
        // 0x00B352A8: STP s4, s5, [sp, #4]       | stack[1152921513195508324] = 0x0;  stack[1152921513195508328] = 0x0;  //  dest_result_addr=1152921513195508324 |  dest_result_addr=1152921513195508328
        // 0x00B352AC: STR s3, [sp]               | stack[1152921513195508320] = 0x0;        //  dest_result_addr=1152921513195508320
        // 0x00B352B0: MOV v3.16b, v12.16b        | V3 = val_39.x;//m1                      
        // 0x00B352B4: MOV v4.16b, v13.16b        | V4 = val_39.y;//m1                      
        // 0x00B352B8: MOV v5.16b, v14.16b        | V5 = val_39.z;//m1                      
        // 0x00B352BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B352C0: MSUB w20, w21, w22, w20    | W20 = val_36 - ((val_36 / this.graph.Length) * this.graph.Length);
        val_59 = val_59 - (val_38 * this.graph.Length);
        // 0x00B352C4: BL #0x1b702c8              | X0 = UnityEngine.Matrix4x4.TRS(pos:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, q:  new UnityEngine.Quaternion() {x = val_63, y = val_39.y, z = val_64, w = val_39.w}, s:  new UnityEngine.Vector3() {x = 0f, y = 0f});
        UnityEngine.Matrix4x4 val_40 = UnityEngine.Matrix4x4.TRS(pos:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, q:  new UnityEngine.Quaternion() {x = val_63, y = val_39.y, z = val_64, w = val_39.w}, s:  new UnityEngine.Vector3() {x = 0f, y = 0f});
        // 0x00B352C8: LDP q1, q0, [sp, #0x100]   | Q1 = val_41; Q0 = val_42;                //  find_add[1152921513195496848] |  find_add[1152921513195496848]
        // 0x00B352CC: LDP q3, q2, [sp, #0xe0]    | Q3 = val_43; Q2 = val_44;                //  find_add[1152921513195496848] |  find_add[1152921513195496848]
        // 0x00B352D0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_65 = 0;
        // 0x00B352D4: ORR w21, wzr, #0xc         | W21 = 12(0xC);                          
        val_55 = 12;
        // 0x00B352D8: STP q1, q0, [x29, #-0xb0]  | stack[1152921513195508656] = val_41;  stack[1152921513195508672] = val_42;  //  dest_result_addr=1152921513195508656 |  dest_result_addr=1152921513195508672
        // 0x00B352DC: STP q3, q2, [x29, #-0xd0]  | stack[1152921513195508624] = val_43;  stack[1152921513195508640] = val_44;  //  dest_result_addr=1152921513195508624 |  dest_result_addr=1152921513195508640
        // 0x00B352E0: B #0xb35534                |  goto label_55;                         
        goto label_55;
        label_56:
        // 0x00B352E4: ADD w22, w22, #1           | W22 = (val_65 + 1) = val_65 (0x00000001);
        val_65 = 1;
        // 0x00B352E8: B #0xb35534                |  goto label_55;                         
        goto label_55;
        label_70:
        // 0x00B352EC: CMP w22, w20               | STATE = COMPARE(0x1, val_36 - ((val_36 / this.graph.Length) * this.graph.Length))
        // 0x00B352F0: B.EQ #0xb352e4             | if (val_65 == val_36) goto label_56;    
        if(val_65 == val_59)
        {
            goto label_56;
        }
        // 0x00B352F4: LDP q1, q0, [x29, #-0xb0]  | Q1 = val_41; Q0 = val_42;                //  | 
        // 0x00B352F8: LDP q3, q2, [x29, #-0xd0]  | Q3 = val_43; Q2 = val_44;                //  | 
        // 0x00B352FC: STP q1, q0, [sp, #0x100]   | val_41 = val_41;  val_42 = val_42;       //  dest_result_addr=1152921513195508576 |  dest_result_addr=1152921513195508592
        val_41 = val_41;
        val_42 = val_42;
        // 0x00B35300: STP q3, q2, [sp, #0xe0]    | val_43 = val_43;  val_44 = val_44;       //  dest_result_addr=1152921513195508544 |  dest_result_addr=1152921513195508560
        val_43 = val_43;
        val_44 = val_44;
        // 0x00B35304: LDR x26, [x19, #0x50]      | X26 = this.graph; //P2                  
        // 0x00B35308: MOV x23, x26               | X23 = this.graph;//m1                   
        val_66 = this.graph;
        // 0x00B3530C: MOV x27, x26               | X27 = this.graph;//m1                   
        val_67 = this.graph;
        // 0x00B35310: CBNZ x26, #0xb35334        | if (this.graph != null) goto label_58;  
        if(this.graph != null)
        {
            goto label_58;
        }
        // 0x00B35314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B35318: LDR x23, [x19, #0x50]      | X23 = this.graph; //P2                  
        val_66 = this.graph;
        // 0x00B3531C: MOV x27, x23               | X27 = this.graph;//m1                   
        val_67 = val_66;
        // 0x00B35320: CBNZ x23, #0xb35334        | if (this.graph != null) goto label_58;  
        if(val_66 != null)
        {
            goto label_58;
        }
        // 0x00B35324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B35328: LDR x23, [x19, #0x50]      | X23 = this.graph; //P2                  
        val_66 = this.graph;
        // 0x00B3532C: CBZ x23, #0xb35580         | if (this.graph == null) goto label_65;  
        if(val_66 == null)
        {
            goto label_65;
        }
        // 0x00B35330: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
        val_67 = 0;
        label_58:
        // 0x00B35334: LDR w8, [x23, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35338: SXTW x24, w22              | X24 = 1 (0x00000001);                   
        // 0x00B3533C: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B35340: B.LO #0xb35350             | if (val_65 < this.graph.Length) goto label_60;
        if(val_65 < this.graph.Length)
        {
            goto label_60;
        }
        // 0x00B35344: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B35348: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3534C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_60:
        // 0x00B35350: MADD x8, x24, x21, x23     | X8 = (1 * val_55 + this.graph) = 12 (0x0000000C);
        // 0x00B35354: LDR s2, [x8, #0x24]        | S2 = 0;                                 
        // 0x00B35358: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3535C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35360: MOV v0.16b, v11.16b        | V0 = 2139095040 (0x7F800000);//ML01     
        // 0x00B35364: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B35368: BL #0x168450c              | X0 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  0f);
        float val_45 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  0f);
        // 0x00B3536C: LDR x28, [x19, #0x50]      | X28 = this.graph; //P2                  
        // 0x00B35370: MOV v12.16b, v0.16b        | V12 = val_45;//m1                       
        // 0x00B35374: CBNZ x28, #0xb3537c        | if (this.graph != null) goto label_61;  
        if(this.graph != null)
        {
            goto label_61;
        }
        // 0x00B35378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_61:
        // 0x00B3537C: LDR w8, [x28, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35380: ADD w23, w22, #1           | W23 = (val_65 + 1) = 2 (0x00000002);    
        // 0x00B35384: SXTW x25, w23              | X25 = 2 (0x00000002);                   
        val_60 = 2;
        // 0x00B35388: CMP w23, w8                | STATE = COMPARE(0x2, this.graph.Length) 
        // 0x00B3538C: B.LO #0xb3539c             | if (2 < this.graph.Length) goto label_62;
        if(2 < this.graph.Length)
        {
            goto label_62;
        }
        // 0x00B35390: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B35394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35398: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_62:
        // 0x00B3539C: MADD x8, x25, x21, x28     | X8 = (val_60 * val_55 + this.graph) = 24 (0x00000018);
        // 0x00B353A0: LDR s2, [x8, #0x24]        | S2 = 2.295924E-39;                      
        // 0x00B353A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B353A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B353AC: MOV v0.16b, v11.16b        | V0 = 2139095040 (0x7F800000);//ML01     
        // 0x00B353B0: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B353B4: BL #0x168450c              | X0 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  2.295924E-39f);
        float val_46 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  2.295924E-39f);
        // 0x00B353B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B353BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B353C0: MOV v13.16b, v0.16b        | V13 = val_46;//m1                       
        // 0x00B353C4: BL #0x20d3bd0              | X0 = UnityEngine.Color.get_blue();      
        UnityEngine.Color val_47 = UnityEngine.Color.blue;
        // 0x00B353C8: MOV v4.16b, v0.16b         | V4 = val_47.r;//m1                      
        // 0x00B353CC: MOV v5.16b, v1.16b         | V5 = val_47.g;//m1                      
        // 0x00B353D0: MOV v6.16b, v2.16b         | V6 = val_47.b;//m1                      
        // 0x00B353D4: MOV v7.16b, v3.16b         | V7 = val_47.a;//m1                      
        // 0x00B353D8: LDP q1, q0, [sp, #0x100]   | Q1 = val_41; Q0 = val_42;                //  | 
        // 0x00B353DC: LDP q3, q2, [sp, #0xe0]    | Q3 = val_43; Q2 = val_44;                //  | 
        // 0x00B353E0: SCVTF s15, w22             | S15 = 1;                                
        // 0x00B353E4: SCVTF s14, w23             | S14 = 2;                                
        val_64 = 2f;
        // 0x00B353E8: STP q1, q0, [sp, #0xc0]    | stack[1152921513195508512] = val_41;  stack[1152921513195508528] = val_42;  //  dest_result_addr=1152921513195508512 |  dest_result_addr=1152921513195508528
        // 0x00B353EC: STP q3, q2, [sp, #0xa0]    | stack[1152921513195508480] = val_43;  stack[1152921513195508496] = val_44;  //  dest_result_addr=1152921513195508480 |  dest_result_addr=1152921513195508496
        // 0x00B353F0: LDR s0, [x26, #0x18]       | S0 = this.graph.Length; //P2            
        // 0x00B353F4: LDR s1, [x27, #0x18]       | S1 = 1.396644E-38;                      
        // 0x00B353F8: ADD x2, sp, #0xa0          | X2 = (1152921513195508320 + 160) = 1152921513195508480 (0x10000001FFEC9300);
        // 0x00B353FC: MOV x0, x19                | X0 = 1152921513195520848 (0x10000001FFECC350);//ML01
        // 0x00B35400: SCVTF s0, s0               | S0 = (float)(this.graph.Length);        
        float val_60 = (float)this.graph.Length;
        // 0x00B35404: SCVTF s1, s1               | S1 = 9966784;                           
        float val_61 = 9966784f;
        // 0x00B35408: FDIV s0, s15, s0           | S0 = (1f / this.graph.Length);          
        val_60 = 1f / val_60;
        // 0x00B3540C: FDIV s1, s14, s1           | S1 = (val_64 / 9966784f);               
        val_61 = val_64 / val_61;
        // 0x00B35410: MOV v2.16b, v12.16b        | V2 = val_45;//m1                        
        // 0x00B35414: MOV v3.16b, v13.16b        | V3 = val_46;//m1                        
        // 0x00B35418: BL #0xb35584               | this.DrawGraphLine(index:  0, m:  new UnityEngine.Matrix4x4() {m00 = val_43, m10 = val_43, m20 = val_43, m30 = val_43, m01 = val_44, m11 = val_44, m21 = val_44, m31 = val_44, m02 = val_41, m12 = val_41, m22 = val_41, m32 = val_41, m03 = val_42, m13 = val_42, m23 = val_42, m33 = val_42}, x1:  (float)this.graph.Length = 1f / (float)this.graph.Length, x2:  9966784f = val_64 / 9966784f, y1:  val_45, y2:  val_46, col:  new UnityEngine.Color() {r = val_47.r, g = val_47.g, b = val_47.b, a = val_47.a});
        this.DrawGraphLine(index:  0, m:  new UnityEngine.Matrix4x4() {m00 = val_43, m10 = val_43, m20 = val_43, m30 = val_43, m01 = val_44, m11 = val_44, m21 = val_44, m31 = val_44, m02 = val_41, m12 = val_41, m22 = val_41, m32 = val_41, m03 = val_42, m13 = val_42, m23 = val_42, m33 = val_42}, x1:  val_60, x2:  val_61, y1:  val_45, y2:  val_46, col:  new UnityEngine.Color() {r = val_47.r, g = val_47.g, b = val_47.b, a = val_47.a});
        // 0x00B3541C: LDP q1, q0, [x29, #-0xb0]  | Q1 = val_41; Q0 = val_42;                //  | 
        // 0x00B35420: LDP q3, q2, [x29, #-0xd0]  | Q3 = val_43; Q2 = val_44;                //  | 
        // 0x00B35424: STP q1, q0, [sp, #0x80]    | stack[1152921513195508448] = val_41;  stack[1152921513195508464] = val_42;  //  dest_result_addr=1152921513195508448 |  dest_result_addr=1152921513195508464
        // 0x00B35428: STP q3, q2, [sp, #0x60]    | stack[1152921513195508416] = val_43;  stack[1152921513195508432] = val_44;  //  dest_result_addr=1152921513195508416 |  dest_result_addr=1152921513195508432
        // 0x00B3542C: LDR x26, [x19, #0x50]      | X26 = this.graph; //P2                  
        // 0x00B35430: MOV x28, x26               | X28 = this.graph;//m1                   
        val_68 = this.graph;
        // 0x00B35434: MOV x27, x26               | X27 = this.graph;//m1                   
        val_69 = this.graph;
        // 0x00B35438: CBNZ x26, #0xb3545c        | if (this.graph != null) goto label_64;  
        if(this.graph != null)
        {
            goto label_64;
        }
        // 0x00B3543C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x00B35440: LDR x28, [x19, #0x50]      | X28 = this.graph; //P2                  
        val_68 = this.graph;
        // 0x00B35444: MOV x27, x28               | X27 = this.graph;//m1                   
        val_69 = val_68;
        // 0x00B35448: CBNZ x28, #0xb3545c        | if (this.graph != null) goto label_64;  
        if(val_68 != null)
        {
            goto label_64;
        }
        // 0x00B3544C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x00B35450: LDR x28, [x19, #0x50]      | X28 = this.graph; //P2                  
        val_68 = this.graph;
        // 0x00B35454: CBZ x28, #0xb35580         | if (this.graph == null) goto label_65;  
        if(val_68 == null)
        {
            goto label_65;
        }
        // 0x00B35458: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
        val_69 = 0;
        label_64:
        // 0x00B3545C: LDR w8, [x28, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B35460: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B35464: B.LO #0xb35474             | if (val_65 < this.graph.Length) goto label_66;
        if(val_65 < this.graph.Length)
        {
            goto label_66;
        }
        // 0x00B35468: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x00B3546C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35470: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_66:
        // 0x00B35474: MADD x8, x24, x21, x28     | X8 = (1 * val_55) + this.graph;         
        var val_48 = val_68 + (1 * val_55);
        // 0x00B35478: LDR s2, [x8, #0x20]        | S2 = (1 * val_55) + this.graph + 32;    
        // 0x00B3547C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35484: MOV v0.16b, v9.16b         | V0 = 2139095040 (0x7F800000);//ML01     
        // 0x00B35488: MOV v1.16b, v8.16b         | V1 = val_29;//m1                        
        // 0x00B3548C: BL #0x168450c              | X0 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  (1 * val_55) + this.graph + 32);
        float val_49 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  (1 * val_55) + this.graph + 32);
        // 0x00B35490: LDR x22, [x19, #0x50]      | X22 = this.graph; //P2                  
        // 0x00B35494: MOV v12.16b, v0.16b        | V12 = val_49;//m1                       
        val_63 = val_49;
        // 0x00B35498: CBNZ x22, #0xb354a0        | if (this.graph != null) goto label_67;  
        if(this.graph != null)
        {
            goto label_67;
        }
        // 0x00B3549C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_67:
        // 0x00B354A0: LDR w8, [x22, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B354A4: CMP w23, w8                | STATE = COMPARE(0x2, this.graph.Length) 
        // 0x00B354A8: B.LO #0xb354b8             | if (2 < this.graph.Length) goto label_68;
        if(2 < this.graph.Length)
        {
            goto label_68;
        }
        // 0x00B354AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B354B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B354B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_68:
        // 0x00B354B8: MADD x8, x25, x21, x22     | X8 = (val_60 * val_55) + this.graph;    
        var val_50 = this.graph + (val_60 * val_55);
        // 0x00B354BC: LDR s2, [x8, #0x20]        | S2 = (val_60 * val_55) + this.graph + 32;
        // 0x00B354C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B354C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B354C8: MOV v0.16b, v9.16b         | V0 = 2139095040 (0x7F800000);//ML01     
        // 0x00B354CC: MOV v1.16b, v8.16b         | V1 = val_29;//m1                        
        // 0x00B354D0: BL #0x168450c              | X0 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  (val_60 * val_55) + this.graph + 32);
        float val_51 = Pathfinding.AstarMath.MapTo(startMin:  Infinityf, startMax:  val_58, value:  (val_60 * val_55) + this.graph + 32);
        // 0x00B354D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B354D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B354DC: MOV v13.16b, v0.16b        | V13 = val_51;//m1                       
        // 0x00B354E0: BL #0x20d3bbc              | X0 = UnityEngine.Color.get_green();     
        UnityEngine.Color val_52 = UnityEngine.Color.green;
        // 0x00B354E4: MOV v4.16b, v0.16b         | V4 = val_52.r;//m1                      
        // 0x00B354E8: MOV v5.16b, v1.16b         | V5 = val_52.g;//m1                      
        // 0x00B354EC: MOV v7.16b, v3.16b         | V7 = val_52.a;//m1                      
        // 0x00B354F0: LDP q1, q0, [sp, #0x80]    | Q1 = val_41; Q0 = val_42;                //  | 
        // 0x00B354F4: LDP q6, q3, [sp, #0x60]    | Q6 = val_43; Q3 = val_44;                //  | 
        // 0x00B354F8: ADD x2, sp, #0x20          | X2 = (1152921513195508320 + 32) = 1152921513195508352 (0x10000001FFEC9280);
        // 0x00B354FC: MOV x0, x19                | X0 = 1152921513195520848 (0x10000001FFECC350);//ML01
        // 0x00B35500: STP q1, q0, [sp, #0x40]    | stack[1152921513195508384] = val_41;  stack[1152921513195508400] = val_42;  //  dest_result_addr=1152921513195508384 |  dest_result_addr=1152921513195508400
        // 0x00B35504: STP q6, q3, [sp, #0x20]    | stack[1152921513195508352] = val_43;  stack[1152921513195508368] = val_44;  //  dest_result_addr=1152921513195508352 |  dest_result_addr=1152921513195508368
        // 0x00B35508: LDR s0, [x26, #0x18]       | S0 = this.graph.Length; //P2            
        // 0x00B3550C: LDR s1, [x27, #0x18]       | S1 = 1.396644E-38;                      
        // 0x00B35510: MOV v6.16b, v2.16b         | V6 = val_52.b;//m1                      
        // 0x00B35514: MOV v2.16b, v12.16b        | V2 = val_49;//m1                        
        // 0x00B35518: SCVTF s0, s0               | S0 = (float)(this.graph.Length);        
        float val_62 = (float)this.graph.Length;
        // 0x00B3551C: SCVTF s1, s1               | S1 = 9966784;                           
        float val_63 = 9966784f;
        // 0x00B35520: FDIV s0, s15, s0           | S0 = (1f / this.graph.Length);          
        val_62 = 1f / val_62;
        // 0x00B35524: FDIV s1, s14, s1           | S1 = (val_64 / 9966784f);               
        val_63 = val_64 / val_63;
        // 0x00B35528: MOV v3.16b, v13.16b        | V3 = val_51;//m1                        
        // 0x00B3552C: BL #0xb35584               | this.DrawGraphLine(index:  0, m:  new UnityEngine.Matrix4x4() {m00 = val_43, m10 = val_43, m20 = val_43, m30 = val_43, m01 = val_44, m11 = val_44, m21 = val_44, m31 = val_44, m02 = val_41, m12 = val_41, m22 = val_41, m32 = val_41, m03 = val_42, m13 = val_42, m23 = val_42, m33 = val_42}, x1:  (float)this.graph.Length = 1f / (float)this.graph.Length, x2:  9966784f = val_64 / 9966784f, y1:  val_63, y2:  val_51, col:  new UnityEngine.Color() {r = val_52.r, g = val_52.g, b = val_52.b, a = val_52.a});
        this.DrawGraphLine(index:  0, m:  new UnityEngine.Matrix4x4() {m00 = val_43, m10 = val_43, m20 = val_43, m30 = val_43, m01 = val_44, m11 = val_44, m21 = val_44, m31 = val_44, m02 = val_41, m12 = val_41, m22 = val_41, m32 = val_41, m03 = val_42, m13 = val_42, m23 = val_42, m33 = val_42}, x1:  val_62, x2:  val_63, y1:  val_63, y2:  val_51, col:  new UnityEngine.Color() {r = val_52.r, g = val_52.g, b = val_52.b, a = val_52.a});
        // 0x00B35530: MOV w22, w23               | W22 = 2 (0x2);//ML01                    
        val_65 = 2;
        label_55:
        // 0x00B35534: LDR x23, [x19, #0x50]      | X23 = this.graph; //P2                  
        val_53 = this.graph;
        // 0x00B35538: CBNZ x23, #0xb35540        | if (this.graph != null) goto label_69;  
        if(val_53 != null)
        {
            goto label_69;
        }
        // 0x00B3553C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_69:
        // 0x00B35540: LDR w8, [x23, #0x18]       | W8 = this.graph.Length; //P2            
        int val_64 = this.graph.Length;
        // 0x00B35544: SUB w8, w8, #1             | W8 = (this.graph.Length - 1);           
        val_64 = val_64 - 1;
        // 0x00B35548: CMP w22, w8                | STATE = COMPARE(0x2, (this.graph.Length - 1))
        // 0x00B3554C: B.LT #0xb352ec             | if (val_65 < this.graph.Length) goto label_70;
        if(val_65 < val_64)
        {
            goto label_70;
        }
        label_32:
        // 0x00B35550: SUB sp, x29, #0x90         | SP = (1152921513195508832 - 144) = 1152921513195508688 (0x10000001FFEC93D0);
        // 0x00B35554: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
        // 0x00B35558: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
        // 0x00B3555C: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
        // 0x00B35560: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
        // 0x00B35564: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
        // 0x00B35568: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x00B3556C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B35570: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B35574: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B35578: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
        // 0x00B3557C: RET                        |  return;                                
        return;
        label_65:
        // 0x00B35580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
    
    }
    //
    // Offset in libil2cpp.so: 0x00B35584 (11752836), len: 448  VirtAddr: 0x00B35584 RVA: 0x00B35584 token: 100682131 methodIndex: 24962 delegateWrapperIndex: 0 methodInvoker: 0
    public void DrawGraphLine(int index, UnityEngine.Matrix4x4 m, float x1, float x2, float y1, float y2, UnityEngine.Color col)
    {
        //
        // Disasemble & Code
        // 0x00B35584: STP d15, d14, [sp, #-0x70]! | stack[1152921513196423712] = ???;  stack[1152921513196423720] = ???;  //  dest_result_addr=1152921513196423712 |  dest_result_addr=1152921513196423720
        // 0x00B35588: STP d13, d12, [sp, #0x10]  | stack[1152921513196423728] = ???;  stack[1152921513196423736] = ???;  //  dest_result_addr=1152921513196423728 |  dest_result_addr=1152921513196423736
        // 0x00B3558C: STP d11, d10, [sp, #0x20]  | stack[1152921513196423744] = ???;  stack[1152921513196423752] = ???;  //  dest_result_addr=1152921513196423744 |  dest_result_addr=1152921513196423752
        // 0x00B35590: STP d9, d8, [sp, #0x30]    | stack[1152921513196423760] = ???;  stack[1152921513196423768] = ???;  //  dest_result_addr=1152921513196423760 |  dest_result_addr=1152921513196423768
        // 0x00B35594: STP x22, x21, [sp, #0x40]  | stack[1152921513196423776] = ???;  stack[1152921513196423784] = ???;  //  dest_result_addr=1152921513196423776 |  dest_result_addr=1152921513196423784
        // 0x00B35598: STP x20, x19, [sp, #0x50]  | stack[1152921513196423792] = ???;  stack[1152921513196423800] = ???;  //  dest_result_addr=1152921513196423792 |  dest_result_addr=1152921513196423800
        // 0x00B3559C: STP x29, x30, [sp, #0x60]  | stack[1152921513196423808] = ???;  stack[1152921513196423816] = ???;  //  dest_result_addr=1152921513196423808 |  dest_result_addr=1152921513196423816
        // 0x00B355A0: ADD x29, sp, #0x60         | X29 = (1152921513196423712 + 96) = 1152921513196423808 (0x10000001FFFA8A80);
        // 0x00B355A4: SUB sp, sp, #0x40          | SP = (1152921513196423712 - 64) = 1152921513196423648 (0x10000001FFFA89E0);
        // 0x00B355A8: STP s6, s7, [sp, #0x18]    | stack[1152921513196423672] = col.b;  stack[1152921513196423676] = col.a;  //  dest_result_addr=1152921513196423672 |  dest_result_addr=1152921513196423676
        // 0x00B355AC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B355B0: LDRB w8, [x21, #0x7a8]     | W8 = (bool)static_value_037337A8;       
        // 0x00B355B4: MOV v11.16b, v5.16b        | V11 = col.g;//m1                        
        // 0x00B355B8: MOV v10.16b, v4.16b        | V10 = col.r;//m1                        
        // 0x00B355BC: MOV v15.16b, v3.16b        | V15 = y2;//m1                           
        // 0x00B355C0: MOV v9.16b, v2.16b         | V9 = y1;//m1                            
        // 0x00B355C4: MOV v8.16b, v1.16b         | V8 = x2;//m1                            
        // 0x00B355C8: MOV v12.16b, v0.16b        | V12 = x1;//m1                           
        // 0x00B355CC: MOV x19, x2                | X19 = 1152921513196467824 (0x10000001FFFB3670);//ML01
        // 0x00B355D0: MOV x20, x0                | X20 = 1152921513196435824 (0x10000001FFFAB970);//ML01
        // 0x00B355D4: TBNZ w8, #0, #0xb355f0     | if (static_value_037337A8 == true) goto label_0;
        // 0x00B355D8: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00B355DC: LDR x8, [x8, #0x9c0]       | X8 = 0x2B8EC54;                         
        // 0x00B355E0: LDR w0, [x8]               | W0 = 0x11D5;                            
        // 0x00B355E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D5, ????);     
        // 0x00B355E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B355EC: STRB w8, [x21, #0x7a8]     | static_value_037337A8 = true;            //  dest_result_addr=57882536
        label_0:
        // 0x00B355F0: LDR x21, [x20, #0xa8]      | X21 = this.cam; //P2                    
        // 0x00B355F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B355F8: ADD x0, sp, #0x30          | X0 = (1152921513196423648 + 48) = 1152921513196423696 (0x10000001FFFA8A10);
        // 0x00B355FC: MOV v0.16b, v12.16b        | V0 = x1;//m1                            
        // 0x00B35600: MOV v1.16b, v9.16b         | V1 = y1;//m1                            
        // 0x00B35604: STR wzr, [sp, #0x38]       | stack[1152921513196423704] = 0x0;        //  dest_result_addr=1152921513196423704
        // 0x00B35608: STR xzr, [sp, #0x30]       | stack[1152921513196423696] = 0x0;        //  dest_result_addr=1152921513196423696
        // 0x00B3560C: BL #0x26987b8              | X0 = label_UnityEngine_Vector3__ctor_GL026987B8();
        // 0x00B35610: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B35614: LDR s2, [sp, #0x38]        | S2 = 0;                                 
        // 0x00B35618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3561C: MOV x0, x19                | X0 = 1152921513196467824 (0x10000001FFFB3670);//ML01
        // 0x00B35620: BL #0x1b71d88              | X0 = label_UnityEngine_Matrix4x4_MultiplyPoint_GL01B71D88();
        // 0x00B35624: MOV v9.16b, v0.16b         | V9 = 0 (0x0);//ML01                     
        // 0x00B35628: MOV v12.16b, v1.16b        | V12 = 0 (0x0);//ML01                    
        // 0x00B3562C: MOV v13.16b, v2.16b        | V13 = 0 (0x0);//ML01                    
        // 0x00B35630: CBNZ x21, #0xb35638        | if (this.cam != null) goto label_1;     
        if(this.cam != null)
        {
            goto label_1;
        }
        // 0x00B35634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? m, ????);          
        label_1:
        // 0x00B35638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3563C: MOV x0, x21                | X0 = this.cam;//m1                      
        // 0x00B35640: MOV v0.16b, v9.16b         | V0 = 0 (0x0);//ML01                     
        // 0x00B35644: MOV v1.16b, v12.16b        | V1 = 0 (0x0);//ML01                     
        // 0x00B35648: MOV v2.16b, v13.16b        | V2 = 0 (0x0);//ML01                     
        // 0x00B3564C: BL #0x20d17ec              | X0 = this.cam.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_1 = this.cam.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B35650: LDR x20, [x20, #0xa8]      | X20 = this.cam; //P2                    
        // 0x00B35654: MOV v12.16b, v0.16b        | V12 = val_1.x;//m1                      
        // 0x00B35658: MOV v13.16b, v1.16b        | V13 = val_1.y;//m1                      
        // 0x00B3565C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35660: ADD x0, sp, #0x20          | X0 = (1152921513196423648 + 32) = 1152921513196423680 (0x10000001FFFA8A00);
        // 0x00B35664: MOV v0.16b, v8.16b         | V0 = x2;//m1                            
        // 0x00B35668: MOV v1.16b, v15.16b        | V1 = y2;//m1                            
        // 0x00B3566C: MOV v14.16b, v2.16b        | V14 = val_1.z;//m1                      
        // 0x00B35670: STR wzr, [sp, #0x28]       | stack[1152921513196423688] = 0x0;        //  dest_result_addr=1152921513196423688
        // 0x00B35674: STR xzr, [sp, #0x20]       | stack[1152921513196423680] = 0x0;        //  dest_result_addr=1152921513196423680
        // 0x00B35678: BL #0x26987b8              | X0 = label_UnityEngine_Vector3__ctor_GL026987B8();
        // 0x00B3567C: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B35680: LDR s2, [sp, #0x28]        | S2 = 0;                                 
        // 0x00B35684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35688: MOV x0, x19                | X0 = 1152921513196467824 (0x10000001FFFB3670);//ML01
        // 0x00B3568C: BL #0x1b71d88              | X0 = label_UnityEngine_Matrix4x4_MultiplyPoint_GL01B71D88();
        // 0x00B35690: MOV v8.16b, v0.16b         | V8 = 0 (0x0);//ML01                     
        // 0x00B35694: MOV v9.16b, v1.16b         | V9 = 0 (0x0);//ML01                     
        // 0x00B35698: MOV v15.16b, v2.16b        | V15 = 0 (0x0);//ML01                    
        // 0x00B3569C: CBNZ x20, #0xb356a4        | if (this.cam != null) goto label_2;     
        if(this.cam != null)
        {
            goto label_2;
        }
        // 0x00B356A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? m, ????);          
        label_2:
        // 0x00B356A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B356A8: MOV x0, x20                | X0 = this.cam;//m1                      
        // 0x00B356AC: MOV v0.16b, v8.16b         | V0 = 0 (0x0);//ML01                     
        // 0x00B356B0: MOV v1.16b, v9.16b         | V1 = 0 (0x0);//ML01                     
        // 0x00B356B4: MOV v2.16b, v15.16b        | V2 = 0 (0x0);//ML01                     
        // 0x00B356B8: BL #0x20d17ec              | X0 = this.cam.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_2 = this.cam.ScreenToWorldPoint(position:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B356BC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B356C0: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00B356C4: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
        // 0x00B356C8: MOV v15.16b, v1.16b        | V15 = val_2.y;//m1                      
        // 0x00B356CC: MOV v9.16b, v2.16b         | V9 = val_2.z;//m1                       
        // 0x00B356D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x00B356D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B356D8: TBZ w8, #0, #0xb356e8      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B356DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B356E0: CBNZ w8, #0xb356e8         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B356E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_4:
        // 0x00B356E8: STP s10, s11, [sp]         | stack[1152921513196423648] = col.r;  stack[1152921513196423652] = col.g;  //  dest_result_addr=1152921513196423648 |  dest_result_addr=1152921513196423652
        // 0x00B356EC: LDR s0, [sp, #0x18]        | S0 = col.b;                             
        // 0x00B356F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B356F4: MOV v1.16b, v13.16b        | V1 = val_1.y;//m1                       
        // 0x00B356F8: MOV v2.16b, v14.16b        | V2 = val_1.z;//m1                       
        // 0x00B356FC: STR s0, [sp, #8]           | stack[1152921513196423656] = col.b;      //  dest_result_addr=1152921513196423656
        // 0x00B35700: LDR s0, [sp, #0x1c]        | S0 = col.a;                             
        // 0x00B35704: MOV v3.16b, v8.16b         | V3 = val_2.x;//m1                       
        // 0x00B35708: MOV v4.16b, v15.16b        | V4 = val_2.y;//m1                       
        // 0x00B3570C: MOV v5.16b, v9.16b         | V5 = val_2.z;//m1                       
        // 0x00B35710: STR s0, [sp, #0xc]         | stack[1152921513196423660] = col.a;      //  dest_result_addr=1152921513196423660
        // 0x00B35714: MOV v0.16b, v12.16b        | V0 = val_1.x;//m1                       
        // 0x00B35718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3571C: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, end:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, color:  new UnityEngine.Color() {r = col.r, g = col.b, a = col.b});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, end:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, color:  new UnityEngine.Color() {r = col.r, g = col.b, a = col.b});
        // 0x00B35720: SUB sp, x29, #0x60         | SP = (1152921513196423808 - 96) = 1152921513196423712 (0x10000001FFFA8A20);
        // 0x00B35724: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B35728: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B3572C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B35730: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B35734: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B35738: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B3573C: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00B35740: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B35744 (11753284), len: 732  VirtAddr: 0x00B35744 RVA: 0x00B35744 token: 100682132 methodIndex: 24963 delegateWrapperIndex: 0 methodInvoker: 0
    public void Cross(UnityEngine.Vector3 p)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x00B35744: STP d15, d14, [sp, #-0x70]! | stack[1152921513196556352] = ???;  stack[1152921513196556360] = ???;  //  dest_result_addr=1152921513196556352 |  dest_result_addr=1152921513196556360
        // 0x00B35748: STP d13, d12, [sp, #0x10]  | stack[1152921513196556368] = ???;  stack[1152921513196556376] = ???;  //  dest_result_addr=1152921513196556368 |  dest_result_addr=1152921513196556376
        // 0x00B3574C: STP d11, d10, [sp, #0x20]  | stack[1152921513196556384] = ???;  stack[1152921513196556392] = ???;  //  dest_result_addr=1152921513196556384 |  dest_result_addr=1152921513196556392
        // 0x00B35750: STP d9, d8, [sp, #0x30]    | stack[1152921513196556400] = ???;  stack[1152921513196556408] = ???;  //  dest_result_addr=1152921513196556400 |  dest_result_addr=1152921513196556408
        // 0x00B35754: STP x28, x27, [sp, #0x40]  | stack[1152921513196556416] = ???;  stack[1152921513196556424] = ???;  //  dest_result_addr=1152921513196556416 |  dest_result_addr=1152921513196556424
        // 0x00B35758: STP x20, x19, [sp, #0x50]  | stack[1152921513196556432] = ???;  stack[1152921513196556440] = ???;  //  dest_result_addr=1152921513196556432 |  dest_result_addr=1152921513196556440
        // 0x00B3575C: STP x29, x30, [sp, #0x60]  | stack[1152921513196556448] = ???;  stack[1152921513196556456] = ???;  //  dest_result_addr=1152921513196556448 |  dest_result_addr=1152921513196556456
        // 0x00B35760: ADD x29, sp, #0x60         | X29 = (1152921513196556352 + 96) = 1152921513196556448 (0x10000001FFFC90A0);
        // 0x00B35764: SUB sp, sp, #0xb0          | SP = (1152921513196556352 - 176) = 1152921513196556176 (0x10000001FFFC8F90);
        // 0x00B35768: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B3576C: LDRB w8, [x20, #0x7a9]     | W8 = (bool)static_value_037337A9;       
        // 0x00B35770: MOV v8.16b, v2.16b         | V8 = p.z;//m1                           
        // 0x00B35774: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
        // 0x00B35778: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
        // 0x00B3577C: MOV x19, x0                | X19 = 1152921513196568464 (0x10000001FFFCBF90);//ML01
        // 0x00B35780: TBNZ w8, #0, #0xb3579c     | if (static_value_037337A9 == true) goto label_0;
        // 0x00B35784: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00B35788: LDR x8, [x8, #0x980]       | X8 = 0x2B8EC50;                         
        // 0x00B3578C: LDR w0, [x8]               | W0 = 0x11D4;                            
        // 0x00B35790: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D4, ????);     
        // 0x00B35794: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B35798: STRB w8, [x20, #0x7a9]     | static_value_037337A9 = true;            //  dest_result_addr=57882537
        label_0:
        // 0x00B3579C: STP xzr, xzr, [sp, #0xa0]  | stack[1152921513196556336] = 0x0;  stack[1152921513196556344] = 0x0;  //  dest_result_addr=1152921513196556336 |  dest_result_addr=1152921513196556344
        // 0x00B357A0: STP xzr, xzr, [sp, #0x90]  | stack[1152921513196556320] = 0x0;  stack[1152921513196556328] = 0x0;  //  dest_result_addr=1152921513196556320 |  dest_result_addr=1152921513196556328
        // 0x00B357A4: STP xzr, xzr, [sp, #0x80]  | stack[1152921513196556304] = 0x0;  stack[1152921513196556312] = 0x0;  //  dest_result_addr=1152921513196556304 |  dest_result_addr=1152921513196556312
        // 0x00B357A8: STP xzr, xzr, [sp, #0x70]  | stack[1152921513196556288] = 0x0;  stack[1152921513196556296] = 0x0;  //  dest_result_addr=1152921513196556288 |  dest_result_addr=1152921513196556296
        // 0x00B357AC: LDR x19, [x19, #0xa8]      | X19 = this.cam; //P2                    
        // 0x00B357B0: CBNZ x19, #0xb357b8        | if (this.cam != null) goto label_1;     
        if(this.cam != null)
        {
            goto label_1;
        }
        // 0x00B357B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11D4, ????);     
        label_1:
        // 0x00B357B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B357BC: ADD x8, sp, #0x30          | X8 = (1152921513196556176 + 48) = 1152921513196556224 (0x10000001FFFC8FC0);
        // 0x00B357C0: MOV x0, x19                | X0 = this.cam;//m1                      
        // 0x00B357C4: BL #0x20d00f4              | X0 = this.cam.get_cameraToWorldMatrix();
        UnityEngine.Matrix4x4 val_1 = this.cam.cameraToWorldMatrix;
        // 0x00B357C8: LDP q1, q0, [sp, #0x50]    | Q1 = val_2; Q0 = val_3;                  //  find_add[1152921513196544464] |  find_add[1152921513196544464]
        // 0x00B357CC: LDP q3, q2, [sp, #0x30]    | Q3 = val_4; Q2 = val_5;                  //  find_add[1152921513196544464] |  find_add[1152921513196544464]
        // 0x00B357D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B357D4: ADD x0, sp, #0x70          | X0 = (1152921513196556176 + 112) = 1152921513196556288 (0x10000001FFFC9000);
        // 0x00B357D8: STP q1, q0, [sp, #0x90]    | stack[1152921513196556320] = val_2;  stack[1152921513196556336] = val_3;  //  dest_result_addr=1152921513196556320 |  dest_result_addr=1152921513196556336
        // 0x00B357DC: STP q3, q2, [sp, #0x70]    | stack[1152921513196556288] = val_4;  stack[1152921513196556304] = val_5;  //  dest_result_addr=1152921513196556288 |  dest_result_addr=1152921513196556304
        // 0x00B357E0: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
        // 0x00B357E4: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
        // 0x00B357E8: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
        // 0x00B357EC: BL #0x1b71ce8              | X0 = label_UnityEngine_Matrix4x4_SetRow_GL01B71CE8();
        // 0x00B357F0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B357F4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B357F8: MOV v8.16b, v0.16b         | V8 = p.x;//m1                           
        // 0x00B357FC: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
        // 0x00B35800: MOV v10.16b, v2.16b        | V10 = p.z;//m1                          
        // 0x00B35804: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B35808: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B3580C: TBZ w8, #0, #0xb3581c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B35810: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B35814: CBNZ w8, #0xb3581c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B35818: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_3:
        // 0x00B3581C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35824: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.up;
        // 0x00B35828: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B3582C: LDR s11, [x8, #0x7ac]      | S11 = 0.2;                              
        // 0x00B35830: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35838: MOV v3.16b, v11.16b        | V3 = 1045220557 (0x3E4CCCCD);//ML01     
        // 0x00B3583C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, d:  0.2f);
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, d:  0.2f);
        // 0x00B35840: MOV v3.16b, v0.16b         | V3 = val_7.x;//m1                       
        // 0x00B35844: MOV v4.16b, v1.16b         | V4 = val_7.y;//m1                       
        // 0x00B35848: MOV v5.16b, v2.16b         | V5 = val_7.z;//m1                       
        // 0x00B3584C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35854: MOV v0.16b, v8.16b         | V0 = p.x;//m1                           
        // 0x00B35858: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
        // 0x00B3585C: MOV v2.16b, v10.16b        | V2 = p.z;//m1                           
        // 0x00B35860: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z});
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z});
        // 0x00B35864: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3586C: STP s1, s0, [sp, #0x1c]    | stack[1152921513196556204] = val_8.y;  stack[1152921513196556208] = val_8.x;  //  dest_result_addr=1152921513196556204 |  dest_result_addr=1152921513196556208
        // 0x00B35870: STR s2, [sp, #0x18]        | stack[1152921513196556200] = val_8.z;    //  dest_result_addr=1152921513196556200
        // 0x00B35874: BL #0x2693d60              | X0 = UnityEngine.Vector3.get_up();      
        UnityEngine.Vector3 val_9 = UnityEngine.Vector3.up;
        // 0x00B35878: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3587C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35880: MOV v3.16b, v11.16b        | V3 = 1045220557 (0x3E4CCCCD);//ML01     
        // 0x00B35884: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  0.2f);
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, d:  0.2f);
        // 0x00B35888: MOV v3.16b, v0.16b         | V3 = val_10.x;//m1                      
        // 0x00B3588C: MOV v4.16b, v1.16b         | V4 = val_10.y;//m1                      
        // 0x00B35890: MOV v5.16b, v2.16b         | V5 = val_10.z;//m1                      
        // 0x00B35894: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3589C: MOV v0.16b, v8.16b         | V0 = p.x;//m1                           
        // 0x00B358A0: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
        // 0x00B358A4: MOV v2.16b, v10.16b        | V2 = p.z;//m1                           
        // 0x00B358A8: STP s9, s8, [sp, #0x28]    | stack[1152921513196556216] = p.y;  stack[1152921513196556220] = p.x;  //  dest_result_addr=1152921513196556216 |  dest_result_addr=1152921513196556220
        // 0x00B358AC: STR s10, [sp, #0x24]       | stack[1152921513196556212] = p.z;        //  dest_result_addr=1152921513196556212
        // 0x00B358B0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        // 0x00B358B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B358B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B358BC: MOV v15.16b, v0.16b        | V15 = val_11.x;//m1                     
        // 0x00B358C0: MOV v12.16b, v1.16b        | V12 = val_11.y;//m1                     
        // 0x00B358C4: MOV v13.16b, v2.16b        | V13 = val_11.z;//m1                     
        // 0x00B358C8: BL #0x20d3ba8              | X0 = UnityEngine.Color.get_red();       
        UnityEngine.Color val_12 = UnityEngine.Color.red;
        // 0x00B358CC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B358D0: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00B358D4: MOV v14.16b, v0.16b        | V14 = val_12.r;//m1                     
        // 0x00B358D8: MOV v8.16b, v1.16b         | V8 = val_12.g;//m1                      
        // 0x00B358DC: MOV v9.16b, v2.16b         | V9 = val_12.b;//m1                      
        // 0x00B358E0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x00B358E4: MOV v10.16b, v3.16b        | V10 = val_12.a;//m1                     
        // 0x00B358E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B358EC: TBZ w8, #0, #0xb358fc      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B358F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B358F4: CBNZ w8, #0xb358fc         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B358F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_5:
        // 0x00B358FC: STP s9, s10, [sp, #8]      | stack[1152921513196556184] = val_12.b;  stack[1152921513196556188] = val_12.a;  //  dest_result_addr=1152921513196556184 |  dest_result_addr=1152921513196556188
        // 0x00B35900: STP s14, s8, [sp]          | stack[1152921513196556176] = val_12.r;  stack[1152921513196556180] = val_12.g;  //  dest_result_addr=1152921513196556176 |  dest_result_addr=1152921513196556180
        // 0x00B35904: LDP s1, s0, [sp, #0x1c]    | S1 = val_8.y; S0 = val_8.x;              //  | 
        // 0x00B35908: LDR s2, [sp, #0x18]        | S2 = val_8.z;                           
        // 0x00B3590C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35910: MOV v3.16b, v15.16b        | V3 = val_11.x;//m1                      
        // 0x00B35914: MOV v4.16b, v12.16b        | V4 = val_11.y;//m1                      
        // 0x00B35918: MOV v5.16b, v13.16b        | V5 = val_11.z;//m1                      
        // 0x00B3591C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35920: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, end:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, color:  new UnityEngine.Color() {r = val_12.r, g = val_12.b, a = val_8.z});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, end:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, color:  new UnityEngine.Color() {r = val_12.r, g = val_12.b, a = val_8.z});
        // 0x00B35924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3592C: BL #0x2693b08              | X0 = UnityEngine.Vector3.get_right();   
        UnityEngine.Vector3 val_13 = UnityEngine.Vector3.right;
        // 0x00B35930: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35938: MOV v3.16b, v11.16b        | V3 = 1045220557 (0x3E4CCCCD);//ML01     
        // 0x00B3593C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, d:  0.2f);
        UnityEngine.Vector3 val_14 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, d:  0.2f);
        // 0x00B35940: LDP s13, s12, [sp, #0x28]  | S13 = p.y; S12 = p.x;                    //  | 
        // 0x00B35944: LDR s14, [sp, #0x24]       | S14 = p.z;                              
        // 0x00B35948: MOV v3.16b, v0.16b         | V3 = val_14.x;//m1                      
        // 0x00B3594C: MOV v4.16b, v1.16b         | V4 = val_14.y;//m1                      
        // 0x00B35950: MOV v5.16b, v2.16b         | V5 = val_14.z;//m1                      
        // 0x00B35954: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3595C: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
        // 0x00B35960: MOV v1.16b, v13.16b        | V1 = p.y;//m1                           
        // 0x00B35964: MOV v2.16b, v14.16b        | V2 = p.z;//m1                           
        // 0x00B35968: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_14.x, y = val_14.y, z = val_14.z});
        // 0x00B3596C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35974: MOV v8.16b, v0.16b         | V8 = val_15.x;//m1                      
        // 0x00B35978: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
        // 0x00B3597C: MOV v10.16b, v2.16b        | V10 = val_15.z;//m1                     
        // 0x00B35980: BL #0x2693b08              | X0 = UnityEngine.Vector3.get_right();   
        UnityEngine.Vector3 val_16 = UnityEngine.Vector3.right;
        // 0x00B35984: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3598C: MOV v3.16b, v11.16b        | V3 = 1045220557 (0x3E4CCCCD);//ML01     
        // 0x00B35990: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, d:  0.2f);
        UnityEngine.Vector3 val_17 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, d:  0.2f);
        // 0x00B35994: MOV v3.16b, v0.16b         | V3 = val_17.x;//m1                      
        // 0x00B35998: MOV v4.16b, v1.16b         | V4 = val_17.y;//m1                      
        // 0x00B3599C: MOV v5.16b, v2.16b         | V5 = val_17.z;//m1                      
        // 0x00B359A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B359A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B359A8: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
        // 0x00B359AC: MOV v1.16b, v13.16b        | V1 = p.y;//m1                           
        // 0x00B359B0: MOV v2.16b, v14.16b        | V2 = p.z;//m1                           
        // 0x00B359B4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        // 0x00B359B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B359BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B359C0: MOV v11.16b, v0.16b        | V11 = val_18.x;//m1                     
        // 0x00B359C4: MOV v12.16b, v1.16b        | V12 = val_18.y;//m1                     
        // 0x00B359C8: MOV v13.16b, v2.16b        | V13 = val_18.z;//m1                     
        // 0x00B359CC: BL #0x20d3ba8              | X0 = UnityEngine.Color.get_red();       
        UnityEngine.Color val_19 = UnityEngine.Color.red;
        // 0x00B359D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B359D4: STP s2, s3, [sp, #8]       | stack[1152921513196556184] = val_19.b;  stack[1152921513196556188] = val_19.a;  //  dest_result_addr=1152921513196556184 |  dest_result_addr=1152921513196556188
        // 0x00B359D8: STP s0, s1, [sp]           | stack[1152921513196556176] = val_19.r;  stack[1152921513196556180] = val_19.g;  //  dest_result_addr=1152921513196556176 |  dest_result_addr=1152921513196556180
        // 0x00B359DC: MOV v0.16b, v8.16b         | V0 = val_15.x;//m1                      
        // 0x00B359E0: MOV v1.16b, v9.16b         | V1 = val_15.y;//m1                      
        // 0x00B359E4: MOV v2.16b, v10.16b        | V2 = val_15.z;//m1                      
        // 0x00B359E8: MOV v3.16b, v11.16b        | V3 = val_18.x;//m1                      
        // 0x00B359EC: MOV v4.16b, v12.16b        | V4 = val_18.y;//m1                      
        // 0x00B359F0: MOV v5.16b, v13.16b        | V5 = val_18.z;//m1                      
        // 0x00B359F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B359F8: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, end:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, color:  new UnityEngine.Color() {r = val_19.r, g = val_19.b, a = val_8.z});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, end:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, color:  new UnityEngine.Color() {r = val_19.r, g = val_19.b, a = val_8.z});
        // 0x00B359FC: SUB sp, x29, #0x60         | SP = (1152921513196556448 - 96) = 1152921513196556352 (0x10000001FFFC9040);
        // 0x00B35A00: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B35A04: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B35A08: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x00B35A0C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B35A10: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B35A14: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B35A18: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00B35A1C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B35A20 (11754016), len: 4900  VirtAddr: 0x00B35A20 RVA: 0x00B35A20 token: 100682133 methodIndex: 24964 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnGUI()
    {
        //
        // Disasemble & Code
        //  | 
        var val_93;
        //  | 
        var val_103;
        //  | 
        var val_110;
        //  | 
        var val_113;
        //  | 
        var val_114;
        //  | 
        var val_115;
        //  | 
        float val_116;
        //  | 
        string val_117;
        //  | 
        var val_118;
        //  | 
        bool val_119;
        //  | 
        var val_120;
        //  | 
        var val_121;
        //  | 
        string val_122;
        //  | 
        var val_123;
        //  | 
        var val_124;
        //  | 
        float val_125;
        //  | 
        float val_126;
        //  | 
        var val_127;
        //  | 
        UnityEngine.Rect val_128;
        //  | 
        float val_129;
        //  | 
        float val_130;
        //  | 
        var val_131;
        //  | 
        float val_132;
        //  | 
        var val_133;
        //  | 
        float val_134;
        //  | 
        var val_135;
        //  | 
        var val_136;
        //  | 
        float val_137;
        //  | 
        var val_138;
        //  | 
        var val_139;
        //  | 
        float val_140;
        //  | 
        var val_141;
        // 0x00B35A20: STP d15, d14, [sp, #-0x90]! | stack[1152921513197503792] = ???;  stack[1152921513197503800] = ???;  //  dest_result_addr=1152921513197503792 |  dest_result_addr=1152921513197503800
        // 0x00B35A24: STP d13, d12, [sp, #0x10]  | stack[1152921513197503808] = ???;  stack[1152921513197503816] = ???;  //  dest_result_addr=1152921513197503808 |  dest_result_addr=1152921513197503816
        // 0x00B35A28: STP d11, d10, [sp, #0x20]  | stack[1152921513197503824] = ???;  stack[1152921513197503832] = ???;  //  dest_result_addr=1152921513197503824 |  dest_result_addr=1152921513197503832
        // 0x00B35A2C: STP d9, d8, [sp, #0x30]    | stack[1152921513197503840] = ???;  stack[1152921513197503848] = ???;  //  dest_result_addr=1152921513197503840 |  dest_result_addr=1152921513197503848
        // 0x00B35A30: STP x26, x25, [sp, #0x40]  | stack[1152921513197503856] = ???;  stack[1152921513197503864] = ???;  //  dest_result_addr=1152921513197503856 |  dest_result_addr=1152921513197503864
        // 0x00B35A34: STP x24, x23, [sp, #0x50]  | stack[1152921513197503872] = ???;  stack[1152921513197503880] = ???;  //  dest_result_addr=1152921513197503872 |  dest_result_addr=1152921513197503880
        // 0x00B35A38: STP x22, x21, [sp, #0x60]  | stack[1152921513197503888] = ???;  stack[1152921513197503896] = ???;  //  dest_result_addr=1152921513197503888 |  dest_result_addr=1152921513197503896
        // 0x00B35A3C: STP x20, x19, [sp, #0x70]  | stack[1152921513197503904] = ???;  stack[1152921513197503912] = ???;  //  dest_result_addr=1152921513197503904 |  dest_result_addr=1152921513197503912
        // 0x00B35A40: STP x29, x30, [sp, #0x80]  | stack[1152921513197503920] = ???;  stack[1152921513197503928] = ???;  //  dest_result_addr=1152921513197503920 |  dest_result_addr=1152921513197503928
        // 0x00B35A44: ADD x29, sp, #0x80         | X29 = (1152921513197503792 + 128) = 1152921513197503920 (0x10000002000B05B0);
        // 0x00B35A48: SUB sp, sp, #0x70          | SP = (1152921513197503792 - 112) = 1152921513197503680 (0x10000002000B04C0);
        // 0x00B35A4C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B35A50: LDRB w8, [x20, #0x7aa]     | W8 = (bool)static_value_037337AA;       
        // 0x00B35A54: MOV x19, x0                | X19 = 1152921513197515936 (0x10000002000B34A0);//ML01
        val_114 = this;
        // 0x00B35A58: TBNZ w8, #0, #0xb35a74     | if (static_value_037337AA == true) goto label_0;
        // 0x00B35A5C: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x00B35A60: LDR x8, [x8, #0xaf8]       | X8 = 0x2B8EC58;                         
        // 0x00B35A64: LDR w0, [x8]               | W0 = 0x11D6;                            
        // 0x00B35A68: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D6, ????);     
        // 0x00B35A6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B35A70: STRB w8, [x20, #0x7aa]     | static_value_037337AA = true;            //  dest_result_addr=57882538
        label_0:
        // 0x00B35A74: STP wzr, wzr, [sp, #0x68]  | stack[1152921513197503784] = 0x0;  stack[1152921513197503788] = 0x0;  //  dest_result_addr=1152921513197503784 |  dest_result_addr=1152921513197503788
        // 0x00B35A78: STP wzr, wzr, [sp, #0x60]  | stack[1152921513197503776] = 0x0;  stack[1152921513197503780] = 0x0;  //  dest_result_addr=1152921513197503776 |  dest_result_addr=1152921513197503780
        // 0x00B35A7C: STP wzr, wzr, [sp, #0x58]  | stack[1152921513197503768] = 0x0;  stack[1152921513197503772] = 0x0;  //  dest_result_addr=1152921513197503768 |  dest_result_addr=1152921513197503772
        // 0x00B35A80: STP wzr, wzr, [sp, #0x50]  | stack[1152921513197503760] = 0x0;  stack[1152921513197503764] = 0x0;  //  dest_result_addr=1152921513197503760 |  dest_result_addr=1152921513197503764
        // 0x00B35A84: STP wzr, wzr, [sp, #0x48]  | stack[1152921513197503752] = 0x0;  stack[1152921513197503756] = 0x0;  //  dest_result_addr=1152921513197503752 |  dest_result_addr=1152921513197503756
        // 0x00B35A88: LDRB w8, [x19, #0x1c]      | W8 = this.show; //P2                    
        // 0x00B35A8C: CBZ w8, #0xb36d18          | if (this.show == false) goto label_107; 
        if(this.show == false)
        {
            goto label_107;
        }
        // 0x00B35A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35A98: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_1 = UnityEngine.Application.isPlaying;
        // 0x00B35A9C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B35AA0: TBNZ w8, #0, #0xb35aac     | if ((val_1 & 1) == true) goto label_2;  
        if(val_2 == true)
        {
            goto label_2;
        }
        // 0x00B35AA4: LDRB w8, [x19, #0x1d]      | W8 = this.showInEditor; //P2            
        // 0x00B35AA8: CBZ w8, #0xb36d18          | if (this.showInEditor == false) goto label_107;
        if(this.showInEditor == false)
        {
            goto label_107;
        }
        label_2:
        // 0x00B35AAC: LDR x8, [x19, #0xa0]       | X8 = this.style; //P2                   
        // 0x00B35AB0: CBNZ x8, #0xb35b74         | if (this.style != null) goto label_4;   
        if(this.style != null)
        {
            goto label_4;
        }
        // 0x00B35AB4: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B35AB8: LDR x8, [x8, #0xcb8]       | X8 = 1152921504726335488;               
        // 0x00B35ABC: LDR x0, [x8]               | X0 = typeof(UnityEngine.GUIStyle);      
        UnityEngine.GUIStyle val_3 = null;
        // 0x00B35AC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.GUIStyle), ????);
        // 0x00B35AC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35AC8: MOV x20, x0                | X20 = 1152921504726335488 (0x10000000071F4000);//ML01
        // 0x00B35ACC: BL #0x2142910              | .ctor();                                
        val_3 = new UnityEngine.GUIStyle();
        // 0x00B35AD0: STR x20, [x19, #0xa0]      | this.style = typeof(UnityEngine.GUIStyle);  //  dest_result_addr=1152921513197516096
        this.style = val_3;
        // 0x00B35AD4: CBNZ x20, #0xb35adc        | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x00B35AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_5:
        // 0x00B35ADC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35AE0: MOV x0, x20                | X0 = 1152921504726335488 (0x10000000071F4000);//ML01
        // 0x00B35AE4: BL #0x2144074              | X0 = get_normal();                      
        UnityEngine.GUIStyleState val_4 = normal;
        // 0x00B35AE8: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B35AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35AF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35AF4: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
        UnityEngine.Color val_5 = UnityEngine.Color.white;
        // 0x00B35AF8: MOV v8.16b, v0.16b         | V8 = val_5.r;//m1                       
        // 0x00B35AFC: MOV v9.16b, v1.16b         | V9 = val_5.g;//m1                       
        // 0x00B35B00: MOV v10.16b, v2.16b        | V10 = val_5.b;//m1                      
        // 0x00B35B04: MOV v11.16b, v3.16b        | V11 = val_5.a;//m1                      
        // 0x00B35B08: CBNZ x20, #0xb35b10        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B35B0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00B35B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35B14: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B35B18: MOV v0.16b, v8.16b         | V0 = val_5.r;//m1                       
        // 0x00B35B1C: MOV v1.16b, v9.16b         | V1 = val_5.g;//m1                       
        // 0x00B35B20: MOV v2.16b, v10.16b        | V2 = val_5.b;//m1                       
        // 0x00B35B24: MOV v3.16b, v11.16b        | V3 = val_5.a;//m1                       
        // 0x00B35B28: BL #0x21440b4              | val_4.set_textColor(value:  new UnityEngine.Color() {r = val_5.r, g = val_5.g, b = val_5.b, a = val_5.a});
        val_4.textColor = new UnityEngine.Color() {r = val_5.r, g = val_5.g, b = val_5.b, a = val_5.a};
        // 0x00B35B2C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00B35B30: LDR x20, [x19, #0xa0]      | X20 = this.style; //P2                  
        // 0x00B35B34: LDR x8, [x8, #0x758]       | X8 = 1152921504693694464;               
        // 0x00B35B38: LDR x0, [x8]               | X0 = typeof(UnityEngine.RectOffset);    
        UnityEngine.RectOffset val_6 = null;
        // 0x00B35B3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.RectOffset), ????);
        // 0x00B35B40: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B35B44: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x00B35B48: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
        // 0x00B35B4C: MOVZ w3, #0x5              | W3 = 5 (0x5);//ML01                     
        // 0x00B35B50: MOVZ w4, #0x5              | W4 = 5 (0x5);//ML01                     
        // 0x00B35B54: MOV x21, x0                | X21 = 1152921504693694464 (0x10000000052D3000);//ML01
        // 0x00B35B58: BL #0x1b82800              | .ctor(left:  5, right:  5, top:  5, bottom:  5);
        val_6 = new UnityEngine.RectOffset(left:  5, right:  5, top:  5, bottom:  5);
        // 0x00B35B5C: CBNZ x20, #0xb35b64        | if (this.style != null) goto label_7;   
        if(this.style != null)
        {
            goto label_7;
        }
        // 0x00B35B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(left:  5, right:  5, top:  5, bottom:  5), ????);
        label_7:
        // 0x00B35B64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35B68: MOV x0, x20                | X0 = this.style;//m1                    
        // 0x00B35B6C: MOV x1, x21                | X1 = 1152921504693694464 (0x10000000052D3000);//ML01
        // 0x00B35B70: BL #0x21461a8              | this.style.set_padding(value:  val_6);  
        this.style.padding = val_6;
        label_4:
        // 0x00B35B74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35B7C: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_7 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B35B80: LDR s1, [x19, #0x48]       | S1 = this.lastUpdate; //P2              
        // 0x00B35B84: FSUB s0, s0, s1            | S0 = (val_7 - this.lastUpdate);         
        val_116 = val_7 - this.lastUpdate;
        // 0x00B35B88: FMOV s1, #0.50000000       | S1 = 0.5;                               
        // 0x00B35B8C: FCMP s0, s1                | STATE = COMPARE((val_7 - this.lastUpdate), 0.5)
        // 0x00B35B90: B.GT #0xb35bb0             | if (val_116 > 0.5f) goto label_9;       
        if(val_116 > 0.5f)
        {
            goto label_9;
        }
        // 0x00B35B94: LDR x8, [x19, #0x40]       | X8 = this.cachedText; //P2              
        // 0x00B35B98: CBZ x8, #0xb35bb0          | if (this.cachedText == null) goto label_9;
        if(this.cachedText == null)
        {
            goto label_9;
        }
        // 0x00B35B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35BA4: BL #0x20c6f44              | X0 = UnityEngine.Application.get_isPlaying();
        bool val_8 = UnityEngine.Application.isPlaying;
        // 0x00B35BA8: AND w8, w0, #1             | W8 = (val_8 & 1);                       
        bool val_9 = val_8;
        // 0x00B35BAC: TBNZ w8, #0, #0xb365dc     | if ((val_8 & 1) == true) goto label_10; 
        if(val_9 == true)
        {
            goto label_10;
        }
        label_9:
        // 0x00B35BB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B35BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35BB8: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_10 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B35BBC: LDR s1, [x19, #0x18]       | S1 = this.yOffset; //P2                 
        // 0x00B35BC0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B35BC4: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B35BC8: LDR s2, [x8, #0x93c]       | S2 = 310;                               
        // 0x00B35BCC: LDR s3, [x9, #0x79c]       | S3 = 40;                                
        // 0x00B35BD0: STR s0, [x19, #0x48]       | this.lastUpdate = val_10;                //  dest_result_addr=1152921513197516008
        this.lastUpdate = val_10;
        // 0x00B35BD4: SCVTF s1, s1               | S1 = (float)(this.yOffset);             
        // 0x00B35BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35BDC: FMOV s0, #5.00000000       | S0 = 5;                                 
        val_116 = 5f;
        // 0x00B35BE0: ADD x0, sp, #0x30          | X0 = (1152921513197503680 + 48) = 1152921513197503728 (0x10000002000B04F0);
        // 0x00B35BE4: STP xzr, xzr, [sp, #0x30]  | stack[1152921513197503728] = 0x0;  stack[1152921513197503736] = 0x0;  //  dest_result_addr=1152921513197503728 |  dest_result_addr=1152921513197503736
        // 0x00B35BE8: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
        // 0x00B35BEC: LDR q0, [sp, #0x30]        | Q0 = 0x0;                               
        UnityEngine.Rect val_116 = 0;
        // 0x00B35BF0: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35BF4: STR q0, [x19, #0x90]       | this.boxRect = new UnityEngine.Rect();   //  dest_result_addr=1152921513197516080
        this.boxRect = val_116;
        // 0x00B35BF8: CBNZ x20, #0xb35c00        | if (this.text != null) goto label_11;   
        if(this.text != null)
        {
            goto label_11;
        }
        // 0x00B35BFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002000B04F0, ????);
        label_11:
        // 0x00B35C00: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B35C04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35C08: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35C0C: BL #0x1b5ac0c              | this.text.set_Length(value:  0);        
        this.text.Length = 0;
        // 0x00B35C10: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35C14: CBNZ x20, #0xb35c1c        | if (this.text != null) goto label_12;   
        if(this.text != null)
        {
            goto label_12;
        }
        // 0x00B35C18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.text, ????);  
        label_12:
        // 0x00B35C1C: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
        // 0x00B35C20: LDR x8, [x8, #0x2c0]       | X8 = (string**)(1152921513196689280)("A* Pathfinding Project Debugger");
        // 0x00B35C24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35C28: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35C2C: LDR x1, [x8]               | X1 = "A* Pathfinding Project Debugger"; 
        // 0x00B35C30: BL #0x1b5c068              | X0 = this.text.AppendLine(value:  "A* Pathfinding Project Debugger");
        System.Text.StringBuilder val_11 = this.text.AppendLine(value:  "A* Pathfinding Project Debugger");
        // 0x00B35C34: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35C38: CBNZ x20, #0xb35c40        | if (this.text != null) goto label_13;   
        if(this.text != null)
        {
            goto label_13;
        }
        // 0x00B35C3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_13:
        // 0x00B35C40: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B35C44: LDR x8, [x8, #0xc50]       | X8 = (string**)(1152921513196697616)("A* Version: ");
        // 0x00B35C48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35C4C: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35C50: LDR x1, [x8]               | X1 = "A* Version: ";                    
        // 0x00B35C54: BL #0x1b5b818              | X0 = this.text.Append(value:  "A* Version: ");
        System.Text.StringBuilder val_12 = this.text.Append(value:  "A* Version: ");
        // 0x00B35C58: ADRP x23, #0x362c000       | X23 = 56803328 (0x362C000);             
        // 0x00B35C5C: LDR x23, [x23, #0xe80]     | X23 = 1152921504837996544;              
        // 0x00B35C60: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00B35C64: LDR x8, [x23]              | X8 = typeof(AstarPath);                 
        // 0x00B35C68: LDRB w9, [x8, #0x10a]      | W9 = AstarPath.__il2cppRuntimeField_10A;
        // 0x00B35C6C: TBZ w9, #0, #0xb35c80      | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B35C70: LDR w9, [x8, #0xbc]        | W9 = AstarPath.__il2cppRuntimeField_cctor_finished;
        // 0x00B35C74: CBNZ w9, #0xb35c80         | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B35C78: MOV x0, x8                 | X0 = 1152921504837996544 (0x100000000DC71000);//ML01
        // 0x00B35C7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
        label_15:
        // 0x00B35C80: BL #0xb36d44               | X0 = AstarPath.get_Version();           
        System.Version val_13 = AstarPath.Version;
        // 0x00B35C84: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x00B35C88: CBNZ x21, #0xb35c90        | if (val_13 != null) goto label_16;      
        if(val_13 != null)
        {
            goto label_16;
        }
        // 0x00B35C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_16:
        // 0x00B35C90: LDR x8, [x21]              | X8 = typeof(System.Version);            
        // 0x00B35C94: MOV x0, x21                | X0 = val_13;//m1                        
        // 0x00B35C98: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Version).__il2cppRuntimeField_140; X1 = typeof(System.Version).__il2cppRuntimeField_148; //  | 
        // 0x00B35C9C: BLR x9                     | X0 = typeof(System.Version).__il2cppRuntimeField_140();
        // 0x00B35CA0: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x00B35CA4: CBNZ x20, #0xb35cac        | if (val_12 != null) goto label_17;      
        if(val_12 != null)
        {
            goto label_17;
        }
        // 0x00B35CA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_17:
        // 0x00B35CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35CB0: MOV x0, x20                | X0 = val_12;//m1                        
        // 0x00B35CB4: MOV x1, x21                | X1 = val_13;//m1                        
        val_117 = val_13;
        // 0x00B35CB8: BL #0x1b5b818              | X0 = val_12.Append(value:  val_117 = val_13);
        System.Text.StringBuilder val_14 = val_12.Append(value:  val_117);
        // 0x00B35CBC: LDRB w8, [x19, #0x20]      | W8 = this.showMemProfile; //P2          
        // 0x00B35CC0: CBZ w8, #0xb3614c          | if (this.showMemProfile == false) goto label_18;
        if(this.showMemProfile == false)
        {
            goto label_18;
        }
        // 0x00B35CC4: ADD x20, x19, #0x90        | X20 = this.boxRect;//AP2 res_addr=1152921513197516080
        // 0x00B35CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35CCC: MOV x0, x20                | X0 = this.boxRect;//m1                  
        // 0x00B35CD0: BL #0x1b819d4              | X0 = label_UnityEngine_Rect_set_width_GL01B819D4();
        // 0x00B35CD4: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B35CD8: LDR s1, [x8, #0x798]       | S1 = 200;                               
        // 0x00B35CDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35CE0: MOV x0, x20                | X0 = this.boxRect;//m1                  
        // 0x00B35CE4: FADD s0, s0, s1            | S0 = (0 + 200f);                        
        val_116 = val_116 + 200f;
        // 0x00B35CE8: BL #0x1b819e4              | X0 = label_UnityEngine_Rect_get_height_GL01B819E4();
        // 0x00B35CEC: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35CF0: CBNZ x20, #0xb35cf8        | if (this.text != null) goto label_19;   
        if(this.text != null)
        {
            goto label_19;
        }
        // 0x00B35CF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.boxRect, ????);
        label_19:
        // 0x00B35CF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35CFC: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35D00: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_15 = this.text.AppendLine();
        // 0x00B35D04: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35D08: CBNZ x20, #0xb35d10        | if (this.text != null) goto label_20;   
        if(this.text != null)
        {
            goto label_20;
        }
        // 0x00B35D0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_20:
        // 0x00B35D10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35D14: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35D18: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_16 = this.text.AppendLine();
        // 0x00B35D1C: ADRP x21, #0x35b9000       | X21 = 56332288 (0x35B9000);             
        // 0x00B35D20: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35D24: LDR x21, [x21, #0xaa0]     | X21 = (string**)(1152921513196730480)("Currently allocated");
        // 0x00B35D28: LDR x0, [x21]              | X0 = "Currently allocated";             
        // 0x00B35D2C: CBNZ x0, #0xb35d38         | if ("Currently allocated" != null) goto label_21;
        if("Currently allocated" != null)
        {
            goto label_21;
        }
        // 0x00B35D30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "Currently allocated", ????);
        // 0x00B35D34: LDR x0, [x21]              | X0 = "Currently allocated";             
        label_21:
        // 0x00B35D38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35D3C: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B35D40: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_17 = PadRight(totalWidth:  25);
        // 0x00B35D44: MOV x21, x0                | X21 = val_17;//m1                       
        // 0x00B35D48: CBNZ x20, #0xb35d50        | if (this.text != null) goto label_22;   
        if(this.text != null)
        {
            goto label_22;
        }
        // 0x00B35D4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_22:
        // 0x00B35D50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35D54: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35D58: MOV x1, x21                | X1 = val_17;//m1                        
        // 0x00B35D5C: BL #0x1b5b818              | X0 = this.text.Append(value:  val_17);  
        System.Text.StringBuilder val_18 = this.text.Append(value:  val_17);
        // 0x00B35D60: ADRP x22, #0x3680000       | X22 = 57147392 (0x3680000);             
        // 0x00B35D64: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35D68: LDR s0, [x19, #0x78]       | S0 = this.allocMem; //P2                
        // 0x00B35D6C: LDR x22, [x22, #0xf60]     | X22 = (string**)(1152921513196742880)("0.0 MB");
        // 0x00B35D70: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B35D74: LDR s8, [x8, #0x940]       | S8 = 1000000;                           
        // 0x00B35D78: SCVTF s0, s0               | S0 = (float)(this.allocMem);            
        float val_117 = (float)this.allocMem;
        // 0x00B35D7C: LDR x1, [x22]              | X1 = "0.0 MB";                          
        // 0x00B35D80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35D84: FDIV s0, s0, s8            | S0 = (this.allocMem / 1000000f);        
        val_117 = val_117 / 1000000f;
        // 0x00B35D88: ADD x0, sp, #0x6c          | X0 = (1152921513197503680 + 108) = 1152921513197503788 (0x10000002000B052C);
        // 0x00B35D8C: STR s0, [sp, #0x6c]        | stack[1152921513197503788] = (this.allocMem / 1000000f);  //  dest_result_addr=1152921513197503788
        // 0x00B35D90: BL #0x18a7768              | X0 = (this.allocMem / 1000000f).ToString(format:  "0.0 MB");
        string val_19 = val_117.ToString(format:  "0.0 MB");
        // 0x00B35D94: MOV x21, x0                | X21 = val_19;//m1                       
        // 0x00B35D98: CBNZ x20, #0xb35da0        | if (this.text != null) goto label_23;   
        if(this.text != null)
        {
            goto label_23;
        }
        // 0x00B35D9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_23:
        // 0x00B35DA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35DA4: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35DA8: MOV x1, x21                | X1 = val_19;//m1                        
        // 0x00B35DAC: BL #0x1b5b818              | X0 = this.text.Append(value:  val_19);  
        System.Text.StringBuilder val_20 = this.text.Append(value:  val_19);
        // 0x00B35DB0: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35DB4: CBNZ x20, #0xb35dbc        | if (this.text != null) goto label_24;   
        if(this.text != null)
        {
            goto label_24;
        }
        // 0x00B35DB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_24:
        // 0x00B35DBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35DC0: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35DC4: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_21 = this.text.AppendLine();
        // 0x00B35DC8: ADRP x21, #0x3650000       | X21 = 56950784 (0x3650000);             
        // 0x00B35DCC: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35DD0: LDR x21, [x21, #0x6e8]     | X21 = (string**)(1152921513196763440)("Peak allocated");
        // 0x00B35DD4: LDR x0, [x21]              | X0 = "Peak allocated";                  
        // 0x00B35DD8: CBNZ x0, #0xb35de4         | if ("Peak allocated" != null) goto label_25;
        if("Peak allocated" != null)
        {
            goto label_25;
        }
        // 0x00B35DDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "Peak allocated", ????);
        // 0x00B35DE0: LDR x0, [x21]              | X0 = "Peak allocated";                  
        label_25:
        // 0x00B35DE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35DE8: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B35DEC: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_22 = PadRight(totalWidth:  25);
        // 0x00B35DF0: MOV x21, x0                | X21 = val_22;//m1                       
        // 0x00B35DF4: CBNZ x20, #0xb35dfc        | if (this.text != null) goto label_26;   
        if(this.text != null)
        {
            goto label_26;
        }
        // 0x00B35DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_26:
        // 0x00B35DFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35E00: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35E04: MOV x1, x21                | X1 = val_22;//m1                        
        // 0x00B35E08: BL #0x1b5b818              | X0 = this.text.Append(value:  val_22);  
        System.Text.StringBuilder val_23 = this.text.Append(value:  val_22);
        // 0x00B35E0C: LDR s0, [x19, #0x80]       | S0 = this.peakAlloc; //P2               
        // 0x00B35E10: LDR x1, [x22]              | X1 = "0.0 MB";                          
        // 0x00B35E14: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35E18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35E1C: SCVTF s0, s0               | S0 = (float)(this.peakAlloc);           
        float val_118 = (float)this.peakAlloc;
        // 0x00B35E20: FDIV s0, s0, s8            | S0 = (this.peakAlloc / 1000000f);       
        val_118 = val_118 / 1000000f;
        // 0x00B35E24: ADD x0, sp, #0x68          | X0 = (1152921513197503680 + 104) = 1152921513197503784 (0x10000002000B0528);
        // 0x00B35E28: STR s0, [sp, #0x68]        | stack[1152921513197503784] = (this.peakAlloc / 1000000f);  //  dest_result_addr=1152921513197503784
        // 0x00B35E2C: BL #0x18a7768              | X0 = (this.peakAlloc / 1000000f).ToString(format:  "0.0 MB");
        string val_24 = val_118.ToString(format:  "0.0 MB");
        // 0x00B35E30: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00B35E34: CBNZ x20, #0xb35e3c        | if (this.text != null) goto label_27;   
        if(this.text != null)
        {
            goto label_27;
        }
        // 0x00B35E38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_27:
        // 0x00B35E3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35E40: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35E44: MOV x1, x21                | X1 = val_24;//m1                        
        // 0x00B35E48: BL #0x1b5b818              | X0 = this.text.Append(value:  val_24);  
        System.Text.StringBuilder val_25 = this.text.Append(value:  val_24);
        // 0x00B35E4C: MOV x20, x0                | X20 = val_25;//m1                       
        // 0x00B35E50: CBNZ x20, #0xb35e58        | if (val_25 != null) goto label_28;      
        if(val_25 != null)
        {
            goto label_28;
        }
        // 0x00B35E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_28:
        // 0x00B35E58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35E5C: MOV x0, x20                | X0 = val_25;//m1                        
        // 0x00B35E60: BL #0x1b5c038              | X0 = val_25.AppendLine();               
        System.Text.StringBuilder val_26 = val_25.AppendLine();
        // 0x00B35E64: ADRP x21, #0x35bf000       | X21 = 56356864 (0x35BF000);             
        // 0x00B35E68: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35E6C: LDR x21, [x21, #0x998]     | X21 = (string**)(1152921513196792208)("Last collect peak");
        // 0x00B35E70: LDR x0, [x21]              | X0 = "Last collect peak";               
        // 0x00B35E74: CBNZ x0, #0xb35e80         | if ("Last collect peak" != null) goto label_29;
        if("Last collect peak" != null)
        {
            goto label_29;
        }
        // 0x00B35E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "Last collect peak", ????);
        // 0x00B35E7C: LDR x0, [x21]              | X0 = "Last collect peak";               
        label_29:
        // 0x00B35E80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35E84: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B35E88: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_27 = PadRight(totalWidth:  25);
        // 0x00B35E8C: MOV x21, x0                | X21 = val_27;//m1                       
        // 0x00B35E90: CBNZ x20, #0xb35e98        | if (this.text != null) goto label_30;   
        if(this.text != null)
        {
            goto label_30;
        }
        // 0x00B35E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_30:
        // 0x00B35E98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35E9C: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35EA0: MOV x1, x21                | X1 = val_27;//m1                        
        // 0x00B35EA4: BL #0x1b5b818              | X0 = this.text.Append(value:  val_27);  
        System.Text.StringBuilder val_28 = this.text.Append(value:  val_27);
        // 0x00B35EA8: LDR s0, [x19, #0x7c]       | S0 = this.collectAlloc; //P2            
        // 0x00B35EAC: LDR x1, [x22]              | X1 = "0.0 MB";                          
        // 0x00B35EB0: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35EB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35EB8: SCVTF s0, s0               | S0 = (float)(this.collectAlloc);        
        float val_119 = (float)this.collectAlloc;
        // 0x00B35EBC: FDIV s0, s0, s8            | S0 = (this.collectAlloc / 1000000f);    
        val_119 = val_119 / 1000000f;
        // 0x00B35EC0: ADD x0, sp, #0x64          | X0 = (1152921513197503680 + 100) = 1152921513197503780 (0x10000002000B0524);
        // 0x00B35EC4: STR s0, [sp, #0x64]        | stack[1152921513197503780] = (this.collectAlloc / 1000000f);  //  dest_result_addr=1152921513197503780
        // 0x00B35EC8: BL #0x18a7768              | X0 = (this.collectAlloc / 1000000f).ToString(format:  "0.0 MB");
        string val_29 = val_119.ToString(format:  "0.0 MB");
        // 0x00B35ECC: MOV x21, x0                | X21 = val_29;//m1                       
        // 0x00B35ED0: CBNZ x20, #0xb35ed8        | if (this.text != null) goto label_31;   
        if(this.text != null)
        {
            goto label_31;
        }
        // 0x00B35ED4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_31:
        // 0x00B35ED8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35EDC: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35EE0: MOV x1, x21                | X1 = val_29;//m1                        
        // 0x00B35EE4: BL #0x1b5b818              | X0 = this.text.Append(value:  val_29);  
        System.Text.StringBuilder val_30 = this.text.Append(value:  val_29);
        // 0x00B35EE8: MOV x20, x0                | X20 = val_30;//m1                       
        // 0x00B35EEC: CBNZ x20, #0xb35ef4        | if (val_30 != null) goto label_32;      
        if(val_30 != null)
        {
            goto label_32;
        }
        // 0x00B35EF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_32:
        // 0x00B35EF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35EF8: MOV x0, x20                | X0 = val_30;//m1                        
        // 0x00B35EFC: BL #0x1b5c038              | X0 = val_30.AppendLine();               
        System.Text.StringBuilder val_31 = val_30.AppendLine();
        // 0x00B35F00: ADRP x21, #0x35f4000       | X21 = 56573952 (0x35F4000);             
        // 0x00B35F04: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35F08: LDR x21, [x21, #0x480]     | X21 = (string**)(1152921513196820992)("Allocation rate");
        // 0x00B35F0C: LDR x0, [x21]              | X0 = "Allocation rate";                 
        // 0x00B35F10: CBNZ x0, #0xb35f1c         | if ("Allocation rate" != null) goto label_33;
        if("Allocation rate" != null)
        {
            goto label_33;
        }
        // 0x00B35F14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "Allocation rate", ????);
        // 0x00B35F18: LDR x0, [x21]              | X0 = "Allocation rate";                 
        label_33:
        // 0x00B35F1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35F20: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B35F24: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_32 = PadRight(totalWidth:  25);
        // 0x00B35F28: MOV x21, x0                | X21 = val_32;//m1                       
        // 0x00B35F2C: CBNZ x20, #0xb35f34        | if (this.text != null) goto label_34;   
        if(this.text != null)
        {
            goto label_34;
        }
        // 0x00B35F30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_34:
        // 0x00B35F34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35F38: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35F3C: MOV x1, x21                | X1 = val_32;//m1                        
        // 0x00B35F40: BL #0x1b5b818              | X0 = this.text.Append(value:  val_32);  
        System.Text.StringBuilder val_33 = this.text.Append(value:  val_32);
        // 0x00B35F44: LDR s0, [x19, #0x6c]       | S0 = this.allocRate; //P2               
        // 0x00B35F48: LDR x1, [x22]              | X1 = "0.0 MB";                          
        // 0x00B35F4C: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35F50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35F54: SCVTF s0, s0               | S0 = (float)(this.allocRate);           
        float val_120 = (float)this.allocRate;
        // 0x00B35F58: FDIV s0, s0, s8            | S0 = (this.allocRate / 1000000f);       
        val_120 = val_120 / 1000000f;
        // 0x00B35F5C: ADD x0, sp, #0x60          | X0 = (1152921513197503680 + 96) = 1152921513197503776 (0x10000002000B0520);
        // 0x00B35F60: STR s0, [sp, #0x60]        | stack[1152921513197503776] = (this.allocRate / 1000000f);  //  dest_result_addr=1152921513197503776
        // 0x00B35F64: BL #0x18a7768              | X0 = (this.allocRate / 1000000f).ToString(format:  "0.0 MB");
        string val_34 = val_120.ToString(format:  "0.0 MB");
        // 0x00B35F68: MOV x21, x0                | X21 = val_34;//m1                       
        // 0x00B35F6C: CBNZ x20, #0xb35f74        | if (this.text != null) goto label_35;   
        if(this.text != null)
        {
            goto label_35;
        }
        // 0x00B35F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_35:
        // 0x00B35F74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35F78: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35F7C: MOV x1, x21                | X1 = val_34;//m1                        
        // 0x00B35F80: BL #0x1b5b818              | X0 = this.text.Append(value:  val_34);  
        System.Text.StringBuilder val_35 = this.text.Append(value:  val_34);
        // 0x00B35F84: MOV x20, x0                | X20 = val_35;//m1                       
        // 0x00B35F88: CBNZ x20, #0xb35f90        | if (val_35 != null) goto label_36;      
        if(val_35 != null)
        {
            goto label_36;
        }
        // 0x00B35F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_36:
        // 0x00B35F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B35F94: MOV x0, x20                | X0 = val_35;//m1                        
        // 0x00B35F98: BL #0x1b5c038              | X0 = val_35.AppendLine();               
        System.Text.StringBuilder val_36 = val_35.AppendLine();
        // 0x00B35F9C: ADRP x21, #0x3653000       | X21 = 56963072 (0x3653000);             
        // 0x00B35FA0: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35FA4: LDR x21, [x21, #0xa20]     | X21 = (string**)(1152921513196849776)("Collection frequency");
        // 0x00B35FA8: LDR x0, [x21]              | X0 = "Collection frequency";            
        // 0x00B35FAC: CBNZ x0, #0xb35fb8         | if ("Collection frequency" != null) goto label_37;
        if("Collection frequency" != null)
        {
            goto label_37;
        }
        // 0x00B35FB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "Collection frequency", ????);
        // 0x00B35FB4: LDR x0, [x21]              | X0 = "Collection frequency";            
        label_37:
        // 0x00B35FB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35FBC: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B35FC0: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_37 = PadRight(totalWidth:  25);
        // 0x00B35FC4: MOV x21, x0                | X21 = val_37;//m1                       
        // 0x00B35FC8: CBNZ x20, #0xb35fd0        | if (this.text != null) goto label_38;   
        if(this.text != null)
        {
            goto label_38;
        }
        // 0x00B35FCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_38:
        // 0x00B35FD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35FD4: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B35FD8: MOV x1, x21                | X1 = val_37;//m1                        
        // 0x00B35FDC: BL #0x1b5b818              | X0 = this.text.Append(value:  val_37);  
        System.Text.StringBuilder val_38 = this.text.Append(value:  val_37);
        // 0x00B35FE0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00B35FE4: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B35FE8: LDR x8, [x8, #0xd70]       | X8 = (string**)(1152921513196862176)("0.00");
        // 0x00B35FEC: ADD x0, x19, #0x64         | X0 = this.delta;//AP2 res_addr=1152921513197516036
        // 0x00B35FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B35FF4: LDR x1, [x8]               | X1 = "0.00";                            
        // 0x00B35FF8: BL #0x18a7768              | X0 = this.delta.ToString(format:  "0.00");
        string val_39 = this.delta.ToString(format:  "0.00");
        // 0x00B35FFC: MOV x21, x0                | X21 = val_39;//m1                       
        // 0x00B36000: CBNZ x20, #0xb36008        | if (this.text != null) goto label_39;   
        if(this.text != null)
        {
            goto label_39;
        }
        // 0x00B36004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_39:
        // 0x00B36008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3600C: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36010: MOV x1, x21                | X1 = val_39;//m1                        
        // 0x00B36014: BL #0x1b5b818              | X0 = this.text.Append(value:  val_39);  
        System.Text.StringBuilder val_40 = this.text.Append(value:  val_39);
        // 0x00B36018: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B3601C: CBNZ x20, #0xb36024        | if (this.text != null) goto label_40;   
        if(this.text != null)
        {
            goto label_40;
        }
        // 0x00B36020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_40:
        // 0x00B36024: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B36028: LDR x8, [x8, #0x940]       | X8 = (string**)(1152921513196874544)("s\n");
        // 0x00B3602C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36030: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36034: LDR x1, [x8]               | X1 = "s\n";                             
        // 0x00B36038: BL #0x1b5b818              | X0 = this.text.Append(value:  "s\n");   
        System.Text.StringBuilder val_41 = this.text.Append(value:  "s\n");
        // 0x00B3603C: ADRP x21, #0x35b9000       | X21 = 56332288 (0x35B9000);             
        // 0x00B36040: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B36044: LDR x21, [x21, #0xb00]     | X21 = (string**)(1152921513196882816)("Last collect fps");
        // 0x00B36048: LDR x0, [x21]              | X0 = "Last collect fps";                
        // 0x00B3604C: CBNZ x0, #0xb36058         | if ("Last collect fps" != null) goto label_41;
        if("Last collect fps" != null)
        {
            goto label_41;
        }
        // 0x00B36050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "Last collect fps", ????);
        // 0x00B36054: LDR x0, [x21]              | X0 = "Last collect fps";                
        label_41:
        // 0x00B36058: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3605C: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B36060: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_42 = PadRight(totalWidth:  25);
        // 0x00B36064: MOV x21, x0                | X21 = val_42;//m1                       
        // 0x00B36068: CBNZ x20, #0xb36070        | if (this.text != null) goto label_42;   
        if(this.text != null)
        {
            goto label_42;
        }
        // 0x00B3606C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_42:
        // 0x00B36070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36074: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36078: MOV x1, x21                | X1 = val_42;//m1                        
        // 0x00B3607C: BL #0x1b5b818              | X0 = this.text.Append(value:  val_42);  
        System.Text.StringBuilder val_43 = this.text.Append(value:  val_42);
        // 0x00B36080: MOV x20, x19               | X20 = 1152921513197515936 (0x10000002000B34A0);//ML01
        // 0x00B36084: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B36088: LDR s0, [x20, #0x68]!      | S0 = this.lastDeltaTime; //P2           
        // 0x00B3608C: LDR x8, [x8, #0xe90]       | X8 = (string**)(1152921513196891120)("0.0 fps");
        // 0x00B36090: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B36094: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36098: LDUR x21, [x20, #-0x30]    | X21 = this.text;                        
        // 0x00B3609C: LDR x1, [x8]               | X1 = "0.0 fps";                         
        // 0x00B360A0: FDIV s0, s1, s0            | S0 = (1f / this.lastDeltaTime);         
        val_116 = 1f / this.lastDeltaTime;
        // 0x00B360A4: ADD x0, sp, #0x5c          | X0 = (1152921513197503680 + 92) = 1152921513197503772 (0x10000002000B051C);
        // 0x00B360A8: STR s0, [sp, #0x5c]        | stack[1152921513197503772] = (1f / this.lastDeltaTime);  //  dest_result_addr=1152921513197503772
        // 0x00B360AC: BL #0x18a7768              | X0 = (1f / this.lastDeltaTime).ToString(format:  "0.0 fps");
        string val_44 = val_116.ToString(format:  "0.0 fps");
        // 0x00B360B0: MOV x22, x0                | X22 = val_44;//m1                       
        // 0x00B360B4: CBNZ x21, #0xb360bc        | if (this.text != null) goto label_43;   
        if(this.text != null)
        {
            goto label_43;
        }
        // 0x00B360B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_43:
        // 0x00B360BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B360C0: MOV x0, x21                | X0 = this.text;//m1                     
        // 0x00B360C4: MOV x1, x22                | X1 = val_44;//m1                        
        // 0x00B360C8: BL #0x1b5b818              | X0 = this.text.Append(value:  val_44);  
        System.Text.StringBuilder val_45 = this.text.Append(value:  val_44);
        // 0x00B360CC: LDR x21, [x19, #0x38]      | X21 = this.text; //P2                   
        // 0x00B360D0: CBNZ x21, #0xb360d8        | if (this.text != null) goto label_44;   
        if(this.text != null)
        {
            goto label_44;
        }
        // 0x00B360D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_44:
        // 0x00B360D8: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
        // 0x00B360DC: LDR x8, [x8, #0xb40]       | X8 = (string**)(1152921509929603584)(" (");
        // 0x00B360E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B360E4: MOV x0, x21                | X0 = this.text;//m1                     
        // 0x00B360E8: LDR x1, [x8]               | X1 = " (";                              
        // 0x00B360EC: BL #0x1b5b818              | X0 = this.text.Append(value:  " (");    
        System.Text.StringBuilder val_46 = this.text.Append(value:  " (");
        // 0x00B360F0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x00B360F4: LDR x21, [x19, #0x38]      | X21 = this.text; //P2                   
        // 0x00B360F8: LDR x8, [x8, #0x520]       | X8 = (string**)(1152921513196911696)("0.000 s");
        // 0x00B360FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36100: MOV x0, x20                | X0 = 1152921513197516040 (0x10000002000B3508);//ML01
        // 0x00B36104: LDR x1, [x8]               | X1 = "0.000 s";                         
        // 0x00B36108: BL #0x18a7768              | X0 = this.lastDeltaTime.ToString(format:  "0.000 s");
        string val_47 = this.lastDeltaTime.ToString(format:  "0.000 s");
        // 0x00B3610C: MOV x20, x0                | X20 = val_47;//m1                       
        // 0x00B36110: CBNZ x21, #0xb36118        | if (this.text != null) goto label_45;   
        if(this.text != null)
        {
            goto label_45;
        }
        // 0x00B36114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_45:
        // 0x00B36118: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3611C: MOV x0, x21                | X0 = this.text;//m1                     
        // 0x00B36120: MOV x1, x20                | X1 = val_47;//m1                        
        // 0x00B36124: BL #0x1b5b818              | X0 = this.text.Append(value:  val_47);  
        System.Text.StringBuilder val_48 = this.text.Append(value:  val_47);
        // 0x00B36128: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B3612C: CBNZ x20, #0xb36134        | if (this.text != null) goto label_46;   
        if(this.text != null)
        {
            goto label_46;
        }
        // 0x00B36130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_46:
        // 0x00B36134: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
        // 0x00B36138: LDR x8, [x8, #0x170]       | X8 = (string**)(1152921509409721808)(")");
        // 0x00B3613C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36140: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36144: LDR x1, [x8]               | X1 = ")";                               
        val_117 = ")";
        // 0x00B36148: BL #0x1b5b818              | X0 = this.text.Append(value:  val_117 = ")");
        System.Text.StringBuilder val_49 = this.text.Append(value:  val_117);
        label_18:
        // 0x00B3614C: LDRH w8, [x19, #0x1e]      | W8 = this.showFPS; //P2                 
        // 0x00B36150: AND w9, w8, #0xff          | W9 = (this.showFPS & 255);              
        bool val_50 = this.showFPS & 255;
        // 0x00B36154: CBZ w9, #0xb363bc          | if ((this.showFPS & 255) == false) goto label_47;
        if(val_50 == false)
        {
            goto label_47;
        }
        // 0x00B36158: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B3615C: CBNZ x20, #0xb36164        | if (this.text != null) goto label_48;   
        if(this.text != null)
        {
            goto label_48;
        }
        // 0x00B36160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_48:
        // 0x00B36164: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36168: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B3616C: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_51 = this.text.AppendLine();
        // 0x00B36170: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B36174: CBNZ x20, #0xb3617c        | if (this.text != null) goto label_49;   
        if(this.text != null)
        {
            goto label_49;
        }
        // 0x00B36178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        label_49:
        // 0x00B3617C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36180: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36184: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_52 = this.text.AppendLine();
        // 0x00B36188: ADRP x21, #0x35f5000       | X21 = 56578048 (0x35F5000);             
        // 0x00B3618C: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B36190: LDR x21, [x21, #0x828]     | X21 = (string**)(1152921513196948656)("FPS");
        // 0x00B36194: LDR x0, [x21]              | X0 = "FPS";                             
        // 0x00B36198: CBNZ x0, #0xb361a4         | if ("FPS" != null) goto label_50;       
        if("FPS" != null)
        {
            goto label_50;
        }
        // 0x00B3619C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "FPS", ????);      
        // 0x00B361A0: LDR x0, [x21]              | X0 = "FPS";                             
        label_50:
        // 0x00B361A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B361A8: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B361AC: BL #0x18adbb8              | X0 = PadRight(totalWidth:  25);         
        string val_53 = PadRight(totalWidth:  25);
        // 0x00B361B0: MOV x21, x0                | X21 = val_53;//m1                       
        // 0x00B361B4: CBNZ x20, #0xb361bc        | if (this.text != null) goto label_51;   
        if(this.text != null)
        {
            goto label_51;
        }
        // 0x00B361B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_53, ????);     
        label_51:
        // 0x00B361BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B361C0: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B361C4: MOV x1, x21                | X1 = val_53;//m1                        
        // 0x00B361C8: BL #0x1b5b818              | X0 = this.text.Append(value:  val_53);  
        System.Text.StringBuilder val_54 = this.text.Append(value:  val_53);
        // 0x00B361CC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B361D0: LDR s0, [x19, #0x58]       | S0 = this.delayedDeltaTime; //P2        
        // 0x00B361D4: LDR x8, [x8, #0xe90]       | X8 = (string**)(1152921513196891120)("0.0 fps");
        // 0x00B361D8: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B361DC: MOV x20, x0                | X20 = val_54;//m1                       
        // 0x00B361E0: FDIV s0, s1, s0            | S0 = (1f / this.delayedDeltaTime);      
        val_116 = 1f / this.delayedDeltaTime;
        // 0x00B361E4: LDR x1, [x8]               | X1 = "0.0 fps";                         
        // 0x00B361E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B361EC: ADD x0, sp, #0x58          | X0 = (1152921513197503680 + 88) = 1152921513197503768 (0x10000002000B0518);
        // 0x00B361F0: STR s0, [sp, #0x58]        | stack[1152921513197503768] = (1f / this.delayedDeltaTime);  //  dest_result_addr=1152921513197503768
        // 0x00B361F4: BL #0x18a7768              | X0 = (1f / this.delayedDeltaTime).ToString(format:  "0.0 fps");
        string val_55 = val_116.ToString(format:  "0.0 fps");
        // 0x00B361F8: MOV x21, x0                | X21 = val_55;//m1                       
        // 0x00B361FC: CBNZ x20, #0xb36204        | if (val_54 != null) goto label_52;      
        if(val_54 != null)
        {
            goto label_52;
        }
        // 0x00B36200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_52:
        // 0x00B36204: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36208: MOV x0, x20                | X0 = val_54;//m1                        
        // 0x00B3620C: MOV x1, x21                | X1 = val_55;//m1                        
        // 0x00B36210: BL #0x1b5b818              | X0 = val_54.Append(value:  val_55);     
        System.Text.StringBuilder val_56 = val_54.Append(value:  val_55);
        // 0x00B36214: ORR w8, wzr, #0x7f800000   | W8 = 2139095040(0x7F800000);            
        // 0x00B36218: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_118 = 0;
        // 0x00B3621C: STR w8, [sp, #0x54]        | stack[1152921513197503764] = 0x7F800000;  //  dest_result_addr=1152921513197503764
        // 0x00B36220: B #0xb36228                |  goto label_53;                         
        goto label_53;
        label_61:
        // 0x00B36224: ADD w20, w20, #1           | W20 = (val_118 + 1) = val_118 (0x00000001);
        val_118 = 1;
        label_53:
        // 0x00B36228: LDR x21, [x19, #0x88]      | X21 = this.fpsDrops; //P2               
        // 0x00B3622C: CBNZ x21, #0xb36234        | if (this.fpsDrops != null) goto label_54;
        if(this.fpsDrops != null)
        {
            goto label_54;
        }
        // 0x00B36230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_54:
        // 0x00B36234: LDR w8, [x21, #0x18]       | W8 = this.fpsDrops.Length; //P2         
        // 0x00B36238: CMP w20, w8                | STATE = COMPARE(0x1, this.fpsDrops.Length)
        // 0x00B3623C: B.GE #0xb362b0             | if (val_118 >= this.fpsDrops.Length) goto label_55;
        if(val_118 >= this.fpsDrops.Length)
        {
            goto label_55;
        }
        // 0x00B36240: LDR x22, [x19, #0x88]      | X22 = this.fpsDrops; //P2               
        // 0x00B36244: CBNZ x22, #0xb3624c        | if (this.fpsDrops != null) goto label_56;
        if(this.fpsDrops != null)
        {
            goto label_56;
        }
        // 0x00B36248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_56:
        // 0x00B3624C: LDR w8, [x22, #0x18]       | W8 = this.fpsDrops.Length; //P2         
        // 0x00B36250: SXTW x21, w20              | X21 = 1 (0x00000001);                   
        // 0x00B36254: CMP w20, w8                | STATE = COMPARE(0x1, this.fpsDrops.Length)
        // 0x00B36258: B.LO #0xb36268             | if (val_118 < this.fpsDrops.Length) goto label_57;
        if(val_118 < this.fpsDrops.Length)
        {
            goto label_57;
        }
        // 0x00B3625C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_56, ????);     
        // 0x00B36260: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36264: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_56, ????);     
        label_57:
        // 0x00B36268: ADD x8, x22, x21, lsl #2   | X8 = this.fpsDrops[0x1]; //PARR1        
        // 0x00B3626C: LDR s0, [x8, #0x20]        | S0 = this.fpsDrops[0x1][0]              
        float val_121 = this.fpsDrops[1];
        // 0x00B36270: LDR s1, [sp, #0x54]        | S1 = Infinity;                          
        // 0x00B36274: FCMP s0, s1                | STATE = COMPARE(this.fpsDrops[0x1][0], Infinity)
        // 0x00B36278: B.PL #0xb36224             | if (this.fpsDrops[1] >= 0) goto label_61;
        if(val_121 >= 0)
        {
            goto label_61;
        }
        // 0x00B3627C: LDR x22, [x19, #0x88]      | X22 = this.fpsDrops; //P2               
        // 0x00B36280: CBNZ x22, #0xb36288        | if (this.fpsDrops != null) goto label_59;
        if(this.fpsDrops != null)
        {
            goto label_59;
        }
        // 0x00B36284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_59:
        // 0x00B36288: LDR w8, [x22, #0x18]       | W8 = this.fpsDrops.Length; //P2         
        // 0x00B3628C: CMP w20, w8                | STATE = COMPARE(0x1, this.fpsDrops.Length)
        // 0x00B36290: B.LO #0xb362a0             | if (val_118 < this.fpsDrops.Length) goto label_60;
        if(val_118 < this.fpsDrops.Length)
        {
            goto label_60;
        }
        // 0x00B36294: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_56, ????);     
        // 0x00B36298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3629C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_56, ????);     
        label_60:
        // 0x00B362A0: ADD x8, x22, x21, lsl #2   | X8 = this.fpsDrops[0x1]; //PARR1        
        // 0x00B362A4: LDR w8, [x8, #0x20]        | W8 = this.fpsDrops[0x1][0]              
        float val_122 = this.fpsDrops[1];
        // 0x00B362A8: STR w8, [sp, #0x54]        | stack[1152921513197503764] = this.fpsDrops[0x1][0];  //  dest_result_addr=1152921513197503764
        // 0x00B362AC: B #0xb36224                |  goto label_61;                         
        goto label_61;
        label_55:
        // 0x00B362B0: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B362B4: CBNZ x20, #0xb362bc        | if (this.text != null) goto label_62;   
        if(this.text != null)
        {
            goto label_62;
        }
        // 0x00B362B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_62:
        // 0x00B362BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B362C0: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B362C4: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_57 = this.text.AppendLine();
        // 0x00B362C8: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B362CC: LDR x21, [x19, #0x88]      | X21 = this.fpsDrops; //P2               
        // 0x00B362D0: CBNZ x21, #0xb362d8        | if (this.fpsDrops != null) goto label_63;
        if(this.fpsDrops != null)
        {
            goto label_63;
        }
        // 0x00B362D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
        label_63:
        // 0x00B362D8: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B362DC: LDR x8, [x21, #0x18]       | X8 = this.fpsDrops.Length; //P2         
        // 0x00B362E0: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B362E4: ADD x1, sp, #0x30          | X1 = (1152921513197503680 + 48) = 1152921513197503728 (0x10000002000B04F0);
        // 0x00B362E8: STR w8, [sp, #0x30]        | stack[1152921513197503728] = this.fpsDrops.Length;  //  dest_result_addr=1152921513197503728
        // 0x00B362EC: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B362F0: BL #0x27bc028              | X0 = 1152921513198006688 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.fpsDrops.Length);
        // 0x00B362F4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B362F8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B362FC: MOV x21, x0                | X21 = 1152921513198006688 (0x100000020012B1A0);//ML01
        // 0x00B36300: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B36304: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B36308: TBZ w9, #0, #0xb3631c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
        // 0x00B3630C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B36310: CBNZ w9, #0xb3631c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
        // 0x00B36314: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B36318: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_65:
        // 0x00B3631C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B36320: ADRP x9, #0x366a000        | X9 = 57057280 (0x366A000);              
        // 0x00B36324: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921513197128960)("Lowest fps (last ");
        // 0x00B36328: LDR x9, [x9, #0x170]       | X9 = (string**)(1152921509409721808)(")");
        // 0x00B3632C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36330: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B36334: LDR x1, [x8]               | X1 = "Lowest fps (last ";               
        // 0x00B36338: LDR x3, [x9]               | X3 = ")";                               
        // 0x00B3633C: MOV x2, x21                | X2 = 1152921513198006688 (0x100000020012B1A0);//ML01
        // 0x00B36340: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "Lowest fps (last ", arg2:  this.fpsDrops.Length);
        string val_58 = System.String.Concat(arg0:  0, arg1:  "Lowest fps (last ", arg2:  this.fpsDrops.Length);
        // 0x00B36344: MOV x21, x0                | X21 = val_58;//m1                       
        // 0x00B36348: CBNZ x21, #0xb36350        | if (val_58 != null) goto label_66;      
        if(val_58 != null)
        {
            goto label_66;
        }
        // 0x00B3634C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_66:
        // 0x00B36350: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36354: MOVZ w1, #0x19             | W1 = 25 (0x19);//ML01                   
        // 0x00B36358: MOV x0, x21                | X0 = val_58;//m1                        
        // 0x00B3635C: BL #0x18adbb8              | X0 = val_58.PadRight(totalWidth:  25);  
        string val_59 = val_58.PadRight(totalWidth:  25);
        // 0x00B36360: MOV x21, x0                | X21 = val_59;//m1                       
        // 0x00B36364: CBNZ x20, #0xb3636c        | if (this.text != null) goto label_67;   
        if(this.text != null)
        {
            goto label_67;
        }
        // 0x00B36368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
        label_67:
        // 0x00B3636C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36370: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36374: MOV x1, x21                | X1 = val_59;//m1                        
        // 0x00B36378: BL #0x1b5b818              | X0 = this.text.Append(value:  val_59);  
        System.Text.StringBuilder val_60 = this.text.Append(value:  val_59);
        // 0x00B3637C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B36380: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
        // 0x00B36384: MOV x20, x0                | X20 = val_60;//m1                       
        // 0x00B36388: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3638C: ADD x0, sp, #0x54          | X0 = (1152921513197503680 + 84) = 1152921513197503764 (0x10000002000B0514);
        // 0x00B36390: LDR x1, [x8]               | X1 = "0.0";                             
        // 0x00B36394: BL #0x18a7768              | X0 = this.fpsDrops[0x1][0].ToString(format:  "0.0");
        string val_61 = val_122.ToString(format:  "0.0");
        // 0x00B36398: MOV x21, x0                | X21 = val_61;//m1                       
        // 0x00B3639C: CBNZ x20, #0xb363a4        | if (val_60 != null) goto label_68;      
        if(val_60 != null)
        {
            goto label_68;
        }
        // 0x00B363A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        label_68:
        // 0x00B363A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B363A8: MOV x0, x20                | X0 = val_60;//m1                        
        // 0x00B363AC: MOV x1, x21                | X1 = val_61;//m1                        
        // 0x00B363B0: BL #0x1b5b818              | X0 = val_60.Append(value:  val_61);     
        System.Text.StringBuilder val_62 = val_60.Append(value:  val_61);
        // 0x00B363B4: LDRB w8, [x19, #0x1f]      | W8 = this.showPathProfile; //P2         
        val_119 = this.showPathProfile;
        // 0x00B363B8: B #0xb363c0                |  goto label_69;                         
        goto label_69;
        label_47:
        // 0x00B363BC: LSR w8, w8, #8             | W8 = (this.showFPS >> 8);               
        val_119 = this.showFPS >> 8;
        label_69:
        // 0x00B363C0: CBZ w8, #0xb365bc          | if ((this.showFPS >> 8) == false) goto label_92;
        if(val_119 == false)
        {
            goto label_92;
        }
        // 0x00B363C4: LDR x0, [x23]              | X0 = typeof(AstarPath);                 
        val_120 = null;
        // 0x00B363C8: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
        // 0x00B363CC: TBZ w8, #0, #0xb363e0      | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_72;
        // 0x00B363D0: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
        // 0x00B363D4: CBNZ w8, #0xb363e0         | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
        // 0x00B363D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
        // 0x00B363DC: LDR x0, [x23]              | X0 = typeof(AstarPath);                 
        val_120 = null;
        label_72:
        // 0x00B363E0: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
        // 0x00B363E4: LDR x21, [x19, #0x38]      | X21 = this.text; //P2                   
        // 0x00B363E8: LDR x20, [x8, #0x18]       | X20 = AstarPath.active;                 
        // 0x00B363EC: CBNZ x21, #0xb363f4        | if (this.text != null) goto label_73;   
        if(this.text != null)
        {
            goto label_73;
        }
        // 0x00B363F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
        label_73:
        // 0x00B363F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B363F8: MOV x0, x21                | X0 = this.text;//m1                     
        // 0x00B363FC: BL #0x1b5c038              | X0 = this.text.AppendLine();            
        System.Text.StringBuilder val_63 = this.text.AppendLine();
        // 0x00B36400: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B36404: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B36408: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B3640C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B36410: TBZ w8, #0, #0xb36420      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_75;
        // 0x00B36414: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B36418: CBNZ w8, #0xb36420         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_75;
        // 0x00B3641C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_75:
        // 0x00B36420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36424: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36428: MOV x1, x20                | X1 = AstarPath.active;//m1              
        // 0x00B3642C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B36430: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  AstarPath.active);
        bool val_64 = UnityEngine.Object.op_Equality(x:  0, y:  AstarPath.active);
        // 0x00B36434: TBZ w0, #0, #0xb36460      | if (val_64 == false) goto label_76;     
        if(val_64 == false)
        {
            goto label_76;
        }
        // 0x00B36438: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B3643C: CBNZ x20, #0xb36444        | if (this.text != null) goto label_77;   
        if(this.text != null)
        {
            goto label_77;
        }
        // 0x00B36440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_77:
        // 0x00B36444: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00B36448: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921513197161840)("\nNo AstarPath Object In The Scene");
        // 0x00B3644C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36450: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B36454: LDR x1, [x8]               | X1 = "\nNo AstarPath Object In The Scene";
        val_117 = "\nNo AstarPath Object In The Scene";
        // 0x00B36458: BL #0x1b5b818              | X0 = this.text.Append(value:  val_117 = "\nNo AstarPath Object In The Scene");
        System.Text.StringBuilder val_65 = this.text.Append(value:  val_117);
        // 0x00B3645C: B #0xb365bc                |  goto label_92;                         
        goto label_92;
        label_76:
        // 0x00B36460: ADRP x20, #0x35fc000       | X20 = 56606720 (0x35FC000);             
        // 0x00B36464: LDR x20, [x20, #0x720]     | X20 = 1152921504839487488;              
        // 0x00B36468: LDR x0, [x20]              | X0 = typeof(Pathfinding.Util.ListPool<T>);
        // 0x00B3646C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
        // 0x00B36470: TBZ w8, #0, #0xb36480      | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_80;
        // 0x00B36474: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B36478: CBNZ w8, #0xb36480         | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_80;
        // 0x00B3647C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
        label_80:
        // 0x00B36480: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
        // 0x00B36484: LDR x21, [x21, #0xa28]     | X21 = 1152921513197166080;              
        // 0x00B36488: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3648C: LDR x1, [x21]              | X1 = public static System.Int32 Pathfinding.Util.ListPool<UnityEngine.Vector3>::GetSize();
        // 0x00B36490: BL #0x1a020a8              | X0 = Pathfinding.Util.ListPool<UnityEngine.Vector3>.GetSize();
        int val_66 = Pathfinding.Util.ListPool<UnityEngine.Vector3>.GetSize();
        // 0x00B36494: LDR w8, [x19, #0xc4]       | W8 = this.maxVecPool; //P2              
        // 0x00B36498: CMP w0, w8                 | STATE = COMPARE(val_66, this.maxVecPool)
        // 0x00B3649C: B.LE #0xb364c8             | if (val_66 <= this.maxVecPool) goto label_81;
        if(val_66 <= this.maxVecPool)
        {
            goto label_81;
        }
        // 0x00B364A0: LDR x0, [x20]              | X0 = typeof(Pathfinding.Util.ListPool<T>);
        // 0x00B364A4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
        // 0x00B364A8: TBZ w8, #0, #0xb364b8      | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_83;
        // 0x00B364AC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B364B0: CBNZ w8, #0xb364b8         | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
        // 0x00B364B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
        label_83:
        // 0x00B364B8: LDR x1, [x21]              | X1 = public static System.Int32 Pathfinding.Util.ListPool<UnityEngine.Vector3>::GetSize();
        // 0x00B364BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B364C0: BL #0x1a020a8              | X0 = Pathfinding.Util.ListPool<UnityEngine.Vector3>.GetSize();
        int val_67 = Pathfinding.Util.ListPool<UnityEngine.Vector3>.GetSize();
        // 0x00B364C4: STR w0, [x19, #0xc4]       | this.maxVecPool = val_67;                //  dest_result_addr=1152921513197516132
        this.maxVecPool = val_67;
        label_81:
        // 0x00B364C8: ADRP x20, #0x3650000       | X20 = 56950784 (0x3650000);             
        // 0x00B364CC: LDR x20, [x20, #0x788]     | X20 = 1152921504839487488;              
        // 0x00B364D0: LDR x0, [x20]              | X0 = typeof(Pathfinding.Util.ListPool<T>);
        // 0x00B364D4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
        // 0x00B364D8: TBZ w8, #0, #0xb364e8      | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_85;
        // 0x00B364DC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B364E0: CBNZ w8, #0xb364e8         | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_85;
        // 0x00B364E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
        label_85:
        // 0x00B364E8: ADRP x21, #0x3632000       | X21 = 56827904 (0x3632000);             
        // 0x00B364EC: LDR x21, [x21, #0xb70]     | X21 = 1152921513197167104;              
        // 0x00B364F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B364F4: LDR x1, [x21]              | X1 = public static System.Int32 Pathfinding.Util.ListPool<Pathfinding.GraphNode>::GetSize();
        // 0x00B364F8: BL #0x19fd894              | X0 = Pathfinding.Util.ListPool<Pathfinding.GraphNode>.GetSize();
        int val_68 = Pathfinding.Util.ListPool<Pathfinding.GraphNode>.GetSize();
        // 0x00B364FC: LDR w8, [x19, #0xc8]       | W8 = this.maxNodePool; //P2             
        // 0x00B36500: CMP w0, w8                 | STATE = COMPARE(val_68, this.maxNodePool)
        // 0x00B36504: B.LE #0xb36530             | if (val_68 <= this.maxNodePool) goto label_86;
        if(val_68 <= this.maxNodePool)
        {
            goto label_86;
        }
        // 0x00B36508: LDR x0, [x20]              | X0 = typeof(Pathfinding.Util.ListPool<T>);
        // 0x00B3650C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
        // 0x00B36510: TBZ w8, #0, #0xb36520      | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_88;
        // 0x00B36514: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
        // 0x00B36518: CBNZ w8, #0xb36520         | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_88;
        // 0x00B3651C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
        label_88:
        // 0x00B36520: LDR x1, [x21]              | X1 = public static System.Int32 Pathfinding.Util.ListPool<Pathfinding.GraphNode>::GetSize();
        // 0x00B36524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36528: BL #0x19fd894              | X0 = Pathfinding.Util.ListPool<Pathfinding.GraphNode>.GetSize();
        int val_69 = Pathfinding.Util.ListPool<Pathfinding.GraphNode>.GetSize();
        // 0x00B3652C: STR w0, [x19, #0xc8]       | this.maxNodePool = val_69;               //  dest_result_addr=1152921513197516136
        this.maxNodePool = val_69;
        label_86:
        // 0x00B36530: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B36534: CBNZ x20, #0xb3653c        | if (this.text != null) goto label_89;   
        if(this.text != null)
        {
            goto label_89;
        }
        // 0x00B36538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_89:
        // 0x00B3653C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B36540: LDR x8, [x8, #0x970]       | X8 = (string**)(1152921513197172224)("\nPool Sizes (size/total created)");
        // 0x00B36544: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36548: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B3654C: LDR x1, [x8]               | X1 = "\nPool Sizes (size/total created)";
        val_117 = "\nPool Sizes (size/total created)";
        // 0x00B36550: BL #0x1b5b818              | X0 = this.text.Append(value:  val_117 = "\nPool Sizes (size/total created)");
        System.Text.StringBuilder val_70 = this.text.Append(value:  val_117);
        // 0x00B36554: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_121 = 0;
        // 0x00B36558: ORR w22, wzr, #0x18        | W22 = 24(0x18);                         
        // 0x00B3655C: B #0xb36574                |  goto label_90;                         
        goto label_90;
        label_95:
        // 0x00B36560: MADD x8, x24, x22, x23     | X8 = (X24 * 24) + 1152921504837996544;  
        var val_71 = 1152921504837996544 + (X24 * 24);
        // 0x00B36564: ADD x0, x8, #0x20          | X0 = ((X24 * 24) + 1152921504837996544 + 32);
        var val_72 = val_71 + 32;
        // 0x00B36568: MOV x1, x20                | X1 = this.text;//m1                     
        val_117 = this.text;
        // 0x00B3656C: BL #0xb36db0               | X0 = sub_B36DB0( ?? ((X24 * 24) + 1152921504837996544 + 32), ????);
        // 0x00B36570: ADD w21, w21, #1           | W21 = (val_121 + 1) = val_121 (0x00000001);
        val_121 = 1;
        label_90:
        // 0x00B36574: LDR x20, [x19, #0xd0]      | X20 = this.debugTypes; //P2             
        // 0x00B36578: CBNZ x20, #0xb36580        | if (this.debugTypes != null) goto label_91;
        if(this.debugTypes != null)
        {
            goto label_91;
        }
        // 0x00B3657C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ((X24 * 24) + 1152921504837996544 + 32), ????);
        label_91:
        // 0x00B36580: LDR w8, [x20, #0x18]       | W8 = this.debugTypes.Length; //P2       
        // 0x00B36584: CMP w21, w8                | STATE = COMPARE(0x1, this.debugTypes.Length)
        // 0x00B36588: B.GE #0xb365bc             | if (val_121 >= this.debugTypes.Length) goto label_92;
        if(val_121 >= this.debugTypes.Length)
        {
            goto label_92;
        }
        // 0x00B3658C: LDR x23, [x19, #0xd0]      | X23 = this.debugTypes; //P2             
        // 0x00B36590: CBNZ x23, #0xb36598        | if (this.debugTypes != null) goto label_93;
        if(this.debugTypes != null)
        {
            goto label_93;
        }
        // 0x00B36594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ((X24 * 24) + 1152921504837996544 + 32), ????);
        label_93:
        // 0x00B36598: LDR w8, [x23, #0x18]       | W8 = this.debugTypes.Length; //P2       
        // 0x00B3659C: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B365A0: SXTW x24, w21              | X24 = 1 (0x00000001);                   
        // 0x00B365A4: CMP w21, w8                | STATE = COMPARE(0x1, this.debugTypes.Length)
        // 0x00B365A8: B.LO #0xb36560             | if (val_121 < this.debugTypes.Length) goto label_95;
        if(val_121 < this.debugTypes.Length)
        {
            goto label_95;
        }
        // 0x00B365AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((X24 * 24) + 1152921504837996544 + 32), ????);
        // 0x00B365B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B365B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((X24 * 24) + 1152921504837996544 + 32), ????);
        // 0x00B365B8: B #0xb36560                |  goto label_95;                         
        goto label_95;
        label_92:
        // 0x00B365BC: LDR x20, [x19, #0x38]      | X20 = this.text; //P2                   
        // 0x00B365C0: CBNZ x20, #0xb365c8        | if (this.text != null) goto label_96;   
        if(this.text != null)
        {
            goto label_96;
        }
        // 0x00B365C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_96:
        // 0x00B365C8: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
        // 0x00B365CC: MOV x0, x20                | X0 = this.text;//m1                     
        // 0x00B365D0: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00B365D4: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
        // 0x00B365D8: STR x0, [x19, #0x40]       | this.cachedText = this.text;             //  dest_result_addr=1152921513197516000
        this.cachedText = this.text;
        label_10:
        // 0x00B365DC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B365E0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B365E4: LDR x20, [x19, #0x28]      | X20 = this.font; //P2                   
        // 0x00B365E8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B365EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B365F0: TBZ w8, #0, #0xb36600      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_98;
        // 0x00B365F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B365F8: CBNZ w8, #0xb36600         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_98;
        // 0x00B365FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_98:
        // 0x00B36600: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36604: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36608: MOV x1, x20                | X1 = this.font;//m1                     
        // 0x00B3660C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B36610: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.font);
        bool val_73 = UnityEngine.Object.op_Inequality(x:  0, y:  this.font);
        // 0x00B36614: TBZ w0, #0, #0xb36658      | if (val_73 == false) goto label_99;     
        if(val_73 == false)
        {
            goto label_99;
        }
        // 0x00B36618: LDR x20, [x19, #0xa0]      | X20 = this.style; //P2                  
        // 0x00B3661C: LDR x21, [x19, #0x28]      | X21 = this.font; //P2                   
        // 0x00B36620: CBNZ x20, #0xb36628        | if (this.style != null) goto label_100; 
        if(this.style != null)
        {
            goto label_100;
        }
        // 0x00B36624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
        label_100:
        // 0x00B36628: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3662C: MOV x0, x20                | X0 = this.style;//m1                    
        // 0x00B36630: MOV x1, x21                | X1 = this.font;//m1                     
        // 0x00B36634: BL #0x21462a0              | this.style.set_font(value:  this.font); 
        this.style.font = this.font;
        // 0x00B36638: LDR x20, [x19, #0xa0]      | X20 = this.style; //P2                  
        // 0x00B3663C: LDR w21, [x19, #0x30]      | W21 = this.fontSize; //P2               
        // 0x00B36640: CBNZ x20, #0xb36648        | if (this.style != null) goto label_101; 
        if(this.style != null)
        {
            goto label_101;
        }
        // 0x00B36644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.style, ????); 
        label_101:
        // 0x00B36648: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3664C: MOV x0, x20                | X0 = this.style;//m1                    
        // 0x00B36650: MOV w1, w21                | W1 = this.fontSize;//m1                 
        // 0x00B36654: BL #0x21450b4              | this.style.set_fontSize(value:  this.fontSize);
        this.style.fontSize = this.fontSize;
        label_99:
        // 0x00B36658: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00B3665C: LDR x21, [x19, #0xa0]      | X21 = this.style; //P2                  
        // 0x00B36660: LDR x23, [x19, #0x40]      | X23 = this.cachedText; //P2             
        val_122 = this.cachedText;
        // 0x00B36664: LDR x8, [x8, #0x120]       | X8 = 1152921504726601728;               
        // 0x00B36668: ADD x20, x19, #0x90        | X20 = this.boxRect;//AP2 res_addr=1152921513197516080
        // 0x00B3666C: LDR x0, [x8]               | X0 = typeof(UnityEngine.GUIContent);    
        UnityEngine.GUIContent val_74 = null;
        // 0x00B36670: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.GUIContent), ????);
        // 0x00B36674: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36678: MOV x1, x23                | X1 = this.cachedText;//m1               
        // 0x00B3667C: MOV x22, x0                | X22 = 1152921504726601728 (0x1000000007235000);//ML01
        // 0x00B36680: BL #0x2134ef0              | .ctor(text:  val_122);                  
        val_74 = new UnityEngine.GUIContent(text:  val_122);
        // 0x00B36684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36688: MOV x0, x20                | X0 = this.boxRect;//m1                  
        // 0x00B3668C: BL #0x1b819b4              | X0 = label_UnityEngine_Rect_set_max_GL01B819B4();
        // 0x00B36690: MOV v8.16b, v0.16b         | V8 = (1f / this.lastDeltaTime);//m1     
        // 0x00B36694: CBNZ x21, #0xb3669c        | if (this.style != null) goto label_102; 
        if(this.style != null)
        {
            goto label_102;
        }
        // 0x00B36698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.boxRect, ????);
        label_102:
        // 0x00B3669C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B366A0: MOV x0, x21                | X0 = this.style;//m1                    
        // 0x00B366A4: MOV x1, x22                | X1 = 1152921504726601728 (0x1000000007235000);//ML01
        // 0x00B366A8: MOV v0.16b, v8.16b         | V0 = (1f / this.lastDeltaTime);//m1     
        // 0x00B366AC: BL #0x21471d0              | X0 = this.style.CalcHeight(content:  val_74, width:  val_116);
        float val_75 = this.style.CalcHeight(content:  val_74, width:  val_116);
        // 0x00B366B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B366B4: MOV x0, x20                | X0 = this.boxRect;//m1                  
        // 0x00B366B8: BL #0x1b819e4              | X0 = label_UnityEngine_Rect_get_height_GL01B819E4();
        // 0x00B366BC: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00B366C0: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00B366C4: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_124 = null;
        // 0x00B366C8: LDP s11, s10, [x19, #0x90] | S11 = this.boxRect; //P2                 //  | 
        // 0x00B366CC: LDP s9, s8, [x19, #0x98]   |                                          //  | 
        // 0x00B366D0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B366D4: TBZ w8, #0, #0xb366e8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_104;
        // 0x00B366D8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B366DC: CBNZ w8, #0xb366e8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_104;
        // 0x00B366E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B366E4: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_124 = null;
        label_104:
        // 0x00B366E8: ADRP x21, #0x366b000       | X21 = 57061376 (0x366B000);             
        // 0x00B366EC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B366F0: LDR x21, [x21, #0x450]     | X21 = 1152921504725856256;              
        val_127 = 1152921504725856256;
        // 0x00B366F4: LDR x20, [x8]              | X20 = System.String.Empty;              
        // 0x00B366F8: LDR x0, [x21]              | X0 = typeof(UnityEngine.GUI);           
        // 0x00B366FC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.GUI.__il2cppRuntimeField_10A;
        // 0x00B36700: TBZ w8, #0, #0xb36710      | if (UnityEngine.GUI.__il2cppRuntimeField_has_cctor == 0) goto label_106;
        // 0x00B36704: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.GUI.__il2cppRuntimeField_cctor_finished;
        // 0x00B36708: CBNZ w8, #0xb36710         | if (UnityEngine.GUI.__il2cppRuntimeField_cctor_finished != 0) goto label_106;
        // 0x00B3670C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.GUI), ????);
        label_106:
        // 0x00B36710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36714: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36718: MOV v0.16b, v11.16b        | V0 = this.boxRect;//m1                  
        // 0x00B3671C: MOV v1.16b, v10.16b        | V1 = val_5.b;//m1                       
        // 0x00B36720: MOV v2.16b, v9.16b         | V2 = val_5.g;//m1                       
        // 0x00B36724: MOV v3.16b, v8.16b         | V3 = (1f / this.lastDeltaTime);//m1     
        // 0x00B36728: MOV x1, x20                | X1 = System.String.Empty;//m1           
        // 0x00B3672C: BL #0x2127fc4              | UnityEngine.GUI.Box(position:  new UnityEngine.Rect() {m_XMin = this.boxRect, m_YMin = val_5.b, m_Width = val_5.g, m_Height = val_116}, text:  0);
        UnityEngine.GUI.Box(position:  new UnityEngine.Rect() {m_XMin = this.boxRect, m_YMin = val_5.b, m_Width = val_5.g, m_Height = val_116}, text:  0);
        // 0x00B36730: LDP s0, s1, [x19, #0x90]   | S0 = this.boxRect; //P2                  //  | 
        val_128 = this.boxRect;
        // 0x00B36734: LDP s2, s3, [x19, #0x98]   |                                          //  | 
        // 0x00B36738: LDR x1, [x19, #0x40]       | X1 = this.cachedText; //P2              
        // 0x00B3673C: LDR x2, [x19, #0xa0]       | X2 = this.style; //P2                   
        // 0x00B36740: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36744: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B36748: BL #0x2126f98              | UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = val_128, m_YMin = val_5.b, m_Width = val_5.g, m_Height = val_116}, text:  0, style:  this.cachedText);
        UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = val_128, m_YMin = val_5.b, m_Width = val_5.g, m_Height = val_116}, text:  0, style:  this.cachedText);
        // 0x00B3674C: LDRB w8, [x19, #0x21]      | W8 = this.showGraph; //P2               
        // 0x00B36750: CBZ w8, #0xb36d18          | if (this.showGraph == false) goto label_107;
        if(this.showGraph == false)
        {
            goto label_107;
        }
        // 0x00B36754: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B36758: LDR s8, [x8, #0x930]       | S8 = Infinity;                          
        val_126 = Infinityf;
        // 0x00B3675C: ADRP x20, #0x363f000       | X20 = 56881152 (0x363F000);             
        // 0x00B36760: LDR x20, [x20, #0x3b0]     | X20 = 1152921504695345152;              
        // 0x00B36764: FMOV s9, wzr               | S9 = 0f;                                
        val_130 = 0f;
        // 0x00B36768: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_131 = 0;
        // 0x00B3676C: ORR w23, wzr, #0xc         | W23 = 12(0xC);                          
        val_122 = 12;
        // 0x00B36770: MOV v10.16b, v9.16b        | V10 = 0;//m1                            
        // 0x00B36774: MOV v12.16b, v8.16b        | V12 = 2139095040 (0x7F800000);//ML01    
        // 0x00B36778: B #0xb3679c                |  goto label_108;                        
        goto label_108;
        label_121:
        // 0x00B3677C: MADD x8, x24, x23, x25     | X8 = (X24 * val_122) + X25;             
        var val_76 = X25 + (X24 * val_122);
        // 0x00B36780: LDR s0, [x8, #0x20]        | S0 = (X24 * val_122) + X25 + 32;        
        val_128 = mem[(X24 * val_122) + X25 + 32];
        val_128 = (X24 * val_122) + X25 + 32;
        // 0x00B36784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3678C: MOV v1.16b, v9.16b         | V1 = 0;//m1                             
        val_129 = val_130;
        // 0x00B36790: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  val_128 = (X24 * val_122) + X25 + 32, b:  val_129 = val_130);
        float val_77 = UnityEngine.Mathf.Max(a:  val_128, b:  val_129);
        // 0x00B36794: MOV v9.16b, v0.16b         | V9 = val_77;//m1                        
        val_130 = val_77;
        // 0x00B36798: ADD w22, w22, #1           | W22 = (val_131 + 1) = val_131 (0x00000001);
        val_131 = 1;
        label_108:
        // 0x00B3679C: LDR x24, [x19, #0x50]      | X24 = this.graph; //P2                  
        // 0x00B367A0: CBNZ x24, #0xb367a8        | if (this.graph != null) goto label_109; 
        if(this.graph != null)
        {
            goto label_109;
        }
        // 0x00B367A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_109:
        // 0x00B367A8: LDR w8, [x24, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B367AC: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B367B0: B.GE #0xb368c0             | if (val_131 >= this.graph.Length) goto label_110;
        if(val_131 >= this.graph.Length)
        {
            goto label_110;
        }
        // 0x00B367B4: LDR x25, [x19, #0x50]      | X25 = this.graph; //P2                  
        // 0x00B367B8: CBNZ x25, #0xb367c0        | if (this.graph != null) goto label_111; 
        if(this.graph != null)
        {
            goto label_111;
        }
        // 0x00B367BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_111:
        // 0x00B367C0: LDR w8, [x25, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B367C4: SXTW x24, w22              | X24 = 1 (0x00000001);                   
        // 0x00B367C8: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B367CC: B.LO #0xb367dc             | if (val_131 < this.graph.Length) goto label_112;
        if(val_131 < this.graph.Length)
        {
            goto label_112;
        }
        // 0x00B367D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B367D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B367D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_112:
        // 0x00B367DC: LDR x0, [x20]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B367E0: NOP                        | 
        // 0x00B367E4: MADD x8, x24, x23, x25     | X8 = (1 * val_122) + this.graph;        
        var val_78 = this.graph + (1 * val_122);
        // 0x00B367E8: LDR s11, [x8, #0x24]       | S11 = (1 * val_122) + this.graph + 36;  
        // 0x00B367EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B367F0: TBZ w8, #0, #0xb36800      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_114;
        // 0x00B367F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B367F8: CBNZ w8, #0xb36800         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_114;
        // 0x00B367FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_114:
        // 0x00B36800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36808: MOV v0.16b, v11.16b        | V0 = (1 * val_122) + this.graph + 36;//m1
        // 0x00B3680C: MOV v1.16b, v12.16b        | V1 = 2139095040 (0x7F800000);//ML01     
        // 0x00B36810: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  (1 * val_122) + this.graph + 36, b:  val_126 = Infinityf);
        float val_79 = UnityEngine.Mathf.Min(a:  (1 * val_122) + this.graph + 36, b:  val_126);
        // 0x00B36814: LDR x25, [x19, #0x50]      | X25 = this.graph; //P2                  
        // 0x00B36818: MOV v12.16b, v0.16b        | V12 = val_79;//m1                       
        // 0x00B3681C: CBNZ x25, #0xb36824        | if (this.graph != null) goto label_115; 
        if(this.graph != null)
        {
            goto label_115;
        }
        // 0x00B36820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_115:
        // 0x00B36824: LDR w8, [x25, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B36828: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B3682C: B.LO #0xb3683c             | if (val_131 < this.graph.Length) goto label_116;
        if(val_131 < this.graph.Length)
        {
            goto label_116;
        }
        // 0x00B36830: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B36834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36838: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_116:
        // 0x00B3683C: MADD x8, x24, x23, x25     | X8 = (1 * val_122) + this.graph;        
        var val_80 = this.graph + (1 * val_122);
        // 0x00B36840: LDR s0, [x8, #0x24]        | S0 = (1 * val_122) + this.graph + 36;   
        // 0x00B36844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3684C: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B36850: BL #0x1a7d940              | X0 = UnityEngine.Mathf.Max(a:  (1 * val_122) + this.graph + 36, b:  val_130);
        float val_81 = UnityEngine.Mathf.Max(a:  (1 * val_122) + this.graph + 36, b:  val_130);
        // 0x00B36854: LDR x25, [x19, #0x50]      | X25 = this.graph; //P2                  
        // 0x00B36858: MOV v10.16b, v0.16b        | V10 = val_81;//m1                       
        // 0x00B3685C: CBNZ x25, #0xb36864        | if (this.graph != null) goto label_117; 
        if(this.graph != null)
        {
            goto label_117;
        }
        // 0x00B36860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_117:
        // 0x00B36864: LDR w8, [x25, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B36868: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B3686C: B.LO #0xb3687c             | if (val_131 < this.graph.Length) goto label_118;
        if(val_131 < this.graph.Length)
        {
            goto label_118;
        }
        // 0x00B36870: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B36874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36878: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_118:
        // 0x00B3687C: MADD x8, x24, x23, x25     | X8 = (1 * val_122) + this.graph;        
        var val_82 = this.graph + (1 * val_122);
        // 0x00B36880: LDR s0, [x8, #0x20]        | S0 = (1 * val_122) + this.graph + 32;   
        // 0x00B36884: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3688C: MOV v1.16b, v8.16b         | V1 = 2139095040 (0x7F800000);//ML01     
        // 0x00B36890: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  (1 * val_122) + this.graph + 32, b:  val_126);
        float val_83 = UnityEngine.Mathf.Min(a:  (1 * val_122) + this.graph + 32, b:  val_126);
        // 0x00B36894: LDR x25, [x19, #0x50]      | X25 = this.graph; //P2                  
        // 0x00B36898: MOV v8.16b, v0.16b         | V8 = val_83;//m1                        
        // 0x00B3689C: CBNZ x25, #0xb368a4        | if (this.graph != null) goto label_119; 
        if(this.graph != null)
        {
            goto label_119;
        }
        // 0x00B368A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_119:
        // 0x00B368A4: LDR w8, [x25, #0x18]       | W8 = this.graph.Length; //P2            
        // 0x00B368A8: CMP w22, w8                | STATE = COMPARE(0x1, this.graph.Length) 
        // 0x00B368AC: B.LO #0xb3677c             | if (val_131 < this.graph.Length) goto label_121;
        if(val_131 < this.graph.Length)
        {
            goto label_121;
        }
        // 0x00B368B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B368B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B368B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x00B368BC: B #0xb3677c                |  goto label_121;                        
        goto label_121;
        label_110:
        // 0x00B368C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B368C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B368C8: BL #0x20d3bd0              | X0 = UnityEngine.Color.get_blue();      
        UnityEngine.Color val_84 = UnityEngine.Color.blue;
        // 0x00B368CC: LDR x0, [x21]              | X0 = typeof(UnityEngine.GUI);           
        // 0x00B368D0: MOV v11.16b, v0.16b        | V11 = val_84.r;//m1                     
        // 0x00B368D4: MOV v13.16b, v1.16b        | V13 = val_84.g;//m1                     
        // 0x00B368D8: MOV v15.16b, v2.16b        | V15 = val_84.b;//m1                     
        // 0x00B368DC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.GUI.__il2cppRuntimeField_10A;
        // 0x00B368E0: MOV v14.16b, v3.16b        | V14 = val_84.a;//m1                     
        // 0x00B368E4: TBZ w8, #0, #0xb368f4      | if (UnityEngine.GUI.__il2cppRuntimeField_has_cctor == 0) goto label_123;
        // 0x00B368E8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.GUI.__il2cppRuntimeField_cctor_finished;
        // 0x00B368EC: CBNZ w8, #0xb368f4         | if (UnityEngine.GUI.__il2cppRuntimeField_cctor_finished != 0) goto label_123;
        // 0x00B368F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.GUI), ????);
        label_123:
        // 0x00B368F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B368F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B368FC: MOV v0.16b, v11.16b        | V0 = val_84.r;//m1                      
        // 0x00B36900: MOV v1.16b, v13.16b        | V1 = val_84.g;//m1                      
        // 0x00B36904: MOV v2.16b, v15.16b        | V2 = val_84.b;//m1                      
        // 0x00B36908: MOV v3.16b, v14.16b        | V3 = val_84.a;//m1                      
        // 0x00B3690C: BL #0x2125198              | UnityEngine.GUI.set_color(value:  new UnityEngine.Color() {r = val_84.r, g = val_84.g, b = val_84.b, a = val_84.a});
        UnityEngine.GUI.color = new UnityEngine.Color() {r = val_84.r, g = val_84.g, b = val_84.b, a = val_84.a};
        // 0x00B36910: LDR x0, [x20]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B36914: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B36918: TBZ w8, #0, #0xb36928      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_125;
        // 0x00B3691C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B36920: CBNZ w8, #0xb36928         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_125;
        // 0x00B36924: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_125:
        // 0x00B36928: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B3692C: LDR s13, [x8, #0x92c]      | S13 = 100000;                           
        float val_125 = 100000f;
        // 0x00B36930: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36938: FDIV s0, s10, s13          | S0 = (val_130 / 100000f);               
        float val_85 = val_130 / val_125;
        // 0x00B3693C: BL #0x1a7dc20              | X0 = UnityEngine.Mathf.RoundToInt(f:  float val_85 = val_130 / 100000f);
        int val_86 = UnityEngine.Mathf.RoundToInt(f:  val_85);
        // 0x00B36940: SCVTF s15, w0              | S15 = (float)(val_86);                  
        // 0x00B36944: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36948: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3694C: STR s15, [sp, #0x50]       | stack[1152921513197503760] = val_86;     //  dest_result_addr=1152921513197503760
        // 0x00B36950: BL #0x1b8b83c              | X0 = UnityEngine.Screen.get_height();   
        int val_87 = UnityEngine.Screen.height;
        // 0x00B36954: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B36958: LDP s0, s2, [x19, #0xbc]   | S0 = this.graphHeight; //P2  S2 = this.graphOffset; //P2  //  | 
        // 0x00B3695C: LDR s14, [x8, #0x944]      | S14 = 1000;                             
        // 0x00B36960: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B36964: LDR s11, [x8, #0x4b0]      | S11 = 100;                              
        // 0x00B36968: FADD s3, s2, s0            | S3 = (this.graphOffset + this.graphHeight);
        float val_88 = this.graphOffset + this.graphHeight;
        // 0x00B3696C: FMUL s0, s15, s14          | S0 = (val_86 * 1000f);                  
        float val_89 = (float)val_86 * 1000f;
        // 0x00B36970: MOV w20, w0                | W20 = val_87;//m1                       
        // 0x00B36974: FMUL s4, s0, s11           | S4 = ((val_86 * 1000f) * 100f);         
        float val_90 = val_89 * 100f;
        // 0x00B36978: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3697C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36980: MOV v0.16b, v12.16b        | V0 = 2139095040 (0x7F800000);//ML01     
        // 0x00B36984: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B36988: BL #0x16845ac              | X0 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  float val_88 = this.graphOffset + this.graphHeight, value:  float val_90 = val_89 * 100f);
        float val_91 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  val_88, value:  val_90);
        // 0x00B3698C: SCVTF s1, w20              | S1 = (float)(val_87);                   
        // 0x00B36990: FSUB s0, s1, s0            | S0 = (val_87 - val_91);                 
        val_91 = (float)val_87 - val_91;
        // 0x00B36994: FMOV s1, #-10.00000000     | S1 = -10;                               
        float val_123 = -10f;
        // 0x00B36998: FADD s1, s0, s1            | S1 = ((val_87 - val_91) + -10f);        
        val_123 = val_91 + val_123;
        // 0x00B3699C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B369A0: FMOV s0, #5.00000000       | S0 = 5;                                 
        // 0x00B369A4: FMOV s3, #20.00000000      | S3 = 20;                                
        // 0x00B369A8: ADD x0, sp, #0x30          | X0 = (1152921513197503680 + 48) = 1152921513197503728 (0x10000002000B04F0);
        // 0x00B369AC: MOV v2.16b, v11.16b        | V2 = 100;//m1                           
        // 0x00B369B0: STP xzr, xzr, [sp, #0x30]  | stack[1152921513197503728] = 0x0;  stack[1152921513197503736] = 0x0;  //  dest_result_addr=1152921513197503728 |  dest_result_addr=1152921513197503736
        // 0x00B369B4: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
        // 0x00B369B8: ADRP x21, #0x3680000       | X21 = 57147392 (0x3680000);             
        // 0x00B369BC: LDR x21, [x21, #0xf60]     | X21 = (string**)(1152921513196742880)("0.0 MB");
        val_127 = "0.0 MB";
        // 0x00B369C0: FMOV s0, #10.00000000      | S0 = 10;                                
        float val_124 = 10f;
        // 0x00B369C4: FDIV s0, s15, s0           | S0 = (val_86 / 10f);                    
        val_124 = (float)val_86 / val_124;
        // 0x00B369C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B369CC: LDR x1, [x21]              | X1 = "0.0 MB";                          
        // 0x00B369D0: ADD x0, sp, #0x4c          | X0 = (1152921513197503680 + 76) = 1152921513197503756 (0x10000002000B050C);
        // 0x00B369D4: STR s0, [sp, #0x4c]        | stack[1152921513197503756] = (val_86 / 10f);  //  dest_result_addr=1152921513197503756
        // 0x00B369D8: BL #0x18a7768              | X0 = (val_86 / 10f).ToString(format:  "0.0 MB");
        string val_92 = val_124.ToString(format:  "0.0 MB");
        // 0x00B369DC: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B369E0: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x00B369E4: MOV x1, x0                 | X1 = val_92;//m1                        
        // 0x00B369E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B369EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B369F0: BL #0x2126ab0              | UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        // 0x00B369F4: FDIV s13, s12, s13         | S13 = (val_126 / 100000f);              
        val_125 = val_126 / val_125;
        // 0x00B369F8: FCVT d0, s13               | D0 = (double)(val_126 / 100000f));      
        // 0x00B369FC: ADD x0, sp, #0x20          | X0 = (1152921513197503680 + 32) = 1152921513197503712 (0x10000002000B04E0);
        // 0x00B36A00: BL #0x980330               | X0 = sub_980330( ?? 0x10000002000B04E0, ????);
        // 0x00B36A04: FCMP s13, #0.0             | STATE = COMPARE((val_126 / 100000f), 0) 
        // 0x00B36A08: B.GE #0xb36a28             | if (100000f >= 0) goto label_126;       
        if(val_125 >= 0f)
        {
            goto label_126;
        }
        // 0x00B36A0C: FMOV d1, #-0.50000000      | D1 = -0.5;                              
        // 0x00B36A10: FMOV s15, #0.50000000      | S15 = 0.5;                              
        val_132 = 0.5f;
        // 0x00B36A14: FCMP d0, d1                | STATE = COMPARE((val_126 / 100000f), -0.5)
        // 0x00B36A18: B.NE #0xb36a58             | if ((double)100000f = val_126 / 100000f != -0.5) goto label_127;
        if((double)val_125 != (-0.5))
        {
            goto label_127;
        }
        // 0x00B36A1C: LDR d0, [sp, #0x20]        | D0 = val_93;                             //  find_add[1152921513197491936]
        val_133 = val_93;
        // 0x00B36A20: FMOV s1, #-1.00000000      | S1 = -1;                                
        val_134 = -1f;
        // 0x00B36A24: B #0xb36a40                |  goto label_128;                        
        goto label_128;
        label_126:
        // 0x00B36A28: FMOV d1, #0.50000000       | D1 = 0.5;                               
        // 0x00B36A2C: FMOV s15, #0.50000000      | S15 = 0.5;                              
        val_132 = 0.5f;
        // 0x00B36A30: FCMP d0, d1                | STATE = COMPARE((val_126 / 100000f), 0.5)
        // 0x00B36A34: B.NE #0xb36a68             | if ((double)100000f != 0.5) goto label_129;
        if((double)val_125 != 0.5)
        {
            goto label_129;
        }
        // 0x00B36A38: LDR d0, [sp, #0x20]        | D0 = val_93;                             //  find_add[1152921513197491936]
        val_133 = val_93;
        // 0x00B36A3C: FMOV s1, #1.00000000       | S1 = 1;                                 
        val_134 = 1f;
        label_128:
        // 0x00B36A40: FCVTZS x8, d0              | X8 = (long)(val_93);                    
        // 0x00B36A44: FCVT s0, d0                | S0 = (float)val_93);                    
        // 0x00B36A48: FADD s1, s0, s1            | S1 = (val_93 + val_134);                
        val_134 = (float)val_133 + val_134;
        // 0x00B36A4C: TST x8, #1                 | STATE = COMPARE(val_93, 0x1)            
        // 0x00B36A50: FCSEL s13, s0, s1, eq      | S13 = ((long)val_133 & 0x1)!=0 ? val_93 : (val_93 + val_134);
        var val_94 = (((long)val_133 & 1) != 0) ? ((float)val_133) : (val_134);
        // 0x00B36A54: B #0xb36a70                |  goto label_131;                        
        goto label_131;
        label_127:
        // 0x00B36A58: FMOV s0, #-0.50000000      | S0 = -0.5;                              
        float val_126 = -0.5f;
        // 0x00B36A5C: FADD s0, s13, s0           | S0 = ((val_126 / 100000f) + -0.5f);     
        val_126 = val_125 + val_126;
        // 0x00B36A60: FRINTP s13, s0             | 
        // 0x00B36A64: B #0xb36a70                |  goto label_131;                        
        goto label_131;
        label_129:
        // 0x00B36A68: FADD s0, s13, s15          | S0 = ((val_126 / 100000f) + val_132);   
        float val_95 = val_125 + val_132;
        // 0x00B36A6C: FRINTM s13, s0             | 
        label_131:
        // 0x00B36A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36A74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36A78: STR s13, [sp, #0x50]       | stack[1152921513197503760] = (val_126 / 100000f);  //  dest_result_addr=1152921513197503760
        // 0x00B36A7C: BL #0x1b8b83c              | X0 = UnityEngine.Screen.get_height();   
        int val_96 = UnityEngine.Screen.height;
        // 0x00B36A80: LDP s0, s2, [x19, #0xbc]   | S0 = this.graphHeight; //P2  S2 = this.graphOffset; //P2  //  | 
        // 0x00B36A84: FMUL s1, s13, s14          | S1 = ((val_126 / 100000f) * 1000f);     
        float val_97 = val_125 * 1000f;
        // 0x00B36A88: MOV w20, w0                | W20 = val_96;//m1                       
        // 0x00B36A8C: FMUL s4, s1, s11           | S4 = (((val_126 / 100000f) * 1000f) * 100f);
        float val_98 = val_97 * 100f;
        // 0x00B36A90: FADD s3, s2, s0            | S3 = (this.graphOffset + this.graphHeight);
        float val_99 = this.graphOffset + this.graphHeight;
        // 0x00B36A94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36A98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36A9C: MOV v0.16b, v12.16b        | V0 = Infinity;//m1                      
        // 0x00B36AA0: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B36AA4: BL #0x16845ac              | X0 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  float val_99 = this.graphOffset + this.graphHeight, value:  float val_98 = val_97 * 100f);
        float val_100 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  val_99, value:  val_98);
        // 0x00B36AA8: SCVTF s1, w20              | S1 = (float)(val_96);                   
        float val_127 = (float)val_96;
        // 0x00B36AAC: FSUB s0, s1, s0            | S0 = (val_96 - val_100);                
        val_100 = val_127 - val_100;
        // 0x00B36AB0: FMOV s12, #-10.00000000    | S12 = -10;                              
        // 0x00B36AB4: FADD s1, s0, s12           | S1 = ((val_96 - val_100) + -10f);       
        val_127 = val_100 + (-10f);
        // 0x00B36AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36ABC: FMOV s0, #5.00000000       | S0 = 5;                                 
        // 0x00B36AC0: FMOV s3, #20.00000000      | S3 = 20;                                
        // 0x00B36AC4: ADD x0, sp, #0x20          | X0 = (1152921513197503680 + 32) = 1152921513197503712 (0x10000002000B04E0);
        // 0x00B36AC8: MOV v2.16b, v11.16b        | V2 = 100;//m1                           
        // 0x00B36ACC: STP xzr, xzr, [sp, #0x20]  | val_93 = 0x0;  stack[1152921513197503720] = 0x0;  //  dest_result_addr=1152921513197503712 |  dest_result_addr=1152921513197503720
        val_93 = 0;
        // 0x00B36AD0: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
        // 0x00B36AD4: LDR x1, [x21]              | X1 = "0.0 MB";                          
        // 0x00B36AD8: FMOV s0, #10.00000000      | S0 = 10;                                
        float val_128 = 10f;
        // 0x00B36ADC: FDIV s0, s13, s0           | S0 = ((val_126 / 100000f) / 10f);       
        val_128 = val_125 / val_128;
        // 0x00B36AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36AE4: ADD x0, sp, #0x48          | X0 = (1152921513197503680 + 72) = 1152921513197503752 (0x10000002000B0508);
        // 0x00B36AE8: STR s0, [sp, #0x48]        | stack[1152921513197503752] = ((val_126 / 100000f) / 10f);  //  dest_result_addr=1152921513197503752
        // 0x00B36AEC: BL #0x18a7768              | X0 = ((val_126 / 100000f) / 10f).ToString(format:  "0.0 MB");
        string val_101 = val_128.ToString(format:  "0.0 MB");
        // 0x00B36AF0: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B36AF4: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x00B36AF8: MOV x1, x0                 | X1 = val_101;//m1                       
        // 0x00B36AFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36B00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36B04: BL #0x2126ab0              | UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        // 0x00B36B08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36B10: BL #0x20d3bbc              | X0 = UnityEngine.Color.get_green();     
        UnityEngine.Color val_102 = UnityEngine.Color.green;
        // 0x00B36B14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36B18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36B1C: BL #0x2125198              | UnityEngine.GUI.set_color(value:  new UnityEngine.Color() {r = val_102.r, g = val_102.g, b = val_102.b, a = val_102.a});
        UnityEngine.GUI.color = new UnityEngine.Color() {r = val_102.r, g = val_102.g, b = val_102.b, a = val_102.a};
        // 0x00B36B20: FCVT d0, s9                | D0 = (double)val_77);                   
        // 0x00B36B24: ADD x0, sp, #0x10          | X0 = (1152921513197503680 + 16) = 1152921513197503696 (0x10000002000B04D0);
        // 0x00B36B28: BL #0x980330               | X0 = sub_980330( ?? 0x10000002000B04D0, ????);
        // 0x00B36B2C: FCMP s9, #0.0              | STATE = COMPARE(val_77, 0)              
        // 0x00B36B30: B.GE #0xb36b4c             | if (val_130 >= 0) goto label_132;       
        if(val_130 >= 0f)
        {
            goto label_132;
        }
        // 0x00B36B34: FMOV d1, #-0.50000000      | D1 = -0.5;                              
        // 0x00B36B38: FCMP d0, d1                | STATE = COMPARE(val_77, -0.5)           
        // 0x00B36B3C: B.NE #0xb36b78             | if ((double)val_130 = val_77 != -0.5) goto label_133;
        if((double)val_130 != (-0.5))
        {
            goto label_133;
        }
        // 0x00B36B40: LDR d0, [sp, #0x10]        | D0 = val_103;                            //  find_add[1152921513197491936]
        val_136 = val_103;
        // 0x00B36B44: FMOV s1, #-1.00000000      | S1 = -1;                                
        val_137 = -1f;
        // 0x00B36B48: B #0xb36b60                |  goto label_134;                        
        goto label_134;
        label_132:
        // 0x00B36B4C: FMOV d1, #0.50000000       | D1 = 0.5;                               
        // 0x00B36B50: FCMP d0, d1                | STATE = COMPARE(val_77, 0.5)            
        // 0x00B36B54: B.NE #0xb36b88             | if ((double)val_130 != 0.5) goto label_135;
        if((double)val_130 != 0.5)
        {
            goto label_135;
        }
        // 0x00B36B58: LDR d0, [sp, #0x10]        | D0 = val_103;                            //  find_add[1152921513197491936]
        val_136 = val_103;
        // 0x00B36B5C: FMOV s1, #1.00000000       | S1 = 1;                                 
        val_137 = 1f;
        label_134:
        // 0x00B36B60: FCVTZS x8, d0              | X8 = (long)(val_103);                   
        // 0x00B36B64: FCVT s0, d0                | S0 = (float)val_103);                   
        // 0x00B36B68: FADD s1, s0, s1            | S1 = (val_103 + val_137);               
        val_137 = (float)val_136 + val_137;
        // 0x00B36B6C: TST x8, #1                 | STATE = COMPARE(val_103, 0x1)           
        // 0x00B36B70: FCSEL s10, s0, s1, eq      | S10 = ((long)val_136 & 0x1)!=0 ? val_103 : (val_103 + val_137);
        var val_104 = (((long)val_136 & 1) != 0) ? ((float)val_136) : (val_137);
        // 0x00B36B74: B #0xb36b90                |  goto label_137;                        
        goto label_137;
        label_133:
        // 0x00B36B78: FMOV s0, #-0.50000000      | S0 = -0.5;                              
        float val_129 = -0.5f;
        // 0x00B36B7C: FADD s0, s9, s0            | S0 = (val_77 + -0.5f);                  
        val_129 = val_130 + val_129;
        // 0x00B36B80: FRINTP s10, s0             | 
        // 0x00B36B84: B #0xb36b90                |  goto label_137;                        
        goto label_137;
        label_135:
        // 0x00B36B88: FADD s0, s9, s15           | S0 = (val_77 + val_132);                
        float val_105 = val_130 + val_132;
        // 0x00B36B8C: FRINTM s10, s0             | 
        label_137:
        // 0x00B36B90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36B98: STR s10, [sp, #0x50]       | stack[1152921513197503760] = 0;          //  dest_result_addr=1152921513197503760
        // 0x00B36B9C: BL #0x1b8b83c              | X0 = UnityEngine.Screen.get_height();   
        int val_106 = UnityEngine.Screen.height;
        // 0x00B36BA0: LDP s0, s2, [x19, #0xbc]   | S0 = this.graphHeight; //P2  S2 = this.graphOffset; //P2  //  | 
        // 0x00B36BA4: MOV w20, w0                | W20 = val_106;//m1                      
        // 0x00B36BA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36BB0: FADD s3, s2, s0            | S3 = (this.graphOffset + this.graphHeight);
        float val_107 = this.graphOffset + this.graphHeight;
        // 0x00B36BB4: MOV v0.16b, v8.16b         | V0 = 2139095040 (0x7F800000);//ML01     
        // 0x00B36BB8: MOV v1.16b, v9.16b         | V1 = val_77;//m1                        
        // 0x00B36BBC: MOV v4.16b, v10.16b        | V4 = 0;//m1                             
        // 0x00B36BC0: BL #0x16845ac              | X0 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  float val_107 = this.graphOffset + this.graphHeight, value:  val_130);
        float val_108 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  val_107, value:  val_130);
        // 0x00B36BC4: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B36BC8: LDR s10, [x8, #0x948]      | S10 = 55;                               
        val_125 = 55f;
        // 0x00B36BCC: SCVTF s1, w20              | S1 = (float)(val_106);                  
        float val_130 = (float)val_106;
        // 0x00B36BD0: FSUB s0, s1, s0            | S0 = (val_106 - val_108);               
        val_108 = val_130 - val_108;
        // 0x00B36BD4: FADD s1, s0, s12           | S1 = ((val_106 - val_108) + -10f);      
        val_130 = val_108 + (-10f);
        // 0x00B36BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36BDC: FMOV s3, #20.00000000      | S3 = 20;                                
        // 0x00B36BE0: ADD x0, sp, #0x10          | X0 = (1152921513197503680 + 16) = 1152921513197503696 (0x10000002000B04D0);
        // 0x00B36BE4: MOV v0.16b, v10.16b        | V0 = 1113325568 (0x425C0000);//ML01     
        // 0x00B36BE8: MOV v2.16b, v11.16b        | V2 = 100;//m1                           
        // 0x00B36BEC: STP xzr, xzr, [sp, #0x10]  | val_103 = 0x0;  stack[1152921513197503704] = 0x0;  //  dest_result_addr=1152921513197503696 |  dest_result_addr=1152921513197503704
        val_103 = 0;
        // 0x00B36BF0: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
        // 0x00B36BF4: ADRP x20, #0x3632000       | X20 = 56827904 (0x3632000);             
        // 0x00B36BF8: LDR x20, [x20, #0x818]     | X20 = (string**)(1152921513197483664)("0 FPS");
        // 0x00B36BFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36C00: ADD x0, sp, #0x50          | X0 = (1152921513197503680 + 80) = 1152921513197503760 (0x10000002000B0510);
        // 0x00B36C04: LDR x1, [x20]              | X1 = "0 FPS";                           
        // 0x00B36C08: BL #0x18a7768              | X0 = 0.ToString(format:  "0 FPS");      
        string val_109 = val_130.ToString(format:  "0 FPS");
        // 0x00B36C0C: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B36C10: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x00B36C14: MOV x1, x0                 | X1 = val_109;//m1                       
        // 0x00B36C18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36C1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36C20: BL #0x2126ab0              | UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        // 0x00B36C24: FCVT d0, s8                | D0 = (double)Infinity);                 
        // 0x00B36C28: MOV x0, sp                 | X0 = 1152921513197503680 (0x10000002000B04C0);//ML01
        // 0x00B36C2C: BL #0x980330               | X0 = sub_980330( ?? 0x10000002000B04C0, ????);
        // 0x00B36C30: FCMP s8, #0.0              | STATE = COMPARE(Infinity, 0)            
        // 0x00B36C34: B.GE #0xb36c50             | if (val_126 >= 0) goto label_138;       
        if(val_126 >= 0f)
        {
            goto label_138;
        }
        // 0x00B36C38: FMOV d1, #-0.50000000      | D1 = -0.5;                              
        // 0x00B36C3C: FCMP d0, d1                | STATE = COMPARE(Infinity, -0.5)         
        // 0x00B36C40: B.NE #0xb36c7c             | if ((double)val_126 != -0.5) goto label_139;
        if((double)val_126 != (-0.5))
        {
            goto label_139;
        }
        // 0x00B36C44: LDR d0, [sp]               | D0 = val_110;                            //  find_add[1152921513197491936]
        val_139 = val_110;
        // 0x00B36C48: FMOV s1, #-1.00000000      | S1 = -1;                                
        val_140 = -1f;
        // 0x00B36C4C: B #0xb36c64                |  goto label_140;                        
        goto label_140;
        label_138:
        // 0x00B36C50: FMOV d1, #0.50000000       | D1 = 0.5;                               
        // 0x00B36C54: FCMP d0, d1                | STATE = COMPARE(Infinity, 0.5)          
        // 0x00B36C58: B.NE #0xb36c8c             | if ((double)val_126 != 0.5) goto label_141;
        if((double)val_126 != 0.5)
        {
            goto label_141;
        }
        // 0x00B36C5C: LDR d0, [sp]               | D0 = val_110;                            //  find_add[1152921513197491936]
        val_139 = val_110;
        // 0x00B36C60: FMOV s1, #1.00000000       | S1 = 1;                                 
        val_140 = 1f;
        label_140:
        // 0x00B36C64: FCVTZS x8, d0              | X8 = (long)(val_110);                   
        // 0x00B36C68: FCVT s0, d0                | S0 = (float)val_110);                   
        float val_131 = (float)val_139;
        // 0x00B36C6C: FADD s1, s0, s1            | S1 = (val_110 + val_140);               
        val_140 = val_131 + val_140;
        // 0x00B36C70: TST x8, #1                 | STATE = COMPARE(val_110, 0x1)           
        // 0x00B36C74: FCSEL s0, s0, s1, eq       | S0 = ((long)val_139 & 0x1)!=0 ? val_110 : (val_110 + val_140);
        val_131 = (((long)val_139 & 1) != 0) ? (val_131) : (val_140);
        // 0x00B36C78: B #0xb36c94                |  goto label_143;                        
        goto label_143;
        label_139:
        // 0x00B36C7C: FMOV s0, #-0.50000000      | S0 = -0.5;                              
        float val_132 = -0.5f;
        // 0x00B36C80: FADD s0, s8, s0            | S0 = (val_126 + -0.5f);                 
        val_132 = val_126 + val_132;
        // 0x00B36C84: FRINTP s0, s0              | 
        // 0x00B36C88: B #0xb36c94                |  goto label_143;                        
        goto label_143;
        label_141:
        // 0x00B36C8C: FADD s0, s8, s15           | S0 = (val_126 + val_132);               
        float val_111 = val_126 + val_132;
        // 0x00B36C90: FRINTM s0, s0              | 
        label_143:
        // 0x00B36C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36C98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36C9C: STR s0, [sp, #0x50]        | stack[1152921513197503760] = (val_126 + val_132);  //  dest_result_addr=1152921513197503760
        // 0x00B36CA0: BL #0x1b8b83c              | X0 = UnityEngine.Screen.get_height();   
        int val_112 = UnityEngine.Screen.height;
        // 0x00B36CA4: LDP s0, s2, [x19, #0xbc]   | S0 = this.graphHeight; //P2  S2 = this.graphOffset; //P2  //  | 
        // 0x00B36CA8: LDR s4, [sp, #0x50]        | S4 = (val_126 + val_132);               
        // 0x00B36CAC: MOV w19, w0                | W19 = val_112;//m1                      
        val_114 = val_112;
        // 0x00B36CB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36CB4: FADD s3, s2, s0            | S3 = (this.graphOffset + this.graphHeight);
        float val_113 = this.graphOffset + this.graphHeight;
        // 0x00B36CB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36CBC: MOV v0.16b, v8.16b         | V0 = Infinity;//m1                      
        // 0x00B36CC0: MOV v1.16b, v9.16b         | V1 = val_77;//m1                        
        // 0x00B36CC4: BL #0x16845ac              | X0 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  float val_113 = this.graphOffset + this.graphHeight, value:  val_111);
        float val_114 = Pathfinding.AstarMath.MapTo(startMin:  val_126, startMax:  val_130, targetMin:  this.graphOffset, targetMax:  val_113, value:  val_111);
        // 0x00B36CC8: SCVTF s1, w19              | S1 = (float)(val_112);                  
        float val_133 = (float)val_114;
        // 0x00B36CCC: FSUB s0, s1, s0            | S0 = (val_112 - val_114);               
        val_114 = val_133 - val_114;
        // 0x00B36CD0: FADD s1, s0, s12           | S1 = ((val_112 - val_114) + -10f);      
        val_133 = val_114 + (-10f);
        // 0x00B36CD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B36CD8: FMOV s3, #20.00000000      | S3 = 20;                                
        // 0x00B36CDC: MOV x0, sp                 | X0 = 1152921513197503680 (0x10000002000B04C0);//ML01
        // 0x00B36CE0: MOV v0.16b, v10.16b        | V0 = 1113325568 (0x425C0000);//ML01     
        // 0x00B36CE4: MOV v2.16b, v11.16b        | V2 = 100;//m1                           
        // 0x00B36CE8: STP xzr, xzr, [sp]         | val_110 = 0x0;  stack[1152921513197503688] = 0x0;  //  dest_result_addr=1152921513197503680 |  dest_result_addr=1152921513197503688
        val_110 = 0;
        // 0x00B36CEC: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
        // 0x00B36CF0: LDR x1, [x20]              | X1 = "0 FPS";                           
        // 0x00B36CF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36CF8: ADD x0, sp, #0x50          | X0 = (1152921513197503680 + 80) = 1152921513197503760 (0x10000002000B0510);
        // 0x00B36CFC: BL #0x18a7768              | X0 = (val_126 + val_132).ToString(format:  "0 FPS");
        string val_115 = val_111.ToString(format:  "0 FPS");
        // 0x00B36D00: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B36D04: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x00B36D08: MOV x1, x0                 | X1 = val_115;//m1                       
        // 0x00B36D0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B36D10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B36D14: BL #0x2126ab0              | UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        UnityEngine.GUI.Label(position:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, text:  0);
        label_107:
        // 0x00B36D18: SUB sp, x29, #0x80         | SP = (1152921513197503920 - 128) = 1152921513197503792 (0x10000002000B0530);
        // 0x00B36D1C: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00B36D20: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00B36D24: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00B36D28: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00B36D2C: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00B36D30: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B36D34: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B36D38: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B36D3C: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
        // 0x00B36D40: RET                        |  return;                                
        return;
    
    }

}
