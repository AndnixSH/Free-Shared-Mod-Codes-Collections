using UnityEngine;

namespace Pathfinding.Serialization
{
    public class AstarSerializer
    {
        // Fields
        private Pathfinding.AstarData data; //  0x00000010
        public Pathfinding.Serialization.JsonFx.JsonWriterSettings writerSettings; //  0x00000018
        public Pathfinding.Serialization.JsonFx.JsonReaderSettings readerSettings; //  0x00000020
        private Pathfinding.Ionic.Zip.ZipFile zip; //  0x00000028
        private System.IO.MemoryStream str; //  0x00000030
        private Pathfinding.Serialization.GraphMeta meta; //  0x00000038
        private Pathfinding.Serialization.SerializeSettings settings; //  0x00000040
        private Pathfinding.NavGraph[] graphs; //  0x00000048
        private const string binaryExt = ".binary";
        private const string jsonExt = ".json";
        private uint checksum; //  0x00000050
        private System.Text.UTF8Encoding encoding; //  0x00000058
        private static System.Text.StringBuilder _stringBuilder; // static_offset: 0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x028BDA70 (42719856), len: 140  VirtAddr: 0x028BDA70 RVA: 0x028BDA70 token: 100682617 methodIndex: 51154 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarSerializer(Pathfinding.AstarData data)
        {
            //
            // Disasemble & Code
            // 0x028BDA70: STP x22, x21, [sp, #-0x30]! | stack[1152921513271154048] = ???;  stack[1152921513271154056] = ???;  //  dest_result_addr=1152921513271154048 |  dest_result_addr=1152921513271154056
            // 0x028BDA74: STP x20, x19, [sp, #0x10]  | stack[1152921513271154064] = ???;  stack[1152921513271154072] = ???;  //  dest_result_addr=1152921513271154064 |  dest_result_addr=1152921513271154072
            // 0x028BDA78: STP x29, x30, [sp, #0x20]  | stack[1152921513271154080] = ???;  stack[1152921513271154088] = ???;  //  dest_result_addr=1152921513271154080 |  dest_result_addr=1152921513271154088
            // 0x028BDA7C: ADD x29, sp, #0x20         | X29 = (1152921513271154048 + 32) = 1152921513271154080 (0x10000002046ED5A0);
            // 0x028BDA80: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BDA84: LDRB w8, [x21, #0x937]     | W8 = (bool)static_value_037B8937;       
            // 0x028BDA88: MOV x20, x1                | X20 = data;//m1                         
            // 0x028BDA8C: MOV x19, x0                | X19 = 1152921513271166096 (0x10000002046F0490);//ML01
            // 0x028BDA90: TBNZ w8, #0, #0x28bdaac    | if (static_value_037B8937 == true) goto label_0;
            // 0x028BDA94: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x028BDA98: LDR x8, [x8, #0xe90]       | X8 = 0x2B8EDB4;                         
            // 0x028BDA9C: LDR w0, [x8]               | W0 = 0x122D;                            
            // 0x028BDAA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x122D, ????);     
            // 0x028BDAA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BDAA8: STRB w8, [x21, #0x937]     | static_value_037B8937 = true;            //  dest_result_addr=58427703
            label_0:
            // 0x028BDAAC: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x028BDAB0: STR w8, [x19, #0x50]       | this.checksum = null;                    //  dest_result_addr=1152921513271166176
            this.checksum = 0;
            // 0x028BDAB4: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x028BDAB8: LDR x8, [x8, #0x9e0]       | X8 = 1152921504649924608;               
            // 0x028BDABC: LDR x0, [x8]               | X0 = typeof(System.Text.UTF8Encoding);  
            System.Text.UTF8Encoding val_1 = null;
            // 0x028BDAC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.UTF8Encoding), ????);
            // 0x028BDAC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDAC8: MOV x21, x0                | X21 = 1152921504649924608 (0x1000000002915000);//ML01
            // 0x028BDACC: BL #0x1b62a98              | .ctor();                                
            val_1 = new System.Text.UTF8Encoding();
            // 0x028BDAD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDAD4: MOV x0, x19                | X0 = 1152921513271166096 (0x10000002046F0490);//ML01
            // 0x028BDAD8: STR x21, [x19, #0x58]      | this.encoding = typeof(System.Text.UTF8Encoding);  //  dest_result_addr=1152921513271166184
            this.encoding = val_1;
            // 0x028BDADC: BL #0x16f59f0              | this..ctor();                           
            // 0x028BDAE0: STR x20, [x19, #0x10]      | this.data = data;                        //  dest_result_addr=1152921513271166112
            this.data = data;
            // 0x028BDAE4: BL #0x28bdafc              | X0 = Pathfinding.Serialization.SerializeSettings.get_Settings();
            Pathfinding.Serialization.SerializeSettings val_2 = Pathfinding.Serialization.SerializeSettings.Settings;
            // 0x028BDAE8: STR x0, [x19, #0x40]       | this.settings = val_2;                   //  dest_result_addr=1152921513271166160
            this.settings = val_2;
            // 0x028BDAEC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028BDAF0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028BDAF4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028BDAF8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028BDB6C (42720108), len: 140  VirtAddr: 0x028BDB6C RVA: 0x028BDB6C token: 100682618 methodIndex: 51155 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarSerializer(Pathfinding.AstarData data, Pathfinding.Serialization.SerializeSettings settings)
        {
            //
            // Disasemble & Code
            // 0x028BDB6C: STP x22, x21, [sp, #-0x30]! | stack[1152921513271282432] = ???;  stack[1152921513271282440] = ???;  //  dest_result_addr=1152921513271282432 |  dest_result_addr=1152921513271282440
            // 0x028BDB70: STP x20, x19, [sp, #0x10]  | stack[1152921513271282448] = ???;  stack[1152921513271282456] = ???;  //  dest_result_addr=1152921513271282448 |  dest_result_addr=1152921513271282456
            // 0x028BDB74: STP x29, x30, [sp, #0x20]  | stack[1152921513271282464] = ???;  stack[1152921513271282472] = ???;  //  dest_result_addr=1152921513271282464 |  dest_result_addr=1152921513271282472
            // 0x028BDB78: ADD x29, sp, #0x20         | X29 = (1152921513271282432 + 32) = 1152921513271282464 (0x100000020470CB20);
            // 0x028BDB7C: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028BDB80: LDRB w8, [x22, #0x938]     | W8 = (bool)static_value_037B8938;       
            // 0x028BDB84: MOV x19, x2                | X19 = settings;//m1                     
            // 0x028BDB88: MOV x20, x1                | X20 = data;//m1                         
            // 0x028BDB8C: MOV x21, x0                | X21 = 1152921513271294480 (0x100000020470FA10);//ML01
            // 0x028BDB90: TBNZ w8, #0, #0x28bdbac    | if (static_value_037B8938 == true) goto label_0;
            // 0x028BDB94: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x028BDB98: LDR x8, [x8, #0x348]       | X8 = 0x2B8EDB0;                         
            // 0x028BDB9C: LDR w0, [x8]               | W0 = 0x122C;                            
            // 0x028BDBA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x122C, ????);     
            // 0x028BDBA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BDBA8: STRB w8, [x22, #0x938]     | static_value_037B8938 = true;            //  dest_result_addr=58427704
            label_0:
            // 0x028BDBAC: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x028BDBB0: STR w8, [x21, #0x50]       | this.checksum = null;                    //  dest_result_addr=1152921513271294560
            this.checksum = 0;
            // 0x028BDBB4: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x028BDBB8: LDR x8, [x8, #0x9e0]       | X8 = 1152921504649924608;               
            // 0x028BDBBC: LDR x0, [x8]               | X0 = typeof(System.Text.UTF8Encoding);  
            System.Text.UTF8Encoding val_1 = null;
            // 0x028BDBC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.UTF8Encoding), ????);
            // 0x028BDBC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDBC8: MOV x22, x0                | X22 = 1152921504649924608 (0x1000000002915000);//ML01
            // 0x028BDBCC: BL #0x1b62a98              | .ctor();                                
            val_1 = new System.Text.UTF8Encoding();
            // 0x028BDBD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDBD4: MOV x0, x21                | X0 = 1152921513271294480 (0x100000020470FA10);//ML01
            // 0x028BDBD8: STR x22, [x21, #0x58]      | this.encoding = typeof(System.Text.UTF8Encoding);  //  dest_result_addr=1152921513271294568
            this.encoding = val_1;
            // 0x028BDBDC: BL #0x16f59f0              | settings..ctor();                       
            val_2 = new System.Object();
            // 0x028BDBE0: STR x19, [x21, #0x40]      | this.settings = settings;                //  dest_result_addr=1152921513271294544
            this.settings = val_2;
            // 0x028BDBE4: STR x20, [x21, #0x10]      | this.data = data;                        //  dest_result_addr=1152921513271294496
            this.data = data;
            // 0x028BDBE8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028BDBEC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028BDBF0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028BDBF4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028BDBF8 (42720248), len: 140  VirtAddr: 0x028BDBF8 RVA: 0x028BDBF8 token: 100682619 methodIndex: 51156 delegateWrapperIndex: 0 methodInvoker: 0
        private static System.Text.StringBuilder GetStringBuilder()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x028BDBF8: STP x20, x19, [sp, #-0x20]! | stack[1152921513271402640] = ???;  stack[1152921513271402648] = ???;  //  dest_result_addr=1152921513271402640 |  dest_result_addr=1152921513271402648
            // 0x028BDBFC: STP x29, x30, [sp, #0x10]  | stack[1152921513271402656] = ???;  stack[1152921513271402664] = ???;  //  dest_result_addr=1152921513271402656 |  dest_result_addr=1152921513271402664
            // 0x028BDC00: ADD x29, sp, #0x10         | X29 = (1152921513271402640 + 16) = 1152921513271402656 (0x100000020472A0A0);
            // 0x028BDC04: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028BDC08: LDRB w8, [x19, #0x939]     | W8 = (bool)static_value_037B8939;       
            // 0x028BDC0C: TBNZ w8, #0, #0x28bdc28    | if (static_value_037B8939 == true) goto label_0;
            // 0x028BDC10: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x028BDC14: LDR x8, [x8, #0xab8]       | X8 = 0x2B8EDDC;                         
            // 0x028BDC18: LDR w0, [x8]               | W0 = 0x1237;                            
            // 0x028BDC1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1237, ????);     
            // 0x028BDC20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BDC24: STRB w8, [x19, #0x939]     | static_value_037B8939 = true;            //  dest_result_addr=58427705
            label_0:
            // 0x028BDC28: ADRP x20, #0x3615000       | X20 = 56709120 (0x3615000);             
            // 0x028BDC2C: LDR x20, [x20, #0x5d0]     | X20 = 1152921504841830400;              
            // 0x028BDC30: LDR x0, [x20]              | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            val_1 = null;
            // 0x028BDC34: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_10A;
            // 0x028BDC38: TBZ w8, #0, #0x28bdc4c     | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028BDC3C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x028BDC40: CBNZ w8, #0x28bdc4c        | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028BDC44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            // 0x028BDC48: LDR x0, [x20]              | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            val_1 = null;
            label_2:
            // 0x028BDC4C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_static_fields;
            // 0x028BDC50: LDR x19, [x8]              | X19 = Pathfinding.Serialization.AstarSerializer._stringBuilder;
            // 0x028BDC54: CBNZ x19, #0x28bdc5c       | if (Pathfinding.Serialization.AstarSerializer._stringBuilder != null) goto label_3;
            if(Pathfinding.Serialization.AstarSerializer._stringBuilder != null)
            {
                goto label_3;
            }
            // 0x028BDC58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            label_3:
            // 0x028BDC5C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028BDC60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BDC64: MOV x0, x19                | X0 = Pathfinding.Serialization.AstarSerializer._stringBuilder;//m1
            // 0x028BDC68: BL #0x1b5ac0c              | Pathfinding.Serialization.AstarSerializer._stringBuilder.set_Length(value:  0);
            Pathfinding.Serialization.AstarSerializer._stringBuilder.Length = 0;
            // 0x028BDC6C: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x028BDC70: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_static_fields;
            // 0x028BDC74: LDR x0, [x8]               | X0 = Pathfinding.Serialization.AstarSerializer._stringBuilder;
            // 0x028BDC78: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028BDC7C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028BDC80: RET                        |  return (System.Text.StringBuilder)Pathfinding.Serialization.AstarSerializer._stringBuilder;
            return Pathfinding.Serialization.AstarSerializer._stringBuilder;
            //  |  // // {name=val_0, type=System.Text.StringBuilder, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BDC84 (42720388), len: 128  VirtAddr: 0x028BDC84 RVA: 0x028BDC84 token: 100682620 methodIndex: 51157 delegateWrapperIndex: 0 methodInvoker: 0
        public void AddChecksum(byte[] bytes)
        {
            //
            // Disasemble & Code
            // 0x028BDC84: STP x22, x21, [sp, #-0x30]! | stack[1152921513271551488] = ???;  stack[1152921513271551496] = ???;  //  dest_result_addr=1152921513271551488 |  dest_result_addr=1152921513271551496
            // 0x028BDC88: STP x20, x19, [sp, #0x10]  | stack[1152921513271551504] = ???;  stack[1152921513271551512] = ???;  //  dest_result_addr=1152921513271551504 |  dest_result_addr=1152921513271551512
            // 0x028BDC8C: STP x29, x30, [sp, #0x20]  | stack[1152921513271551520] = ???;  stack[1152921513271551528] = ???;  //  dest_result_addr=1152921513271551520 |  dest_result_addr=1152921513271551528
            // 0x028BDC90: ADD x29, sp, #0x20         | X29 = (1152921513271551488 + 32) = 1152921513271551520 (0x100000020474E620);
            // 0x028BDC94: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BDC98: LDRB w8, [x21, #0x93a]     | W8 = (bool)static_value_037B893A;       
            // 0x028BDC9C: MOV x20, x1                | X20 = bytes;//m1                        
            // 0x028BDCA0: MOV x19, x0                | X19 = 1152921513271563536 (0x1000000204751510);//ML01
            // 0x028BDCA4: TBNZ w8, #0, #0x28bdcc0    | if (static_value_037B893A == true) goto label_0;
            // 0x028BDCA8: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x028BDCAC: LDR x8, [x8, #0x10]        | X8 = 0x2B8EDB8;                         
            // 0x028BDCB0: LDR w0, [x8]               | W0 = 0x122E;                            
            // 0x028BDCB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x122E, ????);     
            // 0x028BDCB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BDCBC: STRB w8, [x21, #0x93a]     | static_value_037B893A = true;            //  dest_result_addr=58427706
            label_0:
            // 0x028BDCC0: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x028BDCC4: LDR x8, [x8, #0x660]       | X8 = 1152921504850776064;               
            // 0x028BDCC8: LDR w21, [x19, #0x50]      | W21 = this.checksum; //P2               
            // 0x028BDCCC: LDR x0, [x8]               | X0 = typeof(Pathfinding.Util.Checksum); 
            // 0x028BDCD0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.Checksum.__il2cppRuntimeField_10A;
            // 0x028BDCD4: TBZ w8, #0, #0x28bdce4     | if (Pathfinding.Util.Checksum.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028BDCD8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.Checksum.__il2cppRuntimeField_cctor_finished;
            // 0x028BDCDC: CBNZ w8, #0x28bdce4        | if (Pathfinding.Util.Checksum.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028BDCE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Checksum), ????);
            label_2:
            // 0x028BDCE4: MOV x1, x20                | X1 = bytes;//m1                         
            // 0x028BDCE8: MOV w2, w21                | W2 = this.checksum;//m1                 
            // 0x028BDCEC: BL #0x28bdd04              | X0 = Pathfinding.Util.Checksum.GetChecksum(Value:  null, CRCVal:  bytes);
            uint val_1 = Pathfinding.Util.Checksum.GetChecksum(Value:  null, CRCVal:  bytes);
            // 0x028BDCF0: STR w0, [x19, #0x50]       | this.checksum = val_1;                   //  dest_result_addr=1152921513271563616
            this.checksum = val_1;
            // 0x028BDCF4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028BDCF8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028BDCFC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028BDD00: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028BDE04 (42720772), len: 8  VirtAddr: 0x028BDE04 RVA: 0x028BDE04 token: 100682621 methodIndex: 51158 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetChecksum()
        {
            //
            // Disasemble & Code
            // 0x028BDE04: LDR w0, [x0, #0x50]        | W0 = this.checksum; //P2                
            // 0x028BDE08: RET                        |  return (System.UInt32)this.checksum;   
            return this.checksum;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BDE0C (42720780), len: 672  VirtAddr: 0x028BDE0C RVA: 0x028BDE0C token: 100682622 methodIndex: 51159 delegateWrapperIndex: 0 methodInvoker: 0
        public void OpenSerialize()
        {
            //
            // Disasemble & Code
            // 0x028BDE0C: STP x22, x21, [sp, #-0x30]! | stack[1152921513271849216] = ???;  stack[1152921513271849224] = ???;  //  dest_result_addr=1152921513271849216 |  dest_result_addr=1152921513271849224
            // 0x028BDE10: STP x20, x19, [sp, #0x10]  | stack[1152921513271849232] = ???;  stack[1152921513271849240] = ???;  //  dest_result_addr=1152921513271849232 |  dest_result_addr=1152921513271849240
            // 0x028BDE14: STP x29, x30, [sp, #0x20]  | stack[1152921513271849248] = ???;  stack[1152921513271849256] = ???;  //  dest_result_addr=1152921513271849248 |  dest_result_addr=1152921513271849256
            // 0x028BDE18: ADD x29, sp, #0x20         | X29 = (1152921513271849216 + 32) = 1152921513271849248 (0x1000000204797120);
            // 0x028BDE1C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028BDE20: LDRB w8, [x20, #0x93b]     | W8 = (bool)static_value_037B893B;       
            // 0x028BDE24: MOV x19, x0                | X19 = 1152921513271861264 (0x100000020479A010);//ML01
            // 0x028BDE28: TBNZ w8, #0, #0x28bde44    | if (static_value_037B893B == true) goto label_0;
            // 0x028BDE2C: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x028BDE30: LDR x8, [x8, #0xfb8]       | X8 = 0x2B8EDE8;                         
            // 0x028BDE34: LDR w0, [x8]               | W0 = 0x123A;                            
            // 0x028BDE38: BL #0x2782188              | X0 = sub_2782188( ?? 0x123A, ????);     
            // 0x028BDE3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BDE40: STRB w8, [x20, #0x93b]     | static_value_037B893B = true;            //  dest_result_addr=58427707
            label_0:
            // 0x028BDE44: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x028BDE48: LDR x8, [x8, #0x3e0]       | X8 = 1152921504751788032;               
            // 0x028BDE4C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Ionic.Zip.ZipFile);
            Pathfinding.Ionic.Zip.ZipFile val_1 = null;
            // 0x028BDE50: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Ionic.Zip.ZipFile), ????);
            // 0x028BDE54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDE58: MOV x20, x0                | X20 = 1152921504751788032 (0x1000000008A3A000);//ML01
            // 0x028BDE5C: BL #0x1982c9c              | .ctor();                                
            val_1 = new Pathfinding.Ionic.Zip.ZipFile();
            // 0x028BDE60: STR x20, [x19, #0x28]      | this.zip = typeof(Pathfinding.Ionic.Zip.ZipFile);  //  dest_result_addr=1152921513271861304
            this.zip = val_1;
            // 0x028BDE64: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x028BDE68: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x028BDE6C: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x028BDE70: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x028BDE74: TBZ w8, #0, #0x28bde84     | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028BDE78: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x028BDE7C: CBNZ w8, #0x28bde84        | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028BDE80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_2:
            // 0x028BDE84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BDE88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDE8C: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_2 = System.Text.Encoding.UTF8;
            // 0x028BDE90: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028BDE94: CBNZ x20, #0x28bde9c       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x028BDE98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x028BDE9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BDEA0: MOV x0, x20                | X0 = 1152921504751788032 (0x1000000008A3A000);//ML01
            // 0x028BDEA4: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028BDEA8: BL #0x198769c              | set_AlternateEncoding(value:  val_2);   
            AlternateEncoding = val_2;
            // 0x028BDEAC: LDR x20, [x19, #0x28]      | X20 = this.zip; //P2                    
            // 0x028BDEB0: CBNZ x20, #0x28bdeb8       | if (this.zip != null) goto label_4;     
            if(this.zip != null)
            {
                goto label_4;
            }
            // 0x028BDEB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Ionic.Zip.ZipFile), ????);
            label_4:
            // 0x028BDEB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BDEBC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x028BDEC0: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028BDEC4: BL #0x19876a4              | this.zip.set_AlternateEncodingUsage(value:  2);
            this.zip.AlternateEncodingUsage = 2;
            // 0x028BDEC8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x028BDECC: LDR x8, [x8, #0xac0]       | X8 = 1152921504755515392;               
            // 0x028BDED0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            Pathfinding.Serialization.JsonFx.JsonWriterSettings val_3 = null;
            // 0x028BDED4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings), ????);
            // 0x028BDED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDEDC: MOV x20, x0                | X20 = 1152921504755515392 (0x1000000008DC8000);//ML01
            // 0x028BDEE0: BL #0x26df204              | .ctor();                                
            val_3 = new Pathfinding.Serialization.JsonFx.JsonWriterSettings();
            // 0x028BDEE4: STR x20, [x19, #0x18]      | this.writerSettings = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);  //  dest_result_addr=1152921513271861288
            this.writerSettings = val_3;
            // 0x028BDEE8: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x028BDEEC: LDR x8, [x8, #0x630]       | X8 = 1152921504841670656;               
            // 0x028BDEF0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.VectorConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_4 = null;
            // 0x028BDEF4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.VectorConverter), ????);
            // 0x028BDEF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDEFC: MOV x21, x0                | X21 = 1152921504841670656 (0x100000000DFF2000);//ML01
            // 0x028BDF00: BL #0x26d4920              | .ctor();                                
            val_4 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BDF04: CBNZ x20, #0x28bdf0c       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x028BDF08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x028BDF0C: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BDF10: MOV x0, x20                | X0 = 1152921504755515392 (0x1000000008DC8000);//ML01
            // 0x028BDF14: MOV x1, x21                | X1 = 1152921504841670656 (0x100000000DFF2000);//ML01
            // 0x028BDF18: LDP x9, x2, [x8, #0x1f0]   |                                          //  not_find_field!1:496 |  not_find_field!1:504
            // 0x028BDF1C: BLR x9                     | X0 = mem[null + 496]();                 
            // 0x028BDF20: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x028BDF24: LDR x20, [x19, #0x18]      | X20 = this.writerSettings; //P2         
            // 0x028BDF28: LDR x8, [x8, #0x510]       | X8 = 1152921504841564160;               
            // 0x028BDF2C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.BoundsConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_5 = null;
            // 0x028BDF30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.BoundsConverter), ????);
            // 0x028BDF34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDF38: MOV x21, x0                | X21 = 1152921504841564160 (0x100000000DFD8000);//ML01
            // 0x028BDF3C: BL #0x26d4920              | .ctor();                                
            val_5 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BDF40: CBNZ x20, #0x28bdf48       | if (this.writerSettings != null) goto label_6;
            if(this.writerSettings != null)
            {
                goto label_6;
            }
            // 0x028BDF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_6:
            // 0x028BDF48: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            // 0x028BDF4C: MOV x0, x20                | X0 = this.writerSettings;//m1           
            // 0x028BDF50: MOV x1, x21                | X1 = 1152921504841564160 (0x100000000DFD8000);//ML01
            // 0x028BDF54: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F8; //  | 
            // 0x028BDF58: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0();
            // 0x028BDF5C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028BDF60: LDR x20, [x19, #0x18]      | X20 = this.writerSettings; //P2         
            // 0x028BDF64: LDR x8, [x8, #0x6c8]       | X8 = 1152921504841617408;               
            // 0x028BDF68: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.LayerMaskConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_6 = null;
            // 0x028BDF6C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.LayerMaskConverter), ????);
            // 0x028BDF70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDF74: MOV x21, x0                | X21 = 1152921504841617408 (0x100000000DFE5000);//ML01
            // 0x028BDF78: BL #0x26d4920              | .ctor();                                
            val_6 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BDF7C: CBNZ x20, #0x28bdf84       | if (this.writerSettings != null) goto label_7;
            if(this.writerSettings != null)
            {
                goto label_7;
            }
            // 0x028BDF80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_7:
            // 0x028BDF84: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            // 0x028BDF88: MOV x0, x20                | X0 = this.writerSettings;//m1           
            // 0x028BDF8C: MOV x1, x21                | X1 = 1152921504841617408 (0x100000000DFE5000);//ML01
            // 0x028BDF90: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F8; //  | 
            // 0x028BDF94: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0();
            // 0x028BDF98: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x028BDF9C: LDR x20, [x19, #0x18]      | X20 = this.writerSettings; //P2         
            // 0x028BDFA0: LDR x8, [x8, #0xb18]       | X8 = 1152921504841510912;               
            // 0x028BDFA4: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.MatrixConverter);
            Pathfinding.Serialization.MatrixConverter val_7 = null;
            // 0x028BDFA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.MatrixConverter), ????);
            // 0x028BDFAC: MOV x21, x0                | X21 = 1152921504841510912 (0x100000000DFCB000);//ML01
            // 0x028BDFB0: BL #0x28be0c4              | .ctor();                                
            val_7 = new Pathfinding.Serialization.MatrixConverter();
            // 0x028BDFB4: CBNZ x20, #0x28bdfbc       | if (this.writerSettings != null) goto label_8;
            if(this.writerSettings != null)
            {
                goto label_8;
            }
            // 0x028BDFB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_8:
            // 0x028BDFBC: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            // 0x028BDFC0: MOV x0, x20                | X0 = this.writerSettings;//m1           
            // 0x028BDFC4: MOV x1, x21                | X1 = 1152921504841510912 (0x100000000DFCB000);//ML01
            // 0x028BDFC8: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F8; //  | 
            // 0x028BDFCC: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0();
            // 0x028BDFD0: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x028BDFD4: LDR x20, [x19, #0x18]      | X20 = this.writerSettings; //P2         
            // 0x028BDFD8: LDR x8, [x8, #0xe60]       | X8 = 1152921504841457664;               
            // 0x028BDFDC: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GuidConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_8 = null;
            // 0x028BDFE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GuidConverter), ????);
            // 0x028BDFE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BDFE8: MOV x21, x0                | X21 = 1152921504841457664 (0x100000000DFBE000);//ML01
            // 0x028BDFEC: BL #0x26d4920              | .ctor();                                
            val_8 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BDFF0: CBNZ x20, #0x28bdff8       | if (this.writerSettings != null) goto label_9;
            if(this.writerSettings != null)
            {
                goto label_9;
            }
            // 0x028BDFF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_9:
            // 0x028BDFF8: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            // 0x028BDFFC: MOV x0, x20                | X0 = this.writerSettings;//m1           
            // 0x028BE000: MOV x1, x21                | X1 = 1152921504841457664 (0x100000000DFBE000);//ML01
            // 0x028BE004: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F8; //  | 
            // 0x028BE008: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0();
            // 0x028BE00C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028BE010: LDR x20, [x19, #0x18]      | X20 = this.writerSettings; //P2         
            // 0x028BE014: LDR x8, [x8, #0x9c0]       | X8 = 1152921504841404416;               
            // 0x028BE018: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.UnityObjectConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_9 = null;
            // 0x028BE01C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.UnityObjectConverter), ????);
            // 0x028BE020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE024: MOV x21, x0                | X21 = 1152921504841404416 (0x100000000DFB1000);//ML01
            // 0x028BE028: BL #0x26d4920              | .ctor();                                
            val_9 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BE02C: CBNZ x20, #0x28be034       | if (this.writerSettings != null) goto label_10;
            if(this.writerSettings != null)
            {
                goto label_10;
            }
            // 0x028BE030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_10:
            // 0x028BE034: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            // 0x028BE038: MOV x0, x20                | X0 = this.writerSettings;//m1           
            // 0x028BE03C: MOV x1, x21                | X1 = 1152921504841404416 (0x100000000DFB1000);//ML01
            // 0x028BE040: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F8; //  | 
            // 0x028BE044: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_1F0();
            // 0x028BE048: LDR x20, [x19, #0x18]      | X20 = this.writerSettings; //P2         
            // 0x028BE04C: LDR x21, [x19, #0x40]      | X21 = this.settings; //P2               
            // 0x028BE050: CBNZ x21, #0x28be058       | if (this.settings != null) goto label_11;
            if(this.settings != null)
            {
                goto label_11;
            }
            // 0x028BE054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.writerSettings, ????);
            label_11:
            // 0x028BE058: LDRB w21, [x21, #0x11]     | W21 = this.settings.prettyPrint; //P2   
            // 0x028BE05C: CBNZ x20, #0x28be064       | if (this.writerSettings != null) goto label_12;
            if(this.writerSettings != null)
            {
                goto label_12;
            }
            // 0x028BE060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.writerSettings, ????);
            label_12:
            // 0x028BE064: LDR x8, [x20]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings);
            // 0x028BE068: CMP w21, #0                | STATE = COMPARE(this.settings.prettyPrint, 0x0)
            // 0x028BE06C: CSET w1, ne                | W1 = this.settings.prettyPrint == true ? 1 : 0;
            var val_10 = (this.settings.prettyPrint == true) ? 1 : 0;
            // 0x028BE070: MOV x0, x20                | X0 = this.writerSettings;//m1           
            // 0x028BE074: LDP x9, x2, [x8, #0x170]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_170; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_178; //  | 
            // 0x028BE078: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonWriterSettings).__il2cppRuntimeField_170();
            // 0x028BE07C: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x028BE080: LDR x8, [x8, #0x960]       | X8 = 1152921504842203136;               
            // 0x028BE084: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GraphMeta);
            object val_11 = null;
            // 0x028BE088: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GraphMeta), ????);
            // 0x028BE08C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE090: MOV x20, x0                | X20 = 1152921504842203136 (0x100000000E074000);//ML01
            // 0x028BE094: BL #0x16f59f0              | .ctor();                                
            val_11 = new System.Object();
            // 0x028BE098: STR x20, [x19, #0x38]      | this.meta = typeof(Pathfinding.Serialization.GraphMeta);  //  dest_result_addr=1152921513271861320
            this.meta = val_11;
            // 0x028BE09C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028BE0A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028BE0A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028BE0A8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028BE148 (42721608), len: 276  VirtAddr: 0x028BE148 RVA: 0x028BE148 token: 100682623 methodIndex: 51160 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] CloseSerialize()
        {
            //
            // Disasemble & Code
            // 0x028BE148: STP x22, x21, [sp, #-0x30]! | stack[1152921513272051424] = ???;  stack[1152921513272051432] = ???;  //  dest_result_addr=1152921513272051424 |  dest_result_addr=1152921513272051432
            // 0x028BE14C: STP x20, x19, [sp, #0x10]  | stack[1152921513272051440] = ???;  stack[1152921513272051448] = ???;  //  dest_result_addr=1152921513272051440 |  dest_result_addr=1152921513272051448
            // 0x028BE150: STP x29, x30, [sp, #0x20]  | stack[1152921513272051456] = ???;  stack[1152921513272051464] = ???;  //  dest_result_addr=1152921513272051456 |  dest_result_addr=1152921513272051464
            // 0x028BE154: ADD x29, sp, #0x20         | X29 = (1152921513272051424 + 32) = 1152921513272051456 (0x10000002047C8700);
            // 0x028BE158: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028BE15C: LDRB w8, [x20, #0x93c]     | W8 = (bool)static_value_037B893C;       
            // 0x028BE160: MOV x19, x0                | X19 = 1152921513272063472 (0x10000002047CB5F0);//ML01
            // 0x028BE164: TBNZ w8, #0, #0x28be180    | if (static_value_037B893C == true) goto label_0;
            // 0x028BE168: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x028BE16C: LDR x8, [x8, #0x8b8]       | X8 = 0x2B8EDBC;                         
            // 0x028BE170: LDR w0, [x8]               | W0 = 0x122F;                            
            // 0x028BE174: BL #0x2782188              | X0 = sub_2782188( ?? 0x122F, ????);     
            // 0x028BE178: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BE17C: STRB w8, [x20, #0x93c]     | static_value_037B893C = true;            //  dest_result_addr=58427708
            label_0:
            // 0x028BE180: MOV x0, x19                | X0 = 1152921513272063472 (0x10000002047CB5F0);//ML01
            // 0x028BE184: BL #0x28be25c              | X0 = this.SerializeMeta();              
            System.Byte[] val_1 = this.SerializeMeta();
            // 0x028BE188: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028BE18C: MOV x0, x19                | X0 = 1152921513272063472 (0x10000002047CB5F0);//ML01
            // 0x028BE190: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028BE194: BL #0x28bdc84              | this.AddChecksum(bytes:  val_1);        
            this.AddChecksum(bytes:  val_1);
            // 0x028BE198: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BE19C: CBNZ x21, #0x28be1a4       | if (this.zip != null) goto label_1;     
            if(this.zip != null)
            {
                goto label_1;
            }
            // 0x028BE1A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x028BE1A4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x028BE1A8: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921513272027088)("meta.json");
            // 0x028BE1AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BE1B0: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028BE1B4: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x028BE1B8: LDR x1, [x8]               | X1 = "meta.json";                       
            // 0x028BE1BC: BL #0x1983670              | X0 = this.zip.AddEntry(entryName:  "meta.json", byteContent:  val_1);
            Pathfinding.Ionic.Zip.ZipEntry val_2 = this.zip.AddEntry(entryName:  "meta.json", byteContent:  val_1);
            // 0x028BE1C0: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028BE1C4: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028BE1C8: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_3 = null;
            // 0x028BE1CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028BE1D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE1D4: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BE1D8: BL #0x1e762f4              | .ctor();                                
            val_3 = new System.IO.MemoryStream();
            // 0x028BE1DC: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BE1E0: CBNZ x21, #0x28be1e8       | if (this.zip != null) goto label_2;     
            if(this.zip != null)
            {
                goto label_2;
            }
            // 0x028BE1E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x028BE1E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BE1EC: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028BE1F0: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BE1F4: BL #0x19874cc              | this.zip.Save(outputStream:  val_3);    
            this.zip.Save(outputStream:  val_3);
            // 0x028BE1F8: CBNZ x20, #0x28be200       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x028BE1FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.zip, ????);   
            label_3:
            // 0x028BE200: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BE204: MOV x0, x20                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BE208: LDR x9, [x8, #0x2e0]       |  //  not_find_field!1:736
            // 0x028BE20C: LDR x1, [x8, #0x2e8]       |  //  not_find_field!1:744
            // 0x028BE210: BLR x9                     | X0 = mem[null + 736]();                 
            // 0x028BE214: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BE218: CBNZ x20, #0x28be220       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x028BE21C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_4:
            // 0x028BE220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE224: MOV x0, x20                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BE228: BL #0x1e7cf4c              | Dispose();                              
            Dispose();
            // 0x028BE22C: LDR x20, [x19, #0x28]      | X20 = this.zip; //P2                    
            // 0x028BE230: CBNZ x20, #0x28be238       | if (this.zip != null) goto label_5;     
            if(this.zip != null)
            {
                goto label_5;
            }
            // 0x028BE234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_5:
            // 0x028BE238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE23C: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028BE240: BL #0x19879a4              | this.zip.Dispose();                     
            this.zip.Dispose();
            // 0x028BE244: STR xzr, [x19, #0x28]      | this.zip = null;                         //  dest_result_addr=1152921513272063512
            this.zip = 0;
            // 0x028BE248: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028BE24C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028BE250: MOV x0, x21                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BE254: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028BE258: RET                        |  return (System.Byte[])typeof(System.IO.MemoryStream);
            return (System.Byte[])val_3;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BE6A4 (42722980), len: 580  VirtAddr: 0x028BE6A4 RVA: 0x028BE6A4 token: 100682624 methodIndex: 51161 delegateWrapperIndex: 0 methodInvoker: 0
        public void SerializeGraphs(Pathfinding.NavGraph[] _graphs)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_7;
            //  | 
            object val_8;
            //  | 
            var val_9;
            // 0x028BE6A4: STP x28, x27, [sp, #-0x60]! | stack[1152921513272467952] = ???;  stack[1152921513272467960] = ???;  //  dest_result_addr=1152921513272467952 |  dest_result_addr=1152921513272467960
            // 0x028BE6A8: STP x26, x25, [sp, #0x10]  | stack[1152921513272467968] = ???;  stack[1152921513272467976] = ???;  //  dest_result_addr=1152921513272467968 |  dest_result_addr=1152921513272467976
            // 0x028BE6AC: STP x24, x23, [sp, #0x20]  | stack[1152921513272467984] = ???;  stack[1152921513272467992] = ???;  //  dest_result_addr=1152921513272467984 |  dest_result_addr=1152921513272467992
            // 0x028BE6B0: STP x22, x21, [sp, #0x30]  | stack[1152921513272468000] = ???;  stack[1152921513272468008] = ???;  //  dest_result_addr=1152921513272468000 |  dest_result_addr=1152921513272468008
            // 0x028BE6B4: STP x20, x19, [sp, #0x40]  | stack[1152921513272468016] = ???;  stack[1152921513272468024] = ???;  //  dest_result_addr=1152921513272468016 |  dest_result_addr=1152921513272468024
            // 0x028BE6B8: STP x29, x30, [sp, #0x50]  | stack[1152921513272468032] = ???;  stack[1152921513272468040] = ???;  //  dest_result_addr=1152921513272468032 |  dest_result_addr=1152921513272468040
            // 0x028BE6BC: ADD x29, sp, #0x50         | X29 = (1152921513272467952 + 80) = 1152921513272468032 (0x100000020482E240);
            // 0x028BE6C0: SUB sp, sp, #0x10          | SP = (1152921513272467952 - 16) = 1152921513272467936 (0x100000020482E1E0);
            // 0x028BE6C4: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BE6C8: LDRB w8, [x21, #0x93d]     | W8 = (bool)static_value_037B893D;       
            // 0x028BE6CC: MOV x20, x1                | X20 = _graphs;//m1                      
            val_7 = _graphs;
            // 0x028BE6D0: MOV x19, x0                | X19 = 1152921513272480048 (0x1000000204831130);//ML01
            // 0x028BE6D4: TBNZ w8, #0, #0x28be6f0    | if (static_value_037B893D == true) goto label_0;
            // 0x028BE6D8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x028BE6DC: LDR x8, [x8, #0x290]       | X8 = 0x2B8EDFC;                         
            // 0x028BE6E0: LDR w0, [x8]               | W0 = 0x123F;                            
            // 0x028BE6E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x123F, ????);     
            // 0x028BE6E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BE6EC: STRB w8, [x21, #0x93d]     | static_value_037B893D = true;            //  dest_result_addr=58427709
            label_0:
            // 0x028BE6F0: LDR x8, [x19, #0x48]       | X8 = this.graphs; //P2                  
            // 0x028BE6F4: CBNZ x8, #0x28be87c        | if (this.graphs != null) goto label_1;  
            if(this.graphs != null)
            {
                goto label_1;
            }
            // 0x028BE6F8: LDR x8, [x19, #0x28]       | X8 = this.zip; //P2                     
            // 0x028BE6FC: STR x20, [x19, #0x48]      | this.graphs = _graphs;                   //  dest_result_addr=1152921513272480120
            this.graphs = val_7;
            // 0x028BE700: CBZ x8, #0x28be8a8         | if (this.zip == null) goto label_2;     
            if(this.zip == null)
            {
                goto label_2;
            }
            // 0x028BE704: CBNZ x20, #0x28be730       | if (_graphs != null) goto label_3;      
            if(val_7 != null)
            {
                goto label_3;
            }
            // 0x028BE708: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028BE70C: LDR x8, [x8, #0xd20]       | X8 = 1152921507421177472;               
            // 0x028BE710: LDR x20, [x8]              | X20 = typeof(Pathfinding.NavGraph[]);   
            // 0x028BE714: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028BE718: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028BE71C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE720: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028BE724: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028BE728: MOV x20, x0                | X20 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            val_7 = null;
            // 0x028BE72C: STR x20, [x19, #0x48]      | this.graphs = typeof(Pathfinding.NavGraph[]);  //  dest_result_addr=1152921513272480120
            this.graphs = val_7;
            label_3:
            // 0x028BE730: ADRP x24, #0x3652000       | X24 = 56958976 (0x3652000);             
            // 0x028BE734: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
            // 0x028BE738: ADRP x26, #0x3684000       | X26 = 57163776 (0x3684000);             
            // 0x028BE73C: ADRP x27, #0x3609000       | X27 = 56659968 (0x3609000);             
            // 0x028BE740: LDR x24, [x24, #0x140]     | X24 = 1152921504607113216;              
            // 0x028BE744: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
            // 0x028BE748: LDR x26, [x26, #0x390]     | X26 = (string**)(1152921513124056064)("graph");
            // 0x028BE74C: LDR x27, [x27, #0xe08]     | X27 = (string**)(1152921513272282544)(".json");
            // 0x028BE750: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x028BE754: B #0x28be760               |  goto label_4;                          
            goto label_4;
            label_15:
            // 0x028BE758: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            val_7 = this.graphs;
            // 0x028BE75C: ADD w23, w23, #1           | W23 = (val_8 + 1) = val_8 (0x00000001); 
            val_8 = 1;
            label_4:
            // 0x028BE760: CBNZ x20, #0x28be768       | if (this.graphs != null) goto label_5;  
            if(val_7 != null)
            {
                goto label_5;
            }
            // 0x028BE764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_5:
            // 0x028BE768: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BE76C: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BE770: B.GE #0x28be85c            | if (val_8 >= this.graphs.Length) goto label_6;
            if(val_8 >= this.graphs.Length)
            {
                goto label_6;
            }
            // 0x028BE774: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028BE778: CBNZ x21, #0x28be780       | if (this.graphs != null) goto label_7;  
            if(this.graphs != null)
            {
                goto label_7;
            }
            // 0x028BE77C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_7:
            // 0x028BE780: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BE784: SXTW x20, w23              | X20 = 1 (0x00000001);                   
            // 0x028BE788: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BE78C: B.LO #0x28be79c            | if (val_8 < this.graphs.Length) goto label_8;
            if(val_8 < this.graphs.Length)
            {
                goto label_8;
            }
            // 0x028BE790: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028BE794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE798: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_8:
            // 0x028BE79C: ADD x8, x21, x20, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BE7A0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_7 = this.graphs[1];
            // 0x028BE7A4: CBZ x8, #0x28be758         | if (this.graphs[0x1][0] == null) goto label_15;
            if(val_7 == null)
            {
                goto label_15;
            }
            // 0x028BE7A8: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028BE7AC: CBNZ x21, #0x28be7b4       | if (this.graphs != null) goto label_10; 
            if(this.graphs != null)
            {
                goto label_10;
            }
            // 0x028BE7B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_10:
            // 0x028BE7B4: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BE7B8: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BE7BC: B.LO #0x28be7cc            | if (val_8 < this.graphs.Length) goto label_11;
            if(val_8 < this.graphs.Length)
            {
                goto label_11;
            }
            // 0x028BE7C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028BE7C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE7C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_11:
            // 0x028BE7CC: ADD x8, x21, x20, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BE7D0: LDR x1, [x8, #0x20]        | X1 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_8 = this.graphs[1];
            // 0x028BE7D4: MOV x0, x19                | X0 = 1152921513272480048 (0x1000000204831130);//ML01
            // 0x028BE7D8: BL #0x28be8e8              | X0 = this.Serialize(graph:  this.graphs[1]);
            System.Byte[] val_1 = this.Serialize(graph:  val_8);
            // 0x028BE7DC: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028BE7E0: MOV x0, x19                | X0 = 1152921513272480048 (0x1000000204831130);//ML01
            // 0x028BE7E4: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028BE7E8: BL #0x28bdc84              | this.AddChecksum(bytes:  val_1);        
            this.AddChecksum(bytes:  val_1);
            // 0x028BE7EC: LDR x0, [x24]              | X0 = typeof(System.Int32);              
            // 0x028BE7F0: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BE7F4: ADD x1, sp, #0xc           | X1 = (1152921513272467936 + 12) = 1152921513272467948 (0x100000020482E1EC);
            // 0x028BE7F8: STR w23, [sp, #0xc]        | stack[1152921513272467948] = 0x1;        //  dest_result_addr=1152921513272467948
            // 0x028BE7FC: BL #0x27bc028              | X0 = 1152921513272749616 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028BE800: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x028BE804: MOV x22, x0                | X22 = 1152921513272749616 (0x1000000204872E30);//ML01
            // 0x028BE808: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028BE80C: TBZ w9, #0, #0x28be820     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x028BE810: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028BE814: CBNZ w9, #0x28be820        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x028BE818: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028BE81C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_13:
            // 0x028BE820: LDR x1, [x26]              | X1 = "graph";                           
            // 0x028BE824: LDR x3, [x27]              | X3 = ".json";                           
            // 0x028BE828: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BE82C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028BE830: MOV x2, x22                | X2 = 1152921513272749616 (0x1000000204872E30);//ML01
            // 0x028BE834: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_8);
            string val_2 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_8);
            // 0x028BE838: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x028BE83C: CBNZ x21, #0x28be844       | if (this.zip != null) goto label_14;    
            if(this.zip != null)
            {
                goto label_14;
            }
            // 0x028BE840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_14:
            // 0x028BE844: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BE848: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028BE84C: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x028BE850: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x028BE854: BL #0x1983670              | X0 = this.zip.AddEntry(entryName:  val_2, byteContent:  val_1);
            Pathfinding.Ionic.Zip.ZipEntry val_3 = this.zip.AddEntry(entryName:  val_2, byteContent:  val_1);
            // 0x028BE858: B #0x28be758               |  goto label_15;                         
            goto label_15;
            label_6:
            // 0x028BE85C: SUB sp, x29, #0x50         | SP = (1152921513272468032 - 80) = 1152921513272467952 (0x100000020482E1F0);
            // 0x028BE860: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028BE864: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028BE868: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028BE86C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028BE870: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028BE874: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028BE878: RET                        |  return;                                
            return;
            label_1:
            // 0x028BE87C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x028BE880: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x028BE884: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_4 = null;
            // 0x028BE888: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x028BE88C: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x028BE890: LDR x8, [x8, #0x8f0]       | X8 = (string**)(1152921513272454656)("Cannot serialize graphs multiple times.");
            // 0x028BE894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BE898: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            val_9 = val_4;
            // 0x028BE89C: LDR x1, [x8]               | X1 = "Cannot serialize graphs multiple times.";
            // 0x028BE8A0: BL #0x1e6648c              | .ctor(message:  "Cannot serialize graphs multiple times.");
            val_4 = new System.InvalidOperationException(message:  "Cannot serialize graphs multiple times.");
            // 0x028BE8A4: B #0x28be8d0               |  goto label_16;                         
            goto label_16;
            label_2:
            // 0x028BE8A8: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x028BE8AC: LDR x8, [x8, #0x688]       | X8 = 1152921504655462400;               
            // 0x028BE8B0: LDR x0, [x8]               | X0 = typeof(System.NullReferenceException);
            System.NullReferenceException val_5 = null;
            // 0x028BE8B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NullReferenceException), ????);
            // 0x028BE8B8: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x028BE8BC: LDR x8, [x8, #0x610]       | X8 = (string**)(1152921513272454816)("You must not call CloseSerialize before a call to this function");
            // 0x028BE8C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BE8C4: MOV x19, x0                | X19 = 1152921504655462400 (0x1000000002E5D000);//ML01
            val_9 = val_5;
            // 0x028BE8C8: LDR x1, [x8]               | X1 = "You must not call CloseSerialize before a call to this function";
            // 0x028BE8CC: BL #0x17017b8              | .ctor(message:  "You must not call CloseSerialize before a call to this function");
            val_5 = new System.NullReferenceException(message:  "You must not call CloseSerialize before a call to this function");
            label_16:
            // 0x028BE8D0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028BE8D4: LDR x8, [x8, #0x910]       | X8 = 1152921513272455024;               
            // 0x028BE8D8: MOV x0, x19                | X0 = 1152921504655462400 (0x1000000002E5D000);//ML01
            // 0x028BE8DC: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Serialization.AstarSerializer::SerializeGraphs(Pathfinding.NavGraph[] _graphs);
            // 0x028BE8E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NullReferenceException), ????);
            // 0x028BE8E4: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_6 = MoveNext();
        
        }
        //
        // Offset in libil2cpp.so: 0x028BE9E0 (42723808), len: 944  VirtAddr: 0x028BE9E0 RVA: 0x028BE9E0 token: 100682625 methodIndex: 51162 delegateWrapperIndex: 0 methodInvoker: 0
        public void SerializeUserConnections(Pathfinding.UserConnection[] conns)
        {
            //
            // Disasemble & Code
            //  | 
            object val_5;
            // 0x028BE9E0: STP x24, x23, [sp, #-0x40]! | stack[1152921513272924160] = ???;  stack[1152921513272924168] = ???;  //  dest_result_addr=1152921513272924160 |  dest_result_addr=1152921513272924168
            // 0x028BE9E4: STP x22, x21, [sp, #0x10]  | stack[1152921513272924176] = ???;  stack[1152921513272924184] = ???;  //  dest_result_addr=1152921513272924176 |  dest_result_addr=1152921513272924184
            // 0x028BE9E8: STP x20, x19, [sp, #0x20]  | stack[1152921513272924192] = ???;  stack[1152921513272924200] = ???;  //  dest_result_addr=1152921513272924192 |  dest_result_addr=1152921513272924200
            // 0x028BE9EC: STP x29, x30, [sp, #0x30]  | stack[1152921513272924208] = ???;  stack[1152921513272924216] = ???;  //  dest_result_addr=1152921513272924208 |  dest_result_addr=1152921513272924216
            // 0x028BE9F0: ADD x29, sp, #0x30         | X29 = (1152921513272924160 + 48) = 1152921513272924208 (0x100000020489D830);
            // 0x028BE9F4: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BE9F8: LDRB w8, [x21, #0x93e]     | W8 = (bool)static_value_037B893E;       
            // 0x028BE9FC: MOV x20, x1                | X20 = conns;//m1                        
            val_5 = conns;
            // 0x028BEA00: MOV x19, x0                | X19 = 1152921513272936224 (0x10000002048A0720);//ML01
            // 0x028BEA04: TBNZ w8, #0, #0x28bea20    | if (static_value_037B893E == true) goto label_0;
            // 0x028BEA08: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028BEA0C: LDR x8, [x8, #0x338]       | X8 = 0x2B8EE10;                         
            // 0x028BEA10: LDR w0, [x8]               | W0 = 0x1244;                            
            // 0x028BEA14: BL #0x2782188              | X0 = sub_2782188( ?? 0x1244, ????);     
            // 0x028BEA18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BEA1C: STRB w8, [x21, #0x93e]     | static_value_037B893E = true;            //  dest_result_addr=58427710
            label_0:
            // 0x028BEA20: CBNZ x20, #0x28bea48       | if (conns != null) goto label_1;        
            if(val_5 != null)
            {
                goto label_1;
            }
            // 0x028BEA24: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028BEA28: LDR x8, [x8, #0x870]       | X8 = 1152921507462440560;               
            // 0x028BEA2C: LDR x20, [x8]              | X20 = typeof(Pathfinding.UserConnection[]);
            // 0x028BEA30: MOV x0, x20                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028BEA34: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x028BEA38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BEA3C: MOV x0, x20                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028BEA40: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x028BEA44: MOV x20, x0                | X20 = 1152921507462440560 (0x10000000AA34E670);//ML01
            val_5 = null;
            label_1:
            // 0x028BEA48: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x028BEA4C: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x028BEA50: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x028BEA54: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_10A;
            // 0x028BEA58: TBZ w8, #0, #0x28bea68     | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028BEA5C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x028BEA60: CBNZ w8, #0x28bea68        | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028BEA64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            label_3:
            // 0x028BEA68: BL #0x28bdbf8              | X0 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            System.Text.StringBuilder val_1 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            // 0x028BEA6C: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x028BEA70: LDR x23, [x19, #0x18]      | X23 = this.writerSettings; //P2         
            // 0x028BEA74: LDR x8, [x8, #0xb88]       | X8 = 1152921504755408896;               
            // 0x028BEA78: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028BEA7C: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriter);
            // 0x028BEA80: MOV x0, x8                 | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            Pathfinding.Serialization.JsonFx.JsonWriter val_2 = null;
            // 0x028BEA84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            // 0x028BEA88: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BEA8C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028BEA90: MOV x2, x23                | X2 = this.writerSettings;//m1           
            // 0x028BEA94: MOV x22, x0                | X22 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BEA98: BL #0x26da234              | .ctor(output:  val_1, settings:  this.writerSettings);
            val_2 = new Pathfinding.Serialization.JsonFx.JsonWriter(output:  val_1, settings:  this.writerSettings);
            // 0x028BEA9C: CBNZ x22, #0x28beaa4       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x028BEAA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_1, settings:  this.writerSettings), ????);
            label_4:
            // 0x028BEAA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BEAA8: MOV x0, x22                | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BEAAC: MOV x1, x20                | X1 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028BEAB0: BL #0x26d497c              | Write(value:  val_5);                   
            Write(value:  val_5);
            // 0x028BEAB4: LDR x20, [x19, #0x58]      | X20 = this.encoding; //P2               
            // 0x028BEAB8: CBNZ x21, #0x28beac0       | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x028BEABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            label_5:
            // 0x028BEAC0: LDR x8, [x21]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x028BEAC4: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x028BEAC8: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x028BEACC: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x028BEAD0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028BEAD4: CBNZ x20, #0x28beadc       | if (this.encoding != null) goto label_6;
            if(this.encoding != null)
            {
                goto label_6;
            }
            // 0x028BEAD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x028BEADC: LDR x8, [x20]              | X8 = typeof(System.Text.UTF8Encoding);  
            // 0x028BEAE0: MOV x0, x20                | X0 = this.encoding;//m1                 
            // 0x028BEAE4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028BEAE8: LDP x9, x2, [x8, #0x1c0]   | X9 = public System.Byte[] System.Text.Encoding::GetBytes(string s); X2 = public System.Byte[] System.Text.Encoding::GetBytes(string s); //  | 
            // 0x028BEAEC: BLR x9                     | X0 = this.encoding.GetBytes(s:  val_1); 
            System.Byte[] val_3 = this.encoding.GetBytes(s:  val_1);
            // 0x028BEAF0: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x028BEAF4: CBNZ x20, #0x28beafc       | if (val_3 != null) goto label_7;        
            if(val_3 != null)
            {
                goto label_7;
            }
            // 0x028BEAF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x028BEAFC: LDR w8, [x20, #0x18]       | W8 = val_3.Length; //P2                 
            // 0x028BEB00: CMP w8, #3                 | STATE = COMPARE(val_3.Length, 0x3)      
            // 0x028BEB04: B.LT #0x28beb4c            | if (val_3.Length < 3) goto label_8;     
            if(val_3.Length < 3)
            {
                goto label_8;
            }
            // 0x028BEB08: MOV x0, x19                | X0 = 1152921513272936224 (0x10000002048A0720);//ML01
            // 0x028BEB0C: MOV x1, x20                | X1 = val_3;//m1                         
            // 0x028BEB10: BL #0x28bdc84              | this.AddChecksum(bytes:  val_3);        
            this.AddChecksum(bytes:  val_3);
            // 0x028BEB14: LDR x19, [x19, #0x28]      | X19 = this.zip; //P2                    
            // 0x028BEB18: CBNZ x19, #0x28beb20       | if (this.zip != null) goto label_9;     
            if(this.zip != null)
            {
                goto label_9;
            }
            // 0x028BEB1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_9:
            // 0x028BEB20: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x028BEB24: LDR x8, [x8, #0xa98]       | X8 = (string**)(1152921513272908016)("connections.json");
            // 0x028BEB28: MOV x0, x19                | X0 = this.zip;//m1                      
            // 0x028BEB2C: MOV x2, x20                | X2 = val_3;//m1                         
            // 0x028BEB30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BEB34: LDR x1, [x8]               | X1 = "connections.json";                
            // 0x028BEB38: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028BEB3C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028BEB40: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028BEB44: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028BEB48: B #0x1983670               | X0 = this.zip.AddEntry(entryName:  "connections.json", byteContent:  val_3); return;
            Pathfinding.Ionic.Zip.ZipEntry val_4 = this.zip.AddEntry(entryName:  "connections.json", byteContent:  val_3);
            return;
            label_8:
            // 0x028BEB4C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028BEB50: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028BEB54: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028BEB58: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028BEB5C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028BE25C (42721884), len: 1096  VirtAddr: 0x028BE25C RVA: 0x028BE25C token: 100682626 methodIndex: 51163 delegateWrapperIndex: 0 methodInvoker: 0
        private byte[] SerializeMeta()
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            // 0x028BE25C: STP x24, x23, [sp, #-0x40]! | stack[1152921513273634176] = ???;  stack[1152921513273634184] = ???;  //  dest_result_addr=1152921513273634176 |  dest_result_addr=1152921513273634184
            // 0x028BE260: STP x22, x21, [sp, #0x10]  | stack[1152921513273634192] = ???;  stack[1152921513273634200] = ???;  //  dest_result_addr=1152921513273634192 |  dest_result_addr=1152921513273634200
            // 0x028BE264: STP x20, x19, [sp, #0x20]  | stack[1152921513273634208] = ???;  stack[1152921513273634216] = ???;  //  dest_result_addr=1152921513273634208 |  dest_result_addr=1152921513273634216
            // 0x028BE268: STP x29, x30, [sp, #0x30]  | stack[1152921513273634224] = ???;  stack[1152921513273634232] = ???;  //  dest_result_addr=1152921513273634224 |  dest_result_addr=1152921513273634232
            // 0x028BE26C: ADD x29, sp, #0x30         | X29 = (1152921513273634176 + 48) = 1152921513273634224 (0x100000020494ADB0);
            // 0x028BE270: SUB sp, sp, #0x10          | SP = (1152921513273634176 - 16) = 1152921513273634160 (0x100000020494AD70);
            // 0x028BE274: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028BE278: LDRB w8, [x20, #0x93f]     | W8 = (bool)static_value_037B893F;       
            // 0x028BE27C: MOV x19, x0                | X19 = 1152921513273646240 (0x100000020494DCA0);//ML01
            // 0x028BE280: TBNZ w8, #0, #0x28be29c    | if (static_value_037B893F == true) goto label_0;
            // 0x028BE284: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x028BE288: LDR x8, [x8, #0x1c0]       | X8 = 0x2B8EE00;                         
            // 0x028BE28C: LDR w0, [x8]               | W0 = 0x1240;                            
            // 0x028BE290: BL #0x2782188              | X0 = sub_2782188( ?? 0x1240, ????);     
            // 0x028BE294: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BE298: STRB w8, [x20, #0x93f]     | static_value_037B893F = true;            //  dest_result_addr=58427711
            label_0:
            // 0x028BE29C: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x028BE2A0: LDR x8, [x8, #0xe80]       | X8 = 1152921504837996544;               
            // 0x028BE2A4: LDR x0, [x8]               | X0 = typeof(AstarPath);                 
            // 0x028BE2A8: STP xzr, xzr, [sp]         | stack[1152921513273634160] = 0x0;  stack[1152921513273634168] = 0x0;  //  dest_result_addr=1152921513273634160 |  dest_result_addr=1152921513273634168
            // 0x028BE2AC: LDR x21, [x19, #0x38]      | X21 = this.meta; //P2                   
            // 0x028BE2B0: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x028BE2B4: TBZ w8, #0, #0x28be2c4     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028BE2B8: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x028BE2BC: CBNZ w8, #0x28be2c4        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028BE2C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            label_2:
            // 0x028BE2C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BE2C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE2CC: BL #0xb36d44               | X0 = AstarPath.get_Version();           
            System.Version val_1 = AstarPath.Version;
            // 0x028BE2D0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028BE2D4: CBNZ x21, #0x28be2dc       | if (this.meta != null) goto label_3;    
            if(this.meta != null)
            {
                goto label_3;
            }
            // 0x028BE2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x028BE2DC: STR x20, [x21, #0x10]      | this.meta.version = val_1;               //  dest_result_addr=0
            this.meta.version = val_1;
            // 0x028BE2E0: LDR x20, [x19, #0x38]      | X20 = this.meta; //P2                   
            // 0x028BE2E4: LDR x21, [x19, #0x10]      | X21 = this.data; //P2                   
            // 0x028BE2E8: CBNZ x21, #0x28be2f0       | if (this.data != null) goto label_4;    
            if(this.data != null)
            {
                goto label_4;
            }
            // 0x028BE2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x028BE2F0: LDR x21, [x21, #0x38]      | X21 = this.data.graphs; //P2            
            // 0x028BE2F4: CBNZ x21, #0x28be2fc       | if (this.data.graphs != null) goto label_5;
            if(this.data.graphs != null)
            {
                goto label_5;
            }
            // 0x028BE2F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x028BE2FC: CBNZ x20, #0x28be304       | if (this.meta != null) goto label_6;    
            if(this.meta != null)
            {
                goto label_6;
            }
            // 0x028BE300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x028BE304: LDR x8, [x21, #0x18]       | X8 = this.data.graphs.Length; //P2      
            // 0x028BE308: STR w8, [x20, #0x18]       | this.meta.graphs = this.data.graphs.Length;  //  dest_result_addr=0
            this.meta.graphs = this.data.graphs.Length;
            // 0x028BE30C: LDR x23, [x19, #0x38]      | X23 = this.meta; //P2                   
            // 0x028BE310: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE314: CBNZ x20, #0x28be31c       | if (this.data != null) goto label_7;    
            if(this.data != null)
            {
                goto label_7;
            }
            // 0x028BE318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_7:
            // 0x028BE31C: LDR x21, [x20, #0x38]      | X21 = this.data.graphs; //P2            
            // 0x028BE320: CBNZ x21, #0x28be328       | if (this.data.graphs != null) goto label_8;
            if(this.data.graphs != null)
            {
                goto label_8;
            }
            // 0x028BE324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_8:
            // 0x028BE328: CBNZ x23, #0x28be330       | if (this.meta != null) goto label_9;    
            if(this.meta != null)
            {
                goto label_9;
            }
            // 0x028BE32C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_9:
            // 0x028BE330: ADRP x22, #0x3680000       | X22 = 57147392 (0x3680000);             
            // 0x028BE334: LDR x22, [x22, #0x2d0]     | X22 = 1152921504948897168;              
            // 0x028BE338: LDR w21, [x21, #0x18]      | W21 = this.data.graphs.Length; //P2     
            // 0x028BE33C: LDR x20, [x22]             | X20 = typeof(System.String[]);          
            // 0x028BE340: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x028BE344: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x028BE348: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x028BE34C: MOV x1, x21                | X1 = this.data.graphs.Length;//m1       
            // 0x028BE350: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x028BE354: STR x0, [x23, #0x20]       | this.meta.guids = typeof(System.String[]);  //  dest_result_addr=0
            this.meta.guids = null;
            // 0x028BE358: LDR x23, [x19, #0x38]      | X23 = this.meta; //P2                   
            // 0x028BE35C: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE360: CBNZ x20, #0x28be368       | if (this.data != null) goto label_10;   
            if(this.data != null)
            {
                goto label_10;
            }
            // 0x028BE364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_10:
            // 0x028BE368: LDR x21, [x20, #0x38]      | X21 = this.data.graphs; //P2            
            // 0x028BE36C: CBNZ x21, #0x28be374       | if (this.data.graphs != null) goto label_11;
            if(this.data.graphs != null)
            {
                goto label_11;
            }
            // 0x028BE370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_11:
            // 0x028BE374: CBNZ x23, #0x28be37c       | if (this.meta != null) goto label_12;   
            if(this.meta != null)
            {
                goto label_12;
            }
            // 0x028BE378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_12:
            // 0x028BE37C: LDR x20, [x22]             | X20 = typeof(System.String[]);          
            // 0x028BE380: LDR w21, [x21, #0x18]      | W21 = this.data.graphs.Length; //P2     
            // 0x028BE384: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x028BE388: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x028BE38C: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x028BE390: MOV x1, x21                | X1 = this.data.graphs.Length;//m1       
            // 0x028BE394: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x028BE398: STR x0, [x23, #0x28]       | this.meta.typeNames = typeof(System.String[]);  //  dest_result_addr=0
            this.meta.typeNames = null;
            // 0x028BE39C: LDR x22, [x19, #0x38]      | X22 = this.meta; //P2                   
            // 0x028BE3A0: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE3A4: CBNZ x20, #0x28be3ac       | if (this.data != null) goto label_13;   
            if(this.data != null)
            {
                goto label_13;
            }
            // 0x028BE3A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_13:
            // 0x028BE3AC: LDR x21, [x20, #0x38]      | X21 = this.data.graphs; //P2            
            // 0x028BE3B0: CBNZ x21, #0x28be3b8       | if (this.data.graphs != null) goto label_14;
            if(this.data.graphs != null)
            {
                goto label_14;
            }
            // 0x028BE3B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_14:
            // 0x028BE3B8: CBNZ x22, #0x28be3c0       | if (this.meta != null) goto label_15;   
            if(this.meta != null)
            {
                goto label_15;
            }
            // 0x028BE3BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_15:
            // 0x028BE3C0: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x028BE3C4: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x028BE3C8: LDR w21, [x21, #0x18]      | W21 = this.data.graphs.Length; //P2     
            // 0x028BE3CC: LDR x20, [x8]              | X20 = typeof(System.Int32[]);           
            // 0x028BE3D0: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x028BE3D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
            // 0x028BE3D8: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x028BE3DC: MOV x1, x21                | X1 = this.data.graphs.Length;//m1       
            // 0x028BE3E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
            // 0x028BE3E4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x028BE3E8: STR x0, [x22, #0x30]       | this.meta.nodeCounts = typeof(System.Int32[]);  //  dest_result_addr=0
            this.meta.nodeCounts = null;
            // 0x028BE3EC: B #0x28be3f4               |  goto label_16;                         
            goto label_16;
            label_43:
            // 0x028BE3F0: ADD w21, w21, #1           | W21 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            label_16:
            // 0x028BE3F4: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE3F8: CBNZ x20, #0x28be400       | if (this.data != null) goto label_17;   
            if(this.data != null)
            {
                goto label_17;
            }
            // 0x028BE3FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_17:
            // 0x028BE400: LDR x20, [x20, #0x38]      | X20 = this.data.graphs; //P2            
            // 0x028BE404: CBNZ x20, #0x28be40c       | if (this.data.graphs != null) goto label_18;
            if(this.data.graphs != null)
            {
                goto label_18;
            }
            // 0x028BE408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_18:
            // 0x028BE40C: LDR w8, [x20, #0x18]       | W8 = this.data.graphs.Length; //P2      
            // 0x028BE410: CMP w21, w8                | STATE = COMPARE(0x1, this.data.graphs.Length)
            // 0x028BE414: B.GE #0x28be5e0            | if (val_7 >= this.data.graphs.Length) goto label_19;
            if(val_7 >= this.data.graphs.Length)
            {
                goto label_19;
            }
            // 0x028BE418: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE41C: CBNZ x20, #0x28be424       | if (this.data != null) goto label_20;   
            if(this.data != null)
            {
                goto label_20;
            }
            // 0x028BE420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_20:
            // 0x028BE424: LDR x20, [x20, #0x38]      | X20 = this.data.graphs; //P2            
            // 0x028BE428: CBNZ x20, #0x28be430       | if (this.data.graphs != null) goto label_21;
            if(this.data.graphs != null)
            {
                goto label_21;
            }
            // 0x028BE42C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_21:
            // 0x028BE430: LDR w8, [x20, #0x18]       | W8 = this.data.graphs.Length; //P2      
            // 0x028BE434: SXTW x22, w21              | X22 = 1 (0x00000001);                   
            // 0x028BE438: CMP w21, w8                | STATE = COMPARE(0x1, this.data.graphs.Length)
            // 0x028BE43C: B.LO #0x28be44c            | if (val_7 < this.data.graphs.Length) goto label_22;
            if(val_7 < this.data.graphs.Length)
            {
                goto label_22;
            }
            // 0x028BE440: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Int32[]), ????);
            // 0x028BE444: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE448: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Int32[]), ????);
            label_22:
            // 0x028BE44C: ADD x8, x20, x22, lsl #3   | X8 = this.data.graphs[0x1]; //PARR1     
            // 0x028BE450: LDR x8, [x8, #0x20]        | X8 = this.data.graphs[0x1][0]           
            Pathfinding.NavGraph val_7 = this.data.graphs[1];
            // 0x028BE454: CBZ x8, #0x28be3f0         | if (this.data.graphs[0x1][0] == null) goto label_43;
            if(val_7 == null)
            {
                goto label_43;
            }
            // 0x028BE458: LDR x20, [x19, #0x38]      | X20 = this.meta; //P2                   
            // 0x028BE45C: CBNZ x20, #0x28be464       | if (this.meta != null) goto label_24;   
            if(this.meta != null)
            {
                goto label_24;
            }
            // 0x028BE460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_24:
            // 0x028BE464: LDR x23, [x20, #0x20]      | X23 = this.meta.guids; //P2             
            // 0x028BE468: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE46C: CBNZ x20, #0x28be474       | if (this.data != null) goto label_25;   
            if(this.data != null)
            {
                goto label_25;
            }
            // 0x028BE470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_25:
            // 0x028BE474: LDR x20, [x20, #0x38]      | X20 = this.data.graphs; //P2            
            // 0x028BE478: CBNZ x20, #0x28be480       | if (this.data.graphs != null) goto label_26;
            if(this.data.graphs != null)
            {
                goto label_26;
            }
            // 0x028BE47C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_26:
            // 0x028BE480: LDR w8, [x20, #0x18]       | W8 = this.data.graphs.Length; //P2      
            // 0x028BE484: CMP w21, w8                | STATE = COMPARE(0x1, this.data.graphs.Length)
            // 0x028BE488: B.LO #0x28be498            | if (val_7 < this.data.graphs.Length) goto label_27;
            if(val_7 < this.data.graphs.Length)
            {
                goto label_27;
            }
            // 0x028BE48C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Int32[]), ????);
            // 0x028BE490: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE494: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Int32[]), ????);
            label_27:
            // 0x028BE498: ADD x8, x20, x22, lsl #3   | X8 = this.data.graphs[0x1]; //PARR1     
            // 0x028BE49C: LDR x20, [x8, #0x20]       | X20 = this.data.graphs[0x1][0]          
            Pathfinding.NavGraph val_8 = this.data.graphs[1];
            // 0x028BE4A0: CBNZ x20, #0x28be4a8       | if (this.data.graphs[0x1][0] != null) goto label_28;
            if(val_8 != null)
            {
                goto label_28;
            }
            // 0x028BE4A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Int32[]), ????);
            label_28:
            // 0x028BE4A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE4AC: MOV x0, x20                | X0 = this.data.graphs[0x1][0];//m1      
            // 0x028BE4B0: BL #0x155d0d0              | X0 = this.data.graphs[0x1][0].get_guid();
            Pathfinding.Util.Guid val_2 = val_8.guid;
            // 0x028BE4B4: STP x0, x1, [sp]           | stack[1152921513273634160] = val_2._a;  stack[1152921513273634168] = val_2._b;  //  dest_result_addr=1152921513273634160 |  dest_result_addr=1152921513273634168
            // 0x028BE4B8: MOV x0, sp                 | X0 = 1152921513273634160 (0x100000020494AD70);//ML01
            // 0x028BE4BC: BL #0x28beb60              | X0 = label_Pathfinding_Serialization_AstarSerializer_SerializeUserConnections_GL028BEB60();
            // 0x028BE4C0: MOV x20, x0                | X20 = 1152921513273634160 (0x100000020494AD70);//ML01
            // 0x028BE4C4: CBNZ x23, #0x28be4cc       | if (this.meta.guids != null) goto label_29;
            if(this.meta.guids != null)
            {
                goto label_29;
            }
            // 0x028BE4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000020494AD70, ????);
            label_29:
            // 0x028BE4CC: CBZ x20, #0x28be4f0        | if (val_2._a == 0) goto label_31;       
            if(val_2._a == 0)
            {
                goto label_31;
            }
            // 0x028BE4D0: LDR x8, [x23]              | X8 = typeof(System.String[]);           
            // 0x028BE4D4: MOV x0, x20                | X0 = 1152921513273634160 (0x100000020494AD70);//ML01
            // 0x028BE4D8: LDR x1, [x8, #0x30]        | X1 = System.String[].__il2cppRuntimeField_element_class;
            // 0x028BE4DC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x100000020494AD70, ????);
            // 0x028BE4E0: CBNZ x0, #0x28be4f0        | if (val_2._a != 0) goto label_31;       
            if(val_2._a != 0)
            {
                goto label_31;
            }
            // 0x028BE4E4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x100000020494AD70, ????);
            // 0x028BE4E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE4EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000020494AD70, ????);
            label_31:
            // 0x028BE4F0: LDR w8, [x23, #0x18]       | W8 = this.meta.guids.Length; //P2       
            // 0x028BE4F4: CMP w21, w8                | STATE = COMPARE(0x1, this.meta.guids.Length)
            // 0x028BE4F8: B.LO #0x28be508            | if (val_7 < this.meta.guids.Length) goto label_32;
            if(val_7 < this.meta.guids.Length)
            {
                goto label_32;
            }
            // 0x028BE4FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x100000020494AD70, ????);
            // 0x028BE500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE504: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000020494AD70, ????);
            label_32:
            // 0x028BE508: ADD x8, x23, x22, lsl #3   | X8 = this.meta.guids[0x1]; //PARR1      
            // 0x028BE50C: STR x20, [x8, #0x20]       | this.meta.guids[0x1][0] = 0x100000020494AD70;  //  dest_result_addr=0
            this.meta.guids[1] = ;
            // 0x028BE510: LDR x20, [x19, #0x38]      | X20 = this.meta; //P2                   
            // 0x028BE514: CBNZ x20, #0x28be51c       | if (this.meta != null) goto label_33;   
            if(this.meta != null)
            {
                goto label_33;
            }
            // 0x028BE518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000020494AD70, ????);
            label_33:
            // 0x028BE51C: LDR x23, [x20, #0x28]      | X23 = this.meta.typeNames; //P2         
            // 0x028BE520: LDR x20, [x19, #0x10]      | X20 = this.data; //P2                   
            // 0x028BE524: CBNZ x20, #0x28be52c       | if (this.data != null) goto label_34;   
            if(this.data != null)
            {
                goto label_34;
            }
            // 0x028BE528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000020494AD70, ????);
            label_34:
            // 0x028BE52C: LDR x20, [x20, #0x38]      | X20 = this.data.graphs; //P2            
            // 0x028BE530: CBNZ x20, #0x28be538       | if (this.data.graphs != null) goto label_35;
            if(this.data.graphs != null)
            {
                goto label_35;
            }
            // 0x028BE534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000020494AD70, ????);
            label_35:
            // 0x028BE538: LDR w8, [x20, #0x18]       | W8 = this.data.graphs.Length; //P2      
            // 0x028BE53C: CMP w21, w8                | STATE = COMPARE(0x1, this.data.graphs.Length)
            // 0x028BE540: B.LO #0x28be550            | if (val_7 < this.data.graphs.Length) goto label_36;
            if(val_7 < this.data.graphs.Length)
            {
                goto label_36;
            }
            // 0x028BE544: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x100000020494AD70, ????);
            // 0x028BE548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE54C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000020494AD70, ????);
            label_36:
            // 0x028BE550: ADD x8, x20, x22, lsl #3   | X8 = this.data.graphs[0x1]; //PARR1     
            // 0x028BE554: LDR x20, [x8, #0x20]       | X20 = this.data.graphs[0x1][0]          
            Pathfinding.NavGraph val_9 = this.data.graphs[1];
            // 0x028BE558: CBNZ x20, #0x28be560       | if (this.data.graphs[0x1][0] != null) goto label_37;
            if(val_9 != null)
            {
                goto label_37;
            }
            // 0x028BE55C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000020494AD70, ????);
            label_37:
            // 0x028BE560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE564: MOV x0, x20                | X0 = this.data.graphs[0x1][0];//m1      
            // 0x028BE568: BL #0x16fb28c              | X0 = this.data.graphs[0x1][0].GetType();
            System.Type val_3 = val_9.GetType();
            // 0x028BE56C: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x028BE570: CBNZ x20, #0x28be578       | if (val_3 != null) goto label_38;       
            if(val_3 != null)
            {
                goto label_38;
            }
            // 0x028BE574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_38:
            // 0x028BE578: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028BE57C: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028BE580: LDR x9, [x8, #0x230]       | X9 = typeof(System.Type).__il2cppRuntimeField_230;
            // 0x028BE584: LDR x1, [x8, #0x238]       | X1 = typeof(System.Type).__il2cppRuntimeField_238;
            // 0x028BE588: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_230();
            // 0x028BE58C: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x028BE590: CBNZ x23, #0x28be598       | if (this.meta.typeNames != null) goto label_39;
            if(this.meta.typeNames != null)
            {
                goto label_39;
            }
            // 0x028BE594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_39:
            // 0x028BE598: CBZ x20, #0x28be5bc        | if (val_3 == null) goto label_41;       
            if(val_3 == null)
            {
                goto label_41;
            }
            // 0x028BE59C: LDR x8, [x23]              | X8 = typeof(System.String[]);           
            // 0x028BE5A0: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028BE5A4: LDR x1, [x8, #0x30]        | X1 = System.String[].__il2cppRuntimeField_element_class;
            // 0x028BE5A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028BE5AC: CBNZ x0, #0x28be5bc        | if (val_3 != null) goto label_41;       
            if(val_3 != null)
            {
                goto label_41;
            }
            // 0x028BE5B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x028BE5B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE5B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_41:
            // 0x028BE5BC: LDR w8, [x23, #0x18]       | W8 = this.meta.typeNames.Length; //P2   
            // 0x028BE5C0: CMP w21, w8                | STATE = COMPARE(0x1, this.meta.typeNames.Length)
            // 0x028BE5C4: B.LO #0x28be5d4            | if (val_7 < this.meta.typeNames.Length) goto label_42;
            if(val_7 < this.meta.typeNames.Length)
            {
                goto label_42;
            }
            // 0x028BE5C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x028BE5CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BE5D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_42:
            // 0x028BE5D4: ADD x8, x23, x22, lsl #3   | X8 = this.meta.typeNames[0x1]; //PARR1  
            // 0x028BE5D8: STR x20, [x8, #0x20]       | this.meta.typeNames[0x1][0] = val_3;     //  dest_result_addr=0
            this.meta.typeNames[1] = val_3;
            // 0x028BE5DC: B #0x28be3f0               |  goto label_43;                         
            goto label_43;
            label_19:
            // 0x028BE5E0: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x028BE5E4: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x028BE5E8: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x028BE5EC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_10A;
            // 0x028BE5F0: TBZ w8, #0, #0x28be600     | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x028BE5F4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x028BE5F8: CBNZ w8, #0x28be600        | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x028BE5FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            label_45:
            // 0x028BE600: BL #0x28bdbf8              | X0 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            System.Text.StringBuilder val_4 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            // 0x028BE604: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x028BE608: LDR x22, [x19, #0x18]      | X22 = this.writerSettings; //P2         
            // 0x028BE60C: LDR x8, [x8, #0xb88]       | X8 = 1152921504755408896;               
            // 0x028BE610: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x028BE614: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriter);
            // 0x028BE618: MOV x0, x8                 | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            Pathfinding.Serialization.JsonFx.JsonWriter val_5 = null;
            // 0x028BE61C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            // 0x028BE620: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BE624: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x028BE628: MOV x2, x22                | X2 = this.writerSettings;//m1           
            // 0x028BE62C: MOV x21, x0                | X21 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BE630: BL #0x26da234              | .ctor(output:  val_4, settings:  this.writerSettings);
            val_5 = new Pathfinding.Serialization.JsonFx.JsonWriter(output:  val_4, settings:  this.writerSettings);
            // 0x028BE634: LDR x22, [x19, #0x38]      | X22 = this.meta; //P2                   
            // 0x028BE638: CBNZ x21, #0x28be640       | if ( != 0) goto label_46;               
            if(null != 0)
            {
                goto label_46;
            }
            // 0x028BE63C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_4, settings:  this.writerSettings), ????);
            label_46:
            // 0x028BE640: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BE644: MOV x0, x21                | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BE648: MOV x1, x22                | X1 = this.meta;//m1                     
            // 0x028BE64C: BL #0x26d497c              | Write(value:  this.meta);               
            Write(value:  this.meta);
            // 0x028BE650: LDR x19, [x19, #0x58]      | X19 = this.encoding; //P2               
            // 0x028BE654: CBNZ x20, #0x28be65c       | if (val_4 != null) goto label_47;       
            if(val_4 != null)
            {
                goto label_47;
            }
            // 0x028BE658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            label_47:
            // 0x028BE65C: LDR x8, [x20]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x028BE660: MOV x0, x20                | X0 = val_4;//m1                         
            // 0x028BE664: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x028BE668: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x028BE66C: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x028BE670: CBNZ x19, #0x28be678       | if (this.encoding != null) goto label_48;
            if(this.encoding != null)
            {
                goto label_48;
            }
            // 0x028BE674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_48:
            // 0x028BE678: LDR x8, [x19]              | X8 = typeof(System.Text.UTF8Encoding);  
            // 0x028BE67C: MOV x0, x19                | X0 = this.encoding;//m1                 
            // 0x028BE680: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x028BE684: LDP x9, x2, [x8, #0x1c0]   | X9 = public System.Byte[] System.Text.Encoding::GetBytes(string s); X2 = public System.Byte[] System.Text.Encoding::GetBytes(string s); //  | 
            // 0x028BE688: BLR x9                     | X0 = this.encoding.GetBytes(s:  val_4); 
            System.Byte[] val_6 = this.encoding.GetBytes(s:  val_4);
            // 0x028BE68C: SUB sp, x29, #0x30         | SP = (1152921513273634224 - 48) = 1152921513273634176 (0x100000020494AD80);
            // 0x028BE690: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028BE694: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028BE698: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028BE69C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028BE6A0: RET                        |  return (System.Byte[])val_6;           
            return val_6;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028BE8E8 (42723560), len: 248  VirtAddr: 0x028BE8E8 RVA: 0x028BE8E8 token: 100682627 methodIndex: 51164 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] Serialize(Pathfinding.NavGraph graph)
        {
            //
            // Disasemble & Code
            // 0x028BE8E8: STP x24, x23, [sp, #-0x40]! | stack[1152921513274266368] = ???;  stack[1152921513274266376] = ???;  //  dest_result_addr=1152921513274266368 |  dest_result_addr=1152921513274266376
            // 0x028BE8EC: STP x22, x21, [sp, #0x10]  | stack[1152921513274266384] = ???;  stack[1152921513274266392] = ???;  //  dest_result_addr=1152921513274266384 |  dest_result_addr=1152921513274266392
            // 0x028BE8F0: STP x20, x19, [sp, #0x20]  | stack[1152921513274266400] = ???;  stack[1152921513274266408] = ???;  //  dest_result_addr=1152921513274266400 |  dest_result_addr=1152921513274266408
            // 0x028BE8F4: STP x29, x30, [sp, #0x30]  | stack[1152921513274266416] = ???;  stack[1152921513274266424] = ???;  //  dest_result_addr=1152921513274266416 |  dest_result_addr=1152921513274266424
            // 0x028BE8F8: ADD x29, sp, #0x30         | X29 = (1152921513274266368 + 48) = 1152921513274266416 (0x10000002049E5330);
            // 0x028BE8FC: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BE900: LDRB w8, [x21, #0x940]     | W8 = (bool)static_value_037B8940;       
            // 0x028BE904: MOV x20, x1                | X20 = graph;//m1                        
            // 0x028BE908: MOV x19, x0                | X19 = 1152921513274278432 (0x10000002049E8220);//ML01
            // 0x028BE90C: TBNZ w8, #0, #0x28be928    | if (static_value_037B8940 == true) goto label_0;
            // 0x028BE910: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x028BE914: LDR x8, [x8, #0x430]       | X8 = 0x2B8EDF0;                         
            // 0x028BE918: LDR w0, [x8]               | W0 = 0x123C;                            
            // 0x028BE91C: BL #0x2782188              | X0 = sub_2782188( ?? 0x123C, ????);     
            // 0x028BE920: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BE924: STRB w8, [x21, #0x940]     | static_value_037B8940 = true;            //  dest_result_addr=58427712
            label_0:
            // 0x028BE928: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x028BE92C: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x028BE930: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x028BE934: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_10A;
            // 0x028BE938: TBZ w8, #0, #0x28be948     | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028BE93C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x028BE940: CBNZ w8, #0x28be948        | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028BE944: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            label_2:
            // 0x028BE948: BL #0x28bdbf8              | X0 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            System.Text.StringBuilder val_1 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            // 0x028BE94C: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x028BE950: LDR x23, [x19, #0x18]      | X23 = this.writerSettings; //P2         
            // 0x028BE954: LDR x8, [x8, #0xb88]       | X8 = 1152921504755408896;               
            // 0x028BE958: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028BE95C: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriter);
            // 0x028BE960: MOV x0, x8                 | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            Pathfinding.Serialization.JsonFx.JsonWriter val_2 = null;
            // 0x028BE964: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            // 0x028BE968: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BE96C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028BE970: MOV x2, x23                | X2 = this.writerSettings;//m1           
            // 0x028BE974: MOV x22, x0                | X22 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BE978: BL #0x26da234              | .ctor(output:  val_1, settings:  this.writerSettings);
            val_2 = new Pathfinding.Serialization.JsonFx.JsonWriter(output:  val_1, settings:  this.writerSettings);
            // 0x028BE97C: CBNZ x22, #0x28be984       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x028BE980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_1, settings:  this.writerSettings), ????);
            label_3:
            // 0x028BE984: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BE988: MOV x0, x22                | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BE98C: MOV x1, x20                | X1 = graph;//m1                         
            // 0x028BE990: BL #0x26d497c              | Write(value:  graph);                   
            Write(value:  graph);
            // 0x028BE994: LDR x19, [x19, #0x58]      | X19 = this.encoding; //P2               
            // 0x028BE998: CBNZ x21, #0x28be9a0       | if (val_1 != null) goto label_4;        
            if(val_1 != null)
            {
                goto label_4;
            }
            // 0x028BE99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            label_4:
            // 0x028BE9A0: LDR x8, [x21]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x028BE9A4: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x028BE9A8: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x028BE9AC: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x028BE9B0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028BE9B4: CBNZ x19, #0x28be9bc       | if (this.encoding != null) goto label_5;
            if(this.encoding != null)
            {
                goto label_5;
            }
            // 0x028BE9B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x028BE9BC: LDR x8, [x19]              | X8 = typeof(System.Text.UTF8Encoding);  
            // 0x028BE9C0: MOV x0, x19                | X0 = this.encoding;//m1                 
            // 0x028BE9C4: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028BE9C8: LDP x3, x2, [x8, #0x1c0]   | X3 = public System.Byte[] System.Text.Encoding::GetBytes(string s); X2 = public System.Byte[] System.Text.Encoding::GetBytes(string s); //  | 
            // 0x028BE9CC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028BE9D0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028BE9D4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028BE9D8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028BE9DC: BR x3                      | return this.encoding.GetBytes(s:  val_1);
            return this.encoding.GetBytes(s:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x028BED90 (42724752), len: 572  VirtAddr: 0x028BED90 RVA: 0x028BED90 token: 100682628 methodIndex: 51165 delegateWrapperIndex: 0 methodInvoker: 0
        public void SerializeNodes()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_9;
            //  | 
            object val_10;
            //  | 
            string val_11;
            //  | 
            object val_12;
            // 0x028BED90: STP x28, x27, [sp, #-0x60]! | stack[1152921513274617344] = ???;  stack[1152921513274617352] = ???;  //  dest_result_addr=1152921513274617344 |  dest_result_addr=1152921513274617352
            // 0x028BED94: STP x26, x25, [sp, #0x10]  | stack[1152921513274617360] = ???;  stack[1152921513274617368] = ???;  //  dest_result_addr=1152921513274617360 |  dest_result_addr=1152921513274617368
            // 0x028BED98: STP x24, x23, [sp, #0x20]  | stack[1152921513274617376] = ???;  stack[1152921513274617384] = ???;  //  dest_result_addr=1152921513274617376 |  dest_result_addr=1152921513274617384
            // 0x028BED9C: STP x22, x21, [sp, #0x30]  | stack[1152921513274617392] = ???;  stack[1152921513274617400] = ???;  //  dest_result_addr=1152921513274617392 |  dest_result_addr=1152921513274617400
            // 0x028BEDA0: STP x20, x19, [sp, #0x40]  | stack[1152921513274617408] = ???;  stack[1152921513274617416] = ???;  //  dest_result_addr=1152921513274617408 |  dest_result_addr=1152921513274617416
            // 0x028BEDA4: STP x29, x30, [sp, #0x50]  | stack[1152921513274617424] = ???;  stack[1152921513274617432] = ???;  //  dest_result_addr=1152921513274617424 |  dest_result_addr=1152921513274617432
            // 0x028BEDA8: ADD x29, sp, #0x50         | X29 = (1152921513274617344 + 80) = 1152921513274617424 (0x1000000204A3AE50);
            // 0x028BEDAC: SUB sp, sp, #0x10          | SP = (1152921513274617344 - 16) = 1152921513274617328 (0x1000000204A3ADF0);
            // 0x028BEDB0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028BEDB4: LDRB w8, [x20, #0x941]     | W8 = (bool)static_value_037B8941;       
            // 0x028BEDB8: MOV x19, x0                | X19 = 1152921513274629440 (0x1000000204A3DD40);//ML01
            // 0x028BEDBC: TBNZ w8, #0, #0x28bedd8    | if (static_value_037B8941 == true) goto label_0;
            // 0x028BEDC0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028BEDC4: LDR x8, [x8, #0x540]       | X8 = 0x2B8EE0C;                         
            // 0x028BEDC8: LDR w0, [x8]               | W0 = 0x1243;                            
            // 0x028BEDCC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1243, ????);     
            // 0x028BEDD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BEDD4: STRB w8, [x20, #0x941]     | static_value_037B8941 = true;            //  dest_result_addr=58427713
            label_0:
            // 0x028BEDD8: LDR x20, [x19, #0x40]      | X20 = this.settings; //P2               
            // 0x028BEDDC: CBNZ x20, #0x28bede4       | if (this.settings != null) goto label_1;
            if(this.settings != null)
            {
                goto label_1;
            }
            // 0x028BEDE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1243, ????);     
            label_1:
            // 0x028BEDE4: LDRB w8, [x20, #0x10]      | W8 = this.settings.nodes; //P2          
            // 0x028BEDE8: CBZ w8, #0x28bef6c         | if (this.settings.nodes == false) goto label_13;
            if(this.settings.nodes == false)
            {
                goto label_13;
            }
            // 0x028BEDEC: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            val_9 = this.graphs;
            // 0x028BEDF0: CBZ x20, #0x28bef8c        | if (this.graphs == null) goto label_3;  
            if(val_9 == null)
            {
                goto label_3;
            }
            // 0x028BEDF4: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
            // 0x028BEDF8: ADRP x24, #0x35d6000       | X24 = 56451072 (0x35D6000);             
            // 0x028BEDFC: ADRP x25, #0x3684000       | X25 = 57163776 (0x3684000);             
            // 0x028BEE00: ADRP x27, #0x3665000       | X27 = 57036800 (0x3665000);             
            // 0x028BEE04: LDR x23, [x23, #0x140]     | X23 = 1152921504607113216;              
            // 0x028BEE08: LDR x24, [x24, #0xe38]     | X24 = 1152921504608284672;              
            // 0x028BEE0C: LDR x25, [x25, #0x390]     | X25 = (string**)(1152921513124056064)("graph");
            // 0x028BEE10: LDR x27, [x27, #0xdb0]     | X27 = (string**)(1152921513274423776)("_nodes.binary");
            // 0x028BEE14: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x028BEE18: B #0x28bee38               |  goto label_4;                          
            goto label_4;
            label_10:
            // 0x028BEE1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BEE20: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028BEE24: MOV x1, x22                | X1 = X22;//m1                           
            val_11 = X22;
            // 0x028BEE28: MOV x2, x20                | X2 = this.graphs;//m1                   
            // 0x028BEE2C: BL #0x1983670              | X0 = X21.AddEntry(entryName:  val_11 = X22, byteContent:  val_9);
            Pathfinding.Ionic.Zip.ZipEntry val_1 = X21.AddEntry(entryName:  val_11, byteContent:  val_9);
            // 0x028BEE30: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            val_9 = this.graphs;
            // 0x028BEE34: ADD w26, w26, #1           | W26 = (val_10 + 1) = val_10 (0x00000001);
            val_10 = 1;
            label_4:
            // 0x028BEE38: CBNZ x20, #0x28bee40       | if (this.graphs != null) goto label_5;  
            if(val_9 != null)
            {
                goto label_5;
            }
            // 0x028BEE3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x028BEE40: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BEE44: CMP w26, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BEE48: B.GE #0x28beebc            | if (val_10 >= this.graphs.Length) goto label_6;
            if(val_10 >= this.graphs.Length)
            {
                goto label_6;
            }
            // 0x028BEE4C: BL #0x28befcc              | X0 = val_1.SerializeNodes(index:  val_11);
            System.Byte[] val_2 = val_1.SerializeNodes(index:  val_11);
            // 0x028BEE50: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028BEE54: MOV x0, x19                | X0 = 1152921513274629440 (0x1000000204A3DD40);//ML01
            // 0x028BEE58: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028BEE5C: BL #0x28bdc84              | this.AddChecksum(bytes:  val_2);        
            this.AddChecksum(bytes:  val_2);
            // 0x028BEE60: LDR x0, [x23]              | X0 = typeof(System.Int32);              
            // 0x028BEE64: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BEE68: ADD x1, sp, #0xc           | X1 = (1152921513274617328 + 12) = 1152921513274617340 (0x1000000204A3ADFC);
            // 0x028BEE6C: STR w26, [sp, #0xc]        | stack[1152921513274617340] = 0x1;        //  dest_result_addr=1152921513274617340
            // 0x028BEE70: BL #0x27bc028              | X0 = 1152921513274784320 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028BEE74: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x028BEE78: MOV x22, x0                | X22 = 1152921513274784320 (0x1000000204A63A40);//ML01
            // 0x028BEE7C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028BEE80: TBZ w9, #0, #0x28bee94     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028BEE84: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028BEE88: CBNZ w9, #0x28bee94        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028BEE8C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028BEE90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x028BEE94: LDR x1, [x25]              | X1 = "graph";                           
            // 0x028BEE98: LDR x3, [x27]              | X3 = "_nodes.binary";                   
            // 0x028BEE9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BEEA0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028BEEA4: MOV x2, x22                | X2 = 1152921513274784320 (0x1000000204A63A40);//ML01
            // 0x028BEEA8: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_10);
            string val_3 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_10);
            // 0x028BEEAC: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x028BEEB0: CBNZ x21, #0x28bee1c       | if (this.zip != null) goto label_10;    
            if(this.zip != null)
            {
                goto label_10;
            }
            // 0x028BEEB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x028BEEB8: B #0x28bee1c               |  goto label_10;                         
            goto label_10;
            label_6:
            // 0x028BEEBC: ADRP x27, #0x35e1000       | X27 = 56496128 (0x35E1000);             
            // 0x028BEEC0: LDR x27, [x27, #0xd00]     | X27 = (string**)(1152921513274513984)("_conns.binary");
            // 0x028BEEC4: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x028BEEC8: B #0x28beee4               |  goto label_11;                         
            goto label_11;
            label_17:
            // 0x028BEECC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BEED0: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028BEED4: MOV x1, x22                | X1 = X22;//m1                           
            val_11 = X22;
            // 0x028BEED8: MOV x2, x20                | X2 = this.graphs;//m1                   
            // 0x028BEEDC: BL #0x1983670              | X0 = X21.AddEntry(entryName:  val_11 = X22, byteContent:  val_9);
            Pathfinding.Ionic.Zip.ZipEntry val_4 = X21.AddEntry(entryName:  val_11, byteContent:  val_9);
            // 0x028BEEE0: ADD w26, w26, #1           | W26 = (val_12 + 1) = val_12 (0x00000001);
            val_12 = 1;
            label_11:
            // 0x028BEEE4: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028BEEE8: CBNZ x20, #0x28beef0       | if (this.graphs != null) goto label_12; 
            if(this.graphs != null)
            {
                goto label_12;
            }
            // 0x028BEEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x028BEEF0: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BEEF4: CMP w26, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BEEF8: B.GE #0x28bef6c            | if (val_12 >= this.graphs.Length) goto label_13;
            if(val_12 >= this.graphs.Length)
            {
                goto label_13;
            }
            // 0x028BEEFC: BL #0x28bf024              | X0 = val_4.SerializeNodeConnections(index:  val_11);
            System.Byte[] val_5 = val_4.SerializeNodeConnections(index:  val_11);
            // 0x028BEF00: MOV x20, x0                | X20 = val_5;//m1                        
            // 0x028BEF04: MOV x0, x19                | X0 = 1152921513274629440 (0x1000000204A3DD40);//ML01
            // 0x028BEF08: MOV x1, x20                | X1 = val_5;//m1                         
            // 0x028BEF0C: BL #0x28bdc84              | this.AddChecksum(bytes:  val_5);        
            this.AddChecksum(bytes:  val_5);
            // 0x028BEF10: LDR x0, [x23]              | X0 = typeof(System.Int32);              
            // 0x028BEF14: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BEF18: ADD x1, sp, #8             | X1 = (1152921513274617328 + 8) = 1152921513274617336 (0x1000000204A3ADF8);
            // 0x028BEF1C: STR w26, [sp, #8]          | stack[1152921513274617336] = 0x1;        //  dest_result_addr=1152921513274617336
            // 0x028BEF20: BL #0x27bc028              | X0 = 1152921513274874432 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028BEF24: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x028BEF28: MOV x22, x0                | X22 = 1152921513274874432 (0x1000000204A79A40);//ML01
            // 0x028BEF2C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028BEF30: TBZ w9, #0, #0x28bef44     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x028BEF34: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028BEF38: CBNZ w9, #0x28bef44        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x028BEF3C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028BEF40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_15:
            // 0x028BEF44: LDR x1, [x25]              | X1 = "graph";                           
            // 0x028BEF48: LDR x3, [x27]              | X3 = "_conns.binary";                   
            // 0x028BEF4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BEF50: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028BEF54: MOV x2, x22                | X2 = 1152921513274874432 (0x1000000204A79A40);//ML01
            // 0x028BEF58: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_12);
            string val_6 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_12);
            // 0x028BEF5C: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x028BEF60: CBNZ x21, #0x28beecc       | if (this.zip != null) goto label_17;    
            if(this.zip != null)
            {
                goto label_17;
            }
            // 0x028BEF64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x028BEF68: B #0x28beecc               |  goto label_17;                         
            goto label_17;
            label_13:
            // 0x028BEF6C: SUB sp, x29, #0x50         | SP = (1152921513274617424 - 80) = 1152921513274617344 (0x1000000204A3AE00);
            // 0x028BEF70: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028BEF74: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028BEF78: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028BEF7C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028BEF80: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028BEF84: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028BEF88: RET                        |  return;                                
            return;
            label_3:
            // 0x028BEF8C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x028BEF90: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x028BEF94: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_7 = null;
            // 0x028BEF98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x028BEF9C: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x028BEFA0: LDR x8, [x8, #0x340]       | X8 = (string**)(1152921513274604192)("Cannot serialize nodes with no serialized graphs (call SerializeGraphs first)");
            // 0x028BEFA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BEFA8: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x028BEFAC: LDR x1, [x8]               | X1 = "Cannot serialize nodes with no serialized graphs (call SerializeGraphs first)";
            // 0x028BEFB0: BL #0x1e6648c              | .ctor(message:  "Cannot serialize nodes with no serialized graphs (call SerializeGraphs first)");
            val_7 = new System.InvalidOperationException(message:  "Cannot serialize nodes with no serialized graphs (call SerializeGraphs first)");
            // 0x028BEFB4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x028BEFB8: LDR x8, [x8, #0xe40]       | X8 = 1152921513274604416;               
            // 0x028BEFBC: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x028BEFC0: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Serialization.AstarSerializer::SerializeNodes();
            // 0x028BEFC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x028BEFC8: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_8 = MoveNext();
        
        }
        //
        // Offset in libil2cpp.so: 0x028BEFCC (42725324), len: 88  VirtAddr: 0x028BEFCC RVA: 0x028BEFCC token: 100682629 methodIndex: 51166 delegateWrapperIndex: 0 methodInvoker: 0
        private byte[] SerializeNodes(int index)
        {
            //
            // Disasemble & Code
            // 0x028BEFCC: STP x20, x19, [sp, #-0x20]! | stack[1152921513274950592] = ???;  stack[1152921513274950600] = ???;  //  dest_result_addr=1152921513274950592 |  dest_result_addr=1152921513274950600
            // 0x028BEFD0: STP x29, x30, [sp, #0x10]  | stack[1152921513274950608] = ???;  stack[1152921513274950616] = ???;  //  dest_result_addr=1152921513274950608 |  dest_result_addr=1152921513274950616
            // 0x028BEFD4: ADD x29, sp, #0x10         | X29 = (1152921513274950592 + 16) = 1152921513274950608 (0x1000000204A8C3D0);
            // 0x028BEFD8: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028BEFDC: LDRB w8, [x19, #0x942]     | W8 = (bool)static_value_037B8942;       
            // 0x028BEFE0: TBNZ w8, #0, #0x28beffc    | if (static_value_037B8942 == true) goto label_0;
            // 0x028BEFE4: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x028BEFE8: LDR x8, [x8, #0xce0]       | X8 = 0x2B8EE08;                         
            // 0x028BEFEC: LDR w0, [x8]               | W0 = 0x1242;                            
            // 0x028BEFF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1242, ????);     
            // 0x028BEFF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BEFF8: STRB w8, [x19, #0x942]     | static_value_037B8942 = true;            //  dest_result_addr=58427714
            label_0:
            // 0x028BEFFC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028BF000: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x028BF004: LDR x19, [x8]              | X19 = typeof(System.Byte[]);            
            // 0x028BF008: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028BF00C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x028BF010: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028BF014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF018: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028BF01C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028BF020: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028BF07C (42725500), len: 1876  VirtAddr: 0x028BF07C RVA: 0x028BF07C token: 100682630 methodIndex: 51167 delegateWrapperIndex: 0 methodInvoker: 0
        public void SerializeExtraInfo()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Serialization.SerializeSettings val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            object val_26;
            // 0x028BF07C: STP x28, x27, [sp, #-0x60]! | stack[1152921513275509600] = ???;  stack[1152921513275509608] = ???;  //  dest_result_addr=1152921513275509600 |  dest_result_addr=1152921513275509608
            // 0x028BF080: STP x26, x25, [sp, #0x10]  | stack[1152921513275509616] = ???;  stack[1152921513275509624] = ???;  //  dest_result_addr=1152921513275509616 |  dest_result_addr=1152921513275509624
            // 0x028BF084: STP x24, x23, [sp, #0x20]  | stack[1152921513275509632] = ???;  stack[1152921513275509640] = ???;  //  dest_result_addr=1152921513275509632 |  dest_result_addr=1152921513275509640
            // 0x028BF088: STP x22, x21, [sp, #0x30]  | stack[1152921513275509648] = ???;  stack[1152921513275509656] = ???;  //  dest_result_addr=1152921513275509648 |  dest_result_addr=1152921513275509656
            // 0x028BF08C: STP x20, x19, [sp, #0x40]  | stack[1152921513275509664] = ???;  stack[1152921513275509672] = ???;  //  dest_result_addr=1152921513275509664 |  dest_result_addr=1152921513275509672
            // 0x028BF090: STP x29, x30, [sp, #0x50]  | stack[1152921513275509680] = ???;  stack[1152921513275509688] = ???;  //  dest_result_addr=1152921513275509680 |  dest_result_addr=1152921513275509688
            // 0x028BF094: ADD x29, sp, #0x50         | X29 = (1152921513275509600 + 80) = 1152921513275509680 (0x1000000204B14BB0);
            // 0x028BF098: SUB sp, sp, #0x10          | SP = (1152921513275509600 - 16) = 1152921513275509584 (0x1000000204B14B50);
            // 0x028BF09C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028BF0A0: LDRB w8, [x20, #0x943]     | W8 = (bool)static_value_037B8943;       
            // 0x028BF0A4: MOV x19, x0                | X19 = 1152921513275521696 (0x1000000204B17AA0);//ML01
            // 0x028BF0A8: TBNZ w8, #0, #0x28bf0c4    | if (static_value_037B8943 == true) goto label_0;
            // 0x028BF0AC: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x028BF0B0: LDR x8, [x8, #0x7d0]       | X8 = 0x2B8EDF8;                         
            // 0x028BF0B4: LDR w0, [x8]               | W0 = 0x123E;                            
            // 0x028BF0B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x123E, ????);     
            // 0x028BF0BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BF0C0: STRB w8, [x20, #0x943]     | static_value_037B8943 = true;            //  dest_result_addr=58427715
            label_0:
            // 0x028BF0C4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x028BF0C8: LDR x8, [x8, #0xd08]       | X8 = 1152921504841883648;               
            // 0x028BF0CC: LDR x0, [x8]               | X0 = typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey0);
            object val_1 = null;
            // 0x028BF0D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey0), ????);
            // 0x028BF0D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF0D8: MOV x20, x0                | X20 = 1152921504841883648 (0x100000000E026000);//ML01
            // 0x028BF0DC: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x028BF0E0: LDR x21, [x19, #0x40]      | X21 = this.settings; //P2               
            val_22 = this.settings;
            // 0x028BF0E4: CBNZ x21, #0x28bf0ec       | if (this.settings != null) goto label_1;
            if(val_22 != null)
            {
                goto label_1;
            }
            // 0x028BF0E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x028BF0EC: LDRB w8, [x21, #0x10]      | W8 = this.settings.nodes; //P2          
            // 0x028BF0F0: CBZ w8, #0x28bf770         | if (this.settings.nodes == false) goto label_38;
            if(this.settings.nodes == false)
            {
                goto label_38;
            }
            // 0x028BF0F4: CBNZ x20, #0x28bf0fc       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x028BF0F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x028BF0FC: STR wzr, [x20, #0x10]      | typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey0).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504841883664
            typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey0).__il2cppRuntimeField_10 = 0;
            // 0x028BF100: ADRP x25, #0x35dd000       | X25 = 56479744 (0x35DD000);             
            // 0x028BF104: LDR x25, [x25, #0xdb8]     | X25 = 1152921513275054720;              
            // 0x028BF108: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x028BF10C: B #0x28bf114               |  goto label_4;                          
            goto label_4;
            label_13:
            // 0x028BF110: ADD w24, w24, #1           | W24 = (val_23 + 1) = val_23 (0x00000001);
            val_23 = 1;
            label_4:
            // 0x028BF114: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028BF118: CBNZ x21, #0x28bf120       | if (this.graphs != null) goto label_5;  
            if(this.graphs != null)
            {
                goto label_5;
            }
            // 0x028BF11C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x028BF120: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF124: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF128: B.GE #0x28bf1d4            | if (val_23 >= this.graphs.Length) goto label_6;
            if(val_23 >= this.graphs.Length)
            {
                goto label_6;
            }
            // 0x028BF12C: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028BF130: CBNZ x22, #0x28bf138       | if (this.graphs != null) goto label_7;  
            if(this.graphs != null)
            {
                goto label_7;
            }
            // 0x028BF134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_7:
            // 0x028BF138: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF13C: SXTW x21, w24              | X21 = 1 (0x00000001);                   
            // 0x028BF140: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF144: B.LO #0x28bf154            | if (val_23 < this.graphs.Length) goto label_8;
            if(val_23 < this.graphs.Length)
            {
                goto label_8;
            }
            // 0x028BF148: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028BF14C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF150: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_8:
            // 0x028BF154: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF158: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_22 = this.graphs[1];
            // 0x028BF15C: CBZ x8, #0x28bf110         | if (this.graphs[0x1][0] == null) goto label_13;
            if(val_22 == null)
            {
                goto label_13;
            }
            // 0x028BF160: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028BF164: CBNZ x22, #0x28bf16c       | if (this.graphs != null) goto label_10; 
            if(this.graphs != null)
            {
                goto label_10;
            }
            // 0x028BF168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_10:
            // 0x028BF16C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF170: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF174: B.LO #0x28bf184            | if (val_23 < this.graphs.Length) goto label_11;
            if(val_23 < this.graphs.Length)
            {
                goto label_11;
            }
            // 0x028BF178: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028BF17C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF180: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_11:
            // 0x028BF184: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF188: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_23 = this.graphs[1];
            // 0x028BF18C: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028BF190: LDR x23, [x25]             | X23 = System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey0::<>m__0(Pathfinding.GraphNode node);
            // 0x028BF194: LDR x8, [x8, #0xed0]       | X8 = 1152921504840179712;               
            // 0x028BF198: LDR x0, [x8]               | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            Pathfinding.GraphNodeDelegateCancelable val_2 = null;
            // 0x028BF19C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x028BF1A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF1A4: MOV x1, x20                | X1 = 1152921504841883648 (0x100000000E026000);//ML01
            // 0x028BF1A8: MOV x2, x23                | X2 = 1152921513275054720 (0x1000000204AA5A80);//ML01
            // 0x028BF1AC: MOV x22, x0                | X22 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028BF1B0: BL #0x1681308              | .ctor(object:  val_1, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey0::<>m__0(Pathfinding.GraphNode node));
            val_2 = new Pathfinding.GraphNodeDelegateCancelable(object:  val_1, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey0::<>m__0(Pathfinding.GraphNode node));
            // 0x028BF1B4: CBNZ x21, #0x28bf1bc       | if (this.graphs[0x1][0] != null) goto label_12;
            if(val_23 != null)
            {
                goto label_12;
            }
            // 0x028BF1B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_1, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey0::<>m__0(Pathfinding.GraphNode node)), ????);
            label_12:
            // 0x028BF1BC: LDR x8, [x21]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028BF1C0: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x028BF1C4: MOV x1, x22                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028BF1C8: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x028BF1CC: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            // 0x028BF1D0: B #0x28bf110               |  goto label_13;                         
            goto label_13;
            label_6:
            // 0x028BF1D4: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028BF1D8: LDR x8, [x8, #0xc60]       | X8 = 1152921504841936896;               
            // 0x028BF1DC: LDR x0, [x8]               | X0 = typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1);
            object val_3 = null;
            // 0x028BF1E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1), ????);
            // 0x028BF1E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF1E8: MOV x21, x0                | X21 = 1152921504841936896 (0x100000000E033000);//ML01
            // 0x028BF1EC: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x028BF1F0: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028BF1F4: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028BF1F8: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_4 = null;
            // 0x028BF1FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028BF200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF204: MOV x22, x0                | X22 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF208: BL #0x1e762f4              | .ctor();                                
            val_4 = new System.IO.MemoryStream();
            // 0x028BF20C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x028BF210: LDR x8, [x8, #0xb0]        | X8 = 1152921504620744704;               
            // 0x028BF214: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryWriter);    
            System.IO.BinaryWriter val_5 = null;
            // 0x028BF218: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryWriter), ????);
            // 0x028BF21C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BF220: MOV x1, x22                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF224: MOV x23, x0                | X23 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF228: BL #0x1e680b0              | .ctor(output:  val_4);                  
            val_5 = new System.IO.BinaryWriter(output:  val_4);
            // 0x028BF22C: CBZ x21, #0x28bf23c        | if ( == 0) goto label_14;               
            if(null == 0)
            {
                goto label_14;
            }
            // 0x028BF230: MOV x26, x21               | X26 = 1152921504841936896 (0x100000000E033000);//ML01
            val_24 = val_3;
            // 0x028BF234: STR x23, [x26, #0x18]!     | typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1).__il2cppRuntimeField_18 = typeof(System.IO.BinaryWriter);  //  dest_result_addr=1152921504841936920
            typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1).__il2cppRuntimeField_18 = val_5;
            // 0x028BF238: B #0x28bf24c               |  goto label_15;                         
            goto label_15;
            label_14:
            // 0x028BF23C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_4), ????);
            // 0x028BF240: ORR w26, wzr, #0x18        | W26 = 24(0x18);                         
            val_24 = 24;
            // 0x028BF244: STR x23, [x26]             | mem[24] = typeof(System.IO.BinaryWriter);  //  dest_result_addr=24
            mem[24] = val_5;
            // 0x028BF248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_4), ????);
            label_15:
            // 0x028BF24C: LDR x23, [x26]             | X23 = typeof(System.IO.BinaryWriter);   
            // 0x028BF250: CBNZ x20, #0x28bf258       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x028BF254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_4), ????);
            label_16:
            // 0x028BF258: LDR w24, [x20, #0x10]      | W24 = 0x0;                              
            // 0x028BF25C: CBNZ x23, #0x28bf264       | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x028BF260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_4), ????);
            label_17:
            // 0x028BF264: LDR x8, [x23]              | X8 = ;                                  
            // 0x028BF268: MOV x0, x23                | X0 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF26C: MOV w1, w24                | W1 = 0 (0x0);//ML01                     
            // 0x028BF270: LDR x9, [x8, #0x200]       |  //  not_find_field!1:512
            // 0x028BF274: LDR x2, [x8, #0x208]       |  //  not_find_field!1:520
            // 0x028BF278: BLR x9                     | X0 = mem[null + 512]();                 
            // 0x028BF27C: CBNZ x21, #0x28bf284       | if ( != 0) goto label_18;               
            if(null != 0)
            {
                goto label_18;
            }
            // 0x028BF280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_18:
            // 0x028BF284: STR wzr, [x21, #0x10]      | typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504841936912
            typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1).__il2cppRuntimeField_10 = 0;
            // 0x028BF288: ADRP x28, #0x3611000       | X28 = 56692736 (0x3611000);             
            // 0x028BF28C: LDR x28, [x28, #0x7d8]     | X28 = 1152921513275174528;              
            // 0x028BF290: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x028BF294: B #0x28bf29c               |  goto label_19;                         
            goto label_19;
            label_28:
            // 0x028BF298: ADD w27, w27, #1           | W27 = (val_25 + 1) = val_25 (0x00000001);
            val_25 = 1;
            label_19:
            // 0x028BF29C: LDR x23, [x19, #0x48]      | X23 = this.graphs; //P2                 
            // 0x028BF2A0: CBNZ x23, #0x28bf2a8       | if (this.graphs != null) goto label_20; 
            if(this.graphs != null)
            {
                goto label_20;
            }
            // 0x028BF2A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_20:
            // 0x028BF2A8: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF2AC: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF2B0: B.GE #0x28bf35c            | if (val_25 >= this.graphs.Length) goto label_21;
            if(val_25 >= this.graphs.Length)
            {
                goto label_21;
            }
            // 0x028BF2B4: LDR x24, [x19, #0x48]      | X24 = this.graphs; //P2                 
            // 0x028BF2B8: CBNZ x24, #0x28bf2c0       | if (this.graphs != null) goto label_22; 
            if(this.graphs != null)
            {
                goto label_22;
            }
            // 0x028BF2BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_22:
            // 0x028BF2C0: LDR w8, [x24, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF2C4: SXTW x23, w27              | X23 = 1 (0x00000001);                   
            // 0x028BF2C8: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF2CC: B.LO #0x28bf2dc            | if (val_25 < this.graphs.Length) goto label_23;
            if(val_25 < this.graphs.Length)
            {
                goto label_23;
            }
            // 0x028BF2D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryWriter), ????);
            // 0x028BF2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF2D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryWriter), ????);
            label_23:
            // 0x028BF2DC: ADD x8, x24, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF2E0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_24 = this.graphs[1];
            // 0x028BF2E4: CBZ x8, #0x28bf298         | if (this.graphs[0x1][0] == null) goto label_28;
            if(val_24 == null)
            {
                goto label_28;
            }
            // 0x028BF2E8: LDR x24, [x19, #0x48]      | X24 = this.graphs; //P2                 
            // 0x028BF2EC: CBNZ x24, #0x28bf2f4       | if (this.graphs != null) goto label_25; 
            if(this.graphs != null)
            {
                goto label_25;
            }
            // 0x028BF2F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_25:
            // 0x028BF2F4: LDR w8, [x24, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF2F8: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF2FC: B.LO #0x28bf30c            | if (val_25 < this.graphs.Length) goto label_26;
            if(val_25 < this.graphs.Length)
            {
                goto label_26;
            }
            // 0x028BF300: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.BinaryWriter), ????);
            // 0x028BF304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF308: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryWriter), ????);
            label_26:
            // 0x028BF30C: ADD x8, x24, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF310: LDR x23, [x8, #0x20]       | X23 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_25 = this.graphs[1];
            // 0x028BF314: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028BF318: LDR x25, [x28]             | X25 = System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey1::<>m__0(Pathfinding.GraphNode node);
            // 0x028BF31C: LDR x8, [x8, #0xed0]       | X8 = 1152921504840179712;               
            // 0x028BF320: LDR x0, [x8]               | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            Pathfinding.GraphNodeDelegateCancelable val_6 = null;
            // 0x028BF324: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x028BF328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF32C: MOV x1, x21                | X1 = 1152921504841936896 (0x100000000E033000);//ML01
            // 0x028BF330: MOV x2, x25                | X2 = 1152921513275174528 (0x1000000204AC2E80);//ML01
            // 0x028BF334: MOV x24, x0                | X24 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028BF338: BL #0x1681308              | .ctor(object:  val_3, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey1::<>m__0(Pathfinding.GraphNode node));
            val_6 = new Pathfinding.GraphNodeDelegateCancelable(object:  val_3, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey1::<>m__0(Pathfinding.GraphNode node));
            // 0x028BF33C: CBNZ x23, #0x28bf344       | if (this.graphs[0x1][0] != null) goto label_27;
            if(val_25 != null)
            {
                goto label_27;
            }
            // 0x028BF340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_3, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey1::<>m__0(Pathfinding.GraphNode node)), ????);
            label_27:
            // 0x028BF344: LDR x8, [x23]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028BF348: MOV x0, x23                | X0 = this.graphs[0x1][0];//m1           
            // 0x028BF34C: MOV x1, x24                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028BF350: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x028BF354: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            // 0x028BF358: B #0x28bf298               |  goto label_28;                         
            goto label_28;
            label_21:
            // 0x028BF35C: CBNZ x21, #0x28bf364       | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x028BF360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_29:
            // 0x028BF364: LDR w23, [x21, #0x10]      | W23 = 0x0;                              
            // 0x028BF368: CBNZ x20, #0x28bf370       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x028BF36C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_30:
            // 0x028BF370: LDR w8, [x20, #0x10]       | W8 = 0x0;                               
            // 0x028BF374: CMP w23, w8                | STATE = COMPARE(0x0, 0x0)               
            // 0x028BF378: B.NE #0x28bf790            | if (typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey1).__il2cppRuntimeField_10 != typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey0).__il2cppRuntimeField_10) goto label_31;
            // 0x028BF37C: CBNZ x22, #0x28bf384       | if ( != 0) goto label_32;               
            if(null != 0)
            {
                goto label_32;
            }
            // 0x028BF380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_32:
            // 0x028BF384: LDR x8, [x22]              | X8 = ;                                  
            // 0x028BF388: MOV x0, x22                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF38C: LDR x9, [x8, #0x2e0]       |  //  not_find_field!1:736
            // 0x028BF390: LDR x1, [x8, #0x2e8]       |  //  not_find_field!1:744
            // 0x028BF394: BLR x9                     | X0 = mem[null + 736]();                 
            // 0x028BF398: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF39C: CBNZ x21, #0x28bf3a4       | if ( != 0) goto label_33;               
            if(null != 0)
            {
                goto label_33;
            }
            // 0x028BF3A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_33:
            // 0x028BF3A4: LDR x21, [x26]             | X21 = typeof(System.IO.BinaryWriter);   
            // 0x028BF3A8: CBNZ x21, #0x28bf3b0       | if ( != 0) goto label_34;               
            if(null != 0)
            {
                goto label_34;
            }
            // 0x028BF3AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_34:
            // 0x028BF3B0: LDR x8, [x21]              | X8 = ;                                  
            // 0x028BF3B4: MOV x0, x21                | X0 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF3B8: LDP x9, x1, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
            // 0x028BF3BC: BLR x9                     | X0 = mem[null + 368]();                 
            // 0x028BF3C0: MOV x0, x19                | X0 = 1152921513275521696 (0x1000000204B17AA0);//ML01
            // 0x028BF3C4: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF3C8: BL #0x28bdc84              | this.AddChecksum(bytes:  val_4);        
            this.AddChecksum(bytes:  val_4);
            // 0x028BF3CC: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            val_22 = this.zip;
            // 0x028BF3D0: CBNZ x21, #0x28bf3d8       | if (this.zip != null) goto label_35;    
            if(val_22 != null)
            {
                goto label_35;
            }
            // 0x028BF3D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_35:
            // 0x028BF3D8: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x028BF3DC: LDR x8, [x8, #0x8f0]       | X8 = (string**)(1152921513275298432)("graph_references.binary");
            // 0x028BF3E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF3E4: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028BF3E8: MOV x2, x20                | X2 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF3EC: LDR x1, [x8]               | X1 = "graph_references.binary";         
            // 0x028BF3F0: BL #0x1983670              | X0 = this.zip.AddEntry(entryName:  "graph_references.binary", byteContent:  val_4);
            Pathfinding.Ionic.Zip.ZipEntry val_7 = val_22.AddEntry(entryName:  "graph_references.binary", byteContent:  val_4);
            // 0x028BF3F4: ADRP x28, #0x3652000       | X28 = 56958976 (0x3652000);             
            // 0x028BF3F8: ADRP x26, #0x3684000       | X26 = 57163776 (0x3684000);             
            // 0x028BF3FC: LDR x28, [x28, #0x140]     | X28 = 1152921504607113216;              
            // 0x028BF400: LDR x26, [x26, #0x390]     | X26 = (string**)(1152921513124056064)("graph");
            // 0x028BF404: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_26 = 0;
            // 0x028BF408: B #0x28bf410               |  goto label_36;                         
            goto label_36;
            label_59:
            // 0x028BF40C: ADD w27, w27, #1           | W27 = (val_26 + 1) = val_26 (0x00000001);
            val_26 = 1;
            label_36:
            // 0x028BF410: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028BF414: CBNZ x20, #0x28bf41c       | if (this.graphs != null) goto label_37; 
            if(this.graphs != null)
            {
                goto label_37;
            }
            // 0x028BF418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_37:
            // 0x028BF41C: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF420: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF424: B.GE #0x28bf770            | if (val_26 >= this.graphs.Length) goto label_38;
            if(val_26 >= this.graphs.Length)
            {
                goto label_38;
            }
            // 0x028BF428: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028BF42C: LDR x8, [x8, #0x918]       | X8 = 1152921504841990144;               
            // 0x028BF430: LDR x0, [x8]               | X0 = typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey2);
            object val_8 = null;
            // 0x028BF434: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey2), ????);
            // 0x028BF438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF43C: MOV x20, x0                | X20 = 1152921504841990144 (0x100000000E040000);//ML01
            // 0x028BF440: BL #0x16f59f0              | .ctor();                                
            val_8 = new System.Object();
            // 0x028BF444: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028BF448: CBNZ x21, #0x28bf450       | if (this.graphs != null) goto label_39; 
            if(this.graphs != null)
            {
                goto label_39;
            }
            // 0x028BF44C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_39:
            // 0x028BF450: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF454: SXTW x25, w27              | X25 = 1 (0x00000001);                   
            // 0x028BF458: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF45C: B.LO #0x28bf46c            | if (val_26 < this.graphs.Length) goto label_40;
            if(val_26 < this.graphs.Length)
            {
                goto label_40;
            }
            // 0x028BF460: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028BF464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF468: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_40:
            // 0x028BF46C: ADD x8, x21, x25, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF470: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_26 = this.graphs[1];
            // 0x028BF474: CBZ x8, #0x28bf40c         | if (this.graphs[0x1][0] == null) goto label_59;
            if(val_26 == null)
            {
                goto label_59;
            }
            // 0x028BF478: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028BF47C: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028BF480: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_9 = null;
            // 0x028BF484: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028BF488: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF48C: MOV x22, x0                | X22 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF490: BL #0x1e762f4              | .ctor();                                
            val_9 = new System.IO.MemoryStream();
            // 0x028BF494: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x028BF498: LDR x8, [x8, #0xb0]        | X8 = 1152921504620744704;               
            // 0x028BF49C: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryWriter);    
            System.IO.BinaryWriter val_10 = null;
            // 0x028BF4A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryWriter), ????);
            // 0x028BF4A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BF4A8: MOV x1, x22                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF4AC: MOV x21, x0                | X21 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF4B0: BL #0x1e680b0              | .ctor(output:  val_9);                  
            val_10 = new System.IO.BinaryWriter(output:  val_9);
            // 0x028BF4B4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028BF4B8: LDR x8, [x8, #0x8f8]       | X8 = 1152921504841777152;               
            // 0x028BF4BC: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GraphSerializationContext);
            object val_11 = null;
            // 0x028BF4C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GraphSerializationContext), ????);
            // 0x028BF4C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF4C8: MOV x23, x0                | X23 = 1152921504841777152 (0x100000000E00C000);//ML01
            // 0x028BF4CC: BL #0x16f59f0              | .ctor();                                
            val_11 = new System.Object();
            // 0x028BF4D0: STR x21, [x23, #0x20]      | typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_20 = typeof(System.IO.BinaryWriter);  //  dest_result_addr=1152921504841777184
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_20 = val_10;
            // 0x028BF4D4: CBNZ x20, #0x28bf4dc       | if ( != 0) goto label_42;               
            if(null != 0)
            {
                goto label_42;
            }
            // 0x028BF4D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_42:
            // 0x028BF4DC: STR x23, [x20, #0x10]      | typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey2).__il2cppRuntimeField_10 = typeof(Pathfinding.Serialization.GraphSerializationContext);  //  dest_result_addr=1152921504841990160
            typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey2).__il2cppRuntimeField_10 = val_11;
            // 0x028BF4E0: LDR x23, [x19, #0x48]      | X23 = this.graphs; //P2                 
            // 0x028BF4E4: CBNZ x23, #0x28bf4ec       | if (this.graphs != null) goto label_43; 
            if(this.graphs != null)
            {
                goto label_43;
            }
            // 0x028BF4E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_43:
            // 0x028BF4EC: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF4F0: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF4F4: B.LO #0x28bf504            | if (val_26 < this.graphs.Length) goto label_44;
            if(val_26 < this.graphs.Length)
            {
                goto label_44;
            }
            // 0x028BF4F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028BF4FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF500: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_44:
            // 0x028BF504: ADD x8, x23, x25, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF508: LDR x23, [x8, #0x20]       | X23 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_27 = this.graphs[1];
            // 0x028BF50C: CBNZ x20, #0x28bf514       | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x028BF510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_45:
            // 0x028BF514: LDR x24, [x20, #0x10]      | X24 = typeof(Pathfinding.Serialization.GraphSerializationContext);
            // 0x028BF518: CBNZ x23, #0x28bf520       | if (this.graphs[0x1][0] != null) goto label_46;
            if(val_27 != null)
            {
                goto label_46;
            }
            // 0x028BF51C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_46:
            // 0x028BF520: LDR x8, [x23]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028BF524: MOV x0, x23                | X0 = this.graphs[0x1][0];//m1           
            // 0x028BF528: MOV x1, x24                | X1 = 1152921504841777152 (0x100000000E00C000);//ML01
            // 0x028BF52C: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1F0; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1F8; //  | 
            // 0x028BF530: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1F0();
            // 0x028BF534: CBNZ x22, #0x28bf53c       | if ( != 0) goto label_47;               
            if(null != 0)
            {
                goto label_47;
            }
            // 0x028BF538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.graphs[0x1][0], ????);
            label_47:
            // 0x028BF53C: LDR x8, [x22]              | X8 = ;                                  
            // 0x028BF540: MOV x0, x22                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF544: LDR x9, [x8, #0x2e0]       |  //  not_find_field!1:736
            // 0x028BF548: LDR x1, [x8, #0x2e8]       |  //  not_find_field!1:744
            // 0x028BF54C: BLR x9                     | X0 = mem[null + 736]();                 
            // 0x028BF550: MOV x22, x0                | X22 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF554: CBNZ x21, #0x28bf55c       | if ( != 0) goto label_48;               
            if(null != 0)
            {
                goto label_48;
            }
            // 0x028BF558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_48:
            // 0x028BF55C: LDR x8, [x21]              | X8 = ;                                  
            // 0x028BF560: MOV x0, x21                | X0 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF564: LDP x9, x1, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
            // 0x028BF568: BLR x9                     | X0 = mem[null + 368]();                 
            // 0x028BF56C: MOV x0, x19                | X0 = 1152921513275521696 (0x1000000204B17AA0);//ML01
            // 0x028BF570: MOV x1, x22                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF574: BL #0x28bdc84              | this.AddChecksum(bytes:  val_9);        
            this.AddChecksum(bytes:  val_9);
            // 0x028BF578: LDR x0, [x28]              | X0 = typeof(System.Int32);              
            // 0x028BF57C: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BF580: ADD x1, sp, #0xc           | X1 = (1152921513275509584 + 12) = 1152921513275509596 (0x1000000204B14B5C);
            // 0x028BF584: STR w27, [sp, #0xc]        | stack[1152921513275509596] = 0x1;        //  dest_result_addr=1152921513275509596
            // 0x028BF588: BL #0x27bc028              | X0 = 1152921513275926432 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028BF58C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028BF590: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028BF594: MOV x23, x0                | X23 = 1152921513275926432 (0x1000000204B7A7A0);//ML01
            // 0x028BF598: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028BF59C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028BF5A0: TBZ w9, #0, #0x28bf5b4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_50;
            // 0x028BF5A4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028BF5A8: CBNZ w9, #0x28bf5b4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
            // 0x028BF5AC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028BF5B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_50:
            // 0x028BF5B4: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x028BF5B8: LDR x1, [x26]              | X1 = "graph";                           
            // 0x028BF5BC: LDR x8, [x8, #0x230]       | X8 = (string**)(1152921513275429632)("_extra.binary");
            // 0x028BF5C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BF5C4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028BF5C8: MOV x2, x23                | X2 = 1152921513275926432 (0x1000000204B7A7A0);//ML01
            // 0x028BF5CC: LDR x3, [x8]               | X3 = "_extra.binary";                   
            // 0x028BF5D0: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_26);
            string val_12 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_26);
            // 0x028BF5D4: MOV x23, x0                | X23 = val_12;//m1                       
            // 0x028BF5D8: CBNZ x21, #0x28bf5e0       | if (this.zip != null) goto label_51;    
            if(this.zip != null)
            {
                goto label_51;
            }
            // 0x028BF5DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_51:
            // 0x028BF5E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF5E4: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028BF5E8: MOV x1, x23                | X1 = val_12;//m1                        
            // 0x028BF5EC: MOV x2, x22                | X2 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF5F0: BL #0x1983670              | X0 = this.zip.AddEntry(entryName:  val_12, byteContent:  val_9);
            Pathfinding.Ionic.Zip.ZipEntry val_13 = this.zip.AddEntry(entryName:  val_12, byteContent:  val_9);
            // 0x028BF5F4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028BF5F8: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028BF5FC: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_14 = null;
            // 0x028BF600: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028BF604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF608: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF60C: BL #0x1e762f4              | .ctor();                                
            val_14 = new System.IO.MemoryStream();
            // 0x028BF610: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x028BF614: LDR x8, [x8, #0xb0]        | X8 = 1152921504620744704;               
            // 0x028BF618: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryWriter);    
            System.IO.BinaryWriter val_15 = null;
            // 0x028BF61C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryWriter), ????);
            // 0x028BF620: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BF624: MOV x1, x21                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF628: MOV x22, x0                | X22 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF62C: BL #0x1e680b0              | .ctor(output:  val_14);                 
            val_15 = new System.IO.BinaryWriter(output:  val_14);
            // 0x028BF630: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028BF634: LDR x8, [x8, #0x8f8]       | X8 = 1152921504841777152;               
            // 0x028BF638: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GraphSerializationContext);
            object val_16 = null;
            // 0x028BF63C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GraphSerializationContext), ????);
            // 0x028BF640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF644: MOV x23, x0                | X23 = 1152921504841777152 (0x100000000E00C000);//ML01
            // 0x028BF648: BL #0x16f59f0              | .ctor();                                
            val_16 = new System.Object();
            // 0x028BF64C: STR x22, [x23, #0x20]      | typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_20 = typeof(System.IO.BinaryWriter);  //  dest_result_addr=1152921504841777184
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_20 = val_15;
            // 0x028BF650: CBNZ x20, #0x28bf658       | if ( != 0) goto label_52;               
            if(null != 0)
            {
                goto label_52;
            }
            // 0x028BF654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_52:
            // 0x028BF658: STR x23, [x20, #0x10]      | typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey2).__il2cppRuntimeField_10 = typeof(Pathfinding.Serialization.GraphSerializationContext);  //  dest_result_addr=1152921504841990160
            typeof(AstarSerializer.<SerializeExtraInfo>c__AnonStorey2).__il2cppRuntimeField_10 = val_16;
            // 0x028BF65C: LDR x23, [x19, #0x48]      | X23 = this.graphs; //P2                 
            // 0x028BF660: CBNZ x23, #0x28bf668       | if (this.graphs != null) goto label_53; 
            if(this.graphs != null)
            {
                goto label_53;
            }
            // 0x028BF664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_53:
            // 0x028BF668: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028BF66C: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028BF670: B.LO #0x28bf680            | if (val_26 < this.graphs.Length) goto label_54;
            if(val_26 < this.graphs.Length)
            {
                goto label_54;
            }
            // 0x028BF674: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028BF678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF67C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_54:
            // 0x028BF680: ADRP x9, #0x35da000        | X9 = 56467456 (0x35DA000);              
            // 0x028BF684: LDR x9, [x9, #0x988]       | X9 = 1152921513275474784;               
            // 0x028BF688: ADD x8, x23, x25, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028BF68C: LDR x23, [x8, #0x20]       | X23 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_28 = this.graphs[1];
            // 0x028BF690: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028BF694: LDR x25, [x9]              | X25 = System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey2::<>m__0(Pathfinding.GraphNode node);
            // 0x028BF698: LDR x8, [x8, #0xed0]       | X8 = 1152921504840179712;               
            // 0x028BF69C: LDR x0, [x8]               | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            Pathfinding.GraphNodeDelegateCancelable val_17 = null;
            // 0x028BF6A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x028BF6A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF6A8: MOV x1, x20                | X1 = 1152921504841990144 (0x100000000E040000);//ML01
            // 0x028BF6AC: MOV x2, x25                | X2 = 1152921513275474784 (0x1000000204B0C360);//ML01
            // 0x028BF6B0: MOV x24, x0                | X24 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028BF6B4: BL #0x1681308              | .ctor(object:  val_8, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey2::<>m__0(Pathfinding.GraphNode node));
            val_17 = new Pathfinding.GraphNodeDelegateCancelable(object:  val_8, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey2::<>m__0(Pathfinding.GraphNode node));
            // 0x028BF6B8: CBNZ x23, #0x28bf6c0       | if (this.graphs[0x1][0] != null) goto label_55;
            if(val_28 != null)
            {
                goto label_55;
            }
            // 0x028BF6BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_8, method:  System.Boolean AstarSerializer.<SerializeExtraInfo>c__AnonStorey2::<>m__0(Pathfinding.GraphNode node)), ????);
            label_55:
            // 0x028BF6C0: LDR x8, [x23]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028BF6C4: MOV x0, x23                | X0 = this.graphs[0x1][0];//m1           
            // 0x028BF6C8: MOV x1, x24                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028BF6CC: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x028BF6D0: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            // 0x028BF6D4: CBNZ x22, #0x28bf6dc       | if ( != 0) goto label_56;               
            if(null != 0)
            {
                goto label_56;
            }
            // 0x028BF6D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.graphs[0x1][0], ????);
            label_56:
            // 0x028BF6DC: LDR x8, [x22]              | X8 = ;                                  
            // 0x028BF6E0: MOV x0, x22                | X0 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x028BF6E4: LDP x9, x1, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
            // 0x028BF6E8: BLR x9                     | X0 = mem[null + 368]();                 
            // 0x028BF6EC: CBNZ x21, #0x28bf6f4       | if ( != 0) goto label_57;               
            if(null != 0)
            {
                goto label_57;
            }
            // 0x028BF6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_57:
            // 0x028BF6F4: LDR x8, [x21]              | X8 = ;                                  
            // 0x028BF6F8: MOV x0, x21                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF6FC: LDR x9, [x8, #0x2e0]       |  //  not_find_field!1:736
            // 0x028BF700: LDR x1, [x8, #0x2e8]       |  //  not_find_field!1:744
            // 0x028BF704: BLR x9                     | X0 = mem[null + 736]();                 
            // 0x028BF708: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF70C: MOV x0, x19                | X0 = 1152921513275521696 (0x1000000204B17AA0);//ML01
            // 0x028BF710: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF714: BL #0x28bdc84              | this.AddChecksum(bytes:  val_14);       
            this.AddChecksum(bytes:  val_14);
            // 0x028BF718: LDR x0, [x28]              | X0 = typeof(System.Int32);              
            // 0x028BF71C: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028BF720: ADD x1, sp, #8             | X1 = (1152921513275509584 + 8) = 1152921513275509592 (0x1000000204B14B58);
            // 0x028BF724: STR w27, [sp, #8]          | stack[1152921513275509592] = 0x1;        //  dest_result_addr=1152921513275509592
            // 0x028BF728: BL #0x27bc028              | X0 = 1152921513275983776 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028BF72C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x028BF730: LDR x1, [x26]              | X1 = "graph";                           
            // 0x028BF734: LDR x8, [x8, #0x980]       | X8 = (string**)(1152921513275488096)("_references.binary");
            // 0x028BF738: MOV x2, x0                 | X2 = 1152921513275983776 (0x1000000204B887A0);//ML01
            // 0x028BF73C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BF740: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028BF744: LDR x3, [x8]               | X3 = "_references.binary";              
            // 0x028BF748: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_26);
            string val_18 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_26);
            // 0x028BF74C: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x028BF750: CBNZ x21, #0x28bf758       | if (this.zip != null) goto label_58;    
            if(this.zip != null)
            {
                goto label_58;
            }
            // 0x028BF754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_58:
            // 0x028BF758: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF75C: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028BF760: MOV x1, x22                | X1 = val_18;//m1                        
            // 0x028BF764: MOV x2, x20                | X2 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BF768: BL #0x1983670              | X0 = this.zip.AddEntry(entryName:  val_18, byteContent:  val_14);
            Pathfinding.Ionic.Zip.ZipEntry val_19 = this.zip.AddEntry(entryName:  val_18, byteContent:  val_14);
            // 0x028BF76C: B #0x28bf40c               |  goto label_59;                         
            goto label_59;
            label_38:
            // 0x028BF770: SUB sp, x29, #0x50         | SP = (1152921513275509680 - 80) = 1152921513275509600 (0x1000000204B14B60);
            // 0x028BF774: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028BF778: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028BF77C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028BF780: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028BF784: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028BF788: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028BF78C: RET                        |  return;                                
            return;
            label_31:
            // 0x028BF790: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028BF794: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028BF798: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_20 = null;
            // 0x028BF79C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028BF7A0: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x028BF7A4: LDR x8, [x8, #0xc10]       | X8 = (string**)(1152921513275496400)("Some graphs are not consistent in their GetNodes calls, sequential calls give different results.");
            // 0x028BF7A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BF7AC: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028BF7B0: LDR x1, [x8]               | X1 = "Some graphs are not consistent in their GetNodes calls, sequential calls give different results.";
            // 0x028BF7B4: BL #0x1c32b48              | .ctor(message:  "Some graphs are not consistent in their GetNodes calls, sequential calls give different results.");
            val_20 = new System.Exception(message:  "Some graphs are not consistent in their GetNodes calls, sequential calls give different results.");
            // 0x028BF7B8: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028BF7BC: LDR x8, [x8, #0x450]       | X8 = 1152921513275496672;               
            // 0x028BF7C0: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028BF7C4: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Serialization.AstarSerializer::SerializeExtraInfo();
            // 0x028BF7C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028BF7CC: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_21 = MoveNext();
        
        }
        //
        // Offset in libil2cpp.so: 0x028BF024 (42725412), len: 88  VirtAddr: 0x028BF024 RVA: 0x028BF024 token: 100682631 methodIndex: 51168 delegateWrapperIndex: 0 methodInvoker: 0
        private byte[] SerializeNodeConnections(int index)
        {
            //
            // Disasemble & Code
            // 0x028BF024: STP x20, x19, [sp, #-0x20]! | stack[1152921513276064032] = ???;  stack[1152921513276064040] = ???;  //  dest_result_addr=1152921513276064032 |  dest_result_addr=1152921513276064040
            // 0x028BF028: STP x29, x30, [sp, #0x10]  | stack[1152921513276064048] = ???;  stack[1152921513276064056] = ???;  //  dest_result_addr=1152921513276064048 |  dest_result_addr=1152921513276064056
            // 0x028BF02C: ADD x29, sp, #0x10         | X29 = (1152921513276064032 + 16) = 1152921513276064048 (0x1000000204B9C130);
            // 0x028BF030: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028BF034: LDRB w8, [x19, #0x944]     | W8 = (bool)static_value_037B8944;       
            // 0x028BF038: TBNZ w8, #0, #0x28bf054    | if (static_value_037B8944 == true) goto label_0;
            // 0x028BF03C: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x028BF040: LDR x8, [x8, #0xb00]       | X8 = 0x2B8EE04;                         
            // 0x028BF044: LDR w0, [x8]               | W0 = 0x1241;                            
            // 0x028BF048: BL #0x2782188              | X0 = sub_2782188( ?? 0x1241, ????);     
            // 0x028BF04C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BF050: STRB w8, [x19, #0x944]     | static_value_037B8944 = true;            //  dest_result_addr=58427716
            label_0:
            // 0x028BF054: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028BF058: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x028BF05C: LDR x19, [x8]              | X19 = typeof(System.Byte[]);            
            // 0x028BF060: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028BF064: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x028BF068: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028BF06C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF070: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028BF074: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028BF078: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028BF814 (42727444), len: 572  VirtAddr: 0x028BF814 RVA: 0x028BF814 token: 100682632 methodIndex: 51169 delegateWrapperIndex: 0 methodInvoker: 0
        public void SerializeEditorSettings(Pathfinding.GraphEditorBase[] editors)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.Serialization.SerializeSettings val_6;
            //  | 
            object val_7;
            // 0x028BF814: STP x28, x27, [sp, #-0x60]! | stack[1152921513276286656] = ???;  stack[1152921513276286664] = ???;  //  dest_result_addr=1152921513276286656 |  dest_result_addr=1152921513276286664
            // 0x028BF818: STP x26, x25, [sp, #0x10]  | stack[1152921513276286672] = ???;  stack[1152921513276286680] = ???;  //  dest_result_addr=1152921513276286672 |  dest_result_addr=1152921513276286680
            // 0x028BF81C: STP x24, x23, [sp, #0x20]  | stack[1152921513276286688] = ???;  stack[1152921513276286696] = ???;  //  dest_result_addr=1152921513276286688 |  dest_result_addr=1152921513276286696
            // 0x028BF820: STP x22, x21, [sp, #0x30]  | stack[1152921513276286704] = ???;  stack[1152921513276286712] = ???;  //  dest_result_addr=1152921513276286704 |  dest_result_addr=1152921513276286712
            // 0x028BF824: STP x20, x19, [sp, #0x40]  | stack[1152921513276286720] = ???;  stack[1152921513276286728] = ???;  //  dest_result_addr=1152921513276286720 |  dest_result_addr=1152921513276286728
            // 0x028BF828: STP x29, x30, [sp, #0x50]  | stack[1152921513276286736] = ???;  stack[1152921513276286744] = ???;  //  dest_result_addr=1152921513276286736 |  dest_result_addr=1152921513276286744
            // 0x028BF82C: ADD x29, sp, #0x50         | X29 = (1152921513276286656 + 80) = 1152921513276286736 (0x1000000204BD2710);
            // 0x028BF830: SUB sp, sp, #0x10          | SP = (1152921513276286656 - 16) = 1152921513276286640 (0x1000000204BD26B0);
            // 0x028BF834: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BF838: LDRB w8, [x21, #0x945]     | W8 = (bool)static_value_037B8945;       
            // 0x028BF83C: MOV x19, x1                | X19 = editors;//m1                      
            // 0x028BF840: MOV x20, x0                | X20 = 1152921513276298752 (0x1000000204BD5600);//ML01
            // 0x028BF844: TBNZ w8, #0, #0x28bf860    | if (static_value_037B8945 == true) goto label_0;
            // 0x028BF848: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x028BF84C: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8EDF4;                         
            // 0x028BF850: LDR w0, [x8]               | W0 = 0x123D;                            
            // 0x028BF854: BL #0x2782188              | X0 = sub_2782188( ?? 0x123D, ????);     
            // 0x028BF858: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BF85C: STRB w8, [x21, #0x945]     | static_value_037B8945 = true;            //  dest_result_addr=58427717
            label_0:
            // 0x028BF860: CBZ x19, #0x28bfa30        | if (editors == null) goto label_6;      
            if(editors == null)
            {
                goto label_6;
            }
            // 0x028BF864: LDR x21, [x20, #0x40]      | X21 = this.settings; //P2               
            val_6 = this.settings;
            // 0x028BF868: CBNZ x21, #0x28bf870       | if (this.settings != null) goto label_2;
            if(val_6 != null)
            {
                goto label_2;
            }
            // 0x028BF86C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x123D, ????);     
            label_2:
            // 0x028BF870: LDRB w8, [x21, #0x12]      | W8 = this.settings.editorSettings; //P2 
            // 0x028BF874: CBZ w8, #0x28bfa30         | if (this.settings.editorSettings == false) goto label_6;
            if(this.settings.editorSettings == false)
            {
                goto label_6;
            }
            // 0x028BF878: LDR w8, [x19, #0x18]       | W8 = editors.Length; //P2               
            // 0x028BF87C: CMP w8, #1                 | STATE = COMPARE(editors.Length, 0x1)    
            // 0x028BF880: B.LT #0x28bfa30            | if (editors.Length < 1) goto label_6;   
            if(editors.Length < 1)
            {
                goto label_6;
            }
            // 0x028BF884: ADRP x25, #0x3615000       | X25 = 56709120 (0x3615000);             
            // 0x028BF888: ADRP x26, #0x3602000       | X26 = 56631296 (0x3602000);             
            // 0x028BF88C: ADRP x28, #0x3671000       | X28 = 57085952 (0x3671000);             
            // 0x028BF890: LDR x25, [x25, #0x5d0]     | X25 = 1152921504841830400;              
            // 0x028BF894: LDR x26, [x26, #0xb88]     | X26 = 1152921504755408896;              
            // 0x028BF898: LDR x28, [x28, #0xab0]     | X28 = (string**)(1152921513276205024)("_editor.json");
            // 0x028BF89C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            object val_7 = 0;
            label_18:
            // 0x028BF8A0: SXTW x21, w24              | X21 = 0 (0x00000000);                   
            val_6 = 0;
            // 0x028BF8A4: CMP w24, w8                | STATE = COMPARE(0x0, editors.Length)    
            // 0x028BF8A8: B.LO #0x28bf8b8            | if (0 < editors.Length) goto label_5;   
            if(val_7 < editors.Length)
            {
                goto label_5;
            }
            // 0x028BF8AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x123D, ????);     
            // 0x028BF8B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF8B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x123D, ????);     
            label_5:
            // 0x028BF8B8: ADD x27, x19, x21, lsl #3  | X27 = editors[0x0]; //PARR1             
            // 0x028BF8BC: LDR x8, [x27, #0x20]!      | X8 = editors[0x0][0]                    
            Pathfinding.GraphEditorBase val_6 = editors[val_6];
            // 0x028BF8C0: CBZ x8, #0x28bfa30         | if (editors[0x0][0] == null) goto label_6;
            if(val_6 == null)
            {
                goto label_6;
            }
            // 0x028BF8C4: LDR x0, [x25]              | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x028BF8C8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_10A;
            // 0x028BF8CC: TBZ w8, #0, #0x28bf8dc     | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028BF8D0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x028BF8D4: CBNZ w8, #0x28bf8dc        | if (Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028BF8D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            label_8:
            // 0x028BF8DC: BL #0x28bdbf8              | X0 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            System.Text.StringBuilder val_1 = Pathfinding.Serialization.AstarSerializer.GetStringBuilder();
            // 0x028BF8E0: LDR x8, [x26]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonWriter);
            // 0x028BF8E4: LDR x23, [x20, #0x18]      | X23 = this.writerSettings; //P2         
            // 0x028BF8E8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028BF8EC: MOV x0, x8                 | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            Pathfinding.Serialization.JsonFx.JsonWriter val_2 = null;
            // 0x028BF8F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            // 0x028BF8F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BF8F8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028BF8FC: MOV x2, x23                | X2 = this.writerSettings;//m1           
            // 0x028BF900: MOV x22, x0                | X22 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BF904: BL #0x26da234              | .ctor(output:  val_1, settings:  this.writerSettings);
            val_2 = new Pathfinding.Serialization.JsonFx.JsonWriter(output:  val_1, settings:  this.writerSettings);
            // 0x028BF908: LDR w8, [x19, #0x18]       | W8 = editors.Length; //P2               
            // 0x028BF90C: CMP w24, w8                | STATE = COMPARE(0x0, editors.Length)    
            // 0x028BF910: B.LO #0x28bf920            | if (0 < editors.Length) goto label_9;   
            if(val_7 < editors.Length)
            {
                goto label_9;
            }
            // 0x028BF914: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(output:  val_1, settings:  this.writerSettings), ????);
            // 0x028BF918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BF91C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(output:  val_1, settings:  this.writerSettings), ????);
            label_9:
            // 0x028BF920: LDR x23, [x27]             | X23 = editors[0x0] + 32;                
            val_7 = mem[editors[0x0] + 32];
            val_7 = editors[0x0] + 32;
            // 0x028BF924: CBNZ x22, #0x28bf92c       | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x028BF928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(output:  val_1, settings:  this.writerSettings), ????);
            label_10:
            // 0x028BF92C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BF930: MOV x0, x22                | X0 = 1152921504755408896 (0x1000000008DAE000);//ML01
            // 0x028BF934: MOV x1, x23                | X1 = editors[0x0] + 32;//m1             
            // 0x028BF938: BL #0x26d497c              | Write(value:  val_7);                   
            Write(value:  val_7);
            // 0x028BF93C: LDR x22, [x20, #0x58]      | X22 = this.encoding; //P2               
            // 0x028BF940: CBNZ x21, #0x28bf948       | if (val_1 != null) goto label_11;       
            if(val_1 != null)
            {
                goto label_11;
            }
            // 0x028BF944: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Serialization.JsonFx.JsonWriter), ????);
            label_11:
            // 0x028BF948: LDR x8, [x21]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x028BF94C: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x028BF950: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x028BF954: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x028BF958: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028BF95C: CBNZ x22, #0x28bf964       | if (this.encoding != null) goto label_12;
            if(this.encoding != null)
            {
                goto label_12;
            }
            // 0x028BF960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_12:
            // 0x028BF964: LDR x8, [x22]              | X8 = typeof(System.Text.UTF8Encoding);  
            // 0x028BF968: MOV x0, x22                | X0 = this.encoding;//m1                 
            // 0x028BF96C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028BF970: LDP x9, x2, [x8, #0x1c0]   | X9 = public System.Byte[] System.Text.Encoding::GetBytes(string s); X2 = public System.Byte[] System.Text.Encoding::GetBytes(string s); //  | 
            // 0x028BF974: BLR x9                     | X0 = this.encoding.GetBytes(s:  val_1); 
            System.Byte[] val_3 = this.encoding.GetBytes(s:  val_1);
            // 0x028BF978: MOV x21, x0                | X21 = val_3;//m1                        
            val_6 = val_3;
            // 0x028BF97C: CBNZ x21, #0x28bf984       | if (val_3 != null) goto label_13;       
            if(val_6 != null)
            {
                goto label_13;
            }
            // 0x028BF980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_13:
            // 0x028BF984: LDR w8, [x21, #0x18]       | W8 = val_3.Length; //P2                 
            // 0x028BF988: CMP w8, #3                 | STATE = COMPARE(val_3.Length, 0x3)      
            // 0x028BF98C: B.LT #0x28bfa20            | if (val_3.Length < 3) goto label_14;    
            if(val_3.Length < 3)
            {
                goto label_14;
            }
            // 0x028BF990: MOV x0, x20                | X0 = 1152921513276298752 (0x1000000204BD5600);//ML01
            // 0x028BF994: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028BF998: BL #0x28bdc84              | this.AddChecksum(bytes:  val_6);        
            this.AddChecksum(bytes:  val_6);
            // 0x028BF99C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028BF9A0: LDR x22, [x20, #0x28]      | X22 = this.zip; //P2                    
            // 0x028BF9A4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028BF9A8: ADD x1, sp, #0xc           | X1 = (1152921513276286640 + 12) = 1152921513276286652 (0x1000000204BD26BC);
            // 0x028BF9AC: STR w24, [sp, #0xc]        | stack[1152921513276286652] = 0x0;        //  dest_result_addr=1152921513276286652
            // 0x028BF9B0: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028BF9B4: BL #0x27bc028              | X0 = 1152921513276429056 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 0);
            // 0x028BF9B8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028BF9BC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028BF9C0: MOV x23, x0                | X23 = 1152921513276429056 (0x1000000204BF5300);//ML01
            // 0x028BF9C4: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028BF9C8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028BF9CC: TBZ w9, #0, #0x28bf9e0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x028BF9D0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028BF9D4: CBNZ w9, #0x28bf9e0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x028BF9D8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028BF9DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_16:
            // 0x028BF9E0: ADRP x8, #0x3684000        | X8 = 57163776 (0x3684000);              
            // 0x028BF9E4: LDR x8, [x8, #0x390]       | X8 = (string**)(1152921513124056064)("graph");
            // 0x028BF9E8: LDR x3, [x28]              | X3 = "_editor.json";                    
            // 0x028BF9EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BF9F0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028BF9F4: LDR x1, [x8]               | X1 = "graph";                           
            // 0x028BF9F8: MOV x2, x23                | X2 = 1152921513276429056 (0x1000000204BF5300);//ML01
            // 0x028BF9FC: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  0);
            string val_4 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_7);
            // 0x028BFA00: MOV x23, x0                | X23 = val_4;//m1                        
            val_7 = val_4;
            // 0x028BFA04: CBNZ x22, #0x28bfa0c       | if (this.zip != null) goto label_17;    
            if(this.zip != null)
            {
                goto label_17;
            }
            // 0x028BFA08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_17:
            // 0x028BFA0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BFA10: MOV x0, x22                | X0 = this.zip;//m1                      
            // 0x028BFA14: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x028BFA18: MOV x2, x21                | X2 = val_3;//m1                         
            // 0x028BFA1C: BL #0x1983670              | X0 = this.zip.AddEntry(entryName:  val_7, byteContent:  val_6);
            Pathfinding.Ionic.Zip.ZipEntry val_5 = this.zip.AddEntry(entryName:  val_7, byteContent:  val_6);
            label_14:
            // 0x028BFA20: LDR w8, [x19, #0x18]       | W8 = editors.Length; //P2               
            // 0x028BFA24: ADD w24, w24, #1           | W24 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x028BFA28: CMP w24, w8                | STATE = COMPARE((0 + 1), editors.Length)
            // 0x028BFA2C: B.LT #0x28bf8a0            | if (0 < editors.Length) goto label_18;  
            if(val_7 < editors.Length)
            {
                goto label_18;
            }
            label_6:
            // 0x028BFA30: SUB sp, x29, #0x50         | SP = (1152921513276286736 - 80) = 1152921513276286656 (0x1000000204BD26C0);
            // 0x028BFA34: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028BFA38: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028BFA3C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028BFA40: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028BFA44: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028BFA48: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028BFA4C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028BFA50 (42728016), len: 2036  VirtAddr: 0x028BFA50 RVA: 0x028BFA50 token: 100682633 methodIndex: 51170 delegateWrapperIndex: 0 methodInvoker: 0
        public bool OpenDeserialize(byte[] bytes)
        {
            //
            // Disasemble & Code
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            // 0x028BFA50: STP x22, x21, [sp, #-0x30]! | stack[1152921513276637568] = ???;  stack[1152921513276637576] = ???;  //  dest_result_addr=1152921513276637568 |  dest_result_addr=1152921513276637576
            // 0x028BFA54: STP x20, x19, [sp, #0x10]  | stack[1152921513276637584] = ???;  stack[1152921513276637592] = ???;  //  dest_result_addr=1152921513276637584 |  dest_result_addr=1152921513276637592
            // 0x028BFA58: STP x29, x30, [sp, #0x20]  | stack[1152921513276637600] = ???;  stack[1152921513276637608] = ???;  //  dest_result_addr=1152921513276637600 |  dest_result_addr=1152921513276637608
            // 0x028BFA5C: ADD x29, sp, #0x20         | X29 = (1152921513276637568 + 32) = 1152921513276637600 (0x1000000204C281A0);
            // 0x028BFA60: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028BFA64: LDRB w8, [x21, #0x946]     | W8 = (bool)static_value_037B8946;       
            // 0x028BFA68: MOV x20, x1                | X20 = bytes;//m1                        
            // 0x028BFA6C: MOV x19, x0                | X19 = 1152921513276649616 (0x1000000204C2B090);//ML01
            val_19 = this;
            // 0x028BFA70: TBNZ w8, #0, #0x28bfa8c    | if (static_value_037B8946 == true) goto label_0;
            // 0x028BFA74: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028BFA78: LDR x8, [x8, #0xa98]       | X8 = 0x2B8EDE4;                         
            // 0x028BFA7C: LDR w0, [x8]               | W0 = 0x1239;                            
            // 0x028BFA80: BL #0x2782188              | X0 = sub_2782188( ?? 0x1239, ????);     
            // 0x028BFA84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028BFA88: STRB w8, [x21, #0x946]     | static_value_037B8946 = true;            //  dest_result_addr=58427718
            label_0:
            // 0x028BFA8C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x028BFA90: LDR x8, [x8, #0x540]       | X8 = 1152921504755089408;               
            // 0x028BFA94: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);
            Pathfinding.Serialization.JsonFx.JsonReaderSettings val_1 = null;
            // 0x028BFA98: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings), ????);
            // 0x028BFA9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFAA0: MOV x21, x0                | X21 = 1152921504755089408 (0x1000000008D60000);//ML01
            // 0x028BFAA4: BL #0x26d5264              | .ctor();                                
            val_1 = new Pathfinding.Serialization.JsonFx.JsonReaderSettings();
            // 0x028BFAA8: STR x21, [x19, #0x20]      | this.readerSettings = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);  //  dest_result_addr=1152921513276649648
            this.readerSettings = val_1;
            // 0x028BFAAC: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x028BFAB0: LDR x8, [x8, #0x630]       | X8 = 1152921504841670656;               
            // 0x028BFAB4: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.VectorConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_2 = null;
            // 0x028BFAB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.VectorConverter), ????);
            // 0x028BFABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFAC0: MOV x22, x0                | X22 = 1152921504841670656 (0x100000000DFF2000);//ML01
            // 0x028BFAC4: BL #0x26d4920              | .ctor();                                
            val_2 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BFAC8: CBNZ x21, #0x28bfad0       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x028BFACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x028BFAD0: LDR x8, [x21]              | X8 = ;                                  
            // 0x028BFAD4: MOV x0, x21                | X0 = 1152921504755089408 (0x1000000008D60000);//ML01
            // 0x028BFAD8: MOV x1, x22                | X1 = 1152921504841670656 (0x100000000DFF2000);//ML01
            // 0x028BFADC: LDP x9, x2, [x8, #0x160]   |                                          //  not_find_field!1:352 |  not_find_field!1:360
            // 0x028BFAE0: BLR x9                     | X0 = mem[null + 352]();                 
            // 0x028BFAE4: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x028BFAE8: LDR x21, [x19, #0x20]      | X21 = this.readerSettings; //P2         
            // 0x028BFAEC: LDR x8, [x8, #0x510]       | X8 = 1152921504841564160;               
            // 0x028BFAF0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.BoundsConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_3 = null;
            // 0x028BFAF4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.BoundsConverter), ????);
            // 0x028BFAF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFAFC: MOV x22, x0                | X22 = 1152921504841564160 (0x100000000DFD8000);//ML01
            // 0x028BFB00: BL #0x26d4920              | .ctor();                                
            val_3 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BFB04: CBNZ x21, #0x28bfb0c       | if (this.readerSettings != null) goto label_2;
            if(this.readerSettings != null)
            {
                goto label_2;
            }
            // 0x028BFB08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x028BFB0C: LDR x8, [x21]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);
            // 0x028BFB10: MOV x0, x21                | X0 = this.readerSettings;//m1           
            // 0x028BFB14: MOV x1, x22                | X1 = 1152921504841564160 (0x100000000DFD8000);//ML01
            // 0x028BFB18: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_168; //  | 
            // 0x028BFB1C: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160();
            // 0x028BFB20: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028BFB24: LDR x21, [x19, #0x20]      | X21 = this.readerSettings; //P2         
            // 0x028BFB28: LDR x8, [x8, #0x6c8]       | X8 = 1152921504841617408;               
            // 0x028BFB2C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.LayerMaskConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_4 = null;
            // 0x028BFB30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.LayerMaskConverter), ????);
            // 0x028BFB34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFB38: MOV x22, x0                | X22 = 1152921504841617408 (0x100000000DFE5000);//ML01
            // 0x028BFB3C: BL #0x26d4920              | .ctor();                                
            val_4 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BFB40: CBNZ x21, #0x28bfb48       | if (this.readerSettings != null) goto label_3;
            if(this.readerSettings != null)
            {
                goto label_3;
            }
            // 0x028BFB44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x028BFB48: LDR x8, [x21]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);
            // 0x028BFB4C: MOV x0, x21                | X0 = this.readerSettings;//m1           
            // 0x028BFB50: MOV x1, x22                | X1 = 1152921504841617408 (0x100000000DFE5000);//ML01
            // 0x028BFB54: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_168; //  | 
            // 0x028BFB58: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160();
            // 0x028BFB5C: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x028BFB60: LDR x21, [x19, #0x20]      | X21 = this.readerSettings; //P2         
            // 0x028BFB64: LDR x8, [x8, #0xb18]       | X8 = 1152921504841510912;               
            // 0x028BFB68: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.MatrixConverter);
            Pathfinding.Serialization.MatrixConverter val_5 = null;
            // 0x028BFB6C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.MatrixConverter), ????);
            // 0x028BFB70: MOV x22, x0                | X22 = 1152921504841510912 (0x100000000DFCB000);//ML01
            // 0x028BFB74: BL #0x28be0c4              | .ctor();                                
            val_5 = new Pathfinding.Serialization.MatrixConverter();
            // 0x028BFB78: CBNZ x21, #0x28bfb80       | if (this.readerSettings != null) goto label_4;
            if(this.readerSettings != null)
            {
                goto label_4;
            }
            // 0x028BFB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_4:
            // 0x028BFB80: LDR x8, [x21]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);
            // 0x028BFB84: MOV x0, x21                | X0 = this.readerSettings;//m1           
            // 0x028BFB88: MOV x1, x22                | X1 = 1152921504841510912 (0x100000000DFCB000);//ML01
            // 0x028BFB8C: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_168; //  | 
            // 0x028BFB90: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160();
            // 0x028BFB94: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x028BFB98: LDR x21, [x19, #0x20]      | X21 = this.readerSettings; //P2         
            // 0x028BFB9C: LDR x8, [x8, #0xe60]       | X8 = 1152921504841457664;               
            // 0x028BFBA0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GuidConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_6 = null;
            // 0x028BFBA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GuidConverter), ????);
            // 0x028BFBA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFBAC: MOV x22, x0                | X22 = 1152921504841457664 (0x100000000DFBE000);//ML01
            // 0x028BFBB0: BL #0x26d4920              | .ctor();                                
            val_6 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BFBB4: CBNZ x21, #0x28bfbbc       | if (this.readerSettings != null) goto label_5;
            if(this.readerSettings != null)
            {
                goto label_5;
            }
            // 0x028BFBB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x028BFBBC: LDR x8, [x21]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);
            // 0x028BFBC0: MOV x0, x21                | X0 = this.readerSettings;//m1           
            // 0x028BFBC4: MOV x1, x22                | X1 = 1152921504841457664 (0x100000000DFBE000);//ML01
            // 0x028BFBC8: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_168; //  | 
            // 0x028BFBCC: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160();
            // 0x028BFBD0: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028BFBD4: LDR x21, [x19, #0x20]      | X21 = this.readerSettings; //P2         
            // 0x028BFBD8: LDR x8, [x8, #0x9c0]       | X8 = 1152921504841404416;               
            // 0x028BFBDC: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.UnityObjectConverter);
            Pathfinding.Serialization.JsonFx.JsonConverter val_7 = null;
            // 0x028BFBE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.UnityObjectConverter), ????);
            // 0x028BFBE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFBE8: MOV x22, x0                | X22 = 1152921504841404416 (0x100000000DFB1000);//ML01
            // 0x028BFBEC: BL #0x26d4920              | .ctor();                                
            val_7 = new Pathfinding.Serialization.JsonFx.JsonConverter();
            // 0x028BFBF0: CBNZ x21, #0x28bfbf8       | if (this.readerSettings != null) goto label_6;
            if(this.readerSettings != null)
            {
                goto label_6;
            }
            // 0x028BFBF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_6:
            // 0x028BFBF8: LDR x8, [x21]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings);
            // 0x028BFBFC: MOV x0, x21                | X0 = this.readerSettings;//m1           
            // 0x028BFC00: MOV x1, x22                | X1 = 1152921504841404416 (0x100000000DFB1000);//ML01
            // 0x028BFC04: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_168; //  | 
            // 0x028BFC08: BLR x9                     | X0 = typeof(Pathfinding.Serialization.JsonFx.JsonReaderSettings).__il2cppRuntimeField_160();
            // 0x028BFC0C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028BFC10: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028BFC14: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_8 = null;
            // 0x028BFC18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028BFC1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFC20: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BFC24: BL #0x1e762f4              | .ctor();                                
            val_8 = new System.IO.MemoryStream();
            // 0x028BFC28: STR x21, [x19, #0x30]      | this.str = typeof(System.IO.MemoryStream);  //  dest_result_addr=1152921513276649664
            this.str = val_8;
            // 0x028BFC2C: CBNZ x20, #0x28bfc34       | if (bytes != null) goto label_7;        
            if(bytes != null)
            {
                goto label_7;
            }
            // 0x028BFC30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_7:
            // 0x028BFC34: CBNZ x21, #0x28bfc3c       | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x028BFC38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_8:
            // 0x028BFC3C: LDR x8, [x21]              | X8 = ;                                  
            // 0x028BFC40: LDR w3, [x20, #0x18]       | W3 = bytes.Length; //P2                 
            // 0x028BFC44: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028BFC48: MOV x0, x21                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028BFC4C: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
            // 0x028BFC50: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
            // 0x028BFC54: MOV x1, x20                | X1 = bytes;//m1                         
            // 0x028BFC58: BLR x9                     | X0 = mem[null + 608]();                 
            // 0x028BFC5C: LDR x20, [x19, #0x30]      | X20 = this.str; //P2                    
            // 0x028BFC60: CBNZ x20, #0x28bfc68       | if (this.str != null) goto label_9;     
            if(this.str != null)
            {
                goto label_9;
            }
            // 0x028BFC64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_9:
            // 0x028BFC68: LDR x8, [x20]              | X8 = typeof(System.IO.MemoryStream);    
            // 0x028BFC6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFC70: MOV x0, x20                | X0 = this.str;//m1                      
            // 0x028BFC74: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0; X2 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B8; //  | 
            // 0x028BFC78: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0();
            // 0x028BFC7C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x028BFC80: LDR x8, [x8, #0x3e0]       | X8 = 1152921504751788032;               
            // 0x028BFC84: LDR x20, [x19, #0x30]      | X20 = this.str; //P2                    
            // 0x028BFC88: LDR x0, [x8]               | X0 = typeof(Pathfinding.Ionic.Zip.ZipFile);
            // 0x028BFC8C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Ionic.Zip.ZipFile.__il2cppRuntimeField_10A;
            // 0x028BFC90: TBZ w8, #0, #0x28bfca0     | if (Pathfinding.Ionic.Zip.ZipFile.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x028BFC94: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Ionic.Zip.ZipFile.__il2cppRuntimeField_cctor_finished;
            // 0x028BFC98: CBNZ w8, #0x28bfca0        | if (Pathfinding.Ionic.Zip.ZipFile.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x028BFC9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Ionic.Zip.ZipFile), ????);
            label_11:
            // 0x028BFCA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFCA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BFCA8: MOV x1, x20                | X1 = this.str;//m1                      
            // 0x028BFCAC: BL #0x1983d4c              | X0 = Pathfinding.Ionic.Zip.ZipFile.Read(zipStream:  0);
            Pathfinding.Ionic.Zip.ZipFile val_9 = Pathfinding.Ionic.Zip.ZipFile.Read(zipStream:  0);
            // 0x028BFCB0: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x028BFCB4: STR x20, [x19, #0x28]      | this.zip = val_9;                        //  dest_result_addr=1152921513276649656
            this.zip = val_9;
            // 0x028BFCB8: CBNZ x20, #0x28bfcc0       | if (val_9 != null) goto label_12;       
            if(val_9 != null)
            {
                goto label_12;
            }
            // 0x028BFCBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_12:
            // 0x028BFCC0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x028BFCC4: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921513272027088)("meta.json");
            // 0x028BFCC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028BFCCC: MOV x0, x20                | X0 = val_9;//m1                         
            // 0x028BFCD0: LDR x1, [x8]               | X1 = "meta.json";                       
            // 0x028BFCD4: BL #0x197972c              | X0 = val_9.get_Item(fileName:  "meta.json");
            Pathfinding.Ionic.Zip.ZipEntry val_10 = val_9.Item["meta.json"];
            // 0x028BFCD8: MOV x1, x0                 | X1 = val_10;//m1                        
            // 0x028BFCDC: MOV x0, x19                | X0 = 1152921513276649616 (0x1000000204C2B090);//ML01
            // 0x028BFCE0: BL #0x28c0244              | X0 = this.DeserializeMeta(entry:  val_10);
            Pathfinding.Serialization.GraphMeta val_11 = this.DeserializeMeta(entry:  val_10);
            // 0x028BFCE4: MOV x20, x0                | X20 = val_11;//m1                       
            // 0x028BFCE8: STR x20, [x19, #0x38]      | this.meta = val_11;                      //  dest_result_addr=1152921513276649672
            this.meta = val_11;
            // 0x028BFCEC: CBNZ x20, #0x28bfcf4       | if (val_11 != null) goto label_13;      
            if(val_11 != null)
            {
                goto label_13;
            }
            // 0x028BFCF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_13:
            // 0x028BFCF4: ADRP x21, #0x362c000       | X21 = 56803328 (0x362C000);             
            // 0x028BFCF8: LDR x21, [x21, #0xe80]     | X21 = 1152921504837996544;              
            val_20 = 1152921504837996544;
            // 0x028BFCFC: LDR x20, [x20, #0x10]      | X20 = val_11.version; //P2              
            // 0x028BFD00: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            // 0x028BFD04: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x028BFD08: TBZ w8, #0, #0x28bfd18     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x028BFD0C: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x028BFD10: CBNZ w8, #0x28bfd18        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x028BFD14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            label_15:
            // 0x028BFD18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFD1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFD20: BL #0xb36d44               | X0 = AstarPath.get_Version();           
            System.Version val_12 = AstarPath.Version;
            // 0x028BFD24: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x028BFD28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFD2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BFD30: MOV x1, x20                | X1 = val_11.version;//m1                
            // 0x028BFD34: BL #0x273c7c4              | X0 = System.Version.op_GreaterThan(v1:  0, v2:  val_11.version);
            bool val_13 = System.Version.op_GreaterThan(v1:  0, v2:  val_11.version);
            // 0x028BFD38: TBZ w0, #0, #0x28bfeb8     | if (val_13 == false) goto label_16;     
            if(val_13 == false)
            {
                goto label_16;
            }
            // 0x028BFD3C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028BFD40: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x028BFD44: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x028BFD48: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028BFD4C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x028BFD50: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x028BFD54: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028BFD58: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x028BFD5C: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_21 = null;
            // 0x028BFD60: CBNZ x20, #0x28bfd68       | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x028BFD64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_17:
            // 0x028BFD68: ADRP x22, #0x3628000       | X22 = 56786944 (0x3628000);             
            // 0x028BFD6C: LDR x22, [x22, #0xea8]     | X22 = (string**)(1152921513276583360)("Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ");
            // 0x028BFD70: LDR x0, [x22]              | X0 = "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ";
            // 0x028BFD74: CBZ x0, #0x28bfd94         | if ("Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: " == null) goto label_19;
            // 0x028BFD78: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFD7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFD80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ", ????);
            // 0x028BFD84: CBNZ x0, #0x28bfd94        | if ("Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: " != null) goto label_19;
            if(("Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ") != null)
            {
                goto label_19;
            }
            // 0x028BFD88: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ", ????);
            // 0x028BFD8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFD90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ", ????);
            label_19:
            // 0x028BFD94: LDR x22, [x22]             | X22 = "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ";
            // 0x028BFD98: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028BFD9C: CBNZ w8, #0x28bfdac        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_20;
            // 0x028BFDA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ", ????);
            // 0x028BFDA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFDA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ", ????);
            label_20:
            // 0x028BFDAC: STR x22, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ";
            // 0x028BFDB0: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            // 0x028BFDB4: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x028BFDB8: TBZ w8, #0, #0x28bfdc8     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x028BFDBC: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x028BFDC0: CBNZ w8, #0x28bfdc8        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x028BFDC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            label_22:
            // 0x028BFDC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFDCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFDD0: BL #0xb36d44               | X0 = AstarPath.get_Version();           
            System.Version val_14 = AstarPath.Version;
            // 0x028BFDD4: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x028BFDD8: CBZ x21, #0x28bfdfc        | if (val_14 == null) goto label_24;      
            if(val_14 == null)
            {
                goto label_24;
            }
            // 0x028BFDDC: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFDE0: MOV x0, x21                | X0 = val_14;//m1                        
            // 0x028BFDE4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFDE8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x028BFDEC: CBNZ x0, #0x28bfdfc        | if (val_14 != null) goto label_24;      
            if(val_14 != null)
            {
                goto label_24;
            }
            // 0x028BFDF0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x028BFDF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFDF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_24:
            // 0x028BFDFC: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028BFE00: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028BFE04: B.HI #0x28bfe14            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_25;
            // 0x028BFE08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x028BFE0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFE10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_25:
            // 0x028BFE14: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_14;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_14;
            // 0x028BFE18: ADRP x21, #0x3664000       | X21 = 57032704 (0x3664000);             
            // 0x028BFE1C: LDR x21, [x21, #0x3f8]     | X21 = (string**)(1152921513276587712)(" Data version: ");
            // 0x028BFE20: LDR x0, [x21]              | X0 = " Data version: ";                 
            // 0x028BFE24: CBZ x0, #0x28bfe44         | if (" Data version: " == null) goto label_27;
            // 0x028BFE28: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFE2C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFE30: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " Data version: ", ????);
            // 0x028BFE34: CBNZ x0, #0x28bfe44        | if (" Data version: " != null) goto label_27;
            if((" Data version: ") != null)
            {
                goto label_27;
            }
            // 0x028BFE38: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " Data version: ", ????);
            // 0x028BFE3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFE40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " Data version: ", ????);
            label_27:
            // 0x028BFE44: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028BFE48: LDR x21, [x21]             | X21 = " Data version: ";                
            val_20 = " Data version: ";
            // 0x028BFE4C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x028BFE50: B.HI #0x28bfe60            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_28;
            // 0x028BFE54: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " Data version: ", ????);
            // 0x028BFE58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFE5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " Data version: ", ????);
            label_28:
            // 0x028BFE60: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = " Data version: ";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = val_20;
            // 0x028BFE64: LDR x19, [x19, #0x38]      | X19 = this.meta; //P2                   
            // 0x028BFE68: CBNZ x19, #0x28bfe70       | if (this.meta != null) goto label_29;   
            if(this.meta != null)
            {
                goto label_29;
            }
            // 0x028BFE6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? " Data version: ", ????);
            label_29:
            // 0x028BFE70: LDR x19, [x19, #0x10]      | X19 = this.meta.version; //P2           
            // 0x028BFE74: CBZ x19, #0x28bfe98        | if (this.meta.version == null) goto label_31;
            if(this.meta.version == null)
            {
                goto label_31;
            }
            // 0x028BFE78: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFE7C: MOV x0, x19                | X0 = this.meta.version;//m1             
            // 0x028BFE80: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFE84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.meta.version, ????);
            // 0x028BFE88: CBNZ x0, #0x28bfe98        | if (this.meta.version != null) goto label_31;
            if(this.meta.version != null)
            {
                goto label_31;
            }
            // 0x028BFE8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.meta.version, ????);
            // 0x028BFE90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFE94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.meta.version, ????);
            label_31:
            // 0x028BFE98: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028BFE9C: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x028BFEA0: B.HI #0x28bfeb0            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_32;
            // 0x028BFEA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.meta.version, ????);
            // 0x028BFEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFEAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.meta.version, ????);
            label_32:
            // 0x028BFEB0: STR x19, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = this.meta.version;  //  dest_result_addr=1152921504954501320
            typeof(System.Object[]).__il2cppRuntimeField_38 = this.meta.version;
            // 0x028BFEB4: B #0x28c00c8               |  goto label_33;                         
            goto label_33;
            label_16:
            // 0x028BFEB8: LDR x20, [x19, #0x38]      | X20 = this.meta; //P2                   
            // 0x028BFEBC: CBNZ x20, #0x28bfec4       | if (this.meta != null) goto label_34;   
            if(this.meta != null)
            {
                goto label_34;
            }
            // 0x028BFEC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_34:
            // 0x028BFEC4: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            // 0x028BFEC8: LDR x20, [x20, #0x10]      | X20 = this.meta.version; //P2           
            // 0x028BFECC: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x028BFED0: TBZ w8, #0, #0x28bfee0     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x028BFED4: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x028BFED8: CBNZ w8, #0x28bfee0        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x028BFEDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            label_36:
            // 0x028BFEE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFEE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFEE8: BL #0xb36d44               | X0 = AstarPath.get_Version();           
            System.Version val_15 = AstarPath.Version;
            // 0x028BFEEC: MOV x2, x0                 | X2 = val_15;//m1                        
            // 0x028BFEF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFEF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028BFEF8: MOV x1, x20                | X1 = this.meta.version;//m1             
            // 0x028BFEFC: BL #0x273c800              | X0 = System.Version.op_LessThan(v1:  0, v2:  this.meta.version);
            bool val_16 = System.Version.op_LessThan(v1:  0, v2:  this.meta.version);
            // 0x028BFF00: TBZ w0, #0, #0x28c0130     | if (val_16 == false) goto label_37;     
            if(val_16 == false)
            {
                goto label_37;
            }
            // 0x028BFF04: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028BFF08: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x028BFF0C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x028BFF10: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028BFF14: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x028BFF18: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x028BFF1C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028BFF20: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x028BFF24: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_21 = null;
            // 0x028BFF28: CBNZ x20, #0x28bff30       | if ( != null) goto label_38;            
            if(null != null)
            {
                goto label_38;
            }
            // 0x028BFF2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_38:
            // 0x028BFF30: ADRP x22, #0x3636000       | X22 = 56844288 (0x3636000);             
            // 0x028BFF34: LDR x22, [x22, #0x5a0]     | X22 = (string**)(1152921513276608304)("Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ");
            // 0x028BFF38: LDR x0, [x22]              | X0 = "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ";
            // 0x028BFF3C: CBZ x0, #0x28bff5c         | if ("Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: " == null) goto label_40;
            // 0x028BFF40: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFF44: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFF48: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ", ????);
            // 0x028BFF4C: CBNZ x0, #0x28bff5c        | if ("Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: " != null) goto label_40;
            if(("Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ") != null)
            {
                goto label_40;
            }
            // 0x028BFF50: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ", ????);
            // 0x028BFF54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFF58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ", ????);
            label_40:
            // 0x028BFF5C: LDR x22, [x22]             | X22 = "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ";
            // 0x028BFF60: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028BFF64: CBNZ w8, #0x28bff74        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_41;
            // 0x028BFF68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ", ????);
            // 0x028BFF6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFF70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ", ????);
            label_41:
            // 0x028BFF74: STR x22, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ";
            // 0x028BFF78: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            // 0x028BFF7C: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x028BFF80: TBZ w8, #0, #0x28bff90     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_43;
            // 0x028BFF84: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x028BFF88: CBNZ w8, #0x28bff90        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
            // 0x028BFF8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            label_43:
            // 0x028BFF90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028BFF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFF98: BL #0xb36d44               | X0 = AstarPath.get_Version();           
            System.Version val_17 = AstarPath.Version;
            // 0x028BFF9C: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x028BFFA0: CBZ x21, #0x28bffc4        | if (val_17 == null) goto label_45;      
            if(val_17 == null)
            {
                goto label_45;
            }
            // 0x028BFFA4: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFFA8: MOV x0, x21                | X0 = val_17;//m1                        
            // 0x028BFFAC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFFB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x028BFFB4: CBNZ x0, #0x28bffc4        | if (val_17 != null) goto label_45;      
            if(val_17 != null)
            {
                goto label_45;
            }
            // 0x028BFFB8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x028BFFBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFFC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_45:
            // 0x028BFFC4: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028BFFC8: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028BFFCC: B.HI #0x28bffdc            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_46;
            // 0x028BFFD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x028BFFD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028BFFD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_46:
            // 0x028BFFDC: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_17;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_17;
            // 0x028BFFE0: ADRP x21, #0x3664000       | X21 = 57032704 (0x3664000);             
            // 0x028BFFE4: LDR x21, [x21, #0x3f8]     | X21 = (string**)(1152921513276587712)(" Data version: ");
            // 0x028BFFE8: LDR x0, [x21]              | X0 = " Data version: ";                 
            // 0x028BFFEC: CBZ x0, #0x28c000c         | if (" Data version: " == null) goto label_48;
            // 0x028BFFF0: LDR x8, [x20]              | X8 = ;                                  
            // 0x028BFFF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028BFFF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " Data version: ", ????);
            // 0x028BFFFC: CBNZ x0, #0x28c000c        | if (" Data version: " != null) goto label_48;
            if((" Data version: ") != null)
            {
                goto label_48;
            }
            // 0x028C0000: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " Data version: ", ????);
            // 0x028C0004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0008: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " Data version: ", ????);
            label_48:
            // 0x028C000C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C0010: LDR x21, [x21]             | X21 = " Data version: ";                
            val_20 = " Data version: ";
            // 0x028C0014: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x028C0018: B.HI #0x28c0028            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_49;
            // 0x028C001C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " Data version: ", ????);
            // 0x028C0020: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0024: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " Data version: ", ????);
            label_49:
            // 0x028C0028: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = " Data version: ";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = val_20;
            // 0x028C002C: LDR x19, [x19, #0x38]      | X19 = this.meta; //P2                   
            // 0x028C0030: CBNZ x19, #0x28c0038       | if (this.meta != null) goto label_50;   
            if(this.meta != null)
            {
                goto label_50;
            }
            // 0x028C0034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? " Data version: ", ????);
            label_50:
            // 0x028C0038: LDR x19, [x19, #0x10]      | X19 = this.meta.version; //P2           
            // 0x028C003C: CBZ x19, #0x28c0060        | if (this.meta.version == null) goto label_52;
            if(this.meta.version == null)
            {
                goto label_52;
            }
            // 0x028C0040: LDR x8, [x20]              | X8 = ;                                  
            // 0x028C0044: MOV x0, x19                | X0 = this.meta.version;//m1             
            // 0x028C0048: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C004C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.meta.version, ????);
            // 0x028C0050: CBNZ x0, #0x28c0060        | if (this.meta.version != null) goto label_52;
            if(this.meta.version != null)
            {
                goto label_52;
            }
            // 0x028C0054: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.meta.version, ????);
            // 0x028C0058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C005C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.meta.version, ????);
            label_52:
            // 0x028C0060: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C0064: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x028C0068: B.HI #0x28c0078            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_53;
            // 0x028C006C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.meta.version, ????);
            // 0x028C0070: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0074: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.meta.version, ????);
            label_53:
            // 0x028C0078: STR x19, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = this.meta.version;  //  dest_result_addr=1152921504954501320
            typeof(System.Object[]).__il2cppRuntimeField_38 = this.meta.version;
            // 0x028C007C: ADRP x19, #0x35d0000       | X19 = 56426496 (0x35D0000);             
            // 0x028C0080: LDR x19, [x19, #0x140]     | X19 = (string**)(1152921513276620848)("\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n");
            // 0x028C0084: LDR x0, [x19]              | X0 = "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n";
            // 0x028C0088: CBZ x0, #0x28c00a8         | if ("\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n" == null) goto label_55;
            // 0x028C008C: LDR x8, [x20]              | X8 = ;                                  
            // 0x028C0090: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C0094: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n", ????);
            // 0x028C0098: CBNZ x0, #0x28c00a8        | if ("\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n" != null) goto label_55;
            if("\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n" != null)
            {
                goto label_55;
            }
            // 0x028C009C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n", ????);
            // 0x028C00A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C00A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n", ????);
            label_55:
            // 0x028C00A8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C00AC: LDR x19, [x19]             | X19 = "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n";
            // 0x028C00B0: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x028C00B4: B.HI #0x28c00c4            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_56;
            // 0x028C00B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n", ????);
            // 0x028C00BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C00C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n", ????);
            label_56:
            // 0x028C00C4: STR x19, [x20, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n";  //  dest_result_addr=1152921504954501328
            typeof(System.Object[]).__il2cppRuntimeField_40 = "\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions, so it is recommendedto recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n";
            label_33:
            // 0x028C00C8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028C00CC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028C00D0: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x028C00D4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x028C00D8: TBZ w8, #0, #0x28c00e8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_58;
            // 0x028C00DC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C00E0: CBNZ w8, #0x28c00e8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_58;
            // 0x028C00E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_58:
            // 0x028C00E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C00EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C00F0: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028C00F4: BL #0x18b07f0              | X0 = System.String.Concat(args:  0);    
            string val_18 = System.String.Concat(args:  0);
            // 0x028C00F8: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x028C00FC: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x028C0100: MOV x19, x0                | X19 = val_18;//m1                       
            val_19 = val_18;
            // 0x028C0104: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x028C0108: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x028C010C: TBZ w9, #0, #0x28c0120     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x028C0110: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x028C0114: CBNZ w9, #0x28c0120        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x028C0118: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x028C011C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_60:
            // 0x028C0120: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C0124: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0128: MOV x1, x19                | X1 = val_18;//m1                        
            // 0x028C012C: BL #0x1a5dba0              | UnityEngine.Debug.LogWarning(message:  0);
            UnityEngine.Debug.LogWarning(message:  0);
            label_37:
            // 0x028C0130: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x028C0134: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C0138: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C013C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C0140: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028C03EC (42730476), len: 80  VirtAddr: 0x028C03EC RVA: 0x028C03EC token: 100682634 methodIndex: 51171 delegateWrapperIndex: 0 methodInvoker: 0
        public void CloseDeserialize()
        {
            //
            // Disasemble & Code
            // 0x028C03EC: STP x20, x19, [sp, #-0x20]! | stack[1152921513276884752] = ???;  stack[1152921513276884760] = ???;  //  dest_result_addr=1152921513276884752 |  dest_result_addr=1152921513276884760
            // 0x028C03F0: STP x29, x30, [sp, #0x10]  | stack[1152921513276884768] = ???;  stack[1152921513276884776] = ???;  //  dest_result_addr=1152921513276884768 |  dest_result_addr=1152921513276884776
            // 0x028C03F4: ADD x29, sp, #0x10         | X29 = (1152921513276884752 + 16) = 1152921513276884768 (0x1000000204C64720);
            // 0x028C03F8: MOV x19, x0                | X19 = 1152921513276896784 (0x1000000204C67610);//ML01
            // 0x028C03FC: LDR x20, [x19, #0x30]      | X20 = this.str; //P2                    
            // 0x028C0400: CBNZ x20, #0x28c0408       | if (this.str != null) goto label_0;     
            if(this.str != null)
            {
                goto label_0;
            }
            // 0x028C0404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x028C0408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C040C: MOV x0, x20                | X0 = this.str;//m1                      
            // 0x028C0410: BL #0x1e7cf4c              | this.str.Dispose();                     
            this.str.Dispose();
            // 0x028C0414: LDR x20, [x19, #0x28]!     | X20 = this.zip; //P2                    
            // 0x028C0418: CBNZ x20, #0x28c0420       | if (this.zip != null) goto label_1;     
            if(this.zip != null)
            {
                goto label_1;
            }
            // 0x028C041C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.str, ????);   
            label_1:
            // 0x028C0420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0424: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028C0428: BL #0x19879a4              | this.zip.Dispose();                     
            this.zip.Dispose();
            // 0x028C042C: STP xzr, xzr, [x19]        | this.zip = null;  this.str = null;       //  dest_result_addr=1152921513276896824 |  dest_result_addr=1152921513276896832
            this.zip = 0;
            this.str = 0;
            // 0x028C0430: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028C0434: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028C0438: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C043C (42730556), len: 1900  VirtAddr: 0x028C043C RVA: 0x028C043C token: 100682635 methodIndex: 51172 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph[] DeserializeGraphs()
        {
            //
            // Disasemble & Code
            //  | 
            object val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x028C043C: STP x28, x27, [sp, #-0x60]! | stack[1152921513277400864] = ???;  stack[1152921513277400872] = ???;  //  dest_result_addr=1152921513277400864 |  dest_result_addr=1152921513277400872
            // 0x028C0440: STP x26, x25, [sp, #0x10]  | stack[1152921513277400880] = ???;  stack[1152921513277400888] = ???;  //  dest_result_addr=1152921513277400880 |  dest_result_addr=1152921513277400888
            // 0x028C0444: STP x24, x23, [sp, #0x20]  | stack[1152921513277400896] = ???;  stack[1152921513277400904] = ???;  //  dest_result_addr=1152921513277400896 |  dest_result_addr=1152921513277400904
            // 0x028C0448: STP x22, x21, [sp, #0x30]  | stack[1152921513277400912] = ???;  stack[1152921513277400920] = ???;  //  dest_result_addr=1152921513277400912 |  dest_result_addr=1152921513277400920
            // 0x028C044C: STP x20, x19, [sp, #0x40]  | stack[1152921513277400928] = ???;  stack[1152921513277400936] = ???;  //  dest_result_addr=1152921513277400928 |  dest_result_addr=1152921513277400936
            // 0x028C0450: STP x29, x30, [sp, #0x50]  | stack[1152921513277400944] = ???;  stack[1152921513277400952] = ???;  //  dest_result_addr=1152921513277400944 |  dest_result_addr=1152921513277400952
            // 0x028C0454: ADD x29, sp, #0x50         | X29 = (1152921513277400864 + 80) = 1152921513277400944 (0x1000000204CE2770);
            // 0x028C0458: SUB sp, sp, #0x30          | SP = (1152921513277400864 - 48) = 1152921513277400816 (0x1000000204CE26F0);
            // 0x028C045C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028C0460: LDRB w8, [x20, #0x947]     | W8 = (bool)static_value_037B8947;       
            // 0x028C0464: MOV x19, x0                | X19 = 1152921513277412960 (0x1000000204CE5660);//ML01
            // 0x028C0468: TBNZ w8, #0, #0x28c0484    | if (static_value_037B8947 == true) goto label_0;
            // 0x028C046C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x028C0470: LDR x8, [x8, #0x8b8]       | X8 = 0x2B8EDC8;                         
            // 0x028C0474: LDR w0, [x8]               | W0 = 0x1232;                            
            // 0x028C0478: BL #0x2782188              | X0 = sub_2782188( ?? 0x1232, ????);     
            // 0x028C047C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C0480: STRB w8, [x20, #0x947]     | static_value_037B8947 = true;            //  dest_result_addr=58427719
            label_0:
            // 0x028C0484: STP xzr, xzr, [sp, #0x20]  | stack[1152921513277400848] = 0x0;  stack[1152921513277400856] = 0x0;  //  dest_result_addr=1152921513277400848 |  dest_result_addr=1152921513277400856
            // 0x028C0488: STP xzr, xzr, [sp, #0x10]  | stack[1152921513277400832] = 0x0;  stack[1152921513277400840] = 0x0;  //  dest_result_addr=1152921513277400832 |  dest_result_addr=1152921513277400840
            // 0x028C048C: STR xzr, [sp, #8]          | stack[1152921513277400824] = 0x0;        //  dest_result_addr=1152921513277400824
            // 0x028C0490: LDR x21, [x19, #0x38]      | X21 = this.meta; //P2                   
            // 0x028C0494: CBNZ x21, #0x28c049c       | if (this.meta != null) goto label_1;    
            if(this.meta != null)
            {
                goto label_1;
            }
            // 0x028C0498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1232, ????);     
            label_1:
            // 0x028C049C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028C04A0: LDR x8, [x8, #0xd20]       | X8 = 1152921507421177472;               
            // 0x028C04A4: LDR w21, [x21, #0x18]      | W21 = this.meta.graphs; //P2            
            // 0x028C04A8: LDR x20, [x8]              | X20 = typeof(Pathfinding.NavGraph[]);   
            // 0x028C04AC: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028C04B0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028C04B4: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028C04B8: MOV x1, x21                | X1 = this.meta.graphs;//m1              
            // 0x028C04BC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028C04C0: STR x0, [x19, #0x48]       | this.graphs = typeof(Pathfinding.NavGraph[]);  //  dest_result_addr=1152921513277413032
            this.graphs = null;
            // 0x028C04C4: ADRP x28, #0x3684000       | X28 = 57163776 (0x3684000);             
            // 0x028C04C8: ADRP x26, #0x3609000       | X26 = 56659968 (0x3609000);             
            // 0x028C04CC: ADRP x25, #0x3622000       | X25 = 56762368 (0x3622000);             
            // 0x028C04D0: ADRP x24, #0x35cc000       | X24 = 56410112 (0x35CC000);             
            // 0x028C04D4: LDR x28, [x28, #0x390]     | X28 = (string**)(1152921513124056064)("graph");
            // 0x028C04D8: LDR x26, [x26, #0xe08]     | X26 = (string**)(1152921513272282544)(".json");
            // 0x028C04DC: LDR x25, [x25, #0x828]     | X25 = 1152921504755036160;              
            // 0x028C04E0: LDR x24, [x24, #0xef8]     | X24 = 1152921513276997072;              
            // 0x028C04E4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x028C04E8: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            var val_19 = 0;
            // 0x028C04EC: B #0x28c04f4               |  goto label_2;                          
            goto label_2;
            label_25:
            // 0x028C04F0: ADD w20, w20, #1           | W20 = (val_18 + 1) = val_18 (0x00000001);
            val_18 = 1;
            label_2:
            // 0x028C04F4: LDR x21, [x19, #0x38]      | X21 = this.meta; //P2                   
            // 0x028C04F8: CBNZ x21, #0x28c0500       | if (this.meta != null) goto label_3;    
            if(this.meta != null)
            {
                goto label_3;
            }
            // 0x028C04FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_3:
            // 0x028C0500: LDR w8, [x21, #0x18]       | W8 = this.meta.graphs; //P2             
            // 0x028C0504: CMP w20, w8                | STATE = COMPARE(0x1, this.meta.graphs)  
            // 0x028C0508: B.GE #0x28c0848            | if (val_18 >= this.meta.graphs) goto label_4;
            if(val_18 >= this.meta.graphs)
            {
                goto label_4;
            }
            // 0x028C050C: LDR x21, [x19, #0x38]      | X21 = this.meta; //P2                   
            // 0x028C0510: CBNZ x21, #0x28c0518       | if (this.meta != null) goto label_5;    
            if(this.meta != null)
            {
                goto label_5;
            }
            // 0x028C0514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_5:
            // 0x028C0518: MOV x0, x21                | X0 = this.meta;//m1                     
            // 0x028C051C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x028C0520: BL #0x28c0ba8              | X0 = this.meta.GetGraphType(i:  1);     
            System.Type val_1 = this.meta.GetGraphType(i:  1);
            // 0x028C0524: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028C0528: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C052C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0530: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028C0534: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C0538: BL #0x1708de4              | X0 = System.Object.Equals(objA:  0, objB:  val_1);
            bool val_2 = System.Object.Equals(objA:  0, objB:  val_1);
            // 0x028C053C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x028C0540: TBNZ w8, #0, #0x28c04f0    | if ((val_2 & 1) == true) goto label_25; 
            if(val_3 == true)
            {
                goto label_25;
            }
            // 0x028C0544: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028C0548: LDR x22, [x19, #0x28]      | X22 = this.zip; //P2                    
            // 0x028C054C: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028C0550: ADD x1, sp, #4             | X1 = (1152921513277400816 + 4) = 1152921513277400820 (0x1000000204CE26F4);
            // 0x028C0554: STR w20, [sp, #4]          | stack[1152921513277400820] = 0x1;        //  dest_result_addr=1152921513277400820
            // 0x028C0558: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028C055C: BL #0x27bc028              | X0 = 1152921513277465440 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C0560: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028C0564: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028C0568: MOV x23, x0                | X23 = 1152921513277465440 (0x1000000204CF2360);//ML01
            // 0x028C056C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028C0570: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C0574: TBZ w9, #0, #0x28c0588     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028C0578: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C057C: CBNZ w9, #0x28c0588        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028C0580: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C0584: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x028C0588: LDR x1, [x28]              | X1 = "graph";                           
            // 0x028C058C: LDR x3, [x26]              | X3 = ".json";                           
            // 0x028C0590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C0594: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C0598: MOV x2, x23                | X2 = 1152921513277465440 (0x1000000204CF2360);//ML01
            // 0x028C059C: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_18);
            string val_4 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_18);
            // 0x028C05A0: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x028C05A4: CBNZ x22, #0x28c05ac       | if (this.zip != null) goto label_9;     
            if(this.zip != null)
            {
                goto label_9;
            }
            // 0x028C05A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_9:
            // 0x028C05AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C05B0: MOV x0, x22                | X0 = this.zip;//m1                      
            // 0x028C05B4: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x028C05B8: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  val_4);
            Pathfinding.Ionic.Zip.ZipEntry val_5 = this.zip.Item[val_4];
            // 0x028C05BC: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028C05C0: CBZ x22, #0x28c0974        | if (val_5 == null) goto label_10;       
            if(val_5 == null)
            {
                goto label_10;
            }
            // 0x028C05C4: LDR x23, [x19, #0x10]      | X23 = this.data; //P2                   
            // 0x028C05C8: CBNZ x23, #0x28c05d0       | if (this.data != null) goto label_11;   
            if(this.data != null)
            {
                goto label_11;
            }
            // 0x028C05CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_11:
            // 0x028C05D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C05D4: MOV x0, x23                | X0 = this.data;//m1                     
            // 0x028C05D8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028C05DC: BL #0x1681894              | X0 = this.data.CreateGraph(type:  val_1);
            Pathfinding.NavGraph val_6 = this.data.CreateGraph(type:  val_1);
            // 0x028C05E0: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x028C05E4: STR x0, [sp, #0x28]        | stack[1152921513277400856] = val_6;      //  dest_result_addr=1152921513277400856
            Pathfinding.NavGraph val_9 = val_6;
            // 0x028C05E8: BL #0x28c0d8c              | X0 = val_6.GetString(entry:  val_5);    
            string val_7 = val_6.GetString(entry:  val_5);
            // 0x028C05EC: LDR x8, [x25]              | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReader);
            // 0x028C05F0: LDR x22, [x19, #0x20]      | X22 = this.readerSettings; //P2         
            // 0x028C05F4: MOV x23, x0                | X23 = val_7;//m1                        
            // 0x028C05F8: MOV x0, x8                 | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            Pathfinding.Serialization.JsonFx.JsonReader val_8 = null;
            // 0x028C05FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonReader), ????);
            // 0x028C0600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C0604: MOV x1, x23                | X1 = val_7;//m1                         
            // 0x028C0608: MOV x2, x22                | X2 = this.readerSettings;//m1           
            // 0x028C060C: MOV x21, x0                | X21 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C0610: BL #0x26d5180              | .ctor(input:  val_7, settings:  this.readerSettings);
            val_8 = new Pathfinding.Serialization.JsonFx.JsonReader(input:  val_7, settings:  this.readerSettings);
            // 0x028C0614: CBNZ x21, #0x28c061c       | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x028C0618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_7, settings:  this.readerSettings), ????);
            label_12:
            // 0x028C061C: LDR x2, [x24]              | X2 = public System.Void Pathfinding.Serialization.JsonFx.JsonReader::PopulateObject<Pathfinding.NavGraph>(ref Pathfinding.NavGraph obj);
            // 0x028C0620: ADD x1, sp, #0x28          | X1 = (1152921513277400816 + 40) = 1152921513277400856 (0x1000000204CE2718);
            // 0x028C0624: MOV x0, x21                | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C0628: BL #0x10d7400              | PopulateObject<Pathfinding.NavGraph>(obj: ref  Pathfinding.NavGraph val_9 = val_6);
            PopulateObject<Pathfinding.NavGraph>(obj: ref  val_9);
            // 0x028C062C: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C0630: LDR x21, [sp, #0x28]       | X21 = val_6;                            
            // 0x028C0634: CBNZ x22, #0x28c063c       | if (this.graphs != null) goto label_13; 
            if(this.graphs != null)
            {
                goto label_13;
            }
            // 0x028C0638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.Serialization.JsonFx.JsonReader), ????);
            label_13:
            // 0x028C063C: CBZ x21, #0x28c0660        | if (val_6 == 0) goto label_15;          
            if(val_9 == 0)
            {
                goto label_15;
            }
            // 0x028C0640: LDR x8, [x22]              | X8 = typeof(Pathfinding.NavGraph[]);    
            // 0x028C0644: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028C0648: LDR x1, [x8, #0x30]        | X1 = Pathfinding.NavGraph[].__il2cppRuntimeField_element_class;
            // 0x028C064C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028C0650: CBNZ x0, #0x28c0660        | if (val_6 != 0) goto label_15;          
            if(val_9 != 0)
            {
                goto label_15;
            }
            // 0x028C0654: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x028C0658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C065C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_15:
            // 0x028C0660: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C0664: SXTW x23, w20              | X23 = 1 (0x00000001);                   
            // 0x028C0668: CMP w20, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C066C: B.LO #0x28c067c            | if (val_18 < this.graphs.Length) goto label_16;
            if(val_18 < this.graphs.Length)
            {
                goto label_16;
            }
            // 0x028C0670: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x028C0674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_16:
            // 0x028C067C: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C0680: STR x21, [x8, #0x20]       | this.graphs[0x1][0] = val_6;             //  dest_result_addr=0
            this.graphs[1] = val_9;
            // 0x028C0684: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C0688: CBNZ x21, #0x28c0690       | if (this.graphs != null) goto label_17; 
            if(this.graphs != null)
            {
                goto label_17;
            }
            // 0x028C068C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_17:
            // 0x028C0690: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C0694: CMP w20, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C0698: B.LO #0x28c06a8            | if (val_18 < this.graphs.Length) goto label_18;
            if(val_18 < this.graphs.Length)
            {
                goto label_18;
            }
            // 0x028C069C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x028C06A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C06A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_18:
            // 0x028C06A8: ADD x8, x21, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C06AC: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_18 = this.graphs[1];
            // 0x028C06B0: CBNZ x21, #0x28c06b8       | if (this.graphs[0x1][0] != null) goto label_19;
            if(val_18 != null)
            {
                goto label_19;
            }
            // 0x028C06B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_19:
            // 0x028C06B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C06BC: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C06C0: BL #0x155d0d0              | X0 = this.graphs[0x1][0].get_guid();    
            Pathfinding.Util.Guid val_10 = val_18.guid;
            // 0x028C06C4: STP x0, x1, [sp, #0x18]    | stack[1152921513277400840] = val_10._a;  stack[1152921513277400848] = val_10._b;  //  dest_result_addr=1152921513277400840 |  dest_result_addr=1152921513277400848
            // 0x028C06C8: ADD x0, sp, #0x18          | X0 = (1152921513277400816 + 24) = 1152921513277400840 (0x1000000204CE2708);
            // 0x028C06CC: BL #0x28beb60              | X0 = label_Pathfinding_Serialization_AstarSerializer_SerializeUserConnections_GL028BEB60();
            // 0x028C06D0: LDR x22, [x19, #0x38]      | X22 = this.meta; //P2                   
            // 0x028C06D4: MOV x21, x0                | X21 = 1152921513277400840 (0x1000000204CE2708);//ML01
            // 0x028C06D8: CBNZ x22, #0x28c06e0       | if (this.meta != null) goto label_20;   
            if(this.meta != null)
            {
                goto label_20;
            }
            // 0x028C06DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000204CE2708, ????);
            label_20:
            // 0x028C06E0: LDR x22, [x22, #0x20]      | X22 = this.meta.guids; //P2             
            // 0x028C06E4: CBNZ x22, #0x28c06ec       | if (this.meta.guids != null) goto label_21;
            if(this.meta.guids != null)
            {
                goto label_21;
            }
            // 0x028C06E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000204CE2708, ????);
            label_21:
            // 0x028C06EC: LDR w8, [x22, #0x18]       | W8 = this.meta.guids.Length; //P2       
            // 0x028C06F0: CMP w20, w8                | STATE = COMPARE(0x1, this.meta.guids.Length)
            // 0x028C06F4: B.LO #0x28c0704            | if (val_18 < this.meta.guids.Length) goto label_22;
            if(val_18 < this.meta.guids.Length)
            {
                goto label_22;
            }
            // 0x028C06F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000204CE2708, ????);
            // 0x028C06FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0700: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000204CE2708, ????);
            label_22:
            // 0x028C0704: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028C0708: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028C070C: ADD w27, w27, #1           | W27 = (0 + 1);                          
            val_19 = val_19 + 1;
            // 0x028C0710: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x028C0714: ADD x8, x22, x23, lsl #3   | X8 = this.meta.guids[0x1]; //PARR1      
            // 0x028C0718: LDR x22, [x8, #0x20]       | X22 = this.meta.guids[0x1][0]           
            string val_20 = this.meta.guids[1];
            // 0x028C071C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x028C0720: TBZ w8, #0, #0x28c0730     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_24;
            // 0x028C0724: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C0728: CBNZ w8, #0x28c0730        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
            // 0x028C072C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_24:
            // 0x028C0730: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C0734: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C0738: MOV x1, x21                | X1 = 1152921513277400840 (0x1000000204CE2708);//ML01
            // 0x028C073C: MOV x2, x22                | X2 = this.meta.guids[0x1][0];//m1       
            // 0x028C0740: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_10._a);
            bool val_11 = System.String.op_Inequality(a:  0, b:  val_10._a);
            // 0x028C0744: TBZ w0, #0, #0x28c04f0     | if (val_11 == false) goto label_25;     
            if(val_11 == false)
            {
                goto label_25;
            }
            // 0x028C0748: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C074C: CBNZ x21, #0x28c0754       | if (this.graphs != null) goto label_26; 
            if(this.graphs != null)
            {
                goto label_26;
            }
            // 0x028C0750: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_26:
            // 0x028C0754: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C0758: CMP w20, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C075C: B.LO #0x28c076c            | if (val_18 < this.graphs.Length) goto label_27;
            if(val_18 < this.graphs.Length)
            {
                goto label_27;
            }
            // 0x028C0760: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x028C0764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0768: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_27:
            // 0x028C076C: ADD x8, x21, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C0770: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_21 = this.graphs[1];
            // 0x028C0774: CBNZ x21, #0x28c077c       | if (this.graphs[0x1][0] != null) goto label_28;
            if(val_21 != null)
            {
                goto label_28;
            }
            // 0x028C0778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_28:
            // 0x028C077C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0780: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C0784: BL #0x155d0d0              | X0 = this.graphs[0x1][0].get_guid();    
            Pathfinding.Util.Guid val_12 = val_21.guid;
            // 0x028C0788: STP x0, x1, [sp, #8]       | stack[1152921513277400824] = val_12._a;  stack[1152921513277400832] = val_12._b;  //  dest_result_addr=1152921513277400824 |  dest_result_addr=1152921513277400832
            // 0x028C078C: ADD x0, sp, #8             | X0 = (1152921513277400816 + 8) = 1152921513277400824 (0x1000000204CE26F8);
            // 0x028C0790: BL #0x28beb60              | X0 = label_Pathfinding_Serialization_AstarSerializer_SerializeUserConnections_GL028BEB60();
            // 0x028C0794: LDR x21, [x19, #0x38]      | X21 = this.meta; //P2                   
            // 0x028C0798: MOV x19, x0                | X19 = 1152921513277400824 (0x1000000204CE26F8);//ML01
            // 0x028C079C: CBNZ x21, #0x28c07a4       | if (this.meta != null) goto label_29;   
            if(this.meta != null)
            {
                goto label_29;
            }
            // 0x028C07A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000204CE26F8, ????);
            label_29:
            // 0x028C07A4: LDR x21, [x21, #0x20]      | X21 = this.meta.guids; //P2             
            // 0x028C07A8: CBNZ x21, #0x28c07b0       | if (this.meta.guids != null) goto label_30;
            if(this.meta.guids != null)
            {
                goto label_30;
            }
            // 0x028C07AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000204CE26F8, ????);
            label_30:
            // 0x028C07B0: LDR w8, [x21, #0x18]       | W8 = this.meta.guids.Length; //P2       
            // 0x028C07B4: CMP w20, w8                | STATE = COMPARE(0x1, this.meta.guids.Length)
            // 0x028C07B8: B.LO #0x28c07c8            | if (val_18 < this.meta.guids.Length) goto label_31;
            if(val_18 < this.meta.guids.Length)
            {
                goto label_31;
            }
            // 0x028C07BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000204CE26F8, ????);
            // 0x028C07C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C07C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000204CE26F8, ????);
            label_31:
            // 0x028C07C8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028C07CC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028C07D0: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x028C07D4: ADD x8, x21, x23, lsl #3   | X8 = this.meta.guids[0x1]; //PARR1      
            // 0x028C07D8: LDR x20, [x8, #0x20]       | X20 = this.meta.guids[0x1][0]           
            string val_22 = this.meta.guids[1];
            // 0x028C07DC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x028C07E0: TBZ w8, #0, #0x28c07f0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x028C07E4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C07E8: CBNZ w8, #0x28c07f0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x028C07EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_33:
            // 0x028C07F0: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x028C07F4: ADRP x9, #0x35bd000        | X9 = 56348672 (0x35BD000);              
            // 0x028C07F8: LDR x8, [x8, #0x478]       | X8 = (string**)(1152921513277252048)("Guid in graph file not equal to guid defined in meta file. Have you edited the data manually?\n");
            // 0x028C07FC: LDR x9, [x9, #0x368]       | X9 = (string**)(1152921513277252320)(" != ");
            // 0x028C0800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C0804: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028C0808: LDR x1, [x8]               | X1 = "Guid in graph file not equal to guid defined in meta file. Have you edited the data manually?\n";
            // 0x028C080C: LDR x3, [x9]               | X3 = " != ";                            
            // 0x028C0810: MOV x2, x19                | X2 = 1152921513277400824 (0x1000000204CE26F8);//ML01
            // 0x028C0814: MOV x4, x20                | X4 = this.meta.guids[0x1][0];//m1       
            // 0x028C0818: BL #0x18b0400              | X0 = System.String.Concat(str0:  0, str1:  "Guid in graph file not equal to guid defined in meta file. Have you edited the data manually?\n", str2:  val_12._a, str3:  " != ");
            string val_13 = System.String.Concat(str0:  0, str1:  "Guid in graph file not equal to guid defined in meta file. Have you edited the data manually?\n", str2:  val_12._a, str3:  " != ");
            // 0x028C081C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028C0820: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028C0824: MOV x19, x0                | X19 = val_13;//m1                       
            // 0x028C0828: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028C082C: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_14 = null;
            // 0x028C0830: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028C0834: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0838: MOV x1, x19                | X1 = val_13;//m1                        
            // 0x028C083C: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_19 = val_14;
            // 0x028C0840: BL #0x1c32b48              | .ctor(message:  val_13);                
            val_14 = new System.Exception(message:  val_13);
            // 0x028C0844: B #0x28c0b90               |  goto label_34;                         
            goto label_34;
            label_4:
            // 0x028C0848: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028C084C: LDR x8, [x8, #0xd20]       | X8 = 1152921507421177472;               
            // 0x028C0850: LDR x20, [x8]              | X20 = typeof(Pathfinding.NavGraph[]);   
            // 0x028C0854: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028C0858: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028C085C: MOV w1, w27                | W1 = 0 (0x0);//ML01                     
            // 0x028C0860: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028C0864: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028C0868: MOV x20, x0                | X20 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028C086C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_20 = 0;
            // 0x028C0870: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            var val_25 = 0;
            // 0x028C0874: B #0x28c087c               |  goto label_35;                         
            goto label_35;
            label_47:
            // 0x028C0878: ADD w22, w22, #1           | W22 = (val_20 + 1) = val_20 (0x00000001);
            val_20 = 1;
            label_35:
            // 0x028C087C: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C0880: CBNZ x21, #0x28c0888       | if (this.graphs != null) goto label_36; 
            if(this.graphs != null)
            {
                goto label_36;
            }
            // 0x028C0884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_36:
            // 0x028C0888: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C088C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C0890: B.GE #0x28c094c            | if (val_20 >= this.graphs.Length) goto label_37;
            if(val_20 >= this.graphs.Length)
            {
                goto label_37;
            }
            // 0x028C0894: LDR x24, [x19, #0x48]      | X24 = this.graphs; //P2                 
            // 0x028C0898: CBNZ x24, #0x28c08a0       | if (this.graphs != null) goto label_38; 
            if(this.graphs != null)
            {
                goto label_38;
            }
            // 0x028C089C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_38:
            // 0x028C08A0: LDR w8, [x24, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C08A4: SXTW x21, w22              | X21 = 1 (0x00000001);                   
            // 0x028C08A8: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C08AC: B.LO #0x28c08bc            | if (val_20 < this.graphs.Length) goto label_39;
            if(val_20 < this.graphs.Length)
            {
                goto label_39;
            }
            // 0x028C08B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028C08B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C08B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_39:
            // 0x028C08BC: ADD x8, x24, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C08C0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_23 = this.graphs[1];
            // 0x028C08C4: CBZ x8, #0x28c0878         | if (this.graphs[0x1][0] == null) goto label_47;
            if(val_23 == null)
            {
                goto label_47;
            }
            // 0x028C08C8: LDR x24, [x19, #0x48]      | X24 = this.graphs; //P2                 
            // 0x028C08CC: CBNZ x24, #0x28c08d4       | if (this.graphs != null) goto label_41; 
            if(this.graphs != null)
            {
                goto label_41;
            }
            // 0x028C08D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_41:
            // 0x028C08D4: LDR w8, [x24, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C08D8: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C08DC: B.LO #0x28c08ec            | if (val_20 < this.graphs.Length) goto label_42;
            if(val_20 < this.graphs.Length)
            {
                goto label_42;
            }
            // 0x028C08E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x028C08E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C08E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_42:
            // 0x028C08EC: ADD x8, x24, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C08F0: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_24 = this.graphs[1];
            // 0x028C08F4: CBNZ x20, #0x28c08fc       | if ( != null) goto label_43;            
            if(null != null)
            {
                goto label_43;
            }
            // 0x028C08F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.NavGraph[]), ????);
            label_43:
            // 0x028C08FC: CBZ x21, #0x28c0920        | if (this.graphs[0x1][0] == null) goto label_45;
            if(val_24 == null)
            {
                goto label_45;
            }
            // 0x028C0900: LDR x8, [x20]              | X8 = ;                                  
            // 0x028C0904: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C0908: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C090C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.graphs[0x1][0], ????);
            // 0x028C0910: CBNZ x0, #0x28c0920        | if (this.graphs[0x1][0] != null) goto label_45;
            if(val_24 != null)
            {
                goto label_45;
            }
            // 0x028C0914: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.graphs[0x1][0], ????);
            // 0x028C0918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C091C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.graphs[0x1][0], ????);
            label_45:
            // 0x028C0920: LDR w8, [x20, #0x18]       | W8 = Pathfinding.NavGraph[].__il2cppRuntimeField_namespaze;
            // 0x028C0924: SXTW x24, w23              | X24 = 0 (0x00000000);                   
            // 0x028C0928: CMP w23, w8                | STATE = COMPARE(0x0, Pathfinding.NavGraph[].__il2cppRuntimeField_namespaze)
            // 0x028C092C: B.LO #0x28c093c            | if (0 < Pathfinding.NavGraph[].__il2cppRuntimeField_namespaze) goto label_46;
            // 0x028C0930: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.graphs[0x1][0], ????);
            // 0x028C0934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0938: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.graphs[0x1][0], ????);
            label_46:
            // 0x028C093C: ADD x8, x20, x24, lsl #3   | X8 = (null + 0) = 1152921507421177472 (0x10000000A7BF4680);
            // 0x028C0940: ADD w23, w23, #1           | W23 = (0 + 1);                          
            val_25 = val_25 + 1;
            // 0x028C0944: STR x21, [x8, #0x20]       | typeof(Pathfinding.NavGraph[]).__il2cppRuntimeField_20 = this.graphs[0x1][0];  //  dest_result_addr=1152921507421177504
            typeof(Pathfinding.NavGraph[]).__il2cppRuntimeField_20 = val_24;
            // 0x028C0948: B #0x28c0878               |  goto label_47;                         
            goto label_47;
            label_37:
            // 0x028C094C: STR x20, [x19, #0x48]      | this.graphs = typeof(Pathfinding.NavGraph[]);  //  dest_result_addr=1152921513277413032
            this.graphs = null;
            // 0x028C0950: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x028C0954: SUB sp, x29, #0x50         | SP = (1152921513277400944 - 80) = 1152921513277400864 (0x1000000204CE2720);
            // 0x028C0958: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028C095C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028C0960: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028C0964: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028C0968: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028C096C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028C0970: RET                        |  return (Pathfinding.NavGraph[])typeof(Pathfinding.NavGraph[]);
            return (Pathfinding.NavGraph[])null;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph[], size=8, nGRN=0 }
            label_10:
            // 0x028C0974: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028C0978: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x028C097C: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
            // 0x028C0980: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028C0984: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x028C0988: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x028C098C: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028C0990: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x028C0994: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028C0998: CBNZ x19, #0x28c09a0       | if ( != null) goto label_48;            
            if(null != null)
            {
                goto label_48;
            }
            // 0x028C099C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_48:
            // 0x028C09A0: ADRP x21, #0x365a000       | X21 = 56991744 (0x365A000);             
            // 0x028C09A4: LDR x21, [x21, #0x200]     | X21 = (string**)(1152921513277375280)("Could not find data for graph ");
            // 0x028C09A8: LDR x0, [x21]              | X0 = "Could not find data for graph ";  
            // 0x028C09AC: CBZ x0, #0x28c09cc         | if ("Could not find data for graph " == null) goto label_50;
            // 0x028C09B0: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C09B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C09B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Could not find data for graph ", ????);
            // 0x028C09BC: CBNZ x0, #0x28c09cc        | if ("Could not find data for graph " != null) goto label_50;
            if("Could not find data for graph " != null)
            {
                goto label_50;
            }
            // 0x028C09C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Could not find data for graph ", ????);
            // 0x028C09C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C09C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Could not find data for graph ", ????);
            label_50:
            // 0x028C09CC: LDR x21, [x21]             | X21 = "Could not find data for graph "; 
            // 0x028C09D0: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C09D4: CBNZ w8, #0x28c09e4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_51;
            // 0x028C09D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Could not find data for graph ", ????);
            // 0x028C09DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C09E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Could not find data for graph ", ????);
            label_51:
            // 0x028C09E4: STR x21, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "Could not find data for graph ";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "Could not find data for graph ";
            // 0x028C09E8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028C09EC: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028C09F0: ADD x1, sp, #4             | X1 = (1152921513277400816 + 4) = 1152921513277400820 (0x1000000204CE26F4);
            // 0x028C09F4: STR w20, [sp, #4]          | stack[1152921513277400820] = 0x1;        //  dest_result_addr=1152921513277400820
            // 0x028C09F8: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028C09FC: BL #0x27bc028              | X0 = 1152921513277825888 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C0A00: MOV x21, x0                | X21 = 1152921513277825888 (0x1000000204D4A360);//ML01
            // 0x028C0A04: CBZ x21, #0x28c0a28        | if (1 == 0) goto label_53;              
            if(val_18 == 0)
            {
                goto label_53;
            }
            // 0x028C0A08: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C0A0C: MOV x0, x21                | X0 = 1152921513277825888 (0x1000000204D4A360);//ML01
            // 0x028C0A10: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C0A14: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 1, ????);          
            // 0x028C0A18: CBNZ x0, #0x28c0a28        | if (1 != 0) goto label_53;              
            if(val_18 != 0)
            {
                goto label_53;
            }
            // 0x028C0A1C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 1, ????);          
            // 0x028C0A20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0A24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 1, ????);          
            label_53:
            // 0x028C0A28: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C0A2C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028C0A30: B.HI #0x28c0a40            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_54;
            // 0x028C0A34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 1, ????);          
            // 0x028C0A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0A3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 1, ????);          
            label_54:
            // 0x028C0A40: STR x21, [x19, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = 1; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_18;
            typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
            // 0x028C0A44: ADRP x21, #0x3615000       | X21 = 56709120 (0x3615000);             
            // 0x028C0A48: LDR x21, [x21, #0xe10]     | X21 = (string**)(1152921513277379504)(" in zip. Entry \'graph+");
            // 0x028C0A4C: LDR x0, [x21]              | X0 = " in zip. Entry \'graph+";         
            // 0x028C0A50: CBZ x0, #0x28c0a70         | if (" in zip. Entry \'graph+" == null) goto label_56;
            // 0x028C0A54: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C0A58: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C0A5C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " in zip. Entry \'graph+", ????);
            // 0x028C0A60: CBNZ x0, #0x28c0a70        | if (" in zip. Entry \'graph+" != null) goto label_56;
            if((" in zip. Entry \'graph+") != null)
            {
                goto label_56;
            }
            // 0x028C0A64: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " in zip. Entry \'graph+", ????);
            // 0x028C0A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0A6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " in zip. Entry \'graph+", ????);
            label_56:
            // 0x028C0A70: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C0A74: LDR x21, [x21]             | X21 = " in zip. Entry \'graph+";        
            // 0x028C0A78: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x028C0A7C: B.HI #0x28c0a8c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_57;
            // 0x028C0A80: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " in zip. Entry \'graph+", ????);
            // 0x028C0A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0A88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " in zip. Entry \'graph+", ????);
            label_57:
            // 0x028C0A8C: STR x21, [x19, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = " in zip. Entry \'graph+";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = " in zip. Entry \'graph+";
            // 0x028C0A90: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028C0A94: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028C0A98: MOV x1, sp                 | X1 = 1152921513277400816 (0x1000000204CE26F0);//ML01
            // 0x028C0A9C: STR w20, [sp]              | stack[1152921513277400816] = 0x1;        //  dest_result_addr=1152921513277400816
            // 0x028C0AA0: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028C0AA4: BL #0x27bc028              | X0 = 1152921513277829984 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C0AA8: MOV x20, x0                | X20 = 1152921513277829984 (0x1000000204D4B360);//ML01
            // 0x028C0AAC: CBZ x20, #0x28c0ad0        | if (1 == 0) goto label_59;              
            if(val_18 == 0)
            {
                goto label_59;
            }
            // 0x028C0AB0: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C0AB4: MOV x0, x20                | X0 = 1152921513277829984 (0x1000000204D4B360);//ML01
            // 0x028C0AB8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C0ABC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 1, ????);          
            // 0x028C0AC0: CBNZ x0, #0x28c0ad0        | if (1 != 0) goto label_59;              
            if(val_18 != 0)
            {
                goto label_59;
            }
            // 0x028C0AC4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 1, ????);          
            // 0x028C0AC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0ACC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 1, ????);          
            label_59:
            // 0x028C0AD0: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C0AD4: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x028C0AD8: B.HI #0x28c0ae8            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_60;
            // 0x028C0ADC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 1, ????);          
            // 0x028C0AE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0AE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 1, ????);          
            label_60:
            // 0x028C0AE8: STR x20, [x19, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = 1; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
            typeof(System.Object[]).__il2cppRuntimeField_38 = val_18;
            typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
            // 0x028C0AEC: ADRP x20, #0x361d000       | X20 = 56741888 (0x361D000);             
            // 0x028C0AF0: LDR x20, [x20, #0x98]      | X20 = (string**)(1152921513277383728)(".json\' does not exist");
            // 0x028C0AF4: LDR x0, [x20]              | X0 = ".json\' does not exist";          
            // 0x028C0AF8: CBZ x0, #0x28c0b18         | if (".json\' does not exist" == null) goto label_62;
            // 0x028C0AFC: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C0B00: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028C0B04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ".json\' does not exist", ????);
            // 0x028C0B08: CBNZ x0, #0x28c0b18        | if (".json\' does not exist" != null) goto label_62;
            if(".json\' does not exist" != null)
            {
                goto label_62;
            }
            // 0x028C0B0C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ".json\' does not exist", ????);
            // 0x028C0B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0B14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ".json\' does not exist", ????);
            label_62:
            // 0x028C0B18: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x028C0B1C: LDR x20, [x20]             | X20 = ".json\' does not exist";         
            // 0x028C0B20: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x028C0B24: B.HI #0x28c0b34            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_63;
            // 0x028C0B28: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ".json\' does not exist", ????);
            // 0x028C0B2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0B30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ".json\' does not exist", ????);
            label_63:
            // 0x028C0B34: STR x20, [x19, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = ".json\' does not exist";  //  dest_result_addr=1152921504954501328
            typeof(System.Object[]).__il2cppRuntimeField_40 = ".json\' does not exist";
            // 0x028C0B38: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028C0B3C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028C0B40: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x028C0B44: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x028C0B48: TBZ w8, #0, #0x28c0b58     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
            // 0x028C0B4C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C0B50: CBNZ w8, #0x28c0b58        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
            // 0x028C0B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_65:
            // 0x028C0B58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C0B5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0B60: MOV x1, x19                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028C0B64: BL #0x18b07f0              | X0 = System.String.Concat(args:  0);    
            string val_15 = System.String.Concat(args:  0);
            // 0x028C0B68: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x028C0B6C: LDR x8, [x8, #0x448]       | X8 = 1152921504621330432;               
            // 0x028C0B70: MOV x19, x0                | X19 = val_15;//m1                       
            // 0x028C0B74: LDR x8, [x8]               | X8 = typeof(System.IO.FileNotFoundException);
            // 0x028C0B78: MOV x0, x8                 | X0 = 1152921504621330432 (0x1000000000DD0000);//ML01
            System.IO.FileNotFoundException val_16 = null;
            // 0x028C0B7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileNotFoundException), ????);
            // 0x028C0B80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0B84: MOV x1, x19                | X1 = val_15;//m1                        
            // 0x028C0B88: MOV x20, x0                | X20 = 1152921504621330432 (0x1000000000DD0000);//ML01
            val_19 = val_16;
            // 0x028C0B8C: BL #0x1e72f3c              | .ctor(message:  val_15);                
            val_16 = new System.IO.FileNotFoundException(message:  val_15);
            label_34:
            // 0x028C0B90: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x028C0B94: LDR x8, [x8, #0x8d0]       | X8 = 1152921513277387936;               
            // 0x028C0B98: MOV x0, x20                | X0 = 1152921504621330432 (0x1000000000DD0000);//ML01
            // 0x028C0B9C: LDR x1, [x8]               | X1 = public Pathfinding.NavGraph[] Pathfinding.Serialization.AstarSerializer::DeserializeGraphs();
            // 0x028C0BA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.FileNotFoundException), ????);
            // 0x028C0BA4: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_17 = MoveNext();
        
        }
        //
        // Offset in libil2cpp.so: 0x028C0E8C (42733196), len: 408  VirtAddr: 0x028C0E8C RVA: 0x028C0E8C token: 100682636 methodIndex: 51173 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.UserConnection[] DeserializeUserConnections()
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028C0E8C: STP x22, x21, [sp, #-0x30]! | stack[1152921513277930704] = ???;  stack[1152921513277930712] = ???;  //  dest_result_addr=1152921513277930704 |  dest_result_addr=1152921513277930712
            // 0x028C0E90: STP x20, x19, [sp, #0x10]  | stack[1152921513277930720] = ???;  stack[1152921513277930728] = ???;  //  dest_result_addr=1152921513277930720 |  dest_result_addr=1152921513277930728
            // 0x028C0E94: STP x29, x30, [sp, #0x20]  | stack[1152921513277930736] = ???;  stack[1152921513277930744] = ???;  //  dest_result_addr=1152921513277930736 |  dest_result_addr=1152921513277930744
            // 0x028C0E98: ADD x29, sp, #0x20         | X29 = (1152921513277930704 + 32) = 1152921513277930736 (0x1000000204D63CF0);
            // 0x028C0E9C: SUB sp, sp, #0x10          | SP = (1152921513277930704 - 16) = 1152921513277930688 (0x1000000204D63CC0);
            // 0x028C0EA0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028C0EA4: LDRB w8, [x20, #0x948]     | W8 = (bool)static_value_037B8948;       
            // 0x028C0EA8: MOV x19, x0                | X19 = 1152921513277942752 (0x1000000204D66BE0);//ML01
            // 0x028C0EAC: TBNZ w8, #0, #0x28c0ec8    | if (static_value_037B8948 == true) goto label_0;
            // 0x028C0EB0: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x028C0EB4: LDR x8, [x8, #0xca8]       | X8 = 0x2B8EDD4;                         
            // 0x028C0EB8: LDR w0, [x8]               | W0 = 0x1235;                            
            // 0x028C0EBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1235, ????);     
            // 0x028C0EC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C0EC4: STRB w8, [x20, #0x948]     | static_value_037B8948 = true;            //  dest_result_addr=58427720
            label_0:
            // 0x028C0EC8: LDR x20, [x19, #0x28]      | X20 = this.zip; //P2                    
            // 0x028C0ECC: CBNZ x20, #0x28c0ed4       | if (this.zip != null) goto label_1;     
            if(this.zip != null)
            {
                goto label_1;
            }
            // 0x028C0ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1235, ????);     
            label_1:
            // 0x028C0ED4: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x028C0ED8: LDR x8, [x8, #0xa98]       | X8 = (string**)(1152921513272908016)("connections.json");
            // 0x028C0EDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0EE0: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028C0EE4: LDR x1, [x8]               | X1 = "connections.json";                
            // 0x028C0EE8: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  "connections.json");
            Pathfinding.Ionic.Zip.ZipEntry val_1 = this.zip.Item["connections.json"];
            // 0x028C0EEC: CBZ x0, #0x28c0fdc         | if (val_1 == null) goto label_2;        
            if(val_1 == null)
            {
                goto label_2;
            }
            // 0x028C0EF0: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x028C0EF4: BL #0x28c0d8c              | X0 = val_1.GetString(entry:  val_1);    
            string val_2 = val_1.GetString(entry:  val_1);
            // 0x028C0EF8: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x028C0EFC: LDR x20, [x19, #0x20]      | X20 = this.readerSettings; //P2         
            // 0x028C0F00: LDR x8, [x8, #0x828]       | X8 = 1152921504755036160;               
            // 0x028C0F04: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028C0F08: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReader);
            // 0x028C0F0C: MOV x0, x8                 | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            Pathfinding.Serialization.JsonFx.JsonReader val_3 = null;
            // 0x028C0F10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonReader), ????);
            // 0x028C0F14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C0F18: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028C0F1C: MOV x2, x20                | X2 = this.readerSettings;//m1           
            // 0x028C0F20: MOV x19, x0                | X19 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C0F24: BL #0x26d5180              | .ctor(input:  val_2, settings:  this.readerSettings);
            val_3 = new Pathfinding.Serialization.JsonFx.JsonReader(input:  val_2, settings:  this.readerSettings);
            // 0x028C0F28: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028C0F2C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028C0F30: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x028C0F34: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x028C0F38: LDR x8, [x8, #0x1e0]       | X8 = 1152921507462440560;               
            // 0x028C0F3C: LDR x20, [x8]              | X20 = typeof(Pathfinding.UserConnection[]);
            // 0x028C0F40: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028C0F44: TBZ w8, #0, #0x28c0f54     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x028C0F48: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028C0F4C: CBNZ w8, #0x28c0f54        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x028C0F50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x028C0F54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C0F58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0F5C: MOV x1, x20                | X1 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028C0F60: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028C0F64: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x028C0F68: CBNZ x19, #0x28c0f70       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x028C0F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_5:
            // 0x028C0F70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0F74: MOV x0, x19                | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C0F78: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x028C0F7C: BL #0x26d5400              | X0 = Deserialize(type:  val_4);         
            object val_5 = Deserialize(type:  val_4);
            // 0x028C0F80: MOV x19, x0                | X19 = val_5;//m1                        
            val_7 = val_5;
            // 0x028C0F84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x028C0F88: CBZ x19, #0x28c0ffc        | if (val_5 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x028C0F8C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028C0F90: LDR x8, [x8, #0x870]       | X8 = 1152921507462440560;               
            // 0x028C0F94: MOV x0, x19                | X0 = val_5;//m1                         
            val_8 = val_7;
            // 0x028C0F98: LDR x20, [x8]              | X20 = typeof(Pathfinding.UserConnection[]);
            // 0x028C0F9C: MOV x1, x20                | X1 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028C0FA0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x028C0FA4: CBNZ x0, #0x28c0ffc        | if (val_5 != null) goto label_8;        
            if(val_8 != null)
            {
                goto label_8;
            }
            // 0x028C0FA8: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x028C0FAC: MOV x1, x20                | X1 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028C0FB0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028C0FB4: ADD x8, sp, #8             | X8 = (1152921513277930688 + 8) = 1152921513277930696 (0x1000000204D63CC8);
            // 0x028C0FB8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028C0FBC: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921513277918752]
            // 0x028C0FC0: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x028C0FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x028C0FCC: ADD x0, sp, #8             | X0 = (1152921513277930688 + 8) = 1152921513277930696 (0x1000000204D63CC8);
            // 0x028C0FD0: BL #0x299a140              | 
            // 0x028C0FD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x028C0FD8: B #0x28c0ffc               |  goto label_8;                          
            goto label_8;
            label_2:
            // 0x028C0FDC: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x028C0FE0: LDR x8, [x8, #0x870]       | X8 = 1152921507462440560;               
            // 0x028C0FE4: LDR x19, [x8]              | X19 = typeof(Pathfinding.UserConnection[]);
            val_7 = null;
            // 0x028C0FE8: MOV x0, x19                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x028C0FEC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x028C0FF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0FF4: MOV x0, x19                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            val_8 = val_7;
            // 0x028C0FF8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.UserConnection[]), ????);
            label_8:
            // 0x028C0FFC: SUB sp, x29, #0x20         | SP = (1152921513277930736 - 32) = 1152921513277930704 (0x1000000204D63CD0);
            // 0x028C1000: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C1004: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C1008: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C100C: RET                        |  return (Pathfinding.UserConnection[])typeof(Pathfinding.UserConnection[]);
            return (Pathfinding.UserConnection[])val_8;
            //  |  // // {name=val_0, type=Pathfinding.UserConnection[], size=8, nGRN=0 }
            // 0x028C1010: MOV x19, x0                | 
            // 0x028C1014: ADD x0, sp, #8             | 
            // 0x028C1018: BL #0x299a140              | 
            // 0x028C101C: MOV x0, x19                | 
            // 0x028C1020: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028C1024 (42733604), len: 932  VirtAddr: 0x028C1024 RVA: 0x028C1024 token: 100682637 methodIndex: 51174 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeNodes()
        {
            //
            // Disasemble & Code
            //  | 
            object val_11;
            //  | 
            object val_12;
            //  | 
            object val_13;
            // 0x028C1024: STP x28, x27, [sp, #-0x60]! | stack[1152921513278345760] = ???;  stack[1152921513278345768] = ???;  //  dest_result_addr=1152921513278345760 |  dest_result_addr=1152921513278345768
            // 0x028C1028: STP x26, x25, [sp, #0x10]  | stack[1152921513278345776] = ???;  stack[1152921513278345784] = ???;  //  dest_result_addr=1152921513278345776 |  dest_result_addr=1152921513278345784
            // 0x028C102C: STP x24, x23, [sp, #0x20]  | stack[1152921513278345792] = ???;  stack[1152921513278345800] = ???;  //  dest_result_addr=1152921513278345792 |  dest_result_addr=1152921513278345800
            // 0x028C1030: STP x22, x21, [sp, #0x30]  | stack[1152921513278345808] = ???;  stack[1152921513278345816] = ???;  //  dest_result_addr=1152921513278345808 |  dest_result_addr=1152921513278345816
            // 0x028C1034: STP x20, x19, [sp, #0x40]  | stack[1152921513278345824] = ???;  stack[1152921513278345832] = ???;  //  dest_result_addr=1152921513278345824 |  dest_result_addr=1152921513278345832
            // 0x028C1038: STP x29, x30, [sp, #0x50]  | stack[1152921513278345840] = ???;  stack[1152921513278345848] = ???;  //  dest_result_addr=1152921513278345840 |  dest_result_addr=1152921513278345848
            // 0x028C103C: ADD x29, sp, #0x50         | X29 = (1152921513278345760 + 80) = 1152921513278345840 (0x1000000204DC9270);
            // 0x028C1040: SUB sp, sp, #0x10          | SP = (1152921513278345760 - 16) = 1152921513278345744 (0x1000000204DC9210);
            // 0x028C1044: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028C1048: LDRB w8, [x20, #0x949]     | W8 = (bool)static_value_037B8949;       
            // 0x028C104C: MOV x19, x0                | X19 = 1152921513278357856 (0x1000000204DCC160);//ML01
            // 0x028C1050: TBNZ w8, #0, #0x28c106c    | if (static_value_037B8949 == true) goto label_0;
            // 0x028C1054: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x028C1058: LDR x8, [x8, #0x258]       | X8 = 0x2B8EDD0;                         
            // 0x028C105C: LDR w0, [x8]               | W0 = 0x1234;                            
            // 0x028C1060: BL #0x2782188              | X0 = sub_2782188( ?? 0x1234, ????);     
            // 0x028C1064: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C1068: STRB w8, [x20, #0x949]     | static_value_037B8949 = true;            //  dest_result_addr=58427721
            label_0:
            // 0x028C106C: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
            // 0x028C1070: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
            // 0x028C1074: ADRP x24, #0x3684000       | X24 = 57163776 (0x3684000);             
            // 0x028C1078: ADRP x27, #0x3665000       | X27 = 57036800 (0x3665000);             
            // 0x028C107C: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
            // 0x028C1080: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
            // 0x028C1084: LDR x24, [x24, #0x390]     | X24 = (string**)(1152921513124056064)("graph");
            // 0x028C1088: LDR x27, [x27, #0xdb0]     | X27 = (string**)(1152921513274423776)("_nodes.binary");
            // 0x028C108C: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x028C1090: B #0x28c1098               |  goto label_1;                          
            goto label_1;
            label_10:
            // 0x028C1094: ADD w25, w25, #1           | W25 = (val_11 + 1) = val_11 (0x00000001);
            val_11 = 1;
            label_1:
            // 0x028C1098: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C109C: CBNZ x20, #0x28c10a4       | if (this.graphs != null) goto label_2;  
            if(this.graphs != null)
            {
                goto label_2;
            }
            // 0x028C10A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1234, ????);     
            label_2:
            // 0x028C10A4: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C10A8: CMP w25, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C10AC: B.GE #0x28c1150            | if (val_11 >= this.graphs.Length) goto label_3;
            if(val_11 >= this.graphs.Length)
            {
                goto label_3;
            }
            // 0x028C10B0: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C10B4: CBNZ x20, #0x28c10bc       | if (this.graphs != null) goto label_4;  
            if(this.graphs != null)
            {
                goto label_4;
            }
            // 0x028C10B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1234, ????);     
            label_4:
            // 0x028C10BC: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C10C0: SXTW x21, w25              | X21 = 1 (0x00000001);                   
            // 0x028C10C4: CMP w25, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C10C8: B.LO #0x28c10d8            | if (val_11 < this.graphs.Length) goto label_5;
            if(val_11 < this.graphs.Length)
            {
                goto label_5;
            }
            // 0x028C10CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1234, ????);     
            // 0x028C10D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C10D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1234, ????);     
            label_5:
            // 0x028C10D8: ADD x8, x20, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C10DC: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_11 = this.graphs[1];
            // 0x028C10E0: CBZ x8, #0x28c1094         | if (this.graphs[0x1][0] == null) goto label_10;
            if(val_11 == null)
            {
                goto label_10;
            }
            // 0x028C10E4: LDR x0, [x22]              | X0 = typeof(System.Int32);              
            // 0x028C10E8: LDR x20, [x19, #0x28]      | X20 = this.zip; //P2                    
            // 0x028C10EC: ADD x1, sp, #0xc           | X1 = (1152921513278345744 + 12) = 1152921513278345756 (0x1000000204DC921C);
            // 0x028C10F0: STR w25, [sp, #0xc]        | stack[1152921513278345756] = 0x1;        //  dest_result_addr=1152921513278345756
            // 0x028C10F4: BL #0x27bc028              | X0 = 1152921513278471776 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C10F8: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x028C10FC: MOV x21, x0                | X21 = 1152921513278471776 (0x1000000204DE7E60);//ML01
            // 0x028C1100: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C1104: TBZ w9, #0, #0x28c1118     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x028C1108: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C110C: CBNZ w9, #0x28c1118        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x028C1110: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C1114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x028C1118: LDR x1, [x24]              | X1 = "graph";                           
            // 0x028C111C: LDR x3, [x27]              | X3 = "_nodes.binary";                   
            // 0x028C1120: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C1124: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C1128: MOV x2, x21                | X2 = 1152921513278471776 (0x1000000204DE7E60);//ML01
            // 0x028C112C: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_11);
            string val_1 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_11);
            // 0x028C1130: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028C1134: CBNZ x20, #0x28c113c       | if (this.zip != null) goto label_9;     
            if(this.zip != null)
            {
                goto label_9;
            }
            // 0x028C1138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_9:
            // 0x028C113C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1140: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028C1144: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028C1148: BL #0x19875fc              | X0 = this.zip.ContainsEntry(name:  val_1);
            bool val_2 = this.zip.ContainsEntry(name:  val_1);
            // 0x028C114C: B #0x28c1094               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x028C1150: ADRP x25, #0x3613000       | X25 = 56700928 (0x3613000);             
            // 0x028C1154: ADRP x26, #0x367a000       | X26 = 57122816 (0x367A000);             
            // 0x028C1158: LDR x25, [x25, #0xc58]     | X25 = 1152921504621809664;              
            // 0x028C115C: LDR x26, [x26, #0x470]     | X26 = 1152921504620691456;              
            // 0x028C1160: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x028C1164: B #0x28c116c               |  goto label_11;                         
            goto label_11;
            label_22:
            // 0x028C1168: ADD w28, w28, #1           | W28 = (val_12 + 1) = val_12 (0x00000001);
            val_12 = 1;
            label_11:
            // 0x028C116C: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C1170: CBNZ x20, #0x28c1178       | if (this.graphs != null) goto label_12; 
            if(this.graphs != null)
            {
                goto label_12;
            }
            // 0x028C1174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1234, ????);     
            label_12:
            // 0x028C1178: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C117C: CMP w28, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1180: B.GE #0x28c1280            | if (val_12 >= this.graphs.Length) goto label_13;
            if(val_12 >= this.graphs.Length)
            {
                goto label_13;
            }
            // 0x028C1184: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C1188: CBNZ x20, #0x28c1190       | if (this.graphs != null) goto label_14; 
            if(this.graphs != null)
            {
                goto label_14;
            }
            // 0x028C118C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1234, ????);     
            label_14:
            // 0x028C1190: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1194: SXTW x21, w28              | X21 = 1 (0x00000001);                   
            // 0x028C1198: CMP w28, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C119C: B.LO #0x28c11ac            | if (val_12 < this.graphs.Length) goto label_15;
            if(val_12 < this.graphs.Length)
            {
                goto label_15;
            }
            // 0x028C11A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1234, ????);     
            // 0x028C11A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C11A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1234, ????);     
            label_15:
            // 0x028C11AC: ADD x8, x20, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C11B0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_12 = this.graphs[1];
            // 0x028C11B4: CBZ x8, #0x28c1168         | if (this.graphs[0x1][0] == null) goto label_22;
            if(val_12 == null)
            {
                goto label_22;
            }
            // 0x028C11B8: LDR x0, [x22]              | X0 = typeof(System.Int32);              
            // 0x028C11BC: LDR x20, [x19, #0x28]      | X20 = this.zip; //P2                    
            // 0x028C11C0: ADD x1, sp, #8             | X1 = (1152921513278345744 + 8) = 1152921513278345752 (0x1000000204DC9218);
            // 0x028C11C4: STR w28, [sp, #8]          | stack[1152921513278345752] = 0x1;        //  dest_result_addr=1152921513278345752
            // 0x028C11C8: BL #0x27bc028              | X0 = 1152921513278561888 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C11CC: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x028C11D0: MOV x21, x0                | X21 = 1152921513278561888 (0x1000000204DFDE60);//ML01
            // 0x028C11D4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C11D8: TBZ w9, #0, #0x28c11ec     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x028C11DC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C11E0: CBNZ w9, #0x28c11ec        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x028C11E4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C11E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_18:
            // 0x028C11EC: LDR x1, [x24]              | X1 = "graph";                           
            // 0x028C11F0: LDR x3, [x27]              | X3 = "_nodes.binary";                   
            // 0x028C11F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C11F8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C11FC: MOV x2, x21                | X2 = 1152921513278561888 (0x1000000204DFDE60);//ML01
            // 0x028C1200: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_12);
            string val_3 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_12);
            // 0x028C1204: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028C1208: CBNZ x20, #0x28c1210       | if (this.zip != null) goto label_19;    
            if(this.zip != null)
            {
                goto label_19;
            }
            // 0x028C120C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_19:
            // 0x028C1210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1214: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028C1218: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028C121C: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  val_3);
            Pathfinding.Ionic.Zip.ZipEntry val_4 = this.zip.Item[val_3];
            // 0x028C1220: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x028C1224: CBZ x21, #0x28c1168        | if (val_4 == null) goto label_22;       
            if(val_4 == null)
            {
                goto label_22;
            }
            // 0x028C1228: LDR x0, [x25]              | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_5 = null;
            // 0x028C122C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028C1230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1234: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1238: BL #0x1e762f4              | .ctor();                                
            val_5 = new System.IO.MemoryStream();
            // 0x028C123C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1240: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x028C1244: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1248: BL #0x1977030              | val_4.Extract(stream:  val_5);          
            val_4.Extract(stream:  val_5);
            // 0x028C124C: CBNZ x20, #0x28c1254       | if ( != 0) goto label_21;               
            if(null != 0)
            {
                goto label_21;
            }
            // 0x028C1250: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_21:
            // 0x028C1254: LDR x8, [x20]              | X8 = ;                                  
            // 0x028C1258: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C125C: MOV x0, x20                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1260: LDP x9, x2, [x8, #0x1b0]   |                                          //  not_find_field!1:432 |  not_find_field!1:440
            // 0x028C1264: BLR x9                     | X0 = mem[null + 432]();                 
            // 0x028C1268: LDR x0, [x26]              | X0 = typeof(System.IO.BinaryReader);    
            System.IO.BinaryReader val_6 = null;
            // 0x028C126C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x028C1270: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1274: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1278: BL #0x1e664fc              | .ctor(input:  val_5);                   
            val_6 = new System.IO.BinaryReader(input:  val_5);
            // 0x028C127C: B #0x28c1168               |  goto label_22;                         
            goto label_22;
            label_13:
            // 0x028C1280: ADRP x28, #0x35e1000       | X28 = 56496128 (0x35E1000);             
            // 0x028C1284: LDR x28, [x28, #0xd00]     | X28 = (string**)(1152921513274513984)("_conns.binary");
            // 0x028C1288: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x028C128C: B #0x28c1294               |  goto label_23;                         
            goto label_23;
            label_34:
            // 0x028C1290: ADD w27, w27, #1           | W27 = (val_13 + 1) = val_13 (0x00000001);
            val_13 = 1;
            label_23:
            // 0x028C1294: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C1298: CBNZ x20, #0x28c12a0       | if (this.graphs != null) goto label_24; 
            if(this.graphs != null)
            {
                goto label_24;
            }
            // 0x028C129C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1234, ????);     
            label_24:
            // 0x028C12A0: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C12A4: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C12A8: B.GE #0x28c13a8            | if (val_13 >= this.graphs.Length) goto label_25;
            if(val_13 >= this.graphs.Length)
            {
                goto label_25;
            }
            // 0x028C12AC: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C12B0: CBNZ x20, #0x28c12b8       | if (this.graphs != null) goto label_26; 
            if(this.graphs != null)
            {
                goto label_26;
            }
            // 0x028C12B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1234, ????);     
            label_26:
            // 0x028C12B8: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C12BC: SXTW x21, w27              | X21 = 1 (0x00000001);                   
            // 0x028C12C0: CMP w27, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C12C4: B.LO #0x28c12d4            | if (val_13 < this.graphs.Length) goto label_27;
            if(val_13 < this.graphs.Length)
            {
                goto label_27;
            }
            // 0x028C12C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1234, ????);     
            // 0x028C12CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C12D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1234, ????);     
            label_27:
            // 0x028C12D4: ADD x8, x20, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C12D8: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_13 = this.graphs[1];
            // 0x028C12DC: CBZ x8, #0x28c1290         | if (this.graphs[0x1][0] == null) goto label_34;
            if(val_13 == null)
            {
                goto label_34;
            }
            // 0x028C12E0: LDR x0, [x22]              | X0 = typeof(System.Int32);              
            // 0x028C12E4: LDR x20, [x19, #0x28]      | X20 = this.zip; //P2                    
            // 0x028C12E8: ADD x1, sp, #4             | X1 = (1152921513278345744 + 4) = 1152921513278345748 (0x1000000204DC9214);
            // 0x028C12EC: STR w27, [sp, #4]          | stack[1152921513278345748] = 0x1;        //  dest_result_addr=1152921513278345748
            // 0x028C12F0: BL #0x27bc028              | X0 = 1152921513278656096 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C12F4: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x028C12F8: MOV x21, x0                | X21 = 1152921513278656096 (0x1000000204E14E60);//ML01
            // 0x028C12FC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C1300: TBZ w9, #0, #0x28c1314     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x028C1304: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C1308: CBNZ w9, #0x28c1314        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x028C130C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C1310: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_30:
            // 0x028C1314: LDR x1, [x24]              | X1 = "graph";                           
            // 0x028C1318: LDR x3, [x28]              | X3 = "_conns.binary";                   
            // 0x028C131C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C1320: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C1324: MOV x2, x21                | X2 = 1152921513278656096 (0x1000000204E14E60);//ML01
            // 0x028C1328: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_13);
            string val_7 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_13);
            // 0x028C132C: MOV x21, x0                | X21 = val_7;//m1                        
            // 0x028C1330: CBNZ x20, #0x28c1338       | if (this.zip != null) goto label_31;    
            if(this.zip != null)
            {
                goto label_31;
            }
            // 0x028C1334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_31:
            // 0x028C1338: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C133C: MOV x0, x20                | X0 = this.zip;//m1                      
            // 0x028C1340: MOV x1, x21                | X1 = val_7;//m1                         
            // 0x028C1344: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  val_7);
            Pathfinding.Ionic.Zip.ZipEntry val_8 = this.zip.Item[val_7];
            // 0x028C1348: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x028C134C: CBZ x21, #0x28c1290        | if (val_8 == null) goto label_34;       
            if(val_8 == null)
            {
                goto label_34;
            }
            // 0x028C1350: LDR x0, [x25]              | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_9 = null;
            // 0x028C1354: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028C1358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C135C: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1360: BL #0x1e762f4              | .ctor();                                
            val_9 = new System.IO.MemoryStream();
            // 0x028C1364: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1368: MOV x0, x21                | X0 = val_8;//m1                         
            // 0x028C136C: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1370: BL #0x1977030              | val_8.Extract(stream:  val_9);          
            val_8.Extract(stream:  val_9);
            // 0x028C1374: CBNZ x20, #0x28c137c       | if ( != 0) goto label_33;               
            if(null != 0)
            {
                goto label_33;
            }
            // 0x028C1378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_33:
            // 0x028C137C: LDR x8, [x20]              | X8 = ;                                  
            // 0x028C1380: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1384: MOV x0, x20                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1388: LDP x9, x2, [x8, #0x1b0]   |                                          //  not_find_field!1:432 |  not_find_field!1:440
            // 0x028C138C: BLR x9                     | X0 = mem[null + 432]();                 
            // 0x028C1390: LDR x0, [x26]              | X0 = typeof(System.IO.BinaryReader);    
            System.IO.BinaryReader val_10 = null;
            // 0x028C1394: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x028C1398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C139C: MOV x1, x20                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C13A0: BL #0x1e664fc              | .ctor(input:  val_9);                   
            val_10 = new System.IO.BinaryReader(input:  val_9);
            // 0x028C13A4: B #0x28c1290               |  goto label_34;                         
            goto label_34;
            label_25:
            // 0x028C13A8: SUB sp, x29, #0x50         | SP = (1152921513278345840 - 80) = 1152921513278345760 (0x1000000204DC9220);
            // 0x028C13AC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028C13B0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028C13B4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028C13B8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028C13BC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028C13C0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028C13C4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C13D0 (42734544), len: 2320  VirtAddr: 0x028C13D0 RVA: 0x028C13D0 token: 100682638 methodIndex: 51175 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeExtraInfo()
        {
            //
            // Disasemble & Code
            //  | 
            object val_26;
            //  | 
            object val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            // 0x028C13D0: STP x28, x27, [sp, #-0x60]! | stack[1152921513279224720] = ???;  stack[1152921513279224728] = ???;  //  dest_result_addr=1152921513279224720 |  dest_result_addr=1152921513279224728
            // 0x028C13D4: STP x26, x25, [sp, #0x10]  | stack[1152921513279224736] = ???;  stack[1152921513279224744] = ???;  //  dest_result_addr=1152921513279224736 |  dest_result_addr=1152921513279224744
            // 0x028C13D8: STP x24, x23, [sp, #0x20]  | stack[1152921513279224752] = ???;  stack[1152921513279224760] = ???;  //  dest_result_addr=1152921513279224752 |  dest_result_addr=1152921513279224760
            // 0x028C13DC: STP x22, x21, [sp, #0x30]  | stack[1152921513279224768] = ???;  stack[1152921513279224776] = ???;  //  dest_result_addr=1152921513279224768 |  dest_result_addr=1152921513279224776
            // 0x028C13E0: STP x20, x19, [sp, #0x40]  | stack[1152921513279224784] = ???;  stack[1152921513279224792] = ???;  //  dest_result_addr=1152921513279224784 |  dest_result_addr=1152921513279224792
            // 0x028C13E4: STP x29, x30, [sp, #0x50]  | stack[1152921513279224800] = ???;  stack[1152921513279224808] = ???;  //  dest_result_addr=1152921513279224800 |  dest_result_addr=1152921513279224808
            // 0x028C13E8: ADD x29, sp, #0x50         | X29 = (1152921513279224720 + 80) = 1152921513279224800 (0x1000000204E9FBE0);
            // 0x028C13EC: SUB sp, sp, #0x20          | SP = (1152921513279224720 - 32) = 1152921513279224688 (0x1000000204E9FB70);
            // 0x028C13F0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028C13F4: LDRB w8, [x20, #0x94a]     | W8 = (bool)static_value_037B894A;       
            // 0x028C13F8: MOV x19, x0                | X19 = 1152921513279236816 (0x1000000204EA2AD0);//ML01
            // 0x028C13FC: TBNZ w8, #0, #0x28c1418    | if (static_value_037B894A == true) goto label_0;
            // 0x028C1400: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x028C1404: LDR x8, [x8, #0xde0]       | X8 = 0x2B8EDC4;                         
            // 0x028C1408: LDR w0, [x8]               | W0 = 0x1231;                            
            // 0x028C140C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1231, ????);     
            // 0x028C1410: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C1414: STRB w8, [x20, #0x94a]     | static_value_037B894A = true;            //  dest_result_addr=58427722
            label_0:
            // 0x028C1418: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x028C141C: LDR x8, [x8, #0x10]        | X8 = 1152921504842043392;               
            // 0x028C1420: LDR x0, [x8]               | X0 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3);
            object val_1 = null;
            // 0x028C1424: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3), ????);
            // 0x028C1428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C142C: MOV x20, x0                | X20 = 1152921504842043392 (0x100000000E04D000);//ML01
            // 0x028C1430: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x028C1434: ADRP x26, #0x3652000       | X26 = 56958976 (0x3652000);             
            // 0x028C1438: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
            // 0x028C143C: ADRP x28, #0x3684000       | X28 = 57163776 (0x3684000);             
            // 0x028C1440: ADRP x24, #0x360a000       | X24 = 56664064 (0x360A000);             
            // 0x028C1444: LDR x26, [x26, #0x140]     | X26 = 1152921504607113216;              
            // 0x028C1448: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
            // 0x028C144C: LDR x28, [x28, #0x390]     | X28 = (string**)(1152921513124056064)("graph");
            // 0x028C1450: LDR x24, [x24, #0x230]     | X24 = (string**)(1152921513275429632)("_extra.binary");
            // 0x028C1454: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_26 = 0;
            // 0x028C1458: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            // 0x028C145C: B #0x28c1464               |  goto label_1;                          
            goto label_1;
            label_12:
            // 0x028C1460: ADD w23, w23, #1           | W23 = (val_26 + 1) = val_26 (0x00000001);
            val_26 = 1;
            label_1:
            // 0x028C1464: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C1468: CBNZ x21, #0x28c1470       | if (this.graphs != null) goto label_2;  
            if(this.graphs != null)
            {
                goto label_2;
            }
            // 0x028C146C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x028C1470: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1474: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1478: B.GE #0x28c15d8            | if (val_26 >= this.graphs.Length) goto label_3;
            if(val_26 >= this.graphs.Length)
            {
                goto label_3;
            }
            // 0x028C147C: LDR x0, [x26]              | X0 = typeof(System.Int32);              
            // 0x028C1480: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028C1484: ADD x1, sp, #0x1c          | X1 = (1152921513279224688 + 28) = 1152921513279224716 (0x1000000204E9FB8C);
            // 0x028C1488: STR w23, [sp, #0x1c]       | stack[1152921513279224716] = 0x1;        //  dest_result_addr=1152921513279224716
            // 0x028C148C: BL #0x27bc028              | X0 = 1152921513279309776 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C1490: LDR x8, [x27]              | X8 = typeof(System.String);             
            // 0x028C1494: MOV x22, x0                | X22 = 1152921513279309776 (0x1000000204EB47D0);//ML01
            // 0x028C1498: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C149C: TBZ w9, #0, #0x28c14b0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028C14A0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C14A4: CBNZ w9, #0x28c14b0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028C14A8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C14AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_5:
            // 0x028C14B0: LDR x1, [x28]              | X1 = "graph";                           
            // 0x028C14B4: LDR x3, [x24]              | X3 = "_extra.binary";                   
            // 0x028C14B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C14BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C14C0: MOV x2, x22                | X2 = 1152921513279309776 (0x1000000204EB47D0);//ML01
            // 0x028C14C4: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_26);
            string val_2 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_26);
            // 0x028C14C8: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x028C14CC: CBNZ x21, #0x28c14d4       | if (this.zip != null) goto label_6;     
            if(this.zip != null)
            {
                goto label_6;
            }
            // 0x028C14D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x028C14D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C14D8: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028C14DC: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x028C14E0: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  val_2);
            Pathfinding.Ionic.Zip.ZipEntry val_3 = this.zip.Item[val_2];
            // 0x028C14E4: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x028C14E8: CBZ x22, #0x28c1460        | if (val_3 == null) goto label_12;       
            if(val_3 == null)
            {
                goto label_12;
            }
            // 0x028C14EC: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028C14F0: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028C14F4: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_4 = null;
            // 0x028C14F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028C14FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1500: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1504: BL #0x1e762f4              | .ctor();                                
            val_4 = new System.IO.MemoryStream();
            // 0x028C1508: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C150C: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x028C1510: MOV x1, x21                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1514: BL #0x1977030              | val_3.Extract(stream:  val_4);          
            val_3.Extract(stream:  val_4);
            // 0x028C1518: CBNZ x21, #0x28c1520       | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x028C151C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_8:
            // 0x028C1520: LDR x8, [x21]              | X8 = ;                                  
            // 0x028C1524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1528: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C152C: MOV x0, x21                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1530: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x028C1534: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x028C1538: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x028C153C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028C1540: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x028C1544: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            System.IO.BinaryReader val_5 = null;
            // 0x028C1548: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x028C154C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1550: MOV x1, x21                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1554: MOV x22, x0                | X22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x028C1558: BL #0x1e664fc              | .ctor(input:  val_4);                   
            val_5 = new System.IO.BinaryReader(input:  val_4);
            // 0x028C155C: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028C1560: LDR x8, [x8, #0x8f8]       | X8 = 1152921504841777152;               
            // 0x028C1564: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GraphSerializationContext);
            object val_6 = null;
            // 0x028C1568: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GraphSerializationContext), ????);
            // 0x028C156C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1570: MOV x21, x0                | X21 = 1152921504841777152 (0x100000000E00C000);//ML01
            // 0x028C1574: BL #0x16f59f0              | .ctor();                                
            val_6 = new System.Object();
            // 0x028C1578: STP xzr, x22, [x21, #0x10] | typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_10 = 0x0;  typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_18 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504841777168 |  dest_result_addr=1152921504841777176
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_10 = 0;
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_18 = val_5;
            // 0x028C157C: STR w23, [x21, #0x28]      | typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_28 = 0x1;  //  dest_result_addr=1152921504841777192
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_28 = val_26;
            // 0x028C1580: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1584: CBNZ x22, #0x28c158c       | if (this.graphs != null) goto label_9;  
            if(this.graphs != null)
            {
                goto label_9;
            }
            // 0x028C1588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_9:
            // 0x028C158C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1590: SXTW x25, w23              | X25 = 1 (0x00000001);                   
            // 0x028C1594: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1598: B.LO #0x28c15a8            | if (val_26 < this.graphs.Length) goto label_10;
            if(val_26 < this.graphs.Length)
            {
                goto label_10;
            }
            // 0x028C159C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028C15A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C15A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_10:
            // 0x028C15A8: ADD x8, x22, x25, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C15AC: LDR x22, [x8, #0x20]       | X22 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_26 = this.graphs[1];
            // 0x028C15B0: CBNZ x22, #0x28c15b8       | if (this.graphs[0x1][0] != null) goto label_11;
            if(val_26 != null)
            {
                goto label_11;
            }
            // 0x028C15B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_11:
            // 0x028C15B8: LDR x8, [x22]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028C15BC: MOV x0, x22                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C15C0: MOV x1, x21                | X1 = 1152921504841777152 (0x100000000E00C000);//ML01
            // 0x028C15C4: LDR x9, [x8, #0x200]       | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_200;
            // 0x028C15C8: LDR x2, [x8, #0x208]       | X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_208;
            // 0x028C15CC: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_200();
            // 0x028C15D0: ORR w25, wzr, #1           | W25 = 1(0x1);                           
            // 0x028C15D4: B #0x28c1460               |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x028C15D8: TBZ w25, #0, #0x28c1bb4    | if ((0x0 & 0x1) == 0) goto label_49;    
            if((0 & 1) == 0)
            {
                goto label_49;
            }
            // 0x028C15DC: CBNZ x20, #0x28c15e4       | if ( != 0) goto label_14;               
            if(null != 0)
            {
                goto label_14;
            }
            // 0x028C15E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_14:
            // 0x028C15E4: STR wzr, [x20, #0x10]      | typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3).__il2cppRuntimeField_10 = 0x0;  //  dest_result_addr=1152921504842043408
            typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3).__il2cppRuntimeField_10 = 0;
            // 0x028C15E8: ADRP x25, #0x35d2000       | X25 = 56434688 (0x35D2000);             
            // 0x028C15EC: LDR x25, [x25, #0x628]     | X25 = 1152921513278818592;              
            val_27 = 1152921513278818592;
            // 0x028C15F0: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x028C15F4: B #0x28c15fc               |  goto label_15;                         
            goto label_15;
            label_24:
            // 0x028C15F8: ADD w24, w24, #1           | W24 = (val_28 + 1) = val_28 (0x00000001);
            val_28 = 1;
            label_15:
            // 0x028C15FC: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C1600: CBNZ x21, #0x28c1608       | if (this.graphs != null) goto label_16; 
            if(this.graphs != null)
            {
                goto label_16;
            }
            // 0x028C1604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_16:
            // 0x028C1608: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C160C: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1610: B.GE #0x28c16bc            | if (val_28 >= this.graphs.Length) goto label_17;
            if(val_28 >= this.graphs.Length)
            {
                goto label_17;
            }
            // 0x028C1614: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1618: CBNZ x22, #0x28c1620       | if (this.graphs != null) goto label_18; 
            if(this.graphs != null)
            {
                goto label_18;
            }
            // 0x028C161C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_18:
            // 0x028C1620: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1624: SXTW x21, w24              | X21 = 1 (0x00000001);                   
            // 0x028C1628: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C162C: B.LO #0x28c163c            | if (val_28 < this.graphs.Length) goto label_19;
            if(val_28 < this.graphs.Length)
            {
                goto label_19;
            }
            // 0x028C1630: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028C1634: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1638: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_19:
            // 0x028C163C: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1640: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_27 = this.graphs[1];
            // 0x028C1644: CBZ x8, #0x28c15f8         | if (this.graphs[0x1][0] == null) goto label_24;
            if(val_27 == null)
            {
                goto label_24;
            }
            // 0x028C1648: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C164C: CBNZ x22, #0x28c1654       | if (this.graphs != null) goto label_21; 
            if(this.graphs != null)
            {
                goto label_21;
            }
            // 0x028C1650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_21:
            // 0x028C1654: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1658: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C165C: B.LO #0x28c166c            | if (val_28 < this.graphs.Length) goto label_22;
            if(val_28 < this.graphs.Length)
            {
                goto label_22;
            }
            // 0x028C1660: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028C1664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1668: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_22:
            // 0x028C166C: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1670: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_28 = this.graphs[1];
            // 0x028C1674: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028C1678: LDR x23, [x25]             | X23 = System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);
            // 0x028C167C: LDR x8, [x8, #0xed0]       | X8 = 1152921504840179712;               
            // 0x028C1680: LDR x0, [x8]               | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            Pathfinding.GraphNodeDelegateCancelable val_7 = null;
            // 0x028C1684: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x028C1688: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C168C: MOV x1, x20                | X1 = 1152921504842043392 (0x100000000E04D000);//ML01
            // 0x028C1690: MOV x2, x23                | X2 = 1152921513278818592 (0x1000000204E3C920);//ML01
            // 0x028C1694: MOV x22, x0                | X22 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028C1698: BL #0x1681308              | .ctor(object:  val_1, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node));
            val_7 = new Pathfinding.GraphNodeDelegateCancelable(object:  val_1, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node));
            // 0x028C169C: CBNZ x21, #0x28c16a4       | if (this.graphs[0x1][0] != null) goto label_23;
            if(val_28 != null)
            {
                goto label_23;
            }
            // 0x028C16A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_1, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node)), ????);
            label_23:
            // 0x028C16A4: LDR x8, [x21]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028C16A8: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C16AC: MOV x1, x22                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028C16B0: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x028C16B4: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            // 0x028C16B8: B #0x28c15f8               |  goto label_24;                         
            goto label_24;
            label_17:
            // 0x028C16BC: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x028C16C0: LDR x8, [x8, #0xc40]       | X8 = 1152921504842096640;               
            // 0x028C16C4: LDR x0, [x8]               | X0 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4);
            object val_8 = null;
            // 0x028C16C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4), ????);
            // 0x028C16CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C16D0: MOV x20, x0                | X20 = 1152921504842096640 (0x100000000E05A000);//ML01
            // 0x028C16D4: BL #0x16f59f0              | .ctor();                                
            val_8 = new System.Object();
            // 0x028C16D8: LDR x21, [x19, #0x28]      | X21 = this.zip; //P2                    
            // 0x028C16DC: CBNZ x21, #0x28c16e4       | if (this.zip != null) goto label_25;    
            if(this.zip != null)
            {
                goto label_25;
            }
            // 0x028C16E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_25:
            // 0x028C16E4: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x028C16E8: LDR x8, [x8, #0x8f0]       | X8 = (string**)(1152921513275298432)("graph_references.binary");
            // 0x028C16EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C16F0: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028C16F4: LDR x1, [x8]               | X1 = "graph_references.binary";         
            // 0x028C16F8: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  "graph_references.binary");
            Pathfinding.Ionic.Zip.ZipEntry val_9 = this.zip.Item["graph_references.binary"];
            // 0x028C16FC: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x028C1700: CBZ x22, #0x28c1bf4        | if (val_9 == null) goto label_26;       
            if(val_9 == null)
            {
                goto label_26;
            }
            // 0x028C1704: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028C1708: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028C170C: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_10 = null;
            // 0x028C1710: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028C1714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1718: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C171C: BL #0x1e762f4              | .ctor();                                
            val_10 = new System.IO.MemoryStream();
            // 0x028C1720: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1724: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x028C1728: MOV x1, x21                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C172C: BL #0x1977030              | val_9.Extract(stream:  val_10);         
            val_9.Extract(stream:  val_10);
            // 0x028C1730: CBNZ x21, #0x28c1738       | if ( != 0) goto label_27;               
            if(null != 0)
            {
                goto label_27;
            }
            // 0x028C1734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_27:
            // 0x028C1738: LDR x8, [x21]              | X8 = ;                                  
            // 0x028C173C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1740: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C1744: MOV x0, x21                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1748: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x028C174C: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x028C1750: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x028C1754: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028C1758: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x028C175C: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            System.IO.BinaryReader val_11 = null;
            // 0x028C1760: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x028C1764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1768: MOV x1, x21                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C176C: MOV x22, x0                | X22 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x028C1770: BL #0x1e664fc              | .ctor(input:  val_10);                  
            val_11 = new System.IO.BinaryReader(input:  val_10);
            // 0x028C1774: CBZ x20, #0x28c1784        | if ( == 0) goto label_28;               
            if(null == 0)
            {
                goto label_28;
            }
            // 0x028C1778: MOV x21, x20               | X21 = 1152921504842096640 (0x100000000E05A000);//ML01
            val_29 = val_8;
            // 0x028C177C: STR x22, [x21, #0x18]!     | typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4).__il2cppRuntimeField_18 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504842096664
            typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4).__il2cppRuntimeField_18 = val_11;
            // 0x028C1780: B #0x28c1794               |  goto label_29;                         
            goto label_29;
            label_28:
            // 0x028C1784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_10), ????);
            // 0x028C1788: ORR w21, wzr, #0x18        | W21 = 24(0x18);                         
            val_29 = 24;
            // 0x028C178C: STR x22, [x21]             | mem[24] = typeof(System.IO.BinaryReader);  //  dest_result_addr=24
            mem[24] = val_11;
            // 0x028C1790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_10), ????);
            label_29:
            // 0x028C1794: STR x21, [sp]              | stack[1152921513279224688] = 0x18;       //  dest_result_addr=1152921513279224688
            // 0x028C1798: LDR x21, [x21]             | X21 = typeof(System.IO.BinaryReader);   
            // 0x028C179C: CBNZ x21, #0x28c17a4       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x028C17A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_10), ????);
            label_30:
            // 0x028C17A4: LDR x8, [x21]              | X8 = ;                                  
            // 0x028C17A8: MOV x0, x21                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x028C17AC: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x028C17B0: LDR x1, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x028C17B4: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x028C17B8: MOV w21, w0                | W21 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x028C17BC: CBNZ x20, #0x28c17c4       | if ( != 0) goto label_31;               
            if(null != 0)
            {
                goto label_31;
            }
            // 0x028C17C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_31:
            // 0x028C17C4: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x028C17C8: LDR x8, [x8, #0xb20]       | X8 = 1152921507461752176;               
            // 0x028C17CC: ADD w21, w21, #1           | W21 = (mem[24] + 1) = 1152921504620691457 (0x1000000000D34001);
            // 0x028C17D0: LDR x22, [x8]              | X22 = typeof(Pathfinding.GraphNode[]);  
            // 0x028C17D4: MOV x0, x22                | X0 = 1152921507461752176 (0x10000000AA2A6570);//ML01
            // 0x028C17D8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.GraphNode[]), ????);
            // 0x028C17DC: MOV x0, x22                | X0 = 1152921507461752176 (0x10000000AA2A6570);//ML01
            // 0x028C17E0: MOV x1, x21                | X1 = 1152921504620691457 (0x1000000000D34001);//ML01
            // 0x028C17E4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.GraphNode[]), ????);
            // 0x028C17E8: STR x0, [x20, #0x10]       | typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4).__il2cppRuntimeField_10 = typeof(Pathfinding.GraphNode[]);  //  dest_result_addr=1152921504842096656
            typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4).__il2cppRuntimeField_10 = null;
            // 0x028C17EC: ADRP x25, #0x362c000       | X25 = 56803328 (0x362C000);             
            // 0x028C17F0: STR x20, [sp, #8]          | stack[1152921513279224696] = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4);  //  dest_result_addr=1152921513279224696
            // 0x028C17F4: LDR x25, [x25, #0xcc0]     | X25 = 1152921513278946592;              
            // 0x028C17F8: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_30 = 0;
            // 0x028C17FC: B #0x28c1804               |  goto label_32;                         
            goto label_32;
            label_41:
            // 0x028C1800: ADD w24, w24, #1           | W24 = (val_30 + 1) = val_30 (0x00000001);
            val_30 = 1;
            label_32:
            // 0x028C1804: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C1808: CBNZ x21, #0x28c1810       | if (this.graphs != null) goto label_33; 
            if(this.graphs != null)
            {
                goto label_33;
            }
            // 0x028C180C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_33:
            // 0x028C1810: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1814: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1818: B.GE #0x28c1928            | if (val_30 >= this.graphs.Length) goto label_34;
            if(val_30 >= this.graphs.Length)
            {
                goto label_34;
            }
            // 0x028C181C: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1820: CBNZ x22, #0x28c1828       | if (this.graphs != null) goto label_35; 
            if(this.graphs != null)
            {
                goto label_35;
            }
            // 0x028C1824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_35:
            // 0x028C1828: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C182C: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1830: B.LO #0x28c1840            | if (val_30 < this.graphs.Length) goto label_36;
            if(val_30 < this.graphs.Length)
            {
                goto label_36;
            }
            // 0x028C1834: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.GraphNode[]), ????);
            // 0x028C1838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C183C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_36:
            // 0x028C1840: SXTW x21, w24              | X21 = 1 (0x00000001);                   
            // 0x028C1844: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1848: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_29 = this.graphs[1];
            // 0x028C184C: CBZ x8, #0x28c1800         | if (this.graphs[0x1][0] == null) goto label_41;
            if(val_29 == null)
            {
                goto label_41;
            }
            // 0x028C1850: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1854: CBNZ x22, #0x28c185c       | if (this.graphs != null) goto label_38; 
            if(this.graphs != null)
            {
                goto label_38;
            }
            // 0x028C1858: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_38:
            // 0x028C185C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1860: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1864: B.LO #0x28c1874            | if (val_30 < this.graphs.Length) goto label_39;
            if(val_30 < this.graphs.Length)
            {
                goto label_39;
            }
            // 0x028C1868: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.GraphNode[]), ????);
            // 0x028C186C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1870: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_39:
            // 0x028C1874: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1878: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_30 = this.graphs[1];
            // 0x028C187C: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028C1880: LDR x23, [x25]             | X23 = System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);
            // 0x028C1884: LDR x8, [x8, #0xed0]       | X8 = 1152921504840179712;               
            // 0x028C1888: LDR x0, [x8]               | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            // 0x028C188C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x028C1890: MOV x22, x0                | X22 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028C1894: LDR x1, [sp, #8]           | X1 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4);
            // 0x028C1898: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C189C: MOV x0, x22                | X0 = 1152921504840179712 (0x100000000DE86000);//ML01
            Pathfinding.GraphNodeDelegateCancelable val_12 = null;
            // 0x028C18A0: MOV x2, x23                | X2 = 1152921513278946592 (0x1000000204E5BD20);//ML01
            // 0x028C18A4: BL #0x1681308              | .ctor(object:  val_8, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node));
            val_12 = new Pathfinding.GraphNodeDelegateCancelable(object:  val_8, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node));
            // 0x028C18A8: CBNZ x21, #0x28c18b0       | if (this.graphs[0x1][0] != null) goto label_40;
            if(val_30 != null)
            {
                goto label_40;
            }
            // 0x028C18AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_8, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node)), ????);
            label_40:
            // 0x028C18B0: LDR x8, [x21]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028C18B4: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x028C18B8: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C18BC: MOV x1, x22                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028C18C0: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            // 0x028C18C4: B #0x28c1800               |  goto label_41;                         
            goto label_41;
            // 0x028C18C8: MOV x19, x0                | X19 = this.graphs[0x1][0];//m1          
            val_31 = val_30;
            // 0x028C18CC: CMP w1, #1                 | STATE = COMPARE(typeof(Pathfinding.GraphNodeDelegateCancelable), 0x1)
            // 0x028C18D0: B.NE #0x28c1cd4            | if (null != 0x1) goto label_42;         
            if(null != 1)
            {
                goto label_42;
            }
            // 0x028C18D4: MOV x0, x19                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C18D8: BL #0x981060               | X0 = sub_981060( ?? this.graphs[0x1][0], ????);
            // 0x028C18DC: MOV x20, x0                | X20 = this.graphs[0x1][0];//m1          
            // 0x028C18E0: ADRP x21, #0x3624000       | X21 = 56770560 (0x3624000);             
            // 0x028C18E4: LDR x19, [x20]             | X19 = typeof(Pathfinding.NavGraph);     
            // 0x028C18E8: LDR x21, [x21, #0xf98]     | X21 = 1152921504609882112;              
            // 0x028C18EC: LDR x1, [x19]              | X1 = ;                                  
            // 0x028C18F0: LDR x0, [x21]              | X0 = typeof(System.Exception);          
            // 0x028C18F4: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
            // 0x028C18F8: TBZ w0, #0, #0x28c1bd4     | if ((typeof(System.Exception) & 0x1) == 0) goto label_43;
            if((null & 1) == 0)
            {
                goto label_43;
            }
            // 0x028C18FC: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
            // 0x028C1900: LDR x0, [x21]              | X0 = typeof(System.Exception);          
            System.Exception val_13 = null;
            // 0x028C1904: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028C1908: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x028C190C: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921513279066400)("Some graph(s) has thrown an exception during GetNodes, or some graph(s) have deserialized more or fewer nodes than were serialized");
            // 0x028C1910: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C1914: MOV x2, x19                | X2 = 1152921504844173312 (0x100000000E255000);//ML01
            // 0x028C1918: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_32 = val_13;
            // 0x028C191C: LDR x1, [x8]               | X1 = "Some graph(s) has thrown an exception during GetNodes, or some graph(s) have deserialized more or fewer nodes than were serialized";
            // 0x028C1920: BL #0x1c3e600              | .ctor(message:  "Some graph(s) has thrown an exception during GetNodes, or some graph(s) have deserialized more or fewer nodes than were serialized", innerException:  1152921504844173312);
            val_13 = new System.Exception(message:  "Some graph(s) has thrown an exception during GetNodes, or some graph(s) have deserialized more or fewer nodes than were serialized", innerException:  1152921504844173312);
            // 0x028C1924: B #0x28c1cb4               |  goto label_44;                         
            goto label_44;
            label_34:
            // 0x028C1928: LDR x8, [sp, #8]           | X8 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4);
            // 0x028C192C: CBNZ x8, #0x28c1934        | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x028C1930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_45:
            // 0x028C1934: LDR x8, [sp]               | X8 = 0x18;                              
            // 0x028C1938: LDR x21, [x8]              | X21 = typeof(System.IO.BinaryReader);   
            // 0x028C193C: CBNZ x21, #0x28c1944       | if ( != 0) goto label_46;               
            if(null != 0)
            {
                goto label_46;
            }
            // 0x028C1940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNode[]), ????);
            label_46:
            // 0x028C1944: LDR x8, [x21]              | X8 = ;                                  
            // 0x028C1948: MOV x0, x21                | X0 = 1152921504620691456 (0x1000000000D34000);//ML01
            // 0x028C194C: LDP x9, x1, [x8, #0x170]   |                                          //  not_find_field!1:368 |  not_find_field!1:376
            // 0x028C1950: BLR x9                     | X0 = mem[null + 368]();                 
            // 0x028C1954: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_27 = 0;
            // 0x028C1958: B #0x28c1960               |  goto label_47;                         
            goto label_47;
            label_64:
            // 0x028C195C: ADD w25, w25, #1           | W25 = (val_27 + 1) = val_27 (0x00000001);
            val_27 = 1;
            label_47:
            // 0x028C1960: LDR x21, [x19, #0x48]      | X21 = this.graphs; //P2                 
            // 0x028C1964: CBNZ x21, #0x28c196c       | if (this.graphs != null) goto label_48; 
            if(this.graphs != null)
            {
                goto label_48;
            }
            // 0x028C1968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryReader), ????);
            label_48:
            // 0x028C196C: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1970: CMP w25, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1974: B.GE #0x28c1bb4            | if (val_27 >= this.graphs.Length) goto label_49;
            if(val_27 >= this.graphs.Length)
            {
                goto label_49;
            }
            // 0x028C1978: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x028C197C: LDR x8, [x8, #0xee8]       | X8 = 1152921504842149888;               
            // 0x028C1980: LDR x0, [x8]               | X0 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5);
            object val_14 = null;
            // 0x028C1984: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5), ????);
            // 0x028C1988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C198C: MOV x21, x0                | X21 = 1152921504842149888 (0x100000000E067000);//ML01
            // 0x028C1990: BL #0x16f59f0              | .ctor();                                
            val_14 = new System.Object();
            // 0x028C1994: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1998: CBNZ x22, #0x28c19a0       | if (this.graphs != null) goto label_50; 
            if(this.graphs != null)
            {
                goto label_50;
            }
            // 0x028C199C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_50:
            // 0x028C19A0: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C19A4: SXTW x24, w25              | X24 = 1 (0x00000001);                   
            // 0x028C19A8: CMP w25, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C19AC: B.LO #0x28c19bc            | if (val_27 < this.graphs.Length) goto label_51;
            if(val_27 < this.graphs.Length)
            {
                goto label_51;
            }
            // 0x028C19B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028C19B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C19B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_51:
            // 0x028C19BC: ADD x8, x22, x24, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C19C0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_31 = this.graphs[1];
            // 0x028C19C4: CBZ x8, #0x28c195c         | if (this.graphs[0x1][0] == null) goto label_64;
            if(val_31 == null)
            {
                goto label_64;
            }
            // 0x028C19C8: LDR x0, [x26]              | X0 = typeof(System.Int32);              
            // 0x028C19CC: LDR x22, [x19, #0x28]      | X22 = this.zip; //P2                    
            // 0x028C19D0: ADD x1, sp, #0x18          | X1 = (1152921513279224688 + 24) = 1152921513279224712 (0x1000000204E9FB88);
            // 0x028C19D4: STR w25, [sp, #0x18]       | stack[1152921513279224712] = 0x1;        //  dest_result_addr=1152921513279224712
            // 0x028C19D8: BL #0x27bc028              | X0 = 1152921513279690704 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C19DC: LDR x8, [x27]              | X8 = typeof(System.String);             
            // 0x028C19E0: MOV x23, x0                | X23 = 1152921513279690704 (0x1000000204F117D0);//ML01
            // 0x028C19E4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C19E8: TBZ w9, #0, #0x28c19fc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_54;
            // 0x028C19EC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C19F0: CBNZ w9, #0x28c19fc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_54;
            // 0x028C19F4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C19F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_54:
            // 0x028C19FC: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x028C1A00: LDR x1, [x28]              | X1 = "graph";                           
            // 0x028C1A04: LDR x8, [x8, #0x980]       | X8 = (string**)(1152921513275488096)("_references.binary");
            // 0x028C1A08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C1A0C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C1A10: MOV x2, x23                | X2 = 1152921513279690704 (0x1000000204F117D0);//ML01
            // 0x028C1A14: LDR x3, [x8]               | X3 = "_references.binary";              
            // 0x028C1A18: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_27);
            string val_15 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_27);
            // 0x028C1A1C: MOV x23, x0                | X23 = val_15;//m1                       
            // 0x028C1A20: CBNZ x22, #0x28c1a28       | if (this.zip != null) goto label_55;    
            if(this.zip != null)
            {
                goto label_55;
            }
            // 0x028C1A24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_55:
            // 0x028C1A28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1A2C: MOV x0, x22                | X0 = this.zip;//m1                      
            // 0x028C1A30: MOV x1, x23                | X1 = val_15;//m1                        
            // 0x028C1A34: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  val_15);
            Pathfinding.Ionic.Zip.ZipEntry val_16 = this.zip.Item[val_15];
            // 0x028C1A38: MOV x23, x0                | X23 = val_16;//m1                       
            // 0x028C1A3C: CBZ x23, #0x28c1c34        | if (val_16 == null) goto label_56;      
            if(val_16 == null)
            {
                goto label_56;
            }
            // 0x028C1A40: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028C1A44: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028C1A48: MOV x20, x28               | X20 = 58408296 (0x37B3D68);//ML01       
            // 0x028C1A4C: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_17 = null;
            // 0x028C1A50: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028C1A54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1A58: MOV x22, x0                | X22 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1A5C: BL #0x1e762f4              | .ctor();                                
            val_17 = new System.IO.MemoryStream();
            // 0x028C1A60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1A64: MOV x0, x23                | X0 = val_16;//m1                        
            // 0x028C1A68: MOV x1, x22                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1A6C: BL #0x1977030              | val_16.Extract(stream:  val_17);        
            val_16.Extract(stream:  val_17);
            // 0x028C1A70: CBNZ x22, #0x28c1a78       | if ( != 0) goto label_57;               
            if(null != 0)
            {
                goto label_57;
            }
            // 0x028C1A74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_57:
            // 0x028C1A78: LDR x8, [x22]              | X8 = ;                                  
            // 0x028C1A7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1A80: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C1A84: MOV x0, x22                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1A88: LDR x9, [x8, #0x240]       |  //  not_find_field!1:576
            // 0x028C1A8C: LDR x3, [x8, #0x248]       |  //  not_find_field!1:584
            // 0x028C1A90: MOV x28, x26               | X28 = 57977360 (0x374AA10);//ML01       
            // 0x028C1A94: BLR x9                     | X0 = mem[null + 576]();                 
            // 0x028C1A98: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x028C1A9C: LDR x8, [x8, #0x470]       | X8 = 1152921504620691456;               
            // 0x028C1AA0: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryReader);    
            System.IO.BinaryReader val_18 = null;
            // 0x028C1AA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryReader), ????);
            // 0x028C1AA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1AAC: MOV x1, x22                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C1AB0: MOV x23, x0                | X23 = 1152921504620691456 (0x1000000000D34000);//ML01
            val_33 = val_18;
            // 0x028C1AB4: BL #0x1e664fc              | .ctor(input:  val_17);                  
            val_18 = new System.IO.BinaryReader(input:  val_17);
            // 0x028C1AB8: LDR x8, [sp, #8]           | X8 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4);
            val_34 = val_8;
            // 0x028C1ABC: CBZ x8, #0x28c1ad0         | if ( == 0) goto label_58;               
            if(null == 0)
            {
                goto label_58;
            }
            // 0x028C1AC0: LDR x9, [sp]               | X9 = 0x18;                              
            // 0x028C1AC4: MOV x26, x27               | X26 = 57977240 (0x374A998);//ML01       
            val_35 = 1152921504608284672;
            // 0x028C1AC8: STR x23, [x9]              | mem[24] = typeof(System.IO.BinaryReader);  //  dest_result_addr=24
            mem[24] = val_33;
            // 0x028C1ACC: B #0x28c1af4               |  goto label_59;                         
            goto label_59;
            label_58:
            // 0x028C1AD0: MOV x26, x27               | X26 = 57977240 (0x374A998);//ML01       
            val_35 = 1152921504608284672;
            // 0x028C1AD4: MOV x22, x8                | X22 = 1152921504842096640 (0x100000000E05A000);//ML01
            // 0x028C1AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_17), ????);
            // 0x028C1ADC: LDR x27, [sp]              | X27 = 0x18;                             
            // 0x028C1AE0: STR x23, [x27]             | mem[24] = typeof(System.IO.BinaryReader);  //  dest_result_addr=24
            mem[24] = val_33;
            // 0x028C1AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_17), ????);
            // 0x028C1AE8: LDR x23, [x27]             | X23 = typeof(System.IO.BinaryReader);   
            val_33 = mem[24];
            // 0x028C1AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_17), ????);
            // 0x028C1AF0: MOV x8, x22                | X8 = 1152921504842096640 (0x100000000E05A000);//ML01
            val_34 = val_34;
            label_59:
            // 0x028C1AF4: STR x8, [sp, #8]           | stack[1152921513279224696] = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4);  //  dest_result_addr=1152921513279224696
            // 0x028C1AF8: LDR x27, [x8, #0x10]       | X27 = typeof(Pathfinding.GraphNode[]);  
            // 0x028C1AFC: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028C1B00: LDR x8, [x8, #0x8f8]       | X8 = 1152921504841777152;               
            // 0x028C1B04: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.GraphSerializationContext);
            object val_19 = null;
            // 0x028C1B08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.GraphSerializationContext), ????);
            // 0x028C1B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1B10: MOV x22, x0                | X22 = 1152921504841777152 (0x100000000E00C000);//ML01
            // 0x028C1B14: BL #0x16f59f0              | .ctor();                                
            val_19 = new System.Object();
            // 0x028C1B18: STP x27, x23, [x22, #0x10] | typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_10 = typeof(Pathfinding.GraphNode[]);  typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_18 = typeof(System.IO.BinaryReader);  //  dest_result_addr=1152921504841777168 |  dest_result_addr=1152921504841777176
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_10 = typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey4).__il2cppRuntimeField_10;
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_18 = val_33;
            // 0x028C1B1C: STR w25, [x22, #0x28]      | typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_28 = 0x1;  //  dest_result_addr=1152921504841777192
            typeof(Pathfinding.Serialization.GraphSerializationContext).__il2cppRuntimeField_28 = val_27;
            // 0x028C1B20: CBNZ x21, #0x28c1b28       | if ( != 0) goto label_60;               
            if(null != 0)
            {
                goto label_60;
            }
            // 0x028C1B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_60:
            // 0x028C1B28: STR x22, [x21, #0x10]      | typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5).__il2cppRuntimeField_10 = typeof(Pathfinding.Serialization.GraphSerializationContext);  //  dest_result_addr=1152921504842149904
            typeof(AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5).__il2cppRuntimeField_10 = val_19;
            // 0x028C1B2C: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1B30: MOV x27, x26               | X27 = 57977240 (0x374A998);//ML01       
            // 0x028C1B34: CBNZ x22, #0x28c1b3c       | if (this.graphs != null) goto label_61; 
            if(this.graphs != null)
            {
                goto label_61;
            }
            // 0x028C1B38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_61:
            // 0x028C1B3C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1B40: CMP w25, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1B44: MOV x26, x28               | X26 = 57977360 (0x374AA10);//ML01       
            // 0x028C1B48: B.LO #0x28c1b58            | if (val_27 < this.graphs.Length) goto label_62;
            if(val_27 < this.graphs.Length)
            {
                goto label_62;
            }
            // 0x028C1B4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x028C1B50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1B54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_62:
            // 0x028C1B58: ADRP x9, #0x364a000        | X9 = 56926208 (0x364A000);              
            // 0x028C1B5C: LDR x9, [x9, #0xfc8]       | X9 = 1152921513279197808;               
            // 0x028C1B60: ADD x8, x22, x24, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1B64: LDR x22, [x8, #0x20]       | X22 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_32 = this.graphs[1];
            // 0x028C1B68: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x028C1B6C: LDR x24, [x9]              | X24 = System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5::<>m__0(Pathfinding.GraphNode node);
            // 0x028C1B70: LDR x8, [x8, #0xed0]       | X8 = 1152921504840179712;               
            // 0x028C1B74: LDR x0, [x8]               | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            Pathfinding.GraphNodeDelegateCancelable val_20 = null;
            // 0x028C1B78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x028C1B7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C1B80: MOV x1, x21                | X1 = 1152921504842149888 (0x100000000E067000);//ML01
            // 0x028C1B84: MOV x2, x24                | X2 = 1152921513279197808 (0x1000000204E99270);//ML01
            // 0x028C1B88: MOV x23, x0                | X23 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028C1B8C: BL #0x1681308              | .ctor(object:  val_14, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5::<>m__0(Pathfinding.GraphNode node));
            val_20 = new Pathfinding.GraphNodeDelegateCancelable(object:  val_14, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5::<>m__0(Pathfinding.GraphNode node));
            // 0x028C1B90: MOV x28, x20               | X28 = 58408296 (0x37B3D68);//ML01       
            // 0x028C1B94: CBNZ x22, #0x28c1b9c       | if (this.graphs[0x1][0] != null) goto label_63;
            if(val_32 != null)
            {
                goto label_63;
            }
            // 0x028C1B98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_14, method:  System.Boolean AstarSerializer.<DeserializeExtraInfo>c__AnonStorey5::<>m__0(Pathfinding.GraphNode node)), ????);
            label_63:
            // 0x028C1B9C: LDR x8, [x22]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028C1BA0: MOV x0, x22                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C1BA4: MOV x1, x23                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x028C1BA8: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x028C1BAC: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            // 0x028C1BB0: B #0x28c195c               |  goto label_64;                         
            goto label_64;
            label_49:
            // 0x028C1BB4: SUB sp, x29, #0x50         | SP = (1152921513279224800 - 80) = 1152921513279224720 (0x1000000204E9FB90);
            // 0x028C1BB8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028C1BBC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028C1BC0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028C1BC4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028C1BC8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028C1BCC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028C1BD0: RET                        |  return;                                
            return;
            label_43:
            // 0x028C1BD4: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x028C1BD8: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x028C1BDC: LDR x8, [x20]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028C1BE0: STR x8, [x0]               | mem[8] = typeof(Pathfinding.NavGraph);   //  dest_result_addr=8
            mem[8] = null;
            // 0x028C1BE4: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x028C1BE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1BEC: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x028C1BF0: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            label_26:
            // 0x028C1BF4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028C1BF8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028C1BFC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_21 = null;
            // 0x028C1C00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028C1C04: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x028C1C08: LDR x8, [x8, #0x628]       | X8 = (string**)(1152921513279202928)("Node references not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
            // 0x028C1C0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1C10: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028C1C14: LDR x1, [x8]               | X1 = "Node references not found in the data. Was this loaded from an older version of the A* Pathfinding Project?";
            // 0x028C1C18: BL #0x1c32b48              | .ctor(message:  "Node references not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
            val_21 = new System.Exception(message:  "Node references not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
            // 0x028C1C1C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028C1C20: LDR x8, [x8, #0x408]       | X8 = 1152921513279203216;               
            // 0x028C1C24: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028C1C28: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Serialization.AstarSerializer::DeserializeExtraInfo();
            // 0x028C1C2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028C1C30: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_22 = MoveNext();
            label_56:
            // 0x028C1C34: LDR x0, [x26]              | X0 = typeof(System.Int32);              
            // 0x028C1C38: ADD x1, sp, #0x14          | X1 = (1152921513279224688 + 20) = 1152921513279224708 (0x1000000204E9FB84);
            // 0x028C1C3C: STR w25, [sp, #0x14]       | stack[1152921513279224708] = 1152921513278946592;  //  dest_result_addr=1152921513279224708
            // 0x028C1C40: BL #0x27bc028              | X0 = 1152921513279743952 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1152921513278946592);
            // 0x028C1C44: LDR x8, [x27]              | X8 = typeof(System.String);             
            // 0x028C1C48: MOV x19, x0                | X19 = 1152921513279743952 (0x1000000204F1E7D0);//ML01
            // 0x028C1C4C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C1C50: TBZ w9, #0, #0x28c1c64     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_66;
            // 0x028C1C54: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C1C58: CBNZ w9, #0x28c1c64        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_66;
            // 0x028C1C5C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C1C60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_66:
            // 0x028C1C64: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x028C1C68: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x028C1C6C: LDR x8, [x8, #0x518]       | X8 = (string**)(1152921513279208336)("Node references for graph ");
            // 0x028C1C70: LDR x9, [x9, #0x398]       | X9 = (string**)(1152921513279208464)(" not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
            // 0x028C1C74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C1C78: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C1C7C: LDR x1, [x8]               | X1 = "Node references for graph ";      
            // 0x028C1C80: LDR x3, [x9]               | X3 = " not found in the data. Was this loaded from an older version of the A* Pathfinding Project?";
            // 0x028C1C84: MOV x2, x19                | X2 = 1152921513279743952 (0x1000000204F1E7D0);//ML01
            // 0x028C1C88: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "Node references for graph ", arg2:  1152921513278946592);
            string val_23 = System.String.Concat(arg0:  0, arg1:  "Node references for graph ", arg2:  1152921513278946592);
            // 0x028C1C8C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028C1C90: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028C1C94: MOV x19, x0                | X19 = val_23;//m1                       
            // 0x028C1C98: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028C1C9C: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_24 = null;
            // 0x028C1CA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028C1CA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1CA8: MOV x1, x19                | X1 = val_23;//m1                        
            // 0x028C1CAC: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_32 = val_24;
            // 0x028C1CB0: BL #0x1c32b48              | .ctor(message:  val_23);                
            val_24 = new System.Exception(message:  val_23);
            label_44:
            // 0x028C1CB4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x028C1CB8: LDR x8, [x8, #0x408]       | X8 = 1152921513279203216;               
            // 0x028C1CBC: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028C1CC0: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Serialization.AstarSerializer::DeserializeExtraInfo();
            // 0x028C1CC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028C1CC8: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_25 = MoveNext();
            // 0x028C1CCC: MOV x19, x0                | X19 = val_25;//m1                       
            val_31 = val_25;
            // 0x028C1CD0: BL #0x980920               | X0 = sub_980920( ?? val_25, ????);      
            label_42:
            // 0x028C1CD4: MOV x0, x19                | X0 = val_25;//m1                        
            // 0x028C1CD8: BL #0x980800               | X0 = sub_980800( ?? val_25, ????);      
            // 0x028C1CDC: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x028C1D38 (42736952), len: 200  VirtAddr: 0x028C1D38 RVA: 0x028C1D38 token: 100682639 methodIndex: 51176 delegateWrapperIndex: 0 methodInvoker: 0
        public void PostDeserialization()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x028C1D38: STP x22, x21, [sp, #-0x30]! | stack[1152921513279938880] = ???;  stack[1152921513279938888] = ???;  //  dest_result_addr=1152921513279938880 |  dest_result_addr=1152921513279938888
            // 0x028C1D3C: STP x20, x19, [sp, #0x10]  | stack[1152921513279938896] = ???;  stack[1152921513279938904] = ???;  //  dest_result_addr=1152921513279938896 |  dest_result_addr=1152921513279938904
            // 0x028C1D40: STP x29, x30, [sp, #0x20]  | stack[1152921513279938912] = ???;  stack[1152921513279938920] = ???;  //  dest_result_addr=1152921513279938912 |  dest_result_addr=1152921513279938920
            // 0x028C1D44: ADD x29, sp, #0x20         | X29 = (1152921513279938880 + 32) = 1152921513279938912 (0x1000000204F4E160);
            // 0x028C1D48: MOV x19, x0                | X19 = 1152921513279950928 (0x1000000204F51050);//ML01
            // 0x028C1D4C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_1 = 0;
            // 0x028C1D50: B #0x28c1d58               |  goto label_0;                          
            goto label_0;
            label_9:
            // 0x028C1D54: ADD w21, w21, #1           | W21 = (val_1 + 1) = val_1 (0x00000001); 
            val_1 = 1;
            label_0:
            // 0x028C1D58: LDR x20, [x19, #0x48]      | X20 = this.graphs; //P2                 
            // 0x028C1D5C: CBNZ x20, #0x28c1d64       | if (this.graphs != null) goto label_1;  
            if(this.graphs != null)
            {
                goto label_1;
            }
            // 0x028C1D60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x028C1D64: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1D68: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1D6C: B.GE #0x28c1df0            | if (val_1 >= this.graphs.Length) goto label_2;
            if(val_1 >= this.graphs.Length)
            {
                goto label_2;
            }
            // 0x028C1D70: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1D74: CBNZ x22, #0x28c1d7c       | if (this.graphs != null) goto label_3;  
            if(this.graphs != null)
            {
                goto label_3;
            }
            // 0x028C1D78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x028C1D7C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1D80: SXTW x20, w21              | X20 = 1 (0x00000001);                   
            // 0x028C1D84: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1D88: B.LO #0x28c1d98            | if (val_1 < this.graphs.Length) goto label_4;
            if(val_1 < this.graphs.Length)
            {
                goto label_4;
            }
            // 0x028C1D8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x028C1D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1D94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_4:
            // 0x028C1D98: ADD x8, x22, x20, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1D9C: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_1 = this.graphs[1];
            // 0x028C1DA0: CBZ x8, #0x28c1d54         | if (this.graphs[0x1][0] == null) goto label_9;
            if(val_1 == null)
            {
                goto label_9;
            }
            // 0x028C1DA4: LDR x22, [x19, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1DA8: CBNZ x22, #0x28c1db0       | if (this.graphs != null) goto label_6;  
            if(this.graphs != null)
            {
                goto label_6;
            }
            // 0x028C1DAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x028C1DB0: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1DB4: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1DB8: B.LO #0x28c1dc8            | if (val_1 < this.graphs.Length) goto label_7;
            if(val_1 < this.graphs.Length)
            {
                goto label_7;
            }
            // 0x028C1DBC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x028C1DC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1DC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_7:
            // 0x028C1DC8: ADD x8, x22, x20, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1DCC: LDR x20, [x8, #0x20]       | X20 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_2 = this.graphs[1];
            // 0x028C1DD0: CBNZ x20, #0x28c1dd8       | if (this.graphs[0x1][0] != null) goto label_8;
            if(val_2 != null)
            {
                goto label_8;
            }
            // 0x028C1DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x028C1DD8: LDR x8, [x20]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x028C1DDC: MOV x0, x20                | X0 = this.graphs[0x1][0];//m1           
            // 0x028C1DE0: LDR x9, [x8, #0x210]       | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_210;
            // 0x028C1DE4: LDR x1, [x8, #0x218]       | X1 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_218;
            // 0x028C1DE8: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_210();
            // 0x028C1DEC: B #0x28c1d54               |  goto label_9;                          
            goto label_9;
            label_2:
            // 0x028C1DF0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C1DF4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C1DF8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C1DFC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C13C8 (42734536), len: 4  VirtAddr: 0x028C13C8 RVA: 0x028C13C8 token: 100682640 methodIndex: 51177 delegateWrapperIndex: 0 methodInvoker: 0
        private void DeserializeNodes(int index, System.IO.BinaryReader reader)
        {
            //
            // Disasemble & Code
            // 0x028C13C8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C13CC (42734540), len: 4  VirtAddr: 0x028C13CC RVA: 0x028C13CC token: 100682641 methodIndex: 51178 delegateWrapperIndex: 0 methodInvoker: 0
        private void DeserializeNodeConnections(int index, System.IO.BinaryReader reader)
        {
            //
            // Disasemble & Code
            // 0x028C13CC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C1E00 (42737152), len: 692  VirtAddr: 0x028C1E00 RVA: 0x028C1E00 token: 100682642 methodIndex: 51179 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeEditorSettings(Pathfinding.GraphEditorBase[] graphEditors)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_6;
            //  | 
            object val_7;
            // 0x028C1E00: STP x28, x27, [sp, #-0x60]! | stack[1152921513280595344] = ???;  stack[1152921513280595352] = ???;  //  dest_result_addr=1152921513280595344 |  dest_result_addr=1152921513280595352
            // 0x028C1E04: STP x26, x25, [sp, #0x10]  | stack[1152921513280595360] = ???;  stack[1152921513280595368] = ???;  //  dest_result_addr=1152921513280595360 |  dest_result_addr=1152921513280595368
            // 0x028C1E08: STP x24, x23, [sp, #0x20]  | stack[1152921513280595376] = ???;  stack[1152921513280595384] = ???;  //  dest_result_addr=1152921513280595376 |  dest_result_addr=1152921513280595384
            // 0x028C1E0C: STP x22, x21, [sp, #0x30]  | stack[1152921513280595392] = ???;  stack[1152921513280595400] = ???;  //  dest_result_addr=1152921513280595392 |  dest_result_addr=1152921513280595400
            // 0x028C1E10: STP x20, x19, [sp, #0x40]  | stack[1152921513280595408] = ???;  stack[1152921513280595416] = ???;  //  dest_result_addr=1152921513280595408 |  dest_result_addr=1152921513280595416
            // 0x028C1E14: STP x29, x30, [sp, #0x50]  | stack[1152921513280595424] = ???;  stack[1152921513280595432] = ???;  //  dest_result_addr=1152921513280595424 |  dest_result_addr=1152921513280595432
            // 0x028C1E18: ADD x29, sp, #0x50         | X29 = (1152921513280595344 + 80) = 1152921513280595424 (0x1000000204FEE5E0);
            // 0x028C1E1C: SUB sp, sp, #0x10          | SP = (1152921513280595344 - 16) = 1152921513280595328 (0x1000000204FEE580);
            // 0x028C1E20: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028C1E24: LDRB w8, [x21, #0x94b]     | W8 = (bool)static_value_037B894B;       
            // 0x028C1E28: MOV x19, x1                | X19 = graphEditors;//m1                 
            // 0x028C1E2C: MOV x20, x0                | X20 = 1152921513280607440 (0x1000000204FF14D0);//ML01
            // 0x028C1E30: TBNZ w8, #0, #0x28c1e4c    | if (static_value_037B894B == true) goto label_0;
            // 0x028C1E34: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x028C1E38: LDR x8, [x8, #0xf0]        | X8 = 0x2B8EDC0;                         
            // 0x028C1E3C: LDR w0, [x8]               | W0 = 0x1230;                            
            // 0x028C1E40: BL #0x2782188              | X0 = sub_2782188( ?? 0x1230, ????);     
            // 0x028C1E44: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C1E48: STRB w8, [x21, #0x94b]     | static_value_037B894B = true;            //  dest_result_addr=58427723
            label_0:
            // 0x028C1E4C: STR xzr, [sp, #8]          | stack[1152921513280595336] = 0x0;        //  dest_result_addr=1152921513280595336
            // 0x028C1E50: CBZ x19, #0x28c2094        | if (graphEditors == null) goto label_2; 
            if(graphEditors == null)
            {
                goto label_2;
            }
            // 0x028C1E54: LDR w8, [x19, #0x18]       | W8 = graphEditors.Length; //P2          
            // 0x028C1E58: CMP w8, #1                 | STATE = COMPARE(graphEditors.Length, 0x1)
            // 0x028C1E5C: B.LT #0x28c2094            | if (graphEditors.Length < 1) goto label_2;
            if(graphEditors.Length < 1)
            {
                goto label_2;
            }
            // 0x028C1E60: ADRP x26, #0x3684000       | X26 = 57163776 (0x3684000);             
            // 0x028C1E64: ADRP x27, #0x3671000       | X27 = 57085952 (0x3671000);             
            // 0x028C1E68: LDR x26, [x26, #0x390]     | X26 = (string**)(1152921513124056064)("graph");
            // 0x028C1E6C: LDR x27, [x27, #0xab0]     | X27 = (string**)(1152921513276205024)("_editor.json");
            // 0x028C1E70: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            label_25:
            // 0x028C1E74: SXTW x28, w9               | X28 = 0 (0x00000000);                   
            // 0x028C1E78: CMP w9, w8                 | STATE = COMPARE(0x0, graphEditors.Length)
            // 0x028C1E7C: B.LO #0x28c1e8c            | if (0 < graphEditors.Length) goto label_3;
            if(0 < graphEditors.Length)
            {
                goto label_3;
            }
            // 0x028C1E80: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1230, ????);     
            // 0x028C1E84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1E88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1230, ????);     
            label_3:
            // 0x028C1E8C: ADD x24, x19, x28, lsl #3  | X24 = graphEditors[0x0]; //PARR1        
            // 0x028C1E90: LDR x8, [x24, #0x20]!      | X8 = graphEditors[0x0][0]               
            Pathfinding.GraphEditorBase val_7 = graphEditors[0];
            // 0x028C1E94: CBZ x8, #0x28c2084         | if (graphEditors[0x0][0] == null) goto label_7;
            if(val_7 == null)
            {
                goto label_7;
            }
            // 0x028C1E98: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x028C1E9C: B #0x28c1ea4               |  goto label_5;                          
            goto label_5;
            label_19:
            // 0x028C1EA0: ADD w23, w23, #1           | W23 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            label_5:
            // 0x028C1EA4: LDR x21, [x20, #0x48]      | X21 = this.graphs; //P2                 
            val_6 = this.graphs;
            // 0x028C1EA8: CBNZ x21, #0x28c1eb0       | if (this.graphs != null) goto label_6;  
            if(val_6 != null)
            {
                goto label_6;
            }
            // 0x028C1EAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1230, ????);     
            label_6:
            // 0x028C1EB0: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1EB4: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1EB8: B.GE #0x28c2084            | if (val_7 >= this.graphs.Length) goto label_7;
            if(val_7 >= this.graphs.Length)
            {
                goto label_7;
            }
            // 0x028C1EBC: LDR x22, [x20, #0x48]      | X22 = this.graphs; //P2                 
            // 0x028C1EC0: CBNZ x22, #0x28c1ec8       | if (this.graphs != null) goto label_8;  
            if(this.graphs != null)
            {
                goto label_8;
            }
            // 0x028C1EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1230, ????);     
            label_8:
            // 0x028C1EC8: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1ECC: SXTW x21, w23              | X21 = 1 (0x00000001);                   
            // 0x028C1ED0: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1ED4: B.LO #0x28c1ee4            | if (val_7 < this.graphs.Length) goto label_9;
            if(val_7 < this.graphs.Length)
            {
                goto label_9;
            }
            // 0x028C1ED8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1230, ????);     
            // 0x028C1EDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1EE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1230, ????);     
            label_9:
            // 0x028C1EE4: ADD x8, x22, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1EE8: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_8 = this.graphs[1];
            // 0x028C1EEC: CBZ x8, #0x28c1ea0         | if (this.graphs[0x1][0] == null) goto label_19;
            if(val_8 == null)
            {
                goto label_19;
            }
            // 0x028C1EF0: LDR w8, [x19, #0x18]       | W8 = graphEditors.Length; //P2          
            // 0x028C1EF4: CMP w28, w8                | STATE = COMPARE(0x0, graphEditors.Length)
            // 0x028C1EF8: B.LO #0x28c1f08            | if (0 < graphEditors.Length) goto label_11;
            if(0 < graphEditors.Length)
            {
                goto label_11;
            }
            // 0x028C1EFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1230, ????);     
            // 0x028C1F00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1F04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1230, ????);     
            label_11:
            // 0x028C1F08: LDR x22, [x24]             | X22 = graphEditors[0x0] + 32;           
            // 0x028C1F0C: CBNZ x22, #0x28c1f14       | if (graphEditors[0x0] + 32 != 0) goto label_12;
            if((graphEditors[0x0] + 32) != 0)
            {
                goto label_12;
            }
            // 0x028C1F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1230, ????);     
            label_12:
            // 0x028C1F14: LDR x22, [x22, #0x10]      | X22 = graphEditors[0x0] + 32 + 16;      
            // 0x028C1F18: LDR x25, [x20, #0x48]      | X25 = this.graphs; //P2                 
            // 0x028C1F1C: CBNZ x25, #0x28c1f24       | if (this.graphs != null) goto label_13; 
            if(this.graphs != null)
            {
                goto label_13;
            }
            // 0x028C1F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1230, ????);     
            label_13:
            // 0x028C1F24: LDR w8, [x25, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x028C1F28: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x028C1F2C: B.LO #0x28c1f3c            | if (val_7 < this.graphs.Length) goto label_14;
            if(val_7 < this.graphs.Length)
            {
                goto label_14;
            }
            // 0x028C1F30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1230, ????);     
            // 0x028C1F34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C1F38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1230, ????);     
            label_14:
            // 0x028C1F3C: ADD x8, x25, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x028C1F40: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_9 = this.graphs[1];
            // 0x028C1F44: CMP x22, x8                | STATE = COMPARE(graphEditors[0x0] + 32 + 16, this.graphs[0x1][0])
            // 0x028C1F48: B.NE #0x28c1ea0            | if (graphEditors[0x0] + 32 + 16 != this.graphs[1]) goto label_19;
            if((graphEditors[0x0] + 32 + 16) != val_9)
            {
                goto label_19;
            }
            // 0x028C1F4C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028C1F50: LDR x21, [x20, #0x28]      | X21 = this.zip; //P2                    
            // 0x028C1F54: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028C1F58: ADD x1, sp, #4             | X1 = (1152921513280595328 + 4) = 1152921513280595332 (0x1000000204FEE584);
            // 0x028C1F5C: STR w23, [sp, #4]          | stack[1152921513280595332] = 0x1;        //  dest_result_addr=1152921513280595332
            // 0x028C1F60: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028C1F64: BL #0x27bc028              | X0 = 1152921513280803280 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x028C1F68: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028C1F6C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028C1F70: MOV x22, x0                | X22 = 1152921513280803280 (0x10000002050211D0);//ML01
            // 0x028C1F74: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028C1F78: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028C1F7C: TBZ w9, #0, #0x28c1f90     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x028C1F80: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028C1F84: CBNZ w9, #0x28c1f90        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x028C1F88: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028C1F8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_17:
            // 0x028C1F90: LDR x1, [x26]              | X1 = "graph";                           
            // 0x028C1F94: LDR x3, [x27]              | X3 = "_editor.json";                    
            // 0x028C1F98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C1F9C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028C1FA0: MOV x2, x22                | X2 = 1152921513280803280 (0x10000002050211D0);//ML01
            // 0x028C1FA4: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_7);
            string val_1 = System.String.Concat(arg0:  0, arg1:  "graph", arg2:  val_7);
            // 0x028C1FA8: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x028C1FAC: CBNZ x21, #0x28c1fb4       | if (this.zip != null) goto label_18;    
            if(this.zip != null)
            {
                goto label_18;
            }
            // 0x028C1FB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_18:
            // 0x028C1FB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C1FB8: MOV x0, x21                | X0 = this.zip;//m1                      
            // 0x028C1FBC: MOV x1, x22                | X1 = val_1;//m1                         
            // 0x028C1FC0: BL #0x197972c              | X0 = this.zip.get_Item(fileName:  val_1);
            Pathfinding.Ionic.Zip.ZipEntry val_2 = this.zip.Item[val_1];
            // 0x028C1FC4: CBZ x0, #0x28c1ea0         | if (val_2 == null) goto label_19;       
            if(val_2 == null)
            {
                goto label_19;
            }
            // 0x028C1FC8: MOV x1, x0                 | X1 = val_2;//m1                         
            // 0x028C1FCC: BL #0x28c0d8c              | X0 = val_2.GetString(entry:  val_2);    
            string val_3 = val_2.GetString(entry:  val_2);
            // 0x028C1FD0: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x028C1FD4: LDR x22, [x20, #0x20]      | X22 = this.readerSettings; //P2         
            // 0x028C1FD8: LDR x8, [x8, #0x828]       | X8 = 1152921504755036160;               
            // 0x028C1FDC: MOV x23, x0                | X23 = val_3;//m1                        
            val_7 = val_3;
            // 0x028C1FE0: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReader);
            // 0x028C1FE4: MOV x0, x8                 | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            Pathfinding.Serialization.JsonFx.JsonReader val_4 = null;
            // 0x028C1FE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonReader), ????);
            // 0x028C1FEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C1FF0: MOV x1, x23                | X1 = val_3;//m1                         
            // 0x028C1FF4: MOV x2, x22                | X2 = this.readerSettings;//m1           
            // 0x028C1FF8: MOV x21, x0                | X21 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C1FFC: BL #0x26d5180              | .ctor(input:  val_7, settings:  this.readerSettings);
            val_4 = new Pathfinding.Serialization.JsonFx.JsonReader(input:  val_7, settings:  this.readerSettings);
            // 0x028C2000: LDR w8, [x19, #0x18]       | W8 = graphEditors.Length; //P2          
            // 0x028C2004: CMP w28, w8                | STATE = COMPARE(0x0, graphEditors.Length)
            // 0x028C2008: B.LO #0x28c2018            | if (0 < graphEditors.Length) goto label_20;
            if(0 < graphEditors.Length)
            {
                goto label_20;
            }
            // 0x028C200C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(input:  val_7, settings:  this.readerSettings), ????);
            // 0x028C2010: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2014: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(input:  val_7, settings:  this.readerSettings), ????);
            label_20:
            // 0x028C2018: LDR x8, [x24]              | X8 = graphEditors[0x0] + 32;            
            // 0x028C201C: STR x8, [sp, #8]           | stack[1152921513280595336] = graphEditors[0x0] + 32;  //  dest_result_addr=1152921513280595336
            Pathfinding.GraphEditorBase val_5 = graphEditors[0x0] + 32;
            // 0x028C2020: CBNZ x21, #0x28c2028       | if ( != 0) goto label_21;               
            if(null != 0)
            {
                goto label_21;
            }
            // 0x028C2024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(input:  val_7, settings:  this.readerSettings), ????);
            label_21:
            // 0x028C2028: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x028C202C: LDR x8, [x8, #0xfe0]       | X8 = 1152921513280582416;               
            // 0x028C2030: ADD x1, sp, #8             | X1 = (1152921513280595328 + 8) = 1152921513280595336 (0x1000000204FEE588);
            // 0x028C2034: MOV x0, x21                | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C2038: LDR x2, [x8]               | X2 = public System.Void Pathfinding.Serialization.JsonFx.JsonReader::PopulateObject<Pathfinding.GraphEditorBase>(ref Pathfinding.GraphEditorBase obj);
            // 0x028C203C: BL #0x10d7400              | PopulateObject<Pathfinding.GraphEditorBase>(obj: ref  Pathfinding.GraphEditorBase val_5 = graphEditors[0x0] + 32);
            PopulateObject<Pathfinding.GraphEditorBase>(obj: ref  val_5);
            // 0x028C2040: LDR x21, [sp, #8]          | X21 = graphEditors[0x0] + 32;           
            val_6 = val_5;
            // 0x028C2044: CBZ x21, #0x28c2068        | if (graphEditors[0x0] + 32 == 0) goto label_23;
            if(val_6 == 0)
            {
                goto label_23;
            }
            // 0x028C2048: LDR x8, [x19]              | X8 = typeof(Pathfinding.GraphEditorBase[]);
            // 0x028C204C: MOV x0, x21                | X0 = graphEditors[0x0] + 32;//m1        
            // 0x028C2050: LDR x1, [x8, #0x30]        | X1 = Pathfinding.GraphEditorBase[].__il2cppRuntimeField_element_class;
            // 0x028C2054: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? graphEditors[0x0] + 32, ????);
            // 0x028C2058: CBNZ x0, #0x28c2068        | if (graphEditors[0x0] + 32 != 0) goto label_23;
            if(val_6 != 0)
            {
                goto label_23;
            }
            // 0x028C205C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? graphEditors[0x0] + 32, ????);
            // 0x028C2060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C2064: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? graphEditors[0x0] + 32, ????);
            label_23:
            // 0x028C2068: LDR w8, [x19, #0x18]       | W8 = graphEditors.Length; //P2          
            // 0x028C206C: CMP w28, w8                | STATE = COMPARE(0x0, graphEditors.Length)
            // 0x028C2070: B.LO #0x28c2080            | if (0 < graphEditors.Length) goto label_24;
            if(0 < graphEditors.Length)
            {
                goto label_24;
            }
            // 0x028C2074: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? graphEditors[0x0] + 32, ????);
            // 0x028C2078: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C207C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? graphEditors[0x0] + 32, ????);
            label_24:
            // 0x028C2080: STR x21, [x24]             | mem2[0] = graphEditors[0x0] + 32;        //  dest_result_addr=0
            mem2[0] = val_6;
            label_7:
            // 0x028C2084: LDR w8, [x19, #0x18]       | W8 = graphEditors.Length; //P2          
            // 0x028C2088: ADD w9, w28, #1            | W9 = (0 + 1);                           
            var val_6 = 0 + 1;
            // 0x028C208C: CMP w9, w8                 | STATE = COMPARE((0 + 1), graphEditors.Length)
            // 0x028C2090: B.LT #0x28c1e74            | if (val_6 < graphEditors.Length) goto label_25;
            if(val_6 < graphEditors.Length)
            {
                goto label_25;
            }
            label_2:
            // 0x028C2094: SUB sp, x29, #0x50         | SP = (1152921513280595424 - 80) = 1152921513280595344 (0x1000000204FEE590);
            // 0x028C2098: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028C209C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028C20A0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028C20A4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028C20A8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028C20AC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028C20B0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028C0D8C (42732940), len: 256  VirtAddr: 0x028C0D8C RVA: 0x028C0D8C token: 100682643 methodIndex: 51180 delegateWrapperIndex: 0 methodInvoker: 0
        private string GetString(Pathfinding.Ionic.Zip.ZipEntry entry)
        {
            //
            // Disasemble & Code
            // 0x028C0D8C: STP x22, x21, [sp, #-0x30]! | stack[1152921513280895808] = ???;  stack[1152921513280895816] = ???;  //  dest_result_addr=1152921513280895808 |  dest_result_addr=1152921513280895816
            // 0x028C0D90: STP x20, x19, [sp, #0x10]  | stack[1152921513280895824] = ???;  stack[1152921513280895832] = ???;  //  dest_result_addr=1152921513280895824 |  dest_result_addr=1152921513280895832
            // 0x028C0D94: STP x29, x30, [sp, #0x20]  | stack[1152921513280895840] = ???;  stack[1152921513280895848] = ???;  //  dest_result_addr=1152921513280895840 |  dest_result_addr=1152921513280895848
            // 0x028C0D98: ADD x29, sp, #0x20         | X29 = (1152921513280895808 + 32) = 1152921513280895840 (0x1000000205037B60);
            // 0x028C0D9C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028C0DA0: LDRB w8, [x19, #0x94c]     | W8 = (bool)static_value_037B894C;       
            // 0x028C0DA4: MOV x20, x1                | X20 = entry;//m1                        
            // 0x028C0DA8: TBNZ w8, #0, #0x28c0dc4    | if (static_value_037B894C == true) goto label_0;
            // 0x028C0DAC: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x028C0DB0: LDR x8, [x8, #0xd40]       | X8 = 0x2B8EDD8;                         
            // 0x028C0DB4: LDR w0, [x8]               | W0 = 0x1236;                            
            // 0x028C0DB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1236, ????);     
            // 0x028C0DBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C0DC0: STRB w8, [x19, #0x94c]     | static_value_037B894C = true;            //  dest_result_addr=58427724
            label_0:
            // 0x028C0DC4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028C0DC8: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x028C0DCC: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
            System.IO.MemoryStream val_1 = null;
            // 0x028C0DD0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x028C0DD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0DD8: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C0DDC: BL #0x1e762f4              | .ctor();                                
            val_1 = new System.IO.MemoryStream();
            // 0x028C0DE0: CBNZ x20, #0x28c0de8       | if (entry != null) goto label_1;        
            if(entry != null)
            {
                goto label_1;
            }
            // 0x028C0DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x028C0DE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0DEC: MOV x0, x20                | X0 = entry;//m1                         
            // 0x028C0DF0: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C0DF4: BL #0x1977030              | entry.Extract(stream:  val_1);          
            entry.Extract(stream:  val_1);
            // 0x028C0DF8: CBNZ x19, #0x28c0e00       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x028C0DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? entry, ????);      
            label_2:
            // 0x028C0E00: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C0E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0E08: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C0E0C: LDP x9, x2, [x8, #0x1b0]   |                                          //  not_find_field!1:432 |  not_find_field!1:440
            // 0x028C0E10: BLR x9                     | X0 = mem[null + 432]();                 
            // 0x028C0E14: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x028C0E18: LDR x8, [x8, #0x6a8]       | X8 = 1152921504622501888;               
            // 0x028C0E1C: LDR x0, [x8]               | X0 = typeof(System.IO.StreamReader);    
            System.IO.StreamReader val_2 = null;
            // 0x028C0E20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.StreamReader), ????);
            // 0x028C0E24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C0E28: MOV x1, x19                | X1 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C0E2C: MOV x20, x0                | X20 = 1152921504622501888 (0x1000000000EEE000);//ML01
            // 0x028C0E30: BL #0x1e7d4a0              | .ctor(stream:  val_1);                  
            val_2 = new System.IO.StreamReader(stream:  val_1);
            // 0x028C0E34: CBNZ x20, #0x28c0e3c       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x028C0E38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(stream:  val_1), ????);
            label_3:
            // 0x028C0E3C: LDR x8, [x20]              | X8 = ;                                  
            // 0x028C0E40: MOV x0, x20                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
            // 0x028C0E44: LDP x9, x1, [x8, #0x1c0]   |                                          //  not_find_field!1:448 |  not_find_field!1:456
            // 0x028C0E48: BLR x9                     | X0 = mem[null + 448]();                 
            // 0x028C0E4C: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C0E50: MOV x21, x0                | X21 = 1152921504622501888 (0x1000000000EEE000);//ML01
            // 0x028C0E54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0E58: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x028C0E5C: LDP x9, x2, [x8, #0x1b0]   |                                          //  not_find_field!1:432 |  not_find_field!1:440
            // 0x028C0E60: BLR x9                     | X0 = mem[null + 432]();                 
            // 0x028C0E64: CBNZ x20, #0x28c0e6c       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x028C0E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.MemoryStream), ????);
            label_4:
            // 0x028C0E6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0E70: MOV x0, x20                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
            // 0x028C0E74: BL #0x16f5ad0              | Dispose();                              
            Dispose();
            // 0x028C0E78: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C0E7C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C0E80: MOV x0, x21                | X0 = 1152921504622501888 (0x1000000000EEE000);//ML01
            // 0x028C0E84: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C0E88: RET                        |  return (System.String)typeof(System.IO.StreamReader);
            return (string)val_2;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028C0244 (42730052), len: 424  VirtAddr: 0x028C0244 RVA: 0x028C0244 token: 100682644 methodIndex: 51181 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.Serialization.GraphMeta DeserializeMeta(Pathfinding.Ionic.Zip.ZipEntry entry)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_9;
            // 0x028C0244: STP x22, x21, [sp, #-0x30]! | stack[1152921513281033552] = ???;  stack[1152921513281033560] = ???;  //  dest_result_addr=1152921513281033552 |  dest_result_addr=1152921513281033560
            // 0x028C0248: STP x20, x19, [sp, #0x10]  | stack[1152921513281033568] = ???;  stack[1152921513281033576] = ???;  //  dest_result_addr=1152921513281033568 |  dest_result_addr=1152921513281033576
            // 0x028C024C: STP x29, x30, [sp, #0x20]  | stack[1152921513281033584] = ???;  stack[1152921513281033592] = ???;  //  dest_result_addr=1152921513281033584 |  dest_result_addr=1152921513281033592
            // 0x028C0250: ADD x29, sp, #0x20         | X29 = (1152921513281033552 + 32) = 1152921513281033584 (0x1000000205059570);
            // 0x028C0254: SUB sp, sp, #0x10          | SP = (1152921513281033552 - 16) = 1152921513281033536 (0x1000000205059540);
            // 0x028C0258: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028C025C: LDRB w8, [x21, #0x94d]     | W8 = (bool)static_value_037B894D;       
            // 0x028C0260: MOV x20, x1                | X20 = entry;//m1                        
            // 0x028C0264: MOV x19, x0                | X19 = 1152921513281045600 (0x100000020505C460);//ML01
            // 0x028C0268: TBNZ w8, #0, #0x28c0284    | if (static_value_037B894D == true) goto label_0;
            // 0x028C026C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x028C0270: LDR x8, [x8, #0x9d0]       | X8 = 0x2B8EDCC;                         
            // 0x028C0274: LDR w0, [x8]               | W0 = 0x1233;                            
            // 0x028C0278: BL #0x2782188              | X0 = sub_2782188( ?? 0x1233, ????);     
            // 0x028C027C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C0280: STRB w8, [x21, #0x94d]     | static_value_037B894D = true;            //  dest_result_addr=58427725
            label_0:
            // 0x028C0284: CBZ x20, #0x28c0398        | if (entry == null) goto label_1;        
            if(entry == null)
            {
                goto label_1;
            }
            // 0x028C0288: MOV x1, x20                | X1 = entry;//m1                         
            // 0x028C028C: BL #0x28c0d8c              | X0 = this.GetString(entry:  entry);     
            string val_1 = this.GetString(entry:  entry);
            // 0x028C0290: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x028C0294: LDR x20, [x19, #0x20]      | X20 = this.readerSettings; //P2         
            // 0x028C0298: LDR x8, [x8, #0x828]       | X8 = 1152921504755036160;               
            // 0x028C029C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028C02A0: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.JsonFx.JsonReader);
            // 0x028C02A4: MOV x0, x8                 | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            Pathfinding.Serialization.JsonFx.JsonReader val_2 = null;
            // 0x028C02A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.JsonFx.JsonReader), ????);
            // 0x028C02AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C02B0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028C02B4: MOV x2, x20                | X2 = this.readerSettings;//m1           
            // 0x028C02B8: MOV x19, x0                | X19 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C02BC: BL #0x26d5180              | .ctor(input:  val_1, settings:  this.readerSettings);
            val_2 = new Pathfinding.Serialization.JsonFx.JsonReader(input:  val_1, settings:  this.readerSettings);
            // 0x028C02C0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028C02C4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028C02C8: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x028C02CC: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x028C02D0: LDR x8, [x8, #0xde0]       | X8 = 1152921504842203136;               
            // 0x028C02D4: LDR x20, [x8]              | X20 = typeof(Pathfinding.Serialization.GraphMeta);
            // 0x028C02D8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028C02DC: TBZ w8, #0, #0x28c02ec     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028C02E0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028C02E4: CBNZ w8, #0x28c02ec        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028C02E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028C02EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028C02F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C02F4: MOV x1, x20                | X1 = 1152921504842203136 (0x100000000E074000);//ML01
            // 0x028C02F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028C02FC: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x028C0300: CBNZ x19, #0x28c0308       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x028C0304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_4:
            // 0x028C0308: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C030C: MOV x0, x19                | X0 = 1152921504755036160 (0x1000000008D53000);//ML01
            // 0x028C0310: MOV x1, x20                | X1 = val_3;//m1                         
            // 0x028C0314: BL #0x26d5400              | X0 = Deserialize(type:  val_3);         
            object val_4 = Deserialize(type:  val_3);
            // 0x028C0318: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x028C031C: CBZ x0, #0x28c0380         | if (val_4 == null) goto label_7;        
            if(val_4 == null)
            {
                goto label_7;
            }
            // 0x028C0320: ADRP x9, #0x3642000        | X9 = 56893440 (0x3642000);              
            // 0x028C0324: LDR x9, [x9, #0x960]       | X9 = 1152921504842203136;               
            // 0x028C0328: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028C032C: LDR x1, [x9]               | X1 = typeof(Pathfinding.Serialization.GraphMeta);
            // 0x028C0330: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028C0334: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.Serialization.GraphMeta.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028C0338: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.Serialization.GraphMeta.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028C033C: B.LO #0x28c0358            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.Serialization.GraphMeta.__il2cppRuntimeField_typeHierarchyDepth) goto label_6;
            // 0x028C0340: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028C0344: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Serialization.GraphMeta.__il2c
            // 0x028C0348: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Serialization.GraphMeta.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028C034C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Serialization.GraphMeta.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.Serialization.GraphMeta))
            // 0x028C0350: MOV x2, x0                 | X2 = val_4;//m1                         
            val_9 = val_4;
            // 0x028C0354: B.EQ #0x28c0380            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.Serialization.GraphMeta.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_7;
            label_6:
            // 0x028C0358: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028C035C: ADD x8, sp, #8             | X8 = (1152921513281033536 + 8) = 1152921513281033544 (0x1000000205059548);
            // 0x028C0360: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028C0364: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921513281021600]
            // 0x028C0368: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x028C036C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C0370: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x028C0374: ADD x0, sp, #8             | X0 = (1152921513281033536 + 8) = 1152921513281033544 (0x1000000205059548);
            // 0x028C0378: BL #0x299a140              | 
            // 0x028C037C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_9 = 0;
            label_7:
            // 0x028C0380: MOV x0, x2                 | X0 = 0 (0x0);//ML01                     
            // 0x028C0384: SUB sp, x29, #0x20         | SP = (1152921513281033584 - 32) = 1152921513281033552 (0x1000000205059550);
            // 0x028C0388: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C038C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C0390: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C0394: RET                        |  return (Pathfinding.Serialization.GraphMeta)null;
            return (Pathfinding.Serialization.GraphMeta)val_9;
            //  |  // // {name=val_0, type=Pathfinding.Serialization.GraphMeta, size=8, nGRN=0 }
            label_1:
            // 0x028C0398: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028C039C: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028C03A0: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_7 = null;
            // 0x028C03A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028C03A8: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x028C03AC: LDR x8, [x8, #0x298]       | X8 = (string**)(1152921513281020432)("No metadata found in serialized data.");
            // 0x028C03B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028C03B4: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028C03B8: LDR x1, [x8]               | X1 = "No metadata found in serialized data.";
            // 0x028C03BC: BL #0x1c32b48              | .ctor(message:  "No metadata found in serialized data.");
            val_7 = new System.Exception(message:  "No metadata found in serialized data.");
            // 0x028C03C0: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x028C03C4: LDR x8, [x8, #0xfa8]       | X8 = 1152921513281020576;               
            // 0x028C03C8: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028C03CC: LDR x1, [x8]               | X1 = Pathfinding.Serialization.GraphMeta Pathfinding.Serialization.AstarSerializer::DeserializeMeta(Pathfinding.Ionic.Zip.ZipEntry entry);
            // 0x028C03D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028C03D4: BL #0x28abec4              | X0 = MoveNext();                        
            bool val_8 = MoveNext();
            // 0x028C03D8: MOV x19, x0                | X19 = val_8;//m1                        
            // 0x028C03DC: ADD x0, sp, #8             | X0 = (1152921513281033536 + 8) = 1152921513281033544 (0x1000000205059548);
            // 0x028C03E0: BL #0x299a140              | 
            // 0x028C03E4: MOV x0, x19                | X0 = val_8;//m1                         
            // 0x028C03E8: BL #0x980800               | X0 = sub_980800( ?? val_8, ????);       
        
        }
        //
        // Offset in libil2cpp.so: 0x028C20B4 (42737844), len: 332  VirtAddr: 0x028C20B4 RVA: 0x028C20B4 token: 100682645 methodIndex: 51182 delegateWrapperIndex: 0 methodInvoker: 0
        public static void SaveToFile(string path, byte[] data)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x028C20B4: STP x22, x21, [sp, #-0x30]! | stack[1152921513281206992] = ???;  stack[1152921513281207000] = ???;  //  dest_result_addr=1152921513281206992 |  dest_result_addr=1152921513281207000
            // 0x028C20B8: STP x20, x19, [sp, #0x10]  | stack[1152921513281207008] = ???;  stack[1152921513281207016] = ???;  //  dest_result_addr=1152921513281207008 |  dest_result_addr=1152921513281207016
            // 0x028C20BC: STP x29, x30, [sp, #0x20]  | stack[1152921513281207024] = ???;  stack[1152921513281207032] = ???;  //  dest_result_addr=1152921513281207024 |  dest_result_addr=1152921513281207032
            // 0x028C20C0: ADD x29, sp, #0x20         | X29 = (1152921513281206992 + 32) = 1152921513281207024 (0x1000000205083AF0);
            // 0x028C20C4: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028C20C8: LDRB w8, [x19, #0x94e]     | W8 = (bool)static_value_037B894E;       
            // 0x028C20CC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x028C20D0: MOV x21, x1                | X21 = data;//m1                         
            // 0x028C20D4: TBNZ w8, #0, #0x28c20f0    | if (static_value_037B894E == true) goto label_0;
            // 0x028C20D8: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x028C20DC: LDR x8, [x8, #0x150]       | X8 = 0x2B8EDEC;                         
            // 0x028C20E0: LDR w0, [x8]               | W0 = 0x123B;                            
            // 0x028C20E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x123B, ????);     
            // 0x028C20E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C20EC: STRB w8, [x19, #0x94e]     | static_value_037B894E = true;            //  dest_result_addr=58427726
            label_0:
            // 0x028C20F0: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028C20F4: LDR x8, [x8, #0x558]       | X8 = 1152921504621490176;               
            // 0x028C20F8: LDR x0, [x8]               | X0 = typeof(System.IO.FileStream);      
            System.IO.FileStream val_1 = null;
            // 0x028C20FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileStream), ????);
            // 0x028C2100: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C2104: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028C2108: MOV x1, x21                | X1 = data;//m1                          
            // 0x028C210C: MOV x19, x0                | X19 = 1152921504621490176 (0x1000000000DF7000);//ML01
            val_8 = val_1;
            // 0x028C2110: BL #0x1e7389c              | .ctor(path:  data, mode:  2);           
            val_1 = new System.IO.FileStream(path:  data, mode:  2);
            // 0x028C2114: CBNZ x20, #0x28c211c       | if (X2 != 0) goto label_1;              
            if(X2 != 0)
            {
                goto label_1;
            }
            // 0x028C2118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(path:  data, mode:  2), ????);
            label_1:
            // 0x028C211C: CBNZ x19, #0x28c2124       | if ( != 0) goto label_2;                
            if(null != 0)
            {
                goto label_2;
            }
            // 0x028C2120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(path:  data, mode:  2), ????);
            label_2:
            // 0x028C2124: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C2128: LDR w3, [x20, #0x18]       | W3 = X2 + 24;                           
            // 0x028C212C: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
            // 0x028C2130: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
            // 0x028C2134: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C2138: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C213C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x028C2140: BLR x9                     | X0 = mem[null + 608]();                 
            // 0x028C2144: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x028C2148: MOVZ w21, #0x25            | W21 = 37 (0x25);//ML01                  
            val_9 = 37;
            label_10:
            // 0x028C214C: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x028C2150: LDR x8, [x19]              | X8 = ;                                  
            System.IO.FileStream val_10 = null;
            // 0x028C2154: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x028C2158: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x028C215C: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x028C2160: CBZ x9, #0x28c218c         | if (mem[null + 258] == 0) goto label_3; 
            if((mem[null + 258]) == 0)
            {
                goto label_3;
            }
            // 0x028C2164: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_8 = mem[null + 152];
            // 0x028C2168: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x028C216C: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_8 = val_8 + 8;
            label_5:
            // 0x028C2170: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x028C2174: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x028C2178: B.EQ #0x28c219c            | if ((mem[null + 152] + 8) + -8 == null) goto label_4;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_4;
            }
            // 0x028C217C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x028C2180: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_8 = val_8 + 16;
            // 0x028C2184: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x028C2188: B.LO #0x28c2170            | if (0 < mem[null + 258]) goto label_5;  
            if(val_9 < (mem[null + 258]))
            {
                goto label_5;
            }
            label_3:
            // 0x028C218C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C2190: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            val_10 = val_8;
            // 0x028C2194: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.FileStream), ????);
            // 0x028C2198: B #0x28c21a8               |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x028C219C: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x028C21A0: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_10 = val_10 + (((mem[null + 152] + 8)) << 4);
            // 0x028C21A4: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_6:
            // 0x028C21A8: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.FileStream.__il2cppRuntimeField_gc_desc; //  | 
            // 0x028C21AC: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C21B0: BLR x8                     | X0 = x8();                              
            label_9:
            // 0x028C21B4: CBZ x20, #0x28c21d8        | if (0x0 == 0) goto label_8;             
            if(0 == 0)
            {
                goto label_8;
            }
            // 0x028C21B8: CMP w21, #0x25             | STATE = COMPARE(0x25, 0x25)             
            // 0x028C21BC: B.EQ #0x28c21d8            | if (0x25 == 0x25) goto label_8;         
            if(37 == 37)
            {
                goto label_8;
            }
            // 0x028C21C0: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x028C21C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C21C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_8 = ???;
            // 0x028C21CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C21D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_9 = ???;
            // 0x028C21D4: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_8:
            // 0x028C21D8: LDP x29, x30, [sp, #0x20]  | X29 = val_2; X30 = val_3;                //  find_add[1152921513281195040] |  find_add[1152921513281195040]
            // 0x028C21DC: LDP x20, x19, [sp, #0x10]  | X20 = val_4; X19 = val_5;                //  find_add[1152921513281195040] |  find_add[1152921513281195040]
            // 0x028C21E0: LDP x22, x21, [sp], #0x30  | X22 = val_6; X21 = val_7;                //  find_add[1152921513281195040] |  find_add[1152921513281195040]
            // 0x028C21E4: RET                        |  return;                                
            return;
            // 0x028C21E8: BL #0x981060               | 
            // 0x028C21EC: LDR x20, [x0]              | 
            // 0x028C21F0: BL #0x980920               | 
            // 0x028C21F4: MOV w21, wzr               | 
            // 0x028C21F8: CBZ x19, #0x28c21b4        | 
            // 0x028C21FC: B #0x28c214c               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028C2200 (42738176), len: 388  VirtAddr: 0x028C2200 RVA: 0x028C2200 token: 100682646 methodIndex: 51183 delegateWrapperIndex: 0 methodInvoker: 0
        public static byte[] LoadFromFile(string path)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028C2200: STP x22, x21, [sp, #-0x30]! | stack[1152921513281364048] = ???;  stack[1152921513281364056] = ???;  //  dest_result_addr=1152921513281364048 |  dest_result_addr=1152921513281364056
            // 0x028C2204: STP x20, x19, [sp, #0x10]  | stack[1152921513281364064] = ???;  stack[1152921513281364072] = ???;  //  dest_result_addr=1152921513281364064 |  dest_result_addr=1152921513281364072
            // 0x028C2208: STP x29, x30, [sp, #0x20]  | stack[1152921513281364080] = ???;  stack[1152921513281364088] = ???;  //  dest_result_addr=1152921513281364080 |  dest_result_addr=1152921513281364088
            // 0x028C220C: ADD x29, sp, #0x20         | X29 = (1152921513281364048 + 32) = 1152921513281364080 (0x10000002050AA070);
            // 0x028C2210: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028C2214: LDRB w8, [x19, #0x94f]     | W8 = (bool)static_value_037B894F;       
            // 0x028C2218: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028C221C: TBNZ w8, #0, #0x28c2238    | if (static_value_037B894F == true) goto label_0;
            // 0x028C2220: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x028C2224: LDR x8, [x8, #0x4d8]       | X8 = 0x2B8EDE0;                         
            // 0x028C2228: LDR w0, [x8]               | W0 = 0x1238;                            
            // 0x028C222C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1238, ????);     
            // 0x028C2230: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C2234: STRB w8, [x19, #0x94f]     | static_value_037B894F = true;            //  dest_result_addr=58427727
            label_0:
            // 0x028C2238: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028C223C: LDR x8, [x8, #0x558]       | X8 = 1152921504621490176;               
            // 0x028C2240: LDR x0, [x8]               | X0 = typeof(System.IO.FileStream);      
            System.IO.FileStream val_1 = null;
            // 0x028C2244: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileStream), ????);
            // 0x028C2248: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028C224C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028C2250: MOV x1, x20                | X1 = X1;//m1                            
            // 0x028C2254: MOV x19, x0                | X19 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C2258: BL #0x1e7389c              | .ctor(path:  X1, mode:  3);             
            val_1 = new System.IO.FileStream(path:  X1, mode:  3);
            // 0x028C225C: CBNZ x19, #0x28c2264       | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x028C2260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(path:  X1, mode:  3), ????);
            label_1:
            // 0x028C2264: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C2268: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x028C226C: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C2270: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x028C2274: MOV x20, x0                | X20 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C2278: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028C227C: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x028C2280: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
            // 0x028C2284: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028C2288: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x028C228C: AND x1, x20, #0xffffffff   | X1 = (val_1 & 4294967295) = 14643200 (0x00DF7000);
            // 0x028C2290: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028C2294: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x028C2298: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028C229C: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C22A0: LDP x9, x1, [x8, #0x190]   |                                          //  not_find_field!1:400 |  not_find_field!1:408
            // 0x028C22A4: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C22A8: BLR x9                     | X0 = mem[null + 400]();                 
            // 0x028C22AC: MOV x3, x0                 | X3 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C22B0: LDR x8, [x19]              | X8 = ;                                  
            // 0x028C22B4: LDR x9, [x8, #0x220]       |  //  not_find_field!1:544
            // 0x028C22B8: LDR x4, [x8, #0x228]       |  //  not_find_field!1:552
            // 0x028C22BC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C22C0: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C22C4: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028C22C8: BLR x9                     | X0 = mem[null + 544]();                 
            // 0x028C22CC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x028C22D0: MOVZ w22, #0x39            | W22 = 57 (0x39);//ML01                  
            label_9:
            // 0x028C22D4: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x028C22D8: LDR x8, [x19]              | X8 = ;                                  
            System.IO.FileStream val_4 = null;
            // 0x028C22DC: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x028C22E0: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x028C22E4: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x028C22E8: CBZ x9, #0x28c2314         | if (mem[null + 258] == 0) goto label_2; 
            if((mem[null + 258]) == 0)
            {
                goto label_2;
            }
            // 0x028C22EC: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_2 = mem[null + 152];
            // 0x028C22F0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x028C22F4: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_2 = val_2 + 8;
            label_4:
            // 0x028C22F8: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x028C22FC: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x028C2300: B.EQ #0x28c2324            | if ((mem[null + 152] + 8) + -8 == null) goto label_3;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_3;
            }
            // 0x028C2304: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x028C2308: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_2 = val_2 + 16;
            // 0x028C230C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x028C2310: B.LO #0x28c22f8            | if (0 < mem[null + 258]) goto label_4;  
            if(val_3 < (mem[null + 258]))
            {
                goto label_4;
            }
            label_2:
            // 0x028C2314: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028C2318: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            val_2 = val_1;
            // 0x028C231C: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.FileStream), ????);
            // 0x028C2320: B #0x28c2330               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028C2324: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x028C2328: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_4 = val_4 + (((mem[null + 152] + 8)) << 4);
            // 0x028C232C: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_5:
            // 0x028C2330: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.FileStream.__il2cppRuntimeField_gc_desc; //  | 
            // 0x028C2334: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x028C2338: BLR x8                     | X0 = x8();                              
            label_8:
            // 0x028C233C: CBZ x21, #0x28c2354        | if (0x0 == 0) goto label_7;             
            if(0 == 0)
            {
                goto label_7;
            }
            // 0x028C2340: CMP w22, #0x39             | STATE = COMPARE(0x39, 0x39)             
            // 0x028C2344: B.EQ #0x28c2354            | if (0x39 == 0x39) goto label_7;         
            if(57 == 57)
            {
                goto label_7;
            }
            // 0x028C2348: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C234C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028C2350: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_7:
            // 0x028C2354: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x028C2358: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028C235C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028C2360: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028C2364: RET                        |  return (System.Byte[])typeof(System.Byte[]);
            return (System.Byte[])null;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
            // 0x028C2368: BL #0x981060               | 
            // 0x028C236C: LDR x21, [x0]              | 
            // 0x028C2370: BL #0x980920               | 
            // 0x028C2374: MOV x20, xzr               | 
            // 0x028C2378: MOV w22, wzr               | 
            // 0x028C237C: CBZ x19, #0x28c233c        | 
            // 0x028C2380: B #0x28c22d4               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028C2384 (42738564), len: 108  VirtAddr: 0x028C2384 RVA: 0x028C2384 token: 100682647 methodIndex: 51184 delegateWrapperIndex: 0 methodInvoker: 0
        private static AstarSerializer()
        {
            //
            // Disasemble & Code
            // 0x028C2384: STP x20, x19, [sp, #-0x20]! | stack[1152921513281480160] = ???;  stack[1152921513281480168] = ???;  //  dest_result_addr=1152921513281480160 |  dest_result_addr=1152921513281480168
            // 0x028C2388: STP x29, x30, [sp, #0x10]  | stack[1152921513281480176] = ???;  stack[1152921513281480184] = ???;  //  dest_result_addr=1152921513281480176 |  dest_result_addr=1152921513281480184
            // 0x028C238C: ADD x29, sp, #0x10         | X29 = (1152921513281480160 + 16) = 1152921513281480176 (0x10000002050C65F0);
            // 0x028C2390: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028C2394: LDRB w8, [x19, #0x950]     | W8 = (bool)static_value_037B8950;       
            // 0x028C2398: TBNZ w8, #0, #0x28c23b4    | if (static_value_037B8950 == true) goto label_0;
            // 0x028C239C: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x028C23A0: LDR x8, [x8, #0x568]       | X8 = 0x2B8EDAC;                         
            // 0x028C23A4: LDR w0, [x8]               | W0 = 0x122B;                            
            // 0x028C23A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x122B, ????);     
            // 0x028C23AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028C23B0: STRB w8, [x19, #0x950]     | static_value_037B8950 = true;            //  dest_result_addr=58427728
            label_0:
            // 0x028C23B4: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x028C23B8: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x028C23BC: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x028C23C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x028C23C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028C23C8: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x028C23CC: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x028C23D0: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x028C23D4: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x028C23D8: LDR x8, [x8]               | X8 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x028C23DC: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.Serialization.AstarSerializer.__il2cppRuntimeField_static_fields;
            // 0x028C23E0: STR x19, [x8]              | Pathfinding.Serialization.AstarSerializer._stringBuilder = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921504841834496
            Pathfinding.Serialization.AstarSerializer._stringBuilder = val_1;
            // 0x028C23E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028C23E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028C23EC: RET                        |  return;                                
            return;
        
        }
    
    }

}
