using UnityEngine;

namespace Mihua.Assets
{
    public class AssetUtil : IZUpdate
    {
        // Fields
        public const string NETWORK_CHANGE = "NETWORK_CHANGE";
        private UnityEngine.NetworkReachability network; //  0x00000010
        private static System.Collections.Generic.Dictionary<string, FileInfoRes> assetsDic; // static_offset: 0x00000000
        private static System.Text.StringBuilder sb; // static_offset: 0x00000008
        
        // Properties
        public static bool IsWifiNetwork { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AB6FF8 (11235320), len: 52  VirtAddr: 0x00AB6FF8 RVA: 0x00AB6FF8 token: 100693245 methodIndex: 47007 delegateWrapperIndex: 0 methodInvoker: 0
        private AssetUtil()
        {
            //
            // Disasemble & Code
            // 0x00AB6FF8: STP x20, x19, [sp, #-0x20]! | stack[1152921514958538224] = ???;  stack[1152921514958538232] = ???;  //  dest_result_addr=1152921514958538224 |  dest_result_addr=1152921514958538232
            // 0x00AB6FFC: STP x29, x30, [sp, #0x10]  | stack[1152921514958538240] = ???;  stack[1152921514958538248] = ???;  //  dest_result_addr=1152921514958538240 |  dest_result_addr=1152921514958538248
            // 0x00AB7000: ADD x29, sp, #0x10         | X29 = (1152921514958538224 + 16) = 1152921514958538240 (0x1000000269024600);
            // 0x00AB7004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7008: MOV x19, x0                | X19 = 1152921514958550256 (0x10000002690274F0);//ML01
            // 0x00AB700C: BL #0x16f59f0              | this..ctor();                           
            // 0x00AB7010: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7018: BL #0x20c84c4              | X0 = UnityEngine.Application.get_internetReachability();
            UnityEngine.NetworkReachability val_1 = UnityEngine.Application.internetReachability;
            // 0x00AB701C: STR w0, [x19, #0x10]       | this.network = val_1;                    //  dest_result_addr=1152921514958550272
            this.network = val_1;
            // 0x00AB7020: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7024: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB7028: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB702C (11235372), len: 236  VirtAddr: 0x00AB702C RVA: 0x00AB702C token: 100693246 methodIndex: 47008 delegateWrapperIndex: 0 methodInvoker: 0
        private static AssetUtil()
        {
            //
            // Disasemble & Code
            // 0x00AB702C: STP x20, x19, [sp, #-0x20]! | stack[1152921514958659440] = ???;  stack[1152921514958659448] = ???;  //  dest_result_addr=1152921514958659440 |  dest_result_addr=1152921514958659448
            // 0x00AB7030: STP x29, x30, [sp, #0x10]  | stack[1152921514958659456] = ???;  stack[1152921514958659464] = ???;  //  dest_result_addr=1152921514958659456 |  dest_result_addr=1152921514958659464
            // 0x00AB7034: ADD x29, sp, #0x10         | X29 = (1152921514958659440 + 16) = 1152921514958659456 (0x1000000269041F80);
            // 0x00AB7038: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB703C: LDRB w8, [x19, #0x413]     | W8 = (bool)static_value_03733413;       
            // 0x00AB7040: TBNZ w8, #0, #0xab705c     | if (static_value_03733413 == true) goto label_0;
            // 0x00AB7044: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x00AB7048: LDR x8, [x8, #0xc18]       | X8 = 0x2B8EBC0;                         
            // 0x00AB704C: LDR w0, [x8]               | W0 = 0x11B0;                            
            // 0x00AB7050: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B0, ????);     
            // 0x00AB7054: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB7058: STRB w8, [x19, #0x413]     | static_value_03733413 = true;            //  dest_result_addr=57881619
            label_0:
            // 0x00AB705C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB7060: LDR x8, [x8, #0x180]       | X8 = 1152921504615792640;               
            // 0x00AB7064: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, FileInfoRes> val_1 = null;
            // 0x00AB7068: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB706C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00AB7070: LDR x8, [x8, #0xa0]        | X8 = 1152921514958642352;               
            // 0x00AB7074: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB7078: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::.ctor();
            // 0x00AB707C: BL #0x23fb0c4              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, FileInfoRes>();
            // 0x00AB7080: ADRP x20, #0x3671000       | X20 = 57085952 (0x3671000);             
            // 0x00AB7084: LDR x20, [x20, #0xf30]     | X20 = 1152921504903544832;              
            // 0x00AB7088: LDR x8, [x20]              | X8 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB708C: LDR x8, [x8, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB7090: STR x19, [x8]              | Mihua.Assets.AssetUtil.assetsDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903548928
            Mihua.Assets.AssetUtil.assetsDic = val_1;
            // 0x00AB7094: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00AB7098: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00AB709C: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_2 = null;
            // 0x00AB70A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00AB70A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB70A8: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00AB70AC: BL #0x1b5a30c              | .ctor();                                
            val_2 = new System.Text.StringBuilder();
            // 0x00AB70B0: LDR x8, [x20]              | X8 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB70B4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB70B8: STR x19, [x8, #8]          | Mihua.Assets.AssetUtil.sb = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921504903548936
            Mihua.Assets.AssetUtil.sb = val_2;
            // 0x00AB70BC: LDR x0, [x20]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            object val_3 = null;
            // 0x00AB70C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Assets.AssetUtil), ????);
            // 0x00AB70C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB70C8: MOV x19, x0                | X19 = 1152921504903544832 (0x1000000011AF4000);//ML01
            // 0x00AB70CC: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x00AB70D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB70D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB70D8: BL #0x20c84c4              | X0 = UnityEngine.Application.get_internetReachability();
            UnityEngine.NetworkReachability val_4 = UnityEngine.Application.internetReachability;
            // 0x00AB70DC: STR w0, [x19, #0x10]       | typeof(Mihua.Assets.AssetUtil).__il2cppRuntimeField_10 = val_4;  //  dest_result_addr=1152921504903544848
            typeof(Mihua.Assets.AssetUtil).__il2cppRuntimeField_10 = val_4;
            // 0x00AB70E0: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00AB70E4: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
            // 0x00AB70E8: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
            // 0x00AB70EC: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
            // 0x00AB70F0: TBZ w8, #0, #0xab7100      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB70F4: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
            // 0x00AB70F8: CBNZ w8, #0xab7100         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB70FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
            label_2:
            // 0x00AB7100: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7104: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB710C: MOV x1, x19                | X1 = 1152921504903544832 (0x1000000011AF4000);//ML01
            // 0x00AB7110: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB7114: B #0xb14d7c                | AllUpdate.AddUpdate(update:  0); return;
            AllUpdate.AddUpdate(update:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB7118 (11235608), len: 200  VirtAddr: 0x00AB7118 RVA: 0x00AB7118 token: 100693247 methodIndex: 47009 delegateWrapperIndex: 0 methodInvoker: 0
        public void ZUpdate()
        {
            //
            // Disasemble & Code
            // 0x00AB7118: STP x20, x19, [sp, #-0x20]! | stack[1152921514958787824] = ???;  stack[1152921514958787832] = ???;  //  dest_result_addr=1152921514958787824 |  dest_result_addr=1152921514958787832
            // 0x00AB711C: STP x29, x30, [sp, #0x10]  | stack[1152921514958787840] = ???;  stack[1152921514958787848] = ???;  //  dest_result_addr=1152921514958787840 |  dest_result_addr=1152921514958787848
            // 0x00AB7120: ADD x29, sp, #0x10         | X29 = (1152921514958787824 + 16) = 1152921514958787840 (0x1000000269061500);
            // 0x00AB7124: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB7128: LDRB w8, [x20, #0x414]     | W8 = (bool)static_value_03733414;       
            // 0x00AB712C: MOV x19, x0                | X19 = 1152921514958799856 (0x10000002690643F0);//ML01
            // 0x00AB7130: TBNZ w8, #0, #0xab714c     | if (static_value_03733414 == true) goto label_0;
            // 0x00AB7134: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00AB7138: LDR x8, [x8, #0xd50]       | X8 = 0x2B8EBD8;                         
            // 0x00AB713C: LDR w0, [x8]               | W0 = 0x11B6;                            
            // 0x00AB7140: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B6, ????);     
            // 0x00AB7144: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB7148: STRB w8, [x20, #0x414]     | static_value_03733414 = true;            //  dest_result_addr=57881620
            label_0:
            // 0x00AB714C: LDR w20, [x19, #0x10]      | W20 = this.network; //P2                
            // 0x00AB7150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7154: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7158: BL #0x20c84c4              | X0 = UnityEngine.Application.get_internetReachability();
            UnityEngine.NetworkReachability val_1 = UnityEngine.Application.internetReachability;
            // 0x00AB715C: CMP w20, w0                | STATE = COMPARE(this.network, val_1)    
            // 0x00AB7160: B.NE #0xab7170             | if (this.network != val_1) goto label_1;
            if(this.network != val_1)
            {
                goto label_1;
            }
            // 0x00AB7164: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7168: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB716C: RET                        |  return;                                
            return;
            label_1:
            // 0x00AB7170: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7174: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7178: BL #0x20c84c4              | X0 = UnityEngine.Application.get_internetReachability();
            UnityEngine.NetworkReachability val_2 = UnityEngine.Application.internetReachability;
            // 0x00AB717C: STR w0, [x19, #0x10]       | this.network = val_2;                    //  dest_result_addr=1152921514958799872
            this.network = val_2;
            // 0x00AB7180: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00AB7184: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x00AB7188: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_3 = null;
            // 0x00AB718C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x00AB7190: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00AB7194: LDR x8, [x8, #0x10]        | X8 = (string**)(1152921510510282704)("NETWORK_CHANGE");
            // 0x00AB7198: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB719C: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00AB71A0: LDR x1, [x8]               | X1 = "NETWORK_CHANGE";                  
            // 0x00AB71A4: BL #0xd80ce8               | .ctor(name:  "NETWORK_CHANGE");         
            val_3 = new CEvent.ZEvent(name:  "NETWORK_CHANGE");
            // 0x00AB71A8: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00AB71AC: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
            // 0x00AB71B0: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
            // 0x00AB71B4: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
            // 0x00AB71B8: TBZ w8, #0, #0xab71c8      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB71BC: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
            // 0x00AB71C0: CBNZ w8, #0xab71c8         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB71C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
            label_3:
            // 0x00AB71C8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB71CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB71D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB71D4: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00AB71D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB71DC: B #0xd7de90                | CEvent.ZEventCenter.DispatchEvent(ev:  0); return;
            CEvent.ZEventCenter.DispatchEvent(ev:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB71E0 (11235808), len: 36  VirtAddr: 0x00AB71E0 RVA: 0x00AB71E0 token: 100693248 methodIndex: 47010 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool get_IsWifiNetwork()
        {
            //
            // Disasemble & Code
            // 0x00AB71E0: STP x29, x30, [sp, #-0x10]! | stack[1152921514958916224] = ???;  stack[1152921514958916232] = ???;  //  dest_result_addr=1152921514958916224 |  dest_result_addr=1152921514958916232
            // 0x00AB71E4: MOV x29, sp                | X29 = 1152921514958916224 (0x1000000269080A80);//ML01
            // 0x00AB71E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB71EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB71F0: BL #0x20c84c4              | X0 = UnityEngine.Application.get_internetReachability();
            UnityEngine.NetworkReachability val_1 = UnityEngine.Application.internetReachability;
            // 0x00AB71F4: CMP w0, #2                 | STATE = COMPARE(val_1, 0x2)             
            // 0x00AB71F8: CSET w0, eq                | W0 = val_1 == 0x2 ? 1 : 0;              
            var val_2 = (val_1 == 2) ? 1 : 0;
            // 0x00AB71FC: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7200: RET                        |  return (System.Boolean)val_1 == 0x2 ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB7204 (11235844), len: 328  VirtAddr: 0x00AB7204 RVA: 0x00AB7204 token: 100693249 methodIndex: 47011 delegateWrapperIndex: 0 methodInvoker: 0
        public static void SetAssetCfg(Filelist<FileInfoRes> fileList)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x00AB7204: STP x28, x27, [sp, #-0x60]! | stack[1152921514959047600] = ???;  stack[1152921514959047608] = ???;  //  dest_result_addr=1152921514959047600 |  dest_result_addr=1152921514959047608
            // 0x00AB7208: STP x26, x25, [sp, #0x10]  | stack[1152921514959047616] = ???;  stack[1152921514959047624] = ???;  //  dest_result_addr=1152921514959047616 |  dest_result_addr=1152921514959047624
            // 0x00AB720C: STP x24, x23, [sp, #0x20]  | stack[1152921514959047632] = ???;  stack[1152921514959047640] = ???;  //  dest_result_addr=1152921514959047632 |  dest_result_addr=1152921514959047640
            // 0x00AB7210: STP x22, x21, [sp, #0x30]  | stack[1152921514959047648] = ???;  stack[1152921514959047656] = ???;  //  dest_result_addr=1152921514959047648 |  dest_result_addr=1152921514959047656
            // 0x00AB7214: STP x20, x19, [sp, #0x40]  | stack[1152921514959047664] = ???;  stack[1152921514959047672] = ???;  //  dest_result_addr=1152921514959047664 |  dest_result_addr=1152921514959047672
            // 0x00AB7218: STP x29, x30, [sp, #0x50]  | stack[1152921514959047680] = ???;  stack[1152921514959047688] = ???;  //  dest_result_addr=1152921514959047680 |  dest_result_addr=1152921514959047688
            // 0x00AB721C: ADD x29, sp, #0x50         | X29 = (1152921514959047600 + 80) = 1152921514959047680 (0x10000002690A0C00);
            // 0x00AB7220: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB7224: LDRB w8, [x20, #0x415]     | W8 = (bool)static_value_03733415;       
            // 0x00AB7228: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB722C: TBNZ w8, #0, #0xab7248     | if (static_value_03733415 == true) goto label_0;
            // 0x00AB7230: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00AB7234: LDR x8, [x8, #0xac0]       | X8 = 0x2B8EBD4;                         
            // 0x00AB7238: LDR w0, [x8]               | W0 = 0x11B5;                            
            // 0x00AB723C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B5, ????);     
            // 0x00AB7240: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB7244: STRB w8, [x20, #0x415]     | static_value_03733415 = true;            //  dest_result_addr=57881621
            label_0:
            // 0x00AB7248: ADRP x24, #0x35c6000       | X24 = 56385536 (0x35C6000);             
            // 0x00AB724C: ADRP x25, #0x3671000       | X25 = 57085952 (0x3671000);             
            // 0x00AB7250: ADRP x26, #0x35bd000       | X26 = 56348672 (0x35BD000);             
            // 0x00AB7254: ADRP x27, #0x35cc000       | X27 = 56410112 (0x35CC000);             
            // 0x00AB7258: ADRP x28, #0x35ed000       | X28 = 56545280 (0x35ED000);             
            // 0x00AB725C: LDR x24, [x24, #0x5d8]     | X24 = 1152921514959024432;              
            // 0x00AB7260: LDR x25, [x25, #0xf30]     | X25 = 1152921504903544832;              
            // 0x00AB7264: LDR x26, [x26, #0xb50]     | X26 = 1152921510890998992;              
            // 0x00AB7268: LDR x27, [x27, #0x7d8]     | X27 = 1152921514959025456;              
            // 0x00AB726C: LDR x28, [x28, #0xd20]     | X28 = 1152921514959026480;              
            // 0x00AB7270: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_4 = 0;
            // 0x00AB7274: B #0xab7290                |  goto label_1;                          
            goto label_1;
            label_11:
            // 0x00AB7278: LDR x3, [x28]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Add(System.String key, FileInfoRes value);
            // 0x00AB727C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x00AB7280: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00AB7284: MOV x2, x23                | X2 = X23;//m1                           
            // 0x00AB7288: BL #0x23fd44c              | X21.Add(key:  X22, value:  X23);        
            X21.Add(key:  X22, value:  X23);
            // 0x00AB728C: ADD w20, w20, #1           | W20 = (val_4 + 1) = val_4 (0x00000001); 
            val_4 = 1;
            label_1:
            // 0x00AB7290: CBNZ x19, #0xab7298        | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x00AB7294: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X21, ????);        
            label_2:
            // 0x00AB7298: LDR x21, [x19, #0x18]      | X21 = X1 + 24;                          
            // 0x00AB729C: CBNZ x21, #0xab72a4        | if (X1 + 24 != 0) goto label_3;         
            if((X1 + 24) != 0)
            {
                goto label_3;
            }
            // 0x00AB72A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X21, ????);        
            label_3:
            // 0x00AB72A4: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
            // 0x00AB72A8: MOV x0, x21                | X0 = X1 + 24;//m1                       
            // 0x00AB72AC: BL #0x25ed72c              | X0 = X1 + 24.get_Count();               
            int val_1 = X1 + 24.Count;
            // 0x00AB72B0: CMP w20, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00AB72B4: B.GE #0xab7330             | if (val_4 >= val_1) goto label_4;       
            if(val_4 >= val_1)
            {
                goto label_4;
            }
            // 0x00AB72B8: LDR x0, [x25]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_5 = null;
            // 0x00AB72BC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB72C0: TBZ w8, #0, #0xab72d4      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB72C4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB72C8: CBNZ w8, #0xab72d4         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB72CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            // 0x00AB72D0: LDR x0, [x25]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_5 = null;
            label_6:
            // 0x00AB72D4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB72D8: LDR x21, [x8]              | X21 = Mihua.Assets.AssetUtil.assetsDic; 
            // 0x00AB72DC: CBNZ x19, #0xab72e4        | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x00AB72E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_7:
            // 0x00AB72E4: LDR x22, [x19, #0x10]      | X22 = X1 + 16;                          
            // 0x00AB72E8: CBNZ x22, #0xab72f0        | if (X1 + 16 != 0) goto label_8;         
            if((X1 + 16) != 0)
            {
                goto label_8;
            }
            // 0x00AB72EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_8:
            // 0x00AB72F0: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB72F4: MOV x0, x22                | X0 = X1 + 16;//m1                       
            // 0x00AB72F8: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB72FC: BL #0x25ed734              | X0 = X1 + 16.get_Item(index:  1);       
            string val_2 = X1 + 16.Item[1];
            // 0x00AB7300: LDR x23, [x19, #0x18]      | X23 = X1 + 24;                          
            // 0x00AB7304: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00AB7308: CBNZ x23, #0xab7310        | if (X1 + 24 != 0) goto label_9;         
            if((X1 + 24) != 0)
            {
                goto label_9;
            }
            // 0x00AB730C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x00AB7310: LDR x2, [x27]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
            // 0x00AB7314: MOV x0, x23                | X0 = X1 + 24;//m1                       
            // 0x00AB7318: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB731C: BL #0x25ed734              | X0 = X1 + 24.get_Item(index:  1);       
            FileInfoRes val_3 = X1 + 24.Item[1];
            // 0x00AB7320: MOV x23, x0                | X23 = val_3;//m1                        
            // 0x00AB7324: CBNZ x21, #0xab7278        | if (Mihua.Assets.AssetUtil.assetsDic != null) goto label_11;
            if(Mihua.Assets.AssetUtil.assetsDic != null)
            {
                goto label_11;
            }
            // 0x00AB7328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x00AB732C: B #0xab7278                |  goto label_11;                         
            goto label_11;
            label_4:
            // 0x00AB7330: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7334: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB7338: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB733C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB7340: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB7344: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AB7348: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB734C (11236172), len: 472  VirtAddr: 0x00AB734C RVA: 0x00AB734C token: 100693250 methodIndex: 47012 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.List<FileInfoRes> GetNeedLoadList()
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            System.Collections.Generic.List<T> val_8;
            //  | 
            var val_9;
            // 0x00AB734C: STP x26, x25, [sp, #-0x50]! | stack[1152921514959184192] = ???;  stack[1152921514959184200] = ???;  //  dest_result_addr=1152921514959184192 |  dest_result_addr=1152921514959184200
            // 0x00AB7350: STP x24, x23, [sp, #0x10]  | stack[1152921514959184208] = ???;  stack[1152921514959184216] = ???;  //  dest_result_addr=1152921514959184208 |  dest_result_addr=1152921514959184216
            // 0x00AB7354: STP x22, x21, [sp, #0x20]  | stack[1152921514959184224] = ???;  stack[1152921514959184232] = ???;  //  dest_result_addr=1152921514959184224 |  dest_result_addr=1152921514959184232
            // 0x00AB7358: STP x20, x19, [sp, #0x30]  | stack[1152921514959184240] = ???;  stack[1152921514959184248] = ???;  //  dest_result_addr=1152921514959184240 |  dest_result_addr=1152921514959184248
            // 0x00AB735C: STP x29, x30, [sp, #0x40]  | stack[1152921514959184256] = ???;  stack[1152921514959184264] = ???;  //  dest_result_addr=1152921514959184256 |  dest_result_addr=1152921514959184264
            // 0x00AB7360: ADD x29, sp, #0x40         | X29 = (1152921514959184192 + 64) = 1152921514959184256 (0x10000002690C2180);
            // 0x00AB7364: SUB sp, sp, #0x30          | SP = (1152921514959184192 - 48) = 1152921514959184144 (0x10000002690C2110);
            // 0x00AB7368: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB736C: LDRB w8, [x19, #0x416]     | W8 = (bool)static_value_03733416;       
            // 0x00AB7370: TBNZ w8, #0, #0xab738c     | if (static_value_03733416 == true) goto label_0;
            // 0x00AB7374: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00AB7378: LDR x8, [x8, #0xcc8]       | X8 = 0x2B8EBC8;                         
            // 0x00AB737C: LDR w0, [x8]               | W0 = 0x11B2;                            
            // 0x00AB7380: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B2, ????);     
            // 0x00AB7384: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB7388: STRB w8, [x19, #0x416]     | static_value_03733416 = true;            //  dest_result_addr=57881622
            label_0:
            // 0x00AB738C: STP xzr, xzr, [sp, #0x20]  | stack[1152921514959184176] = 0x0;  stack[1152921514959184184] = 0x0;  //  dest_result_addr=1152921514959184176 |  dest_result_addr=1152921514959184184
            // 0x00AB7390: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB7394: STR xzr, [sp, #0x18]       | stack[1152921514959184168] = 0x0;        //  dest_result_addr=1152921514959184168
            // 0x00AB7398: LDR x8, [x8, #0x540]       | X8 = 1152921504616644608;               
            // 0x00AB739C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<FileInfoRes> val_1 = null;
            // 0x00AB73A0: STP xzr, xzr, [sp, #8]     | stack[1152921514959184152] = 0x0;  stack[1152921514959184160] = 0x0;  //  dest_result_addr=1152921514959184152 |  dest_result_addr=1152921514959184160
            // 0x00AB73A4: STR xzr, [sp]              | stack[1152921514959184144] = 0x0;        //  dest_result_addr=1152921514959184144
            // 0x00AB73A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB73AC: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x00AB73B0: LDR x8, [x8, #0x1b0]       | X8 = 1152921514959159984;               
            // 0x00AB73B4: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB73B8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<FileInfoRes>::.ctor();
            // 0x00AB73BC: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<FileInfoRes>();
            // 0x00AB73C0: ADRP x21, #0x3671000       | X21 = 57085952 (0x3671000);             
            // 0x00AB73C4: LDR x21, [x21, #0xf30]     | X21 = 1152921504903544832;              
            // 0x00AB73C8: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_7 = null;
            // 0x00AB73CC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB73D0: TBZ w8, #0, #0xab73e4      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB73D4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB73D8: CBNZ w8, #0xab73e4         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB73DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            // 0x00AB73E0: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_7 = null;
            label_2:
            // 0x00AB73E4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB73E8: LDR x20, [x8]              | X20 = Mihua.Assets.AssetUtil.assetsDic; 
            // 0x00AB73EC: CBNZ x20, #0xab73f4        | if (Mihua.Assets.AssetUtil.assetsDic != null) goto label_3;
            if(Mihua.Assets.AssetUtil.assetsDic != null)
            {
                goto label_3;
            }
            // 0x00AB73F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_3:
            // 0x00AB73F4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00AB73F8: LDR x8, [x8, #0x790]       | X8 = 1152921514959161008;               
            // 0x00AB73FC: MOV x0, x20                | X0 = Mihua.Assets.AssetUtil.assetsDic;//m1
            // 0x00AB7400: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, FileInfoRes>::GetEnumerator();
            // 0x00AB7404: MOV x8, sp                 | X8 = 1152921514959184144 (0x10000002690C2110);//ML01
            // 0x00AB7408: BL #0x23ff0fc              | X0 = Mihua.Assets.AssetUtil.assetsDic.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_2 = Mihua.Assets.AssetUtil.assetsDic.GetEnumerator();
            // 0x00AB740C: ADRP x22, #0x361d000       | X22 = 56741888 (0x361D000);             
            // 0x00AB7410: ADRP x23, #0x3640000       | X23 = 56885248 (0x3640000);             
            // 0x00AB7414: ADRP x24, #0x3646000       | X24 = 56909824 (0x3646000);             
            // 0x00AB7418: ADRP x25, #0x364f000       | X25 = 56946688 (0x364F000);             
            // 0x00AB741C: ADRP x26, #0x3660000       | X26 = 57016320 (0x3660000);             
            // 0x00AB7420: LDR x22, [x22, #0x458]     | X22 = 1152921514959162032;              
            // 0x00AB7424: LDR x23, [x23, #0x218]     | X23 = 1152921514959163056;              
            // 0x00AB7428: LDR x24, [x24, #0x920]     | X24 = 1152921514959164080;              
            // 0x00AB742C: LDR x25, [x25, #0x3e0]     | X25 = 1152921514959165104;              
            // 0x00AB7430: LDR x26, [x26, #0xcc0]     | X26 = 1152921514959166128;              
            label_9:
            // 0x00AB7434: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, FileInfoRes>::MoveNext();
            // 0x00AB7438: MOV x0, sp                 | X0 = 1152921514959184144 (0x10000002690C2110);//ML01
            // 0x00AB743C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB7440: AND w8, w0, #1             | W8 = ( & 1) = 0 (0x00000000);           
            // 0x00AB7444: TBZ w8, #0, #0xab74d4      | if ((0x0 & 0x1) == 0) goto label_4;     
            if((0 & 1) == 0)
            {
                goto label_4;
            }
            // 0x00AB7448: LDR x1, [x23]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, FileInfoRes>::get_Current();
            // 0x00AB744C: MOV x0, sp                 | X0 = 1152921514959184144 (0x10000002690C2110);//ML01
            // 0x00AB7450: BL #0xf3ac3c               | X0 = null.GetHandle();                  
            UnityEngine.Playables.PlayableHandle val_3 = 0.GetHandle();
            // 0x00AB7454: LDR x8, [x24]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, FileInfoRes>::get_Key();
            // 0x00AB7458: STP x0, x1, [sp, #0x20]    | stack[1152921514959184176] = val_3.m_Handle;  stack[1152921514959184184] = val_3.m_Version;  //  dest_result_addr=1152921514959184176 |  dest_result_addr=1152921514959184184
            // 0x00AB745C: ADD x0, sp, #0x20          | X0 = (1152921514959184144 + 32) = 1152921514959184176 (0x10000002690C2130);
            // 0x00AB7460: MOV x1, x8                 | X1 = 1152921514959164080 (0x10000002690BD2B0);//ML01
            // 0x00AB7464: BL #0x1dc9dd4              | X0 = val_3.m_Handle.get_InitialType();  
            System.Type val_4 = val_3.m_Handle.InitialType;
            // 0x00AB7468: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x00AB746C: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB7470: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB7474: TBZ w8, #0, #0xab7484      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB7478: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB747C: CBNZ w8, #0xab7484         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB7480: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_6:
            // 0x00AB7484: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x00AB7488: BL #0xab4c88               | X0 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            bool val_5 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            // 0x00AB748C: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x00AB7490: TBNZ w8, #0, #0xab7434     | if ((val_5 & 1) == true) goto label_9;  
            if(val_6 == true)
            {
                goto label_9;
            }
            // 0x00AB7494: LDR x1, [x25]              | X1 = public FileInfoRes System.Collections.Generic.KeyValuePair<System.String, FileInfoRes>::get_Value();
            // 0x00AB7498: ADD x0, sp, #0x20          | X0 = (1152921514959184144 + 32) = 1152921514959184176 (0x10000002690C2130);
            // 0x00AB749C: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB74A0: MOV x20, x0                | X20 = 1152921514959184176 (0x10000002690C2130);//ML01
            // 0x00AB74A4: CBNZ x19, #0xab74ac        | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x00AB74A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002690C2130, ????);
            label_8:
            // 0x00AB74AC: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<FileInfoRes>::Add(FileInfoRes item);
            // 0x00AB74B0: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB74B4: MOV x1, x20                | X1 = 1152921514959184176 (0x10000002690C2130);//ML01
            // 0x00AB74B8: BL #0x25ea480              | Add(item:  val_3.m_Handle);             
            Add(item:  val_3.m_Handle);
            // 0x00AB74BC: B #0xab7434                |  goto label_9;                          
            goto label_9;
            // 0x00AB74C0: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB74C4: LDR x20, [x0]              | X20 = ;                                 
            val_8 = null;
            // 0x00AB74C8: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB74CC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00AB74D0: B #0xab74dc                |  goto label_10;                         
            goto label_10;
            label_4:
            // 0x00AB74D4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00AB74D8: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            val_9 = 1;
            label_10:
            // 0x00AB74DC: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00AB74E0: LDR x8, [x8, #0xcf8]       | X8 = 1152921514959171248;               
            // 0x00AB74E4: MOV x0, sp                 | X0 = 1152921514959184144 (0x10000002690C2110);//ML01
            // 0x00AB74E8: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, FileInfoRes>::Dispose();
            // 0x00AB74EC: BL #0xf3acac               | null.Dispose();                         
            0.Dispose();
            // 0x00AB74F0: TBNZ w21, #0, #0xab7504    | if ((0x1 & 0x1) != 0) goto label_12;    
            if((val_9 & 1) != 0)
            {
                goto label_12;
            }
            // 0x00AB74F4: CBZ x20, #0xab7504         | if (0x0 == 0) goto label_12;            
            if(val_8 == 0)
            {
                goto label_12;
            }
            // 0x00AB74F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB74FC: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7500: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_12:
            // 0x00AB7504: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB7508: SUB sp, x29, #0x40         | SP = (1152921514959184256 - 64) = 1152921514959184192 (0x10000002690C2140);
            // 0x00AB750C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7510: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB7514: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB7518: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB751C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB7520: RET                        |  return (System.Collections.Generic.List<FileInfoRes>)typeof(System.Collections.Generic.List<T>);
            return (System.Collections.Generic.List<FileInfoRes>)val_1;
            //  |  // // {name=val_0, type=System.Collections.Generic.List<FileInfoRes>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB4C88 (11226248), len: 564  VirtAddr: 0x00AB4C88 RVA: 0x00AB4C88 token: 100693251 methodIndex: 47013 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool Exists(string abName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_8;
            //  | 
            string val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x00AB4C88: STP x22, x21, [sp, #-0x30]! | stack[1152921514959322944] = ???;  stack[1152921514959322952] = ???;  //  dest_result_addr=1152921514959322944 |  dest_result_addr=1152921514959322952
            // 0x00AB4C8C: STP x20, x19, [sp, #0x10]  | stack[1152921514959322960] = ???;  stack[1152921514959322968] = ???;  //  dest_result_addr=1152921514959322960 |  dest_result_addr=1152921514959322968
            // 0x00AB4C90: STP x29, x30, [sp, #0x20]  | stack[1152921514959322976] = ???;  stack[1152921514959322984] = ???;  //  dest_result_addr=1152921514959322976 |  dest_result_addr=1152921514959322984
            // 0x00AB4C94: ADD x29, sp, #0x20         | X29 = (1152921514959322944 + 32) = 1152921514959322976 (0x10000002690E3F60);
            // 0x00AB4C98: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB4C9C: LDRB w8, [x20, #0x417]     | W8 = (bool)static_value_03733417;       
            // 0x00AB4CA0: MOV x19, x1                | X19 = X1;//m1                           
            val_8 = X1;
            // 0x00AB4CA4: TBNZ w8, #0, #0xab4cc0     | if (static_value_03733417 == true) goto label_0;
            // 0x00AB4CA8: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00AB4CAC: LDR x8, [x8, #0xdd8]       | X8 = 0x2B8EBC4;                         
            // 0x00AB4CB0: LDR w0, [x8]               | W0 = 0x11B1;                            
            // 0x00AB4CB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B1, ????);     
            // 0x00AB4CB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB4CBC: STRB w8, [x20, #0x417]     | static_value_03733417 = true;            //  dest_result_addr=57881623
            label_0:
            // 0x00AB4CC0: ADRP x21, #0x3671000       | X21 = 57085952 (0x3671000);             
            // 0x00AB4CC4: LDR x21, [x21, #0xf30]     | X21 = 1152921504903544832;              
            val_9 = 1152921504903544832;
            // 0x00AB4CC8: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_10 = null;
            // 0x00AB4CCC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB4CD0: TBZ w8, #0, #0xab4ce4      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB4CD4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4CD8: CBNZ w8, #0xab4ce4         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB4CDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            // 0x00AB4CE0: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_10 = null;
            label_2:
            // 0x00AB4CE4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB4CE8: LDR x20, [x8]              | X20 = Mihua.Assets.AssetUtil.assetsDic; 
            // 0x00AB4CEC: CBNZ x20, #0xab4cf4        | if (Mihua.Assets.AssetUtil.assetsDic != null) goto label_3;
            if(Mihua.Assets.AssetUtil.assetsDic != null)
            {
                goto label_3;
            }
            // 0x00AB4CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_3:
            // 0x00AB4CF4: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00AB4CF8: LDR x8, [x8, #0x530]       | X8 = 1152921514959292464;               
            // 0x00AB4CFC: MOV x0, x20                | X0 = Mihua.Assets.AssetUtil.assetsDic;//m1
            // 0x00AB4D00: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB4D04: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, FileInfoRes>::ContainsKey(System.String key);
            // 0x00AB4D08: BL #0x23fd9f0              | X0 = Mihua.Assets.AssetUtil.assetsDic.ContainsKey(key:  val_8);
            bool val_1 = Mihua.Assets.AssetUtil.assetsDic.ContainsKey(key:  val_8);
            // 0x00AB4D0C: TBZ w0, #0, #0xab4e50      | if (val_1 == false) goto label_4;       
            if(val_1 == false)
            {
                goto label_4;
            }
            // 0x00AB4D10: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_11 = null;
            // 0x00AB4D14: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB4D18: TBZ w8, #0, #0xab4d2c      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB4D1C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4D20: CBNZ w8, #0xab4d2c         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB4D24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            // 0x00AB4D28: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_11 = null;
            label_6:
            // 0x00AB4D2C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB4D30: LDR x20, [x8, #8]          | X20 = Mihua.Assets.AssetUtil.sb;        
            // 0x00AB4D34: CBNZ x20, #0xab4d3c        | if (Mihua.Assets.AssetUtil.sb != null) goto label_7;
            if(Mihua.Assets.AssetUtil.sb != null)
            {
                goto label_7;
            }
            // 0x00AB4D38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_7:
            // 0x00AB4D3C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4D40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB4D44: MOV x0, x20                | X0 = Mihua.Assets.AssetUtil.sb;//m1     
            // 0x00AB4D48: BL #0x1b5ac0c              | Mihua.Assets.AssetUtil.sb.set_Length(value:  0);
            Mihua.Assets.AssetUtil.sb.Length = 0;
            // 0x00AB4D4C: LDR x8, [x21]              | X8 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB4D50: LDR x8, [x8, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB4D54: LDR x20, [x8]              | X20 = Mihua.Assets.AssetUtil.assetsDic; 
            // 0x00AB4D58: CBNZ x20, #0xab4d60        | if (Mihua.Assets.AssetUtil.assetsDic != null) goto label_8;
            if(Mihua.Assets.AssetUtil.assetsDic != null)
            {
                goto label_8;
            }
            // 0x00AB4D5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Assets.AssetUtil.sb, ????);
            label_8:
            // 0x00AB4D60: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00AB4D64: LDR x8, [x8, #0x230]       | X8 = 1152921514959293488;               
            // 0x00AB4D68: MOV x0, x20                | X0 = Mihua.Assets.AssetUtil.assetsDic;//m1
            // 0x00AB4D6C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB4D70: LDR x2, [x8]               | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
            // 0x00AB4D74: BL #0x23fc26c              | X0 = Mihua.Assets.AssetUtil.assetsDic.get_Item(key:  val_8);
            FileInfoRes val_2 = Mihua.Assets.AssetUtil.assetsDic.Item[val_8];
            // 0x00AB4D78: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AB4D7C: CBNZ x20, #0xab4d84        | if (val_2 != null) goto label_9;        
            if(val_2 != null)
            {
                goto label_9;
            }
            // 0x00AB4D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x00AB4D84: LDR w8, [x20, #0x30]       | W8 = val_2.loadType; //P2               
            // 0x00AB4D88: CMP w8, #2                 | STATE = COMPARE(val_2.loadType, 0x2)    
            // 0x00AB4D8C: B.LT #0xab4e48             | if (val_2.loadType < 2) goto label_10;  
            if(val_2.loadType < 2)
            {
                goto label_10;
            }
            // 0x00AB4D90: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_12 = null;
            // 0x00AB4D94: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB4D98: TBZ w8, #0, #0xab4dac      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AB4D9C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4DA0: CBNZ w8, #0xab4dac         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AB4DA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            // 0x00AB4DA8: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            val_12 = null;
            label_12:
            // 0x00AB4DAC: ADRP x21, #0x35ef000       | X21 = 56553472 (0x35EF000);             
            // 0x00AB4DB0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB4DB4: LDR x21, [x21, #0xde8]     | X21 = 1152921504911265792;              
            // 0x00AB4DB8: LDR x20, [x8, #8]          | X20 = Mihua.Assets.AssetUtil.sb;        
            // 0x00AB4DBC: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
            val_13 = null;
            // 0x00AB4DC0: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
            // 0x00AB4DC4: TBZ w8, #0, #0xab4dd8      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00AB4DC8: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4DCC: CBNZ w8, #0xab4dd8         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00AB4DD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
            // 0x00AB4DD4: LDR x0, [x21]              | X0 = typeof(Loader.PathUtil);           
            val_13 = null;
            label_14:
            // 0x00AB4DD8: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB4DDC: LDR x21, [x8, #0x28]       | X21 = Loader.PathUtil.persistentDataPath;
            val_9 = Loader.PathUtil.persistentDataPath;
            // 0x00AB4DE0: CBNZ x20, #0xab4de8        | if (Mihua.Assets.AssetUtil.sb != null) goto label_15;
            if(Mihua.Assets.AssetUtil.sb != null)
            {
                goto label_15;
            }
            // 0x00AB4DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
            label_15:
            // 0x00AB4DE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB4DEC: MOV x0, x20                | X0 = Mihua.Assets.AssetUtil.sb;//m1     
            // 0x00AB4DF0: MOV x1, x21                | X1 = Loader.PathUtil.persistentDataPath;//m1
            // 0x00AB4DF4: BL #0x1b5b818              | X0 = Mihua.Assets.AssetUtil.sb.Append(value:  val_9);
            System.Text.StringBuilder val_3 = Mihua.Assets.AssetUtil.sb.Append(value:  val_9);
            // 0x00AB4DF8: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00AB4DFC: CBNZ x20, #0xab4e04        | if (val_3 != null) goto label_16;       
            if(val_3 != null)
            {
                goto label_16;
            }
            // 0x00AB4E00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_16:
            // 0x00AB4E04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB4E08: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00AB4E0C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB4E10: BL #0x1b5b818              | X0 = val_3.Append(value:  val_8);       
            System.Text.StringBuilder val_4 = val_3.Append(value:  val_8);
            // 0x00AB4E14: MOV x19, x0                | X19 = val_4;//m1                        
            val_8 = val_4;
            // 0x00AB4E18: CBNZ x19, #0xab4e20        | if (val_4 != null) goto label_17;       
            if(val_8 != null)
            {
                goto label_17;
            }
            // 0x00AB4E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_17:
            // 0x00AB4E20: LDR x8, [x19]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x00AB4E24: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x00AB4E28: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x00AB4E2C: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x00AB4E30: MOV x1, x0                 | X1 = val_4;//m1                         
            // 0x00AB4E34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4E38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB4E3C: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_5 = System.IO.File.Exists(path:  0);
            // 0x00AB4E40: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x00AB4E44: TBZ w8, #0, #0xab4ea8      | if ((val_5 & 1) == false) goto label_18;
            if(val_6 == false)
            {
                goto label_18;
            }
            label_10:
            // 0x00AB4E48: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_14 = 1;
            // 0x00AB4E4C: B #0xab4eac                |  goto label_19;                         
            goto label_19;
            label_4:
            // 0x00AB4E50: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x00AB4E54: LDR x8, [x8, #0x2c8]       | X8 = (string**)(1152921514959306800)("没有找到资源：{0}");
            // 0x00AB4E58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4E5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB4E60: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00AB4E64: LDR x1, [x8]               | X1 = "没有找到资源：{0}";                      
            // 0x00AB4E68: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "没有找到资源：{0}");
            string val_7 = EString.EFormat(format:  0, arg0:  "没有找到资源：{0}");
            // 0x00AB4E6C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB4E70: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB4E74: MOV x19, x0                | X19 = val_7;//m1                        
            val_8 = val_7;
            // 0x00AB4E78: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB4E7C: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB4E80: TBZ w9, #0, #0xab4e94      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00AB4E84: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4E88: CBNZ w9, #0xab4e94         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00AB4E8C: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB4E90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_21:
            // 0x00AB4E94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4E98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB4E9C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB4EA0: MOV x1, x19                | X1 = val_7;//m1                         
            // 0x00AB4EA4: BL #0xb5b3cc               | EDebug.LogWarning(message:  0, isShowStack:  val_8);
            EDebug.LogWarning(message:  0, isShowStack:  val_8);
            label_18:
            // 0x00AB4EA8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_14 = 0;
            label_19:
            // 0x00AB4EAC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB4EB0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB4EB4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB4EB8: RET                        |  return (System.Boolean)false;          
            return (bool)val_14;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB7524 (11236644), len: 1344  VirtAddr: 0x00AB7524 RVA: 0x00AB7524 token: 100693252 methodIndex: 47014 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.IO.MemoryStream LoadDataFromStreamPath(string fileName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x00AB7524: STP x26, x25, [sp, #-0x50]! | stack[1152921514959557904] = ???;  stack[1152921514959557912] = ???;  //  dest_result_addr=1152921514959557904 |  dest_result_addr=1152921514959557912
            // 0x00AB7528: STP x24, x23, [sp, #0x10]  | stack[1152921514959557920] = ???;  stack[1152921514959557928] = ???;  //  dest_result_addr=1152921514959557920 |  dest_result_addr=1152921514959557928
            // 0x00AB752C: STP x22, x21, [sp, #0x20]  | stack[1152921514959557936] = ???;  stack[1152921514959557944] = ???;  //  dest_result_addr=1152921514959557936 |  dest_result_addr=1152921514959557944
            // 0x00AB7530: STP x20, x19, [sp, #0x30]  | stack[1152921514959557952] = ???;  stack[1152921514959557960] = ???;  //  dest_result_addr=1152921514959557952 |  dest_result_addr=1152921514959557960
            // 0x00AB7534: STP x29, x30, [sp, #0x40]  | stack[1152921514959557968] = ???;  stack[1152921514959557976] = ???;  //  dest_result_addr=1152921514959557968 |  dest_result_addr=1152921514959557976
            // 0x00AB7538: ADD x29, sp, #0x40         | X29 = (1152921514959557904 + 64) = 1152921514959557968 (0x100000026911D550);
            // 0x00AB753C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB7540: LDRB w8, [x20, #0x418]     | W8 = (bool)static_value_03733418;       
            // 0x00AB7544: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB7548: TBNZ w8, #0, #0xab7564     | if (static_value_03733418 == true) goto label_0;
            // 0x00AB754C: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00AB7550: LDR x8, [x8, #0x170]       | X8 = 0x2B8EBCC;                         
            // 0x00AB7554: LDR w0, [x8]               | W0 = 0x11B3;                            
            // 0x00AB7558: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B3, ????);     
            // 0x00AB755C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB7560: STRB w8, [x20, #0x418]     | static_value_03733418 = true;            //  dest_result_addr=57881624
            label_0:
            // 0x00AB7564: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7568: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB756C: BL #0x20c73f8              | X0 = UnityEngine.Application.get_streamingAssetsPath();
            string val_1 = UnityEngine.Application.streamingAssetsPath;
            // 0x00AB7570: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB7574: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB7578: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AB757C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00AB7580: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB7584: TBZ w9, #0, #0xab7598      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB7588: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB758C: CBNZ w9, #0xab7598         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB7590: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AB7594: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00AB7598: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AB759C: LDR x8, [x8, #0xc60]       | X8 = (string**)(1152921514959451664)("{0}/allAssets/{1}");
            // 0x00AB75A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB75A4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AB75A8: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x00AB75AC: LDR x1, [x8]               | X1 = "{0}/allAssets/{1}";               
            // 0x00AB75B0: MOV x3, x19                | X3 = X1;//m1                            
            // 0x00AB75B4: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "{0}/allAssets/{1}", arg1:  val_1);
            string val_2 = System.String.Format(format:  0, arg0:  "{0}/allAssets/{1}", arg1:  val_1);
            // 0x00AB75B8: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00AB75BC: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
            // 0x00AB75C0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AB75C4: LDR x8, [x8]               | X8 = typeof(System.IO.MemoryStream);    
            // 0x00AB75C8: MOV x0, x8                 | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            System.IO.MemoryStream val_3 = null;
            // 0x00AB75CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
            // 0x00AB75D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB75D4: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_17 = val_3;
            // 0x00AB75D8: BL #0x1e762f4              | .ctor();                                
            val_3 = new System.IO.MemoryStream();
            // 0x00AB75DC: ADRP x24, #0x3630000       | X24 = 56819712 (0x3630000);             
            // 0x00AB75E0: LDR x24, [x24, #0x3d0]     | X24 = 1152921504954501264;              
            // 0x00AB75E4: LDR x21, [x24]             | X21 = typeof(System.Object[]);          
            // 0x00AB75E8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB75EC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB75F0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AB75F4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB75F8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB75FC: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB7600: CBNZ x21, #0xab7608        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00AB7604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_3:
            // 0x00AB7608: CBZ x20, #0xab762c         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x00AB760C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB7610: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB7614: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00AB7618: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00AB761C: CBNZ x0, #0xab762c         | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00AB7620: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00AB7624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x00AB762C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB7630: CBNZ w8, #0xab7640         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00AB7634: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB7638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB763C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x00AB7640: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;
            // 0x00AB7644: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00AB7648: LDR x8, [x8, #0xff0]       | X8 = 1152921504690180096;               
            // 0x00AB764C: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaObject);
            // 0x00AB7650: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaObject), ????);
            // 0x00AB7654: MOV x20, x0                | X20 = 1152921504690180096 (0x1000000004F79000);//ML01
            // 0x00AB7658: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x00AB765C: LDR x8, [x8, #0x878]       | X8 = (string**)(1152921514875437312)("java.net.URL");
            // 0x00AB7660: LDR x1, [x8]               | X1 = "java.net.URL";                    
            // 0x00AB7664: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB7668: MOV x0, x20                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
            UnityEngine.AndroidJavaObject val_4 = null;
            // 0x00AB766C: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB7670: BL #0x20bad84              | .ctor(className:  "java.net.URL", args:  null);
            val_4 = new UnityEngine.AndroidJavaObject(className:  "java.net.URL", args:  null);
            // 0x00AB7674: CBNZ x20, #0xab767c        | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x00AB7678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "java.net.URL", args:  null), ????);
            label_7:
            // 0x00AB767C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AB7680: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921514875437408)("openConnection");
            // 0x00AB7684: LDR x22, [x24]             | X22 = typeof(System.Object[]);          
            // 0x00AB7688: LDR x21, [x8]              | X21 = "openConnection";                 
            // 0x00AB768C: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB7690: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB7694: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7698: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB769C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB76A0: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB76A4: ADRP x25, #0x3608000       | X25 = 56655872 (0x3608000);             
            // 0x00AB76A8: LDR x25, [x25, #0x710]     | X25 = 1152921514474317632;              
            // 0x00AB76AC: LDR x3, [x25]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
            // 0x00AB76B0: MOV x0, x20                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
            // 0x00AB76B4: MOV x1, x21                | X1 = 1152921514875437408 (0x10000002640E4160);//ML01
            // 0x00AB76B8: BL #0x12f5e74              | X0 = Call<UnityEngine.AndroidJavaObject>(methodName:  "openConnection", args:  null);
            UnityEngine.AndroidJavaObject val_5 = Call<UnityEngine.AndroidJavaObject>(methodName:  "openConnection", args:  null);
            // 0x00AB76BC: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x00AB76C0: CBNZ x21, #0xab76c8        | if (val_5 != null) goto label_8;        
            if(val_5 != null)
            {
                goto label_8;
            }
            // 0x00AB76C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_8:
            // 0x00AB76C8: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AB76CC: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921514875441600)("getContentLength");
            // 0x00AB76D0: LDR x22, [x24]             | X22 = typeof(System.Object[]);          
            // 0x00AB76D4: LDR x20, [x8]              | X20 = "getContentLength";               
            // 0x00AB76D8: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB76DC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB76E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB76E4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB76E8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB76EC: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB76F0: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00AB76F4: LDR x8, [x8, #0x6c0]       | X8 = 1152921514875441712;               
            // 0x00AB76F8: LDR x3, [x8]               | X3 = public System.Int32 UnityEngine.AndroidJavaObject::Call<System.Int32>(string methodName, object[] args);
            // 0x00AB76FC: MOV x0, x21                | X0 = val_5;//m1                         
            // 0x00AB7700: MOV x1, x20                | X1 = 1152921514875441600 (0x10000002640E51C0);//ML01
            // 0x00AB7704: BL #0x12f5dd4              | X0 = val_5.Call<System.Int32>(methodName:  "getContentLength", args:  null);
            int val_6 = val_5.Call<System.Int32>(methodName:  "getContentLength", args:  null);
            // 0x00AB7708: MOV w20, w0                | W20 = val_6;//m1                        
            // 0x00AB770C: CMP w20, #1                | STATE = COMPARE(val_6, 0x1)             
            // 0x00AB7710: B.LT #0xab7750             | if (val_6 < 1) goto label_9;            
            if(val_6 < 1)
            {
                goto label_9;
            }
            // 0x00AB7714: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00AB7718: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x00AB771C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x00AB7720: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x00AB7724: TBZ w8, #0, #0xab7734      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00AB7728: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x00AB772C: CBNZ w8, #0xab7734         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00AB7730: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_11:
            // 0x00AB7734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7738: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB773C: ORR w2, wzr, #0x8000       | W2 = 32768(0x8000);                     
            // 0x00AB7740: MOV w1, w20                | W1 = val_6;//m1                         
            // 0x00AB7744: BL #0x1a6e2fc              | X0 = UnityEngine.Mathf.Min(a:  0, b:  val_6);
            int val_7 = UnityEngine.Mathf.Min(a:  0, b:  val_6);
            // 0x00AB7748: MOV w20, w0                | W20 = val_7;//m1                        
            val_18 = val_7;
            // 0x00AB774C: B #0xab7754                |  goto label_12;                         
            goto label_12;
            label_9:
            // 0x00AB7750: ORR w20, wzr, #0x8000      | W20 = 32768(0x8000);                    
            val_18 = 32768;
            label_12:
            // 0x00AB7754: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00AB7758: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00AB775C: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
            // 0x00AB7760: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AB7764: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AB7768: MOV w1, w20                | W1 = 32768 (0x8000);//ML01              
            // 0x00AB776C: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AB7770: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AB7774: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AB7778: CBNZ x21, #0xab7780        | if (val_5 != null) goto label_13;       
            if(val_5 != null)
            {
                goto label_13;
            }
            // 0x00AB777C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
            label_13:
            // 0x00AB7780: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00AB7784: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921514875442736)("getInputStream");
            // 0x00AB7788: LDR x23, [x24]             | X23 = typeof(System.Object[]);          
            // 0x00AB778C: LDR x22, [x8]              | X22 = "getInputStream";                 
            // 0x00AB7790: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB7794: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB7798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB779C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB77A0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB77A4: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB77A8: LDR x3, [x25]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
            // 0x00AB77AC: MOV x0, x21                | X0 = val_5;//m1                         
            // 0x00AB77B0: MOV x1, x22                | X1 = 1152921514875442736 (0x10000002640E5630);//ML01
            // 0x00AB77B4: BL #0x12f5e74              | X0 = val_5.Call<UnityEngine.AndroidJavaObject>(methodName:  "getInputStream", args:  null);
            UnityEngine.AndroidJavaObject val_8 = val_5.Call<UnityEngine.AndroidJavaObject>(methodName:  "getInputStream", args:  null);
            // 0x00AB77B8: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x00AB77BC: LDR x22, [x24]             | X22 = typeof(System.Object[]);          
            // 0x00AB77C0: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB77C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB77C8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AB77CC: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB77D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB77D4: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB77D8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00AB77DC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00AB77E0: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00AB77E4: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00AB77E8: LDR x8, [x8, #0x888]       | X8 = 1152921504996170800;               
            // 0x00AB77EC: LDR x23, [x8]              | X23 = typeof(System.Byte[]);            
            // 0x00AB77F0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00AB77F4: TBZ w8, #0, #0xab7804      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00AB77F8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00AB77FC: CBNZ w8, #0xab7804         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00AB7800: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_15:
            // 0x00AB7804: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7808: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB780C: MOV x1, x23                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AB7810: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00AB7814: MOV x23, x0                | X23 = val_9;//m1                        
            // 0x00AB7818: CBNZ x22, #0xab7820        | if ( != null) goto label_16;            
            if(null != null)
            {
                goto label_16;
            }
            // 0x00AB781C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_16:
            // 0x00AB7820: CBZ x23, #0xab7844         | if (val_9 == null) goto label_18;       
            if(val_9 == null)
            {
                goto label_18;
            }
            // 0x00AB7824: LDR x8, [x22]              | X8 = ;                                  
            // 0x00AB7828: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB782C: MOV x0, x23                | X0 = val_9;//m1                         
            // 0x00AB7830: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00AB7834: CBNZ x0, #0xab7844         | if (val_9 != null) goto label_18;       
            if(val_9 != null)
            {
                goto label_18;
            }
            // 0x00AB7838: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x00AB783C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7840: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_18:
            // 0x00AB7844: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB7848: CBNZ w8, #0xab7858         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_19;
            // 0x00AB784C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x00AB7850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7854: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_19:
            // 0x00AB7858: STR x23, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_9;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_9;
            // 0x00AB785C: CBNZ x21, #0xab7864        | if (val_8 != null) goto label_20;       
            if(val_8 != null)
            {
                goto label_20;
            }
            // 0x00AB7860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_20:
            // 0x00AB7864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7868: MOV x0, x21                | X0 = val_8;//m1                         
            // 0x00AB786C: BL #0x20b7380              | X0 = val_8.GetRawClass();               
            IntPtr val_10 = val_8.GetRawClass();
            // 0x00AB7870: MOV x23, x0                | X23 = val_10;//m1                       
            // 0x00AB7874: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00AB7878: LDR x8, [x8, #0x4f8]       | X8 = 1152921514875451024;               
            // 0x00AB787C: LDR x2, [x8]               | X2 = public static System.String UnityEngine.AndroidJNIHelper::GetSignature<System.Int32>(object[] args);
            // 0x00AB7880: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7884: MOV x1, x22                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB7888: BL #0x10cdf4c              | X0 = UnityEngine.AndroidJNIHelper.GetSignature<System.Int32>(args:  0);
            string val_11 = UnityEngine.AndroidJNIHelper.GetSignature<System.Int32>(args:  0);
            // 0x00AB788C: MOV x3, x0                 | X3 = val_11;//m1                        
            // 0x00AB7890: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00AB7894: LDR x8, [x8, #0xa18]       | X8 = (string**)(1152921514875456144)("read");
            // 0x00AB7898: LDR x2, [x8]               | X2 = "read";                            
            // 0x00AB789C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB78A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AB78A4: MOV x1, x23                | X1 = val_10;//m1                        
            // 0x00AB78A8: BL #0x20c42a8              | X0 = UnityEngine.AndroidJNIHelper.GetMethodID(javaClass:  0, methodName:  val_10, signature:  "read");
            IntPtr val_12 = UnityEngine.AndroidJNIHelper.GetMethodID(javaClass:  0, methodName:  val_10, signature:  "read");
            // 0x00AB78AC: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x00AB78B0: LDR x23, [x24]             | X23 = typeof(System.Object[]);          
            // 0x00AB78B4: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB78B8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB78BC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AB78C0: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB78C4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB78C8: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB78CC: CBNZ x23, #0xab78d4        | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x00AB78D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_21:
            // 0x00AB78D4: CBZ x20, #0xab78f8         | if ( == null) goto label_23;            
            if(null == null)
            {
                goto label_23;
            }
            // 0x00AB78D8: LDR x8, [x23]              | X8 = ;                                  
            // 0x00AB78DC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB78E0: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AB78E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Byte[]), ????);
            // 0x00AB78E8: CBNZ x0, #0xab78f8         | if ( != null) goto label_23;            
            if(null != null)
            {
                goto label_23;
            }
            // 0x00AB78EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(System.Byte[]), ????);
            // 0x00AB78F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB78F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_23:
            // 0x00AB78F8: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB78FC: CBNZ w8, #0xab790c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_24;
            // 0x00AB7900: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
            // 0x00AB7904: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7908: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
            label_24:
            // 0x00AB790C: STR x20, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = typeof(System.Byte[]);  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = null;
            // 0x00AB7910: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7914: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB7918: MOV x1, x23                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB791C: BL #0x20be290              | X0 = UnityEngine.AndroidJNIHelper.CreateJNIArgArray(args:  0);
            UnityEngine.jvalue[] val_13 = UnityEngine.AndroidJNIHelper.CreateJNIArgArray(args:  0);
            // 0x00AB7920: MOV x20, x0                | X20 = val_13;//m1                       
            // 0x00AB7924: CBNZ x21, #0xab792c        | if (val_8 != null) goto label_25;       
            if(val_8 != null)
            {
                goto label_25;
            }
            // 0x00AB7928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_25:
            // 0x00AB792C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7930: MOV x0, x21                | X0 = val_8;//m1                         
            // 0x00AB7934: BL #0x20b7a48              | X0 = val_8.GetRawObject();              
            IntPtr val_14 = val_8.GetRawObject();
            // 0x00AB7938: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00AB793C: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
            // 0x00AB7940: LDR x25, [x25, #0xcf0]     | X25 = 1152921514875493088;              
            label_30:
            // 0x00AB7944: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7948: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AB794C: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x00AB7950: MOV x2, x22                | X2 = val_12;//m1                        
            // 0x00AB7954: MOV x3, x20                | X3 = val_13;//m1                        
            // 0x00AB7958: BL #0x20c0b54              | X0 = UnityEngine.AndroidJNI.CallIntMethod(obj:  0, methodID:  val_14, args:  val_12);
            int val_15 = UnityEngine.AndroidJNI.CallIntMethod(obj:  0, methodID:  val_14, args:  val_12);
            // 0x00AB795C: MOV w23, w0                | W23 = val_15;//m1                       
            // 0x00AB7960: CMN w23, #1                | STATE = COMPARE(val_15, 0x1)            
            // 0x00AB7964: B.EQ #0xab7a00             | if (val_15 == 1) goto label_26;         
            if(val_15 == 1)
            {
                goto label_26;
            }
            // 0x00AB7968: CBNZ x20, #0xab7970        | if (val_13 != null) goto label_27;      
            if(val_13 != null)
            {
                goto label_27;
            }
            // 0x00AB796C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_27:
            // 0x00AB7970: LDR w8, [x20, #0x18]       | W8 = val_13.Length; //P2                
            // 0x00AB7974: CBNZ w8, #0xab7984         | if (val_13.Length != 0) goto label_28;  
            if(val_13.Length != 0)
            {
                goto label_28;
            }
            // 0x00AB7978: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x00AB797C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7980: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_28:
            // 0x00AB7984: LDR x1, [x20, #0x20]       | X1 = val_13[0]                          
            UnityEngine.jvalue val_17 = val_13[0];
            // 0x00AB7988: LDR x2, [x25]              | X2 = public static System.Byte[] UnityEngine.AndroidJNIHelper::ConvertFromJNIArray<System.Byte[]>(IntPtr array);
            // 0x00AB798C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7990: BL #0x12e045c              | X0 = UnityEngine.AndroidJNIHelper.ConvertFromJNIArray<System.Byte[]>(array:  0);
            System.Byte[] val_16 = UnityEngine.AndroidJNIHelper.ConvertFromJNIArray<System.Byte[]>(array:  0);
            // 0x00AB7994: MOV x24, x0                | X24 = val_16;//m1                       
            // 0x00AB7998: CBNZ x19, #0xab79a0        | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x00AB799C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_29:
            // 0x00AB79A0: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB79A4: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
            // 0x00AB79A8: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
            // 0x00AB79AC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AB79B0: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x00AB79B4: MOV x1, x24                | X1 = val_16;//m1                        
            // 0x00AB79B8: MOV w3, w23                | W3 = val_15;//m1                        
            // 0x00AB79BC: BLR x9                     | X0 = mem[null + 608]();                 
            // 0x00AB79C0: B #0xab7944                |  goto label_30;                         
            goto label_30;
            label_33:
            // 0x00AB79C4: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            val_19 = val_17;
            // 0x00AB79C8: CMP w1, #1                 | STATE = COMPARE(val_16, 0x1)            
            // 0x00AB79CC: B.NE #0xab7a48             | if (val_16 != 0x1) goto label_31;       
            if(val_16 != 1)
            {
                goto label_31;
            }
            // 0x00AB79D0: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x00AB79D4: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.MemoryStream), ????);
            // 0x00AB79D8: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
            // 0x00AB79DC: ADRP x9, #0x3638000        | X9 = 56852480 (0x3638000);              
            // 0x00AB79E0: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB79E4: LDR x9, [x9, #0xf90]       | X9 = 1152921504606900224;               
            // 0x00AB79E8: LDR x1, [x8]               |  //  not_find_field!1:0
            // 0x00AB79EC: LDR x0, [x9]               | X0 = typeof(System.Object);             
            // 0x00AB79F0: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Object), ????);
            // 0x00AB79F4: TBZ w0, #0, #0xab7a20      | if ((typeof(System.Object) & 0x1) == 0) goto label_32;
            if((null & 1) == 0)
            {
                goto label_32;
            }
            // 0x00AB79F8: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Object), ????);
            // 0x00AB79FC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_17 = 0;
            label_26:
            // 0x00AB7A00: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7A04: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7A08: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB7A0C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB7A10: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB7A14: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB7A18: RET                        |  return (System.IO.MemoryStream)null;   
            return (System.IO.MemoryStream)val_17;
            //  |  // // {name=val_0, type=System.IO.MemoryStream, size=8, nGRN=0 }
            // 0x00AB7A1C: B #0xab79c4                |  goto label_33;                         
            goto label_33;
            label_32:
            // 0x00AB7A20: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00AB7A24: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x00AB7A28: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB7A2C: STR x8, [x0]               | mem[8] = ;                               //  dest_result_addr=8
            mem[8] = null;
            // 0x00AB7A30: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x00AB7A34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB7A38: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x00AB7A3C: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x00AB7A40: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
            val_19 = 8;
            // 0x00AB7A44: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            label_31:
            // 0x00AB7A48: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
            // 0x00AB7A4C: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
            // 0x00AB7A50: BL #0xab7a54               |  R0 = label_34();                       
            label_34:
            // 0x00AB7A54: STP x29, x30, [sp, #-0x10]! | stack[1152921514959557888] = ;  stack[1152921514959557896] = ???;  //  dest_result_addr=1152921514959557888 |  dest_result_addr=1152921514959557896
            // 0x00AB7A58: MOV x29, sp                | X29 = 1152921514959557888 (0x100000026911D500);//ML01
            // 0x00AB7A5C: BL #0x981060               | X0 = sub_981060( ?? 0x8, ????);         
            // 0x00AB7A60: BL #0x97ff70               | X0 = sub_97FF70( ?? 0x8, ????);         
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB7A64 (11237988), len: 552  VirtAddr: 0x00AB7A64 RVA: 0x00AB7A64 token: 100693253 methodIndex: 47015 delegateWrapperIndex: 0 methodInvoker: 0
        public static void SaveCacheBundleFile(string assetBundleName, byte[] p1)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00AB7A64: STP x22, x21, [sp, #-0x30]! | stack[1152921514959862448] = ???;  stack[1152921514959862456] = ???;  //  dest_result_addr=1152921514959862448 |  dest_result_addr=1152921514959862456
            // 0x00AB7A68: STP x20, x19, [sp, #0x10]  | stack[1152921514959862464] = ???;  stack[1152921514959862472] = ???;  //  dest_result_addr=1152921514959862464 |  dest_result_addr=1152921514959862472
            // 0x00AB7A6C: STP x29, x30, [sp, #0x20]  | stack[1152921514959862480] = ???;  stack[1152921514959862488] = ???;  //  dest_result_addr=1152921514959862480 |  dest_result_addr=1152921514959862488
            // 0x00AB7A70: ADD x29, sp, #0x20         | X29 = (1152921514959862448 + 32) = 1152921514959862480 (0x1000000269167AD0);
            // 0x00AB7A74: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AB7A78: LDRB w8, [x21, #0x419]     | W8 = (bool)static_value_03733419;       
            // 0x00AB7A7C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00AB7A80: MOV x19, x1                | X19 = p1;//m1                           
            // 0x00AB7A84: TBNZ w8, #0, #0xab7aa0     | if (static_value_03733419 == true) goto label_0;
            // 0x00AB7A88: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x00AB7A8C: LDR x8, [x8, #0x518]       | X8 = 0x2B8EBD0;                         
            // 0x00AB7A90: LDR w0, [x8]               | W0 = 0x11B4;                            
            // 0x00AB7A94: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B4, ????);     
            // 0x00AB7A98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB7A9C: STRB w8, [x21, #0x419]     | static_value_03733419 = true;            //  dest_result_addr=57881625
            label_0:
            // 0x00AB7AA0: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00AB7AA4: BL #0xab7c8c               | X0 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  4532);
            System.Byte[] val_1 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  4532);
            // 0x00AB7AA8: ADRP x21, #0x35ef000       | X21 = 56553472 (0x35EF000);             
            // 0x00AB7AAC: LDR x21, [x21, #0xde8]     | X21 = 1152921504911265792;              
            // 0x00AB7AB0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AB7AB4: LDR x8, [x21]              | X8 = typeof(Loader.PathUtil);           
            val_14 = null;
            // 0x00AB7AB8: LDRB w9, [x8, #0x10a]      | W9 = Loader.PathUtil.__il2cppRuntimeField_10A;
            // 0x00AB7ABC: TBZ w9, #0, #0xab7ad4      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB7AC0: LDR w9, [x8, #0xbc]        | W9 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB7AC4: CBNZ w9, #0xab7ad4         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB7AC8: MOV x0, x8                 | X0 = 1152921504911265792 (0x1000000012251000);//ML01
            // 0x00AB7ACC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
            // 0x00AB7AD0: LDR x8, [x21]              | X8 = typeof(Loader.PathUtil);           
            val_14 = null;
            label_2:
            // 0x00AB7AD4: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00AB7AD8: LDR x8, [x8, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB7ADC: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x00AB7AE0: LDR x21, [x8, #0x28]       | X21 = Loader.PathUtil.persistentDataPath;
            // 0x00AB7AE4: LDR x0, [x9]               | X0 = typeof(System.String);             
            // 0x00AB7AE8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB7AEC: TBZ w8, #0, #0xab7afc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00AB7AF0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB7AF4: CBNZ w8, #0xab7afc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00AB7AF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_4:
            // 0x00AB7AFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7B00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB7B04: MOV x1, x21                | X1 = Loader.PathUtil.persistentDataPath;//m1
            // 0x00AB7B08: MOV x2, x19                | X2 = p1;//m1                            
            // 0x00AB7B0C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
            string val_2 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
            // 0x00AB7B10: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00AB7B14: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00AB7B18: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AB7B1C: LDR x8, [x8]               | X8 = typeof(System.IO.Path);            
            // 0x00AB7B20: LDRB w9, [x8, #0x10a]      | W9 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00AB7B24: TBZ w9, #0, #0xab7b38      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB7B28: LDR w9, [x8, #0xbc]        | W9 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00AB7B2C: CBNZ w9, #0xab7b38         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB7B30: MOV x0, x8                 | X0 = 1152921504622075904 (0x1000000000E86000);//ML01
            // 0x00AB7B34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_6:
            // 0x00AB7B38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7B3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB7B40: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00AB7B44: BL #0x1e6bf14              | X0 = System.IO.Path.GetDirectoryName(path:  0);
            string val_3 = System.IO.Path.GetDirectoryName(path:  0);
            // 0x00AB7B48: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00AB7B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7B50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB7B54: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB7B58: BL #0x1e6aa78              | X0 = System.IO.Directory.Exists(path:  0);
            bool val_4 = System.IO.Directory.Exists(path:  0);
            // 0x00AB7B5C: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x00AB7B60: TBNZ w8, #0, #0xab7b74     | if ((val_4 & 1) == true) goto label_7;  
            if(val_5 == true)
            {
                goto label_7;
            }
            // 0x00AB7B64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7B68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB7B6C: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB7B70: BL #0x1e6922c              | X0 = System.IO.Directory.CreateDirectory(path:  0);
            System.IO.DirectoryInfo val_6 = System.IO.Directory.CreateDirectory(path:  0);
            label_7:
            // 0x00AB7B74: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00AB7B78: LDR x8, [x8, #0x558]       | X8 = 1152921504621490176;               
            // 0x00AB7B7C: LDR x0, [x8]               | X0 = typeof(System.IO.FileStream);      
            System.IO.FileStream val_7 = null;
            // 0x00AB7B80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileStream), ????);
            // 0x00AB7B84: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00AB7B88: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00AB7B8C: ORR w3, wzr, #2            | W3 = 2(0x2);                            
            // 0x00AB7B90: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x00AB7B94: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00AB7B98: MOV x19, x0                | X19 = 1152921504621490176 (0x1000000000DF7000);//ML01
            val_15 = val_7;
            // 0x00AB7B9C: BL #0x1e70970              | .ctor(path:  val_2, mode:  2, access:  2, share:  1);
            val_7 = new System.IO.FileStream(path:  val_2, mode:  2, access:  2, share:  1);
            // 0x00AB7BA0: CBNZ x20, #0xab7ba8        | if (val_1 != null) goto label_8;        
            if(val_1 != null)
            {
                goto label_8;
            }
            // 0x00AB7BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(path:  val_2, mode:  2, access:  2, share:  1), ????);
            label_8:
            // 0x00AB7BA8: CBNZ x19, #0xab7bb0        | if ( != 0) goto label_9;                
            if(null != 0)
            {
                goto label_9;
            }
            // 0x00AB7BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(path:  val_2, mode:  2, access:  2, share:  1), ????);
            label_9:
            // 0x00AB7BB0: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB7BB4: LDR w3, [x20, #0x18]       | W3 = val_1.Length; //P2                 
            // 0x00AB7BB8: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
            // 0x00AB7BBC: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
            // 0x00AB7BC0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AB7BC4: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x00AB7BC8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00AB7BCC: BLR x9                     | X0 = mem[null + 608]();                 
            // 0x00AB7BD0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00AB7BD4: MOVZ w21, #0x54            | W21 = 84 (0x54);//ML01                  
            val_16 = 84;
            label_17:
            // 0x00AB7BD8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00AB7BDC: LDR x8, [x19]              | X8 = ;                                  
            System.IO.FileStream val_16 = null;
            // 0x00AB7BE0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00AB7BE4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00AB7BE8: LDRH w9, [x8, #0x102]      |  //  not_find_field!1:258
            // 0x00AB7BEC: CBZ x9, #0xab7c18          | if (mem[null + 258] == 0) goto label_10;
            if((mem[null + 258]) == 0)
            {
                goto label_10;
            }
            // 0x00AB7BF0: LDR x10, [x8, #0x98]       |  //  not_find_field!1:152
            var val_14 = mem[null + 152];
            // 0x00AB7BF4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x00AB7BF8: ADD x10, x10, #8           | X10 = (mem[null + 152] + 8);            
            val_14 = val_14 + 8;
            label_12:
            // 0x00AB7BFC: LDUR x12, [x10, #-8]       | X12 = (mem[null + 152] + 8) + -8;       
            // 0x00AB7C00: CMP x12, x1                | STATE = COMPARE((mem[null + 152] + 8) + -8, typeof(System.IDisposable))
            // 0x00AB7C04: B.EQ #0xab7c28             | if ((mem[null + 152] + 8) + -8 == null) goto label_11;
            if(((mem[null + 152] + 8) + -8) == null)
            {
                goto label_11;
            }
            // 0x00AB7C08: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x00AB7C0C: ADD x10, x10, #0x10        | X10 = ((mem[null + 152] + 8) + 16);     
            val_14 = val_14 + 16;
            // 0x00AB7C10: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[null + 258])
            // 0x00AB7C14: B.LO #0xab7bfc             | if (0 < mem[null + 258]) goto label_12; 
            if(val_15 < (mem[null + 258]))
            {
                goto label_12;
            }
            label_10:
            // 0x00AB7C18: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AB7C1C: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            val_17 = val_15;
            // 0x00AB7C20: BL #0x2776c24              | X0 = sub_2776C24( ?? typeof(System.IO.FileStream), ????);
            // 0x00AB7C24: B #0xab7c34                |  goto label_13;                         
            goto label_13;
            label_11:
            // 0x00AB7C28: LDR w9, [x10]              | W9 = (mem[null + 152] + 8);             
            // 0x00AB7C2C: ADD x8, x8, x9, lsl #4     | X8 = (null + ((mem[null + 152] + 8)) << 4);
            val_16 = val_16 + (((mem[null + 152] + 8)) << 4);
            // 0x00AB7C30: ADD x0, x8, #0x110         |  //  not_find_field:(null + ((mem[null + 152] + 8)) << 4).272
            label_13:
            // 0x00AB7C34: LDP x8, x1, [x0]           | X8 = ; X1 = System.IO.FileStream.__il2cppRuntimeField_gc_desc; //  | 
            // 0x00AB7C38: MOV x0, x19                | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
            // 0x00AB7C3C: BLR x8                     | X0 = x8();                              
            label_16:
            // 0x00AB7C40: CBZ x20, #0xab7c64         | if (0x0 == 0) goto label_15;            
            if(0 == 0)
            {
                goto label_15;
            }
            // 0x00AB7C44: CMP w21, #0x54             | STATE = COMPARE(0x54, 0x54)             
            // 0x00AB7C48: B.EQ #0xab7c64             | if (0x54 == 0x54) goto label_15;        
            if(84 == 84)
            {
                goto label_15;
            }
            // 0x00AB7C4C: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00AB7C50: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB7C54: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_15 = ???;
            // 0x00AB7C58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB7C5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_16 = ???;
            // 0x00AB7C60: B #0x27ae3bc               | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_15:
            // 0x00AB7C64: LDP x29, x30, [sp, #0x20]  | X29 = val_8; X30 = val_9;                //  find_add[1152921514959850496] |  find_add[1152921514959850496]
            // 0x00AB7C68: LDP x20, x19, [sp, #0x10]  | X20 = val_10; X19 = val_11;              //  find_add[1152921514959850496] |  find_add[1152921514959850496]
            // 0x00AB7C6C: LDP x22, x21, [sp], #0x30  | X22 = val_12; X21 = val_13;              //  find_add[1152921514959850496] |  find_add[1152921514959850496]
            // 0x00AB7C70: RET                        |  return;                                
            return;
            // 0x00AB7C74: BL #0x981060               | 
            // 0x00AB7C78: LDR x20, [x0]              | 
            // 0x00AB7C7C: BL #0x980920               | 
            // 0x00AB7C80: MOV w21, wzr               | 
            // 0x00AB7C84: CBZ x19, #0xab7c40         | 
            // 0x00AB7C88: B #0xab7bd8                | 
        
        }
    
    }

}
