using UnityEngine;

namespace Mihua.Asset.ABLoadOperation
{
    public class AssetOperationSimulation : AssetOperation
    {
        // Fields
        protected UnityEngine.Object m_SimulatedObject; //  0x00000018
        
        // Properties
        public override float progress { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AB059C (11208092), len: 52  VirtAddr: 0x00AB059C RVA: 0x00AB059C token: 100693177 methodIndex: 46917 delegateWrapperIndex: 0 methodInvoker: 0
        public AssetOperationSimulation(UnityEngine.Object simulatedObject)
        {
            //
            // Disasemble & Code
            // 0x00AB059C: STP x20, x19, [sp, #-0x20]! | stack[1152921514948751344] = ???;  stack[1152921514948751352] = ???;  //  dest_result_addr=1152921514948751344 |  dest_result_addr=1152921514948751352
            // 0x00AB05A0: STP x29, x30, [sp, #0x10]  | stack[1152921514948751360] = ???;  stack[1152921514948751368] = ???;  //  dest_result_addr=1152921514948751360 |  dest_result_addr=1152921514948751368
            // 0x00AB05A4: ADD x29, sp, #0x10         | X29 = (1152921514948751344 + 16) = 1152921514948751360 (0x10000002686CF000);
            // 0x00AB05A8: MOV x19, x1                | X19 = simulatedObject;//m1              
            // 0x00AB05AC: MOV x20, x0                | X20 = 1152921514948763376 (0x10000002686D1EF0);//ML01
            // 0x00AB05B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB05B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB05B8: STRB w8, [x20, #0x11]      | mem[1152921514948763393] = 0x1;          //  dest_result_addr=1152921514948763393
            mem[1152921514948763393] = 1;
            // 0x00AB05BC: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00AB05C0: STR x19, [x20, #0x18]      | this.m_SimulatedObject = simulatedObject;  //  dest_result_addr=1152921514948763400
            this.m_SimulatedObject = simulatedObject;
            // 0x00AB05C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB05C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB05CC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB05D0 (11208144), len: 8  VirtAddr: 0x00AB05D0 RVA: 0x00AB05D0 token: 100693178 methodIndex: 46918 delegateWrapperIndex: 0 methodInvoker: 0
        public override UnityEngine.Object GetAsset()
        {
            //
            // Disasemble & Code
            // 0x00AB05D0: LDR x0, [x0, #0x18]        | X0 = this.m_SimulatedObject; //P2       
            // 0x00AB05D4: RET                        |  return (UnityEngine.Object)this.m_SimulatedObject;
            return this.m_SimulatedObject;
            //  |  // // {name=val_0, type=UnityEngine.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB05D8 (11208152), len: 8  VirtAddr: 0x00AB05D8 RVA: 0x00AB05D8 token: 100693179 methodIndex: 46919 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool Update()
        {
            //
            // Disasemble & Code
            // 0x00AB05D8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00AB05DC: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB05E0 (11208160), len: 8  VirtAddr: 0x00AB05E0 RVA: 0x00AB05E0 token: 100693180 methodIndex: 46920 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool IsDone()
        {
            //
            // Disasemble & Code
            // 0x00AB05E0: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00AB05E4: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB05E8 (11208168), len: 8  VirtAddr: 0x00AB05E8 RVA: 0x00AB05E8 token: 100693181 methodIndex: 46921 delegateWrapperIndex: 0 methodInvoker: 0
        public override float get_progress()
        {
            //
            // Disasemble & Code
            // 0x00AB05E8: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x00AB05EC: RET                        |  return (System.Single)1;               
            return 1f;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB05F0 (11208176), len: 4  VirtAddr: 0x00AB05F0 RVA: 0x00AB05F0 token: 100693182 methodIndex: 46922 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Clear()
        {
            //
            // Disasemble & Code
            // 0x00AB05F0: RET                        |  return;                                
            return;
        
        }
    
    }

}
