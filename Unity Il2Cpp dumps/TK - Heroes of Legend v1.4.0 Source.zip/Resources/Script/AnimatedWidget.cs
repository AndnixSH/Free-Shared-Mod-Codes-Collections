using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x28673C0
public class AnimatedWidget : MonoBehaviour
{
    // Fields
    public float width; //  0x00000018
    public float height; //  0x0000001C
    private UIWidget mWidget; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B27548 (11695432), len: 16  VirtAddr: 0x00B27548 RVA: 0x00B27548 token: 100688423 methodIndex: 24784 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimatedWidget()
    {
        //
        // Disasemble & Code
        // 0x00B27548: ORR x8, xzr, #0x3f8000003f800000 | X8 = 4575657222473777152(0x3F8000003F800000);
        // 0x00B2754C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27550: STR x8, [x0, #0x18]        | this.width = 1; this.height = 1;         //  dest_result_addr=1152921514237357112 dest_result_addr=1152921514237357116
        this.width = 1f;
        this.height = 1f;
        // 0x00B27554: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27558 (11695448), len: 92  VirtAddr: 0x00B27558 RVA: 0x00B27558 token: 100688424 methodIndex: 24785 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEnable()
    {
        //
        // Disasemble & Code
        // 0x00B27558: STP x20, x19, [sp, #-0x20]! | stack[1152921514237461152] = ???;  stack[1152921514237461160] = ???;  //  dest_result_addr=1152921514237461152 |  dest_result_addr=1152921514237461160
        // 0x00B2755C: STP x29, x30, [sp, #0x10]  | stack[1152921514237461168] = ???;  stack[1152921514237461176] = ???;  //  dest_result_addr=1152921514237461168 |  dest_result_addr=1152921514237461176
        // 0x00B27560: ADD x29, sp, #0x10         | X29 = (1152921514237461152 + 16) = 1152921514237461168 (0x100000023E0782B0);
        // 0x00B27564: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B27568: LDRB w8, [x20, #0x74b]     | W8 = (bool)static_value_0373374B;       
        // 0x00B2756C: MOV x19, x0                | X19 = 1152921514237473184 (0x100000023E07B1A0);//ML01
        // 0x00B27570: TBNZ w8, #0, #0xb2758c     | if (static_value_0373374B == true) goto label_0;
        // 0x00B27574: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
        // 0x00B27578: LDR x8, [x8, #0x878]       | X8 = 0x2B8ADBC;                         
        // 0x00B2757C: LDR w0, [x8]               | W0 = 0x22D;                             
        // 0x00B27580: BL #0x2782188              | X0 = sub_2782188( ?? 0x22D, ????);      
        // 0x00B27584: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B27588: STRB w8, [x20, #0x74b]     | static_value_0373374B = true;            //  dest_result_addr=57882443
        label_0:
        // 0x00B2758C: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B27590: LDR x8, [x8, #0x940]       | X8 = 1152921511725110736;               
        // 0x00B27594: MOV x0, x19                | X0 = 1152921514237473184 (0x100000023E07B1A0);//ML01
        // 0x00B27598: LDR x1, [x8]               | X1 = public UIWidget UnityEngine.Component::GetComponent<UIWidget>();
        // 0x00B2759C: BL #0x23d5410              | X0 = this.GetComponent<UIWidget>();     
        UIWidget val_1 = this.GetComponent<UIWidget>();
        // 0x00B275A0: STR x0, [x19, #0x20]       | this.mWidget = val_1;                    //  dest_result_addr=1152921514237473216
        this.mWidget = val_1;
        // 0x00B275A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B275A8: MOV x0, x19                | X0 = 1152921514237473184 (0x100000023E07B1A0);//ML01
        // 0x00B275AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B275B0: B #0xb275b4                | this.LateUpdate(); return;              
        this.LateUpdate();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B275B4 (11695540), len: 288  VirtAddr: 0x00B275B4 RVA: 0x00B275B4 token: 100688425 methodIndex: 24786 delegateWrapperIndex: 0 methodInvoker: 0
    private void LateUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B275B4: STP d9, d8, [sp, #-0x40]!  | stack[1152921514237589504] = ???;  stack[1152921514237589512] = ???;  //  dest_result_addr=1152921514237589504 |  dest_result_addr=1152921514237589512
        // 0x00B275B8: STP x22, x21, [sp, #0x10]  | stack[1152921514237589520] = ???;  stack[1152921514237589528] = ???;  //  dest_result_addr=1152921514237589520 |  dest_result_addr=1152921514237589528
        // 0x00B275BC: STP x20, x19, [sp, #0x20]  | stack[1152921514237589536] = ???;  stack[1152921514237589544] = ???;  //  dest_result_addr=1152921514237589536 |  dest_result_addr=1152921514237589544
        // 0x00B275C0: STP x29, x30, [sp, #0x30]  | stack[1152921514237589552] = ???;  stack[1152921514237589560] = ???;  //  dest_result_addr=1152921514237589552 |  dest_result_addr=1152921514237589560
        // 0x00B275C4: ADD x29, sp, #0x30         | X29 = (1152921514237589504 + 48) = 1152921514237589552 (0x100000023E097830);
        // 0x00B275C8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B275CC: LDRB w8, [x20, #0x74c]     | W8 = (bool)static_value_0373374C;       
        // 0x00B275D0: MOV x19, x0                | X19 = 1152921514237601568 (0x100000023E09A720);//ML01
        // 0x00B275D4: TBNZ w8, #0, #0xb275f0     | if (static_value_0373374C == true) goto label_0;
        // 0x00B275D8: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
        // 0x00B275DC: LDR x8, [x8, #0x730]       | X8 = 0x2B8ADB8;                         
        // 0x00B275E0: LDR w0, [x8]               | W0 = 0x22C;                             
        // 0x00B275E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x22C, ????);      
        // 0x00B275E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B275EC: STRB w8, [x20, #0x74c]     | static_value_0373374C = true;            //  dest_result_addr=57882444
        label_0:
        // 0x00B275F0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B275F4: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B275F8: LDR x20, [x19, #0x20]      | X20 = this.mWidget; //P2                
        // 0x00B275FC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B27600: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B27604: TBZ w8, #0, #0xb27614      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B27608: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B2760C: CBNZ w8, #0xb27614         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B27610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B27614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2761C: MOV x1, x20                | X1 = this.mWidget;//m1                  
        // 0x00B27620: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B27624: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mWidget);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mWidget);
        // 0x00B27628: TBZ w0, #0, #0xb276c0      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B2762C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B27630: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B27634: LDR x20, [x19, #0x20]      | X20 = this.mWidget; //P2                
        // 0x00B27638: LDR s8, [x19, #0x18]       | S8 = this.width; //P2                   
        // 0x00B2763C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B27640: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B27644: TBZ w8, #0, #0xb27654      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B27648: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B2764C: CBNZ w8, #0xb27654         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B27650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_5:
        // 0x00B27654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2765C: MOV v0.16b, v8.16b         | V0 = this.width;//m1                    
        // 0x00B27660: BL #0x1a7dc20              | X0 = UnityEngine.Mathf.RoundToInt(f:  this.width);
        int val_2 = UnityEngine.Mathf.RoundToInt(f:  this.width);
        // 0x00B27664: MOV w21, w0                | W21 = val_2;//m1                        
        // 0x00B27668: CBNZ x20, #0xb27670        | if (this.mWidget != null) goto label_6; 
        if(this.mWidget != null)
        {
            goto label_6;
        }
        // 0x00B2766C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B27670: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B27674: MOV x0, x20                | X0 = this.mWidget;//m1                  
        // 0x00B27678: MOV w1, w21                | W1 = val_2;//m1                         
        // 0x00B2767C: BL #0x152af84              | this.mWidget.set_width(value:  val_2);  
        this.mWidget.width = val_2;
        // 0x00B27680: LDR s0, [x19, #0x1c]       | S0 = this.height; //P2                  
        // 0x00B27684: LDR x20, [x19, #0x20]      | X20 = this.mWidget; //P2                
        // 0x00B27688: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2768C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27690: BL #0x1a7dc20              | X0 = UnityEngine.Mathf.RoundToInt(f:  this.height);
        int val_3 = UnityEngine.Mathf.RoundToInt(f:  this.height);
        // 0x00B27694: MOV w19, w0                | W19 = val_3;//m1                        
        // 0x00B27698: CBNZ x20, #0xb276a0        | if (this.mWidget != null) goto label_7; 
        if(this.mWidget != null)
        {
            goto label_7;
        }
        // 0x00B2769C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B276A0: MOV x0, x20                | X0 = this.mWidget;//m1                  
        // 0x00B276A4: MOV w1, w19                | W1 = val_3;//m1                         
        // 0x00B276A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B276AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B276B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B276B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B276B8: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B276BC: B #0x152b1f8               | this.mWidget.set_height(value:  val_3); return;
        this.mWidget.height = val_3;
        return;
        label_3:
        // 0x00B276C0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B276C4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B276C8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B276CC: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B276D0: RET                        |  return;                                
        return;
    
    }

}
