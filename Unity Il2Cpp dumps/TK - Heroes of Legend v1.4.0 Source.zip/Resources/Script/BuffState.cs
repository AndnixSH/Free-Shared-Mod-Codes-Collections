using UnityEngine;
public class BuffState : IObject
{
    // Fields
    public int buffID; //  0x00000010
    public BuffEnum.EBuffState buffState; //  0x00000018
    public int para1; //  0x00000020
    public int para2; //  0x00000024
    public int para3; //  0x00000028
    public int para4; //  0x0000002C
    public int srcID; //  0x00000030
    public int count; //  0x00000034
    public float timer; //  0x00000038
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA2548 (12199240), len: 8  VirtAddr: 0x00BA2548 RVA: 0x00BA2548 token: 100692335 methodIndex: 25547 delegateWrapperIndex: 0 methodInvoker: 0
    public BuffState()
    {
        //
        // Disasemble & Code
        // 0x00BA2548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA254C: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA0C24 (12192804), len: 28  VirtAddr: 0x00BA0C24 RVA: 0x00BA0C24 token: 100692336 methodIndex: 25548 delegateWrapperIndex: 0 methodInvoker: 0
    public void Setup(int _buffID, BuffEnum.EBuffState _buffState, int _para1, int _para2, int _para3, int _para4, int _srcID)
    {
        //
        // Disasemble & Code
        // 0x00BA0C24: STR w1, [x0, #0x10]        | this.buffID = _buffID;                   //  dest_result_addr=1152921514800479184
        this.buffID = _buffID;
        // 0x00BA0C28: STR x2, [x0, #0x18]        | this.buffState = _buffState;             //  dest_result_addr=1152921514800479192
        this.buffState = _buffState;
        // 0x00BA0C2C: STP w3, w4, [x0, #0x20]    | this.para1 = _para1;  this.para2 = _para2;  //  dest_result_addr=1152921514800479200 |  dest_result_addr=1152921514800479204
        this.para1 = _para1;
        this.para2 = _para2;
        // 0x00BA0C30: STP w5, w6, [x0, #0x28]    | this.para3 = _para3;  this.para4 = _para4;  //  dest_result_addr=1152921514800479208 |  dest_result_addr=1152921514800479212
        this.para3 = _para3;
        this.para4 = _para4;
        // 0x00BA0C34: STP w7, wzr, [x0, #0x30]   | this.srcID = _srcID;  this.count = 0;    //  dest_result_addr=1152921514800479216 |  dest_result_addr=1152921514800479220
        this.srcID = _srcID;
        this.count = 0;
        // 0x00BA0C38: STR wzr, [x0, #0x38]       | this.timer = 0;                          //  dest_result_addr=1152921514800479224
        this.timer = 0f;
        // 0x00BA0C3C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2550 (12199248), len: 20  VirtAddr: 0x00BA2550 RVA: 0x00BA2550 token: 100692337 methodIndex: 25549 delegateWrapperIndex: 0 methodInvoker: 0
    public void Reset()
    {
        //
        // Disasemble & Code
        // 0x00BA2550: STR wzr, [x0, #0x10]       | this.buffID = 0;                         //  dest_result_addr=1152921514800595280
        this.buffID = 0;
        // 0x00BA2554: STR wzr, [x0, #0x38]       | this.timer = 0;                          //  dest_result_addr=1152921514800595320
        this.timer = 0f;
        // 0x00BA2558: STP xzr, xzr, [x0, #0x28]  | this.para3 = 0; this.para4 = 0;  this.srcID = 0; this.count = 0;  //  dest_result_addr=1152921514800595304 dest_result_addr=1152921514800595308 |  dest_result_addr=1152921514800595312 dest_result_addr=1152921514800595316
        this.para3 = 0;
        this.para4 = 0;
        this.srcID = 0;
        this.count = 0;
        // 0x00BA255C: STP xzr, xzr, [x0, #0x18]  | this.buffState = null;  this.para1 = 0; this.para2 = 0;  //  dest_result_addr=1152921514800595288 |  dest_result_addr=1152921514800595296 dest_result_addr=1152921514800595300
        this.buffState = 0;
        this.para1 = 0;
        this.para2 = 0;
        // 0x00BA2560: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2564 (12199268), len: 20  VirtAddr: 0x00BA2564 RVA: 0x00BA2564 token: 100692338 methodIndex: 25550 delegateWrapperIndex: 0 methodInvoker: 0
    public void Cleanup()
    {
        //
        // Disasemble & Code
        // 0x00BA2564: STR wzr, [x0, #0x10]       | this.buffID = 0;                         //  dest_result_addr=1152921514800707280
        this.buffID = 0;
        // 0x00BA2568: STR wzr, [x0, #0x38]       | this.timer = 0;                          //  dest_result_addr=1152921514800707320
        this.timer = 0f;
        // 0x00BA256C: STP xzr, xzr, [x0, #0x28]  | this.para3 = 0; this.para4 = 0;  this.srcID = 0; this.count = 0;  //  dest_result_addr=1152921514800707304 dest_result_addr=1152921514800707308 |  dest_result_addr=1152921514800707312 dest_result_addr=1152921514800707316
        this.para3 = 0;
        this.para4 = 0;
        this.srcID = 0;
        this.count = 0;
        // 0x00BA2570: STP xzr, xzr, [x0, #0x18]  | this.buffState = null;  this.para1 = 0; this.para2 = 0;  //  dest_result_addr=1152921514800707288 |  dest_result_addr=1152921514800707296 dest_result_addr=1152921514800707300
        this.buffState = 0;
        this.para1 = 0;
        this.para2 = 0;
        // 0x00BA2574: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA0F04 (12193540), len: 312  VirtAddr: 0x00BA0F04 RVA: 0x00BA0F04 token: 100692339 methodIndex: 25551 delegateWrapperIndex: 0 methodInvoker: 0
    public BuffState Clone()
    {
        //
        // Disasemble & Code
        //  | 
        int val_2;
        //  | 
        float val_3;
        // 0x00BA0F04: STP d9, d8, [sp, #-0x40]!  | stack[1152921514800815392] = ???;  stack[1152921514800815400] = ???;  //  dest_result_addr=1152921514800815392 |  dest_result_addr=1152921514800815400
        // 0x00BA0F08: STP x22, x21, [sp, #0x10]  | stack[1152921514800815408] = ???;  stack[1152921514800815416] = ???;  //  dest_result_addr=1152921514800815408 |  dest_result_addr=1152921514800815416
        // 0x00BA0F0C: STP x20, x19, [sp, #0x20]  | stack[1152921514800815424] = ???;  stack[1152921514800815432] = ???;  //  dest_result_addr=1152921514800815424 |  dest_result_addr=1152921514800815432
        // 0x00BA0F10: STP x29, x30, [sp, #0x30]  | stack[1152921514800815440] = ???;  stack[1152921514800815448] = ???;  //  dest_result_addr=1152921514800815440 |  dest_result_addr=1152921514800815448
        // 0x00BA0F14: ADD x29, sp, #0x30         | X29 = (1152921514800815392 + 48) = 1152921514800815440 (0x100000025F9B9D50);
        // 0x00BA0F18: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA0F1C: LDRB w8, [x20, #0xab5]     | W8 = (bool)static_value_03733AB5;       
        // 0x00BA0F20: MOV x19, x0                | X19 = 1152921514800827456 (0x100000025F9BCC40);//ML01
        // 0x00BA0F24: TBNZ w8, #0, #0xba0f40     | if (static_value_03733AB5 == true) goto label_0;
        // 0x00BA0F28: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00BA0F2C: LDR x8, [x8, #0xbb8]       | X8 = 0x2B8FDD4;                         
        // 0x00BA0F30: LDR w0, [x8]               | W0 = 0x1639;                            
        // 0x00BA0F34: BL #0x2782188              | X0 = sub_2782188( ?? 0x1639, ????);     
        // 0x00BA0F38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA0F3C: STRB w8, [x20, #0xab5]     | static_value_03733AB5 = true;            //  dest_result_addr=57883317
        label_0:
        // 0x00BA0F40: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00BA0F44: LDR x8, [x8, #0xec8]       | X8 = 1152921504898646016;               
        // 0x00BA0F48: LDR x0, [x8]               | X0 = typeof(BuffState);                 
        object val_1 = null;
        // 0x00BA0F4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BuffState), ????);
        // 0x00BA0F50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA0F54: MOV x20, x0                | X20 = 1152921504898646016 (0x1000000011648000);//ML01
        // 0x00BA0F58: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00BA0F5C: LDR w21, [x19, #0x10]      | W21 = this.buffID; //P2                 
        val_2 = this.buffID;
        // 0x00BA0F60: CBZ x20, #0xba0fa8         | if ( == 0) goto label_1;                
        if(null == 0)
        {
            goto label_1;
        }
        // 0x00BA0F64: STR w21, [x20, #0x10]      | typeof(BuffState).__il2cppRuntimeField_10 = this.buffID;  //  dest_result_addr=1152921504898646032
        typeof(BuffState).__il2cppRuntimeField_10 = val_2;
        // 0x00BA0F68: LDR x8, [x19, #0x18]       | X8 = this.buffState; //P2               
        // 0x00BA0F6C: STR x8, [x20, #0x18]       | typeof(BuffState).__il2cppRuntimeField_18 = this.buffState;  //  dest_result_addr=1152921504898646040
        typeof(BuffState).__il2cppRuntimeField_18 = this.buffState;
        // 0x00BA0F70: LDR w8, [x19, #0x20]       | W8 = this.para1; //P2                   
        // 0x00BA0F74: STR w8, [x20, #0x20]       | typeof(BuffState).__il2cppRuntimeField_20 = this.para1;  //  dest_result_addr=1152921504898646048
        typeof(BuffState).__il2cppRuntimeField_20 = this.para1;
        // 0x00BA0F78: LDR w8, [x19, #0x24]       | W8 = this.para2; //P2                   
        // 0x00BA0F7C: STR w8, [x20, #0x24]       | typeof(BuffState).__il2cppRuntimeField_24 = this.para2;  //  dest_result_addr=1152921504898646052
        typeof(BuffState).__il2cppRuntimeField_24 = this.para2;
        // 0x00BA0F80: LDR w8, [x19, #0x28]       | W8 = this.para3; //P2                   
        // 0x00BA0F84: STR w8, [x20, #0x28]       | typeof(BuffState).__il2cppRuntimeField_28 = this.para3;  //  dest_result_addr=1152921504898646056
        typeof(BuffState).__il2cppRuntimeField_28 = this.para3;
        // 0x00BA0F88: LDR w8, [x19, #0x2c]       | W8 = this.para4; //P2                   
        // 0x00BA0F8C: STR w8, [x20, #0x2c]       | typeof(BuffState).__il2cppRuntimeField_2C = this.para4;  //  dest_result_addr=1152921504898646060
        typeof(BuffState).__il2cppRuntimeField_2C = this.para4;
        // 0x00BA0F90: LDR w8, [x19, #0x30]       | W8 = this.srcID; //P2                   
        // 0x00BA0F94: STR w8, [x20, #0x30]       | typeof(BuffState).__il2cppRuntimeField_30 = this.srcID;  //  dest_result_addr=1152921504898646064
        typeof(BuffState).__il2cppRuntimeField_30 = this.srcID;
        // 0x00BA0F98: LDR w8, [x19, #0x34]       | W8 = this.count; //P2                   
        // 0x00BA0F9C: STR w8, [x20, #0x34]       | typeof(BuffState).__il2cppRuntimeField_34 = this.count;  //  dest_result_addr=1152921504898646068
        typeof(BuffState).__il2cppRuntimeField_34 = this.count;
        // 0x00BA0FA0: LDR s8, [x19, #0x38]       | S8 = this.timer; //P2                   
        val_3 = this.timer;
        // 0x00BA0FA4: B #0xba1020                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00BA0FA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA0FAC: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
        // 0x00BA0FB0: STR w21, [x8]              | mem[16] = this.buffID;                   //  dest_result_addr=16
        mem[16] = val_2;
        // 0x00BA0FB4: LDR x21, [x19, #0x18]      | X21 = this.buffState; //P2              
        // 0x00BA0FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA0FBC: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
        // 0x00BA0FC0: STR x21, [x8]              | mem[24] = this.buffState;                //  dest_result_addr=24
        mem[24] = this.buffState;
        // 0x00BA0FC4: LDR w21, [x19, #0x20]      | W21 = this.para1; //P2                  
        // 0x00BA0FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA0FCC: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00BA0FD0: STR w21, [x8]              | mem[32] = this.para1;                    //  dest_result_addr=32
        mem[32] = this.para1;
        // 0x00BA0FD4: LDR w21, [x19, #0x24]      | W21 = this.para2; //P2                  
        // 0x00BA0FD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA0FDC: STR w21, [x20, #0x24]      | typeof(BuffState).__il2cppRuntimeField_24 = this.para2;  //  dest_result_addr=1152921504898646052
        typeof(BuffState).__il2cppRuntimeField_24 = this.para2;
        // 0x00BA0FE0: LDR w21, [x19, #0x28]      | W21 = this.para3; //P2                  
        // 0x00BA0FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA0FE8: MOVZ w8, #0x28             | W8 = 40 (0x28);//ML01                   
        // 0x00BA0FEC: STR w21, [x8]              | mem[40] = this.para3;                    //  dest_result_addr=40
        mem[40] = this.para3;
        // 0x00BA0FF0: LDR w21, [x19, #0x2c]      | W21 = this.para4; //P2                  
        // 0x00BA0FF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA0FF8: STR w21, [x20, #0x2c]      | typeof(BuffState).__il2cppRuntimeField_2C = this.para4;  //  dest_result_addr=1152921504898646060
        typeof(BuffState).__il2cppRuntimeField_2C = this.para4;
        // 0x00BA0FFC: LDR w21, [x19, #0x30]      | W21 = this.srcID; //P2                  
        // 0x00BA1000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA1004: ORR w8, wzr, #0x30         | W8 = 48(0x30);                          
        // 0x00BA1008: STR w21, [x8]              | mem[48] = this.srcID;                    //  dest_result_addr=48
        mem[48] = this.srcID;
        // 0x00BA100C: LDR w21, [x19, #0x34]      | W21 = this.count; //P2                  
        val_2 = this.count;
        // 0x00BA1010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00BA1014: STR w21, [x20, #0x34]      | typeof(BuffState).__il2cppRuntimeField_34 = this.count;  //  dest_result_addr=1152921504898646068
        typeof(BuffState).__il2cppRuntimeField_34 = val_2;
        // 0x00BA1018: LDR s8, [x19, #0x38]       | S8 = this.timer; //P2                   
        val_3 = this.timer;
        // 0x00BA101C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_2:
        // 0x00BA1020: STR s8, [x20, #0x38]       | typeof(BuffState).__il2cppRuntimeField_38 = this.timer;  //  dest_result_addr=1152921504898646072
        typeof(BuffState).__il2cppRuntimeField_38 = val_3;
        // 0x00BA1024: MOV x0, x20                | X0 = 1152921504898646016 (0x1000000011648000);//ML01
        // 0x00BA1028: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA102C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA1030: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA1034: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00BA1038: RET                        |  return (BuffState)typeof(BuffState);   
        return (BuffState)val_1;
        //  |  // // {name=val_0, type=BuffState, size=8, nGRN=0 }
    
    }

}
