using UnityEngine;
[Serializable]
public enum ColorCorrectionMode
{
    // Fields
    Simple = 0
    ,Advanced = 1
    

}
